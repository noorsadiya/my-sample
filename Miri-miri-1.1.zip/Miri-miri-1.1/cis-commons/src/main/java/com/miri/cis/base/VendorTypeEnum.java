/**
 *
 */
package com.miri.cis.base;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Chandra
 *
 */
public enum VendorTypeEnum {

    MAP("map"), CRM("crm"), ERP("erp"), MANUAL("manual");
    private String text;

    private static Map<String, VendorTypeEnum> vendorTypeMapper = new HashMap<>();

    static {
        for (final VendorTypeEnum chartEnum : VendorTypeEnum.values()) {
            vendorTypeMapper.put(chartEnum.getText(), chartEnum);
        }
        vendorTypeMapper = Collections.unmodifiableMap(vendorTypeMapper);
    }

    public static Map<String, VendorTypeEnum> getVendorTypeMapper() {
        return vendorTypeMapper;
    }

    private VendorTypeEnum(final String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    /**
     * Returns String value corresponding to enum.
     *
     * @param text
     * @return
     */
    public static VendorTypeEnum fromString(final String text) {
        if (text != null) {
            for (final VendorTypeEnum jobType : VendorTypeEnum.values()) {
                if (text.equalsIgnoreCase(jobType.getText())) {
                    return jobType;
                }
            }
        }
        return null;
    }

}
