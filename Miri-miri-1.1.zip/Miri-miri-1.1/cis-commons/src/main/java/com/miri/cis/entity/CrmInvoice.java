
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for MAP Invoice document in elasticsearch
 * 
 * @author rammoole
 *
 */
@Component
public class CrmInvoice extends ESEntity {

	private static final long serialVersionUID = 2957663795790697533L;

	private String invoiceDocumentRefId;

	@CSVColumnRank(1)
	private String invoiceId;

	@CSVColumnRank(7)
	private String createdBy;

	@CSVColumnRank(6)
	private String description;

	private String lastModifiedBy;

	@CSVColumnRank(2)
	private String invoiceName;

	private String orderId;

	@CSVColumnRank(3)
	private String status;

	@CSVColumnRank(4)
	private String createdDate;

	@CSVColumnRank(5)
	private double invoiceAmount;

	@CSVColumnRank(8)
	private String lastModifiedDate;

	public String getInvoiceDocumentRefId() {
		return invoiceDocumentRefId;
	}

	public void setInvoiceDocumentRefId(String invoiceDocumentRefId) {
		this.invoiceDocumentRefId = invoiceDocumentRefId;
	}

	public String getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getInvoiceName() {
		return invoiceName;
	}

	public void setInvoiceName(String invoiceName) {
		this.invoiceName = invoiceName;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public double getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(double invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String getDocumentRefId() {
		return getInvoiceDocumentRefId();
	}

	private final String PREFIX = "CRM - Invoice";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

}
