package com.miri.cis.utilities;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;


public class JacksonUtils {

	private JacksonUtils() {}

	//NOTE: Do not add methods that can modify this internal ObjectMapper instance
	private static final ObjectMapper mapper = new ObjectMapper();

	public static <T> T readValue(String content, Class<T> valueType)
			throws IOException {
		return mapper.readValue(content, valueType);
	}

	public static <T> T convertValue(Object fromValue, Class<T> toValueType) {
		return mapper.convertValue(fromValue, toValueType);
	}

}
