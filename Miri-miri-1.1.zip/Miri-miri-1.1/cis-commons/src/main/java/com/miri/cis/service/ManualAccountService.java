package com.miri.cis.service;

import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.common.lang3.StringUtils;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.base.ElasticsearchConfig;
import com.miri.cis.utilities.DateUtilities;

@Component
public class ManualAccountService {

	private static Logger LOGGER = Logger.getLogger(ManualAccountService.class);

	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";

	public static final String LAST_MODIFIED_DATE = "lastModifiedDate";

	public static final Object FISCAL_START = "fiscalStart";

	@Autowired
	private ElasticsearchConfig elasticsearchConfig;

	/**
	 * Returns the Previous Nth year Dates
	 * @return Calendar
	 * @author Prem Kumar
	 */
	public Date getPreviousNyearStartDate(int years) {
		Date startDate = getFiscalStartDate();
		if (startDate != null) {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(startDate);
			calendar.add(Calendar.YEAR, -years);
			return calendar.getTime();
		} else {
			return null;
		}
	}

	public Date getFiscalStartDate() {
		String fiscalStart = getFiscalStartDateStr();
		if (StringUtils.isNotBlank(fiscalStart)) {
			return DateUtilities.stringToDateByPattern(fiscalStart, DATE_FORMAT_YYYY_MM_DD);
		} else {
			return null;
		}
	}

	public String getFiscalStartDateStr() {
		String fiscalStart = null;
		try {
			SearchRequestBuilder searchRequestBuilder = elasticsearchConfig.getTransportClient().prepareSearch(ElasticSearchEnums.MANUAL.getText())
					.setTypes(ElasticSearchEnums.ACCOUNT_STRATEGY.getText())
					.setSize(1)
					.addSort(LAST_MODIFIED_DATE, SortOrder.DESC);
			SearchResponse searchResponse = searchRequestBuilder.get();


			SearchHits searchHits = searchResponse.getHits();
			for(SearchHit hit: searchHits) {
				fiscalStart = hit.getSource().get(FISCAL_START).toString();
				if (StringUtils.isNotBlank(fiscalStart)) {
					break;
				}
			}
			// Since the date from elasticsearch will always be in 2015-10-05T10:38:48.056Z format. only date is required.
			return fiscalStart.split("T")[0];
		} catch(Exception e) {
			LOGGER.error("Error while Fetching Fiacal StartDate  "+e.getMessage(), e);
			return null;
		}
	}
}
