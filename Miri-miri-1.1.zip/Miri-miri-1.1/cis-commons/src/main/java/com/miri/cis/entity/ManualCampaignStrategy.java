/**
 *
 */
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * @author chavanka
 *
 */
@Component
public class ManualCampaignStrategy extends ESEntity {
	private static final long serialVersionUID = -6368875380204449628L;

	private String campaignStrategyDocumentRefId;
	private String campaignId;
	@CSVColumnRank(1)
	private String parentCampaignName;
	private String parentCampaignId;
	@CSVColumnRank(2)
	private String subCampaignName;
	private String campaignStart;
	private String campaignRuntime;
	private List<ProductFamily> productFamily = new ArrayList<ProductFamily>();
	private List<String> customerSeg = new ArrayList<String>();
	private List<String> targetAudience = new ArrayList<String>();
	private List<String> targetRegions = new ArrayList<String>();
	private List<String> leadSources = new ArrayList<String>();
	private List<String> touchpoints = new ArrayList<String>();
	private List<String> assets = new ArrayList<String>();
	@CSVColumnRank(3)
	private Integer totalCost;
	private Integer dealsClosed;
	private Integer marketingInfluencedRevenue;
	private boolean draft;
	private String createdBy;
	private String createdDate;
	private String updatedBy;
	private String updatedDate;
	private String campaignName;
	private String newCampaignName;
	private Set<String> editableFields;

	/**
	 *
	 * @return The campaignStrategyDocumentRefId
	 */
	public String getCampaignStrategyDocumentRefId() {
		return campaignStrategyDocumentRefId;
	}

	/**
	 *
	 * @param campaignStrategyDocumentRefId
	 *            The campaignStrategyDocumentRefId
	 */
	public void setCampaignStrategyDocumentRefId(String campaignStrategyDocumentRefId) {
		this.campaignStrategyDocumentRefId = campaignStrategyDocumentRefId;
	}

	/**
	 *
	 * @return The campaignId
	 */
	public String getCampaignId() {
		return campaignId;
	}

	/**
	 *
	 * @param campaignId
	 *            The campaignId
	 */
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	/**
	 *
	 * @return The parentCampaignName
	 */
	public String getParentCampaignName() {
		return parentCampaignName;
	}

	/**
	 *
	 * @param parentCampaignName
	 *            The parentCampaignName
	 */
	public void setParentCampaignName(String parentCampaignName) {
		this.parentCampaignName = parentCampaignName;
	}

	/**
	 *
	 * @return The parentCampaignId
	 */
	public String getParentCampaignId() {
		return parentCampaignId;
	}

	/**
	 *
	 * @param parentCampaignId
	 *            The parentCampaignId
	 */
	public void setParentCampaignId(String parentCampaignId) {
		this.parentCampaignId = parentCampaignId;
	}

	/**
	 *
	 * @return The subCampaignName
	 */
	public String getSubCampaignName() {
		return subCampaignName;
	}

	/**
	 *
	 * @param subCampaignName
	 *            The subCampaignName
	 */
	public void setSubCampaignName(String subCampaignName) {
		this.subCampaignName = subCampaignName;
	}

	/**
	 *
	 * @return The campaignStart
	 */
	public String getCampaignStart() {
		return campaignStart;
	}

	/**
	 *
	 * @param campaignStart
	 *            The campaignStart
	 */
	public void setCampaignStart(String campaignStart) {
		this.campaignStart = campaignStart;
	}

	/**
	 *
	 * @return The campaignRuntime
	 */
	public String getCampaignRuntime() {
		return campaignRuntime;
	}

	/**
	 *
	 * @param campaignRuntime
	 *            The campaignRuntime
	 */
	public void setCampaignRuntime(String campaignRuntime) {
		this.campaignRuntime = campaignRuntime;
	}

	/**
	 *
	 * @return The productFamily
	 */
	public List<ProductFamily> getProductFamily() {
		return productFamily;
	}

	/**
	 *
	 * @param productFamily
	 *            The productFamily
	 */
	public void setProductFamily(List<ProductFamily> productFamily) {
		this.productFamily = productFamily;
	}

	/**
	 *
	 * @return The customerSeg
	 */
	public List<String> getCustomerSeg() {
		return customerSeg;
	}

	/**
	 *
	 * @param customerSeg
	 *            The customerSeg
	 */
	public void setCustomerSeg(List<String> customerSeg) {
		this.customerSeg = customerSeg;
	}

	/**
	 *
	 * @return The targetAudience
	 */
	public List<String> getTargetAudience() {
		return targetAudience;
	}

	/**
	 *
	 * @param targetAudience
	 *            The targetAudience
	 */
	public void setTargetAudience(List<String> targetAudience) {
		this.targetAudience = targetAudience;
	}

	/**
	 *
	 * @return The targetRegions
	 */
	public List<String> getTargetRegions() {
		return targetRegions;
	}

	/**
	 *
	 * @param targetRegions
	 *            The targetRegions
	 */
	public void setTargetRegions(List<String> targetRegions) {
		this.targetRegions = targetRegions;
	}

	/**
	 *
	 * @return The leadSources
	 */
	public List<String> getLeadSources() {
		return leadSources;
	}

	/**
	 *
	 * @param leadSources
	 *            The leadSources
	 */
	public void setLeadSources(List<String> leadSources) {
		this.leadSources = leadSources;
	}

	/**
	 *
	 * @return The touchpoints
	 */
	public List<String> getTouchpoints() {
		return touchpoints;
	}

	/**
	 *
	 * @param touchpoints
	 *            The touchpoints
	 */
	public void setTouchpoints(List<String> touchpoints) {
		this.touchpoints = touchpoints;
	}

	/**
	 *
	 * @return The assets
	 */
	public List<String> getAssets() {
		return assets;
	}

	/**
	 *
	 * @param assets
	 *            The assets
	 */
	public void setAssets(List<String> assets) {
		this.assets = assets;
	}

	/**
	 *
	 * @return The totalCost
	 */
	public Integer getTotalCost() {
		return totalCost;
	}

	/**
	 *
	 * @param totalCost
	 *            The totalCost
	 */
	public void setTotalCost(Integer totalCost) {
		this.totalCost = totalCost;
	}

	/**
	 *
	 * @return The dealsClosed
	 */
	public Integer getDealsClosed() {
		return dealsClosed;
	}

	/**
	 *
	 * @param dealsClosed
	 *            The dealsClosed
	 */
	public void setDealsClosed(Integer dealsClosed) {
		this.dealsClosed = dealsClosed;
	}

	/**
	 *
	 * @return The marketingInfluencedRevenue
	 */
	public Integer getMarketingInfluencedRevenue() {
		return marketingInfluencedRevenue;
	}

	/**
	 *
	 * @param marketingInfluencedRevenue
	 *            The marketingInfluencedRevenue
	 */
	public void setMarketingInfluencedRevenue(Integer marketingInfluencedRevenue) {
		this.marketingInfluencedRevenue = marketingInfluencedRevenue;
	}

	/**
	 *
	 * @return The createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @return the draft
	 */
	public boolean isDraft() {
		return draft;
	}

	/**
	 * @param draft the draft to set
	 */
	public void setDraft(boolean draft) {
		this.draft = draft;
	}

	/**
	 * @return the editableFields
	 */
	public Set<String> getEditableFields() {
		return editableFields;
	}

	/**
	 * @param editableFields the editableFields to set
	 */
	public void setEditableFields(Set<String> editableFields) {
		this.editableFields = editableFields;
	}

	/**
	 *
	 * @param createdBy
	 *            The createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 *
	 * @return The createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 *
	 * @param createdDate
	 *            The createdDate
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 *
	 * @return The updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 *
	 * @param updatedBy
	 *            The updatedBy
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 *
	 * @return The updatedDate
	 */
	public String getUpdatedDate() {
		return updatedDate;
	}

	/**
	 *
	 * @param updatedDate
	 *            The updatedDate
	 */
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String getDocumentRefId() {
		// TODO Auto-generated method stub
		return campaignStrategyDocumentRefId;
	}

	/**
	 * @return the campaignName
	 */
	public String getCampaignName() {
		return campaignName;
	}

	/**
	 * @param campaignName the campaignName to set
	 */
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	/**
	 * @return the newCampaignName
	 */
	public String getNewCampaignName() {
		return newCampaignName;
	}

	/**
	 * @param newCampaignName the newCampaignName to set
	 */
	public void setNewCampaignName(String newCampaignName) {
		this.newCampaignName = newCampaignName;
	}

	private final String PREFIX = "Campaign Strategy";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}
}
