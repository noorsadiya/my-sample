
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for CRM Opportunity Product document in elasticsearch
 * 
 * @author rammoole
 *
 */
@Component
public class CrmOpportunityProduct extends ESEntity {

	private static final long serialVersionUID = -3781345916073996338L;

	private String opportunityProductDocumentRefId;

	@CSVColumnRank(1)
	private String opportunityId;

	@CSVColumnRank(2)
	private String product;

	@CSVColumnRank(3)
	private int quantity;

	@CSVColumnRank(4)
	private double listPrice;

	@CSVColumnRank(7)
	private double total;

	@CSVColumnRank(5)
	private double salesPrice;

	@CSVColumnRank(6)
	private String sortOrder;

	@CSVColumnRank(8)
	private String createdDate;

	@CSVColumnRank(10)
	private String lastModifiedDate;

	@CSVColumnRank(2.1)
	private String lineDescription;

	@CSVColumnRank(9)
	private String productCode;

	@CSVColumnRank(7.9)
	private String createdBy;

	@CSVColumnRank(10.1)
	private String lastModifiedBy;

	public String getOpportunityProductDocumentRefId() {
		return opportunityProductDocumentRefId;
	}

	public void setOpportunityProductDocumentRefId(String opportunityProductDocumentRefId) {
		this.opportunityProductDocumentRefId = opportunityProductDocumentRefId;
	}

	public String getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getListPrice() {
		return listPrice;
	}

	public void setListPrice(double listPrice) {
		this.listPrice = listPrice;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public double getSalesPrice() {
		return salesPrice;
	}

	public void setSalesPrice(double salesPrice) {
		this.salesPrice = salesPrice;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLineDescription() {
		return lineDescription;
	}

	public void setLineDescription(String lineDescription) {
		this.lineDescription = lineDescription;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	@Override
	public String getDocumentRefId() {
		return getOpportunityProductDocumentRefId();
	}

	private final String PREFIX = "CRM - Opportunity Product";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

}
