
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.miri.cis.base.annotations.CSVColumnRank;


/**
 * Entity for ERP opportunity document in Elasticsearch
 *
 * @author rammoole
 *
 */
@Component
public class ErpOpportunity extends ESEntity {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 7048827476661418805L;

	@CSVColumnRank(5)
	private String opportunityDocumentRefId;

	@CSVColumnRank(5)
	private String opportunityId;

	@CSVColumnRank(5)
	private String opportunityName;

	@CSVColumnRank(5)
	private String closedDate;

	@CSVColumnRank(5)
	private String owner;

	@CSVColumnRank(5)
	private String accountId;

	@CSVColumnRank(5)
	private String status;

	@CSVColumnRank(5)
	private String probability;

	@CSVColumnRank(5)
	private String opportunityType;

	@CSVColumnRank(7)
	private String companyName;

	@CSVColumnRank(5)
	private String website;

	@JsonUnwrapped(prefix="billing")
	@CSVColumnRank(5)
	private Address billingAddress;

	@JsonUnwrapped(prefix="shipping")
	@CSVColumnRank(5)
	private Address shippingAddress;

	@CSVColumnRank(5)
	private String location;

	@CSVColumnRank(5)
	private String salesRepName;

	@CSVColumnRank(5)
	private double expectedRevenue;

	@CSVColumnRank(10)
	private double opportunityAmount;

	@CSVColumnRank(5)
	private String createdBy;

	@CSVColumnRank(5)
	private String createdDate;

	@CSVColumnRank(5)
	private String lastModifiedBy;

	@CSVColumnRank(5)
	private String lastModifiedDate;

	public String getOpportunityDocumentRefId() {
		return opportunityDocumentRefId;
	}

	public void setOpportunityDocumentRefId(String opportunityDocumentRefId) {
		this.opportunityDocumentRefId = opportunityDocumentRefId;
	}

	public String getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getClosedDate() {
		return closedDate;
	}

	public void setClosedDate(String closedDate) {
		this.closedDate = closedDate;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getProbability() {
		return probability;
	}

	public void setProbability(String probability) {
		this.probability = probability;
	}

	public String getOpportunityType() {
		return opportunityType;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public Address getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}

	public Address getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(Address shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSalesRepName() {
		return salesRepName;
	}

	public void setSalesRepName(String salesRepName) {
		this.salesRepName = salesRepName;
	}

	public double getExpectedRevenue() {
		return expectedRevenue;
	}

	public void setExpectedRevenue(double expectedRevenue) {
		this.expectedRevenue = expectedRevenue;
	}

	public double getOpportunityAmount() {
		return opportunityAmount;
	}

	public void setOpportunityAmount(double opportunityAmount) {
		this.opportunityAmount = opportunityAmount;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String getDocumentRefId() {
		return getOpportunityDocumentRefId();
	}
	
	private final String PREFIX = "ERP - Opportunity";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}
}
