/**
 * 
 */
package com.miri.cis.base;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * VendorsEnum: Maintains all vendors names as ENUM values.
 * 
 * @author Chandra
 *
 */
public enum VendorsEnum {

	MARKETO("marketo"), ELOQUA("eloqua"), PARDOT("pardot"), SALESFORCE_CRM("salesforceCRM"), FUSION("fusion"), SAP_ERP(
			"sapERP"), NETSUITE("netsuite"), ORACLE_ERP("oracleERP"), CSV("csv");
	private String text;

	private static Map<String, VendorsEnum> vendorMapper = new HashMap<>();

	static {
		for (VendorsEnum chartEnum : VendorsEnum.values()) {
			vendorMapper.put(chartEnum.getText(), chartEnum);
		}
		vendorMapper = Collections.unmodifiableMap(vendorMapper);
	}

	public static Map<String, VendorsEnum> getChartMapper() {
		return vendorMapper;
	}

	private VendorsEnum(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}

	/**
	 * Returns String value corresponding to enum.
	 * 
	 * @param text
	 * @return
	 */
	public static VendorsEnum fromString(String text) {
		if (text != null) {
			for (VendorsEnum vendor : VendorsEnum.values()) {
				if (text.equalsIgnoreCase(vendor.getText())) {
					return vendor;
				}
			}
		}
		return null;
	}

}
