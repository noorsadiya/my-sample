
package com.miri.cis.entity;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for CRM Account document in elasticsearch
 * @author rammoole
 *
 */
@Component
public class CrmAccount extends ESEntity {

	/**
	 * Generated serial version UID
	 */
	private static final long serialVersionUID = -1037416177018188299L;

	private String accountDocumentRefId;

	@CSVColumnRank(1)
	private String accountId;

	@CSVColumnRank(1.1)
	private String accountName;

	@CSVColumnRank(2)
	private String externalCompanyId;

	@CSVColumnRank(5)
	private String createdBy;

	@CSVColumnRank(6)
	private String createdDate;

	private String lastModifiedBy;

	private String lastModifiedDate;

	@CSVColumnRank(4)
	private BigDecimal annualRevenue;

	@CSVColumnRank(7)
	private String region;

	//@JsonUnwrapped(prefix="billing")
	@CSVColumnRank(9)
	private Address billingAddress;

	//@JsonUnwrapped(prefix="shipping")
	@CSVColumnRank(9.1)
  	private Address shippingAddress;

  	@CSVColumnRank(6.5)
	private String industry;

  	@CSVColumnRank(6.1)
	private String sicCode;

  	@CSVColumnRank(6.2)
	private String website;

  	@CSVColumnRank(5.5)
	private String accountOwner;

	@CSVColumnRank(3)
	private String parentAccount;

	@CSVColumnRank(6.6)
	private String accountNumber;

	@CSVColumnRank(6.7)
	private String accountSource;

	@CSVColumnRank(5.6)
	private String contactOwner;

	@CSVColumnRank(6.2)
	private String tickerSymbol;

	@CSVColumnRank(7)
	private int numberOfLocations;

	@CSVColumnRank(8)
	private String upsellOpportunity;

	private String tradeStyle;

	@CSVColumnRank(10)
	private String site;

	public String getAccountDocumentRefId() {
		return accountDocumentRefId;
	}


	public String getAccountId() {
		return accountId;
	}


	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}


	public String getAccountName() {
		return accountName;
	}


	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public String getExternalCompanyId() {
		return externalCompanyId;
	}


	public void setExternalCompanyId(String externalCompanyId) {
		this.externalCompanyId = externalCompanyId;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public String getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}


	public String getLastModifiedBy() {
		return lastModifiedBy;
	}


	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}


	public String getLastModifiedDate() {
		return lastModifiedDate;
	}


	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}


	public BigDecimal getAnnualRevenue() {
		return annualRevenue;
	}


	public void setAnnualRevenue(BigDecimal annualRevenue) {
		this.annualRevenue = annualRevenue;
	}


	public String getRegion() {
		return region;
	}


	public void setRegion(String region) {
		this.region = region;
	}


	public Address getBillingAddress() {
		return billingAddress;
	}


	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}


	public Address getShippingAddress() {
		return shippingAddress;
	}


	public void setShippingAddress(Address shippingAddress) {
		this.shippingAddress = shippingAddress;
	}


	public String getIndustry() {
		return industry;
	}


	public void setIndustry(String industry) {
		this.industry = industry;
	}


	public String getSicCode() {
		return sicCode;
	}


	public void setSicCode(String sicCode) {
		this.sicCode = sicCode;
	}


	public String getWebsite() {
		return website;
	}


	public void setWebsite(String website) {
		this.website = website;
	}


	public String getAccountOwner() {
		return accountOwner;
	}


	public void setAccountOwner(String accountOwner) {
		this.accountOwner = accountOwner;
	}


	public String getParentAccount() {
		return parentAccount;
	}


	public void setParentAccount(String parentAccount) {
		this.parentAccount = parentAccount;
	}


	public String getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getAccountSource() {
		return accountSource;
	}


	public void setAccountSource(String accountSource) {
		this.accountSource = accountSource;
	}


	public String getContactOwner() {
		return contactOwner;
	}


	public void setContactOwner(String contactOwner) {
		this.contactOwner = contactOwner;
	}


	public String getTickerSymbol() {
		return tickerSymbol;
	}


	public void setTickerSymbol(String tickerSymbol) {
		this.tickerSymbol = tickerSymbol;
	}


	public int getNumberOfLocations() {
		return numberOfLocations;
	}


	public void setNumberOfLocations(int numberOfLocations) {
		this.numberOfLocations = numberOfLocations;
	}


	public String getUpsellOpportunity() {
		return upsellOpportunity;
	}


	public void setUpsellOpportunity(String upsellOpportunity) {
		this.upsellOpportunity = upsellOpportunity;
	}


	public String getTradeStyle() {
		return tradeStyle;
	}


	public void setTradeStyle(String tradeStyle) {
		this.tradeStyle = tradeStyle;
	}


	public String getSite() {
		return site;
	}


	public void setSite(String site) {
		this.site = site;
	}


	public void setAccountDocumentRefId(String accountDocumentRefId) {
		this.accountDocumentRefId = accountDocumentRefId;
	}


	@Override
	public String toString() {
		return "CrmAccount [accountDocumentRefId=" + accountDocumentRefId + ", accountId=" + accountId
				+ ", accountName=" + accountName + ", externalCompanyId=" + externalCompanyId + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + ", lastModifiedBy=" + lastModifiedBy
				+ ", lastModifiedDate=" + lastModifiedDate + ", annualRevenue=" + annualRevenue + ", billingAddress="
				+ billingAddress + ", shippingAddress=" + shippingAddress + ", industry=" + industry + ", sicCode="
				+ sicCode + ", website=" + website + ", accountOwner=" + accountOwner + ", parentAccount="
				+ parentAccount + ", accountNumber=" + accountNumber + ", accountSource=" + accountSource
				+ ", contactOwner=" + contactOwner + ", tickerSymbol=" + tickerSymbol + ", numberOfLocations="
				+ numberOfLocations + ", upsellOpportunity=" + upsellOpportunity + ", tradeStyle=" + tradeStyle
				+ ", site=" + site + "]";
	}


	@Override
	public String getDocumentRefId() {
		return getAccountDocumentRefId();
	}

	private final String PREFIX = "CRM - Account";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

	@Override
	public String csvColumnsValues() {
		String value = StringUtils.EMPTY;
		for (String fieldStr : sortedColumnNames()) {
			try {
				Field field = null;
				field = this.getClass().getDeclaredField(fieldStr);
				if (null != field) {
					field.setAccessible(true);
					if (field.getType().getName().equals(Address.class.getName()) && field.get(this) != null) {
						value = value + StringUtils.trim(((Address) field.get(this)).csvColumnsValues());
					} else {
						value = value + clean(String.valueOf(field.get(this)));
					}
					value = value + ",";
				}
			} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
				e.printStackTrace();
			}
		}
		return value;
	}


}
