
package com.miri.cis.entity;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.miri.cis.base.annotations.CSVColumnRank;


/**
 * Entity for ERP Account document in elasticsearch
 * @author rammoole
 *
 */
@Component
public class ErpAccount extends ESEntity {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 6166599934675183405L;

	private String accountDocumentRefId;
	
	private String accountId;

	@CSVColumnRank(5)
	private String salesOwner;

	private String salesOwnerId;

	@CSVColumnRank(7.5)
	private String sicCode;

	@CSVColumnRank(1)
	private String customerName;

	@CSVColumnRank(2)
	private String parentAccountId;

	@CSVColumnRank(2.5)
	private String parentAccountName;

	private String site;

	private String geo;

	@CSVColumnRank(4)
	private String industry;

	@CSVColumnRank(7)
	private BigDecimal annualRevenue;

	@CSVColumnRank(1.5)
	private String company;

	@CSVColumnRank(5.9)
	private String emailAddress;

	private String companyId;

	@CSVColumnRank(8)
	private String companyWebsite;

	@CSVColumnRank(5.7)
	private String phone;

	@CSVColumnRank(8.5)
	private int noOfEmployees;

	@JsonUnwrapped(prefix="billing")
	@CSVColumnRank(9)
	private Address billingAddress;

	@JsonUnwrapped(prefix="shipping")
	@CSVColumnRank(9.5)
	private Address shippingAddress;

	@CSVColumnRank(5.5)
	private String leadSource;

	@CSVColumnRank(10)
	private String createdBy;

	@CSVColumnRank(10.3)
	private String createdDate;

	@CSVColumnRank(11)
	private String lastModifiedBy;

	@CSVColumnRank(11.5)
	private String lastModifiedDate;

	public String getAccountDocumentRefId() {
		return accountDocumentRefId;
	}

	public void setAccountDocumentRefId(String accountDocumentRefId) {
		this.accountDocumentRefId = accountDocumentRefId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getSalesOwner() {
		return salesOwner;
	}

	public void setSalesOwner(String salesOwner) {
		this.salesOwner = salesOwner;
	}

	public String getSalesOwnerId() {
		return salesOwnerId;
	}

	public void setSalesOwnerId(String salesOwnerId) {
		this.salesOwnerId = salesOwnerId;
	}

	public String getSicCode() {
		return sicCode;
	}

	public void setSicCode(String sicCode) {
		this.sicCode = sicCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getParentAccountId() {
		return parentAccountId;
	}

	public void setParentAccountId(String parentAccountId) {
		this.parentAccountId = parentAccountId;
	}

	public String getParentAccountName() {
		return parentAccountName;
	}

	public void setParentAccountName(String parentAccountName) {
		this.parentAccountName = parentAccountName;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getGeo() {
		return geo;
	}

	public void setGeo(String geo) {
		this.geo = geo;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public BigDecimal getAnnualRevenue() {
		return annualRevenue;
	}

	public void setAnnualRevenue(BigDecimal annualRevenue) {
		this.annualRevenue = annualRevenue;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getNoOfEmployees() {
		return noOfEmployees;
	}

	public void setNoOfEmployees(int noOfEmployees) {
		this.noOfEmployees = noOfEmployees;
	}

	public Address getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}

	public Address getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(Address shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public String getLeadSource() {
		return leadSource;
	}

	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String getDocumentRefId() {
		return getAccountDocumentRefId();
	}

	private final String PREFIX = "ERP - Account";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}
	
	@Override
	public String csvColumnsValues() {
		String value = StringUtils.EMPTY;
		for (String fieldStr : sortedColumnNames()) {
			try {
				Field field = null;
				field = this.getClass().getDeclaredField(fieldStr);
				if (null != field) {
					field.setAccessible(true);
					if (field.getType().getName().equals(Address.class.getName()) && field.get(this) != null) {
						value = value + StringUtils.trim(((Address) field.get(this)).csvColumnsValues());
					} else {
						value = value + clean(String.valueOf(field.get(this)));
					}
					value = value + ",";
				}
			} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
}
