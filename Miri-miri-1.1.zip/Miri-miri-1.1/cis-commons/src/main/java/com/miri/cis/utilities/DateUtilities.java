package com.miri.cis.utilities;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class DateUtilities {
	private static Logger LOGGER = Logger.getLogger(DateUtilities.class);

    private static final String ELASTICSEARCH_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
	private static final String TIMEZONE_INDICATOR = "Z";

    /**
     * If input is String Date, convert to required format.
     *
     * @param date
     * @return
     */
    public static String stringToDate(String date) {
        return dateToString(stringToDateFormat(date));
    }

    /**
	 * Utility methods to convert given date as a string with given datePattern into Date Object.
	 *
	 * @param dateAsString date string to be converted into Date Object
	 * @param datePattern pattern of the given date string
	 * @return {@link java.util.Date} Object for the given date or null if date
	 * string can't be parsed according to the given pattern
	 */
    public static Date stringToDateByPattern(String dateAsString, String datePattern) {
        Date parsedDate;
        DateFormat finalDateFormat = new SimpleDateFormat(datePattern);
		try {
			parsedDate = finalDateFormat.parse(dateAsString);
		} catch (ParseException e) {
			LOGGER.warn("Invalid dateAsString: " + dateAsString, e);
			parsedDate = null;
		}

        return parsedDate;
    }

    /**
     * Converts given java.util.Date object to String format
     *
     * @param dateToConvert Date object to be converted to String
     * @return Date converted to String
     */
    public static String dateToString(Date dateToConvert) {
        if (dateToConvert != null) {
            DateFormat finalDateFormat = new SimpleDateFormat(ELASTICSEARCH_DATE_FORMAT);
            return finalDateFormat.format(dateToConvert) + TIMEZONE_INDICATOR;
        }
        return null;
    }

    public static String dateToString(Date dateToConvert, String pattern) {
        if (dateToConvert != null) {
            DateFormat finalDateFormat = new SimpleDateFormat(pattern);
            return finalDateFormat.format(dateToConvert);
        }
        return null;
    }

    /**
     * Converts given Elastic Search Date String in to java.util.Date object
     *
     * @param esDateString Elastic Search Date String
     * @return Date object for the given esDateString
     */
    public static Date esDateStringToDate(final String esDateString) {
    	Date parsedDate = null;
    	if (StringUtils.isNotBlank(esDateString)) {
        	String esDateStringTrimmed = esDateString;
        	int timeZoneLetterIndex = esDateString.indexOf(TIMEZONE_INDICATOR);
        	if (timeZoneLetterIndex != -1) {
        		esDateStringTrimmed = esDateString.substring(0, timeZoneLetterIndex);
			}
            DateFormat finalDateFormat = new SimpleDateFormat(ELASTICSEARCH_DATE_FORMAT);
            try {
				parsedDate = finalDateFormat.parse(esDateStringTrimmed);
			} catch (ParseException e) {
				LOGGER.warn("Invalid esDateString: " + esDateString, e);
				parsedDate = null;
			}
        }
        return parsedDate;
    }

    /**
     * converting the date from MM/dd/yyy to MM-dd-yyyy format
     *
     * @param date
     * @return
     */
    public static String replaceStringSlashwithHyphen(final String date) {
        if (StringUtils.isNotBlank(date)) {
            if (date.contains("/")) {
                return date.replace("/", "-");
            }
        }
        return date;
    }

    /**
     * Converting string to Date format
     *
     * @param date
     * @return
     */
    public static Date stringToDateFormat(String date) {
        String properDate = replaceStringSlashwithHyphen(date);
        SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
        try {
            if (StringUtils.isNotBlank(properDate)) {
                return formatter.parse(properDate);
            }
        } catch (ParseException e) {
            LOGGER.error("Exception while parsing date");
        }
        return null;
    }

    /**
     * Adds specified years to the given date if it's not null. Negative yearsToAdd value can be used.
     *
     * @param dateToModify Date value to be updated
     * @param yearsToAdd number of years to add to the date
     * @return updated date value if dateToModify is not null
     */
	public static Date addYearsToDate(Date dateToModify, int yearsToAdd) {
		return addMonthsToDate(dateToModify, yearsToAdd * 12);
	}

    /**
     * Adds specified months to the given date if it's not null. Negative monthsToAdd value can be used.
     *
     * @param dateToModify Date value to be updated
     * @param monthsToAdd number of months to add to the date
     * @return updated date value if dateToModify is not null
     */
	public static Date addMonthsToDate(Date dateToModify, int monthsToAdd) {
		Date changedDate = null;
		if (dateToModify != null) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateToModify);
			cal.add(Calendar.MONTH, monthsToAdd);
			changedDate = cal.getTime();
		}
		return changedDate;
	}


    /**
     * Get difference wrt to the given <code>timeOfTheDay</code> string
     * conforming to the given <code>datePattern</code>.
     *
     * @param timeOfTheDay time to be parsed
     * @param timePattern pattern to be used for parsing the time string
     * @return difference in millis between current time and
     */
	public static long getMillisForTimeFromNow(String timeOfTheDay, String timePattern) {
		Date dateWithTime = DateUtilities.stringToDateByPattern(timeOfTheDay, timePattern);
		Calendar calWithTime = Calendar.getInstance();
		calWithTime.setTime(dateWithTime);

		Calendar cal = Calendar.getInstance();
		cal.setTimeZone(calWithTime.getTimeZone());
		Date timeZoneDate = cal.getTime();

		cal.add(Calendar.DATE, 1);
		cal.set(Calendar.HOUR_OF_DAY, calWithTime.get(Calendar.HOUR_OF_DAY));
		cal.set(Calendar.MINUTE, calWithTime.get(Calendar.MINUTE));
		cal.set(Calendar.SECOND, calWithTime.get(Calendar.SECOND));
		Date timeZoneDateWithTime = cal.getTime();

		return timeZoneDateWithTime.getTime() - timeZoneDate.getTime();
	}
}
