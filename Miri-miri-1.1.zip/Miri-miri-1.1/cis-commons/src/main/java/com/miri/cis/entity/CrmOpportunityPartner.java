
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for CRM Opportunity Partner document in elasticsearch
 * 
 * @author rammoole
 *
 */
@Component
public class CrmOpportunityPartner extends ESEntity {

	private static final long serialVersionUID = 824881941107551460L;

	private String partnerDocumentRefId;

	@CSVColumnRank(2)
	private String partnerId;

	@CSVColumnRank(3)
	private String partnerRole;

	@CSVColumnRank(4)
	private String accountFromId;

	@CSVColumnRank(5)
	private String accountToId;

	@CSVColumnRank(11)
	private String opportunityId;

	@CSVColumnRank(6)
	private String createdBy;

	@CSVColumnRank(7)
	private String lastModifiedBy;

	@CSVColumnRank(6.5)
	private String createdDate;

	@CSVColumnRank(7.5)
	private String lastModifiedDate;

	public String getPartnerDocumentRefId() {
		return partnerDocumentRefId;
	}

	public void setPartnerDocumentRefId(String partnerDocumentRefId) {
		this.partnerDocumentRefId = partnerDocumentRefId;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getPartnerRole() {
		return partnerRole;
	}

	public void setPartnerRole(String partnerRole) {
		this.partnerRole = partnerRole;
	}

	public String getAccountFromId() {
		return accountFromId;
	}

	public void setAccountFromId(String accountFromId) {
		this.accountFromId = accountFromId;
	}

	public String getAccountToId() {
		return accountToId;
	}

	public void setAccountToId(String accountToId) {
		this.accountToId = accountToId;
	}

	public String getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String getDocumentRefId() {
		return getPartnerDocumentRefId();
	}

	private final String PREFIX = "CRM - Opportunity Partner";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

}
