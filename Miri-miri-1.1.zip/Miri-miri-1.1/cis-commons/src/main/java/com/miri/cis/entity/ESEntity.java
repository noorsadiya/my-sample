package com.miri.cis.entity;

import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.apache.commons.lang.CharSetUtils;
import org.apache.commons.lang.StringUtils;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * @author Chandra
 *
 */
public abstract class ESEntity implements Serializable {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -3182450515017707273L;

	public abstract String getDocumentRefId();

	private String vendorType;

	private String vendorName;

	private String instanceName;

	private List<String> tags = new ArrayList<String>();

	public List<String> getTags() {
		return tags;
	}

	public void setTags(List<String> tags) {
		this.tags = tags;
	}

	public String getVendorType() {
		return vendorType;
	}

	public void setVendorType(String vendorType) {
		this.vendorType = vendorType;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	public abstract List<String> sortedColumnNames();
	
	public abstract String csvColumnsHeaders();

	public String csvColumnsValues() {
		String value = StringUtils.EMPTY;
		for (String fieldStr : sortedColumnNames()) {
			try {
				Field field = null;
				field = this.getClass().getDeclaredField(fieldStr);
				if (null != field) {
					field.setAccessible(true);
					value = value + clean(String.valueOf(field.get(this)));
					value = value + ",";
				}
			} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
				e.printStackTrace();
			}
		}
		return value;
	}

	public List<String> generateColumnNamesByRank(Class<? extends ESEntity> clazz) {
		Field[] fields = clazz.getDeclaredFields();
		TreeMap<Double, String> sortedFieldNames = new TreeMap<>();
		for (Field field : fields) {
			Annotation annotation = field.getAnnotation(CSVColumnRank.class);
			if (annotation != null && annotation instanceof CSVColumnRank) {
				sortedFieldNames.put(((CSVColumnRank) annotation).value(), field.getName());
			}
		}
		return new ArrayList<>(sortedFieldNames.values());
	}

	public String displayCSVColumnNames(List<String> valuesList, final String prefix) {
		String csvColumnNames = StringUtils.EMPTY;
		for (int i = 0; i < valuesList.size(); i++) {
			csvColumnNames = csvColumnNames + (prefix + " ") + (StringUtils.isNotBlank(valuesList.get(i))
					? camelCaseToNormalString(valuesList.get(i)) : StringUtils.EMPTY) + ",";
			/*
			 * if (i < valuesList.size()) { csvColumnNames = csvColumnNames +
			 * ","; }
			 */
		}
		return csvColumnNames;
	}

	private String camelCaseToNormalString(String name) {
		String incomingName = name;
		if (StringUtils.isBlank(name))
			return StringUtils.EMPTY;

		name = name.replaceAll(String.format("%s|%s|%s", "(?<=[A-Z])(?=[A-Z][a-z])", "(?<=[^A-Z])(?=[A-Z])",
				"(?<=[A-Za-z])(?=[^A-Za-z])"), " ");

		if (StringUtils.equals(incomingName, name))
			name = StringUtils.upperCase(incomingName.substring(0, 1)) + incomingName.substring(1);

		return name;
	}

	public String clean(String str) {
		if (StringUtils.isBlank(str) || StringUtils.equalsIgnoreCase("null", str) || StringUtils.equalsIgnoreCase("0", str))
			return StringUtils.EMPTY;

		return CharSetUtils.delete(str, " \t\r\n\b");
	}
}
