
package com.miri.cis.entity;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;;

/**
 * Entity for CRM campaign document in elasticsearch
 * 
 * @author rammoole
 *
 */
@Component
public class CrmCampaign extends ESEntity {

	private static final long serialVersionUID = -4147136687930861703L;

	private String campaignDocumentRefId;

	@CSVColumnRank(0.5)
	private String campaignId;

	@CSVColumnRank(1)
	private String campaignName;
	@CSVColumnRank(1.001)
	private String parentCampaignId;

	@CSVColumnRank(2)
	private String startDate;

	@CSVColumnRank(3)
	private double actualCost;

	@CSVColumnRank(4)
	private String campaignType;

	@CSVColumnRank(6)
	private String createdDate;

	@CSVColumnRank(7)
	private String createdBy;

	@CSVColumnRank(8)
	private String status;

	@CSVColumnRank(1.1)
	private double budgetedCost;

	@CSVColumnRank(5)
	private String campaignOwner;

	private int numTotalOpportunities;

	private int numWonOpportunities;

	private int totalContacts;

	private double totalValueWonOpportunities;

	@CSVColumnRank(9)
	private String runtime;

	@CSVColumnRank(10)
	private String endDate;

	@CSVColumnRank(11)
	private BigDecimal expectedRevenue;

	@CSVColumnRank(12)
	private String lastModifiedDate;

	@CSVColumnRank(5)
	private int numOfLeads;

	@CSVColumnRank(13)
	private double totalValueOpportunities;

	@CSVColumnRank(14)
	private String description;

	@CSVColumnRank(12.1)
	private String lastModifiedBy;

	@CSVColumnRank(1.01)
	private String parentCampaignName;

	public String getCampaignDocumentRefId() {
		return campaignDocumentRefId;
	}

	public void setCampaignDocumentRefId(String campaignDocumentRefId) {
		this.campaignDocumentRefId = campaignDocumentRefId;
	}

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public String getParentCampaignId() {
		return parentCampaignId;
	}

	public void setParentCampaignId(String parentCampaignId) {
		this.parentCampaignId = parentCampaignId;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public double getActualCost() {
		return actualCost;
	}

	public void setActualCost(double actualCost) {
		this.actualCost = actualCost;
	}

	public String getCampaignType() {
		return campaignType;
	}

	public void setCampaignType(String campaignType) {
		this.campaignType = campaignType;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public double getBudgetedCost() {
		return budgetedCost;
	}

	public void setBudgetedCost(double budgetedCost) {
		this.budgetedCost = budgetedCost;
	}

	public String getCampaignOwner() {
		return campaignOwner;
	}

	public void setCampaignOwner(String campaignOwner) {
		this.campaignOwner = campaignOwner;
	}

	public int getNumTotalOpportunities() {
		return numTotalOpportunities;
	}

	public void setNumTotalOpportunities(int numTotalOpportunities) {
		this.numTotalOpportunities = numTotalOpportunities;
	}

	public int getNumWonOpportunities() {
		return numWonOpportunities;
	}

	public void setNumWonOpportunities(int numWonOpportunities) {
		this.numWonOpportunities = numWonOpportunities;
	}

	public int getTotalContacts() {
		return totalContacts;
	}

	public void setTotalContacts(int totalContacts) {
		this.totalContacts = totalContacts;
	}

	public double getTotalValueWonOpportunities() {
		return totalValueWonOpportunities;
	}

	public void setTotalValueWonOpportunities(double totalValueWonOpportunities) {
		this.totalValueWonOpportunities = totalValueWonOpportunities;
	}

	public String getRuntime() {
		return runtime;
	}

	public void setRuntime(String runtime) {
		this.runtime = runtime;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public BigDecimal getExpectedRevenue() {
		return expectedRevenue;
	}

	public void setExpectedRevenue(BigDecimal expectedRevenue) {
		this.expectedRevenue = expectedRevenue;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public int getNumOfLeads() {
		return numOfLeads;
	}

	public void setNumOfLeads(int numOfLeads) {
		this.numOfLeads = numOfLeads;
	}

	public double getTotalValueOpportunities() {
		return totalValueOpportunities;
	}

	public void setTotalValueOpportunities(double totalValueOpportunities) {
		this.totalValueOpportunities = totalValueOpportunities;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getParentCampaignName() {
		return parentCampaignName;
	}

	public void setParentCampaignName(String parentCampaignName) {
		this.parentCampaignName = parentCampaignName;
	}

	@Override
	public String toString() {
		return "CrmCampaign [campaignDocumentRefId=" + campaignDocumentRefId + ", campaignName=" + campaignName
				+ ", campaignId=" + campaignId + ", parentCampaignId=" + parentCampaignId + ", campaignOwner="
				+ campaignOwner + ", type=" + campaignType + ", numTotalOpportunities=" + numTotalOpportunities
				+ ", numWonOpportunities=" + numWonOpportunities + ", numOfLeads=" + numOfLeads + ", totalContacts="
				+ totalContacts + ", totalValueOpportunities=" + totalValueOpportunities
				+ ", totalValueWonOpportunities=" + totalValueWonOpportunities + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", runtime=" + runtime + ", expectedRevenue=" + expectedRevenue
				+ ", actualCost=" + actualCost + ", budgetedCost=" + budgetedCost + ", status=" + status
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", lastModifiedBy=" + lastModifiedBy
				+ ", lastModifiedDate=" + lastModifiedDate + "]";
	}

	@Override
	public String getDocumentRefId() {
		return getCampaignDocumentRefId();
	}

	private final String PREFIX = "CRM - Campaign";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

	@Override
	public String csvColumnsValues() {
		String value = StringUtils.EMPTY;
		for (String fieldStr : sortedColumnNames()) {
			try {
				Field field = null;
				field = this.getClass().getDeclaredField(fieldStr);
				if (null != field) {
					field.setAccessible(true);
					if (field.getType().getName().equals(Address.class.getName()) && field.get(this) != null) {
						value = value + StringUtils.trim(((Address) field.get(this)).csvColumnsValues());
					} else {
						value = value + clean(String.valueOf(field.get(this)));
					}
					value = value + ",";
				}
			} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
				e.printStackTrace();
			}
		}
		return value;
	}

}
