
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for MAP sales Person document in Elasticsearch
 * 
 * @author rammoole
 *
 */
@Component
public class MapSalesPerson extends ESEntity {

	private static final long serialVersionUID = 3905977489802880200L;

	private String userDocumentRefId;

	private String userId;

	@CSVColumnRank(3)
	private String firstName;

	@CSVColumnRank(2)
	private String lastName;

	@CSVColumnRank(1)
	private String userName;

	@CSVColumnRank(4)
	private String email;

	@CSVColumnRank(6.7)
	private String createdDate;

	@CSVColumnRank(6.9)
	private String lastModifiedDate;

	@CSVColumnRank(6.6)
	private String createdBy;

	@CSVColumnRank(6)
	private String mobilePhone;

	@CSVColumnRank(5)
	private String title;

	@CSVColumnRank(7)
	private String active;

	@CSVColumnRank(6.8)
	private String lastModifiedBy;

	@CSVColumnRank(6.5)
	private String company;

	public String getUserDocumentRefId() {
		return userDocumentRefId;
	}

	public void setUserDocumentRefId(String userDocumentRefId) {
		this.userDocumentRefId = userDocumentRefId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	@Override
	public String getDocumentRefId() {
		return getUserDocumentRefId();
	}

	private final String PREFIX = "MAP - Sales Person";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}


}
