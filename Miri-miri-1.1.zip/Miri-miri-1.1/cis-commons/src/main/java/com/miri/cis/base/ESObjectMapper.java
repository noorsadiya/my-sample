/**
 *
 */
package com.miri.cis.base;

import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.miri.cis.entity.CrmAccount;
import com.miri.cis.entity.CrmCampaign;
import com.miri.cis.entity.CrmContact;
import com.miri.cis.entity.CrmInvoice;
import com.miri.cis.entity.CrmLead;
import com.miri.cis.entity.CrmOpportunity;
import com.miri.cis.entity.CrmOpportunityCompetitor;
import com.miri.cis.entity.CrmOpportunityPartner;
import com.miri.cis.entity.CrmOpportunityProduct;
import com.miri.cis.entity.CrmOrderDetails;
import com.miri.cis.entity.CrmOrderProduct;
import com.miri.cis.entity.CrmProduct;
import com.miri.cis.entity.CrmUser;
import com.miri.cis.entity.ESEntity;
import com.miri.cis.entity.ErpAccount;
import com.miri.cis.entity.ErpInvoice;
import com.miri.cis.entity.ErpInvoiceItem;
import com.miri.cis.entity.ErpOpportunity;
import com.miri.cis.entity.ErpOpportunityCompetitor;
import com.miri.cis.entity.ErpSalesOrder;
import com.miri.cis.entity.ManualBusinessStrategy;
import com.miri.cis.entity.ManualCampaignStrategy;
import com.miri.cis.entity.MapAccount;
import com.miri.cis.entity.MapAsset;
import com.miri.cis.entity.MapCampaign;
import com.miri.cis.entity.MapLead;
import com.miri.cis.entity.MapOpportunity;
import com.miri.cis.entity.MapSalesPerson;

/**
 * ESObjectMapper: Maps Search response MAP to corresponding ES entities.
 *
 * @author Chandra
 *
 */

public final class ESObjectMapper {
	
    private static ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Returns ESEntity object for the given JSON document map.
     * 
     * @param map
     * @param type
     * @param index
     * @return
     */
    public static ESEntity getObject(final Map<String, Object> map, final String type, final String index) {

        ESEntity esEntity = null;
        final ElasticSearchEnums elasticSearchEnums = ElasticSearchEnums.getChartMapper().get(type);
        final VendorTypeEnum vendorTypeEnum = VendorTypeEnum.getVendorTypeMapper().get(index);

        if (vendorTypeEnum == null || elasticSearchEnums == null) return null;

        switch (vendorTypeEnum) {
        case MAP:

            esEntity = mapObjectMapper(map, esEntity, elasticSearchEnums);
            break;
        case CRM:
            esEntity = crmObjectMapper(map, esEntity, elasticSearchEnums);
            break;
        case ERP:
            esEntity = erpObjectMapper(map, esEntity, elasticSearchEnums);
            break;

        case MANUAL:
            esEntity = manualObjectMapper(map, esEntity, elasticSearchEnums);
            break;

        default:
            break;
        }

        return esEntity;

    }

    /**
     * Maps incoming JSON doc to corresponding java pojo.
     * 
     * @param map
     * @param esEntity
     * @param elasticSearchEnums
     * @return
     */
    private static ESEntity manualObjectMapper(Map<String, Object> map, ESEntity esEntity,
            ElasticSearchEnums elasticSearchEnums) {
        switch (elasticSearchEnums) {
        case BUSINESS_STRATEGY:
        	 esEntity = objectMapper.convertValue(map, ManualBusinessStrategy.class);
            break;
        case CAMPAIGN_STRATEGY:
        	 esEntity = objectMapper.convertValue(map, ManualCampaignStrategy.class);
            break;
        default:
            break;
        }
        return esEntity;
    }

    /**
     * Maps given search response to corresponding MAP entity.
     *
     * @param map
     * @param esEntity
     * @param elasticSearchEnums
     * @return
     */
    private static ESEntity mapObjectMapper(final Map<String, Object> map, ESEntity esEntity,
            final ElasticSearchEnums elasticSearchEnums) {
        switch (elasticSearchEnums) {
        case MAP_CAMPAIGN:
            esEntity = objectMapper.convertValue(map, MapCampaign.class);
            break;

        case MAP_LEAD:
            esEntity = objectMapper.convertValue(map, MapLead.class);
            break;

        case MAP_ASSET:
            esEntity = objectMapper.convertValue(map, MapAsset.class);
            break;

        case MAP_OPPORTUNITY:
            esEntity = objectMapper.convertValue(map, MapOpportunity.class);
            break;
        case MAP_SALESPERSON:
            esEntity = objectMapper.convertValue(map, MapSalesPerson.class);

            break;
        case MAP_ACCOUNT:
            esEntity = objectMapper.convertValue(map, MapAccount.class);
            break;

        default:
            break;
        }
        return esEntity;
    }

    /**
     * Maps given search response to corresponding CRM entity.
     *
     * @param map
     * @param esEntity
     * @param elasticSearchEnums
     * @return
     */
    private static ESEntity crmObjectMapper(final Map<String, Object> map, ESEntity esEntity,
            final ElasticSearchEnums elasticSearchEnums) {
        switch (elasticSearchEnums) {
        case CRM_ACCOUNT:
            esEntity = objectMapper.convertValue(map, CrmAccount.class);
            break;

        case CRM_CAMPAIGN:
            esEntity = objectMapper.convertValue(map, CrmCampaign.class);
            break;

        case CRM_CONTACT:
            esEntity = objectMapper.convertValue(map, CrmContact.class);
            break;

        case CRM_INVOICE:
            esEntity = objectMapper.convertValue(map, CrmInvoice.class);
            break;
        case CRM_LEAD:
            esEntity = objectMapper.convertValue(map, CrmLead.class);

            break;
        case CRM_OPPORTUNITY_COMPETITOR:
            esEntity = objectMapper.convertValue(map, CrmOpportunityCompetitor.class);
            break;

        case CRM_OPP_PRODUCT:
            esEntity = objectMapper.convertValue(map, CrmOpportunityProduct.class);
            break;

        case CRM_OPPORTUNITY:
            esEntity = objectMapper.convertValue(map, CrmOpportunity.class);
            break;

        case CRM_ORDER:
            esEntity = objectMapper.convertValue(map, CrmOrderDetails.class);
            break;

        case CRM_ORDER_PRODUCT:
            esEntity = objectMapper.convertValue(map, CrmOrderProduct.class);
            break;
        case CRM_PARTNER:
            esEntity = objectMapper.convertValue(map, CrmOpportunityPartner.class);

            break;
        case CRM_PRODUCT:
            esEntity = objectMapper.convertValue(map, CrmProduct.class);
            break;

        case CRM_USER:
            esEntity = objectMapper.convertValue(map, CrmUser.class);
            break;

        default:
            break;
        }
        return esEntity;
    }

    /**
     * Maps given search response to corresponding ERP entity.
     *
     * @param map
     * @param esEntity
     * @param elasticSearchEnums
     * @return
     */
    private static ESEntity erpObjectMapper(final Map<String, Object> map, ESEntity esEntity,
            final ElasticSearchEnums elasticSearchEnums) {
        switch (elasticSearchEnums) {
        case ERP_ACCOUNT:
            esEntity = objectMapper.convertValue(map, ErpAccount.class);
            break;

        case ERP_OPPORTUNITY_COMPETITOR:
            esEntity = objectMapper.convertValue(map, ErpOpportunityCompetitor.class);
            break;

        case ERP_INVOICE:
            esEntity = objectMapper.convertValue(map, ErpInvoice.class);
            break;
            
        case ERP_INVOICE_ITEM:
            esEntity = objectMapper.convertValue(map, ErpInvoiceItem.class);
            break;
            
        case ERP_OPPORTUNITY:
            esEntity = objectMapper.convertValue(map, ErpOpportunity.class);
            break;
        case ERP_SALESORDER:
            esEntity = objectMapper.convertValue(map, ErpSalesOrder.class);
            break;

        default:
            break;
        }
        return esEntity;
    }

}
