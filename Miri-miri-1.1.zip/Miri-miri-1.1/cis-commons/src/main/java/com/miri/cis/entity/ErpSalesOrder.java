package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for ERP Sales Order document in elasticsearch
 * @author rammoole
 *
 */
@Component
public class ErpSalesOrder extends ESEntity {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -7745580045531101603L;

	private String salesOrderDocumentRefId;

	@CSVColumnRank(5)
	private String orderId;

	@CSVColumnRank(5)
	private String orderOwner;

	@CSVColumnRank(5)
	private String accountName;

	@CSVColumnRank(5)
	private String opportunityId;

	@CSVColumnRank(5)
	private String activatedDate;

	@CSVColumnRank(5)
	private String orderInvoiceId;
	
	@CSVColumnRank(5)
	private String customerPo;

	@CSVColumnRank(5)
	private Double salesAmount;

	private String customerId;

	private String salesOrdeAccountYTD;

	@CSVColumnRank(5)
	private String leadSource;

	@CSVColumnRank(5)
	private String partner;

	@CSVColumnRank(5)
	private String status;

	@CSVColumnRank(5)
	private String createdBy;

	@CSVColumnRank(5)
	private String createdDate;

	@CSVColumnRank(5)
	private String lastModifiedBy;

	@CSVColumnRank(5)
	private String activatedBy;

	@CSVColumnRank(5)
	private String lastModifiedDate;

	private List<String> salesAccountCurrentOrders = new ArrayList<String>();

	private List<String> items = new ArrayList<String>();


	public String getSalesOrderDocumentRefId() {
		return salesOrderDocumentRefId;
	}

	public void setSalesOrderDocumentRefId(String salesOrderDocumentRefId) {
		this.salesOrderDocumentRefId = salesOrderDocumentRefId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getOrderOwner() {
		return orderOwner;
	}

	public void setOrderOwner(String orderOwner) {
		this.orderOwner = orderOwner;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getActivatedDate() {
		return activatedDate;
	}

	public void setActivatedDate(String activatedDate) {
		this.activatedDate = activatedDate;
	}

	public String getOrderInvoiceId() {
		return orderInvoiceId;
	}

	public void setOrderInvoiceId(String orderInvoiceId) {
		this.orderInvoiceId = orderInvoiceId;
	}

	public String getCustomerPo() {
		return customerPo;
	}

	public void setCustomerPo(String customerPo) {
		this.customerPo = customerPo;
	}

	public List<String> getItems() {
		return items;
	}

	public void setItems(List<String> items) {
		this.items = items;
	}

	public Double getSalesAmount() {
		return salesAmount;
	}

	public void setSalesAmount(Double salesAmount) {
		this.salesAmount = salesAmount;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public List<String> getSalesAccountCurrentOrders() {
		return salesAccountCurrentOrders;
	}

	public void setSalesAccountCurrentOrders(List<String> salesAccountCurrentOrders) {
		this.salesAccountCurrentOrders = salesAccountCurrentOrders;
	}

	public String getSalesOrdeAccountYTD() {
		return salesOrdeAccountYTD;
	}

	public void setSalesOrdeAccountYTD(String salesOrdeAccountYTD) {
		this.salesOrdeAccountYTD = salesOrdeAccountYTD;
	}

	public String getLeadSource() {
		return leadSource;
	}

	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}

	public String getPartner() {
		return partner;
	}

	public void setPartner(String partner) {
		this.partner = partner;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getActivatedBy() {
		return activatedBy;
	}

	public void setActivatedBy(String activatedBy) {
		this.activatedBy = activatedBy;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String getDocumentRefId() {
		return getSalesOrderDocumentRefId();
	}

	private final String PREFIX = "ERP - Sales Order";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}
}
