/**
 *
 */
package com.miri.cis.base;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * @author Chandra
 *
 */
public enum ElasticSearchEnums {

	// Indices
    MAP("map"), CRM("crm"), ERP("erp"),JOB_HISTORY("job_history"),JOB("job"), MANUAL("manual"),

    // Map Documents
    MAP_LEAD("map_lead"),MAP_ASSET("map_asset"),MAP_SALESPERSON("map_sales_person"),MAP_ACCOUNT("map_account"),
    MAP_CAMPAIGN("map_campaign"), MAP_OPPORTUNITY("map_opportunity"),

    // ERP Documents
    ERP_ACCOUNT("erp_account"),ERP_OPPORTUNITY("erp_opportunity"),ERP_INVOICE("erp_invoice"),ERP_SALESORDER("erp_sales_order"),
    ERP_OPPORTUNITY_COMPETITOR("erp_opportunity_competitor"),ERP_ORDER_ITEM("erp_order_item"),ERP_PRODUCT("erp_product"),
    ERP_INVOICE_ITEM("erp_invoice_item"),

    // CRM Documents
    CRM_CAMPAIGN("crm_campaign"),CRM_OPPORTUNITY("crm_opportunity"),CRM_ACCOUNT("crm_account"),CRM_CONTACT("crm_contact"),
    CRM_INVOICE("crm_invoice"),CRM_LEAD("crm_lead"),CRM_OPPORTUNITY_COMPETITOR("crm_opportunity_competitor"),CRM_OPP_PRODUCT("crm_opportunity_product"),
    CRM_OPP_PARTNER("crm_opportunity_partner"),CRM_ORDER("crm_order"),CRM_ORDER_PRODUCT("crm_order_product"),CRM_PARTNER("crm_partner"),
    CRM_PRODUCT("crm_product"),CRM_USER("crm_user"),CRM_CONTRACT("crm_contract"),CRM_ASSET("crm_asset"),
    CRM_CAMPAIGN_OPPORTUNITY_MAPPED("crm_Opportunity_campaign_mapped"),OPPORTUNITY_INVOICE_MAPPED("opportunity_invoice_mapped"),
    ERP_INVOCE_INVOICE_ITEM_MAPPED("erp_invoice_invoice_item_mapped"),
    // Manual Documents
    BUSINESS_STRATEGY("business_strategy"), CAMPAIGN_STRATEGY("campaign_strategy"), ACCOUNT_STRATEGY("account_strategy"), IMPACT_INDICATORS("impact_indicators"),

	//vendor details

	VENDORTYPE("vendorType"),VENDORNAME("vendorName"),INSTANCENAME("instanceName"), PHALADATA("phaladata"), COUNTRY("country"), CODE("code");

    private String text;

    private static final Logger LOGGER = Logger.getLogger(ElasticSearchEnums.class);
    private static Map<String, ElasticSearchEnums> esEnumMapper = new HashMap<>();

    static {
        for (final ElasticSearchEnums esEnum : ElasticSearchEnums.values()) {
            esEnumMapper.put(esEnum.getText(), esEnum);
        }
        esEnumMapper = Collections.unmodifiableMap(esEnumMapper);
    }

    public static Map<String, ElasticSearchEnums> getChartMapper() {
        return esEnumMapper;
    }

    private ElasticSearchEnums(final String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    /**
     * Returns String value corresponding to enum.
     *
     * @param text
     * @return
     */
    public static ElasticSearchEnums fromString(final String text) {
        if (text != null) {
            for (final ElasticSearchEnums esEnumType : ElasticSearchEnums.values()) {
                if (text.equalsIgnoreCase(esEnumType.getText())) {
                    return esEnumType;
                }
            }
        }
        LOGGER.info("returning null for doctype:"+text);
        return null;
    }

}
