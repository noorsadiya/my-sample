
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for CRM Opportunity Competitor document in elasticsearch
 * 
 * @author rammoole
 *
 */
@Component
public class CrmOpportunityCompetitor extends ESEntity {

	private static final long serialVersionUID = 1731685614489039891L;

	private String opportunityCompetitorDocumentRefId;

	private String createdBy;

	@CSVColumnRank(1)
	private String competitorName;

	@CSVColumnRank(0.1)
	private String opportunityId;

	@CSVColumnRank(4)
	private String strengths;

	@CSVColumnRank(5)
	private String weaknesses;

	private String lastModifiedBy;

	@CSVColumnRank(2)
	private String createdDate;

	@CSVColumnRank(6)
	private String lastModifiedDate;

	@CSVColumnRank(3)
	private String url;

	public String getOpportunityCompetitorDocumentRefId() {
		return opportunityCompetitorDocumentRefId;
	}

	public void setOpportunityCompetitorDocumentRefId(String opportunityCompetitorDocumentRefId) {
		this.opportunityCompetitorDocumentRefId = opportunityCompetitorDocumentRefId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCompetitorName() {
		return competitorName;
	}

	public void setCompetitorName(String competitorName) {
		this.competitorName = competitorName;
	}

	public String getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getStrengths() {
		return strengths;
	}

	public void setStrengths(String strengths) {
		this.strengths = strengths;
	}

	public String getWeaknesses() {
		return weaknesses;
	}

	public void setWeaknesses(String weaknesses) {
		this.weaknesses = weaknesses;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public String getDocumentRefId() {
		return getOpportunityCompetitorDocumentRefId();
	}

	private final String PREFIX = "CRM - Opportunity Competitor ";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

}
