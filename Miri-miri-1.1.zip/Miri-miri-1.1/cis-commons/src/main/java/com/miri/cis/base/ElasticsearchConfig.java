/**
 * 
 */
package com.miri.cis.base;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.transport.TransportAddress;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Elasticsearch configuration.
 * 
 * @author Chandra
 *
 */
@Component
public class ElasticsearchConfig {
    private static final Logger LOG = Logger.getLogger(ElasticsearchConfig.class);

    @Value("${spring.data.elasticsearch.cluster-name}")
    private String clusterName;

    @Value("${spring.data.elasticsearch.cluster-nodes}")
    private String clusterNode;

    private Client client = null;

    public String getClusterName() {
        return clusterName;
    }

    /**
     * Returns Host.
     * 
     * @return
     */
    public String getESHost() {
        try {
            String[] serverDetails = clusterNode.split(":");
            return serverDetails[0];
        } catch (Exception ex) {
            LOG.error("Exception while fetching ES Host");
        }
        return StringUtils.EMPTY;
    }

    /**
     * Returns ES port.
     * 
     * @return
     */
    public int getESPort() {
        try {
            String[] serverDetails = clusterNode.split(":");
            return Integer.parseInt(serverDetails[1]);
        } catch (Exception ex) {
            LOG.error("Exception while fetching ES Port");
        }
        return 0;
    }

    /**
     * Returns transport client with given cluster name.
     * 
     * @return
     */
    @SuppressWarnings("resource")
	public Client getTransportClient() {
        if (client == null) {
            Settings settings = ImmutableSettings.settingsBuilder().put("cluster.name", clusterName)
                    .put("client.transport.ignore_cluster_name", false).put("node.client", true)
                    .put("client.transport.sniff", true).build();
            String[] serverDetails = clusterNode.split(":");
            final String host = serverDetails[0];
            final int port = Integer.parseInt(serverDetails[1]);
            TransportAddress transportAddress = new InetSocketTransportAddress(host, port);
            client = new TransportClient(settings).addTransportAddress(transportAddress);
        }
        return client;

    }

    public String getClusterNode() {
        return clusterNode;
    }

    public void setClusterNode(String clusterNode) {
        this.clusterNode = clusterNode;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public void setClusterName(String clusterName) {
        this.clusterName = clusterName;
    }

}
