
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * POJO for CRM Order Product document in elasticsearch
 * 
 * @author rammoole
 *
 */
@Component
public class CrmOrderProduct extends ESEntity {

	private static final long serialVersionUID = -7611034762806764019L;

	private String orderProductDocumentRefId;

	@CSVColumnRank(7.9)
	private String createdBy;

	@CSVColumnRank(1)
	private String order;

	@CSVColumnRank(2)
	private String orderProductNumber;

	@CSVColumnRank(3)
	private String productId;

	@CSVColumnRank(4)
	private String productCode;

	@CSVColumnRank(5)
	private double totalPrice;

	@CSVColumnRank(9)
	private String lastModifiedBy;

	@CSVColumnRank(10)
	private String lastModifiedDate;

	@CSVColumnRank(6)
	private int quantity;

	@CSVColumnRank(7)
	private double unitPrice;

	@CSVColumnRank(8)
	private String createdDate;

	public String getOrderProductDocumentRefId() {
		return orderProductDocumentRefId;
	}

	public void setOrderProductDocumentRefId(String orderProductDocumentRefId) {
		this.orderProductDocumentRefId = orderProductDocumentRefId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public String getOrderProductNumber() {
		return orderProductNumber;
	}

	public void setOrderProductNumber(String orderProductNumber) {
		this.orderProductNumber = orderProductNumber;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String getDocumentRefId() {
		return getOrderProductDocumentRefId();
	}

	private final String PREFIX = "CRM - Account";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

}
