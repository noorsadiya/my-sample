package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for ERP Invoice document in elasticsearch
 * @author rammoole
 *
 */
@Component
public class ErpInvoice  extends ESEntity {

	private static final long serialVersionUID = 2222736527985065050L;

	private String invoiceDocumentRefId;

	@CSVColumnRank(5)
    private String invoiceId;

	@CSVColumnRank(5)
    private String invoiceName;

	@CSVColumnRank(5)
    private String opportunityId;

	@CSVColumnRank(5)
    private String saleOrderId;

	@CSVColumnRank(5)
    private String accountId;

	@CSVColumnRank(5)
    private String description;

	@CSVColumnRank(5)
    private String status;

    @CSVColumnRank(5)
    private String leadSource;

    @CSVColumnRank(5)
    private String salesPerson;

    @CSVColumnRank(5)
    private String accountName;

    @CSVColumnRank(5)
    private double salesAmount;

    @CSVColumnRank(5)
    private int productQuantity;

    @CSVColumnRank(5)
    private double productUnitPrice;

    @CSVColumnRank(5)
    private String salesCurrency;

    @CSVColumnRank(5)
    private String createdBy;

    @CSVColumnRank(5)
    private String createdDate;

    @CSVColumnRank(5)
    private String lastModifiedBy;

    @CSVColumnRank(5)
    private String lastModifiedDate;

    @CSVColumnRank(5)
    private List<String> invoiceItems;
    
    private double salesAmountUSD;
    
    private double salesAmountGBP;
    
    private double salesAmountEUR;

    public String getInvoiceDocumentRefId() {
		return invoiceDocumentRefId;
	}



	public void setInvoiceDocumentRefId(String invoiceDocumentRefId) {
		this.invoiceDocumentRefId = invoiceDocumentRefId;
	}



	public String getInvoiceId() {
		return invoiceId;
	}



	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}



	public String getInvoiceName() {
		return invoiceName;
	}



	public void setInvoiceName(String invoiceName) {
		this.invoiceName = invoiceName;
	}



	public String getOpportunityId() {
		return opportunityId;
	}



	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}



	public String getSaleOrderId() {
		return saleOrderId;
	}



	public void setSaleOrderId(String saleOrderId) {
		this.saleOrderId = saleOrderId;
	}



	/**
	 * @return the accountId
	 */
	public String getAccountId() {
		return accountId;
	}



	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getLeadSource() {
		return leadSource;
	}



	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}



	public String getSalesPerson() {
		return salesPerson;
	}



	public void setSalesPerson(String salesPerson) {
		this.salesPerson = salesPerson;
	}



	public String getAccountName() {
		return accountName;
	}



	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}



	public double getSalesAmount() {
		return salesAmount;
	}



	public void setSalesAmount(double salesAmount) {
		this.salesAmount = salesAmount;
	}



	public int getProductQuantity() {
		return productQuantity;
	}



	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}



	public double getProductUnitPrice() {
		return productUnitPrice;
	}



	public void setProductUnitPrice(double productUnitPrice) {
		this.productUnitPrice = productUnitPrice;
	}



	public String getSalesCurrency() {
		return salesCurrency;
	}



	public void setSalesCurrency(String salesCurrency) {
		this.salesCurrency = salesCurrency;
	}



	public String getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}



	public String getCreatedDate() {
		return createdDate;
	}



	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}



	public String getLastModifiedBy() {
		return lastModifiedBy;
	}



	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}



	public String getLastModifiedDate() {
		return lastModifiedDate;
	}



	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}


	@Override
	public String getDocumentRefId() {
		return getInvoiceDocumentRefId();
	}

	public void setInvoiceItems(List<String> invoiceItems) {
		this.invoiceItems = invoiceItems;
	}

	public List<String> getInvoiceItems() {
		return invoiceItems;
	}

	@Override
	public String toString() {
		return "ErpInvoice [invoiceId=" + invoiceId + ", invoiceName=" + invoiceName + ", opportunityId=" + opportunityId + ", saleOrderId=" + saleOrderId
				+ ", accountId=" + accountId + ", status=" + status + ", leadSource=" + leadSource + ", salesPerson=" + salesPerson + ", "
				+ "accountName=" + accountName + ", salesAmount=" + salesAmount + ", productQuantity=" + productQuantity + ", productUnitPrice=" + productUnitPrice
				+ ", salesCurrency=" + salesCurrency + ", createdBy=" + createdBy + ", createdDate=" + createdDate
				+ ", lastModifiedBy=" + lastModifiedBy + ", lastModifiedDate=" + lastModifiedDate + "]";
	}
	
	private final String PREFIX = "ERP - Invoice";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}



	/**
	 * @return the salesAmountUSD
	 */
	public double getSalesAmountUSD() {
		return salesAmountUSD;
	}



	/**
	 * @param salesAmountUSD the salesAmountUSD to set
	 */
	public void setSalesAmountUSD(double salesAmountUSD) {
		this.salesAmountUSD = salesAmountUSD;
	}



	/**
	 * @return the salesAmountGBP
	 */
	public double getSalesAmountGBP() {
		return salesAmountGBP;
	}



	/**
	 * @param salesAmountGBP the salesAmountGBP to set
	 */
	public void setSalesAmountGBP(double salesAmountGBP) {
		this.salesAmountGBP = salesAmountGBP;
	}



	/**
	 * @return the salesAmountEUR
	 */
	public double getSalesAmountEUR() {
		return salesAmountEUR;
	}



	/**
	 * @param salesAmountEUR the salesAmountEUR to set
	 */
	public void setSalesAmountEUR(double salesAmountEUR) {
		this.salesAmountEUR = salesAmountEUR;
	}

}
