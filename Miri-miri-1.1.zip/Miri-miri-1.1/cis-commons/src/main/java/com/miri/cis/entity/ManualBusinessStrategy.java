/**
 *
 */
package com.miri.cis.entity;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.miri.cis.base.annotations.CSVColumnRank;
import com.miri.cis.entity.ManualIndicatorTarget.IndicatorValue;

/**
 * @author chavanka
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class ManualBusinessStrategy extends ESEntity {
	private static final long serialVersionUID = -4197198751429563423L;

	private String businessStrategyDocumentRefId;
	@CSVColumnRank(1)
	private List<MonthlyTarget> businessRevenueTarget;
	@CSVColumnRank(2)
	private List<MonthlyTarget> monthlyBusinessRevenueTarget;
	@CSVColumnRank(3)
	private List<MonthlyTarget> quaterlyBusinessRevenuetarget;
	@CSVColumnRank(4)
	private List<MarketingInfluencedRevenueTarget> marketingInfluencedRevenueTarget;
	@CSVColumnRank(5)
	private List<MarketingInfluencedRevenueTarget> monthlymarketingInfluencedRevenueTarget;
	@CSVColumnRank(6)
	private List<MarketingInfluencedRevenueTarget> quaterlyMarketingInfluencedRevenueTarget;
	@CSVColumnRank(7)
	private Integer marketingBudgetSpend;
	private boolean draft;
	@CSVColumnRank(8)
	private String createdDate;
	@CSVColumnRank(9)
	private String lastModifiedDate;
	

	/**
	 *
	 * @return The businessStrategyDocumentRefId
	 */
	public String getBusinessStrategyDocumentRefId() {
		return businessStrategyDocumentRefId;
	}

	/**
	 *
	 * @param businessStrategyDocumentRefId
	 *            The businessStrategyDocumentRefId
	 */
	public void setBusinessStrategyDocumentRefId(String businessStrategyDocumentRefId) {
		this.businessStrategyDocumentRefId = businessStrategyDocumentRefId;
	}

	/**
	 *
	 * @return The businessRevenueTarget
	 */
	public List<MonthlyTarget> getBusinessRevenueTarget() {
		return businessRevenueTarget;
	}

	/**
	 *
	 * @param businessRevenueTarget
	 *            The businessRevenueTarget
	 */
	public void setBusinessRevenueTarget(List<MonthlyTarget> businessRevenueTarget) {
		this.businessRevenueTarget = businessRevenueTarget;
	}

	/**
	 * @return The monthlyBusinessRevenueTarget
	 */
	public List<MonthlyTarget> getMonthlyBusinessRevenueTarget() {
		return monthlyBusinessRevenueTarget;
	}

	/**
	 * @param monthlyBusinessRevenueTarget
	 *            The monthlyBusinessRevenueTarget to set
	 */
	public void setMonthlyBusinessRevenueTarget(List<MonthlyTarget> monthlyBusinessRevenueTarget) {
		this.monthlyBusinessRevenueTarget = monthlyBusinessRevenueTarget;
	}

	/**
	 *
	 * @return The marketingInfluencedRevenueTarget
	 */
	public List<MarketingInfluencedRevenueTarget> getMarketingInfluencedRevenueTarget() {
		return marketingInfluencedRevenueTarget;
	}

	/**
	 *
	 * @param marketingInfluencedRevenueTarget
	 *            The marketingInfluencedRevenueTarget
	 */
	public void setMarketingInfluencedRevenueTarget(
			List<MarketingInfluencedRevenueTarget> marketingInfluencedRevenueTarget) {
		this.marketingInfluencedRevenueTarget = marketingInfluencedRevenueTarget;
	}

	/**
	 * @return The monthlymarketingInfluencedRevenueTarget
	 */
	public List<MarketingInfluencedRevenueTarget> getMonthlymarketingInfluencedRevenueTarget() {
		return monthlymarketingInfluencedRevenueTarget;
	}

	/**
	 * @param monthlymarketingInfluencedRevenueTarget
	 *            The monthlymarketingInfluencedRevenueTarget to set
	 */
	public void setMonthlymarketingInfluencedRevenueTarget(
			List<MarketingInfluencedRevenueTarget> monthlymarketingInfluencedRevenueTarget) {
		this.monthlymarketingInfluencedRevenueTarget = monthlymarketingInfluencedRevenueTarget;
	}

	/**
	 *
	 * @return The marketingBudgetSpend
	 */
	public Integer getMarketingBudgetSpend() {
		return marketingBudgetSpend;
	}

	/**
	 *
	 * @param marketingBudgetSpend
	 *            The marketingBudgetSpend
	 */
	public void setMarketingBudgetSpend(Integer marketingBudgetSpend) {
		this.marketingBudgetSpend = marketingBudgetSpend;
	}

	/**
	 * @return the draft
	 */
	public boolean isDraft() {
		return draft;
	}

	/**
	 * @param draft
	 *            the draft to set
	 */
	public void setDraft(boolean draft) {
		this.draft = draft;
	}

	/**
	 *
	 * @return The createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 *
	 * @param createdDate
	 *            The createdDate
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 *
	 * @return The lastModifiedDate
	 */
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 *
	 * @param lastModifiedDate
	 *            The lastModifiedDate
	 */
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String getDocumentRefId() {
		return businessStrategyDocumentRefId;
	}

	/**
	 * @return the quaterlyBusinessRevenuetarget
	 */
	public List<MonthlyTarget> getQuaterlyBusinessRevenuetarget() {
		return quaterlyBusinessRevenuetarget;
	}

	/**
	 * @param quaterlyBusinessRevenuetarget
	 *            the quaterlyBusinessRevenuetarget to set
	 */
	public void setQuaterlyBusinessRevenuetarget(List<MonthlyTarget> quaterlyBusinessRevenuetarget) {
		this.quaterlyBusinessRevenuetarget = quaterlyBusinessRevenuetarget;
	}

	/**
	 * @return the quaterlyMarketingInfluencedRevenueTarget
	 */
	public List<MarketingInfluencedRevenueTarget> getQuaterlyMarketingInfluencedRevenueTarget() {
		return quaterlyMarketingInfluencedRevenueTarget;
	}

	/**
	 * @param quaterlyMarketingInfluencedRevenueTarget
	 *            the quaterlyMarketingInfluencedRevenueTarget to set
	 */
	public void setQuaterlyMarketingInfluencedRevenueTarget(
			List<MarketingInfluencedRevenueTarget> quaterlyMarketingInfluencedRevenueTarget) {
		this.quaterlyMarketingInfluencedRevenueTarget = quaterlyMarketingInfluencedRevenueTarget;
	}

	@SuppressWarnings("unchecked")
	public void update(Map<String, Object> source) {
		Set<Entry<String, Object>> entries = source.entrySet();
		for (Entry<String, Object> entry : entries) {
			String key = entry.getKey();
			switch (key) {
			case "marketingBudgetSpend":
				this.marketingBudgetSpend = (Integer) entry.getValue();
				break;

			case "businessRevenueTarget": {
				if (this.businessRevenueTarget == null) {
					this.businessRevenueTarget = new ArrayList<>();
				}
				List<?> targetValues = (List<MonthlyTarget>) entry.getValue();
				if (CollectionUtils.isNotEmpty(targetValues)) {
					for (Object targetValue : targetValues) {
						Map<String, Object> values = (Map<String, Object>) targetValue;
						this.businessRevenueTarget
								.add(new MonthlyTarget(getInteger((Number)values.get(IndicatorValue.FIELDNAME_ID)),
										(String) values.get(IndicatorValue.FIELDNAME_MONTH),
										(Number) values.get(IndicatorValue.FIELDNAME_VALUE)));
					}
				}
				break;
			}

			case "monthlyBusinessRevenueTarget": {
				if (this.monthlyBusinessRevenueTarget == null) {
					this.monthlyBusinessRevenueTarget = new ArrayList<>();
				}
				List<?> targetValues = (List<MonthlyTarget>) entry.getValue();
				if (CollectionUtils.isNotEmpty(targetValues)) {
					for (Object targetValue : targetValues) {
						Map<String, Object> values = (Map<String, Object>) targetValue;
						this.monthlyBusinessRevenueTarget
								.add(new MonthlyTarget(getInteger((Number)values.get(IndicatorValue.FIELDNAME_ID)),
										(String) values.get(IndicatorValue.FIELDNAME_MONTH),
										(Number) values.get(IndicatorValue.FIELDNAME_VALUE)));
					}
				}
				break;
			}

			case "quaterlyBusinessRevenuetarget": {
				if (this.quaterlyBusinessRevenuetarget == null) {
					this.quaterlyBusinessRevenuetarget = new ArrayList<>();
				}
				List<?> targetValues = (List<MonthlyTarget>) entry.getValue();
				if (CollectionUtils.isNotEmpty(targetValues)) {
					for (Object targetValue : targetValues) {
						Map<String, Object> values = (Map<String, Object>) targetValue;
						this.quaterlyBusinessRevenuetarget
								.add(new MonthlyTarget(getInteger((Number)values.get(IndicatorValue.FIELDNAME_ID)),
										(String) values.get(IndicatorValue.FIELDNAME_MONTH),
										(Number) values.get(IndicatorValue.FIELDNAME_VALUE)));
					}
				}
				break;
			}

			case "marketingInfluencedRevenueTarget": {
				if (this.marketingInfluencedRevenueTarget == null) {
					this.marketingInfluencedRevenueTarget = new ArrayList<>();
				}
				List<?> monthlyValues = (List<?>) entry.getValue();
				if (CollectionUtils.isNotEmpty(monthlyValues)) {
					for (Object monthlyValue : monthlyValues) {
						Map<String, Object> values = (Map<String, Object>) monthlyValue;
						this.marketingInfluencedRevenueTarget.add(
								new MarketingInfluencedRevenueTarget(getInteger((Number) values.get(IndicatorValue.FIELDNAME_ID)),
										(String) values.get(IndicatorValue.FIELDNAME_MONTH),
										(Number) values.get(IndicatorValue.FIELDNAME_VALUE)));
					}
				}
				break;
			}

			case "monthlymarketingInfluencedRevenueTarget": {
				if (this.monthlymarketingInfluencedRevenueTarget == null) {
					this.monthlymarketingInfluencedRevenueTarget = new ArrayList<>();
				}
				List<?> monthlyValues = (List<?>) entry.getValue();
				if (CollectionUtils.isNotEmpty(monthlyValues)) {
					for (Object monthlyValue : monthlyValues) {
						Map<String, Object> values = (Map<String, Object>) monthlyValue;
						this.monthlymarketingInfluencedRevenueTarget.add(
								new MarketingInfluencedRevenueTarget(getInteger((Number)values.get(IndicatorValue.FIELDNAME_ID)),
										(String) values.get(IndicatorValue.FIELDNAME_MONTH),
										(Number) values.get(IndicatorValue.FIELDNAME_VALUE)));
					}
				}
				break;
			}

			case "quaterlyMarketingInfluencedRevenueTarget": {
				if (this.quaterlyMarketingInfluencedRevenueTarget == null) {
					this.quaterlyMarketingInfluencedRevenueTarget = new ArrayList<>();
				}
				List<?> monthlyValues = (List<?>) entry.getValue();
				if (CollectionUtils.isNotEmpty(monthlyValues)) {
					for (Object monthlyValue : monthlyValues) {
						Map<String, Object> values = (Map<String, Object>) monthlyValue;
						this.quaterlyMarketingInfluencedRevenueTarget.add(
								new MarketingInfluencedRevenueTarget(getInteger((Number) values.get(IndicatorValue.FIELDNAME_ID)),
										(String) values.get(IndicatorValue.FIELDNAME_MONTH),
										(Number) values.get(IndicatorValue.FIELDNAME_VALUE)));
					}
				}
				break;
			}

			case "createdDate":
				this.createdDate = (String) entry.getValue();
				break;

			case "lastModifiedDate":
				this.lastModifiedDate = (String) entry.getValue();
				break;

			case "tags":
				Object tagsObject = entry.getValue();
				if (String.class.isInstance(tagsObject)) { // why is it string
															// when there are no
															// values?
					String tagsStr = (String) entry.getValue();
					List<String> tagsList = Collections.emptyList();
					if (StringUtils.isNotBlank(tagsStr)) {
						String[] split = tagsStr.split(",");// confirm if this
															// is correct?
						tagsList = Arrays.asList(split);
					}
					this.setTags(tagsList);

				} else {
					this.setTags((List<String>) tagsObject);
				}
				break;

			case "vendorName":
				this.setVendorName((String) entry.getValue());
				break;

			case "vendorType":
				this.setVendorType((String) entry.getValue());
				break;

			case "instanceName":
				this.setInstanceName((String) entry.getValue());
				break;

			case "businessStrategyDocumentRefId":
				this.businessStrategyDocumentRefId = (String) entry.getValue();
				break;

			default:
				break;
			}
		}
	}

	private final String PREFIX = "Business Strategy";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

	@SuppressWarnings("unchecked")
	@Override
	public String csvColumnsValues() {
		String value = StringUtils.EMPTY;
		for (String fieldStr : sortedColumnNames()) {
			try {
				Field field = null;
				field = this.getClass().getDeclaredField(fieldStr);
				if (null != field) {
					field.setAccessible(true);
					if (field.getName().equals("businessRevenueTarget")
							|| field.getName().equals("monthlyBusinessRevenueTarget")
							|| field.getName().equals("quaterlyBusinessRevenuetarget")) {
						value = value + StringUtils.trim(getMonthlyTargetData((List<MonthlyTarget>) field.get(this)));
					} else if (field.getName().equals("marketingInfluencedRevenueTarget")
							|| field.getName().equals("monthlymarketingInfluencedRevenueTarget")
							|| field.getName().equals("quaterlyMarketingInfluencedRevenueTarget")) {
						value = value + StringUtils
								.trim(getMIRevenueData((List<MarketingInfluencedRevenueTarget>) field.get(this)));
					} else
						value = value + clean(String.valueOf(field.get(this)));
				}
				value = value + ",";

			} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
				e.printStackTrace();
			}
		}

		return value;
	}

	private String getMIRevenueData(List<MarketingInfluencedRevenueTarget> list) {
		String result = StringUtils.EMPTY;
		if (null != list) {
			for (MarketingInfluencedRevenueTarget influencedRevenueTarget : list) {
				result = result + influencedRevenueTarget.csvColumnsValues() + " ";
			}
		}
		return result;
	}

	private String getMonthlyTargetData(List<MonthlyTarget> list) {
		String result = StringUtils.EMPTY;
		if (null != list) {
			for (MonthlyTarget monthlyTarget : list) {
				result = result + monthlyTarget.csvColumnsValues() + " ";
			}
		}
		return result;
	}
	
	
	private Integer getInteger(Number number) {
		  return number != null ? number.intValue() : null;
		 }

}
