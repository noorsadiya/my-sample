
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for CRM Contact document in elasticsearch
 * 
 * @author rammoole
 *
 */
@Component
public class CrmContact extends ESEntity {

	/**
	 * Generated serial version UID
	 */
	private static final long serialVersionUID = 6004645640985527187L;

	private String contactDocumentRefId;
	@CSVColumnRank(1)
	private String contactId;

	@CSVColumnRank(2)
	private String accountId;

	@CSVColumnRank(3)
	private String contactName;

	@CSVColumnRank(4)
	private String contactNumber;

	@CSVColumnRank(5)
	private String contactOwner;

	@CSVColumnRank(3.1)
	private String email;

	@CSVColumnRank(6)
	private String createdBy;

	@CSVColumnRank(7)
	private String lastModifiedBy;

	@CSVColumnRank(8)
	private String status;

	@CSVColumnRank(6.2)
	private String activatedDate;

	@CSVColumnRank(6.1)
	private String createdDate;
	@CSVColumnRank(7.1)
	private String lastModifiedDate;

	@CSVColumnRank(1.1)
	private String name; // Not there in json schema

	@CSVColumnRank(2.1)
	private String leadSource;

	public String getContactDocumentRefId() {
		return contactDocumentRefId;
	}

	public void setContactDocumentRefId(String contactDocumentRefId) {
		this.contactDocumentRefId = contactDocumentRefId;
	}

	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getContactOwner() {
		return contactOwner;
	}

	public void setContactOwner(String contactOwner) {
		this.contactOwner = contactOwner;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getActivatedDate() {
		return activatedDate;
	}

	public void setActivatedDate(String activatedDate) {
		this.activatedDate = activatedDate;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLeadSource() {
		return leadSource;
	}

	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}

	@Override
	public String getDocumentRefId() {
		// TODO Auto-generated method stub
		return null;
	}

	private final String PREFIX = "CRM - Contact";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

}
