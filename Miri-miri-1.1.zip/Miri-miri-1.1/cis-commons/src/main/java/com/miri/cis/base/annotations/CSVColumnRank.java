/**
 * 
 */
package com.miri.cis.base.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author Chandra
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface CSVColumnRank {

	public double rank() default 0;
	
	double value() default -1;

	public String name() default "";

}
