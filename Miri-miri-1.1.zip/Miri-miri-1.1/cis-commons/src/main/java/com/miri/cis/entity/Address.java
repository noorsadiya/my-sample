
package com.miri.cis.entity;

import java.io.Serializable;

import org.apache.commons.lang.CharSetUtils;
import org.apache.commons.lang.StringUtils;

public class Address implements Serializable {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -2541437082134968455L;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private String countryName;
	private String countryIso;
	private String postalCode;

	/**
	 * 
	 * @return The addressLine1
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 * 
	 * @param addressLine1
	 *            The addressLine1
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * 
	 * @return The addressLine2
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * 
	 * @param addressLine2
	 *            The addressLine2
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * 
	 * @return The city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * 
	 * @param city
	 *            The city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * 
	 * @return The state
	 */
	public String getState() {
		return state;
	}

	/**
	 * 
	 * @param state
	 *            The state
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * 
	 * @return The countryName
	 */
	public String getCountryName() {
		return countryName;
	}

	/**
	 * 
	 * @param countryName
	 *            The countryName
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	/**
	 * 
	 * @return The countryIso
	 */
	public String getCountryIso() {
		return countryIso;
	}

	/**
	 * 
	 * @param countryIso
	 *            The countryIso
	 */
	public void setCountryIso(String countryIso) {
		this.countryIso = countryIso;
	}

	/**
	 * 
	 * @return The postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * 
	 * @param postalCode
	 *            The postalCode
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String csvColumnsValues() {
		String address = StringUtils.EMPTY;

		address = address + clean(this.getAddressLine1()) + " " + clean(this.getAddressLine2()) + " "
				+ clean(this.getCity()) + " " + clean(this.getState()) + " " + clean(this.getCountryName());

		return address;
	}

	public String clean(String str) {
		if (StringUtils.isBlank(str) || StringUtils.equalsIgnoreCase("null", str)
				|| StringUtils.equalsIgnoreCase("0", str))
			return StringUtils.EMPTY;

		return CharSetUtils.delete(str, " \t\r\n\b");
	}
}
