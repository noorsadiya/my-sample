package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for CRM User document in elasticsearch
 * @author rammoole
 *
 */
@Component
public class CrmUser  extends ESEntity {

	private static final long serialVersionUID = 1L;

	private String userDocumentRefId;

	@CSVColumnRank(1)
    private String userId;

	@CSVColumnRank(3)
    private String firstname;

	@CSVColumnRank(4)
    private String lastname;

	@CSVColumnRank(5)
    private String email;

	@CSVColumnRank(9.2)
    private String lastModifiedDate;

    @CSVColumnRank(8)
    private String createdBy;

    @CSVColumnRank(6)
    private String mobilePhone;

    @CSVColumnRank(7)
    private String title;

    @CSVColumnRank(9)
    private String company;

    @CSVColumnRank(3.1)
    private String active;

    @CSVColumnRank(2)
    private String username;

    private String timezone;

    @CSVColumnRank(8)
    private String createdDate;

    @CSVColumnRank(9.1)
    private String lastModifiedBy;



	public String getUserDocumentRefId() {
		return userDocumentRefId;
	}



	public void setUserDocumentRefId(String userDocumentRefId) {
		this.userDocumentRefId = userDocumentRefId;
	}



	public String getUserId() {
		return userId;
	}



	public void setUserId(String userId) {
		this.userId = userId;
	}



	public String getFirstname() {
		return firstname;
	}



	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}



	public String getLastname() {
		return lastname;
	}



	public void setLastname(String lastname) {
		this.lastname = lastname;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getLastModifiedDate() {
		return lastModifiedDate;
	}



	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}



	public String getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}



	public String getMobilePhone() {
		return mobilePhone;
	}



	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}



	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public String getCompany() {
		return company;
	}



	public void setCompany(String company) {
		this.company = company;
	}



	public String getActive() {
		return active;
	}



	public void setActive(String active) {
		this.active = active;
	}



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public String getTimezone() {
		return timezone;
	}



	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}



	public String getCreatedDate() {
		return createdDate;
	}



	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}



	public String getLastModifiedBy() {
		return lastModifiedBy;
	}



	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}



	@Override
	public String getDocumentRefId() {
		return getUserDocumentRefId();
	}

	private final String PREFIX = "CRM - User";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

}
