
package com.miri.cis.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

/**
 * POJO for MAP Campaign document in Elasticsearch.
 *
 * @author rammoole
 *
 */
@Component
public class MapCampaign extends ESEntity {
	private static final long serialVersionUID = 745630769109007718L;

	private String campaignId;

	private String campaignName;

	private String parentCampaignId;

	private String parentCampaignName;

	private String campaignDocumentRefId;

	private String startDate;

	private double actualCost;

	private String campaignType;

	private List<String> products = new ArrayList<String>();

	private String createdDate;

	private String createdBy;

	private String currentStatus;

	private double budgetedCost;

	private String description;

	private String campaignOwner;

	private String runtime;

	private String endDate;

	private BigDecimal expectedRevenue;

	private List<String> leadSources = new ArrayList<>();

	private List<String> touchPoints = new ArrayList<>();

	private List<String> assets = new ArrayList<>();

	private String lastModifiedBy;

	private String lastModifiedDate;

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public String getParentCampaignId() {
		return parentCampaignId;
	}

	public void setParentCampaignId(String parentCampaignId) {
		this.parentCampaignId = parentCampaignId;
	}

	public String getParentCampaignName() {
		return parentCampaignName;
	}

	public void setParentCampaignName(String parentCampaignName) {
		this.parentCampaignName = parentCampaignName;
	}

	public String getCampaignDocumentRefId() {
		return campaignDocumentRefId;
	}

	public void setCampaignDocumentRefId(String campaignDocumentRefId) {
		this.campaignDocumentRefId = campaignDocumentRefId;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public double getActualCost() {
		return actualCost;
	}

	public void setActualCost(double actualCost) {
		this.actualCost = actualCost;
	}

	public String getCampaignType() {
		return campaignType;
	}

	public void setCampaignType(String campaignType) {
		this.campaignType = campaignType;
	}

	public List<String> getProducts() {
		return products;
	}

	public void setProducts(List<String> products) {
		this.products = products;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public double getBudgetedCost() {
		return budgetedCost;
	}

	public void setBudgetedCost(double budgetedCost) {
		this.budgetedCost = budgetedCost;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCampaignOwner() {
		return campaignOwner;
	}

	public void setCampaignOwner(String campaignOwner) {
		this.campaignOwner = campaignOwner;
	}

	public String getRuntime() {
		return runtime;
	}

	public void setRuntime(String runtime) {
		this.runtime = runtime;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public BigDecimal getExpectedRevenue() {
		return expectedRevenue;
	}

	public void setExpectedRevenue(BigDecimal expectedRevenue) {
		this.expectedRevenue = expectedRevenue;
	}

	public List<String> getLeadSources() {
		return leadSources;
	}

	public void setLeadSources(List<String> leadSources) {
		this.leadSources = leadSources;
	}

	public List<String> getTouchPoints() {
		return touchPoints;
	}

	public void setTouchPoints(List<String> touchPoints) {
		this.touchPoints = touchPoints;
	}

	public List<String> getAssets() {
		return assets;
	}

	public void setAssets(List<String> assets) {
		this.assets = assets;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String getDocumentRefId() {
		return getCampaignDocumentRefId();
	}

	private final String PREFIX = "MAP - Campaign";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

}
