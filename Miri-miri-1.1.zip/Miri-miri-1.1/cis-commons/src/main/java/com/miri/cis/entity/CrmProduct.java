package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for CRM Product document in elasticsearch
 * 
 * @author rammoole
 *
 */
@Component
public class CrmProduct extends ESEntity {

	private static final long serialVersionUID = 5003878942852922723L;

	private String productDocumentRefId;

	@CSVColumnRank(1)
	private String productId;

	@CSVColumnRank(1.1)
	private String active;

	@CSVColumnRank(5)
	private String createdBy;

	@CSVColumnRank(7.1)
	private String lastModifiedBy;

	@CSVColumnRank(3)
	private String productCode;

	@CSVColumnRank(4)
	private String productDescription;

	@CSVColumnRank(2)
	private String productFamily;

	@CSVColumnRank(1.1)
	private String productName;

	@CSVColumnRank(1.11)
	private String levelOne;

	@CSVColumnRank(1.12)
	private String levelTwo;

	@CSVColumnRank(1.13)
	private String levelThree;

	@CSVColumnRank(6)
	private String createdDate;

	@CSVColumnRank(4.1)
	private double defaultPrice;

	@CSVColumnRank(7)
	private String lastModifiedDate;

	public String getProductDocumentRefId() {
		return productDocumentRefId;
	}

	public void setProductDocumentRefId(String productDocumentRefId) {
		this.productDocumentRefId = productDocumentRefId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getProductFamily() {
		return productFamily;
	}

	public void setProductFamily(String productFamily) {
		this.productFamily = productFamily;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public double getDefaultPrice() {
		return defaultPrice;
	}

	public void setDefaultPrice(double defaultPrice) {
		this.defaultPrice = defaultPrice;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String getDocumentRefId() {
		return getProductDocumentRefId();
	}

	private final String PREFIX = "CRM - Product";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

	public String getLevelOne() {
		return levelOne;
	}

	public void setLevelOne(String levelOne) {
		this.levelOne = levelOne;
	}

	public String getLevelTwo() {
		return levelTwo;
	}

	public void setLevelTwo(String levelTwo) {
		this.levelTwo = levelTwo;
	}

	public String getLevelThree() {
		return levelThree;
	}

	public void setLevelThree(String levelThree) {
		this.levelThree = levelThree;
	}

}
