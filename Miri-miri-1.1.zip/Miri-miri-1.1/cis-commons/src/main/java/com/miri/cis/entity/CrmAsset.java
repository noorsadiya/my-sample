package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for CRM Account document in elasticsearch
 * @author rammoole
 *
 */
@Component
public class CrmAsset extends ESEntity {
	
	private static final long serialVersionUID = -1885105272202023469L;

	private String assetDocumentId;
	
	private String assetId;
	@CSVColumnRank(1)
	private String assetName;
	@CSVColumnRank(2)
	private double price;
	@CSVColumnRank(3)
	private String productId;
	@CSVColumnRank(5)
	private String accountId;
	@CSVColumnRank(6)
	private String createdDate;
	@CSVColumnRank(7)
	private String createdBy;
	@CSVColumnRank(8)
	private String lastModifiedBy;
	@CSVColumnRank(9)
	private String lastModifiedDate;
	@CSVColumnRank(10)
	private String status;
	@CSVColumnRank(11)
	private String description;
	@CSVColumnRank(3.1)
	private int quantity;
	
	public String getAssetDocumentId() {
		return assetDocumentId;
	}
	
	public void setAssetDocumentId(String assetDocumentId) {
		this.assetDocumentId = assetDocumentId;
	}
	
	public String getAssetId() {
		return assetId;
	}
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	
	private final String PREFIX = "CRM - Asset";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

	@Override
	public String getDocumentRefId() {
		return getAssetDocumentId();
	}
}
