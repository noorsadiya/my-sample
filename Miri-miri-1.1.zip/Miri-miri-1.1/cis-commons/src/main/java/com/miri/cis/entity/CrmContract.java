
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for MAP Contract document in elasticsearch
 * @author rammoole
 *
 */
@Component
public class CrmContract extends ESEntity {

	private static final long serialVersionUID = 8357051926408038372L;

	private String contractDocumentRefId;

    @CSVColumnRank(1)
    private String accountId;

    @CSVColumnRank(2)
    private String contractId;

    @CSVColumnRank(3)
    private String contractName;

    @CSVColumnRank(4)
    private String contractNumber;

    @CSVColumnRank(5)
    private String contractOwner;

    @CSVColumnRank(6)
    private String status;

    @CSVColumnRank(7)
    private String activatedDate;

    @CSVColumnRank(8)
    private String createdBy;

    @CSVColumnRank(8.1)
    private String createdDate;

    @CSVColumnRank(9)
    private String lastModifiedBy;

    @CSVColumnRank(10)
    private String lastModifiedDate;


    /**
     *
     * @return
     *     The accountId
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     *
     * @return
     *     The activatedDate
     */
    public String getActivatedDate() {
        return activatedDate;
    }


    /**
     *
     * @return
     *     The contractDocumentRefId
     */
    public String getContractDocumentRefId() {
        return contractDocumentRefId;
    }

    /**
     *
     * @return
     *     The contractId
     */
    public String getContractId() {
        return contractId;
    }

    /**
     *
     * @return
     *     The contractName
     */
    public String getContractName() {
        return contractName;
    }

    /**
     *
     * @return
     *     The contractNumber
     */
    public String getContractNumber() {
        return contractNumber;
    }

    /**
     *
     * @return
     *     The contractOwner
     */
    public String getContractOwner() {
        return contractOwner;
    }

    /**
     *
     * @return
     *     The createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     *
     * @return
     *     The createdDate
     */
    public String getCreatedDate() {
        return createdDate;
    }



    /**
     *
     * @return
     *     The lastModifiedBy
     */
    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    /**
     *
     * @return
     *     The lastModifiedDate
     */
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    /**
     *
     * @return
     *     The status
     */
    public String getStatus() {
        return status;
    }

    /**
     *
     * @param accountId
     *     The accountId
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     *
     * @param activatedDate
     *     The activatedDate
     */
    public void setActivatedDate(String activatedDate) {
        this.activatedDate = activatedDate;
    }

    /**
     *
     * @param contractDocumentRefId
     *     The contractDocumentRefId
     */
    public void setContractDocumentRefId(String contractDocumentRefId) {
        this.contractDocumentRefId = contractDocumentRefId;
    }

    /**
     *
     * @param contractId
     *     The contractId
     */
    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    /**
     *
     * @param contractName
     *     The contractName
     */
    public void setContractName(String contractName) {
        this.contractName = contractName;
    }

    /**
     *
     * @param contractNumber
     *     The contractNumber
     */
    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    /**
     *
     * @param contractOwner
     *     The contractOwner
     */
    public void setContractOwner(String contractOwner) {
        this.contractOwner = contractOwner;
    }

    /**
     *
     * @param createdBy
     *     The createdBy
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     *
     * @param createdDate
     *     The createdDate
     */
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    /**
     *
     * @param lastModifiedBy
     *     The lastModifiedBy
     */
    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    /**
     *
     * @param lastModifiedDate
     *     The lastModifiedDate
     */
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

     /*
     * @param status
     *     The status
     */
    public void setStatus(String status) {
        this.status = status;
    }

	@Override
	public String getDocumentRefId() {
		return getContractDocumentRefId();
	}

	
	private final String PREFIX = "CRM - Contract";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

}
