/**
 *
 */
package com.miri.cis.entity;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @author chavanka
 *
 */
@Component
public class MarketingInfluencedRevenueTarget {

	private Integer id;

	private String month;

	private Number value;

	public MarketingInfluencedRevenueTarget() {
	}

	public MarketingInfluencedRevenueTarget(Integer id, String month, Number value) {
		this.id = id;
		this.month = month;
		this.value = value;
	}

	/**
	 *
	 * @return The id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 *
	 * @param id The id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 *
	 * @return The month
	 */
	public String getMonth() {
		return month;
	}

	/**
	 *
	 * @param month The month
	 */
	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 *
	 * @return The value
	 */
	public Number getValue() {
		return value;
	}

	/**
	 *
	 * @param value The value
	 */
	public void setValue(Number value) {
		this.value = value;
	}
	
	public String csvColumnsValues() {
		return StringUtils.trimToEmpty(getMonth()+"-"+getValue()); 

	}
}
