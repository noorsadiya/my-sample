
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;;

/**
 * Entity for ERP Opportunity Competitor document in elasticsearch
 * @author rammoole
 *
 */
@Component
public class ErpOpportunityCompetitor  extends ESEntity {

    /**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -3065853401772212775L;

	private String opportunityCompetitorDocumentRefId;

    private String competitorName;
    private String opportunityId;
    private String strengths;
    private String weaknesses;
    private String createdBy;
    private String createdDate;
    private String lastModifiedBy;
    private String lastModifiedDate;

    private String url;

    public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

    /**
     *
     * @return
     *     The opportunityCompetitorDocumentRefId
     */
    public String getOpportunityCompetitorDocumentRefId() {
        return opportunityCompetitorDocumentRefId;
    }

    /**
     *
     * @param opportunityCompetitorDocumentRefId
     *     The opportunityCompetitorDocumentRefId
     */
    public void setOpportunityCompetitorDocumentRefId(String opportunityCompetitorDocumentRefId) {
        this.opportunityCompetitorDocumentRefId = opportunityCompetitorDocumentRefId;
    }

    /**
     *
     * @return
     *     The competitorName
     */
    public String getCompetitorName() {
        return competitorName;
    }

    /**
     *
     * @param competitorName
     *     The competitorName
     */
    public void setCompetitorName(String competitorName) {
        this.competitorName = competitorName;
    }

    /**
     *
     * @return
     *     The opportunityId
     */
    public String getOpportunityId() {
        return opportunityId;
    }

    /**
     *
     * @param opportunityId
     *     The opportunityId
     */
    public void setOpportunityId(String opportunityId) {
        this.opportunityId = opportunityId;
    }

    /**
     *
     * @return
     *     The strengths
     */
    public String getStrengths() {
        return strengths;
    }

    /**
     *
     * @param strengths
     *     The strengths
     */
    public void setStrengths(String strengths) {
        this.strengths = strengths;
    }

    /**
     *
     * @return
     *     The weaknesses
     */
    public String getWeaknesses() {
        return weaknesses;
    }

    /**
     *
     * @param weaknesses
     *     The weaknesses
     */
    public void setWeaknesses(String weaknesses) {
        this.weaknesses = weaknesses;
    }

    /**
     *
     * @return
     *     The createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     *
     * @param createdBy
     *     The createdBy
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     *
     * @return
     *     The createdDate
     */
    public String getCreatedDate() {
        return createdDate;
    }

    /**
     *
     * @param createdDate
     *     The createdDate
     */
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    /**
     *
     * @return
     *     The lastModifiedBy
     */
    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    /**
     *
     * @param lastModifiedBy
     *     The lastModifiedBy
     */
    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    /**
     *
     * @return
     *     The lastModifiedDate
     */
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    /**
     *
     * @param lastModifiedDate
     *     The lastModifiedDate
     */
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

	@Override
	public String getDocumentRefId() {
		return getOpportunityCompetitorDocumentRefId();
	}

	private final String PREFIX = "ERP - Opportunity";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}
}
