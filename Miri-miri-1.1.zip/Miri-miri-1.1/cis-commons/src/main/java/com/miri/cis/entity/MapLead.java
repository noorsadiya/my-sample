
package com.miri.cis.entity;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for MAP Lead document in Elasticsearch.
 *
 * @author rammoole
 *
 */
@Component
public class MapLead extends ESEntity {

	private static final long serialVersionUID = -3821294060618479115L;

	private String leadDocumentRefId;

	private String leadId;

	@CSVColumnRank(1)
	private String leadName;

	@CSVColumnRank(16)
	private String website;

	@CSVColumnRank(15)
	private BigDecimal annualRevenue;

	@CSVColumnRank(14)
	private int noOfEmployees;

	@CSVColumnRank(13)
	private String industry;

	@CSVColumnRank(10)
	private String email;

	@CSVColumnRank(11)
	private String jobTitle;

	@CSVColumnRank(12)
	private String companyName;

	private String companyId;

	@CSVColumnRank(9)
	private String createdDate;

	@CSVColumnRank(20)
	private String lastModifiedDate;

	@CSVColumnRank(7)
	private String leadOwner;

	@CSVColumnRank(8)
	private String leadSource;

	private String leadStatus;

	@CSVColumnRank(6)
	private String createdBy;

	private String campaignId;

	@CSVColumnRank(5)
	private String campaignName;

	@JsonUnwrapped(prefix="billing")
	@CSVColumnRank(17)
	private Address billingAddress;

	@JsonUnwrapped(prefix="shipping")
	@CSVColumnRank(18)
	private Address shippingAddress;

	@CSVColumnRank(19)
	private String phone;

	private String mobilePhone;
	@CSVColumnRank(16.5)
	private String sicCode;

	@CSVColumnRank(2)
	private String firstName;

	@CSVColumnRank(3)
	private String lastName;

	private String rating;

	private String leadScore;

	@CSVColumnRank(4)
	private String middleName;
	
	@CSVColumnRank(14.5)
	private String department;
	
	@CSVColumnRank(19)
	private String lastModifiedBy;

	private List<String> touchPoints;

	@CSVColumnRank(3.1)
	private List<String> assets;

	public String getLeadId() {
		return leadId;
	}

	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}

	public String getLeadName() {
		return leadName;
	}

	public void setLeadName(String leadName) {
		this.leadName = leadName;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public BigDecimal getAnnualRevenue() {
		return annualRevenue;
	}

	public void setAnnualRevenue(BigDecimal annualRevenue) {
		this.annualRevenue = annualRevenue;
	}

	public int getNoOfEmployees() {
		return noOfEmployees;
	}

	public void setNoOfEmployees(int noOfEmployees) {
		this.noOfEmployees = noOfEmployees;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLeadOwner() {
		return leadOwner;
	}

	public void setLeadOwner(String leadOwner) {
		this.leadOwner = leadOwner;
	}

	public String getLeadSource() {
		return leadSource;
	}

	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}

	public String getLeadStatus() {
		return leadStatus;
	}

	public void setLeadStatus(String leadStatus) {
		this.leadStatus = leadStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public Address getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}

	public Address getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(Address shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getSicCode() {
		return sicCode;
	}

	public void setSicCode(String sicCode) {
		this.sicCode = sicCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getLeadScore() {
		return leadScore;
	}

	public void setLeadScore(String leadScore) {
		this.leadScore = leadScore;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getLeadDocumentRefId() {
		return leadDocumentRefId;
	}

	public void setLeadDocumentRefId(String leadDocumentRefId) {
		this.leadDocumentRefId = leadDocumentRefId;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public List<String> getTouchPoints() {
		return touchPoints;
	}

	public void setTouchPoints(List<String> touchPoints) {
		this.touchPoints = touchPoints;
	}

	public List<String> getAssets() {
		return assets;
	}

	public void setAssets(List<String> assets) {
		this.assets = assets;
	}

	@Override
	public String getDocumentRefId() {
		return getLeadDocumentRefId();
	}

	public String getIdentifier() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(this.getLeadSource());
		stringBuilder.append("-");
		stringBuilder.append(StringUtils.join(this.getAssets(), ","));
		return stringBuilder.toString();
	}
	
	public String getMapAssets() {
		return StringUtils.join(this.getAssets(), ",");
	}
	private final String PREFIX = "MAP - Lead";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

	@Override
	public String csvColumnsValues() {
		String value = StringUtils.EMPTY;
		for (String fieldStr : sortedColumnNames()) {
			try {
				Field field = null;
				field = this.getClass().getDeclaredField(fieldStr);
				if (null != field) {
					field.setAccessible(true);
					if (field.getType().getName().equals(Address.class.getName()) && field.get(this) != null) {
						value = value + StringUtils.trim(((Address) field.get(this)).csvColumnsValues());
					} else {
						value = value + clean(String.valueOf(field.get(this)));
					}
					value = value + ",";
				}
			} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
				e.printStackTrace();
			}
		}

		return value;

	}

}
