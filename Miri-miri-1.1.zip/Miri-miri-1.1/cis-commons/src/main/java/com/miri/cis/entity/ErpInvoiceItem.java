package com.miri.cis.entity;


import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * ERP Invoice Item Elasticsearch entity for invoice item.
 * @author rammoole
 *
 */
@Component
public class ErpInvoiceItem  extends ESEntity {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 6372905979483532258L;

	private String invoiceItemDocumentId;

	@CSVColumnRank(5)
	private int quantity;

	@CSVColumnRank(5)
	private int quantityOrdered;

	@CSVColumnRank(5)
	private int quantityRemaining;

	@CSVColumnRank(5)
	private double amount;

	@CSVColumnRank(5)
	private double price;

	private String description;

	@CSVColumnRank(5)
	private String  productId;

	@CSVColumnRank(5)
	private String createdDate; // date created

	@CSVColumnRank(5)
	private String createdBy;

	@CSVColumnRank(5)
	private String lastModifiedDate;

	@CSVColumnRank(5)
	private String lastModifiedBy;
	
	private String invoiceItemId;
	
	@CSVColumnRank(5)
	private String productName;
	
	private double amountUSD;
	
	private double amountGBP;
	
	private double amountEUR;
	
	private String levelTwo;
	
	private String levelOne;
	
	private String levelThree;
	
	private String productFamily;
	
	private String opportunityId;
	
	public String getOpportunityId() {
		return opportunityId;
	}
	
	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}
	
	public String getLevelTwo() {
		return levelTwo;
	}

	public void setLevelTwo(String levelTwo) {
		this.levelTwo = levelTwo;
	}

	public String getLevelOne() {
		return levelOne;
	}

	public void setLevelOne(String levelOne) {
		this.levelOne = levelOne;
	}

	public String getLevelThree() {
		return levelThree;
	}

	public void setLevelThree(String levelThree) {
		this.levelThree = levelThree;
	}

	public String getProductFamily() {
		return productFamily;
	}

	public void setProductFamily(String productFamily) {
		this.productFamily = productFamily;
	}

	public void setInvoiceItemDocumentId(String invoiceItemDocumentId) {
		this.invoiceItemDocumentId = invoiceItemDocumentId;
	}

	public String getInvoiceItemDocumentId() {
		return invoiceItemDocumentId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getQuantityOrdered() {
		return quantityOrdered;
	}

	public void setQuantityOrdered(int quantityOrdered) {
		this.quantityOrdered = quantityOrdered;
	}

	public int getQuantityRemaining() {
		return quantityRemaining;
	}

	public void setQuantityRemaining(int quantityRemaining) {
		this.quantityRemaining = quantityRemaining;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	 public void setPrice(double price) {
		this.price = price;
	}

	 public double getPrice() {
		return price;
	}

	 public void setProductId(String productId) {
		this.productId = productId;
	}

	 public String getProductId() {
		return productId;
	}
	 
	public String getInvoiceItemId() {
		return invoiceItemId;
	}

	public void setInvoiceItemId(String invoiceItemId) {
		this.invoiceItemId = invoiceItemId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	@Override
	public String getDocumentRefId() {
		return getInvoiceItemDocumentId();
	}
	
	private final String PREFIX = "ERP - Invoice Item";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

	/**
	 * @return the amountUSD
	 */
	public double getAmountUSD() {
		return amountUSD;
	}

	/**
	 * @param amountUSD the amountUSD to set
	 */
	public void setAmountUSD(double amountUSD) {
		this.amountUSD = amountUSD;
	}

	/**
	 * @return the amountGBP
	 */
	public double getAmountGBP() {
		return amountGBP;
	}

	/**
	 * @param amountGBP the amountGBP to set
	 */
	public void setAmountGBP(double amountGBP) {
		this.amountGBP = amountGBP;
	}

	/**
	 * @return the amountEUR
	 */
	public double getAmountEUR() {
		return amountEUR;
	}

	/**
	 * @param amountEUR the amountEUR to set
	 */
	public void setAmountEUR(double amountEUR) {
		this.amountEUR = amountEUR;
	}
}
