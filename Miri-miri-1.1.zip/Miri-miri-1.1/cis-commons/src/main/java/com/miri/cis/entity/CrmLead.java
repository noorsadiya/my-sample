
package com.miri.cis.entity;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * POJO for MAP Lead document in elasticsearch
 * 
 * @author rammoole
 *
 */
@Component
public class CrmLead extends ESEntity {

	private static final long serialVersionUID = -1159929622258640443L;

	private String leadDocumentRefId;

	private String leadId;

	@CSVColumnRank(1)
	private String leadName;

	private BigDecimal annualRevenue;

	@CSVColumnRank(11.7)
	private int noOfEmployees;

	@CSVColumnRank(11.8)
	private String industry;

	@CSVColumnRank(5)
	private String email;

	@CSVColumnRank(2)
	private String title;

	@CSVColumnRank(11)
	private String company;

	@CSVColumnRank(9)
	private String createdDate;

	@CSVColumnRank(10)
	private String lastModifiedDate;

	@CSVColumnRank(4)
	private String leadOwner;

	@CSVColumnRank(6)
	private String leadSource;

	@CSVColumnRank(7)
	private String leadStatus;

	@CSVColumnRank(8)
	private String createdBy;

	private String campaignId;

	@CSVColumnRank(3)
	private String campaignName;

	@JsonUnwrapped(prefix="billing")
	@CSVColumnRank(14)
	private Address billingAddress;

	@JsonUnwrapped(prefix="shipping")
	@CSVColumnRank(15)
	private Address shippingAddress;

	@CSVColumnRank(16)
	private String phone;

	@CSVColumnRank(11.9)
	private String sicCode;

	@CSVColumnRank(12.1)
	private String rating;

	private String leadScore;

	@CSVColumnRank(12)
	private String accountName;

	private String accountId;

	@CSVColumnRank(13)
	private String website;

	@CSVColumnRank(1.1)
	private String productInterest;

	@CSVColumnRank(10.1)
	private String lastModifiedBy;

	public String getLeadDocumentRefId() {
		return leadDocumentRefId;
	}

	public void setLeadDocumentRefId(String leadDocumentRefId) {
		this.leadDocumentRefId = leadDocumentRefId;
	}

	public String getLeadId() {
		return leadId;
	}

	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}

	public String getLeadName() {
		return leadName;
	}

	public void setLeadName(String leadName) {
		this.leadName = leadName;
	}

	public BigDecimal getAnnualRevenue() {
		return annualRevenue;
	}

	public void setAnnualRevenue(BigDecimal annualRevenue) {
		this.annualRevenue = annualRevenue;
	}

	public int getNoOfEmployees() {
		return noOfEmployees;
	}

	public void setNoOfEmployees(int noOfEmployees) {
		this.noOfEmployees = noOfEmployees;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLeadOwner() {
		return leadOwner;
	}

	public void setLeadOwner(String leadOwner) {
		this.leadOwner = leadOwner;
	}

	public String getLeadSource() {
		return leadSource;
	}

	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}

	public String getLeadStatus() {
		return leadStatus;
	}

	public void setLeadStatus(String leadStatus) {
		this.leadStatus = leadStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public Address getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}

	public Address getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(Address shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSicCode() {
		return sicCode;
	}

	public void setSicCode(String sicCode) {
		this.sicCode = sicCode;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getLeadScore() {
		return leadScore;
	}

	public void setLeadScore(String leadScore) {
		this.leadScore = leadScore;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getProductInterest() {
		return productInterest;
	}

	public void setProductInterest(String productInterest) {
		this.productInterest = productInterest;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	@Override
	public String getDocumentRefId() {
		return getLeadDocumentRefId();
	}

	private final String PREFIX = "CRM - Lead";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	@Override
	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames, PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

	@Override
	public String csvColumnsValues() {
		String value = StringUtils.EMPTY;
		for (String fieldStr : sortedColumnNames()) {
			try {
				Field field = null;
				field = this.getClass().getDeclaredField(fieldStr);
				if (null != field) {
					field.setAccessible(true);
					if (field.getType().getName().equals(Address.class.getName()) && field.get(this) != null) {
						value = value + StringUtils.trim(((Address) field.get(this)).csvColumnsValues());
					} else {
						value = value +  clean(String.valueOf(field.get(this)));
					}
					value = value + ",";
				}
			} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
				e.printStackTrace();
			}
		}

		return value;
	}

}
