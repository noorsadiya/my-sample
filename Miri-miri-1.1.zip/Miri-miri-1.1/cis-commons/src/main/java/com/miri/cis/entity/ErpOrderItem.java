package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

/**
 * Entity for ERP orderItem document in Elasticsearch.
 *
 * @author rammoole
 *
 */
@Component
public class ErpOrderItem extends ESEntity {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -2298922858517805588L;

	private String itemDocumentId;

	private String itemId;

	private String itemName; // this can be treated as product name

	private String upccode; // universal product code

	private int quantity;

	private Double totalValue; // total Amount

	private String itemType;

	private Double cost; // unit price

	private String createdDate; // date created

	private String createdBy;

	private String lastModifiedDate;

	private String lastModifiedBy;
	


	public Double getCost() {
		return cost;
	}


	public String getItemDocumentId() {
		return itemDocumentId;
	}


	public void setItemDocumentId(String itemDocumentId) {
		this.itemDocumentId = itemDocumentId;
	}


	public String getItemId() {
		return itemId;
	}


	public void setItemId(String itemId) {
		this.itemId = itemId;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public String getUpccode() {
		return upccode;
	}


	public void setUpccode(String upccode) {
		this.upccode = upccode;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public Double getTotalValue() {
		return totalValue;
	}


	public void setTotalValue(Double totalValue) {
		this.totalValue = totalValue;
	}


	public String getItemType() {
		return itemType;
	}


	public void setItemType(String itemType) {
		this.itemType = itemType;
	}


	public String getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public String getLastModifiedDate() {
		return lastModifiedDate;
	}


	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}


	public String getLastModifiedBy() {
		return lastModifiedBy;
	}


	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}


	public void setCost(Double cost) {
		this.cost = cost;
	}

	

	@Override
	public String getDocumentRefId() {
		return getItemDocumentId();
	}
	
	private final String PREFIX = "ERP - Order Item";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}
}
