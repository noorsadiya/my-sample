
package com.miri.cis.entity;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * CRM Order Details Entity for orderDetails document in elasticsearch
 * 
 * @author rammoole
 *
 */
@Component
public class CrmOrderDetails extends ESEntity {

	private static final long serialVersionUID = -4826300603491034311L;

	private String orderDetailsDocumentRefId;

	@CSVColumnRank(1)
	private String accountId;

	@CSVColumnRank(3.1)
	private String activatedBy;

	@CSVColumnRank(3.2)
	private String activatedDate;

	@JsonUnwrapped(prefix="billing")
	@CSVColumnRank(14)
	private Address billingAddress;

	@CSVColumnRank(15)
	private String billToContact;

	@CSVColumnRank(12.1)
	private String createdBy;

	@CSVColumnRank(2)
	private String contractName;

	private String contractNumber;

	@CSVColumnRank(3)
	private String opportunityId;

	@CSVColumnRank(4)
	private String orderName;

	@CSVColumnRank(5)
	private String orderNumber;

	@CSVColumnRank(6)
	private int amount;

	@CSVColumnRank(7)
	private String orderOwner;

	@CSVColumnRank(8)
	private String orderReferenceNumber;

	@CSVColumnRank(9)
	private String poNumber;

	@CSVColumnRank(10)
	private String poDate;

	@CSVColumnRank(11)
	private String status;

	@CSVColumnRank(13)
	private String lastModBy;
	@CSVColumnRank(12)
	private String createdDate;

	@CSVColumnRank(13.1)
	private String lastModifiedDate;

	public String getOrderDetailsDocumentRefId() {
		return orderDetailsDocumentRefId;
	}

	public void setOrderDetailsDocumentRefId(String orderDetailsDocumentRefId) {
		this.orderDetailsDocumentRefId = orderDetailsDocumentRefId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getActivatedBy() {
		return activatedBy;
	}

	public void setActivatedBy(String activatedBy) {
		this.activatedBy = activatedBy;
	}

	public String getActivatedDate() {
		return activatedDate;
	}

	public void setActivatedDate(String activatedDate) {
		this.activatedDate = activatedDate;
	}

	public Address getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}

	public String getBillToContact() {
		return billToContact;
	}

	public void setBillToContact(String billToContact) {
		this.billToContact = billToContact;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getContractName() {
		return contractName;
	}

	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

	public String getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}

	public String getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getOrderName() {
		return orderName;
	}

	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getOrderOwner() {
		return orderOwner;
	}

	public void setOrderOwner(String orderOwner) {
		this.orderOwner = orderOwner;
	}

	public String getOrderReferenceNumber() {
		return orderReferenceNumber;
	}

	public void setOrderReferenceNumber(String orderReferenceNumber) {
		this.orderReferenceNumber = orderReferenceNumber;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getPoDate() {
		return poDate;
	}

	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLastModBy() {
		return lastModBy;
	}

	public void setLastModBy(String lastModBy) {
		this.lastModBy = lastModBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String getDocumentRefId() {
		return getOrderDetailsDocumentRefId();
	}

	private final String PREFIX = "CRM - Order Details";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

	@Override
	public String csvColumnsValues() {
		String value = StringUtils.EMPTY;
		for (String fieldStr : sortedColumnNames()) {
			try {
				Field field = null;
				field = this.getClass().getDeclaredField(fieldStr);
				if (null != field) {
					field.setAccessible(true);
					if (field.getType().getName().equals(Address.class.getName()) && field.get(this) != null) {
						value = value + StringUtils.trim(((Address) field.get(this)).csvColumnsValues());
					} else {
						value = value + clean(String.valueOf(field.get(this)));
					}
					value = value + ",";
				}
			} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
				e.printStackTrace();
			}
		}
		return value;
	}

}
