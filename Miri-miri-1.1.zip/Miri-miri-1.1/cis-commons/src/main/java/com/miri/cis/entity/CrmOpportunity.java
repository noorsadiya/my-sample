
package com.miri.cis.entity;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * Entity for CRM opportunity document in Elasticsearch.
 *
 * @author rammoole
 *
 */
@Component
public class CrmOpportunity extends ESEntity {

	private static final long serialVersionUID = 4512021230851378788L;

	private String accountId;

	@CSVColumnRank(10)
	private double amount;

	@CSVColumnRank(9)
	private BigDecimal annualRevenue;

	private String closedDate;

	@CSVColumnRank(8)
	private String companyInformation;

	@CSVColumnRank(7)
	private String companyName;

	@CSVColumnRank(4)
	private String createdBy;

	@CSVColumnRank(5)
	private String createdOn;

	@CSVColumnRank(6.1)
	private String description;

	@CSVColumnRank(7)
	private double expectedRevenue;

	private String fiscal;

	private String fiscalCategory;

	private String fiscalQuarter;

	private String fiscalYear;

	@CSVColumnRank(13)
	private String industry;

	@CSVColumnRank(14)
	private String lastModifiedBy;

	@CSVColumnRank(15)
	private String lastModifiedDate;

	@CSVColumnRank(11)
	private String leadSource;

	@CSVColumnRank(12)
	private String location;

	private List<String> mainCompetitors = new ArrayList<>();

	private String nextStep;

	private String opportunityDocumentRefId;

	private String opportunityId;

	@CSVColumnRank(1)
	private String opportunityName;

	@CSVColumnRank(2)
	private String opportunityStatus;

	@CSVColumnRank(3)
	private String opportunityType;

	private String orderNumber;

	private String owner;

	private List<String> painPoints = new ArrayList<>();

	@CSVColumnRank(1.1)
	private String primaryCampSource;

	@CSVColumnRank(2.1)
	private int probabilityPerc;

	@CSVColumnRank(6)
	private int quantity;

	@CSVColumnRank(13.1)
	private String site;

	@CSVColumnRank(3.1)
	private String stage;
	
	@CSVColumnRank(3.2)
	private List<String> assets;
	
	@CSVColumnRank(3.3)
	private String competitor;
	
	@CSVColumnRank(3.4)
	private String product;
	
	@CSVColumnRank(3.5)
	private String accountName;
	
	@CSVColumnRank(3.6)
	private String country;
	
	@CSVColumnRank(3.7)
	private String partnerRole;
	
	@CSVColumnRank(3.8)
	private String partners;
	
	@CSVColumnRank(3.9)
	private String campaignName;
	
	@CSVColumnRank(3.91)
	private String parentCampaignName;
	
	public String getParentCampaignName() {
		return parentCampaignName;
	}
	public void setParentCampaignName(String parentCampaignName) {
		this.parentCampaignName = parentCampaignName;
	}
	
	public String getPartnerRole() {
		return partnerRole;
	}
	public void setPartnerRole(String partnerRole) {
		this.partnerRole = partnerRole;
	}
	public String getPartners() {
		return partners;
	}
	public void setPartners(String partners) {
		this.partners = partners;
	}
	public String getCampaignName() {
		return campaignName;
	}
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	
	public String getCountry() {
		return country;
	}
	
	public void setCountry(String country) {
		this.country = country;
	}
	
	public String getProduct() {
		return product;
	}
	
	public void setProduct(String product) {
		this.product = product;
	}
	
	public String getCompetitor() {
		return competitor;
	}
	
	public void setCompetitor(String competitor) {
		this.competitor = competitor;
	}
	
	
	public List<String> getAssets() {
		return assets;
	}
	
	public void setAssets(List<String> assets) {
		this.assets = assets;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public BigDecimal getAnnualRevenue() {
		return annualRevenue;
	}

	public void setAnnualRevenue(BigDecimal annualRevenue) {
		this.annualRevenue = annualRevenue;
	}

	public String getClosedDate() {
		return closedDate;
	}

	public void setClosedDate(String closedDate) {
		this.closedDate = closedDate;
	}

	public String getCompanyInformation() {
		return companyInformation;
	}

	public void setCompanyInformation(String companyInformation) {
		this.companyInformation = companyInformation;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getExpectedRevenue() {
		return expectedRevenue;
	}

	public void setExpectedRevenue(double expectedRevenue) {
		this.expectedRevenue = expectedRevenue;
	}

	public String getFiscal() {
		return fiscal;
	}

	public void setFiscal(String fiscal) {
		this.fiscal = fiscal;
	}

	public String getFiscalCategory() {
		return fiscalCategory;
	}

	public void setFiscalCategory(String fiscalCategory) {
		this.fiscalCategory = fiscalCategory;
	}

	public String getFiscalQuarter() {
		return fiscalQuarter;
	}

	public void setFiscalQuarter(String fiscalQuarter) {
		this.fiscalQuarter = fiscalQuarter;
	}

	public String getFiscalYear() {
		return fiscalYear;
	}

	public void setFiscalYear(String fiscalYear) {
		this.fiscalYear = fiscalYear;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLeadSource() {
		return leadSource;
	}

	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<String> getMainCompetitors() {
		return mainCompetitors;
	}

	public void setMainCompetitors(List<String> mainCompetitors) {
		this.mainCompetitors = mainCompetitors;
	}

	public String getNextStep() {
		return nextStep;
	}

	public void setNextStep(String nextStep) {
		this.nextStep = nextStep;
	}

	public String getOpportunityDocumentRefId() {
		return opportunityDocumentRefId;
	}

	public void setOpportunityDocumentRefId(String opportunityDocumentRefId) {
		this.opportunityDocumentRefId = opportunityDocumentRefId;
	}

	public String getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getOpportunityStatus() {
		return opportunityStatus;
	}

	public void setOpportunityStatus(String opportunityStatus) {
		this.opportunityStatus = opportunityStatus;
	}

	public String getOpportunityType() {
		return opportunityType;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public List<String> getPainPoints() {
		return painPoints;
	}

	public void setPainPoints(List<String> painPoints) {
		this.painPoints = painPoints;
	}

	public String getPrimaryCampSource() {
		return primaryCampSource;
	}

	public void setPrimaryCampSource(String primaryCampSource) {
		this.primaryCampSource = primaryCampSource;
	}

	public int getProbabilityPerc() {
		return probabilityPerc;
	}

	public void setProbabilityPerc(int probabilityPerc) {
		this.probabilityPerc = probabilityPerc;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	
	@Override
	public String toString() {
		return "CrmOpportunity [opportunityDocumentRefId=" + opportunityDocumentRefId + ", opportunityId="
				+ opportunityId + ", createdOn=" + createdOn + ", lastModifiedDate=" + lastModifiedDate + ", amount="
				+ amount + ", closedDate=" + closedDate + ", expectedRevenue=" + expectedRevenue
				+ ", companyInformation=" + companyInformation + ", owner=" + owner + ", leadSource=" + leadSource
				+ ", opportunityName=" + opportunityName + ", nextStep=" + nextStep + ", probabilityPerc="
				+ probabilityPerc + ", stage=" + stage + ", opportunityType=" + opportunityType + ", createdBy="
				+ createdBy + ", opportunityStatus=" + opportunityStatus + ", accountId=" + accountId + ", companyName="
				+ companyName + ", location=" + location + ", annualRevenue=" + annualRevenue + ", industry=" + industry
				+ ", mainCompetitors=" + mainCompetitors + ", site=" + site + ", fiscal=" + fiscal + ", fiscalQuarter="
				+ fiscalQuarter + ", fiscalYear=" + fiscalYear + ", fiscalCategory=" + fiscalCategory + ", quantity="
				+ quantity + ", primaryCampSource=" + primaryCampSource + ", description=" + description
				+ ", painPoints=" + painPoints + ", orderNumber=" + orderNumber + ", lastModifiedBy=" + lastModifiedBy
				+ "]";
	}

	@Override
	public String getDocumentRefId() {
		return getOpportunityDocumentRefId();
	}
	
	/**
	 * Converts  the Assets into comma separated Value
	 * @return
	 */
	public String getAssetsCombined(){
		return StringUtils.join(this.getAssets(), ",");
	}
	
	public String getIdentifier() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(this.getLeadSource());
		stringBuilder.append("-");
		stringBuilder.append(StringUtils.join(this.getAssets(), ","));
		return stringBuilder.toString();
	}
	private final String PREFIX = "CRM - Opportunity";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}

	@Override
	public String csvColumnsValues() {
		String value = StringUtils.EMPTY;
		for (String fieldStr : sortedColumnNames()) {
			try {
				Field field = null;
				field = this.getClass().getDeclaredField(fieldStr);
				if (null != field) {
					field.setAccessible(true);
					if (field.getType().getName().equals(Address.class.getName()) && field.get(this) != null) {
						value = value + StringUtils.trim(((Address) field.get(this)).csvColumnsValues());
					} else {
						value = value + clean(String.valueOf(field.get(this)));
					}
					value = value + ",";
				}
			} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
				e.printStackTrace();
			}
		}

		return value;

	}
	
}
