
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

/**
 * POJO for MAP asset document in elasticsearch
 * 
 * @author rammoole
 *
 */
@Component
public class MapAsset extends ESEntity {

	private static final long serialVersionUID = 7989107944260753877L;

	private String assetDocumentRefId;

	private String assetId;

	@CSVColumnRank(1)
	private String assetName;

	@CSVColumnRank(2)
	private String createdBy;

	@CSVColumnRank(3)
	private String createdAt;

	@CSVColumnRank(4)
	private String updatedBy;

	@CSVColumnRank(5)
	private String updatedAt;

	/**
	 *
	 * @return The assetDocumentRefId
	 */
	public String getAssetDocumentRefId() {
		return assetDocumentRefId;
	}

	/**
	 *
	 * @param assetDocumentRefId
	 *            The assetDocumentRefId
	 */
	public void setAssetDocumentRefId(String assetDocumentRefId) {
		this.assetDocumentRefId = assetDocumentRefId;
	}

	/**
	 *
	 * @return The assetId
	 */
	public String getAssetId() {
		return assetId;
	}

	/**
	 *
	 * @param assetId
	 *            The assetId
	 */
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	/**
	 *
	 * @return The assetName
	 */
	public String getAssetName() {
		return assetName;
	}

	/**
	 *
	 * @param assetName
	 *            The assetName
	 */
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	/**
	 *
	 * @return The createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 *
	 * @param createdBy
	 *            The createdBy
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 *
	 * @return The createdAt
	 */
	public String getCreatedAt() {
		return createdAt;
	}

	/**
	 *
	 * @param createdAt
	 *            The createdAt
	 */
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 *
	 * @return The updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 *
	 * @param updatedBy
	 *            The updatedBy
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 *
	 * @return The updatedAt
	 */
	public String getUpdatedAt() {
		return updatedAt;
	}

	/**
	 *
	 * @param updatedAt
	 *            The updatedAt
	 */
	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	@Override
	public String getDocumentRefId() {
		return getAssetDocumentRefId();
	}

	private final String PREFIX = "MAP - Asset";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();

	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}


}
