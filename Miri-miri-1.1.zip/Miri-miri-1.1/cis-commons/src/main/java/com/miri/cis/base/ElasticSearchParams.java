/**
 * 
 */
package com.miri.cis.base;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * ElasticSearchParams: Holds parameters used to point to elastic search
 * instance. Creates instance with index and document type for indexing.
 * 
 * @author Chandra
 *
 */
@Component
@Scope("prototype")
public class ElasticSearchParams {

    @Autowired
    ElasticsearchConfig elasticsearchConfig;
    
	@Value("${spring.data.elasticsearch.cluster-nodes}")
	private String server;

	private String port;

	private String index;

	private String documentType;
	
	@Value("${spring.data.elasticsearch.cluster-name}")
	private String clusterName;

	public ElasticsearchConfig getElasticsearchConfig() {
        return elasticsearchConfig;
    }

    public void setElasticsearchConfig(ElasticsearchConfig elasticsearchConfig) {
        this.elasticsearchConfig = elasticsearchConfig;
    }

    public ElasticSearchParams() {
		super();
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getServer() {
		return server;
	}

	public void setServer(String server) {
		this.server = server;
	}

	public ElasticSearchParams(String index, String documentType) {
		super();
		this.index = index;
		this.documentType = documentType;
	}

	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	/**
	 * Returns path for given document and index of elastic search.
	 * 
	 * @return
	 */
	public String getDocPath() {
		return server + "/" + getIndex() + "/" + getDocumentType();
	}

	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}
	

}
