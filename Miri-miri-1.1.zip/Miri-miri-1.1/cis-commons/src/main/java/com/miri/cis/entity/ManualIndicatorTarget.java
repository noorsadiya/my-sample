package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class ManualIndicatorTarget extends ESEntity {
	private static final long serialVersionUID = 6632251549705302310L;
	public static final String FIELDNAME_INDICATORID = "indicatorId";
	public static final String FIELDNAME_INDICATORTYPE = "indicatorType";
	public static final String FIELDNAME_INDICATORVALUE = "indicatorValue";
	public static final String FIELDNAME_LASTMODIFIEDDATE = "lastModifiedDate";
	public static final String FIELDNAME_INDICATORVALUE_VALUE = FIELDNAME_INDICATORVALUE + "."
			+ IndicatorValue.FIELDNAME_VALUE;
	public static final String FIELDNAME_INDICATORVALUE_MONTH = FIELDNAME_INDICATORVALUE + "."
			+ IndicatorValue.FIELDNAME_MONTH;
	public static final String FIELDNAME_INDICATORVALUE_ID = FIELDNAME_INDICATORVALUE + "."
			+ IndicatorValue.FIELDNAME_ID;

	private String indicatorId;
	private String indicatorType;
	private List<IndicatorValue> indicatorValue;
	private String createdDate;
	private String lastModifiedDate;

	@Override
	public String getDocumentRefId() {
		return null;
	}

	public String getIndicatorId() {
		return indicatorId;
	}

	public void setIndicatorId(String indicatorId) {
		this.indicatorId = indicatorId;
	}

	public String getIndicatorType() {
		return indicatorType;
	}

	public void setIndicatorType(String indicatorType) {
		this.indicatorType = indicatorType;
	}

	public List<IndicatorValue> getIndicatorValue() {
		return indicatorValue;
	}

	public void setIndicatorValue(List<IndicatorValue> indicatorValue) {
		this.indicatorValue = indicatorValue;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public static class IndicatorValue {
		public static final String FIELDNAME_ID = "id";
		public static final String FIELDNAME_MONTH = "month";
		public static final String FIELDNAME_VALUE = "value";

		private String id;
		private String month;
		private Double value;

		public IndicatorValue() {
		}

		public IndicatorValue(String id, String month, Double value) {
			this.id = id;
			this.month = month;
			this.value = value;
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getMonth() {
			return month;
		}

		public void setMonth(String month) {
			this.month = month;
		}

		public Double getValue() {
			return value;
		}

		public void setValue(Double value) {
			this.value = value;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("IndicatorValue [id=");
			builder.append(id);
			builder.append(", month=");
			builder.append(month);
			builder.append(", value=");
			builder.append(value);
			builder.append("]");
			return builder.toString();
		}
	}

	@SuppressWarnings("unchecked")
	public void update(Map<String, Object> source) {
		Set<Entry<String, Object>> entries = source.entrySet();
		for (Entry<String, Object> entry : entries) {
			String key = entry.getKey();
			switch (key) {
			case "indicatorId":
				this.indicatorId = (String) entry.getValue();
				break;

			case "indicatorType":
				this.indicatorType = (String) entry.getValue();
				break;

			case "indicatorValue":
				if (this.indicatorValue == null) {
					this.indicatorValue = new ArrayList<IndicatorValue>();
				}
				List<?> indicatorValues = (List<?>) entry.getValue();
				for (Object indicatorValue : indicatorValues) {
					Map<String, Object> values = (Map<String, Object>) indicatorValue;
					this.indicatorValue.add(new IndicatorValue((String) values.get(IndicatorValue.FIELDNAME_ID),
							(String) values.get(IndicatorValue.FIELDNAME_MONTH),
							(Double) values.get(IndicatorValue.FIELDNAME_VALUE)));
				}
				break;

			case "createdDate":
				this.createdDate = (String) entry.getValue();
				break;

			case "lastModifiedDate":
				this.lastModifiedDate = (String) entry.getValue();
				break;

			case "tags":
				Object tagsObject = entry.getValue();
				if (String.class.isInstance(tagsObject)) { // why is it string
															// when there are no
															// values?
					String tagsStr = (String) entry.getValue();
					List<String> tagsList = Collections.emptyList();
					if (StringUtils.isNotBlank(tagsStr)) {
						String[] split = tagsStr.split(",");// confirm if this
															// is correct?
						tagsList = Arrays.asList(split);
					}
					this.setTags(tagsList);

				} else {
					this.setTags((List<String>) tagsObject);
				}
				break;

			default:
				break;
			}
		}
	}

	public void update(String id, String indicatorType, List<IndicatorValue> indicatorValue, String createdDate,
			String updatedDate) {
		this.indicatorId = String.valueOf(id);
		this.indicatorType = indicatorType;
		this.indicatorValue = indicatorValue;
		this.createdDate = createdDate;
		this.lastModifiedDate = updatedDate;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ManualIndicatorTarget [indicatorId=");
		builder.append(indicatorId);
		builder.append(", indicatorType=");
		builder.append(indicatorType);
		builder.append(", indicatorValue=");
		builder.append(indicatorValue);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", lastModifiedDate=");
		builder.append(lastModifiedDate);
		builder.append("]");
		return builder.toString();
	}

	@Override
	public String csvColumnsHeaders() {
		return StringUtils.EMPTY;
	}

	@Override
	public String csvColumnsValues() {
		return StringUtils.EMPTY;
	}

	@Override
	public List<String> sortedColumnNames() {
		// TODO Auto-generated method stub
		return null;
	}

}
