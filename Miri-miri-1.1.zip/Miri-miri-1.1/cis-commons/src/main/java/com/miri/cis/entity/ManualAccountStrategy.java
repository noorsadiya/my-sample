/**
 *
 */
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author chavanka
 *
 */
@Component
@JsonIgnoreProperties(ignoreUnknown = true)
public class ManualAccountStrategy extends ESEntity {
	private static final long serialVersionUID = 193851191703167125L;

	private String accountStrategyDocumentRefId;

	private String name;

	private String addressLine1;

	private String addressLine2;

	private String addressLine3;

	private String city;

	private String state;

	private String countryName;

	private String currencyName;

	private String countryIso;

	private String zipCode;

	private String businessUnit;

	private Double annualRevenue;

	private Integer noOfEmployees;

	private String industry;

	private String website;

	private String fiscalYear;

	private String fiscalStart;

	private String logo;

	private boolean draft;

	private String createdDate;

	private String lastModifiedDate;

	private List<String> crmRegions = new ArrayList<String>();

	private List<String> crmSalesStages = new ArrayList<String>();

	private List<String> tags = new ArrayList<String>();


	/**
	 *
	 * @return The accountStrategyDocumentRefId
	 */
	public String getAccountStrategyDocumentRefId() {
		return accountStrategyDocumentRefId;
	}

	/**
	 *
	 * @param accountStrategyDocumentRefId The accountStrategyDocumentRefId
	 */
	public void setAccountStrategyDocumentRefId(String accountStrategyDocumentRefId) {
		this.accountStrategyDocumentRefId = accountStrategyDocumentRefId;
	}

	/**
	 *
	 * @return The name
	 */
	public String getName() {
		return name;
	}

	/**
	 *
	 * @param name The name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 *
	 * @return The addressLine1
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 *
	 * @param addressLine1 The addressLine1
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 *
	 * @return The addressLine2
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 *
	 * @param addressLine2 The addressLine2
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * @return the addressLine3
	 */
	public String getAddressLine3() {
		return addressLine3;
	}

	/**
	 * @param addressLine3 the addressLine3 to set
	 */
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	/**
	 *
	 * @return The city
	 */
	public String getCity() {
		return city;
	}

	/**
	 *
	 * @param city The city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 *
	 * @return The state
	 */
	public String getState() {
		return state;
	}

	/**
	 *
	 * @param state The state
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 *
	 * @return The countryName
	 */
	public String getCountryName() {
		return countryName;
	}

	/**
	 *
	 * @param countryName The countryName
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	/**
	 * @return the currencyName
	 */
	public String getCurrencyName() {
		return currencyName;
	}

	/**
	 * @param currencyName the currencyName to set
	 */
	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	/**
	 *
	 * @return The countryIso
	 */
	public String getCountryIso() {
		return countryIso;
	}

	/**
	 *
	 * @param countryIso The countryIso
	 */
	public void setCountryIso(String countryIso) {
		this.countryIso = countryIso;
	}

	/**
	 *
	 * @return The businessUnit
	 */
	public String getBusinessUnit() {
		return businessUnit;
	}

	/**
	 *
	 * @param businessUnit The businessUnit
	 */
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	/**
	 *
	 * @return The annualRevenue
	 */
	public Double getAnnualRevenue() {
		return annualRevenue;
	}

	/**
	 *
	 * @param annualRevenue The annualRevenue
	 */
	public void setAnnualRevenue(Double annualRevenue) {
		this.annualRevenue = annualRevenue;
	}

	/**
	 *
	 * @return The noOfEmployees
	 */
	public Integer getNoOfEmployees() {
		return noOfEmployees;
	}

	/**
	 *
	 * @param noOfEmployees The noOfEmployees
	 */
	public void setNoOfEmployees(Integer noOfEmployees) {
		this.noOfEmployees = noOfEmployees;
	}

	/**
	 *
	 * @return The industry
	 */
	public String getIndustry() {
		return industry;
	}

	/**
	 *
	 * @param industry The industry
	 */
	public void setIndustry(String industry) {
		this.industry = industry;
	}

	/**
	 *
	 * @return The website
	 */
	public String getWebsite() {
		return website;
	}

	/**
	 *
	 * @param website The website
	 */
	public void setWebsite(String website) {
		this.website = website;
	}

	/**
	 *
	 * @return The fiscalYear
	 */
	public String getFiscalYear() {
		return fiscalYear;
	}

	/**
	 *
	 * @param fiscalYear The fiscalYear
	 */
	public void setFiscalYear(String fiscalYear) {
		this.fiscalYear = fiscalYear;
	}

	/**
	 *
	 * @return The fiscalStart
	 */
	public String getFiscalStart() {
		return fiscalStart;
	}

	/**
	 *
	 * @param fiscalStart The fiscalStart
	 */
	public void setFiscalStart(String fiscalStart) {
		this.fiscalStart = fiscalStart;
	}

	/**
	 *
	 * @return The logo
	 */
	public String getLogo() {
		return logo;
	}

	/**
	 *
	 * @param logo The logo
	 */
	public void setLogo(String logo) {
		this.logo = logo;
	}

	/**
	 * @return the draft
	 */
	public boolean isDraft() {
		return draft;
	}

	/**
	 * @param draft the draft to set
	 */
	public void setDraft(boolean draft) {
		this.draft = draft;
	}

	/**
	 *
	 * @return The createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 *
	 * @param createdDate The createdDate
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 *
	 * @return The lastModifiedDate
	 */
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 *
	 * @param lastModifiedDate The lastModifiedDate
	 */
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public List<String> getCrmRegions() {
		return crmRegions;
	}

	public void setCrmRegions(List<String> crmRegions) {
		this.crmRegions = crmRegions;
	}

	public List<String> getCrmSalesStages() {
		return crmSalesStages;
	}

	public void setCrmSalesStages(List<String> crmSalesStages) {
		this.crmSalesStages = crmSalesStages;
	}

	@Override
	public List<String> getTags() {
		return tags;
	}

	@Override
	public void setTags(List<String> tags) {
		this.tags = tags;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	@Override
	@JsonIgnore
	public String getDocumentRefId() {
		return accountStrategyDocumentRefId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ManualAccountStrategy [accountStrategyDocumentRefId=");
		builder.append(accountStrategyDocumentRefId);
		builder.append(", name=");
		builder.append(name);
		builder.append(", addressLine1=");
		builder.append(addressLine1);
		builder.append(", addressLine2=");
		builder.append(addressLine2);
		builder.append(", addressLine3=");
		builder.append(addressLine3);
		builder.append(", city=");
		builder.append(city);
		builder.append(", state=");
		builder.append(state);
		builder.append(", countryName=");
		builder.append(countryName);
		builder.append(", currencyName=");
		builder.append(currencyName);
		builder.append(", countryIso=");
		builder.append(countryIso);
		builder.append(", zipCode=");
		builder.append(zipCode);
		builder.append(", businessUnit=");
		builder.append(businessUnit);
		builder.append(", annualRevenue=");
		builder.append(annualRevenue);
		builder.append(", noOfEmployees=");
		builder.append(noOfEmployees);
		builder.append(", industry=");
		builder.append(industry);
		builder.append(", website=");
		builder.append(website);
		builder.append(", fiscalYear=");
		builder.append(fiscalYear);
		builder.append(", fiscalStart=");
		builder.append(fiscalStart);
		builder.append(", logo=");
		builder.append(logo);
		builder.append(", isDraft=");
		builder.append(draft);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", lastModifiedDate=");
		builder.append(lastModifiedDate);
		builder.append(", crmRegions=");
		builder.append(crmRegions);
		builder.append(", crmSalesStages=");
		builder.append(crmSalesStages);
		builder.append(", tags=");
		builder.append(tags);
		builder.append(", getVendorType()=");
		builder.append(getVendorType());
		builder.append(", getVendorName()=");
		builder.append(getVendorName());
		builder.append(", getInstanceName()=");
		builder.append(getInstanceName());
		builder.append("]");
		return builder.toString();
	}

	@Override
	public String csvColumnsHeaders() {
		return StringUtils.EMPTY;
	}

	@Override
	public String csvColumnsValues() {
		return StringUtils.EMPTY;
	}

	@Override
	public List<String> sortedColumnNames() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
