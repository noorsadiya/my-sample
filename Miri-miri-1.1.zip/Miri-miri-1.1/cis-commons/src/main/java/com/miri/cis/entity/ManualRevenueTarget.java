package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.miri.cis.base.annotations.CSVColumnRank;

@Component
public class ManualRevenueTarget extends ESEntity {
	
	private static final long serialVersionUID = 4885647509423177846L;

	@CSVColumnRank(4)
	private String businessStrategyDocumentRefId;
	
	@CSVColumnRank(1)
	private Double businessRevenueTarget;
	
	@CSVColumnRank(2)
	private Double marketingInfluencedTarget;
	
	@CSVColumnRank(3)
	private String createdDate; 


	public Double getBusinessRevenueTarget() {
		return businessRevenueTarget;
	}

	public void setBusinessRevenueTarget(Double businessRevenueTarget) {
		this.businessRevenueTarget = businessRevenueTarget;
	}

	public Double getMarketingInfluencedTarget() {
		return marketingInfluencedTarget;
	}

	public void setMarketingInfluencedTarget(Double marketingInfluencedTarget) {
		this.marketingInfluencedTarget = marketingInfluencedTarget;
	}

	
	@Override
	public String getDocumentRefId() {
		return businessStrategyDocumentRefId;
	}
	
	


	public String getBusinessStrategyDocumentRefId() {
		return businessStrategyDocumentRefId;
	}

	public void setBusinessStrategyDocumentRefId(String businessStrategyDocumentRefId) {
		this.businessStrategyDocumentRefId = businessStrategyDocumentRefId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}




	private final String PREFIX = "Business Strategy";

	private static String csvColumnNames = StringUtils.EMPTY;

	private static List<String> sortedColumnNames = new ArrayList<>();
	
	public String csvColumnsHeaders() {
		if (StringUtils.isBlank(csvColumnNames)) {
			sortedColumnNames();
			csvColumnNames = displayCSVColumnNames(sortedColumnNames(), PREFIX);
		}

		return csvColumnNames;

	}

	public List<String> sortedColumnNames() {
		if (null == sortedColumnNames || sortedColumnNames.isEmpty())
			sortedColumnNames = generateColumnNamesByRank(this.getClass());

		return sortedColumnNames;
	}
	

}
