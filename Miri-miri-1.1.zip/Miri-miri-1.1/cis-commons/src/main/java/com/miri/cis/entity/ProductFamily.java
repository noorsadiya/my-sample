
package com.miri.cis.entity;

import java.util.ArrayList;
import java.util.List;

public class ProductFamily {

    private List<String> products = new ArrayList<String>();

    /**
     * 
     * @return
     *     The products
     */
    public List<String> getProducts() {
        return products;
    }

    /**
     * 
     * @param products
     *     The products
     */
    public void setProducts(List<String> products) {
        this.products = products;
    }

}
