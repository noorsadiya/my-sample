-- MySQL dump 10.13  Distrib 5.6.27, for Win64 (x86_64)
--
-- Host: localhost    Database: phaladata
-- ------------------------------------------------------
-- Server version	5.6.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `phaladata`
--

/*!40000 DROP DATABASE IF EXISTS `phaladata`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phaladata` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `phaladata`;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(45) DEFAULT NULL,
  `business_unit` varchar(45) DEFAULT NULL,
  `address1` varchar(50) DEFAULT NULL,
  `address2` varchar(50) DEFAULT NULL,
  `address3` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zip_code` varchar(50) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `industry_id` int(11) DEFAULT NULL,
  `no_of_employees` int(11) DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `annual_revenue` double DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `logo` mediumblob,
  `draft` tinyint(1) NOT NULL DEFAULT '0',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fiscal_start` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `fk_account_country_id` (`country_id`),
  KEY `fk_account_industry_id` (`industry_id`),
  KEY `fk_account_currency_id` (`currency_id`),
  CONSTRAINT `fk_account_country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`),
  CONSTRAINT `fk_account_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`id`),
  CONSTRAINT `fk_account_industry_id` FOREIGN KEY (`industry_id`) REFERENCES `industry` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2016-02-03 06:33:28','2016-02-17 21:17:50','2015-03-31 18:30:00');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `asset_name` text,
  `opportunities` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authority`
--

DROP TABLE IF EXISTS `authority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authority` (
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authority`
--

LOCK TABLES `authority` WRITE;
/*!40000 ALTER TABLE `authority` DISABLE KEYS */;
INSERT INTO `authority` VALUES ('ROLE_ADMIN'),('ROLE_EXECUTIVE'),('ROLE_MASTER'),('ROLE_USER');
/*!40000 ALTER TABLE `authority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_job_execution`
--

DROP TABLE IF EXISTS `batch_job_execution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_job_execution` (
  `JOB_EXECUTION_ID` bigint(20) NOT NULL,
  `VERSION` bigint(20) DEFAULT NULL,
  `JOB_INSTANCE_ID` bigint(20) NOT NULL,
  `CREATE_TIME` datetime NOT NULL,
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `EXIT_CODE` varchar(2500) DEFAULT NULL,
  `EXIT_MESSAGE` varchar(2500) DEFAULT NULL,
  `LAST_UPDATED` datetime DEFAULT NULL,
  `JOB_CONFIGURATION_LOCATION` varchar(2500) DEFAULT NULL,
  PRIMARY KEY (`JOB_EXECUTION_ID`),
  KEY `JOB_INST_EXEC_FK` (`JOB_INSTANCE_ID`),
  CONSTRAINT `JOB_INST_EXEC_FK` FOREIGN KEY (`JOB_INSTANCE_ID`) REFERENCES `batch_job_instance` (`JOB_INSTANCE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_job_execution`
--

LOCK TABLES `batch_job_execution` WRITE;
/*!40000 ALTER TABLE `batch_job_execution` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch_job_execution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_job_execution_context`
--

DROP TABLE IF EXISTS `batch_job_execution_context`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_job_execution_context` (
  `JOB_EXECUTION_ID` bigint(20) NOT NULL,
  `SHORT_CONTEXT` varchar(2500) NOT NULL,
  `SERIALIZED_CONTEXT` text,
  PRIMARY KEY (`JOB_EXECUTION_ID`),
  CONSTRAINT `JOB_EXEC_CTX_FK` FOREIGN KEY (`JOB_EXECUTION_ID`) REFERENCES `batch_job_execution` (`JOB_EXECUTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_job_execution_context`
--

LOCK TABLES `batch_job_execution_context` WRITE;
/*!40000 ALTER TABLE `batch_job_execution_context` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch_job_execution_context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_job_execution_params`
--

DROP TABLE IF EXISTS `batch_job_execution_params`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_job_execution_params` (
  `JOB_EXECUTION_ID` bigint(20) NOT NULL,
  `TYPE_CD` varchar(6) NOT NULL,
  `KEY_NAME` varchar(100) NOT NULL,
  `STRING_VAL` varchar(250) DEFAULT NULL,
  `DATE_VAL` datetime DEFAULT NULL,
  `LONG_VAL` bigint(20) DEFAULT NULL,
  `DOUBLE_VAL` double DEFAULT NULL,
  `IDENTIFYING` char(1) NOT NULL,
  KEY `JOB_EXEC_PARAMS_FK` (`JOB_EXECUTION_ID`),
  CONSTRAINT `JOB_EXEC_PARAMS_FK` FOREIGN KEY (`JOB_EXECUTION_ID`) REFERENCES `batch_job_execution` (`JOB_EXECUTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_job_execution_params`
--

LOCK TABLES `batch_job_execution_params` WRITE;
/*!40000 ALTER TABLE `batch_job_execution_params` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch_job_execution_params` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_job_execution_seq`
--

DROP TABLE IF EXISTS `batch_job_execution_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_job_execution_seq` (
  `ID` bigint(20) NOT NULL,
  `UNIQUE_KEY` char(1) NOT NULL,
  UNIQUE KEY `UNIQUE_KEY_UN` (`UNIQUE_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_job_execution_seq`
--

LOCK TABLES `batch_job_execution_seq` WRITE;
/*!40000 ALTER TABLE `batch_job_execution_seq` DISABLE KEYS */;
INSERT INTO `batch_job_execution_seq` VALUES (0,'0');
/*!40000 ALTER TABLE `batch_job_execution_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_job_instance`
--

DROP TABLE IF EXISTS `batch_job_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_job_instance` (
  `JOB_INSTANCE_ID` bigint(20) NOT NULL,
  `VERSION` bigint(20) DEFAULT NULL,
  `JOB_NAME` varchar(100) NOT NULL,
  `JOB_KEY` varchar(32) NOT NULL,
  PRIMARY KEY (`JOB_INSTANCE_ID`),
  UNIQUE KEY `JOB_INST_UN` (`JOB_NAME`,`JOB_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_job_instance`
--

LOCK TABLES `batch_job_instance` WRITE;
/*!40000 ALTER TABLE `batch_job_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch_job_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_job_seq`
--

DROP TABLE IF EXISTS `batch_job_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_job_seq` (
  `ID` bigint(20) NOT NULL,
  `UNIQUE_KEY` char(1) NOT NULL,
  UNIQUE KEY `UNIQUE_KEY_UN` (`UNIQUE_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_job_seq`
--

LOCK TABLES `batch_job_seq` WRITE;
/*!40000 ALTER TABLE `batch_job_seq` DISABLE KEYS */;
INSERT INTO `batch_job_seq` VALUES (0,'0');
/*!40000 ALTER TABLE `batch_job_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_step_execution`
--

DROP TABLE IF EXISTS `batch_step_execution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_step_execution` (
  `STEP_EXECUTION_ID` bigint(20) NOT NULL,
  `VERSION` bigint(20) NOT NULL,
  `STEP_NAME` varchar(100) NOT NULL,
  `JOB_EXECUTION_ID` bigint(20) NOT NULL,
  `START_TIME` datetime NOT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `COMMIT_COUNT` bigint(20) DEFAULT NULL,
  `READ_COUNT` bigint(20) DEFAULT NULL,
  `FILTER_COUNT` bigint(20) DEFAULT NULL,
  `WRITE_COUNT` bigint(20) DEFAULT NULL,
  `READ_SKIP_COUNT` bigint(20) DEFAULT NULL,
  `WRITE_SKIP_COUNT` bigint(20) DEFAULT NULL,
  `PROCESS_SKIP_COUNT` bigint(20) DEFAULT NULL,
  `ROLLBACK_COUNT` bigint(20) DEFAULT NULL,
  `EXIT_CODE` varchar(2500) DEFAULT NULL,
  `EXIT_MESSAGE` varchar(2500) DEFAULT NULL,
  `LAST_UPDATED` datetime DEFAULT NULL,
  PRIMARY KEY (`STEP_EXECUTION_ID`),
  KEY `JOB_EXEC_STEP_FK` (`JOB_EXECUTION_ID`),
  CONSTRAINT `JOB_EXEC_STEP_FK` FOREIGN KEY (`JOB_EXECUTION_ID`) REFERENCES `batch_job_execution` (`JOB_EXECUTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_step_execution`
--

LOCK TABLES `batch_step_execution` WRITE;
/*!40000 ALTER TABLE `batch_step_execution` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch_step_execution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_step_execution_context`
--

DROP TABLE IF EXISTS `batch_step_execution_context`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_step_execution_context` (
  `STEP_EXECUTION_ID` bigint(20) NOT NULL,
  `SHORT_CONTEXT` varchar(2500) NOT NULL,
  `SERIALIZED_CONTEXT` text,
  PRIMARY KEY (`STEP_EXECUTION_ID`),
  CONSTRAINT `STEP_EXEC_CTX_FK` FOREIGN KEY (`STEP_EXECUTION_ID`) REFERENCES `batch_step_execution` (`STEP_EXECUTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_step_execution_context`
--

LOCK TABLES `batch_step_execution_context` WRITE;
/*!40000 ALTER TABLE `batch_step_execution_context` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch_step_execution_context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_step_execution_seq`
--

DROP TABLE IF EXISTS `batch_step_execution_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_step_execution_seq` (
  `ID` bigint(20) NOT NULL,
  `UNIQUE_KEY` char(1) NOT NULL,
  UNIQUE KEY `UNIQUE_KEY_UN` (`UNIQUE_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_step_execution_seq`
--

LOCK TABLES `batch_step_execution_seq` WRITE;
/*!40000 ALTER TABLE `batch_step_execution_seq` DISABLE KEYS */;
INSERT INTO `batch_step_execution_seq` VALUES (0,'0');
/*!40000 ALTER TABLE `batch_step_execution_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_strategy_configuration_details`
--

DROP TABLE IF EXISTS `business_strategy_configuration_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_strategy_configuration_details` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `revenue_name` varchar(250) NOT NULL,
  `month_name` varchar(250) NOT NULL,
  `monthly_target` double NOT NULL,
  `quaterly_target` double NOT NULL,
  `yearly_target` double NOT NULL,
  `draft` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=337 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_strategy_configuration_details`
--

LOCK TABLES `business_strategy_configuration_details` WRITE;
/*!40000 ALTER TABLE `business_strategy_configuration_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `business_strategy_configuration_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `continent`
--

DROP TABLE IF EXISTS `continent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `continent` (
  `id` int(11) NOT NULL,
  `continent_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `continent`
--

LOCK TABLES `continent` WRITE;
/*!40000 ALTER TABLE `continent` DISABLE KEYS */;
INSERT INTO `continent` VALUES (1,'Africa'),(2,'Antarctica'),(3,'Asia'),(4,'Australia'),(5,'Europe'),(6,'North America'),(7,'South America');
/*!40000 ALTER TABLE `continent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(50) NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `continent_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `3_geo_id` int(11) NOT NULL,
  `4_geo_id` int(11) NOT NULL,
  `is_selected` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_continent_id` (`continent_id`),
  KEY `fk_country_region_id` (`region_id`),
  KEY `fk_3_geo_id` (`3_geo_id`),
  KEY `fk_4_geo_id` (`4_geo_id`),
  CONSTRAINT `fk_3_geo_id` FOREIGN KEY (`3_geo_id`) REFERENCES `geo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_4_geo_id` FOREIGN KEY (`4_geo_id`) REFERENCES `geo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_continent_id` FOREIGN KEY (`continent_id`) REFERENCES `continent` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_country_region_id` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'AntiguaBarbuda',0,1,1,1,2,1),(2,'Argentina',0,1,1,1,2,1),(3,'Bahamas',0,1,1,1,2,1),(4,'Barbados',0,1,1,1,2,1),(5,'Belize',0,1,1,1,2,1),(6,'Bermuda',0,1,1,1,2,1),(7,'Bolivia',0,1,1,1,2,1),(8,'Brazil',0,1,1,1,2,1),(9,'Canada',0,1,1,1,2,1),(10,'Chile',0,1,1,1,2,1),(11,'Colombia',0,1,1,1,2,1),(12,'CostaRica',0,1,1,1,2,1),(13,'Cuba',0,1,1,1,2,1),(14,'Dominica',0,1,1,1,2,1),(15,'DominicanRepublic',0,1,1,1,2,1),(16,'Ecuador',0,1,1,1,2,1),(17,'ElSalvador',0,1,1,1,2,1),(18,'FrenchGuyana',0,1,1,1,2,1),(19,'Greenland',0,1,1,1,2,1),(20,'Grenada',0,1,1,1,2,1),(21,'Guadelupe',0,1,1,1,2,1),(22,'Guatemala',0,1,1,1,2,1),(23,'Guyana',0,1,1,1,2,1),(24,'Haiti',0,1,1,1,2,1),(25,'Honduras',0,1,1,1,2,1),(26,'Jamaica',0,1,1,1,2,1),(27,'Martinique',0,1,1,1,2,1),(28,'Mexico',0,1,1,1,2,1),(29,'NetherlandAntilles',0,1,1,1,2,1),(30,'Nicaragua',0,1,1,1,2,1),(31,'Panama',0,1,1,1,2,1),(32,'Paraguay',0,1,1,1,2,1),(33,'Peru',0,1,1,1,2,1),(34,'PuertoRico',0,1,1,1,2,1),(35,'St.Kitts&Nevis',0,1,1,1,2,1),(36,'Suriname',0,1,1,1,2,1),(37,'TrinidadandTobago',0,1,1,1,2,1),(38,'U.S.VirginIslands',0,1,1,1,2,1),(39,'UnitedStates',0,1,1,1,2,1),(40,'Uruguay',0,1,1,1,2,1),(41,'Venezuela',0,1,1,1,2,1),(42,'Albania',0,1,2,1,2,1),(43,'Algeria',0,1,2,1,2,1),(44,'Andorra',0,1,2,1,2,1),(45,'Angola',0,1,2,1,2,1),(46,'Austria',0,1,2,1,2,1),(47,'Bahrain',0,1,2,1,2,1),(48,'Belarus',0,1,2,1,2,1),(49,'Belgium',0,1,2,1,2,1),(50,'Benin',0,1,2,1,2,1),(51,'BosniaandHerzegovina',0,1,2,1,2,1),(52,'Botswana',0,1,2,1,2,1),(53,'Bulgaria',0,1,2,1,2,1),(54,'BurkinaFaso',0,1,2,1,2,1),(55,'Burundi',0,1,2,1,2,1),(56,'Cameroon',0,1,2,1,2,1),(57,'CapeVerde',0,1,2,1,2,1),(58,'CentralAfricanRepublic',0,1,2,1,2,1),(59,'Chad',0,1,2,1,2,1),(60,'Comoros',0,1,2,1,2,1),(61,'Croatia',0,1,2,1,2,1),(62,'Cyprus',0,1,2,1,2,1),(63,'CzechRepublic',0,1,2,1,2,1),(64,'DemocraticRepublicoftheCongo',0,1,2,1,2,1),(65,'Denmark',0,1,2,1,2,1),(66,'Djibouti',0,1,2,1,2,1),(67,'Egypt',0,1,2,1,2,1),(68,'EquatorialGuinea',0,1,2,1,2,1),(69,'Eritrea',0,1,2,1,2,1),(70,'Estonia',0,1,2,1,2,1),(71,'Ethiopia',0,1,2,1,2,1),(72,'FaroeIslands',0,1,2,1,2,1),(73,'Finland',0,1,2,1,2,1),(74,'France',0,1,2,1,2,1),(75,'Gabon',0,1,2,1,2,1),(76,'Gambia',0,1,2,1,2,1),(77,'Georgia',0,1,2,1,2,1),(78,'Germany',0,1,2,1,2,1),(79,'Ghana',0,1,2,1,2,1),(80,'Gibraltar',0,1,2,1,2,1),(81,'Greece',0,1,2,1,2,1),(82,'Guernsey',0,1,2,1,2,1),(83,'Guinea',0,1,2,1,2,1),(84,'Guinea-Bissau',0,1,2,1,2,1),(85,'Hungary',0,1,2,1,2,1),(86,'Iceland',0,1,2,1,2,1),(87,'Iran',0,1,2,1,2,1),(88,'Iraq',0,1,2,1,2,1),(89,'Ireland',0,1,2,1,2,1),(90,'IsleOfMan',0,1,2,1,2,1),(91,'Israel',0,1,2,1,2,1),(92,'Italy',0,1,2,1,2,1),(93,'IvoryCoast',0,1,2,1,2,1),(94,'Jersey',0,1,2,1,2,1),(95,'Jordan',0,1,2,1,2,1),(96,'Kenya',0,1,2,1,2,1),(97,'Kuwait',0,1,2,1,2,1),(98,'Latvia',0,1,2,1,2,1),(99,'Lebanon',0,1,2,1,2,1),(100,'Lesotho',0,1,2,1,2,1),(101,'Liberia',0,1,2,1,2,1),(102,'Libya',0,1,2,1,2,1),(103,'Liechtenstein',0,1,2,1,2,1),(104,'Lithuania',0,1,2,1,2,1),(105,'Luxembourg',0,1,2,1,2,1),(106,'Macedonia',0,1,2,1,2,1),(107,'Madagascar',0,1,2,1,2,1),(108,'Malawi',0,1,2,1,2,1),(109,'Mali',0,1,2,1,2,1),(110,'Malta',0,1,2,1,2,1),(111,'Mauritania',0,1,2,1,2,1),(112,'Mauritius',0,1,2,1,2,1),(113,'Moldova',0,1,2,1,2,1),(114,'Monaco',0,1,2,1,2,1),(115,'Montenegro',0,1,2,1,2,1),(116,'Morocco',0,1,2,1,2,1),(117,'Mozambique',0,1,2,1,2,1),(118,'Namibia',0,1,2,1,2,1),(119,'Netherlands',0,1,2,1,2,1),(120,'Niger',0,1,2,1,2,1),(121,'Nigeria',0,1,2,1,2,1),(122,'Norway',0,1,2,1,2,1),(123,'Oman',0,1,2,1,2,1),(124,'Palestine',0,1,2,1,2,1),(125,'Poland',0,1,2,1,2,1),(126,'Portugal',0,1,2,1,2,1),(127,'Qatar',0,1,2,1,2,1),(128,'Romania',0,1,2,1,2,1),(129,'Rwanda',0,1,2,1,2,1),(130,'SanMarino',0,1,2,1,2,1),(131,'SaoTome&Principe',0,1,2,1,2,1),(132,'SaudiArabia',0,1,2,1,2,1),(133,'Senegal',0,1,2,1,2,1),(134,'Serbia',0,1,2,1,2,1),(135,'Slovakia',0,1,2,1,2,1),(136,'Slovenia',0,1,2,1,2,1),(137,'Somalia',0,1,2,1,2,1),(138,'SouthAfrica',0,1,2,1,2,1),(139,'Spain',0,1,2,1,2,1),(140,'Sudan',0,1,2,1,2,1),(141,'Swaziland',0,1,2,1,2,1),(142,'Sweden',0,1,2,1,2,1),(143,'Switzerland',0,1,2,1,2,1),(144,'Syria',0,1,2,1,2,1),(145,'Tanzania',0,1,2,1,2,1),(146,'Togo',0,1,2,1,2,1),(147,'Tunisia',0,1,2,1,2,1),(148,'Turkey',0,1,2,1,2,1),(149,'Uganda',0,1,2,1,2,1),(150,'Ukraine',0,1,2,1,2,1),(151,'UnitedArabEmirates',0,1,2,1,2,1),(152,'UnitedKingdom',0,1,2,1,2,1),(153,'VaticanCity',0,1,2,1,2,1),(154,'WesternSahara',0,1,2,1,2,1),(155,'Yemen',0,1,2,1,2,1),(156,'Zambia',0,1,2,1,2,1),(157,'Zimbabwe(Rhodesia)',0,1,2,1,2,1),(158,'Afghanistan',0,1,3,1,2,1),(159,'AmericanSamoa',0,1,3,1,2,1),(160,'Australia',0,1,3,1,2,1),(161,'Bangladesh',0,1,3,1,2,1),(162,'Bhutan',0,1,3,1,2,1),(163,'Brunei',0,1,3,1,2,1),(164,'Cambodia',0,1,3,1,2,1),(165,'China',0,1,3,1,2,1),(166,'CookIslands',0,1,3,1,2,1),(167,'EastTimor',0,1,3,1,2,1),(168,'FederatedStatesofMicronesia',0,1,3,1,2,1),(169,'Fiji',0,1,3,1,2,1),(170,'FrenchPolynesia',0,1,3,1,2,1),(171,'Guam',0,1,3,1,2,1),(172,'HongKong(China)',0,1,3,1,2,1),(173,'India',0,1,3,1,2,1),(174,'Indonesia',0,1,3,1,2,1),(175,'Japan',0,1,3,1,2,1),(176,'Kiribati',0,1,3,1,2,1),(177,'Laos',0,1,3,1,2,1),(178,'Macau(China)',0,1,3,1,2,1),(179,'Malaysia',0,1,3,1,2,1),(180,'Maldives',0,1,3,1,2,1),(181,'MarshallIslands',0,1,3,1,2,1),(182,'Mongolia',0,1,3,1,2,1),(183,'Myanmar',0,1,3,1,2,1),(184,'Nauru',0,1,3,1,2,1),(185,'Nepal',0,1,3,1,2,1),(186,'NewCaledonia(associatemember)',0,1,3,1,2,1),(187,'NewZealand',0,1,3,1,2,1),(188,'Niue',0,1,3,1,2,1),(189,'NorthKorea',0,1,3,1,2,1),(190,'NorthernMarianaIslands',0,1,3,1,2,1),(191,'Pakistan',0,1,3,1,2,1),(192,'Palau',0,1,3,1,2,1),(193,'PapuaNewGuinea',0,1,3,1,2,1),(194,'Philippines',0,1,3,1,2,1),(195,'PitcairnIslands',0,1,3,1,2,1),(196,'Samoa',0,1,3,1,2,1),(197,'Singapore',0,1,3,1,2,1),(198,'SolomonIslands',0,1,3,1,2,1),(199,'SouthKorea',0,1,3,1,2,1),(200,'SriLanka',0,1,3,1,2,1),(201,'Taiwan',0,1,3,1,2,1),(202,'Thailand',0,1,3,1,2,1),(203,'Tokelau',0,1,3,1,2,1),(204,'Tonga',0,1,3,1,2,1),(205,'Tuvalu',0,1,3,1,2,1),(206,'Vanuatu',0,1,3,1,2,1),(207,'Vietnam',0,1,3,1,2,1),(208,'WallisandFutuna',0,1,3,1,2,1);
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_instance`
--

DROP TABLE IF EXISTS `crm_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_instance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `web_service_vendor_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_instance`
--

LOCK TABLES `crm_instance` WRITE;
/*!40000 ALTER TABLE `crm_instance` DISABLE KEYS */;
INSERT INTO `crm_instance` VALUES (1,'csv',NULL);
/*!40000 ALTER TABLE `crm_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_instance_sales_stage`
--

DROP TABLE IF EXISTS `crm_instance_sales_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_instance_sales_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crm_instance_id` int(11) NOT NULL,
  `sales_stage_name` varchar(128) NOT NULL,
  `local_crm_sales_stage_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_crm_instance_sales_stage_cssid` (`local_crm_sales_stage_id`),
  KEY `fk_crm_instance_sales_stage_ciid` (`crm_instance_id`),
  CONSTRAINT `fk_crm_instance_sales_stage_ciid` FOREIGN KEY (`crm_instance_id`) REFERENCES `crm_instance` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_crm_instance_sales_stage_cssid` FOREIGN KEY (`local_crm_sales_stage_id`) REFERENCES `local_crm_sales_stage` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_instance_sales_stage`
--

LOCK TABLES `crm_instance_sales_stage` WRITE;
/*!40000 ALTER TABLE `crm_instance_sales_stage` DISABLE KEYS */;
INSERT INTO `crm_instance_sales_stage` VALUES (1,1,'Closed Won',1),(2,1,'Closed Lost',2),(3,1,'Negotiation/Review',3),(4,1,'Proposal/Price Quote',3),(5,1,'Prospecting',4),(6,1,'Qualification',4),(7,1,'Needs Analysis',4),(8,1,'Value Proposition',4),(9,1,'Id. Decision Makers ',4),(10,1,'Perception Analysis ',4);
/*!40000 ALTER TABLE `crm_instance_sales_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(64) DEFAULT NULL,
  `currency_code` char(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_currency_name` (`currency_name`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES (1,'Andorran Peseta','ADP'),(2,'United Arab Emirates Dirham','AED'),(3,'Afghanistan Afghani','AFA'),(4,'Albanian Lek','ALL'),(5,'Netherlands Antillian Guilder','ANG'),(6,'Angolan Kwanza','AOK'),(7,'Argentine Peso','ARS'),(8,'Australian Dollar','AUD'),(9,'Aruban Florin','AWG'),(10,'Barbados Dollar','BBD'),(11,'Bangladeshi Taka','BDT'),(12,'Bulgarian Lev','BGN'),(13,'Bahraini Dinar','BHD'),(14,'Burundi Franc','BIF'),(15,'Bermudian Dollar','BMD'),(16,'Brunei Dollar','BND'),(17,'Bolivian Boliviano','BOB'),(18,'Brazilian Real','BRL'),(19,'Bahamian Dollar','BSD'),(20,'Bhutan Ngultrum','BTN'),(21,'Burma Kyat','BUK'),(22,'Botswanian Pula','BWP'),(23,'Belize Dollar','BZD'),(24,'Canadian Dollar','CAD'),(25,'Swiss Franc','CHF'),(26,'Chilean Unidades de Fomento','CLF'),(27,'Chilean Peso','CLP'),(28,'Yuan (Chinese) Renminbi','CNY'),(29,'Colombian Peso','COP'),(30,'Costa Rican Colon','CRC'),(31,'Czech Republic Koruna','CZK'),(32,'Cuban Peso','CUP'),(33,'Cape Verde Escudo','CVE'),(34,'Cyprus Pound','CYP'),(35,'Danish Krone','DKK'),(36,'Dominican Peso','DOP'),(37,'Algerian Dinar','DZD'),(38,'Ecuador Sucre','ECS'),(39,'Egyptian Pound','EGP'),(40,'Estonian Kroon (EEK)','EEK'),(41,'Ethiopian Birr','ETB'),(42,'Euro','EUR'),(43,'Fiji Dollar','FJD'),(44,'Falkland Islands Pound','FKP'),(45,'British Pound','GBP'),(46,'Ghanaian Cedi','GHC'),(47,'Gibraltar Pound','GIP'),(48,'Gambian Dalasi','GMD'),(49,'Guinea Franc','GNF'),(50,'Guatemalan Quetzal','GTQ'),(51,'Guinea-Bissau Peso','GWP'),(52,'Guyanan Dollar','GYD'),(53,'Hong Kong Dollar','HKD'),(54,'Honduran Lempira','HNL'),(55,'Haitian Gourde','HTG'),(56,'Hungarian Forint','HUF'),(57,'Indonesian Rupiah','IDR'),(58,'Irish Punt','IEP'),(59,'Israeli Shekel','ILS'),(60,'Indian Rupee','INR'),(61,'Iraqi Dinar','IQD'),(62,'Iranian Rial','IRR'),(63,'Jamaican Dollar','JMD'),(64,'Jordanian Dinar','JOD'),(65,'Japanese Yen','JPY'),(66,'Kenyan Schilling','KES'),(67,'Kampuchean (Cambodian) Riel','KHR'),(68,'Comoros Franc','KMF'),(69,'North Korean Won','KPW'),(70,'(South) Korean Won','KRW'),(71,'Kuwaiti Dinar','KWD'),(72,'Cayman Islands Dollar','KYD'),(73,'Lao Kip','LAK'),(74,'Lebanese Pound','LBP'),(75,'Sri Lanka Rupee','LKR'),(76,'Liberian Dollar','LRD'),(77,'Lesotho Loti','LSL'),(78,'Libyan Dinar','LYD'),(79,'Moroccan Dirham','MAD'),(80,'Malagasy Franc','MGF'),(81,'Mongolian Tugrik','MNT'),(82,'Macau Pataca','MOP'),(83,'Mauritanian Ouguiya','MRO'),(84,'Maltese Lira','MTL'),(85,'Mauritius Rupee','MUR'),(86,'Maldive Rufiyaa','MVR'),(87,'Malawi Kwacha','MWK'),(88,'Mexican Peso','MXP'),(89,'Malaysian Ringgit','MYR'),(90,'Mozambique Metical','MZM'),(91,'Namibian Dollar','NAD'),(92,'Nigerian Naira','NGN'),(93,'Nicaraguan Cordoba','NIO'),(94,'Norwegian Kroner','NOK'),(95,'Nepalese Rupee','NPR'),(96,'New Zealand Dollar','NZD'),(97,'Omani Rial','OMR'),(98,'Panamanian Balboa','PAB'),(99,'Peruvian Nuevo Sol','PEN'),(100,'Papua New Guinea Kina','PGK'),(101,'Philippine Peso','PHP'),(102,'Pakistan Rupee','PKR'),(103,'Polish Zloty','PLN'),(104,'Paraguay Guarani','PYG'),(105,'Qatari Rial','QAR'),(106,'Romanian Leu','RON'),(107,'Rwanda Franc','RWF'),(108,'Saudi Arabian Riyal','SAR'),(109,'Solomon Islands Dollar','SBD'),(110,'Seychelles Rupee','SCR'),(111,'Sudanese Pound','SDP'),(112,'Swedish Krona','SEK'),(113,'Singapore Dollar','SGD'),(114,'St. Helena Pound','SHP'),(115,'Sierra Leone Leone','SLL'),(116,'Somali Schilling','SOS'),(117,'Suriname Guilder','SRG'),(118,'Sao Tome and Principe Dobra','STD'),(119,'Russian Ruble','RUB'),(120,'El Salvador Colon','SVC'),(121,'Syrian Potmd','SYP'),(122,'Swaziland Lilangeni','SZL'),(123,'Thai Baht','THB'),(124,'Tunisian Dinar','TND'),(125,'Tongan Paanga','TOP'),(126,'East Timor Escudo','TPE'),(127,'Turkish Lira','TRY'),(128,'Trinidad and Tobago Dollar','TTD'),(129,'Taiwan Dollar','TWD'),(130,'Tanzanian Schilling','TZS'),(131,'Uganda Shilling','UGX'),(132,'US Dollar','USD'),(133,'Uruguayan Peso','UYU'),(134,'Venezualan Bolivar','VEF'),(135,'Vietnamese Dong','VND'),(136,'Vanuatu Vatu','VUV'),(137,'Samoan Tala','WST'),(138,'CommunautÃ© FinanciÃ¨re Africaine BEAC, Francs','XAF'),(139,'Silver, Ounces','XAG'),(140,'Gold, Ounces','XAU'),(141,'East Caribbean Dollar','XCD'),(142,'International Monetary Fund (IMF) Special Drawing Rights','XDR'),(143,'CommunautÃ© FinanciÃ¨re Africaine BCEAO - Francs','XOF'),(144,'Palladium Ounces','XPD'),(145,'Comptoirs FranÃ§ais du Pacifique Francs','XPF'),(146,'Platinum, Ounces','XPT'),(147,'Democratic Yemeni Dinar','YDD'),(148,'Yemeni Rial','YER'),(149,'New Yugoslavia Dinar','YUD'),(150,'South African Rand','ZAR'),(151,'Zambian Kwacha','ZMK'),(152,'Zaire Zaire','ZRZ'),(153,'Zimbabwe Dollar','ZWD'),(154,'Slovak Koruna','SKK'),(155,'Armenian Dram','AMD');
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_exchange_rates`
--

DROP TABLE IF EXISTS `currency_exchange_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency_exchange_rates` (
  `base_currency` varchar(5) NOT NULL,
  `quote_currency` varchar(5) NOT NULL,
  `exchange_rate` float NOT NULL,
  `symbol` varchar(10) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`symbol`,`date`),
  KEY `Date_index` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_exchange_rates`
--

LOCK TABLES `currency_exchange_rates` WRITE;
/*!40000 ALTER TABLE `currency_exchange_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `currency_exchange_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_view`
--

DROP TABLE IF EXISTS `dashboard_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_view` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `metadata` mediumtext,
  `filter` varchar(100) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dashboard_view_url_unique` (`url`,`filter`),
  KEY `FK_dashoard_view_created_by` (`created_by`),
  CONSTRAINT `FK_dashoard_view_created_by` FOREIGN KEY (`created_by`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_view`
--

LOCK TABLES `dashboard_view` WRITE;
/*!40000 ALTER TABLE `dashboard_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo`
--

DROP TABLE IF EXISTS `geo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo`
--

LOCK TABLES `geo` WRITE;
/*!40000 ALTER TABLE `geo` DISABLE KEYS */;
INSERT INTO `geo` VALUES (1,'3 Geo Setup'),(2,'4 Geo Setup');
/*!40000 ALTER TABLE `geo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_business_strategy`
--

DROP TABLE IF EXISTS `global_business_strategy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global_business_strategy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `total_revenue_target` double NOT NULL,
  `marketing_inf_revenue_target` double NOT NULL,
  `fiscal_start` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_business_strategy`
--

LOCK TABLES `global_business_strategy` WRITE;
/*!40000 ALTER TABLE `global_business_strategy` DISABLE KEYS */;
/*!40000 ALTER TABLE `global_business_strategy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `impact_indicator_history`
--

DROP TABLE IF EXISTS `impact_indicator_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impact_indicator_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indicator_name` varchar(64) NOT NULL,
  `value` decimal(15,0) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impact_indicator_history`
--

LOCK TABLES `impact_indicator_history` WRITE;
/*!40000 ALTER TABLE `impact_indicator_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `impact_indicator_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `impact_indicator_target`
--

DROP TABLE IF EXISTS `impact_indicator_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impact_indicator_target` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indicator_name` varchar(64) NOT NULL,
  `target_value` decimal(15,0) NOT NULL,
  `valid_from` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `valid_upto` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impact_indicator_target`
--

LOCK TABLES `impact_indicator_target` WRITE;
/*!40000 ALTER TABLE `impact_indicator_target` DISABLE KEYS */;
/*!40000 ALTER TABLE `impact_indicator_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `industry`
--

DROP TABLE IF EXISTS `industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `industry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `industry_name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_industry_name` (`industry_name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `industry`
--

LOCK TABLES `industry` WRITE;
/*!40000 ALTER TABLE `industry` DISABLE KEYS */;
INSERT INTO `industry` VALUES (1,'Consumer Goods and Services'),(2,'Energy'),(3,'Financials'),(4,'Government Agencies'),(5,'Healthcare'),(6,'High Technology'),(7,'Industrials'),(8,'Materials'),(9,'Retail'),(10,'Telecommunications'),(11,'Utilities');
/*!40000 ALTER TABLE `industry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_log`
--

DROP TABLE IF EXISTS `job_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_type` varchar(128) NOT NULL,
  `vendor_name` varchar(128) NOT NULL,
  `instance_name` varchar(128) NOT NULL DEFAULT '',
  `version` varchar(64) NOT NULL,
  `job_name` varchar(128) NOT NULL,
  `job_group_name` varchar(128) NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `finish_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` varchar(32) NOT NULL,
  `info` mediumtext,
  `fetch_from_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fetch_from` int(11) DEFAULT NULL,
  `fetch_size` int(11) DEFAULT NULL,
  `next_record_token` varchar(256) DEFAULT NULL,
  `succeeded_record_count` int(11) DEFAULT '0',
  `failed_records` mediumtext,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_log`
--

LOCK TABLES `job_log` WRITE;
/*!40000 ALTER TABLE `job_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_source`
--

DROP TABLE IF EXISTS `lead_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_source` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lead_source` varchar(64) NOT NULL,
  `opportunities` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_source`
--

LOCK TABLES `lead_source` WRITE;
/*!40000 ALTER TABLE `lead_source` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `local_crm_sales_stage`
--

DROP TABLE IF EXISTS `local_crm_sales_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `local_crm_sales_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stage` varchar(128) NOT NULL,
  `stage_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `local_crm_sales_stage`
--

LOCK TABLES `local_crm_sales_stage` WRITE;
/*!40000 ALTER TABLE `local_crm_sales_stage` DISABLE KEYS */;
INSERT INTO `local_crm_sales_stage` VALUES (1,'Closed Won','closedWon'),(2,'Closed Lost','closedLost'),(3,'Qualified Pipeline','qualifiedPipeline'),(4,'Others','others');
/*!40000 ALTER TABLE `local_crm_sales_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail_config`
--

DROP TABLE IF EXISTS `mail_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(128) NOT NULL,
  `attribute_value` text NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attribute_unique` (`attribute_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_config`
--

LOCK TABLES `mail_config` WRITE;
/*!40000 ALTER TABLE `mail_config` DISABLE KEYS */;
INSERT INTO `mail_config` VALUES (1,'mail.smtp.host','smtp.gmail.com','2016-02-14 21:35:36','2016-02-14 21:35:36'),(2,'mail.smtp.port','587','2016-02-14 21:35:36','2016-02-14 21:35:36'),(3,'mail.smtp.username','supraja.vattikundala@neevtech.com','2016-02-14 21:35:36','2016-02-14 21:35:36'),(4,'mail.smtp.password','Neevtech%899','2016-02-14 21:35:36','2016-02-17 21:13:20'),(5,'mail.smtp.from-address','team@phaladata.com','2016-02-14 21:35:36','2016-02-14 21:35:36'),(6,'mail.smtp.auth','true','2016-02-14 21:35:36','2016-02-14 21:35:36'),(7,'mail.smtp.starttls.enable','true','2016-02-14 21:35:36','2016-02-14 21:35:36'),(8,'admin.recipients','admin@phaladata.com','2016-02-14 21:35:36','2016-02-14 21:35:36');
/*!40000 ALTER TABLE `mail_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manual_campaign_input`
--

DROP TABLE IF EXISTS `manual_campaign_input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manual_campaign_input` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(64) DEFAULT NULL,
  `campaign_name` varchar(64) DEFAULT NULL,
  `parent_campaign_id` varchar(64) DEFAULT NULL,
  `parent_campaign_name` varchar(64) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `touch_point_label` varchar(64) DEFAULT NULL,
  `total_campaign_cost` double DEFAULT NULL,
  `new_campaign_name` varchar(64) DEFAULT NULL,
  `draft` tinyint(1) NOT NULL DEFAULT '0',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `editable_column` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaign_id_UNIQUE` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manual_campaign_input`
--

LOCK TABLES `manual_campaign_input` WRITE;
/*!40000 ALTER TABLE `manual_campaign_input` DISABLE KEYS */;
/*!40000 ALTER TABLE `manual_campaign_input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `miri_cis_interaction_config`
--

DROP TABLE IF EXISTS `miri_cis_interaction_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `miri_cis_interaction_config` (
  `id` int(11) DEFAULT NULL,
  `type` varchar(9) DEFAULT NULL,
  `action` varchar(13) DEFAULT NULL,
  `value` varchar(25) DEFAULT NULL,
  `app` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `miri_cis_interaction_config`
--

LOCK TABLES `miri_cis_interaction_config` WRITE;
/*!40000 ALTER TABLE `miri_cis_interaction_config` DISABLE KEYS */;
INSERT INTO `miri_cis_interaction_config` VALUES (1,'cache','cache-clear','/admin/cache/clear','miri'),(2,'cache','cache-disable','/admin/cache/disable','miri'),(3,'cache','cache-enable','/admin/cache/enable','miri'),(4,'es','clean-mapping','/es/clean-and-put-mapping','cis'),(5,'scheduler','run','/admin/scheduler/run','cis'),(6,'status','check','/status/check','cis'),(7,'scheduler','run','/admin/etl/run','cis'),(8,'scheduler','restart','/admin/etl/restart','cis'),(9,'scheduler','status','/admin/scheduler/status','cis');
/*!40000 ALTER TABLE `miri_cis_interaction_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `miri_metric_ref`
--

DROP TABLE IF EXISTS `miri_metric_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `miri_metric_ref` (
  `id` int(11) DEFAULT NULL,
  `category` varchar(9) DEFAULT NULL,
  `section` varchar(10) DEFAULT NULL,
  `item` varchar(16) DEFAULT NULL,
  `url` varchar(73) DEFAULT NULL,
  `filter` varchar(30) DEFAULT NULL,
  `subdrilldown` varchar(85) DEFAULT NULL,
  `timeframe` varchar(74) DEFAULT NULL,
  `charttype` varchar(19) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `miri_metric_ref`
--

LOCK TABLES `miri_metric_ref` WRITE;
/*!40000 ALTER TABLE `miri_metric_ref` DISABLE KEYS */;
INSERT INTO `miri_metric_ref` VALUES (1,'visualize','measure','MISG','/dashboard/visualize/measure/mi-sg-revenue-achieved','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(2,'visualize','measure','MISG','/dashboard/visualize/measure/mi-sg-revenue-achieved','marketing-influenced','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(3,'visualize','measure','MISG','/dashboard/visualize/measure/mi-sg-revenue-achieved','sales-generated','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(4,'visualize','measure','NBC','/dashboard/visualize/measure/new-business-closed','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','scatter'),(5,'visualize','measure','NBC','/dashboard/visualize/measure/new-business-closed','marketing-influenced','campaign,lead-source,competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','scatter'),(6,'visualize','measure','NBC','/dashboard/visualize/measure/new-business-closed','sales-generated','competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','scatter'),(7,'visualize','measure','LOO','/dashboard/visualize/measure/large-open-opportunities-pipeline','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnRotated'),(8,'visualize','measure','LOO','/dashboard/visualize/measure/large-open-opportunities-pipeline','marketing-influenced','sales-person,oppurtunity-stage,probability-close','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnRotated'),(9,'visualize','measure','LOO','/dashboard/visualize/measure/large-open-opportunities-pipeline','sales-generated','sales-person,oppurtunity-stage,probability-close','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnRotated'),(10,'visualize','measure','MISGP','/dashboard/visualize/measure/marketing-influence-sales-generated-pipeline','overall','N/A','N/A','stackedChart'),(11,'visualize','measure','MISGP','/dashboard/visualize/measure/marketing-influence-sales-generated-pipeline','marketing-influenced','oppurtunity-stage,probability-close','N/A','stackedChart'),(12,'visualize','measure','MISGP','/dashboard/visualize/measure/marketing-influence-sales-generated-pipeline','sales-generated','oppurtunity-stage,probability-close','N/A','stackedChart'),(13,'visualize','measure','CWR','/dashboard/visualize/measure/competitive-win-rate','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','pie'),(14,'visualize','measure','CWR','/dashboard/visualize/measure/competitive-win-rate','marketing-influenced','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','pie'),(15,'visualize','measure','CWR','/dashboard/visualize/measure/competitive-win-rate','sales-generated','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','pie'),(16,'visualize','understand','Top Customers','/dashboard/visualize/understand/top-customers-win','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicBar'),(17,'visualize','understand','Top Customers','/dashboard/visualize/understand/top-customers-win','marketing-influenced','campaign,competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicBar'),(18,'visualize','understand','Top Customers','/dashboard/visualize/understand/top-customers-win','sales-generated','competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicBar'),(19,'visualize','understand','Top Products','/dashboard/visualize/understand/top-products-by-revenue-achieved','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(20,'visualize','understand','Top Products','/dashboard/visualize/understand/top-products-by-revenue-achieved','marketing-influenced','campaign,competitor,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(21,'visualize','understand','Top Products','/dashboard/visualize/understand/top-products-by-revenue-achieved','sales-generated','competitor,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(22,'visualize','understand','Top countries','/dashboard/visualize/understand/top-regions-by-revenue-achieved','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','geo'),(23,'visualize','understand','Top countries','/dashboard/visualize/understand/top-regions-by-revenue-achieved','marketing-influenced','campaign,competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','geo'),(24,'visualize','understand','Top countries','/dashboard/visualize/understand/top-regions-by-revenue-achieved','sales-generated','competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','geo'),(25,'visualize','understand','Top Industries','/dashboard/visualize/understand/top-industry-by-revenue','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','barAction'),(26,'visualize','understand','Top Industries','/dashboard/visualize/understand/top-industry-by-revenue','marketing-influenced','campaign,competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','barAction'),(27,'visualize','understand','Top Industries','/dashboard/visualize/understand/top-industry-by-revenue','sales-generated','competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','barAction'),(28,'visualize','understand','Top Sales People','/dashboard/visualize/understand/top-sales-people-by-revenue-achieved','overall','campaign,competitive-win-rate,average-deal-size,average-sell-price,no-of-deals-closed','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','cloumnBasic'),(29,'visualize','Connect','ATR','/dashboard/visualize/connect/average-time-to-revenue','overall','N/A','N/A','spineIrregular'),(30,'visualize','Connect','ATR','/dashboard/visualize/connect/average-time-to-revenue','marketing-influenced','N/A','N/A','spineIrregular'),(31,'visualize','Connect','ATR','/dashboard/visualize/connect/average-time-to-revenue','sales-generated','N/A','N/A','spineIrregular'),(32,'visualize','Connect','LDC','/dashboard/visualize/connect/largest-deals-closed','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','bubbleChart'),(33,'visualize','Connect','LDC','/dashboard/visualize/connect/largest-deals-closed','marketing-influenced','campaign,lead-source,competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','bubbleChart'),(34,'visualize','Connect','LDC','/dashboard/visualize/connect/largest-deals-closed','sales-generated','competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','bubbleChart'),(35,'visualize','Connect','ROI','/dashboard/visualize/connect/marketing-spend-roi','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','combo'),(36,'visualize','Connect','BPC','/dashboard/visualize/connect/best-performing-campaigns','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(37,'analyze','Measure','WLTA','/dashboard/analyze/measure/win-loss-trend-analysis','campaign','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(38,'analyze','Measure','WLTA','/dashboard/analyze/measure/win-loss-trend-analysis','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(39,'analyze','Measure','WLTA','/dashboard/analyze/measure/win-loss-trend-analysis','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(40,'analyze','Measure','WLTA','/dashboard/analyze/measure/win-loss-trend-analysis','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(41,'analyze','Measure','WLTA','/dashboard/analyze/measure/win-loss-trend-analysis','new-or-existing','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(42,'analyze','Measure','WLTA','/dashboard/analyze/measure/win-loss-trend-analysis','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(43,'analyze','Measure','WLTA','/dashboard/analyze/measure/win-loss-trend-analysis','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(44,'analyze','Measure','WLTA','/dashboard/analyze/measure/win-loss-trend-analysis','region-or-country','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(45,'analyze','Measure','MCCPTA','/dashboard/analyze/measure/marketing-campaign-cost-performance','lead-to-opportunity-conversion','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','funnelChart'),(46,'analyze','Measure','MCCPTA','/dashboard/analyze/measure/marketing-campaign-cost-performance','opportunity-to-deal-conversion','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','funnelChart'),(47,'analyze','Measure','MCPTA','/dashboard/analyze/measure/marketing-campaign-cost-performance','average-cost-lead','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','lineLabels'),(48,'analyze','Measure','MCPTA','/dashboard/analyze/measure/marketing-campaign-cost-performance','average-cost-opportunity','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','lineLabels'),(49,'analyze','Measure','MCPTA','/dashboard/analyze/measure/marketing-campaign-cost-performance','average-cost-deal','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','lineLabels'),(50,'analyze','Measure','SRPTA','/dashboard/analyze/measure/sales-campaign-revenue-performance','new-or-existing','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(51,'analyze','Measure','SRPTA','/dashboard/analyze/measure/sales-campaign-revenue-performance','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(52,'analyze','Measure','SRPTA','/dashboard/analyze/measure/sales-campaign-revenue-performance','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(53,'analyze','Measure','SRPTA','/dashboard/analyze/measure/sales-campaign-revenue-performance','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(54,'analyze','Measure','SRPTA','/dashboard/analyze/measure/sales-campaign-revenue-performance','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(55,'analyze','Measure','SRPTA','/dashboard/analyze/measure/sales-campaign-revenue-performance','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(56,'analyze','Measure','SRPTA','/dashboard/analyze/measure/sales-campaign-revenue-performance','region','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(57,'analyze','Measure','MCRPTA','/dashboard/analyze/measure/marketing-campaign-revenue-performance','new-or-existing','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(58,'analyze','Measure','MCRPTA','/dashboard/analyze/measure/marketing-campaign-revenue-performance','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(59,'analyze','Measure','MCRPTA','/dashboard/analyze/measure/marketing-campaign-revenue-performance','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(60,'analyze','Measure','MCRPTA','/dashboard/analyze/measure/marketing-campaign-revenue-performance','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(61,'analyze','Measure','MCRPTA','/dashboard/analyze/measure/marketing-campaign-revenue-performance','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(62,'analyze','Measure','MCRPTA','/dashboard/analyze/measure/marketing-campaign-revenue-performance','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(63,'analyze','Measure','MCRPTA','/dashboard/analyze/measure/marketing-campaign-revenue-performance','region','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(64,'analyze','Understand','PATA','/dashboard/analyze/understand/product-adoption-trend-analysis','region','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(65,'analyze','Understand','PATA','/dashboard/analyze/understand/product-adoption-trend-analysis','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(66,'analyze','Understand','PATA','/dashboard/analyze/understand/product-adoption-trend-analysis','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(67,'analyze','Understand','PATA','/dashboard/analyze/understand/product-adoption-trend-analysis','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(68,'analyze','Understand','PATA','/dashboard/analyze/understand/product-adoption-trend-analysis','campaign','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(69,'analyze','Understand','PATA','/dashboard/analyze/understand/product-adoption-trend-analysis','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(70,'analyze','Understand','PATA','/dashboard/analyze/understand/product-adoption-trend-analysis','new-or-existing','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(71,'analyze','Understand','PATA','/dashboard/analyze/understand/product-adoption-trend-analysis','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(72,'analyze','Understand','PTA','/dashboard/analyze/understand/pricing-trend-analysis','region','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(73,'analyze','Understand','PTA','/dashboard/analyze/understand/pricing-trend-analysis','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(74,'analyze','Understand','PTA','/dashboard/analyze/understand/pricing-trend-analysis','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(75,'analyze','Understand','PTA','/dashboard/analyze/understand/pricing-trend-analysis','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(76,'analyze','Understand','PTA','/dashboard/analyze/understand/pricing-trend-analysis','campaign','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(77,'analyze','Understand','PTA','/dashboard/analyze/understand/pricing-trend-analysis','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(78,'analyze','Understand','PTA','/dashboard/analyze/understand/pricing-trend-analysis','new-or-existing','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(79,'analyze','Understand','PTA','/dashboard/analyze/understand/pricing-trend-analysis','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(80,'analyze','Understand','RTM','/dashboard/analyze/understand/rtm-success-trend-analysis','region','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(81,'analyze','Understand','RTM','/dashboard/analyze/understand/rtm-success-trend-analysis','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(82,'analyze','Understand','RTM','/dashboard/analyze/understand/rtm-success-trend-analysis','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(83,'analyze','Understand','RTM','/dashboard/analyze/understand/rtm-success-trend-analysis','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(84,'analyze','Understand','RTM','/dashboard/analyze/understand/rtm-success-trend-analysis','campaign','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(85,'analyze','Understand','RTM','/dashboard/analyze/understand/rtm-success-trend-analysis','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(86,'analyze','Understand','RTM','/dashboard/analyze/understand/rtm-success-trend-analysis','new-or-existing','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(87,'analyze','Understand','RTM','/dashboard/analyze/understand/rtm-success-trend-analysis','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(88,'analyze','Understand','RTM','/dashboard/analyze/understand/route-to-market','partner','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(89,'analyze','Connect','BJTA','/dashboard/analyze/connect/buyers-journey-trend-analysis','overall','N/A','N/A','splineIrregularTime'),(90,'analyze','Connect','BJTA','/dashboard/analyze/connect/buyers-journey-trend-analysis','campaign','N/A','N/A','splineIrregularTime'),(91,'analyze','Connect','BJTA','/dashboard/analyze/connect/buyers-journey-trend-analysis','customers','N/A','N/A','splineIrregularTime'),(92,'analyze','Connect','BJTA','/dashboard/analyze/connect/buyers-journey-trend-analysis','competitor','N/A','N/A','splineIrregularTime'),(93,'analyze','Connect','BJTA','/dashboard/analyze/connect/buyers-journey-trend-analysis','product','N/A','N/A','splineIrregularTime'),(94,'analyze','Connect','BJTA','/dashboard/analyze/connect/buyers-journey-trend-analysis','sales-person','N/A','N/A','splineIrregularTime'),(95,'analyze','Connect','CVTA','/dashboard/analyze/connect/customers-life-time-value-trend-analysis','overall','N/A','N/A','splineIrregularTime'),(96,'analyze','Connect','CVTA','/dashboard/analyze/connect/customers-life-time-value-trend-analysis','campaign','N/A','N/A','splineIrregularTime'),(97,'analyze','Connect','CVTA','/dashboard/analyze/connect/customers-life-time-value-trend-analysis','competitor','N/A','N/A','splineIrregularTime'),(98,'analyze','Connect','CVTA','/dashboard/analyze/connect/customers-life-time-value-trend-analysis','industry','N/A','N/A','splineIrregularTime'),(99,'analyze','Connect','CVTA','/dashboard/analyze/connect/customers-life-time-value-trend-analysis','product','N/A','N/A','splineIrregularTime'),(100,'analyze','Connect','CVTA','/dashboard/analyze/connect/customers-life-time-value-trend-analysis','sales-person','N/A','N/A','splineIrregularTime'),(101,'analyze','Connect','CVTA','/dashboard/analyze/connect/customers-life-time-value-trend-analysis','region-or-country','N/A','N/A','splineIrregularTime'),(102,'analyze','Connect','DTTA','/dashboard/analyze/connect/demand-triggers-trend-analysis','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud'),(103,'analyze','Connect','DTTA','/dashboard/analyze/connect/demand-triggers-trend-analysis','campaign','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud'),(104,'analyze','Connect','DTTA','/dashboard/analyze/connect/demand-triggers-trend-analysis','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud'),(105,'analyze','Connect','DTTA','/dashboard/analyze/connect/demand-triggers-trend-analysis','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud'),(106,'analyze','Connect','DTTA','/dashboard/analyze/connect/demand-triggers-trend-analysis','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud'),(107,'analyze','Connect','DTTA','/dashboard/analyze/connect/demand-triggers-trend-analysis','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud'),(108,'analyze','Connect','DTTA','/dashboard/analyze/connect/demand-triggers-trend-analysis','region-or-country','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud');
/*!40000 ALTER TABLE `miri_metric_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persistent_login`
--

DROP TABLE IF EXISTS `persistent_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `persistent_login` (
  `username` varchar(64) NOT NULL,
  `series` varchar(64) NOT NULL,
  `token` varchar(64) NOT NULL,
  `last_used` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`series`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persistent_login`
--

LOCK TABLES `persistent_login` WRITE;
/*!40000 ALTER TABLE `persistent_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `persistent_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` VALUES (1,'AMS'),(2,'EMEA'),(3,'APJ'),(4,'Japan');
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region_country`
--

DROP TABLE IF EXISTS `region_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region_country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_region_country_region_id` (`region_id`),
  KEY `fk_country_id` (`country_id`),
  CONSTRAINT `fk_country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_region_id` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region_country`
--

LOCK TABLES `region_country` WRITE;
/*!40000 ALTER TABLE `region_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `region_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_search`
--

DROP TABLE IF EXISTS `saved_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saved_search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `search_key` varchar(100) NOT NULL,
  `columns` mediumtext,
  `start_page_no` int(11) NOT NULL,
  `current_page_no` int(11) NOT NULL,
  `page_size` int(11) NOT NULL,
  `filters` varchar(255) DEFAULT NULL,
  `sort_on_doc` varchar(50) DEFAULT NULL,
  `sort_on_field` varchar(50) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_saved_search_created_by` (`created_by`),
  CONSTRAINT `FK_saved_search_created_by` FOREIGN KEY (`created_by`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_search`
--

LOCK TABLES `saved_search` WRITE;
/*!40000 ALTER TABLE `saved_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `saved_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `touch_point`
--

DROP TABLE IF EXISTS `touch_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `touch_point` (
  `touch_point_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `leads_associated` mediumtext,
  `touchpoint_date` datetime DEFAULT NULL,
  `touch_point_name` varchar(255) DEFAULT NULL,
  `unique_combinations` mediumtext,
  `touch_point_campaign_id` bigint(20) NOT NULL,
  `opportunities` mediumtext,
  PRIMARY KEY (`touch_point_id`),
  KEY `FK_q7gso4s0kvey4h4caw0h6tub9` (`touch_point_campaign_id`),
  CONSTRAINT `FK_q7gso4s0kvey4h4caw0h6tub9` FOREIGN KEY (`touch_point_campaign_id`) REFERENCES `touch_point_campaigns` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `touch_point`
--

LOCK TABLES `touch_point` WRITE;
/*!40000 ALTER TABLE `touch_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `touch_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `touch_point_campaigns`
--

DROP TABLE IF EXISTS `touch_point_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `touch_point_campaigns` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(255) DEFAULT NULL,
  `campaign_name` varchar(255) DEFAULT NULL,
  `last_run` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `touch_point_campaigns`
--

LOCK TABLES `touch_point_campaigns` WRITE;
/*!40000 ALTER TABLE `touch_point_campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `touch_point_campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_authority`
--

DROP TABLE IF EXISTS `user_authority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_authority` (
  `username` varchar(100) NOT NULL,
  `authority_name` varchar(50) NOT NULL,
  PRIMARY KEY (`username`,`authority_name`),
  KEY `FK_tnnyxjpcvg2aj0d0i6ufnabm2` (`authority_name`),
  CONSTRAINT `FK_h5t8nplqarkfi7tscc9unyr7y` FOREIGN KEY (`username`) REFERENCES `user_info` (`username`),
  CONSTRAINT `FK_tnnyxjpcvg2aj0d0i6ufnabm2` FOREIGN KEY (`authority_name`) REFERENCES `authority` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_authority`
--

LOCK TABLES `user_authority` WRITE;
/*!40000 ALTER TABLE `user_authority` DISABLE KEYS */;
INSERT INTO `user_authority` VALUES ('admin@phaladata.com','ROLE_ADMIN'),('exec@phaladata.com','ROLE_EXECUTIVE'),('master@phaladata.com','ROLE_MASTER'),('guest@phaladata.com','ROLE_USER');
/*!40000 ALTER TABLE `user_authority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_info` (
  `username` varchar(100) NOT NULL,
  `active` bit(1) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `profile_pic` longblob,
  `background_img` varchar(64) DEFAULT NULL,
  `designation` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_info`
--

LOCK TABLES `user_info` WRITE;
/*!40000 ALTER TABLE `user_info` DISABLE KEYS */;
INSERT INTO `user_info` VALUES ('admin@phaladata.com','','supraja','v','$2a$10$QqfMJQXMkgtTuaYxb9JPvew1tB9DOiUTNzUiEeXMDgcDaAfrDKnVy','324435454324','img1',NULL),('exec@phaladata.com','','Executive','User','$2a$10$E2PSxeWK79SKFNXp4SZ6C.qPN3vQZ4W4.QMFi7TpovSAFpoteyWu2',NULL,NULL,NULL),('guest@phaladata.com','','Guest','Guest','$2a$10$E2PSxeWK79SKFNXp4SZ6C.qPN3vQZ4W4.QMFi7TpovSAFpoteyWu2','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQMAAADCCAMAAAB6zFdcAAAAxlBMVEX///8AdboAdbsAb7Obx98Acrn//v8AbK/h9fzw/f/A4e0rgrsQeLT6//8AbLFVl8HA3e6It9Su0d2t0OSdydk1iL0Aa6wAcbnr/P8Aba0AdrgAaa4AcK3i9fxEjr7n+v6gzOXK6PW23O1vqcsee7FWm8V2vNhkpM5ZmcjA2eXN6/M3jMF4sc9SlLxwosRIjbiSwt615vkOfLnV8PsAYaAAYqRZk7Oixtd1uN0AcaeBxuXo9frP8fyNtMtrnromeahAmdFLptvmB4OwAAAJKklEQVR4nO2cC3ubOBaGjYiMsUHUdW3MJb573eYyceuZaTrZndn9/39qJXE1SAKcpIaZ8z6pnyZG4ujjIB0dCXo9AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAvx39/rUtAIBWwO6EwSD97z8Ue7KzVva1rbgqp72BtcA5XduON6BR995PHd++sXSkaUgPb+z4m0sNuKSEqFDxb/bt7eB2IOF2OTftC504PtHdItCwpvmapgWLdY1yzCAhcjteJOa/5GxhxywHtz07+2vK8IelYDeaPu23x8l62VgJrsF8HFIBqBvwf653NCtLfQzFpoQfZGXMKTVUVOT3nNH/2YV/Pf/YzSezP8saEOaoYjSEKa7rklm42E5ODXToMw3szZRocfsR+9CCqbQlCR8DoTlaINdghLGoiOvkDf4azv/t+cOtL9DA0KrwaSOQphNrcRzU16DXW249HCuQgLC3nVdoQMRWEJUGwhJUg9yd/yE0Tz/++7z435+l/mBICmYWYF/5fuQqLgn3mxrOwM9hTyxSrIn9kN0mdhOZBmJrVBqIG4DP/GDjUQ3+8BfPv5cqqOEHeXRjUUeFaEBMLDuzEGNju1QU/Bg010DsBwUNfjVPv3797Xks0kDhBAJ8zLv3inHKPIZiu7ggxJooNHize+Fcg9vv9sv3l++n9ZfyvdDMD3jd3oOie2cnWC8kFzNuzvRLduzP0kBBYw1Y48jiJG0D7QufPT2KCMSmeWPVCPn+GpSsbqQBSpqGrY2sejYgyp0AYcNRR0pt94Nc27yVuL5BMiCKddCtQphUuiht1yDv38aNoDY6IOqqCoL9KXes8J5ouwZ50Oy8c+dpAmdWCjb4r0w8hHQrHlf5sXuDTIfxbzlv6JIGtG8r9Al0QHRF8ZYffxq5EJEeS2eTeDYuRY2d0oB2jCx0Ti/hekHkAaePyDSSjB//ITnWmBY7125pgHQnu6GXD7PYEr9sEZ1thLmbn/abWhQ4U1fwClFjtzSgV/GYVMMHRJ9e7pInoDR1wDyA/Zvson4zOjZ1kC5qwK6jF3Xzg4MRmSEOjHSLp5Ciu+bkBDjJKPhRPUHeFTqlAcPd25UDIg722ZTbPFpu/PfIC/invstcoVUa8FlzFhqKMTbswgq7wnSuPElNoTGk8FiEZ4dEp0vmzu+qQdYWSRv1hXyGyBTEwTZuXJ8nVaQOk0rVJg2wq+sYS9uXoOvKGeJ95uTmKk6qlArwCIr8dWqdBqPD4bD/PPKIK2skSm5n2c3ihrkQ6LQn1FRcroz3j3j2EAcb75VDuUADd8y+tc3T6olUOoMQRJ6yGaLJEszRaIAEkhGeducDRzv6xKir5hows8zNTtXty7xE926yqGhIwwdp74r0fM79Uys00HIacJaO8qYvQ9tKcgPi4BAIrfR5rdhwskPn41BS59XuheQse8nFkXE2IK52qqRKYeyUnujKGvR7gylWZuALJ/e22ZVdO4agI+TNzw6NQ8iDIT/Ltf2AZef9+hrcD9Ny87GHFWEWWeTGThpCKk5xfQ3sg4tEHbrw3Pd3vEyf+bYulw7h/GSSTb2TwbadGvSGTbpFI4oLBlteuUQ7FDh3afV06s0HH/lJWqCBOW0SJdD5sG2v6PRIFmjTATHdmtJnG1UqO90WaNB7cMUHSpgdPtMB0ZddV2zkuk3ZrOuMNmgwqT888nhQF44GUWyNg1G2ammOLcnAcUYbNBgGNRXgreRBMRL0cGzhASfziL58Ol2iDRqsZ/UlUIKC3DxisCU1I4+ra9BvpgGSjXHoPLFm3oSubEWqyNU1YAcG8rG7hJ+0uGRXPrFWFRKc0QYNGvSJAlAkizHK4sLBdlanL0y4vgb93rjZ2Chk9pw6gT0ZkWS/Wi2ur0HPfmpy0UQgktufeOcEDdrPaIEGJ3nqtBZIC7NEiTlOVibry9ACDditUHPOJMb/mta1mWbpuQ7dC0uroeuWseLc2mDLFpqQfOwQ8/M1QOca2FuC0OtuBpYsGLIM+w9VlkAKurof3ESTYNGB9XMrCM+2m8WsKh6QRFcX7VN9Ow3so6ewrh6IB4+6eCaVOwjL8hRvpkH5GYQaGgwOlSN5tTpZSCwPo+lPcPiXJJFPhkXTqzTA+1fuzYs1sOebbahMITUJG1D6If6a7CbS9QVt8fj46OR5dB4ff7HlGqBv9JhCGcd5+lISRb7W9pkxDWfqrtD/VjfJpl6XY9LwjcyfxIl4X3NxGXdkyjVga6blIkF5n7BIg+iJBl4+WUHP7c88P8vn5daoOWAkGw5knV60S03iBxKhp0oNBPvDEKmnQQPIKt2HcyGxtumGJem9IAKrNRDxxhogDe9ueywpHGIk7exqYaRziY5pQCuMR4+1Q2OouusP5/C9KtYqnUt0SwNqvcU3U/V5Rki5SVdJPq/SMQ3o9VtlFdEo4rJgmozO9uZ1SwN0HpDbG9X6sgwaPye+1EUNcFh4zG3+4DV1BWNRDP+6ogEPF5BRfo5jeF9vsYCPpTQE8Y6lPdtd0UBjrTBuBM/ymEf2dHO9DBESPtLSJQ2MsV3SgP1+2geV2Ve+DOWGfEAs1tEhDYyjbHLO+sYKL/B5Xyh+aLYzGmDvRnAJE1egUwhlsIAwMnbih8K6o4H7bah+zHO4UD46ir2HeSZZpzSIN1Tg2b7y2e/kQVfeO6J8DfRXci/Nh7Reg6gZZFfr3SbR3ty0VLpFE7mh8i0IkvyBmDfSoP4pEZscknBc8wUAdrRHO6o+VQDnH+8Ta9CgQW/oB/XiGpbpsWopEN/lyy1fr0+ea2NnIZUvyKmvAbpAA/81GiDsktD5VPECh6IQw2m2XZ8Z6h2W2XNNEg2arPEneaQGRUQa/EaITnQ5xHUJMTxreljlX8tS8yU1fP9xklcgoxrvTvgUKIwp2ka4BjtCVC04LyLIJ77c1GC1WQ+q3uYiY+2Q+GUa6YCo5K6OQSkT/jxVoyK3FzbkNZgrtvkQkUXl62BazqvedDY4zHT1gHh2mkbnileNftqb2C4+kb355Z3eFPb3fAvddVr1M86qHg9fW/N7l2gx8JJSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoIv8HxU4wkf1VwNCAAAAAElFTkSuQmCC',NULL,NULL),('master@phaladata.com','','Master','User456','$2a$10$E2PSxeWK79SKFNXp4SZ6C.qPN3vQZ4W4.QMFi7TpovSAFpoteyWu2',NULL,NULL,NULL);
/*!40000 ALTER TABLE `user_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_login_token`
--

DROP TABLE IF EXISTS `user_login_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_login_token` (
  `id` varchar(255) NOT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `user` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_nv6inptdyrxxwyap5fax7erin` (`user`),
  CONSTRAINT `FK_nv6inptdyrxxwyap5fax7erin` FOREIGN KEY (`user`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_login_token`
--

LOCK TABLES `user_login_token` WRITE;
/*!40000 ALTER TABLE `user_login_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_login_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_service_vendor`
--

DROP TABLE IF EXISTS `web_service_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_service_vendor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_type` varchar(128) NOT NULL,
  `vendor_name` varchar(128) NOT NULL,
  `instance_name` varchar(128) NOT NULL DEFAULT '',
  `version` varchar(32) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `draft` tinyint(1) NOT NULL DEFAULT '0',
  `connected` tinyint(1) NOT NULL DEFAULT '0',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendor_type_instance_name_unique` (`vendor_type`,`instance_name`,`vendor_name`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_service_vendor`
--

LOCK TABLES `web_service_vendor` WRITE;
/*!40000 ALTER TABLE `web_service_vendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `web_service_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_service_vendor_configuration_detail`
--

DROP TABLE IF EXISTS `web_service_vendor_configuration_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_service_vendor_configuration_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `web_service_vendor_id` int(11) NOT NULL,
  `attribute_name` varchar(128) NOT NULL,
  `attribute_value` varchar(256) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendor_attribute_unique` (`web_service_vendor_id`,`attribute_name`),
  CONSTRAINT `FK_web_service_vendor` FOREIGN KEY (`web_service_vendor_id`) REFERENCES `web_service_vendor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1682 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_service_vendor_configuration_detail`
--

LOCK TABLES `web_service_vendor_configuration_detail` WRITE;
/*!40000 ALTER TABLE `web_service_vendor_configuration_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `web_service_vendor_configuration_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_service_vendor_global_config`
--

DROP TABLE IF EXISTS `web_service_vendor_global_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_service_vendor_global_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(128) NOT NULL,
  `attribute_value` varchar(256) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendor_attribute_unique` (`attribute_name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_service_vendor_global_config`
--

LOCK TABLES `web_service_vendor_global_config` WRITE;
/*!40000 ALTER TABLE `web_service_vendor_global_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `web_service_vendor_global_config` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-02-18  2:49:12
