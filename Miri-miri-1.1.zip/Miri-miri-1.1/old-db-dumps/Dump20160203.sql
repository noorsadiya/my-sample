-- MySQL dump 10.13  Distrib 5.6.27, for Win64 (x86_64)
--
-- Host: localhost    Database: phaladata
-- ------------------------------------------------------
-- Server version	5.6.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(45) DEFAULT NULL,
  `business_unit` varchar(45) DEFAULT NULL,
  `address1` varchar(50) DEFAULT NULL,
  `address2` varchar(50) DEFAULT NULL,
  `address3` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zip_code` varchar(50) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `industry_id` int(11) DEFAULT NULL,
  `no_of_employees` int(11) DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `annual_revenue` double DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `logo` mediumblob,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fiscal_start` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `fk_account_country_id` (`country_id`),
  KEY `fk_account_industry_id` (`industry_id`),
  KEY `fk_account_currency_id` (`currency_id`),
  CONSTRAINT `fk_account_country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`),
  CONSTRAINT `fk_account_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`id`),
  CONSTRAINT `fk_account_industry_id` FOREIGN KEY (`industry_id`) REFERENCES `industry` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,'Razorfish','Bangalore','The Estate','Dickenson Road','Near Trinity Circle, M.G.Road','Bangalore','Karnataka','560066',104,1,121,60,1000000,'http://www.google.com','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAqsAAAGwCAYAAACO4iw0AAAYVGlDQ1BJQ0MgUHJvZmlsZQAAWAmtWWdUFE2z7tnZRM5RcpYgOYvkHEWyICw5hyWIiCR5UQGVJIogiGIABFQkqYgSRAQRUUAUFEQkiCRFRBRuL4b3O/fc79+dc2bmmerqmqrq6qmuHgC20ZLCw4MxjACEhEaRbY31BJycXQQIbwE1YAIMAAAakldkuK6NjQXE/+X4OggQStNzGYqs/8L038hM3j6RXgAgNpDB0zvSKwTiWwBg6b3CyVEA4NohXXh/VDgFT0PMSoYKQvyDgv22MB5qD1g9f2GRLR47W30A8GoAEGlJJLIfAPQGkC4Q4+UH5dB7wzbmUO+AUNgtFuJdXv4kSONuhDzSISFhFPweYgnP/5Dj9x+YRPL8K5NE8vuLf9kCe8IXGwREhgeTDmw9/H9eQoKjob+2DkF4pfUnm9jCOyv0W1FQmDkF00J8PdTTyhpiZojvBkCLfuNe/2gTe4gp/GNekfrQl4Ad4i/eJANziHkAwFBHB9nr/sZiJDJEW/wYvYAoU7vf2IEcZvtbPiYwNNiKEh9QDibe38f0D87xiTTcA+lQB0ygb4CRKcRwrDBX4/ztHCGGemIaYwIcrCCmh7g9MmgPRQeKnP44f30KfYuHHG1L0VkE0qd9yUYUGyEPShsSCdGWfFTIi7T1Lk5IV4rytzOBdNgXtfD2MTCEGL4XdfIJtf+tD+ofHqVHkUPhjwsP3opvqCea4xNsTKELQVwWGbPnT9+HUWQ7Ch36DR0MJJlR4hXqjM6GR9lQfELR5xuwAPrAAAiAaHh6gjAQCAJ65xrm4NOvFiNAAmTgB3yAzG/Knx6OWy2h8LoHxIFPIBTyRP7tp7fV6gNiIP3nX+qvvjLAd6s1ZqtHEPgA3xCC5cbuwmpiLeBVB54KWDWs+p9+Agx/9MQb4g3wJngj/PY/FOAFtQ6GJxkE/B80c9jmA60jw2voHxv+lYf7gHuGe4cbwI3hhoEDeL8l5bel7gEp5D8a/JVsCcagtF9e8YEeCwUzf3iwYlBrZaweVgvqD3XHsmO5gQxWCVqii9WGtilD6h/vUbSO/qvbv7784/c/fBStBf7Dxt90ekl65d9aeP6xCo7kH0/8byn/tgQAb8hl/r850aNoLdqJPkC70LtoAxBAW9BGtAdtpuDfOhttecfv79tstzwaBG0I+MMjVyk3I/fjz9NfW0mQQtGAMgYw/qN8YqNg/AH9sPAD5AA//ygBXfgV9hEwDfXaIS2gICevDADlm07hAeCz7da3GmF/+i+N3ATATi0Yvyv/0jy4AajNAoAp5F+aCAqnkSIAzY+9oskxv+RhKTcczBYMcGZwAT4gDCSgTQpABWgCHWAIzIA1sAPOYB/0uj8IgVrvB/EgGaSBDJAFToGzoARcBFdBFbgJGsBd8AA8BN2gDwyA1zA2JsFHsAi+gnUEQQgIHcKCcCH8iCgihSggasguxBCxQGwRZ8QD8UNCkWgkHjmMZCA5yFmkFClHbiBNyAOkC3mGDCPjyAyyjHzHoBhaDCuGFyOGkcWoYXQx5hg7jBvGDxOBicOkYk5gzmAuYK5h6jEPMN2YAcwY5iNmBQUoDcqOCqIyqBqqj1qjLqgvSkYT0HQ0H72AVqO34Vg/R8fQOXQNi8eyYAWwMjA+TbD2WC9sBDYBm4k9i72Krce2Y59jx7GL2A0cHY4HJ4XTwJninHB+uP24NFw+7jKuDtcB584k7isej2fHi+NV4dx0xgfiD+Iz8efwNfj7+Gf4CfwKgUDgIkgRtAjWBBIhipBGKCBcI7QQ+gmThG9EGiI/UYFoRHQhhhJTiPnECuI9Yj9xirhOxUglSqVBZU3lTXWA6iRVGdVtqqdUk1Tr1EzU4tRa1HbUgdTJ1Geoq6k7qEeoP9PQ0AjRqNPspgmgSaI5Q3Od5hHNOM0aLTOtJK0+rSttNO0J2iu092mHaT/T0dGJ0enQudBF0Z2gK6dro3tD942ehX4HvSm9N30ifSF9PX0//TwDFYMogy7DPoY4hnyGWoanDHOMVIxijPqMJMYExkLGJsYhxhUmFiZ5JmumEKZMpgqmLqZpZgKzGLMhszdzKvNF5jbmCRaURZhFn8WL5TBLGUsHyyQrnlWc1ZQ1kDWDtYq1l3WRjZlNic2BLZatkK2ZbYwdZRdjN2UPZj/JfpN9kP07By+HLocPxzGOao5+jlXObZw6nD6c6Zw1nAOc37kEuAy5griyuRq4Rrmx3JLcu7n3cxdzd3DPbWPdprnNa1v6tpvbXvFgeCR5bHkO8lzk6eFZ4eXjNeYN5y3gbeOd42Pn0+EL5Mvju8c3w8/Cv4s/gD+Pv4V/VoBNQFcgWOCMQLvAoiCPoIlgtGCpYK/gupC4kL1QilCN0KgwtbCasK9wnnCr8KIIv4ilSLxIpcgrUSpRNVF/0dOinaKrYuJijmJHxBrEpsU5xU3F48QrxUck6CS0JSIkLki82I7frrY9aPu57X2SGEllSX/JQsmnUhgpFakAqXNSz6Rx0urSodIXpIdkaGV0ZWJkKmXGd7DvsNiRsqNhx7ysiKyLbLZsp+yGnLJcsFyZ3Gt5Znkz+RT52/LLCpIKXgqFCi8U6RSNFBMVGxWXlKSUfJSKlV4qsyhbKh9RblX+qaKqQlapVplRFVH1UC1SHVJjVbNRy1R7pI5T11NPVL+rvqahohGlcVNjQVNGM0izQnN6p/hOn51lOye0hLRIWqVaY7sEdnnsOr9rTFtQm6R9QfudjrCOt85lnSnd7bqButd05/Xk9Mh6dXqr+hr6h/TvG6AGxgbpBr2GzIb2hmcN3xgJGfkZVRotGisbHzS+b4IzMTfJNhky5TX1Mi03XTRTNTtk1m5Oa77H/Kz5OwtJC7LFbUuMpZllruWIlahVqFWDNbA2tc61HrURt4mwubMbv9tmd+HuD7bytvG2nXtY9rjvqdjz1U7P7qTda3sJ+2j7VgcGB1eHcodVRwPHHMcxJ1mnQ07dztzOAc6NLgQXB5fLLit7Dfee2jvpquya5jroJu4W69a1j3tf8L5mdwZ3knutB87D0aPC4wfJmnSBtOJp6lnkueil73Xa66O3jnee94yPlk+Oz5Svlm+O77Sfll+u34y/tn++/1yAfsDZgKVAk8CSwNUg66ArQZvBjsE1IcQQj5CmUObQoND2ML6w2LBn4VLhaeFjERoRpyIWyebky5FIpFtkYxQrXDz3REtE/xM9HrMrpjDm236H/bWxTLGhsT0HJA8cOzAVZxR36SD2oNfB1njB+OT48UO6h0oTkATPhNZE4cTUxMkk46SrydTJQclPUuRSclK+HHY8fDuVNzUpdeIf438q0+jTyGlDRzSPlBzFHg042ntM8VjBsY107/THGXIZ+Rk/Mr0yHx+XP37m+OYJ3xO9J1VOFmfhs0KzBrO1s6/mMOXE5UzkWubW5wnkped9OeV+qitfKb/kNPXp6NNjZyzONBaIFGQV/Djrf3agUK+wpoin6FjR6jnvc/3FOsXVJbwlGSXfzwecf1lqXFp/QexC/kX8xZiLH8ocyjovqV0qv8x9OePyzyuhV8au2l5tL1ctL6/gqThZiamMrpy55nqtr8qgqrFaprq0hr0m4zq4Hn199obHjcGb5jdba9Vqq2+J3iqqY6lLr0fqD9QvNvg3jDU6Nz5rMmtqva15u+7OjjtX7greLWxmaz55j/pe6r3NlriWlfvh9+ce+D2YaHVvfd3m1PaifXd7b4d5x6OHRg/bOnU7Wx5pPbrbpdHV9FjtcUO3Snd9j3JP3RPlJ3W9Kr31T1WfNvap991+tvPZvX7t/gfPDZ4/fGH6onvAauDZoP3gyyHXobGX3i+nh4OHl17FvFp/nTSCG0kfZRzNf8Pz5sLb7W9rxlTGmscNxnve7Xn3esJr4uP7yPc/JlM/0H3In+KfKp9WmL47YzTTN7t3dvJj+Mf1ubRPTJ+K5iXmby3oLPQsOi1OLpGXNpczP3N9vvJF6Uvris3Km68hX9dX079xfbu6prbW+d3x+9T6/h+EH2d+bv95e8N8Y2QzZHMznEQmba0F4OoAYHx9AVi+AgCdMwAsfQBQ0/+qubY44BIDgTwQY+FqQQ64gFwwAnN5IjKOsccMo35YFFuHi8RrEGgJc8QRqh7qVpp22k66J/RDjIpMJSwsrMfYNjgSuFDuVB4m3lJ+ZYFHQr4iBNFK8T0SG5JV0q4ys7IBcrMKforjys4q3Wqq6iWayM69Wte1ER1r3Ty91wZ8hruNPIzDTJJMs80umtdZdFmOWi3bEHcL2Krtsbbztz/sUOLY4NTrPL0XceVyU9xn4e7tcZCU51np1eo97LPkR+3PGyAdqBZkFGwXQgoNCzsYfjQij1waeS2qKbo95tn+17FvDozHvT84FT9zaDZhLvFT0nzyfMr84fnUhX8W0j4dmT06fWwqfTrjY+bC8a8nNrOoszlyxHJV8kxP+eRnnr515lXBZqFQkf45UvGhkjPnb5R2XXh7ceUS1WXuK1JXNcpNKxwrva6FVR2oToERm3ej6GZZbcut0bq1BqZG0Sbl2zp3jO6aNBvd02lRvy/3QLnVpi2gPakj72FZZ82juq6Gx7e6q3vKnhT0pj+N6wt45thv8Fz+Bc8AfmB+cHDo7ssLw0de+b82GhEa2RwdedP0Nn8satz2ndwEw8Sn9z2TJR8CpxSmVqcbZsizErMvPybPic51fPL4tD5fumC68HmxZMli6cdy9WfSF44vvStHvqp9HVl1Xu37Zv3t+Vrgd5rv3etXfhT/rNp4urkJxx+FtRkPUAaOIAXUgy+IHlKEwWCiMMtoPJYZexsXDFc/s4Q64mEqJ2oVGiaaJToqeiUGD8YMpnvM31kV2KLZ73BSczlxX+Mh8PrwdQnsEMwVRkVCRfvE5SXSt7+X2imdLTMhu0MuUr5OYUFJTNlOJVm1Qq1P/bMm9U42Ld…KKrgg/t/woNJLP8g8IQn6CdRa7n7ZDm4/iipApnOnRDTHwCwtgMJ50HXVNZzXXrA3sPomo4nTcc7HzeMOdfJtu7n8YXnx2kZcebMVhpszss2DXpx+pVzf0EKo5UoUePrggLD0Rt1UlCwB/drw6Xb9riY4I/jRth0rihr79eD+h+9jjXD0zbpUGJhqoy0jMaKMQfweHRsJKe0RYVO3HOqu5H9+Q9lH03Ri6V1ueRmFCHYmYHqriQ8a/gk7+myQf626vw6qPjsKKoTo2WniHJc7ApJwPhfja8eks/5XpVK0JoSb6eUkx9pxgdH0/UXbsqZ7/igZH44d0tTrTYksMWWnLo810+HkrJ4rOuaqKxL+Rh4ZhYerUhd1Q/LGR1tc7BVwUZOMbbAczKP4wMui7LVu6JjkpZPAUClxMC7njtIJ6Ma8KrGbcTnzq3Z9qbe/DYrV11PKrFs2XEVzs+q4wDjGeJTkIQtLFBXgq8oToHMWlLpIwDkuNxoIiWCWkWqmh1RyQr4RpVxZcwB/veyZCvrW0oQWb8aBToEzGzoP2ZTp+X+mjhFwi0FgKHcmdg5PytTuSiMlYhb+4grOGyyym6xZeop/LwYSaTRw3Ie+YxzNxA/KBzU7cdRPKesZyvWpRLoSOw5aP/QmyQnrdDSY7WSXJUJmvFyr3bMej719H//mW6kmSvSl+N0Pg3HikJpSggeamaDLjH4i4c0clSlRaQidKy2/DnmNE4SoFq222HsnldQrLyyByhj26McacHmLfrrjCmjpI5xoyRmLlFNulTy59fcAQTrLovAzXiMn+K0wB8+AH9O4YqqRVFNVR9B+o3ZOGlj2spnjZCTR+qKaqh8YhSktUXLcGQ2Z9IyyqB4WrBsqLK3jr6+yOwrxquPQf2vEJ74T4iajvkpKhGJcTz2I1Pp2N5iflef60dwG/N9PV7jnR4YcIjELiEETDntX9D/mxVUQ1FelYmUqxyI1aMewKH6NgMM1689dr/gJ5/OjIjcHJaGC0F0ntA5EAkSjGQFVXFb9GFK0Hao2QJNig8W/TyX7iimpKRCTL/Q8id1wtFVUNL+C4QAg27l3FFNSr1YUweKcuVozlTsLzoB1O+8FQVeWeEA58880cnRTXKyoSjFbf2CdLxkCKX7GV4XJ2ICU3C1KwRpJCSq9uKkfPySNISj3I5qldUWaJyTF38Aez++h0bLFxxTO7pnMa/sqKqRrWMRYNTndU8SL6azAH8oYh98F0hurr0VKql1d+gB3hqFxVmK3tbU1QTxmHq+CQKTcXNkW1PUWXYCmWVoXAOLipjLSr370Pxm9rux41rCmFr/BKrdygErZko3v8OPtxdiHS1jC2rcZCdH6VziVmvYEfxHjwUG4oJ6w5ilmrmY6WZlOpvseKJmfhq2xyeYwB9pVZWr0PnXWv4jGrKC9vx4Tvv4Kv8BTzdytc+lhiaB7jxVOS3Dh035EWwQOCSQYDzWp+j2KAuVoycgRlTpmDarEylnqXYe6zZlBdfSjfairtrml4YWjFrXR52bn+QlE1dOI0PO4m/d2aP40QKS6rJb0NlRR0PC7spDQvzj2HvX5N5mPAIBC4MAjZ89HK2QjoVz82disenPcU/vNZ+WIaxJjKqsvqwTm7NkeRWZVkeBugraTuINRvUfp2K9XuP4MOCfSgv34Y4k01JVe+9jmIl/9Tn52HqlGl4PFUJ2LEJR5zkaCgW0YxiZelarcyqH/HvMRnQ10OWnd8iI1Zv/qavJPkTHsb6gkJs+lO4Byy+gDVjHd6bm6QQiKcNVt+ict2Yc7oynY9NsXowzNt1lpWoG0rQ5XqMmfUayquzEd0WbQCouUJZVbqZr4/775O/NsNuSeKMjNO/orH6iDT1z+gNeGAYwpjHLwL3ZdHUiOKUyRj5LfRhLJqehmhm5yaF+EP7FuwozdIowUpu7dHcxIwHZPeH6KsljyUyTqvPqSayG/LsWouO55JECoHA74iAjtccx77mH3rYMh0DY/ph2CRVSKt1dMOLarSXz6isBchIjkV4sF4IyeMDm0AJJ1v1KIWWPAtjwZAxqlQG1k5JQUxkHyzJK5NWZbwsViQTCJwTAr/yXDswdlAc+g8azZVGHK5GE0klLqO6ajKKh1F+ScaR0tSF06JPMB3PDXjqIQxWjpByt0H5rE6+rZw0FDExgzFPnQgiunpdDQmTkcaWvoMHIlWd7HFTD12VTL3TZv+FbFUjEE5Gr56xcCbhJNudo1p+041Nsh6gJG+hXQFX9pJnmlnSotlIjOmLxBm5qGU74tqga6M6+IX/pU7QpgdXR11bN9Xf9Kuahs5hq/uZJ1dDpYDwEKib/3kC1UMDQUs/kJ4OMyGQnFMGjdVUkmbP1qJjRluECQQuGQT0vOYkVUKRmNwTZ84oNaWNIoEqP6mVd8OLHWhDlScXqNoKGBOq40NgsLRkeFQXH5GejY+DbsScSUu4Ur32yQzcnrwPg1uYFNKREF6BwHkjEJWchECFMbqQ5lnX+QptAoVR55uqvChKx3MnvtfkobucerkEMqdLpC87iUWpHk2neqGzPiOvhwdNzR0v6mk5q8E8xiMWpMb/zGaHnL9JmX2fRMPPT6/Oc7KyRz826aNaaJdf2F0o3rsBC+fOwEZlf0z9lmexZOBgZKd7d1yYvqhL3e+k2lzqlb2U6lf49nY80v9eVPxjGf/qDLntevSM7CYtQxygyh5d+jyK0nMRf7aYlhzrlOqHoLMedd4ZtdZxFbMkHx+WxOHGa3rjSi2a+3pcFU3+Uun9rfX5GPX8CHy3db2uPv29snFrLTq8YsIjELgUEdDxmqX3TZxPkZCGrAVT0TesE93uVo/q70GzOEzi2LSZFR0v6r5HUfh+IYb4dcDyxbvOo8VOYlmiU1vyCX4MH4HN1eORPyMZT0jjRx2+ONaIwbShSziBwIVCQFOprBjz0Dyk39QLfo4mnKyux5Ux0aSLOa2/e10NS6TGc/UbJmPJ9Rvw4B1/wE/ffY8r+7HNV86ua49eFCDLt8RxtAL5YCJCSHbWnzwOR3ea+bTYQXv2PTvSX9Xv0AN7d+HQbV3RJzIcFr0cdkPFMxaUkScqx4b3ihBOx0r26q4rc8167BnyMKrWvO2mFArWjU3uEznHOGpLUFARjPnr9mHaoRzE3y9v6Pzfb3+khG1PWRVmAM6/v9dv9TuepWn3OGQs3cXzzBl/G+2siMX0p+KVsFJkDOqL/ndM4bMj6dnTEEPz/Fwh5blVTwCuYjwquVLMHHUvxr/9jRrg9AxPy8BkJaR+y2wMpKXCkU9vVUKsWPyft0p+17JU1pWTektHISweAoHLCgHX/k/Vt8TicdU0p2Q1RibG0VI78Wr87RietoX2LDNnzosRSfdKsezfgZwsDEuZwj8QWZir6slCfXE2FC6dgrF3xNG1lX0VRZXlj8et1wlF1RckRVpfEbAgfb66P6IcC8cNRX9rH/p4i8OwtBTkV7FtTc7O6/7OZKPKc0Ri7dPjkRg/GMPvT8cX0tq1s1yK+OMjfK9HMfEDW+a2Wmmp+44UjHnrsFQJM952CQvorJkjFNHmMeLXb1yb4dwo6c07LCLjBvG8xYsnY9ioPDRZeiBaDaUNYROpzgsNu/ZZtEtdlTxm4caw2oNb8MSkFFjp+nVVUWXZY6J7KFTa1kMoq63ye8Zj0bYSpCkH7Cdk5mLjCw9r9iRSGVZMW1WAl9LkL56OXZSCXWwA/JA2czNS1K2ElKyncemCf8mFY05ZIWYpuzXVpoTQzsD1xduQHCyHGMvqJH2xynEdpId3dFT64ikQuJwQMPZ/te6Dp2/D+oXjDHxKsVY7fpKEmTkv+oX/ERsXjlDJ0DMek2mnsuxOoF7OrMVzftWCJJ9ZuBTmh+7RVufEoXRr3bZXxe04zqiItwuAgIU2Je3btoyfjqEVQX2y2bDMfpVms8rTucg0ilH6egLxnKtsBE6dtsNFLtFej5fKClzkGyvn1itkIwAz3nYJ84vGc+syefXYSQHl3znPDvvzTHRWuS6lN1gExIzAS+N1/NqNYRKOmQXLtM1eRDPlqQWYrNjTdukqmwbwYg2YmYUbw5rRTVdT5qVTTeaSWYCiYxgiL/tXcc6qDz9hWc4kulZtl5RjVv5BTOoNNNJnZVBQkLltKd260djEjFjoSKogi3kaiZrZPwedLNBEB/dTXovnvA5bIxrP0k1ZnQIRZKGp23N0rUXnHIsX2QQCFx8BzqfEqcQ/FqdbrFh1zHlR5ZVOZHN6Hizntr0Ouw1NZ9m8lT+NMUZDOLfZRIRAoNUQsDU2SisF/mSbbWnVTk6ysVGWjZ0CLS3eSsUaw3nBS3loCoDDRvKYjuk/x7Z4wsJOMpixa6fAIF17qJ0NTbTJmuTyBbnQw056gnT9gqFcUwQu60AvrDYu6/ZdsMr/Rp3SzxIkH+DtrhS6ru3cO6gfLKQEe+ukurSCPGstOt7WW6QTCPzuCHjkU3NevNC84hdgkW+++d0BEhVorwj4IoN8w8g32dgqvOBH/OS9SHVpjicsAkgfcJ0monbqr+5yoXq+AQGkJ7iWer5UL8X8wgzAp19Fs6lRN/L6lF0kFggIBAQCAgGBgEBAICAQ8AkBYQbgC1y65ULnqX5fiIi0AgGBgEBAICAQEAgIBAQC3iIglFVvkRLpBAICAYGAQEAgIBAQCAgELjoCwgzgokMuChQICAQEAgIBgYBAQCAgEPAWAaGseouUSCcQEAgIBAQCAgGBgEBAIHDRERDK6kWHXBQoEBAICAQEAgIBgYBAQCDgLQJCWfUWKZFOICAQEAgIBAQCAgGBgEDgoiMglNWLDrkoUCAgEBAICAQEAgIBgYBAwFsEhLLqLVIinUBAICAQEAgIBAQCAgGBwEVHQCirFx1yUaBAQCAgEBAICAQEAgIBgYC3CAhl1VukRDqBgEBAICAQEAgIBAQCAoGLjoBQVi865KJAgYBAQCAgEBAICAQEAgIBbxH4/yz3BF0tiyPFAAAAAElFTkSuQmCC','2016-02-03 12:03:28','2016-02-03 12:08:27','2015-03-31 18:30:00');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authority`
--

DROP TABLE IF EXISTS `authority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authority` (
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authority`
--

LOCK TABLES `authority` WRITE;
/*!40000 ALTER TABLE `authority` DISABLE KEYS */;
INSERT INTO `authority` VALUES ('ROLE_ADMIN'),('ROLE_EXECUTIVE'),('ROLE_GUEST'),('ROLE_MASTER'),('ROLE_USER');
/*!40000 ALTER TABLE `authority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `continent`
--

DROP TABLE IF EXISTS `continent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `continent` (
  `id` int(11) NOT NULL,
  `continent_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `continent`
--

LOCK TABLES `continent` WRITE;
/*!40000 ALTER TABLE `continent` DISABLE KEYS */;
INSERT INTO `continent` VALUES (1,'Africa'),(2,'Antarctica'),(3,'Asia'),(4,'Australia'),(5,'Europe'),(6,'North America'),(7,'South America');
/*!40000 ALTER TABLE `continent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(50) NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `continent_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `3_geo_id` int(11) NOT NULL,
  `4_geo_id` int(11) NOT NULL,
  `is_selected` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_continent_id` (`continent_id`),
  KEY `fk_country_region_id` (`region_id`),
  KEY `fk_3_geo_id` (`3_geo_id`),
  KEY `fk_4_geo_id` (`4_geo_id`),
  CONSTRAINT `fk_3_geo_id` FOREIGN KEY (`3_geo_id`) REFERENCES `geo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_4_geo_id` FOREIGN KEY (`4_geo_id`) REFERENCES `geo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_continent_id` FOREIGN KEY (`continent_id`) REFERENCES `continent` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_country_region_id` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'Antigua Barbuda',0,1,1,1,2,1),(2,'Argentina',0,1,1,1,2,1),(3,'Bahamas',0,1,1,1,2,1),(4,'Barbados',0,1,1,1,2,1),(5,'Belize',0,1,1,1,2,1),(6,'Bermuda',0,1,1,1,2,1),(7,'Bolivia',0,1,1,1,2,1),(8,'Brazil',0,1,1,1,2,1),(9,'Canada',0,1,1,1,2,1),(10,'Chile',0,1,1,1,2,1),(11,'Colombia',0,1,1,1,2,1),(12,'Costa Rica',0,1,1,1,2,1),(13,'Cuba',0,1,1,1,2,1),(14,'Dominica',0,1,1,1,2,1),(15,'Dominican Republic',0,1,1,1,2,1),(16,'Ecuador',0,1,1,1,2,1),(17,'El Salvador',0,1,1,1,2,1),(18,'French Guyana',0,1,1,1,2,1),(19,'Greenland',0,1,1,1,2,1),(20,'Grenada',0,1,1,1,2,1),(21,'Guadelupe',0,1,1,1,2,1),(22,'Guatemala',0,1,1,1,2,1),(23,'Guyana',0,1,1,1,2,1),(24,'Haiti',0,1,1,1,2,1),(25,'Honduras',0,1,1,1,2,1),(26,'Jamaica',0,1,1,1,2,1),(27,'Martinique',0,1,1,1,2,1),(28,'Mexico',0,1,1,1,2,1),(29,'Netherland Antilles',0,1,1,1,2,1),(30,'Nicaragua',0,1,1,1,2,1),(31,'Panama',0,1,1,1,2,1),(32,'Paraguay',0,1,1,1,2,1),(33,'Peru',0,1,1,1,2,1),(34,'Puerto Rico',0,1,1,1,2,1),(35,'St. Kitts & Nevis',0,1,1,1,2,1),(36,'Suriname',0,1,1,1,2,1),(37,'Trinidad and Tobago',0,1,1,1,2,1),(38,'U.S. Virgin Islands',0,1,1,1,2,1),(39,'United States',0,1,1,1,2,1),(40,'Uruguay',0,1,1,1,2,1),(41,'Venezuela',0,1,1,1,2,1),(42,'Albania',0,1,2,1,2,1),(43,'Algeria',0,1,2,1,2,1),(44,'Andorra',0,1,2,1,2,1),(45,'Angola',0,1,2,1,2,1),(46,'Austria',0,1,2,1,2,1),(47,'Bahrain',0,1,2,1,2,1),(48,'Belarus',0,1,2,1,2,1),(49,'Belgium',0,1,2,1,2,1),(50,'Benin',0,1,2,1,2,1),(51,'Bosnia and Herzegovina',0,1,2,1,2,1),(52,'Botswana',0,1,2,1,2,1),(53,'Bulgaria',0,1,2,1,2,1),(54,'Burkina Faso',0,1,2,1,2,1),(55,'Burundi',0,1,2,1,2,1),(56,'Cameroon',0,1,2,1,2,1),(57,'Cape Verde',0,1,2,1,2,1),(58,'Central African Republic',0,1,2,1,2,1),(59,'Chad',0,1,2,1,2,1),(60,'Comoros',0,1,2,1,2,1),(61,'Croatia',0,1,2,1,2,1),(62,'Cyprus',0,1,2,1,2,1),(63,'Czech Republic',0,1,2,1,2,1),(64,'Democratic Republic of the Congo',0,1,2,1,2,1),(65,'Denmark',0,1,2,1,2,1),(66,'Djibouti',0,1,2,1,2,1),(67,'Egypt',0,1,2,1,2,1),(68,'Equatorial Guinea',0,1,2,1,2,1),(69,'Eritrea',0,1,2,1,2,1),(70,'Estonia',0,1,2,1,2,1),(71,'Ethiopia',0,1,2,1,2,1),(72,'Faroe Islands',0,1,2,1,2,1),(73,'Finland',0,1,2,1,2,1),(74,'France',0,1,2,1,2,1),(75,'Gabon',0,1,2,1,2,1),(76,'Gambia',0,1,2,1,2,1),(77,'Georgia',0,1,2,1,2,1),(78,'Germany',0,1,2,1,2,1),(79,'Ghana',0,1,2,1,2,1),(80,'Gibraltar',0,1,2,1,2,1),(81,'Greece',0,1,2,1,2,1),(82,'Guernsey',0,1,2,1,2,1),(83,'Guinea',0,1,2,1,2,1),(84,'Guinea-Bissau',0,1,2,1,2,1),(85,'Hungary',0,1,2,1,2,1),(86,'Iceland',0,1,2,1,2,1),(87,'Iran',0,1,2,1,2,1),(88,'Iraq',0,1,2,1,2,1),(89,'Ireland',0,1,2,1,2,1),(90,'Isle Of Man',0,1,2,1,2,1),(91,'Israel',0,1,2,1,2,1),(92,'Italy',0,1,2,1,2,1),(93,'Ivory Coast',0,1,2,1,2,1),(94,'Jersey',0,1,2,1,2,1),(95,'Jordan',0,1,2,1,2,1),(96,'Kenya',0,1,2,1,2,1),(97,'Kuwait',0,1,2,1,2,1),(98,'Latvia',0,1,2,1,2,1),(99,'Lebanon',0,1,2,1,2,1),(100,'Lesotho',0,1,2,1,2,1),(101,'Liberia',0,1,2,1,2,1),(102,'Libya',0,1,2,1,2,1),(103,'Liechtenstein',0,1,2,1,2,1),(104,'Lithuania',0,1,2,1,2,1),(105,'Luxembourg',0,1,2,1,2,1),(106,'Macedonia',0,1,2,1,2,1),(107,'Madagascar',0,1,2,1,2,1),(108,'Malawi',0,1,2,1,2,1),(109,'Mali',0,1,2,1,2,1),(110,'Malta',0,1,2,1,2,1),(111,'Mauritania',0,1,2,1,2,1),(112,'Mauritius',0,1,2,1,2,1),(113,'Moldova',0,1,2,1,2,1),(114,'Monaco',0,1,2,1,2,1),(115,'Montenegro',0,1,2,1,2,1),(116,'Morocco',0,1,2,1,2,1),(117,'Mozambique',0,1,2,1,2,1),(118,'Namibia',0,1,2,1,2,1),(119,'Netherlands',0,1,2,1,2,1),(120,'Niger',0,1,2,1,2,1),(121,'Nigeria',0,1,2,1,2,1),(122,'Norway',0,1,2,1,2,1),(123,'Oman',0,1,2,1,2,1),(124,'Palestine',0,1,2,1,2,1),(125,'Poland',0,1,2,1,2,1),(126,'Portugal',0,1,2,1,2,1),(127,'Qatar',0,1,2,1,2,1),(128,'Romania',0,1,2,1,2,1),(129,'Rwanda',0,1,2,1,2,1),(130,'San Marino',0,1,2,1,2,1),(131,'Sao Tome & Principe',0,1,2,1,2,1),(132,'Saudi Arabia',0,1,2,1,2,1),(133,'Senegal',0,1,2,1,2,1),(134,'Serbia',0,1,2,1,2,1),(135,'Slovakia',0,1,2,1,2,1),(136,'Slovenia',0,1,2,1,2,1),(137,'Somalia',0,1,2,1,2,1),(138,'South Africa',0,1,2,1,2,1),(139,'Spain',0,1,2,1,2,1),(140,'Sudan',0,1,2,1,2,1),(141,'Swaziland',0,1,2,1,2,1),(142,'Sweden',0,1,2,1,2,1),(143,'Switzerland',0,1,2,1,2,1),(144,'Syria',0,1,2,1,2,1),(145,'Tanzania',0,1,2,1,2,1),(146,'Togo',0,1,2,1,2,1),(147,'Tunisia',0,1,2,1,2,1),(148,'Turkey',0,1,2,1,2,1),(149,'Uganda',0,1,2,1,2,1),(150,'Ukraine',0,1,2,1,2,1),(151,'United Arab Emirates',0,1,2,1,2,1),(152,'United Kingdom',0,1,2,1,2,1),(153,'Vatican City',0,1,2,1,2,1),(154,'Western Sahara',0,1,2,1,2,1),(155,'Yemen',0,1,2,1,2,1),(156,'Zambia',0,1,2,1,2,1),(157,'Zimbabwe (Rhodesia)',0,1,2,1,2,1),(158,' Afghanistan',0,1,3,1,2,1),(159,' American Samoa',0,1,3,1,2,1),(160,' Australia',0,1,3,1,2,1),(161,' Bangladesh',0,1,3,1,2,1),(162,' Bhutan',0,1,3,1,2,1),(163,' Brunei',0,1,3,1,2,1),(164,' Cambodia',0,1,3,1,2,1),(165,' China',0,1,3,1,2,1),(166,' Cook Islands',0,1,3,1,2,1),(167,' East Timor',0,1,3,1,2,1),(168,' Federated States of Micronesia',0,1,3,1,2,1),(169,' Fiji',0,1,3,1,2,1),(170,' French Polynesia',0,1,3,1,2,1),(171,' Guam',0,1,3,1,2,1),(172,' Hong Kong (China)',0,1,3,1,2,1),(173,' India',0,1,3,1,2,1),(174,' Indonesia',0,1,3,1,2,1),(175,' Japan',0,1,3,1,2,1),(176,' Kiribati',0,1,3,1,2,1),(177,' Laos',0,1,3,1,2,1),(178,' Macau (China)',0,1,3,1,2,1),(179,' Malaysia',0,1,3,1,2,1),(180,' Maldives',0,1,3,1,2,1),(181,' Marshall Islands',0,1,3,1,2,1),(182,' Mongolia',0,1,3,1,2,1),(183,' Myanmar',0,1,3,1,2,1),(184,' Nauru',0,1,3,1,2,1),(185,' Nepal',0,1,3,1,2,1),(186,' New Caledonia (associate member)',0,1,3,1,2,1),(187,' New Zealand',0,1,3,1,2,1),(188,' Niue',0,1,3,1,2,1),(189,' North Korea',0,1,3,1,2,1),(190,' Northern Mariana Islands',0,1,3,1,2,1),(191,' Pakistan',0,1,3,1,2,1),(192,' Palau',0,1,3,1,2,1),(193,' Papua New Guinea',0,1,3,1,2,1),(194,' Philippines',0,1,3,1,2,1),(195,' Pitcairn Islands',0,1,3,1,2,1),(196,' Samoa',0,1,3,1,2,1),(197,' Singapore',0,1,3,1,2,1),(198,' Solomon Islands',0,1,3,1,2,1),(199,' South Korea',0,1,3,1,2,1),(200,' Sri Lanka',0,1,3,1,2,1),(201,' Taiwan',0,1,3,1,2,1),(202,' Thailand',0,1,3,1,2,1),(203,' Tokelau',0,1,3,1,2,1),(204,' Tonga',0,1,3,1,2,1),(205,' Tuvalu',0,1,3,1,2,1),(206,' Vanuatu',0,1,3,1,2,1),(207,' Vietnam',0,1,3,1,2,1),(208,' Wallis and Futuna',0,1,3,1,2,1);
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_instance`
--

DROP TABLE IF EXISTS `crm_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_instance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_instance`
--

LOCK TABLES `crm_instance` WRITE;
/*!40000 ALTER TABLE `crm_instance` DISABLE KEYS */;
INSERT INTO `crm_instance` VALUES (1,'csv');
/*!40000 ALTER TABLE `crm_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_instance_sales_stage`
--

DROP TABLE IF EXISTS `crm_instance_sales_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_instance_sales_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crm_instance_id` int(11) NOT NULL,
  `sales_stage_name` varchar(128) NOT NULL,
  `local_crm_sales_stage_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_crm_instance_sales_stage_ciid` (`crm_instance_id`),
  KEY `fk_crm_instance_sales_stage_cssid` (`local_crm_sales_stage_id`),
  CONSTRAINT `fk_crm_instance_sales_stage_ciid` FOREIGN KEY (`crm_instance_id`) REFERENCES `crm_instance` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_crm_instance_sales_stage_cssid` FOREIGN KEY (`local_crm_sales_stage_id`) REFERENCES `local_crm_sales_stage` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_instance_sales_stage`
--

LOCK TABLES `crm_instance_sales_stage` WRITE;
/*!40000 ALTER TABLE `crm_instance_sales_stage` DISABLE KEYS */;
INSERT INTO `crm_instance_sales_stage` VALUES (1,1,'Closed Won',1),(2,1,'Closed Lost',2),(3,1,'Negotiation/Review',3),(4,1,'Proposal/Price Quote',3),(5,1,'Prospecting',4),(6,1,'Qualification',4),(7,1,'Needs Analysis',4),(8,1,'Value Proposition',4),(9,1,'Id. Decision Makers',4),(10,1,'Perception Analysis',4);
/*!40000 ALTER TABLE `crm_instance_sales_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(64) DEFAULT NULL,
  `currency_code` char(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_currency_name` (`currency_name`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES (1,'Andorran Peseta','ADP'),(2,'United Arab Emirates Dirham','AED'),(3,'Afghanistan Afghani','AFA'),(4,'Albanian Lek','ALL'),(5,'Netherlands Antillian Guilder','ANG'),(6,'Angolan Kwanza','AOK'),(7,'Argentine Peso','ARS'),(8,'Australian Dollar','AUD'),(9,'Aruban Florin','AWG'),(10,'Barbados Dollar','BBD'),(11,'Bangladeshi Taka','BDT'),(12,'Bulgarian Lev','BGN'),(13,'Bahraini Dinar','BHD'),(14,'Burundi Franc','BIF'),(15,'Bermudian Dollar','BMD'),(16,'Brunei Dollar','BND'),(17,'Bolivian Boliviano','BOB'),(18,'Brazilian Real','BRL'),(19,'Bahamian Dollar','BSD'),(20,'Bhutan Ngultrum','BTN'),(21,'Burma Kyat','BUK'),(22,'Botswanian Pula','BWP'),(23,'Belize Dollar','BZD'),(24,'Canadian Dollar','CAD'),(25,'Swiss Franc','CHF'),(26,'Chilean Unidades de Fomento','CLF'),(27,'Chilean Peso','CLP'),(28,'Yuan (Chinese) Renminbi','CNY'),(29,'Colombian Peso','COP'),(30,'Costa Rican Colon','CRC'),(31,'Czech Republic Koruna','CZK'),(32,'Cuban Peso','CUP'),(33,'Cape Verde Escudo','CVE'),(34,'Cyprus Pound','CYP'),(35,'Danish Krone','DKK'),(36,'Dominican Peso','DOP'),(37,'Algerian Dinar','DZD'),(38,'Ecuador Sucre','ECS'),(39,'Egyptian Pound','EGP'),(40,'Estonian Kroon (EEK)','EEK'),(41,'Ethiopian Birr','ETB'),(42,'Euro','EUR'),(43,'Fiji Dollar','FJD'),(44,'Falkland Islands Pound','FKP'),(45,'British Pound','GBP'),(46,'Ghanaian Cedi','GHC'),(47,'Gibraltar Pound','GIP'),(48,'Gambian Dalasi','GMD'),(49,'Guinea Franc','GNF'),(50,'Guatemalan Quetzal','GTQ'),(51,'Guinea-Bissau Peso','GWP'),(52,'Guyanan Dollar','GYD'),(53,'Hong Kong Dollar','HKD'),(54,'Honduran Lempira','HNL'),(55,'Haitian Gourde','HTG'),(56,'Hungarian Forint','HUF'),(57,'Indonesian Rupiah','IDR'),(58,'Irish Punt','IEP'),(59,'Israeli Shekel','ILS'),(60,'Indian Rupee','INR'),(61,'Iraqi Dinar','IQD'),(62,'Iranian Rial','IRR'),(63,'Jamaican Dollar','JMD'),(64,'Jordanian Dinar','JOD'),(65,'Japanese Yen','JPY'),(66,'Kenyan Schilling','KES'),(67,'Kampuchean (Cambodian) Riel','KHR'),(68,'Comoros Franc','KMF'),(69,'North Korean Won','KPW'),(70,'(South) Korean Won','KRW'),(71,'Kuwaiti Dinar','KWD'),(72,'Cayman Islands Dollar','KYD'),(73,'Lao Kip','LAK'),(74,'Lebanese Pound','LBP'),(75,'Sri Lanka Rupee','LKR'),(76,'Liberian Dollar','LRD'),(77,'Lesotho Loti','LSL'),(78,'Libyan Dinar','LYD'),(79,'Moroccan Dirham','MAD'),(80,'Malagasy Franc','MGF'),(81,'Mongolian Tugrik','MNT'),(82,'Macau Pataca','MOP'),(83,'Mauritanian Ouguiya','MRO'),(84,'Maltese Lira','MTL'),(85,'Mauritius Rupee','MUR'),(86,'Maldive Rufiyaa','MVR'),(87,'Malawi Kwacha','MWK'),(88,'Mexican Peso','MXP'),(89,'Malaysian Ringgit','MYR'),(90,'Mozambique Metical','MZM'),(91,'Namibian Dollar','NAD'),(92,'Nigerian Naira','NGN'),(93,'Nicaraguan Cordoba','NIO'),(94,'Norwegian Kroner','NOK'),(95,'Nepalese Rupee','NPR'),(96,'New Zealand Dollar','NZD'),(97,'Omani Rial','OMR'),(98,'Panamanian Balboa','PAB'),(99,'Peruvian Nuevo Sol','PEN'),(100,'Papua New Guinea Kina','PGK'),(101,'Philippine Peso','PHP'),(102,'Pakistan Rupee','PKR'),(103,'Polish Zloty','PLN'),(104,'Paraguay Guarani','PYG'),(105,'Qatari Rial','QAR'),(106,'Romanian Leu','RON'),(107,'Rwanda Franc','RWF'),(108,'Saudi Arabian Riyal','SAR'),(109,'Solomon Islands Dollar','SBD'),(110,'Seychelles Rupee','SCR'),(111,'Sudanese Pound','SDP'),(112,'Swedish Krona','SEK'),(113,'Singapore Dollar','SGD'),(114,'St. Helena Pound','SHP'),(115,'Sierra Leone Leone','SLL'),(116,'Somali Schilling','SOS'),(117,'Suriname Guilder','SRG'),(118,'Sao Tome and Principe Dobra','STD'),(119,'Russian Ruble','RUB'),(120,'El Salvador Colon','SVC'),(121,'Syrian Potmd','SYP'),(122,'Swaziland Lilangeni','SZL'),(123,'Thai Baht','THB'),(124,'Tunisian Dinar','TND'),(125,'Tongan Paanga','TOP'),(126,'East Timor Escudo','TPE'),(127,'Turkish Lira','TRY'),(128,'Trinidad and Tobago Dollar','TTD'),(129,'Taiwan Dollar','TWD'),(130,'Tanzanian Schilling','TZS'),(131,'Uganda Shilling','UGX'),(132,'US Dollar','USD'),(133,'Uruguayan Peso','UYU'),(134,'Venezualan Bolivar','VEF'),(135,'Vietnamese Dong','VND'),(136,'Vanuatu Vatu','VUV'),(137,'Samoan Tala','WST'),(138,'CommunautÃ© FinanciÃ¨re Africaine BEAC, Francs','XAF'),(139,'Silver, Ounces','XAG'),(140,'Gold, Ounces','XAU'),(141,'East Caribbean Dollar','XCD'),(142,'International Monetary Fund (IMF) Special Drawing Rights','XDR'),(143,'CommunautÃ© FinanciÃ¨re Africaine BCEAO - Francs','XOF'),(144,'Palladium Ounces','XPD'),(145,'Comptoirs FranÃ§ais du Pacifique Francs','XPF'),(146,'Platinum, Ounces','XPT'),(147,'Democratic Yemeni Dinar','YDD'),(148,'Yemeni Rial','YER'),(149,'New Yugoslavia Dinar','YUD'),(150,'South African Rand','ZAR'),(151,'Zambian Kwacha','ZMK'),(152,'Zaire Zaire','ZRZ'),(153,'Zimbabwe Dollar','ZWD'),(154,'Slovak Koruna','SKK'),(155,'Armenian Dram','AMD');
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_exchange_rates`
--

DROP TABLE IF EXISTS `currency_exchange_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency_exchange_rates` (
  `base_currency` varchar(5) NOT NULL,
  `quote_currency` varchar(5) NOT NULL,
  `exchange_rate` float NOT NULL,
  `symbol` varchar(10) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`symbol`,`date`),
  KEY `Date_index` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_exchange_rates`
--

LOCK TABLES `currency_exchange_rates` WRITE;
/*!40000 ALTER TABLE `currency_exchange_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `currency_exchange_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_view`
--

DROP TABLE IF EXISTS `dashboard_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_view` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `metadata` mediumtext,
  `filter` varchar(100) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dashboard_view_url_unique` (`url`,`filter`),
  KEY `FK_dashoard_view_created_by` (`created_by`),
  CONSTRAINT `FK_dashoard_view_created_by` FOREIGN KEY (`created_by`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_view`
--

LOCK TABLES `dashboard_view` WRITE;
/*!40000 ALTER TABLE `dashboard_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo`
--

DROP TABLE IF EXISTS `geo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo`
--

LOCK TABLES `geo` WRITE;
/*!40000 ALTER TABLE `geo` DISABLE KEYS */;
INSERT INTO `geo` VALUES (1,'3 Geo Setup'),(2,'4 Geo Setup');
/*!40000 ALTER TABLE `geo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_business_strategy`
--

DROP TABLE IF EXISTS `global_business_strategy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global_business_strategy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `total_revenue_target` double NOT NULL,
  `marketing_inf_revenue_target` double NOT NULL,
  `fiscal_start` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_business_strategy`
--

LOCK TABLES `global_business_strategy` WRITE;
/*!40000 ALTER TABLE `global_business_strategy` DISABLE KEYS */;
/*!40000 ALTER TABLE `global_business_strategy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `impact_indicator_target`
--

DROP TABLE IF EXISTS `impact_indicator_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impact_indicator_target` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indicator_name` varchar(50) NOT NULL,
  `target_value` decimal(10,0) NOT NULL,
  `valid_from` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `valid_upto` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impact_indicator_target`
--

LOCK TABLES `impact_indicator_target` WRITE;
/*!40000 ALTER TABLE `impact_indicator_target` DISABLE KEYS */;
/*!40000 ALTER TABLE `impact_indicator_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `industry`
--

DROP TABLE IF EXISTS `industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `industry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `industry_name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_industry_name` (`industry_name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `industry`
--

LOCK TABLES `industry` WRITE;
/*!40000 ALTER TABLE `industry` DISABLE KEYS */;
INSERT INTO `industry` VALUES (1,'Consumer Goods and Services'),(2,'Energy'),(3,'Financials'),(4,'Government Agencies'),(5,'Healthcare'),(6,'High Technology'),(7,'Industrials'),(8,'Materials'),(9,'Retail'),(10,'Telecommunications'),(11,'Utilities');
/*!40000 ALTER TABLE `industry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_log`
--

DROP TABLE IF EXISTS `job_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_type` varchar(128) NOT NULL,
  `vendor_name` varchar(128) NOT NULL,
  `instance_name` varchar(128) NOT NULL DEFAULT '',
  `version` varchar(64) NOT NULL,
  `job_name` varchar(128) NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `finish_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` varchar(32) NOT NULL,
  `info` mediumtext,
  `fetch_from` int(11) DEFAULT NULL,
  `fetch_size` int(11) DEFAULT NULL,
  `next_record_token` varchar(256) DEFAULT NULL,
  `failed_records` mediumtext,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_log`
--

LOCK TABLES `job_log` WRITE;
/*!40000 ALTER TABLE `job_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `local_crm_sales_stage`
--

DROP TABLE IF EXISTS `local_crm_sales_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `local_crm_sales_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stage` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `local_crm_sales_stage`
--

LOCK TABLES `local_crm_sales_stage` WRITE;
/*!40000 ALTER TABLE `local_crm_sales_stage` DISABLE KEYS */;
INSERT INTO `local_crm_sales_stage` VALUES (1,'Closed/Won'),(2,'Closed/Lost'),(3,'Qualified Pipeline'),(4,'Others');
/*!40000 ALTER TABLE `local_crm_sales_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manual_campaign_input`
--

DROP TABLE IF EXISTS `manual_campaign_input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manual_campaign_input` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(64) DEFAULT NULL,
  `campaign_name` varchar(64) DEFAULT NULL,
  `parent_campaign_id` varchar(64) DEFAULT NULL,
  `parent_campaign_name` varchar(64) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `touch_point_label` varchar(64) DEFAULT NULL,
  `total_campaign_cost` double DEFAULT NULL,
  `new_campaign_name` varchar(64) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaign_id_UNIQUE` (`campaign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manual_campaign_input`
--

LOCK TABLES `manual_campaign_input` WRITE;
/*!40000 ALTER TABLE `manual_campaign_input` DISABLE KEYS */;
/*!40000 ALTER TABLE `manual_campaign_input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `miri_metric_ref`
--

DROP TABLE IF EXISTS `miri_metric_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `miri_metric_ref` (
  `id` int(11) DEFAULT NULL,
  `category` varchar(9) DEFAULT NULL,
  `section` varchar(10) DEFAULT NULL,
  `item` varchar(16) DEFAULT NULL,
  `url` varchar(78) DEFAULT NULL,
  `filter` varchar(30) DEFAULT NULL,
  `subdrilldown` varchar(85) DEFAULT NULL,
  `timeframe` varchar(74) DEFAULT NULL,
  `charttype` varchar(19) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `miri_metric_ref`
--

LOCK TABLES `miri_metric_ref` WRITE;
/*!40000 ALTER TABLE `miri_metric_ref` DISABLE KEYS */;
INSERT INTO `miri_metric_ref` VALUES (1,'visualize','measure','MISG','/miri/dashboard/visualize/measure/mi-sg-revenue-achieved','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(2,'visualize','measure','MISG','/miri/dashboard/visualize/measure/mi-sg-revenue-achieved','marketing-influenced','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(3,'visualize','measure','MISG','/miri/dashboard/visualize/measure/mi-sg-revenue-achieved','sales-generated','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(4,'visualize','measure','NBC','/miri/dashboard/visualize/measure/new-business-closed','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','scatter'),(5,'visualize','measure','NBC','/miri/dashboard/visualize/measure/new-business-closed','marketing-influenced','campaign,lead-source,competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','scatter'),(6,'visualize','measure','NBC','/miri/dashboard/visualize/measure/new-business-closed','sales-generated','competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','scatter'),(7,'visualize','measure','LOO','/miri/dashboard/visualize/measure/large-open-opportunities-pipeline','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnRotated'),(8,'visualize','measure','LOO','/miri/dashboard/visualize/measure/large-open-opportunities-pipeline','marketing-influenced','sales-person,oppurtunity-stage,probability-close','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnRotated'),(9,'visualize','measure','LOO','/miri/dashboard/visualize/measure/large-open-opportunities-pipeline','sales-generated','sales-person,oppurtunity-stage,probability-close','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnRotated'),(10,'visualize','measure','MISGP','/miri/dashboard/visualize/measure/marketing-influence-sales-generated-pipeline','overall','N/A','N/A','stackedChart'),(11,'visualize','measure','MISGP','/miri/dashboard/visualize/measure/marketing-influence-sales-generated-pipeline','marketing-influenced','oppurtunity-stage,probability-close','N/A','stackedChart'),(12,'visualize','measure','MISGP','/miri/dashboard/visualize/measure/marketing-influence-sales-generated-pipeline','sales-generated','oppurtunity-stage,probability-close','N/A','stackedChart'),(13,'visualize','measure','CWR','/miri/dashboard/visualize/measure/competitive-win-rate','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','pie'),(14,'visualize','measure','CWR','/miri/dashboard/visualize/measure/competitive-win-rate','marketing-influenced','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','pie'),(15,'visualize','measure','CWR','/miri/dashboard/visualize/measure/competitive-win-rate','sales-generated','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','pie'),(16,'visualize','understand','Top Customers','/miri/dashboard/visualize/understand/top-customers-win','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicBar'),(17,'visualize','understand','Top Customers','/miri/dashboard/visualize/understand/top-customers-win','marketing-influenced','campaign,competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicBar'),(18,'visualize','understand','Top Customers','/miri/dashboard/visualize/understand/top-customers-win','sales-generated','competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicBar'),(19,'visualize','understand','Top Products','/miri/dashboard/visualize/understand/top-products-by-revenue-achieved','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(20,'visualize','understand','Top Products','/miri/dashboard/visualize/understand/top-products-by-revenue-achieved','marketing-influenced','campaign,competitor,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(21,'visualize','understand','Top Products','/miri/dashboard/visualize/understand/top-products-by-revenue-achieved','sales-generated','competitor,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(22,'visualize','understand','Top countries','/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','geo'),(23,'visualize','understand','Top countries','/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved','marketing-influenced','campaign,competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','geo'),(24,'visualize','understand','Top countries','/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved','sales-generated','competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','geo'),(25,'visualize','understand','Top Industries','/miri/dashboard/visualize/understand/top-industry-by-revenue','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','barAction'),(26,'visualize','understand','Top Industries','/miri/dashboard/visualize/understand/top-industry-by-revenue','marketing-influenced','campaign,competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','barAction'),(27,'visualize','understand','Top Industries','/miri/dashboard/visualize/understand/top-industry-by-revenue','sales-generated','competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','barAction'),(28,'visualize','understand','Top Sales People','/miri/dashboard/visualize/understand/top-sales-people-by-revenue-achieved','overall','campaign,competitive-win-rate,average-deal-size,average-sell-price,no-of-deals-closed','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','cloumnBasic'),(29,'visualize','Connect','ATR','/miri/dashboard/visualize/connect/average-time-to-revenue','overall','N/A','N/A','spineIrregular'),(30,'visualize','Connect','ATR','/miri/dashboard/visualize/connect/average-time-to-revenue','marketing-influenced','N/A','N/A','spineIrregular'),(31,'visualize','Connect','ATR','/miri/dashboard/visualize/connect/average-time-to-revenue','sales-generated','N/A','N/A','spineIrregular'),(32,'visualize','Connect','LDC','/miri/dashboard/visualize/connect/largest-deals-closed','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','bubbleChart'),(33,'visualize','Connect','LDC','/miri/dashboard/visualize/connect/largest-deals-closed','marketing-influenced','campaign,lead-source,competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','bubbleChart'),(34,'visualize','Connect','LDC','/miri/dashboard/visualize/connect/largest-deals-closed','sales-generated','competitor,product,sales-person','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','bubbleChart'),(35,'visualize','Connect','ROI','miri/dashboard/visualize/connect/marketing-spend-roi','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','combo'),(36,'visualize','Connect','BPC','miri/dashboard/visualize/connect/best-performing-campaigns','overall','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(37,'analyze','Measure','WLTA','miri/dashboard/analyze/measure/win-loss-trend-analysis','campaign','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(38,'analyze','Measure','WLTA','miri/dashboard/analyze/measure/win-loss-trend-analysis','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(39,'analyze','Measure','WLTA','miri/dashboard/analyze/measure/win-loss-trend-analysis','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(40,'analyze','Measure','WLTA','miri/dashboard/analyze/measure/win-loss-trend-analysis','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(41,'analyze','Measure','WLTA','miri/dashboard/analyze/measure/win-loss-trend-analysis','new-or-existing','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(42,'analyze','Measure','WLTA','miri/dashboard/analyze/measure/win-loss-trend-analysis','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(43,'analyze','Measure','WLTA','miri/dashboard/analyze/measure/win-loss-trend-analysis','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(44,'analyze','Measure','WLTA','miri/dashboard/analyze/measure/win-loss-trend-analysis','region-or-country','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(45,'analyze','Measure','MCCPTA','miri/dashboard/analyze/measure/marketing-campaign-cost-performance','lead-to-opportunity-conversion','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','funnelChart'),(46,'analyze','Measure','MCCPTA','miri/dashboard/analyze/measure/marketing-campaign-cost-performance','opportunity-to-deal-conversion','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','funnelChart'),(47,'analyze','Measure','MCPTA','miri/dashboard/analyze/measure/marketing-campaign-cost-performance','average-cost-lead','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','lineLabels'),(48,'analyze','Measure','MCPTA','miri/dashboard/analyze/measure/marketing-campaign-cost-performance','average-cost-opportunity','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','lineLabels'),(49,'analyze','Measure','MCPTA','miri/dashboard/analyze/measure/marketing-campaign-cost-performance','average-cost-deal','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','lineLabels'),(50,'analyze','Measure','SRPTA','miri/dashboard/analyze/measure/sales-campaign-revenue-performance','new-or-existing','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(51,'analyze','Measure','SRPTA','miri/dashboard/analyze/measure/sales-campaign-revenue-performance','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(52,'analyze','Measure','SRPTA','miri/dashboard/analyze/measure/sales-campaign-revenue-performance','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(53,'analyze','Measure','SRPTA','miri/dashboard/analyze/measure/sales-campaign-revenue-performance','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(54,'analyze','Measure','SRPTA','miri/dashboard/analyze/measure/sales-campaign-revenue-performance','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(55,'analyze','Measure','SRPTA','miri/dashboard/analyze/measure/sales-campaign-revenue-performance','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(56,'analyze','Measure','SRPTA','miri/dashboard/analyze/measure/sales-campaign-revenue-performance','region','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(57,'analyze','Measure','MCRPTA','miri/dashboard/analyze/measure/marketing-campaign-revenue-performance','new-or-existing','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(58,'analyze','Measure','MCRPTA','miri/dashboard/analyze/measure/marketing-campaign-revenue-performance','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(59,'analyze','Measure','MCRPTA','miri/dashboard/analyze/measure/marketing-campaign-revenue-performance','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(60,'analyze','Measure','MCRPTA','miri/dashboard/analyze/measure/marketing-campaign-revenue-performance','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(61,'analyze','Measure','MCRPTA','miri/dashboard/analyze/measure/marketing-campaign-revenue-performance','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(62,'analyze','Measure','MCRPTA','miri/dashboard/analyze/measure/marketing-campaign-revenue-performance','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(63,'analyze','Measure','MCRPTA','miri/dashboard/analyze/measure/marketing-campaign-revenue-performance','region','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','basicLine'),(64,'analyze','Understand','PATA','/miri/dashboard/analyze/understand/product-adoption-trend-analysis','region','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(65,'analyze','Understand','PATA','/miri/dashboard/analyze/understand/product-adoption-trend-analysis','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(66,'analyze','Understand','PATA','/miri/dashboard/analyze/understand/product-adoption-trend-analysis','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(67,'analyze','Understand','PATA','/miri/dashboard/analyze/understand/product-adoption-trend-analysis','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(68,'analyze','Understand','PATA','/miri/dashboard/analyze/understand/product-adoption-trend-analysis','campaign','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(69,'analyze','Understand','PATA','/miri/dashboard/analyze/understand/product-adoption-trend-analysis','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(70,'analyze','Understand','PATA','/miri/dashboard/analyze/understand/product-adoption-trend-analysis','new-or-existing','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(71,'analyze','Understand','PATA','/miri/dashboard/analyze/understand/product-adoption-trend-analysis','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','largeTreeMap'),(72,'analyze','Understand','PTA','/miri/dashboard/analyze/understand/pricing-trend-analysis','region','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(73,'analyze','Understand','PTA','/miri/dashboard/analyze/understand/pricing-trend-analysis','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(74,'analyze','Understand','PTA','/miri/dashboard/analyze/understand/pricing-trend-analysis','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(75,'analyze','Understand','PTA','/miri/dashboard/analyze/understand/pricing-trend-analysis','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(76,'analyze','Understand','PTA','/miri/dashboard/analyze/understand/pricing-trend-analysis','campaign','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(77,'analyze','Understand','PTA','/miri/dashboard/analyze/understand/pricing-trend-analysis','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(78,'analyze','Understand','PTA','/miri/dashboard/analyze/understand/pricing-trend-analysis','new-or-existing','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(79,'analyze','Understand','PTA','/miri/dashboard/analyze/understand/pricing-trend-analysis','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','multiAxes'),(80,'analyze','Understand','RTM','/miri/dashboard/analyze/understand/rtm-success-trend-analysis','region','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(81,'analyze','Understand','RTM','/miri/dashboard/analyze/understand/rtm-success-trend-analysis','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(82,'analyze','Understand','RTM','/miri/dashboard/analyze/understand/rtm-success-trend-analysis','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(83,'analyze','Understand','RTM','/miri/dashboard/analyze/understand/rtm-success-trend-analysis','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(84,'analyze','Understand','RTM','/miri/dashboard/analyze/understand/rtm-success-trend-analysis','campaign','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(85,'analyze','Understand','RTM','/miri/dashboard/analyze/understand/rtm-success-trend-analysis','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(86,'analyze','Understand','RTM','/miri/dashboard/analyze/understand/rtm-success-trend-analysis','new-or-existing','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(87,'analyze','Understand','RTM','/miri/dashboard/analyze/understand/rtm-success-trend-analysis','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(88,'analyze','Understand','RTM','/miri/dashboard/analyze/understand/route-to-market','partner','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','columnDrilldown'),(89,'analyze','Connect','BJTA','/miri/dashboard/analyze/connect/buyers-journey-trend-analysis','overall','N/A','N/A','splineIrregularTime'),(90,'analyze','Connect','BJTA','/miri/dashboard/analyze/connect/buyers-journey-trend-analysis','campaign','N/A','N/A','splineIrregularTime'),(91,'analyze','Connect','BJTA','/miri/dashboard/analyze/connect/buyers-journey-trend-analysis','customers','N/A','N/A','splineIrregularTime'),(92,'analyze','Connect','BJTA','/miri/dashboard/analyze/connect/buyers-journey-trend-analysis','competitor','N/A','N/A','splineIrregularTime'),(93,'analyze','Connect','BJTA','/miri/dashboard/analyze/connect/buyers-journey-trend-analysis','product','N/A','N/A','splineIrregularTime'),(94,'analyze','Connect','BJTA','/miri/dashboard/analyze/connect/buyers-journey-trend-analysis','sales-person','N/A','N/A','splineIrregularTime'),(95,'analyze','Connect','CVTA','/miri/dashboard/analyze/connect/customers-life-time-value-trend-analysis','overall','N/A','N/A','splineIrregularTime'),(96,'analyze','Connect','CVTA','/miri/dashboard/analyze/connect/customers-life-time-value-trend-analysis','campaign','N/A','N/A','splineIrregularTime'),(97,'analyze','Connect','CVTA','/miri/dashboard/analyze/connect/customers-life-time-value-trend-analysis','competitor','N/A','N/A','splineIrregularTime'),(98,'analyze','Connect','CVTA','/miri/dashboard/analyze/connect/customers-life-time-value-trend-analysis','industry','N/A','N/A','splineIrregularTime'),(99,'analyze','Connect','CVTA','/miri/dashboard/analyze/connect/customers-life-time-value-trend-analysis','product','N/A','N/A','splineIrregularTime'),(100,'analyze','Connect','CVTA','/miri/dashboard/analyze/connect/customers-life-time-value-trend-analysis','sales-person','N/A','N/A','splineIrregularTime'),(101,'analyze','Connect','CVTA','/miri/dashboard/analyze/connect/customers-life-time-value-trend-analysis','region-or-country','N/A','N/A','splineIrregularTime'),(102,'analyze','Connect','DTTA','/miri/dashboard/analyze/connect/demand-triggers-trend-analysis','competitor','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud'),(103,'analyze','Connect','DTTA','/miri/dashboard/analyze/connect/demand-triggers-trend-analysis','campaign','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud'),(104,'analyze','Connect','DTTA','/miri/dashboard/analyze/connect/demand-triggers-trend-analysis','customers','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud'),(105,'analyze','Connect','DTTA','/miri/dashboard/analyze/connect/demand-triggers-trend-analysis','industry','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud'),(106,'analyze','Connect','DTTA','/miri/dashboard/analyze/connect/demand-triggers-trend-analysis','product','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud'),(107,'analyze','Connect','DTTA','/miri/dashboard/analyze/connect/demand-triggers-trend-analysis','sales-person','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud'),(108,'analyze','Connect','DTTA','/miri/dashboard/analyze/connect/demand-triggers-trend-analysis','region-or-country','N/A','oneYear,firstQuarter,secondQuarter,thirdQuarter,fourthQuarter,onePlusYears','wordCloud');
/*!40000 ALTER TABLE `miri_metric_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persistent_login`
--

DROP TABLE IF EXISTS `persistent_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `persistent_login` (
  `username` varchar(64) NOT NULL,
  `series` varchar(64) NOT NULL,
  `token` varchar(64) NOT NULL,
  `last_used` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`series`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persistent_login`
--

LOCK TABLES `persistent_login` WRITE;
/*!40000 ALTER TABLE `persistent_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `persistent_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` VALUES (1,'AMS'),(2,'EMEA'),(3,'APJ'),(4,'Japan');
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region_country`
--

DROP TABLE IF EXISTS `region_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region_country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_region_country_region_id` (`region_id`),
  KEY `fk_country_id` (`country_id`),
  CONSTRAINT `fk_country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_region_id` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region_country`
--

LOCK TABLES `region_country` WRITE;
/*!40000 ALTER TABLE `region_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `region_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_search`
--

DROP TABLE IF EXISTS `saved_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saved_search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `search_key` varchar(100) NOT NULL,
  `columns` mediumtext,
  `start_page_no` int(11) NOT NULL,
  `current_page_no` int(11) NOT NULL,
  `page_size` int(11) NOT NULL,
  `filters` varchar(255) DEFAULT NULL,
  `sort_on_doc` varchar(50) DEFAULT NULL,
  `sort_on_field` varchar(50) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_saved_search_created_by` (`created_by`),
  CONSTRAINT `FK_saved_search_created_by` FOREIGN KEY (`created_by`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_search`
--

LOCK TABLES `saved_search` WRITE;
/*!40000 ALTER TABLE `saved_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `saved_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_authority`
--

DROP TABLE IF EXISTS `user_authority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_authority` (
  `username` varchar(100) NOT NULL,
  `authority_name` varchar(50) NOT NULL,
  PRIMARY KEY (`username`,`authority_name`),
  KEY `FK_tnnyxjpcvg2aj0d0i6ufnabm2` (`authority_name`),
  CONSTRAINT `FK_h5t8nplqarkfi7tscc9unyr7y` FOREIGN KEY (`username`) REFERENCES `user_info` (`username`),
  CONSTRAINT `FK_tnnyxjpcvg2aj0d0i6ufnabm2` FOREIGN KEY (`authority_name`) REFERENCES `authority` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_authority`
--

LOCK TABLES `user_authority` WRITE;
/*!40000 ALTER TABLE `user_authority` DISABLE KEYS */;
INSERT INTO `user_authority` VALUES ('admin@phaladata.com','ROLE_ADMIN'),('exec@phaladata.com','ROLE_EXECUTIVE'),('guest@phaladata.com','ROLE_GUEST'),('master@phaladata.com','ROLE_MASTER');
/*!40000 ALTER TABLE `user_authority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_info` (
  `username` varchar(100) NOT NULL,
  `active` bit(1) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_info`
--

LOCK TABLES `user_info` WRITE;
/*!40000 ALTER TABLE `user_info` DISABLE KEYS */;
INSERT INTO `user_info` VALUES ('admin@phaladata.com','','Admin','Admin','$2a$10$n2usJ4tUqZF8CydUlqgupOgBjxW5QomRuDhlSJrSTjCM4iUAiy6W.'),('exec@phaladata.com','','Executive','User','$2a$10$E2PSxeWK79SKFNXp4SZ6C.qPN3vQZ4W4.QMFi7TpovSAFpoteyWu2'),('guest@phaladata.com','','Guest','Guest','$2a$10$E2PSxeWK79SKFNXp4SZ6C.qPN3vQZ4W4.QMFi7TpovSAFpoteyWu2'),('master@phaladata.com','','Master','User','$2a$10$E2PSxeWK79SKFNXp4SZ6C.qPN3vQZ4W4.QMFi7TpovSAFpoteyWu2');
/*!40000 ALTER TABLE `user_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_login_token`
--

DROP TABLE IF EXISTS `user_login_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_login_token` (
  `id` varchar(255) NOT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `user` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_nv6inptdyrxxwyap5fax7erin` (`user`),
  CONSTRAINT `FK_nv6inptdyrxxwyap5fax7erin` FOREIGN KEY (`user`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_login_token`
--

LOCK TABLES `user_login_token` WRITE;
/*!40000 ALTER TABLE `user_login_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_login_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_service_vendor`
--

DROP TABLE IF EXISTS `web_service_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_service_vendor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_type` varchar(128) NOT NULL,
  `vendor_name` varchar(128) NOT NULL,
  `instance_name` varchar(128) NOT NULL DEFAULT '',
  `version` varchar(32) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendor_type_instance_name_unique` (`vendor_type`,`instance_name`,`vendor_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_service_vendor`
--

LOCK TABLES `web_service_vendor` WRITE;
/*!40000 ALTER TABLE `web_service_vendor` DISABLE KEYS */;
INSERT INTO `web_service_vendor` VALUES (1,'dataArrMAP','oracle_eloqua','oracle_eloqua-0','0',0,'2016-01-14 14:25:28','2016-02-03 02:40:09'),(2,'CRM','FUSION','','',1,'2016-01-14 14:25:52','2016-01-14 14:25:52'),(3,'CRM','SalesForce','','',1,'2016-01-14 16:22:11','2016-02-02 07:27:39'),(4,'MAP','Eloqua','','',0,'2016-01-22 03:54:55','2016-02-03 02:47:28'),(5,'MAP','Marketo','','',1,'2016-01-27 05:59:27','2016-02-02 07:27:42');
/*!40000 ALTER TABLE `web_service_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_service_vendor_configuration_detail`
--

DROP TABLE IF EXISTS `web_service_vendor_configuration_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_service_vendor_configuration_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `web_service_vendor_id` int(11) NOT NULL,
  `attribute_name` varchar(128) NOT NULL,
  `attribute_value` varchar(256) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendor_attribute_unique` (`web_service_vendor_id`,`attribute_name`),
  CONSTRAINT `FK_web_service_vendor` FOREIGN KEY (`web_service_vendor_id`) REFERENCES `web_service_vendor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `touch_point`;

CREATE TABLE `touch_point` (
  `touch_point_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `leads_associated` mediumtext,
  `touchpoint_date` datetime DEFAULT NULL,
  `touch_point_name` varchar(255) DEFAULT NULL,
  `unique_combinations` mediumtext,
  `touch_point_campaign_id` bigint(20) NOT NULL,
  PRIMARY KEY (`touch_point_id`),
  KEY `FK_q7gso4s0kvey4h4caw0h6tub9` (`touch_point_campaign_id`),
  CONSTRAINT `FK_q7gso4s0kvey4h4caw0h6tub9` FOREIGN KEY (`touch_point_campaign_id`) REFERENCES `touch_point_campaigns` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2423 DEFAULT CHARSET=utf8;
SELECT * FROM phaladata.touch_point;

DROP TABLE IF EXISTS `touch_point_campaigns`;

CREATE TABLE `touch_point_campaigns` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(255) DEFAULT NULL,
  `campaign_name` varchar(255) DEFAULT NULL,
  `last_run` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `web_service_vendor_configuration_detail`
--

LOCK TABLES `web_service_vendor_configuration_detail` WRITE;
/*!40000 ALTER TABLE `web_service_vendor_configuration_detail` DISABLE KEYS */;
INSERT INTO `web_service_vendor_configuration_detail` VALUES (1,1,'apiUserKey','','2016-01-14 14:25:39','2016-01-14 14:25:39'),(2,1,'class','class com.miri.search.data.DatasourceSetup','2016-01-14 14:25:39','2016-01-14 14:25:39'),(3,1,'clientId','','2016-01-14 14:25:39','2016-01-14 14:25:39'),(4,1,'clientSecret','','2016-01-14 14:25:39','2016-01-14 14:25:39'),(5,1,'companyName','hhhhhh','2016-01-14 14:25:39','2016-01-14 14:25:39'),(6,1,'datasourceId','0','2016-01-14 14:25:39','2016-01-14 14:25:39'),(7,1,'email','','2016-01-14 14:25:39','2016-01-14 14:25:39'),(8,1,'isConnected','false','2016-01-14 14:25:39','2016-01-14 14:25:39'),(9,1,'password','admin123','2016-01-14 14:25:39','2016-01-14 14:25:39'),(10,1,'securityToken','','2016-01-14 14:25:39','2016-01-14 14:25:39'),(11,1,'showApiUserKey','false','2016-01-14 14:25:39','2016-01-14 14:25:39'),(12,1,'showClientId','false','2016-01-14 14:25:39','2016-01-14 14:25:39'),(13,1,'showClientSecret','false','2016-01-14 14:25:39','2016-01-14 14:25:39'),(14,1,'showCompanyName','true','2016-01-14 14:25:39','2016-01-14 14:25:39'),(15,1,'showEmail','false','2016-01-14 14:25:39','2016-01-14 14:25:39'),(16,1,'showPassword','true','2016-01-14 14:25:39','2016-01-14 14:25:39'),(17,1,'showUrl','true','2016-01-14 14:25:39','2016-01-14 14:25:39'),(18,1,'showUsername','true','2016-01-14 14:25:39','2016-01-14 14:25:39'),(19,1,'system','oracle_eloqua','2016-01-14 14:25:39','2016-01-14 14:25:39'),(20,1,'url','test','2016-01-14 14:25:39','2016-01-14 14:25:39'),(21,1,'username','admin@phaladata.com','2016-01-14 14:25:39','2016-01-14 14:25:39'),(22,2,'ws-username','bala.gupta','2016-01-14 14:25:52','2016-01-14 14:25:52'),(23,2,'ws-password','Welcome1','2016-01-14 14:25:52','2016-01-14 14:25:52'),(24,2,'CampaignPublicService.service.url','https://caul-test.crm.us2.oraclecloud.com/mktDialogs/CampaignPublicService','2016-01-14 14:25:52','2016-01-14 14:25:52'),(25,2,'CampaignPublicService.service.uri','http://xmlns.oracle.com/oracle/apps/marketing/coreMarketing/campaigns/campaignPublicService/','2016-01-14 14:25:52','2016-01-14 14:25:52'),(26,2,'CampaignPublicService.service.name','CampaignPublicService','2016-01-14 14:25:52','2016-01-14 14:25:52'),(27,2,'LeadIntegrationService.service.url','https://caul-test.crm.us2.oraclecloud.com/mklLeads/LeadIntegrationService','2016-01-14 14:25:52','2016-01-14 14:25:52'),(28,2,'LeadIntegrationService.service.uri','http://xmlns.oracle.com/apps/marketing/leadMgmt/leads/leadServiceV3/','2016-01-14 14:25:52','2016-01-14 14:25:52'),(29,2,'LeadIntegrationService.service.name','LeadIntegrationService','2016-01-14 14:25:52','2016-01-14 14:25:52'),(30,3,'crm.salesforce.rest.api.userName','mohan.mohan@razorfish.com','2016-01-14 16:22:28','2016-01-14 16:22:28'),(31,3,'crm.salesforce.rest.api.password','Phaladata#1','2016-01-14 16:22:28','2016-01-14 16:22:28'),(32,3,'crm.salesforce.rest.api.salesforceOAuthTokenURL','https://login.salesforce.com/services/oauth2/token','2016-01-14 16:22:28','2016-01-14 16:22:28'),(33,3,'crm.salesforce.rest.api.securityToken','ySW4lAEZViUQ9jhB3FgiSdqE','2016-01-14 16:22:28','2016-01-14 16:22:28'),(34,3,'crm.salesforce.rest.api.clientId','3MVG9ZL0ppGP5UrCILi40zjOjtoBZLtvBkkgyU0Mgxa5f4XIDGzQJtTxdNTbNiD59cLTi7R9IXD4XA4dD1j0f','2016-01-14 16:22:28','2016-01-14 16:22:28'),(35,3,'crm.salesforce.rest.api.clientSecret','7084216803122508927','2016-01-14 16:22:28','2016-01-14 16:22:28'),(36,3,'crm.salesforce.rest.api.version','v35.0','2016-01-14 16:22:28','2016-01-14 16:22:28'),(37,4,'map.eloqua.rest.api.endpoint','https://secure.p02.eloqua.com/API/REST','2016-01-22 03:55:11','2016-01-22 05:18:33'),(38,4,'map.eloqua.rest.api.username','Chandra.Shekar','2016-01-22 03:55:11','2016-01-22 03:55:11'),(39,4,'map.eloqua.rest.api.password','Phaladata#1','2016-01-22 03:55:11','2016-01-22 03:55:11'),(41,4,'map.eloqua.rest.api.sitename','TechnologyPartnerPhalaData','2016-01-22 03:56:28','2016-01-22 03:56:28'),(42,5,'map.marketo.rest.api.endpoint','https://677-LMM-556.mktorest.com/','2016-01-27 06:01:03','2016-01-27 06:01:03'),(43,5,'map.marketo.rest.api.clientId','fc72ee69-2951-4697-b207-d22e82ed7567','2016-01-27 06:01:03','2016-01-27 19:20:00'),(44,5,'map.marketo.rest.api.clientSecret','oakNeA8QGEzIb7J4Tq2ocKjZGiYVUKuW','2016-01-27 06:01:03','2016-01-27 06:01:03'),(45,5,'map.marketo.rest.api.endpoint.oauth.token.serviceurl','identity/oauth/token','2016-01-27 06:01:03','2016-01-27 09:27:48');
/*!40000 ALTER TABLE `web_service_vendor_configuration_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-02-03 17:40:07
