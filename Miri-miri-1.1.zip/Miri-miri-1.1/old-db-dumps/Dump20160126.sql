-- MySQL dump 10.13  Distrib 5.6.24, for linux-glibc2.5 (x86_64)
--
-- Host: 127.0.0.1    Database: phaladata
-- ------------------------------------------------------
-- Server version	5.6.27-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(45) DEFAULT NULL,
  `business_unit` varchar(45) DEFAULT NULL,
  `address1` varchar(50) DEFAULT NULL,
  `address2` varchar(50) DEFAULT NULL,
  `address3` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zip_code` varchar(50) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `industry_id` int(11) DEFAULT NULL,
  `no_of_employees` int(11) DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `annual_revenue` double DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `logo` mediumblob,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fiscal_start` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `fk_account_country_id` (`country_id`),
  KEY `fk_account_industry_id` (`industry_id`),
  KEY `fk_account_currency_id` (`currency_id`),
  CONSTRAINT `fk_account_country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`),
  CONSTRAINT `fk_account_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`id`),
  CONSTRAINT `fk_account_industry_id` FOREIGN KEY (`industry_id`) REFERENCES `industry` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,'admin@phaladata.com','admin123','a','b','c','d','e','560017',104,5,12,12,1234,'http://www.google.com','data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEBUSEhIRFRUWFhcWFRYVFxUVFxgXFRcXFhgYFRcYHSggGBolGxcYITEhJSorLi4vGB8zODMtNygtLisBCgoKDg0OGBAQGi0lICUtLS0tLS0tLS0tLS0tLS0tLS0tLSstLS0tKy0tLS0tLS0rLS0tLS0tLS0tLS0tLS0tLf/AABEIAPEA0QMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAABAAIEBQYDBwj/xABEEAABAwIEAwQIAwYEBAcAAAABAAIRAyEEEjFBBVFhBiJxgRMykaGxwdHwQlLhFDNicoLxByNDshY0Y6IVJDVzkrPi/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAECBAMF/8QAIhEBAQACAgICAwEBAAAAAAAAAAECEQMhBDESQSIyURNh/9oADAMBAAIRAxEAPwCoSTg1HKuqhiSflRyoOcIgJ8IwgYAjCfCUKNpNhc8RXYwZnuDRzJhQ+LcZp0BBOZ+zBE/1cgsbj8e7EPzOAFrAHToC7T5qNjSP7T0gTDXEcwW38JUrCccov/M3T1gN9NCViThHa5THOR8RKsMFVLbejDj1idN+7cdJUbNNwyqCJBBHROJCocHjnXzUy2RIjeNwTM+cm26Zii4Oc8l1SmG7OIubAQL/ACEqdmmjhKFksB2jLDlLCac6k5nNaQI0Fx9VqsLiWVG5mGR5jXTXbqpiD4RhOhKFIbCUJ8JQogaAllT4ShQkyEYToRhNBkIwnQlCaASSSU6HKEoTgEYUbDYShPhKEDYShPhKEDYVF2i462i0spuBqm0CDl6u5HopfaLiYw9EkeubMHU7+AXnFSoXEk3JMk9SoBc8uJc4kkmSTv4qQ2g4QS0wbgw4j2hRmVCCtDwmoXd15kHaWj2fVAMHWDgGua1xiB6x/QqY/CBozQB/CcwPsI+BXavg2UCHMc6fy9wgk7XM+SdxPFl4FiLSRGW/kVCXL/xVrW5my5v4mOcZB/Mw7HxEFQsXxNhcKtPn326B3IxzEn2gqpxQJKj5I0QXPGGh1NtawLzlIFhYDbbWPJSOy/G20z6N9mk2dqBOoPIZoM7SU3BBlTDNYTdtR7twSMgJ06D/ALQN1UVaGUBwsHXAuRlM2ObXT4KYPUYShRuESaFPMZIa0EzM2F58IU2FZVzhKF1hKFI5QjC6QlCJc4ShdIQhAyEoToShAIST0VAjgJ0IgJ0JoMhGE/KiAg5wjCfCSDBdvag9Oxo1DL8hJMffgswr3ts0DGOgkktaTPONB0iFQqoewhWHD6zQ8GDbYAH42VautF0INy3itMsiXF5EQYLo3jKbT487hVmLxOeQxpIB9VpFSOrg3uj2uKd2e7NvxZABcBvay9M4T/hiwM7znHpYW8NwuWXLjOnecOVm68ffTbElonm0uN/O2hGidSwRIJIHv3+/evacF/h5Ra5wItB33nZdn9hqLQQALrleefx1nj/9eChjgCBp4xb9Vza81HgEmTZsQO9Aa22g0aOUBb3th2V/Z6b3MmNfJYThlHPXptJjM9ovpqDEwYnTQ6hd8M5lNxw5eO4XVelcIoubSGcQ7QjWMtgJGvipsIUGw0Dlb2W+S6Lq4mwlCckgbCEJySBsJJyBCAJIwhCBJJJIGtCKKSBJIwlCAQiEYSQeb9tsTnxRA0YA3z1O3Uc1n1Y8fpuGJqZ25SXEx0mx6yN1XqqSC1fZLslVxJDohs6/RUPCMA6vWZTbq5wHluvojhOEp4akxrQAGNA+vvXDm5LjNRq8fimV3U7s3wOnh6bWtAELSUaaz2E4o95hlOY3JhRsb25p4d/o6zXB3QT7xZZcGjklvpqnsvZR8RS8VX8K7R0sQe4TYEweSq+NduMNScWude/u5lRe+orJlj7RO1WFD6L28wV8+hoZiACYy1BflDhv0Xr3E+1fpmk0nUzYy0m56ATdeaVuGvdis3oy5prSRFiC+TB0i8LR48s3K5eVZdWPRw1GE5JbGM2EoTkkAhAhOSQNhBPQIQMSTiEIQNhJPhJBzRCARCApJIoAknQlCDzjtxhHMxJf+F4kHq2A4fA+a5/8PvyNqEOhzc7Y0ynQytt2k4c2tRINssuB5WI9l1a/4YVW4nh4pPAc6jNNzfxBjjIPVvwLTqDA4c2Vxm478GOOV1WY/wANcABiSSPwyJ8V66ymXCIlZmvg24fFMYGhvdIBEQ4DRw8rEcwVpsBiNCseeXyu2/DCY46ik4l2drVnQ+tWbSIjJQOSDsSdX+EgI0eyNH0XoR6ZxzZsz7wLd0CYaOog31W6wRa5dzlaCbdFaenPLLWXrtQ8A4HTwzsrQTMyTqZ2VDxTsPhXVKrjSc+XZoD4Ik5rW8oW1w16gnkuWOhlYOJgO7p+I+arNybTbvLV/jy/ivZFobTFKiabaZu5xkmST53MzGyj4Cnl9IOTyPYGr1DiJHozovOngZnR+Z3xK0ePbcrtw8mSYzRqSSMLWxgkjCUIAkjCSAJJJIEhCKSAQkikg5BFAIoCE5ABOQBKEUkEXijM1CoObHfArD9jO1B4fijWyl7HAsqMBgkG8jaQR7zzXoLhII52XnPGOAOpHkCSM18t9PCDb2KuWMs1VscrjdxtePdu8Ni30jQZUDqckl7Q2x1GuoPxWp7P8TbVbE3XjXBcG4ekcRdoHuufcFsey/EMrxexWPk45PTfw8ly9vWcHiSLKXWa59J0PyGO6TeDsSPFUWAxYcD0E+SicR4sQYHpHiLtpsfU1O4YDHnC44yu+Vjlj+KYzA/5zqzMSweu3KGvb1aRZwvofas7xvt3UxzmUWMfRZmBe91i4AjutjQHcrRNq52QcHiC07GnUHLk2OWpWY7U0apcPR4MtJkC4aRJ1N/gF1053ftqeO8XyUheS5tovNlnsBPomk6kSf6r/NQXF+SlQfOYlwvqGhrcx959oVsAu3j4a3WXyeTeoCSKULUygkjCSAJIpQgCBCdCSBsIJyBCgBFGEkRtxCICCcESckkkgSSSIQBNr0GvaWvAIOoK6J9KmXGAlupupk3dRFwnBmBpyixN58FksdgH4WpacsyD9V63huHRSHNVnE+Fh4IcFgvJ3a9GcfUjLYDjLhkeDazXDoV6JwaoHUbANPNvW9+a8e4vhKmFfAnIdPotJ2R7bim30b4PIqLj1uJmfeq0naDj1XD2FPNI1aS0HobFQeDNxOIf6auzI1t2i4kxqZMwNh1lSOJ9u6ZbGVvO0FZ3F9sKtdwoYchpdqeQi56RKmY5ZTRlyTHu10wVEurVa7ie85zafSm0wDHUifCFYQhSYGtDRoAAPJOW7Gamnm5Xd2CKSKsgEIRSQBFJJAISRSQNIQT0CEAhBPSUIR0kQiiRSSSCAhFAKNxDFim3+I6fU9FJa6vrd4MF3GLTAE7uJ008VsOE8KDRcX3XmFOo5wk5TcAyL6TvurvhfaHEYcgMdmaP9N3eb5bgeBXHm4ss51XXg5scL3HqRoQ0BV2IwygcJ7b4eraqDSdyMvb7QJHmPNXNOvSq3p1GPH8LgfcFiy48sfcbceXHL7ZnjPCGVmFrhK8p492ddReYEibc17ljaELLcewAe0kC6rjyXGuuXHM528aqUnb5lxoV6lJ2djnMcLAixvqtZjaJEgAE6Ko4lw0sDBPenMVswz+TFycXxXfB+1b4ArNz/wAbYB1jvDTzsrjDdpMO85czmu5PaR+ixVChBv7Drr9+9TP2NtQQbEaHlyWlk237HhwlpBHMXRXn+Ex1Sg8NeXNnR4m4Hx8NQtdguKB0B8X0cPVP08UNrJJFFEhCUIpIGwjCKSAIFEoIDKSCSIcYSRSUJJJJNq1Q1pc4wAJKDhxHFGlTLg3M7RrdJO0nYblY92IrOyuc8l0d821mwgWDR96Sp+Ox5e6drwL2HNc8Mwcr/cqdK7Lh+Il8GBPsMXVq3kYuZ2t1jldVPEMLHebtqBaOoUnh2NDxldZ3uI69VMpZ/E5zvwx0HOPHdc8nUTzI+B/RPaJ2nz9k+33prD5+2Pv6bqyiSOI4hkRUqADlVqQRfYkeCa/iWIP+o8En8wI96bJ3OwAtz2HLmuc/dyVX4Y36WmeU9VDxDHuNyZ3M7+RKhV8HcnMD1vJPWb7q5yDX+3hG6ZXDYge0SLeRUzGRFyt9qoYWwMai8XPjbRS6NAiwI5a+3pCk5WiIItzFtk6Igmb+AuNPsaqdI24Yjh7KjHNeRAAjnJEgttb9QqfhpqUnejJJMywGYdrN/wALhzvO+i0QAGsnpzsNPKVF4hhWvaQDJF27AG89YgDUbqLEyrXgePzg03Wc3Y2MciOn3orVYbC14iXFrm3B0cNrW0PI25rXUMX3QXxBjK8WaZ0zfkdtGnI7KtXiWin0qZc4NAkkwAu+O4dUomHjXcGQq3KS6WmNs2ioIpKyATSnIFAoSRhJBwSSSUAFZ7i2PFR2Rplg32J5zuB0XTjONzONIEhg9cj8R/LPIb9fBVoFtPFTIi0qdPx52Uqi6LgC3z5/eyjzB+X0+nwXVjgRZSqlUYiTrtb4qlxlMU3iLNd6p5HXKfiPZsrMVDJvfrv9FyxdEPYWO0It0I0I5GyWbJdOuBxecQdQII0J0upmY2BNh71j8LinNfkcYeJh3P73WiwWNzW0dvoZjcApKmxPuNJv5z4BMqOvryvYnziyZ935oSOp+9t1ZR2NQR8LX13+q41W3uAPO+nX46IuqCIH2PFJ1Umw+Om9pvsg6U35dJuL7ezoEnix3tE+tGvvsmHxEDmAD0kA8v7otd4Rexg+3mfqpQcaojadI1tyvb7KL9jJABGhvHiB094TKhPrR43Gp5D580XARG4m/u1N/LqgquJ0odnizt418IsFouztcPoluoFoOkOGnW8qhxDSRv8AHRT+x9S9Rt9B8T9VSr4rmn6TDua+lL2NcCaZPebeZpOOo/gO2hGh33E3trUb6kSD12WOV5w+sH0WNcXfl5C1vgFj8nrVb/F73KrcJw6rVEsYSPLZRntIJBEEGCORW9dVbRYKdJoLo7oHvcTsFiePcLr0qprOe1weQS2CNr35/VRh5PfaMvG63EZAotMiUFr2yCkkkpHBQeMcQFCmXHU2aOv0U5ZDtZiJxDad4DAYHMk/RvsUDhTrF1yIkknn3ufNdPSzuVwomxkbef6otNtvh7FZVJ9NfSPCfqlm3bY+20bk6fJR8xFvcfqjhXgnz0mPfsgkCpoR9nT22T88Hnz6/cqMQQ6OZvp7Z+9l0NSRra3gTz++ZQVvG8JPebqL/YC44LEE30cPI+5XDwHCBr0+XRUuJpllTMIvrFh4Wsq2LRe4TF5hlJv8foVKMzBjSb9f0sqJlxmGm/RT8Li9iBOxtv8ANTKrcU9rZPl1+emwSD9Ofifefoubq5O8/BNeRoPvxV1XZ7wNzOptFzGhSzA7HyIEFMp0SW5i12XQEg5Z5Tog6roANOXjO3xTaNOoqf3G0/FF750EjTf4+BXH00iTpO256zc/fkS7u3PI7RvGikMrsFjJHUnfzUjsdT/zcQZ/II8Z28lGmeeuvKI3Nl37JVAMRXZ+ZrHDwaXA/wC4KuS2LVxy1U/jPDnU6VMw9oJLWmdHmIc/k3X7hR8CYqsn83wBPyWi7U0zUwRys9JlObIDBIgiW/xCZWDyfyunoeJ+PaRgn08PRhzsxIBc92rvoOixfaPiOIxTg2hTqmmPx5crT/K5xAcOoVj2W4FVLQ/GvLhAyUdQOtQ7/wAunOdBJ7Vcea0Cm0ZnzYN18I1Kzaat9srgsLVYGgkG5L4vln8IKsCufCsJiKuZzgabf45a528BpvHUro0WHgtnjXqxi8qTcpSijCS1MiOsR2ifGMe7k1gHjln5ra1HhoLjoASfACSvMHYh1Z7qjvxEnXmdJ+9FCVjTdPPrzXR5t05Tp9wolJx2ER96qTSdOkddJ8lKDmPJt9UalzckyPOQuL2xoB4bIGufxT47jzQ060ahcCw+sNOo0sjh6pynnMLjjZEVG6gbbjcW1THVBMt9V0HlB3+CCxpG3kuOMp5hr15DohRqiPp7F09JaJ9/lb72QVtBxaY/VS+o0+Ci4lkHVdcPVGmtrz93UJXlCg5rGuqFjM/qB5gua4RnywQ1v8ToB2mLCm17nNaAS6wAAMqO7H5T6UMBqkg+kec4bA1ax0jOTeTIGwFo0XYPH0y8tcJqiXZiZLm6mJ3m53KpnyXHHa/HxzPKRoOJNbQ4WKbgAcumnedr/wBxPuWEptLtAdz7L6eC2HG8Fice/KxmSlTPrPOVr3bBsSTHOIlZTimAq4Z2SoInQ2IPgVz8fKau73XXyse5qdRxqEAQ3RBtRuscouYsb8jtzXD0hJgdfDrqiAb7xr0C1bY3XNNojW8Rty209658FrZcbTP5w5h21BI98JhMj1vLefYomIrFpbUGrHAjrBn4woq2L0TEB2Xu+sLt8RePPTzUpvaekaGaoS0HukTBB0hxm0HyUOniA6MhGY0zVAJuWDLJA3u9tvoVn+C8JY7E1MPX9V5dldO4NwNr6+Syc8l7a/Gtm43vAapqHLiH5G5Q5rQYLmncnUDW1ipXFeMUKNMtp+jYAbmQB1JJ1PvXh9fG4h9f0dGo4tD3NpketkBOWXamytWcEYxvpcVVNrkAy72lcbx6913nJ8u5Gr4l2iBMU3F5dZjWm7j8h1OilUWENaDqAAfEC6reC4CmA2sKeUlsNDmhrg03lwBME2+7K2Wrh45jGXm5LnSRQSXZwQsS1ppvDjDcrg48hBn3LzjB1qYAaNAAJO/3qt9xsj9mrToabwY6tI+a8/ZhgQLmAD3Rz681CXb0vpDDXNAnTRMfhntPddfXx8gnMwNN22Q+fuXekws/GCIi/XmVJsz02eGvBY6LH8J+hXOpQq6ekBG0g23tdSiWutY+YGi4AvbowFu4kE/07ohwo4hzCGVW906ETHtOiae7LORt/KbhS87Koyz/AEutE/fRV2JMEASbQ06mDseog+1RUpTcRb7tzhSGVfxEi2n3uq51Smwd65/KNZ62Tm4iILx/KwT702lMqum5uTdc2gzuSdOvKOq5NqnoDyFyrvstg5rio5tm6Tfvbez5hVzymM2thh88pi3WE7PYVuDFKpTDqj2jM4esHn8rtAAfgpHZ7sZRw7hVOZ72zDnmwnkBZJ2KJLdova/uV9g89WmG5rDU9F5v+mV329T/ACxmuj8ZxNjG+tAHlp05LD8cfWx4ijQLmNM+kMNDiLANc6A7y5LX43AYdrg+oA7KDZxOXxLdHeareP8AG2sZJMaQBrf1QBzPJThlZZYjPGXGz+vNyzKYIuCQ4cjy+/chiKhNvv2qXjqjy97qjS0uObKRETuWnTnKry+bffivVl3Hj2aroXaC2mosoeLBy90STZdc4/X7+7oVAZHj038NVGV1Npxm7pecMotqY2mwSQzDUMknUMdmd5wfcVadscCKOHdXDi1zYyxaC4wPeVm+Osfh3UMW3MI7ji2xA2vsrvtPxZmI4eMr83eYXGwMg7gWF1kv5WVsn4zLFhOE491B2dkSWFt9gSLj2LU9j8K3EZ61VwqFjwGtMw0xOYjQzNvA+WTp4OpXqtpUWOfUfZrWiScrSTA8GkrYdguGVKRrOdmDZawAgiS3vF0ET+KPM8l3mM3tnuV1priEESE1dFBlFCUURpnu09bLhyPzuDffmPwWTawCN/v3q97ZP/dN55z4kZdB5+9UNOoQI9yJdRRLjuTsB9Auf7MRqTPWR7kc3MJ/pQBqfP3baIhzaMp9VvjN/onOqEX+f0SL51dtv92C5PaBrHPmPgiQq42l+JjSfG5PkbKvdXNU91raYGpJTcfUbFm39y4YSlP4SVXaUpjKLfWeHHf9E8Yui2cjXOOnq/PZKng/+mfNaDgnZfEVyDlbSZN3EXj+Eb/BRllMZupxxuV1FPhTXquDadMCfb/Zbvh+A9ExjZlwHePNx1V9w7gtOgyKYk/ic4y4x1+QsueKpRdYOblufU9PR4OGcfd9m03RC60uKGkT3rHYKmNZoccziBrry2XE4rPZoIHtd+i5aaLWgxNSri6rXu/dtEhvM8yOS4VTRpONWP8ANGYteSXZDESATA9m52VfgeIlodSoglzrZjoJ3JUfiHB6bL167nMDe7Tp90uO5c+ZMnlHir4xzyvSk43xk4h+ctAMAeepHgCSqppJGtuWgSeWzlbZsmBNhy8Uc0r08JrGR5Gd3la6FtoH978v7ossYPO/Pmml4FhfXz2XL7+VvvZTUS6rdVabH4fI8AgtggrzXFYc0ahY1xLD8BcStXU4oPRQDeFksXVJesnFLK2c1li57IY/E0sS79laz0lRmQ1XNJNJhMvc0yMpNhOvKF6Dh6LWMDGiAP7k+ZJKw/YB3/mXjnSPue36reELTGSlKajCQCsFCKMJKEKHiFJr6wa4BwDJgidT/wDlR39m6Tj3XPZ0HeHsd8ipGK/5if8Apj/c5T8GbhYOXPLHO6r0uHjxy45uKr/giq4dyrSdP5g5nwzKJiex2Lb/AKbHfyvb84J9i9BwlUNC4YnjLAYuTyaC72gKJ5GZfFweW4vhleme9Se32HpqFV1nBoP0Xo3HaFSs3uAg7Tb2rHYzsninmB6Lzc75NXbDn37cuTxtfrusrUq5ndFf8Fp1qhy0ac7EmzR/MflqtDwTsK1kOrOzn8oEN89z7lrsPg2sGVrQ0CwAEBM/I1+ph4tveSp4R2cayHVf8x+uncHgN/E+5aakYbAkLkBCY/FNbr9+Cy3K5XdbJjjjNYplI2i46kT8FFxVHXTw/uoz+NO2EDyJ99gq/iXF6QYXVH+Uk36AG5U6RbpX8QyNfLiIGgIIPnEyojuObNaD4CyzvE+PB7pjy1UB3GuQ9y7Y8NcMvIn02De0pYe9LeobPlEqh4x2hfiKt7CLAWsqCrj3O6LjReS8Ez9hdsOKS7Z+TnuU0uRUjx5KTh5I+9+agUI1U2mZ5rQzU90Aaj6X3XQGBzsDHK3Q8rXCimoS7523su7dEQi4iuWy07LgzDE0n1zZoc2m3q4y4+xo94UvD8KqYnEZGaQC50d1o5mPcN1a9r6QZ+zYCg3cOk6Znn0bS47kkuJXP46dLlsOxDcuLjnh83/yNN3zW+WR4RQFPilRjdGYdjR5NoD5LXK0VpIhKEYUhQkikpGcxn7/APoH+5yn4TUJJLzOf9q9Xxv0ixxPq+Sh8H/cD+Y/FJJUnp1Waj4f1kklz+3T6TDom1NUkl0jnTCqTi/rDxSSRCFV+SxHG/XPgUkl34fbhz/qo0woJLZPTziC70dkUkFhT+SlYbby+KSSurXVnrnxXapskkg13Y390/8An+QVV2t/52l/LT/+xySSrUpPC/8A1jF/+2z/AG0Vq0kkgcgEklYOSSSQf//Z','2016-01-20 10:55:27','2016-01-22 12:41:54','2015-12-30 18:30:00');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authority`
--

DROP TABLE IF EXISTS `authority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authority` (
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authority`
--

LOCK TABLES `authority` WRITE;
/*!40000 ALTER TABLE `authority` DISABLE KEYS */;
INSERT INTO `authority` VALUES ('ROLE_ADMIN'),('ROLE_GUEST'),('ROLE_USER');
/*!40000 ALTER TABLE `authority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_strategy_configuration_details`
--

DROP TABLE IF EXISTS `business_strategy_configuration_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_strategy_configuration_details` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `revenue_name` varchar(250) NOT NULL,
  `month_name` varchar(250) NOT NULL,
  `monthly_target` double NOT NULL,
  `quaterly_target` double NOT NULL,
  `yearly_target` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_strategy_configuration_details`
--

LOCK TABLES `business_strategy_configuration_details` WRITE;
/*!40000 ALTER TABLE `business_strategy_configuration_details` DISABLE KEYS */;
INSERT INTO `business_strategy_configuration_details` VALUES (193,'businessRevenueTarget','Dec',4,12,48),(194,'businessRevenueTarget','Jan',4,12,48),(195,'businessRevenueTarget','Feb',4,12,48),(196,'businessRevenueTarget','Mar',4,12,48),(197,'businessRevenueTarget','Apr',4,12,48),(198,'businessRevenueTarget','May',4,12,48),(199,'businessRevenueTarget','Jun',4,12,48),(200,'businessRevenueTarget','Jul',4,12,48),(201,'businessRevenueTarget','Aug',4,12,48),(202,'businessRevenueTarget','Sep',4,12,48),(203,'businessRevenueTarget','Oct',4,12,48),(204,'businessRevenueTarget','Nov',4,12,48),(205,'marketingInfluencedRevenueTarget','Dec',10,26,101),(206,'marketingInfluencedRevenueTarget','Jan',8,26,101),(207,'marketingInfluencedRevenueTarget','Feb',8,26,101),(208,'marketingInfluencedRevenueTarget','Mar',9,25,101),(209,'marketingInfluencedRevenueTarget','Apr',8,25,101),(210,'marketingInfluencedRevenueTarget','May',8,25,101),(211,'marketingInfluencedRevenueTarget','Jun',9,25,101),(212,'marketingInfluencedRevenueTarget','Jul',8,25,101),(213,'marketingInfluencedRevenueTarget','Aug',8,25,101),(214,'marketingInfluencedRevenueTarget','Sep',9,25,101),(215,'marketingInfluencedRevenueTarget','Oct',8,25,101),(216,'marketingInfluencedRevenueTarget','Nov',8,25,101);
/*!40000 ALTER TABLE `business_strategy_configuration_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `continent`
--

DROP TABLE IF EXISTS `continent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `continent` (
  `id` int(11) NOT NULL,
  `continent_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `continent`
--

LOCK TABLES `continent` WRITE;
/*!40000 ALTER TABLE `continent` DISABLE KEYS */;
INSERT INTO `continent` VALUES (1,'Africa'),(2,'Antarctica'),(3,'Asia'),(4,'Europe'),(5,'North America'),(6,'Oceania'),(7,'South America');
/*!40000 ALTER TABLE `continent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(50) NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `continent_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `3_geo_id` int(11) NOT NULL,
  `4_geo_id` int(11) NOT NULL,
  `is_selected` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_continent_id` (`continent_id`),
  KEY `fk_country_region_id` (`region_id`),
  KEY `fk_3_geo_id` (`3_geo_id`),
  KEY `fk_4_geo_id` (`4_geo_id`),
  CONSTRAINT `fk_3_geo_id` FOREIGN KEY (`3_geo_id`) REFERENCES `geo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_4_geo_id` FOREIGN KEY (`4_geo_id`) REFERENCES `geo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_continent_id` FOREIGN KEY (`continent_id`) REFERENCES `continent` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_country_region_id` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'Antigua Barbuda',0,1,1,1,2,1),(2,'Argentina',0,1,1,1,2,1),(3,'Bahamas',0,1,1,1,2,1),(4,'Barbados',0,1,1,1,2,1),(5,'Belize',0,1,1,1,2,1),(6,'Bermuda',0,1,1,1,2,1),(7,'Bolivia',0,1,1,1,2,1),(8,'Brazil',0,1,1,1,2,1),(9,'Canada',0,1,1,1,2,1),(10,'Chile',0,1,1,1,2,1),(11,'Colombia',0,1,1,1,2,1),(12,'Costa Rica',0,1,1,1,2,1),(13,'Cuba',0,1,1,1,2,1),(14,'Dominica',0,1,1,1,2,1),(15,'Dominican Republic',0,1,1,1,2,1),(16,'Ecuador',0,1,1,1,2,1),(17,'El Salvador',0,1,1,1,2,1),(18,'French Guyana',0,1,1,1,2,1),(19,'Greenland',0,1,1,1,2,1),(20,'Grenada',0,1,1,1,2,1),(21,'Guadelupe',0,1,1,1,2,1),(22,'Guatemala',0,1,1,1,2,1),(23,'Guyana',0,1,1,1,2,1),(24,'Haiti',0,1,1,1,2,1),(25,'Honduras',0,1,1,1,2,1),(26,'Jamaica',0,1,1,1,2,1),(27,'Martinique',0,1,1,1,2,1),(28,'Mexico',0,1,1,1,2,1),(29,'Netherland Antilles',0,1,1,1,2,1),(30,'Nicaragua',0,1,1,1,2,1),(31,'Panama',0,1,1,1,2,1),(32,'Paraguay',0,1,1,1,2,1),(33,'Peru',0,1,1,1,2,1),(34,'Puerto Rico',0,1,1,1,2,1),(35,'St. Kitts & Nevis',0,1,1,1,2,1),(36,'Suriname',0,1,1,1,2,1),(37,'Trinidad and Tobago',0,1,1,1,2,1),(38,'U.S. Virgin Islands',0,1,1,1,2,1),(39,'United States',0,1,1,1,2,1),(40,'Uruguay',0,1,1,1,2,1),(41,'Venezuela',0,1,1,1,2,1),(42,'Albania',0,1,2,1,2,1),(43,'Algeria',0,1,2,1,2,1),(44,'Andorra',0,1,2,1,2,1),(45,'Angola',0,1,2,1,2,1),(46,'Austria',0,1,2,1,2,1),(47,'Bahrain',0,1,2,1,2,1),(48,'Belarus',0,1,2,1,2,1),(49,'Belgium',0,1,2,1,2,1),(50,'Benin',0,1,2,1,2,1),(51,'Bosnia and Herzegovina',0,1,2,1,2,1),(52,'Botswana',0,1,2,1,2,1),(53,'Bulgaria',0,1,2,1,2,1),(54,'Burkina Faso',0,1,2,1,2,1),(55,'Burundi',0,1,2,1,2,1),(56,'Cameroon',0,1,2,1,2,1),(57,'Cape Verde',0,1,2,1,2,1),(58,'Central African Republic',0,1,2,1,2,1),(59,'Chad',0,1,2,1,2,1),(60,'Comoros',0,1,2,1,2,1),(61,'Croatia',0,1,2,1,2,1),(62,'Cyprus',0,1,2,1,2,1),(63,'Czech Republic',0,1,2,1,2,1),(64,'Democratic Republic of the Congo',0,1,2,1,2,1),(65,'Denmark',0,1,2,1,2,1),(66,'Djibouti',0,1,2,1,2,1),(67,'Egypt',0,1,2,1,2,1),(68,'Equatorial Guinea',0,1,2,1,2,1),(69,'Eritrea',0,1,2,1,2,1),(70,'Estonia',0,1,2,1,2,1),(71,'Ethiopia',0,1,2,1,2,1),(72,'Faroe Islands',0,1,2,1,2,1),(73,'Finland',0,1,2,1,2,1),(74,'France',0,1,2,1,2,1),(75,'Gabon',0,1,2,1,2,1),(76,'Gambia',0,1,2,1,2,1),(77,'Georgia',0,1,2,1,2,1),(78,'Germany',0,1,2,1,2,1),(79,'Ghana',0,1,2,1,2,1),(80,'Gibraltar',0,1,2,1,2,1),(81,'Greece',0,1,2,1,2,1),(82,'Guernsey',0,1,2,1,2,1),(83,'Guinea',0,1,2,1,2,1),(84,'Guinea-Bissau',0,1,2,1,2,1),(85,'Hungary',0,1,2,1,2,1),(86,'Iceland',0,1,2,1,2,1),(87,'Iran',0,1,2,1,2,1),(88,'Iraq',0,1,2,1,2,1),(89,'Ireland',0,1,2,1,2,1),(90,'Isle Of Man',0,1,2,1,2,1),(91,'Israel',0,1,2,1,2,1),(92,'Italy',0,1,2,1,2,1),(93,'Ivory Coast',0,1,2,1,2,1),(94,'Jersey',0,1,2,1,2,1),(95,'Jordan',0,1,2,1,2,1),(96,'Kenya',0,1,2,1,2,1),(97,'Kuwait',0,1,2,1,2,1),(98,'Latvia',0,1,2,1,2,1),(99,'Lebanon',0,1,2,1,2,1),(100,'Lesotho',0,1,2,1,2,1),(101,'Liberia',0,1,2,1,2,1),(102,'Libya',0,1,2,1,2,1),(103,'Liechtenstein',0,1,2,1,2,1),(104,'Lithuania',0,1,2,1,2,1),(105,'Luxembourg',0,1,2,1,2,1),(106,'Macedonia',0,1,2,1,2,1),(107,'Madagascar',0,1,2,1,2,1),(108,'Malawi',0,1,2,1,2,1),(109,'Mali',0,1,2,1,2,1),(110,'Malta',0,1,2,1,2,1),(111,'Mauritania',0,1,2,1,2,1),(112,'Mauritius',0,1,2,1,2,1),(113,'Moldova',0,1,2,1,2,1),(114,'Monaco',0,1,2,1,2,1),(115,'Montenegro',0,1,2,1,2,1),(116,'Morocco',0,1,2,1,2,1),(117,'Mozambique',0,1,2,1,2,1),(118,'Namibia',0,1,2,1,2,1),(119,'Netherlands',0,1,2,1,2,1),(120,'Niger',0,1,2,1,2,1),(121,'Nigeria',0,1,2,1,2,1),(122,'Norway',0,1,2,1,2,1),(123,'Oman',0,1,2,1,2,1),(124,'Palestine',0,1,2,1,2,1),(125,'Poland',0,1,2,1,2,1),(126,'Portugal',0,1,2,1,2,1),(127,'Qatar',0,1,2,1,2,1),(128,'Romania',0,1,2,1,2,1),(129,'Rwanda',0,1,2,1,2,1),(130,'San Marino',0,1,2,1,2,1),(131,'Sao Tome & Principe',0,1,2,1,2,1),(132,'Saudi Arabia',0,1,2,1,2,1),(133,'Senegal',0,1,2,1,2,1),(134,'Serbia',0,1,2,1,2,1),(135,'Slovakia',0,1,2,1,2,1),(136,'Slovenia',0,1,2,1,2,1),(137,'Somalia',0,1,2,1,2,1),(138,'South Africa',0,1,2,1,2,1),(139,'Spain',0,1,2,1,2,1),(140,'Sudan',0,1,2,1,2,1),(141,'Swaziland',0,1,2,1,2,1),(142,'Sweden',0,1,2,1,2,1),(143,'Switzerland',0,1,2,1,2,1),(144,'Syria',0,1,2,1,2,1),(145,'Tanzania',0,1,2,1,2,1),(146,'Togo',0,1,2,1,2,1),(147,'Tunisia',0,1,2,1,2,1),(148,'Turkey',0,1,2,1,2,1),(149,'Uganda',0,1,2,1,2,1),(150,'Ukraine',0,1,2,1,2,1),(151,'United Arab Emirates',0,1,2,1,2,1),(152,'United Kingdom',0,1,2,1,2,1),(153,'Vatican City',0,1,2,1,2,1),(154,'Western Sahara',0,1,2,1,2,1),(155,'Yemen',0,1,2,1,2,1),(156,'Zambia',0,1,2,1,2,1),(157,'Zimbabwe (Rhodesia)',0,1,2,1,2,1),(158,' Afghanistan',0,1,3,1,2,1),(159,' American Samoa',0,1,3,1,2,1),(160,' Australia',0,1,3,1,2,1),(161,' Bangladesh',0,1,3,1,2,1),(162,' Bhutan',0,1,3,1,2,1),(163,' Brunei',0,1,3,1,2,1),(164,' Cambodia',0,1,3,1,2,1),(165,' China',0,1,3,1,2,1),(166,' Cook Islands',0,1,3,1,2,1),(167,' East Timor',0,1,3,1,2,1),(168,' Federated States of Micronesia',0,1,3,1,2,1),(169,' Fiji',0,1,3,1,2,1),(170,' French Polynesia',0,1,3,1,2,1),(171,' Guam',0,1,3,1,2,1),(172,' Hong Kong (China)',0,1,3,1,2,1),(173,' India',0,1,3,1,2,1),(174,' Indonesia',0,1,3,1,2,1),(175,' Japan',0,1,3,1,0,1),(176,' Kiribati',0,1,3,1,2,1),(177,' Laos',0,1,3,1,2,1),(178,' Macau (China)',0,1,3,1,2,1),(179,' Malaysia',0,1,3,1,2,1),(180,' Maldives',0,1,3,1,2,1),(181,' Marshall Islands',0,1,3,1,2,1),(182,' Mongolia',0,1,3,1,2,1),(183,' Myanmar',0,1,3,1,2,1),(184,' Nauru',0,1,3,1,2,1),(185,' Nepal',0,1,3,1,2,1),(186,' New Caledonia (associate member)',0,1,3,1,2,1),(187,' New Zealand',0,1,3,1,2,1),(188,' Niue',0,1,3,1,2,1),(189,' North Korea',0,1,3,1,2,1),(190,' Northern Mariana Islands',0,1,3,1,2,1),(191,' Pakistan',0,1,3,1,2,1),(192,' Palau',0,1,3,1,2,1),(193,' Papua New Guinea',0,1,3,1,2,1),(194,' Philippines',0,1,3,1,2,1),(195,' Pitcairn Islands',0,1,3,1,2,1),(196,' Samoa',0,1,3,1,2,1),(197,' Singapore',0,1,3,1,2,1),(198,' Solomon Islands',0,1,3,1,2,1),(199,' South Korea',0,1,3,1,2,1),(200,' Sri Lanka',0,1,3,1,2,1),(201,' Taiwan',0,1,3,1,2,1),(202,' Thailand',0,1,3,1,2,1),(203,' Tokelau',0,1,3,1,2,1),(204,' Tonga',0,1,3,1,2,1),(205,' Tuvalu',0,1,3,1,2,1),(206,' Vanuatu',0,1,3,1,2,1),(207,' Vietnam',0,1,3,1,2,1),(208,' Wallis and Futuna',0,1,3,1,2,1);
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_instance`
--

DROP TABLE IF EXISTS `crm_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_instance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_instance`
--

LOCK TABLES `crm_instance` WRITE;
/*!40000 ALTER TABLE `crm_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_instance_sales_stage`
--

DROP TABLE IF EXISTS `crm_instance_sales_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_instance_sales_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crm_instance_id` int(11) NOT NULL,
  `crm_sales_stage_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_crm_instance_sales_stage_crm_instance_id` (`crm_instance_id`),
  KEY `idx_crm_instance_sales_stage_crm_sales_stage_id` (`crm_sales_stage_id`),
  CONSTRAINT `fk_crm_instance_sales_stage_ciid` FOREIGN KEY (`crm_instance_id`) REFERENCES `crm_instance` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_crm_instance_sales_stage_cssid` FOREIGN KEY (`crm_sales_stage_id`) REFERENCES `crm_sales_stage` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_instance_sales_stage`
--

LOCK TABLES `crm_instance_sales_stage` WRITE;
/*!40000 ALTER TABLE `crm_instance_sales_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_instance_sales_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_sales_stage`
--

DROP TABLE IF EXISTS `crm_sales_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_sales_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stage` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_sales_stage`
--

LOCK TABLES `crm_sales_stage` WRITE;
/*!40000 ALTER TABLE `crm_sales_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_sales_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(64) DEFAULT NULL,
  `currency_code` char(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_currency_name` (`currency_name`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES (1,'Andorran Peseta','ADP'),(2,'United Arab Emirates Dirham','AED'),(3,'Afghanistan Afghani','AFA'),(4,'Albanian Lek','ALL'),(5,'Netherlands Antillian Guilder','ANG'),(6,'Angolan Kwanza','AOK'),(7,'Argentine Peso','ARS'),(8,'Australian Dollar','AUD'),(9,'Aruban Florin','AWG'),(10,'Barbados Dollar','BBD'),(11,'Bangladeshi Taka','BDT'),(12,'Bulgarian Lev','BGN'),(13,'Bahraini Dinar','BHD'),(14,'Burundi Franc','BIF'),(15,'Bermudian Dollar','BMD'),(16,'Brunei Dollar','BND'),(17,'Bolivian Boliviano','BOB'),(18,'Brazilian Real','BRL'),(19,'Bahamian Dollar','BSD'),(20,'Bhutan Ngultrum','BTN'),(21,'Burma Kyat','BUK'),(22,'Botswanian Pula','BWP'),(23,'Belize Dollar','BZD'),(24,'Canadian Dollar','CAD'),(25,'Swiss Franc','CHF'),(26,'Chilean Unidades de Fomento','CLF'),(27,'Chilean Peso','CLP'),(28,'Yuan (Chinese) Renminbi','CNY'),(29,'Colombian Peso','COP'),(30,'Costa Rican Colon','CRC'),(31,'Czech Republic Koruna','CZK'),(32,'Cuban Peso','CUP'),(33,'Cape Verde Escudo','CVE'),(34,'Cyprus Pound','CYP'),(35,'Danish Krone','DKK'),(36,'Dominican Peso','DOP'),(37,'Algerian Dinar','DZD'),(38,'Ecuador Sucre','ECS'),(39,'Egyptian Pound','EGP'),(40,'Estonian Kroon (EEK)','EEK'),(41,'Ethiopian Birr','ETB'),(42,'Euro','EUR'),(43,'Fiji Dollar','FJD'),(44,'Falkland Islands Pound','FKP'),(45,'British Pound','GBP'),(46,'Ghanaian Cedi','GHC'),(47,'Gibraltar Pound','GIP'),(48,'Gambian Dalasi','GMD'),(49,'Guinea Franc','GNF'),(50,'Guatemalan Quetzal','GTQ'),(51,'Guinea-Bissau Peso','GWP'),(52,'Guyanan Dollar','GYD'),(53,'Hong Kong Dollar','HKD'),(54,'Honduran Lempira','HNL'),(55,'Haitian Gourde','HTG'),(56,'Hungarian Forint','HUF'),(57,'Indonesian Rupiah','IDR'),(58,'Irish Punt','IEP'),(59,'Israeli Shekel','ILS'),(60,'Indian Rupee','INR'),(61,'Iraqi Dinar','IQD'),(62,'Iranian Rial','IRR'),(63,'Jamaican Dollar','JMD'),(64,'Jordanian Dinar','JOD'),(65,'Japanese Yen','JPY'),(66,'Kenyan Schilling','KES'),(67,'Kampuchean (Cambodian) Riel','KHR'),(68,'Comoros Franc','KMF'),(69,'North Korean Won','KPW'),(70,'(South) Korean Won','KRW'),(71,'Kuwaiti Dinar','KWD'),(72,'Cayman Islands Dollar','KYD'),(73,'Lao Kip','LAK'),(74,'Lebanese Pound','LBP'),(75,'Sri Lanka Rupee','LKR'),(76,'Liberian Dollar','LRD'),(77,'Lesotho Loti','LSL'),(78,'Libyan Dinar','LYD'),(79,'Moroccan Dirham','MAD'),(80,'Malagasy Franc','MGF'),(81,'Mongolian Tugrik','MNT'),(82,'Macau Pataca','MOP'),(83,'Mauritanian Ouguiya','MRO'),(84,'Maltese Lira','MTL'),(85,'Mauritius Rupee','MUR'),(86,'Maldive Rufiyaa','MVR'),(87,'Malawi Kwacha','MWK'),(88,'Mexican Peso','MXP'),(89,'Malaysian Ringgit','MYR'),(90,'Mozambique Metical','MZM'),(91,'Namibian Dollar','NAD'),(92,'Nigerian Naira','NGN'),(93,'Nicaraguan Cordoba','NIO'),(94,'Norwegian Kroner','NOK'),(95,'Nepalese Rupee','NPR'),(96,'New Zealand Dollar','NZD'),(97,'Omani Rial','OMR'),(98,'Panamanian Balboa','PAB'),(99,'Peruvian Nuevo Sol','PEN'),(100,'Papua New Guinea Kina','PGK'),(101,'Philippine Peso','PHP'),(102,'Pakistan Rupee','PKR'),(103,'Polish Zloty','PLN'),(104,'Paraguay Guarani','PYG'),(105,'Qatari Rial','QAR'),(106,'Romanian Leu','RON'),(107,'Rwanda Franc','RWF'),(108,'Saudi Arabian Riyal','SAR'),(109,'Solomon Islands Dollar','SBD'),(110,'Seychelles Rupee','SCR'),(111,'Sudanese Pound','SDP'),(112,'Swedish Krona','SEK'),(113,'Singapore Dollar','SGD'),(114,'St. Helena Pound','SHP'),(115,'Sierra Leone Leone','SLL'),(116,'Somali Schilling','SOS'),(117,'Suriname Guilder','SRG'),(118,'Sao Tome and Principe Dobra','STD'),(119,'Russian Ruble','RUB'),(120,'El Salvador Colon','SVC'),(121,'Syrian Potmd','SYP'),(122,'Swaziland Lilangeni','SZL'),(123,'Thai Baht','THB'),(124,'Tunisian Dinar','TND'),(125,'Tongan Paanga','TOP'),(126,'East Timor Escudo','TPE'),(127,'Turkish Lira','TRY'),(128,'Trinidad and Tobago Dollar','TTD'),(129,'Taiwan Dollar','TWD'),(130,'Tanzanian Schilling','TZS'),(131,'Uganda Shilling','UGX'),(132,'US Dollar','USD'),(133,'Uruguayan Peso','UYU'),(134,'Venezualan Bolivar','VEF'),(135,'Vietnamese Dong','VND'),(136,'Vanuatu Vatu','VUV'),(137,'Samoan Tala','WST'),(138,'CommunautÃ© FinanciÃ¨re Africaine BEAC, Francs','XAF'),(139,'Silver, Ounces','XAG'),(140,'Gold, Ounces','XAU'),(141,'East Caribbean Dollar','XCD'),(142,'International Monetary Fund (IMF) Special Drawing Rights','XDR'),(143,'CommunautÃ© FinanciÃ¨re Africaine BCEAO - Francs','XOF'),(144,'Palladium Ounces','XPD'),(145,'Comptoirs FranÃ§ais du Pacifique Francs','XPF'),(146,'Platinum, Ounces','XPT'),(147,'Democratic Yemeni Dinar','YDD'),(148,'Yemeni Rial','YER'),(149,'New Yugoslavia Dinar','YUD'),(150,'South African Rand','ZAR'),(151,'Zambian Kwacha','ZMK'),(152,'Zaire Zaire','ZRZ'),(153,'Zimbabwe Dollar','ZWD'),(154,'Slovak Koruna','SKK'),(155,'Armenian Dram','AMD');
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_exchange_rates`
--

DROP TABLE IF EXISTS `currency_exchange_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency_exchange_rates` (
  `base_currency` varchar(5) NOT NULL,
  `quote_currency` varchar(5) NOT NULL,
  `exchange_rate` float NOT NULL,
  `symbol` varchar(10) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`symbol`,`date`),
  KEY `Date_index` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_exchange_rates`
--

LOCK TABLES `currency_exchange_rates` WRITE;
/*!40000 ALTER TABLE `currency_exchange_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `currency_exchange_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_view`
--

DROP TABLE IF EXISTS `dashboard_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_view` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `metadata` mediumtext,
  `filter` varchar(100) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dashboard_view_url_unique` (`url`,`filter`),
  KEY `FK_dashoard_view_created_by` (`created_by`),
  CONSTRAINT `FK_dashoard_view_created_by` FOREIGN KEY (`created_by`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_view`
--

LOCK TABLES `dashboard_view` WRITE;
/*!40000 ALTER TABLE `dashboard_view` DISABLE KEYS */;
INSERT INTO `dashboard_view` VALUES (12,'dashboard/analyze/measure/win-loss-trend-analysis/competitor?chartType=columnStacked','view metadata','view filter','2015-12-11 10:50:22','guest@phaladata.com');
/*!40000 ALTER TABLE `dashboard_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo`
--

DROP TABLE IF EXISTS `geo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo`
--

LOCK TABLES `geo` WRITE;
/*!40000 ALTER TABLE `geo` DISABLE KEYS */;
INSERT INTO `geo` VALUES (1,'3 Geo Setup'),(2,'4 Geo Setup');
/*!40000 ALTER TABLE `geo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_business_strategy`
--

DROP TABLE IF EXISTS `global_business_strategy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global_business_strategy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `total_revenue_target` double NOT NULL,
  `marketing_inf_revenue_target` double NOT NULL,
  `fiscal_start` varchar(45) NOT NULL COMMENT 'MM/DD',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_business_strategy`
--

LOCK TABLES `global_business_strategy` WRITE;
/*!40000 ALTER TABLE `global_business_strategy` DISABLE KEYS */;
INSERT INTO `global_business_strategy` VALUES (16,48,101,'2015-12-01T06:30:00.000Z');
/*!40000 ALTER TABLE `global_business_strategy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `impact_indicator_target`
--

DROP TABLE IF EXISTS `impact_indicator_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impact_indicator_target` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indicator_name` varchar(50) NOT NULL,
  `target_value` decimal(10,0) NOT NULL,
  `valid_from` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `valid_upto` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impact_indicator_target`
--

LOCK TABLES `impact_indicator_target` WRITE;
/*!40000 ALTER TABLE `impact_indicator_target` DISABLE KEYS */;
INSERT INTO `impact_indicator_target` VALUES (1,'NEWCUSTOMER',2,'2016-01-01 06:30:00','2016-01-31 06:30:00','2016-01-25 11:12:28','2016-01-25 11:12:28'),(2,'AVGDEALSIZE',9,'2016-01-01 06:30:00','2016-01-31 06:30:00','2016-01-25 11:12:34','2016-01-25 11:12:34'),(3,'AVGSELLPRICE',102,'2016-01-01 06:30:00','2016-01-31 06:30:00','2016-01-25 11:12:35','2016-01-25 11:12:35'),(4,'TOPREVENUEACCOUNTS',1,'2016-01-01 06:30:00','2016-01-31 06:30:00','2016-01-25 11:12:36','2016-01-25 11:12:36'),(5,'TOPREVENUEACCOUNTS_QUALIFIER',32,'2016-01-01 06:30:00','2016-01-31 06:30:00','2016-01-25 11:12:37','2016-01-25 11:12:37'),(6,'NUMDEALSCLOSED',4,'2016-01-01 06:30:00','2016-01-31 06:30:00','2016-01-25 11:12:38','2016-01-25 11:12:38'),(7,'AVGTIMETOREVENUE',72,'2016-01-01 06:30:00','2016-01-31 06:30:00','2016-01-25 11:12:39','2016-01-25 11:12:39'),(8,'MARKETINGSPENDROI',81,'2016-01-01 06:30:00','2016-01-31 06:30:00','2016-01-25 11:12:40','2016-01-25 11:12:40'),(9,'CUSTOMERACQUISITIONCOST',5,'2016-01-01 06:30:00','2016-01-31 06:30:00','2016-01-25 11:12:41','2016-01-25 11:12:41'),(10,'AVGCOSTPEROPPORTUNITY',6,'2016-01-01 06:30:00','2016-01-31 06:30:00','2016-01-25 11:12:41','2016-01-25 11:12:41'),(11,'COMPETITIVEWINRATE',11,'2016-01-01 06:30:00','2016-01-31 06:30:00','2016-01-25 11:12:42','2016-01-25 11:12:42');
/*!40000 ALTER TABLE `impact_indicator_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `industry`
--

DROP TABLE IF EXISTS `industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `industry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `industry_name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_industry_name` (`industry_name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `industry`
--

LOCK TABLES `industry` WRITE;
/*!40000 ALTER TABLE `industry` DISABLE KEYS */;
INSERT INTO `industry` VALUES (1,'Consumer Goods and Services'),(2,'Energy'),(3,'Financials'),(4,'Government Agencies'),(5,'Healthcare'),(6,'High Technology'),(7,'Industrials'),(8,'Materials'),(9,'Retail'),(10,'Telecommunications'),(11,'Utilities');
/*!40000 ALTER TABLE `industry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_history`
--

DROP TABLE IF EXISTS `job_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_history` (
  `id` bigint(20) NOT NULL,
  `from_time` datetime DEFAULT NULL,
  `batch_size` int(11) NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `offset_record` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `to_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_history`
--

LOCK TABLES `job_history` WRITE;
/*!40000 ALTER TABLE `job_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manual_campaign_input`
--

DROP TABLE IF EXISTS `manual_campaign_input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manual_campaign_input` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(45) DEFAULT NULL,
  `campaign_name` varchar(45) DEFAULT NULL,
  `parent_campaign_id` varchar(45) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `touch_point_label` varchar(50) DEFAULT NULL,
  `total_campaign_cost` double DEFAULT NULL,
  `parent_campaign_name` varchar(45) DEFAULT NULL,
  `new_campaign_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaign_id_UNIQUE` (`campaign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manual_campaign_input`
--

LOCK TABLES `manual_campaign_input` WRITE;
/*!40000 ALTER TABLE `manual_campaign_input` DISABLE KEYS */;
INSERT INTO `manual_campaign_input` VALUES (1,'123','dummy899',NULL,NULL,NULL,123,'parent1','');
/*!40000 ALTER TABLE `manual_campaign_input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persistent_login`
--

DROP TABLE IF EXISTS `persistent_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `persistent_login` (
  `username` varchar(64) NOT NULL,
  `series` varchar(64) NOT NULL,
  `token` varchar(64) NOT NULL,
  `last_used` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`series`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persistent_login`
--

LOCK TABLES `persistent_login` WRITE;
/*!40000 ALTER TABLE `persistent_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `persistent_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` VALUES (1,'AMS'),(2,'EMEA'),(3,'APJ'),(4,'Japan');
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region_country`
--

DROP TABLE IF EXISTS `region_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region_country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_region_country_region_id` (`region_id`),
  KEY `fk_country_id` (`country_id`),
  CONSTRAINT `fk_country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_region_id` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region_country`
--

LOCK TABLES `region_country` WRITE;
/*!40000 ALTER TABLE `region_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `region_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_search`
--

DROP TABLE IF EXISTS `saved_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saved_search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `search_key` varchar(100) NOT NULL,
  `columns` mediumtext,
  `start_page_no` int(11) NOT NULL,
  `current_page_no` int(11) NOT NULL,
  `page_size` int(11) NOT NULL,
  `filters` varchar(255) DEFAULT NULL,
  `sort_on_doc` varchar(50) DEFAULT NULL,
  `sort_on_field` varchar(50) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_saved_search_created_by` (`created_by`),
  CONSTRAINT `FK_saved_search_created_by` FOREIGN KEY (`created_by`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_search`
--

LOCK TABLES `saved_search` WRITE;
/*!40000 ALTER TABLE `saved_search` DISABLE KEYS */;
INSERT INTO `saved_search` VALUES (15,'search-hugh','hugh','{\"manualBusinessStrategy\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"businessStrategyDocumentRefId\":null,\"businessRevenueTarget\":null,\"marketingInfluencedRevenueTarget\":[],\"marketingBudgetSpend\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"manualCampaignStrategy\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"campaignStrategyDocumentRefId\":null,\"campaignId\":null,\"parentCampaignName\":null,\"parentCampaignId\":null,\"subCampaignName\":null,\"campaignStart\":null,\"campaignRuntime\":null,\"productFamily\":[],\"customerSeg\":[],\"targetAudience\":[],\"targetRegions\":[],\"leadSources\":[],\"touchpoints\":[],\"assets\":[],\"totalCost\":null,\"dealsClosed\":null,\"marketingInfluencedRevenue\":null,\"createdBy\":null,\"createdDate\":null,\"updatedBy\":null,\"updatedDate\":null,\"documentRefId\":null},\"mapCampaign\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"campaignId\":null,\"campaignName\":null,\"parentCampaignId\":null,\"parentCampaignName\":null,\"campaignDocumentRefId\":null,\"startDate\":null,\"actualCost\":0.0,\"campaignType\":null,\"products\":[],\"createdDate\":null,\"createdBy\":null,\"currentStatus\":null,\"budgetedCost\":0.0,\"description\":null,\"campaignOwner\":null,\"runtime\":null,\"endDate\":null,\"expectedRevenue\":0.0,\"leadSources\":[],\"touchPoints\":[],\"assets\":[],\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"mapLead\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"leadId\":null,\"leadName\":null,\"website\":null,\"annualRevenue\":0.0,\"noOfEmployees\":0,\"industry\":null,\"email\":null,\"jobTitle\":null,\"companyName\":null,\"companyId\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"leadOwner\":null,\"leadSource\":null,\"leadStatus\":null,\"createdBy\":null,\"campaignId\":null,\"campaignName\":null,\"billingAddress\":null,\"shippingAddress\":null,\"phone\":null,\"mobilePhone\":null,\"sicCode\":null,\"lastName\":null,\"rating\":null,\"leadScore\":null,\"middleName\":null,\"department\":null,\"leadDocumentRefId\":null,\"assets\":[],\"lastModifiedBy\":null,\"touchPoints\":null,\"documentRefId\":null},\"mapOpportunity\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityDocumentRefId\":null,\"opportunityId\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"amount\":0.0,\"annualRevenue\":0.0,\"closedDate\":null,\"expectedRevenue\":0.0,\"companyInformation\":null,\"companyName\":null,\"opportunityOwner\":null,\"isWon\":null,\"isClosed\":null,\"leadSource\":null,\"name\":null,\"nextStep\":null,\"probability\":0.0,\"stage\":null,\"opportunityType\":null,\"createdBy\":null,\"status\":null,\"accountId\":null,\"address\":null,\"industry\":null,\"noOfEmployees\":0,\"productInterest\":null,\"mainCompetitors\":null,\"partners\":null,\"fiscal\":null,\"fiscalQuarter\":null,\"fiscalYear\":null,\"forecastCategoryName\":null,\"productQuantity\":0,\"campaignId\":null,\"campaignName\":null,\"assetId\":null,\"assetType\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"mapAccount\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"accountDocumentRefId\":null,\"accountId\":null,\"name\":null,\"company\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"annualRevenue\":0.0,\"organizationName\":null,\"organizationId\":null,\"billingAddress\":null,\"accountOwner\":null,\"accountOwnerId\":null,\"industry\":null,\"mainPhone\":null,\"noOfEmployees\":null,\"sicCode\":null,\"accountType\":null,\"website\":null,\"tickerSymbol\":null,\"shippingAddress\":null,\"email\":null,\"leadSource\":null,\"contactOwner\":null,\"documentRefId\":null},\"mapAsset\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"assetDocumentRefId\":null,\"assetId\":null,\"assetName\":null,\"createdBy\":null,\"createdAt\":null,\"updatedBy\":null,\"updatedAt\":null,\"documentRefId\":null},\"mapSalesPerson\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"userDocumentRefId\":null,\"userId\":null,\"firstName\":null,\"lastName\":null,\"userName\":null,\"email\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"createdBy\":null,\"mobilePhone\":null,\"title\":null,\"active\":null,\"lastModifiedBy\":null,\"company\":null,\"documentRefId\":null},\"crmAccount\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"accountDocumentRefId\":null,\"accountId\":null,\"accountName\":null,\"externalCompanyId\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"annualRevenue\":0.0,\"billingAddress\":null,\"shippingAddress\":null,\"industry\":null,\"sicCode\":null,\"website\":null,\"accountOwner\":null,\"parentAccount\":null,\"accountNumber\":null,\"accountSource\":null,\"contactOwner\":null,\"tickerSymbol\":null,\"numberOfLocations\":0,\"upsellOpportunity\":null,\"tradeStyle\":null,\"site\":null,\"documentRefId\":null},\"crmCampaign\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"campaignDocumentRefId\":null,\"campaignId\":null,\"campaignName\":null,\"parentCampaignId\":null,\"startDate\":null,\"actualCost\":0.0,\"campaignType\":null,\"createdDate\":null,\"createdBy\":null,\"status\":null,\"budgetedCost\":0.0,\"campaignOwner\":null,\"numTotalOpportunities\":0,\"numWonOpportunities\":0,\"totalContacts\":0,\"totalValueWonOpportunities\":0.0,\"runtime\":null,\"endDate\":null,\"expectedRevenue\":0.0,\"lastModifiedDate\":null,\"numOfLeads\":0,\"totalValueOpportunities\":0.0,\"description\":null,\"lastModifiedBy\":null,\"parentCampaignName\":null,\"documentRefId\":null},\"crmContact\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"contactDocumentRefId\":null,\"contactId\":null,\"accountId\":null,\"contactName\":null,\"contactNumber\":null,\"contactOwner\":null,\"email\":null,\"createdBy\":null,\"lastModifiedBy\":null,\"status\":null,\"activatedDate\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"name\":null,\"leadSource\":null,\"documentRefId\":null},\"crmContract\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"contractDocumentRefId\":null,\"accountId\":null,\"contractId\":null,\"contractName\":null,\"contractNumber\":null,\"contractOwner\":null,\"status\":null,\"activatedDate\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmInvoice\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"invoiceDocumentRefId\":null,\"invoiceId\":null,\"createdBy\":null,\"description\":null,\"lastModifiedBy\":null,\"invoiceName\":null,\"orderId\":null,\"status\":null,\"createdDate\":null,\"invoiceAmount\":0.0,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmLead\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"leadDocumentRefId\":null,\"leadId\":null,\"leadName\":null,\"annualRevenue\":0.0,\"noOfEmployees\":0,\"industry\":null,\"email\":null,\"title\":null,\"company\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"leadOwner\":null,\"leadSource\":null,\"leadStatus\":null,\"createdBy\":null,\"campaignId\":null,\"campaignName\":null,\"billingAddress\":null,\"shippingAddress\":null,\"phone\":null,\"sicCode\":null,\"rating\":null,\"leadScore\":null,\"accountName\":null,\"accountId\":null,\"website\":null,\"productInterest\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"crmOpportunity\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityDocumentRefId\":null,\"opportunityId\":null,\"createdOn\":null,\"lastModifiedDate\":null,\"amount\":0.0,\"closedDate\":null,\"expectedRevenue\":0.0,\"companyInformation\":null,\"owner\":null,\"leadSource\":null,\"opportunityName\":null,\"nextStep\":null,\"probabilityPerc\":0,\"stage\":null,\"opportunityType\":null,\"createdBy\":null,\"opportunityStatus\":null,\"accountId\":null,\"companyName\":null,\"location\":null,\"annualRevenue\":0.0,\"industry\":null,\"mainCompetitors\":[],\"site\":null,\"fiscal\":null,\"fiscalQuarter\":null,\"fiscalYear\":null,\"fiscalCategory\":null,\"quantity\":0,\"primaryCampSource\":null,\"description\":null,\"painPoints\":[],\"orderNumber\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"crmOpportunityCompetitor\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityCompetitorDocumentRefId\":null,\"createdBy\":null,\"competitorName\":null,\"opportunityId\":null,\"strengths\":null,\"weaknesses\":null,\"lastModifiedBy\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"url\":null,\"documentRefId\":null},\"crmOpportunityPartner\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"partnerDocumentRefId\":null,\"partnerId\":null,\"partnerRole\":null,\"accountFromId\":null,\"accountToId\":null,\"opportunityId\":null,\"createdBy\":null,\"lastModifiedBy\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmOpportunityProduct\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityProductDocumentRefId\":null,\"opportunityId\":null,\"product\":null,\"quantity\":0,\"listPrice\":0.0,\"total\":0.0,\"salesPrice\":0.0,\"sortOrder\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"lineDescription\":null,\"productCode\":null,\"createdBy\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"crmProduct\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"productDocumentRefId\":null,\"productId\":null,\"active\":null,\"createdBy\":null,\"lastModifiedBy\":null,\"productCode\":null,\"productDescription\":null,\"productFamily\":null,\"productName\":null,\"createdDate\":null,\"defaultPrice\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmOrderDetails\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"orderDetailsDocumentRefId\":null,\"accountId\":null,\"activatedBy\":null,\"activatedDate\":null,\"billingAddress\":null,\"billToContact\":null,\"createdBy\":null,\"contractName\":null,\"contractNumber\":null,\"opportunityId\":null,\"orderName\":null,\"orderNumber\":null,\"amount\":0,\"orderOwner\":null,\"orderReferenceNumber\":null,\"poNumber\":null,\"poDate\":null,\"status\":null,\"lastModBy\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmOrderProduct\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"orderProductDocumentRefId\":null,\"createdBy\":null,\"order\":null,\"orderProductNumber\":null,\"productId\":null,\"productCode\":null,\"totalPrice\":0,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"quantity\":0,\"unitPrice\":0,\"createdDate\":null,\"documentRefId\":null},\"crmUser\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"userDocumentRefId\":null,\"userId\":null,\"firstname\":null,\"lastname\":null,\"email\":null,\"lastModifiedDate\":null,\"createdBy\":null,\"mobilePhone\":null,\"title\":null,\"company\":null,\"active\":null,\"username\":null,\"timezone\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"erpAccount\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"accountDocumentRefId\":null,\"accountId\":null,\"salesOwner\":null,\"salesOwnerId\":null,\"sicCode\":null,\"customerName\":null,\"parentAccountId\":null,\"parentAccountName\":null,\"site\":null,\"geo\":null,\"industry\":null,\"annualRevenue\":0.0,\"company\":null,\"emailAddress\":null,\"companyId\":null,\"companyWebsite\":null,\"phone\":null,\"noOfEmployees\":0,\"billingAddress\":null,\"shippingAddress\":null,\"leadSource\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"erpInvoice\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"invoiceDocumentRefId\":null,\"invoiceId\":null,\"invoiceName\":null,\"opportunityId\":null,\"saleOrderId\":null,\"accountId\":null,\"description\":null,\"status\":null,\"leadSource\":null,\"salesPerson\":null,\"accountName\":null,\"salesAmount\":0.0,\"productQuantity\":0,\"productUnitPrice\":0.0,\"salesCurrency\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"erpOpportunity\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityDocumentRefId\":null,\"opportunityId\":null,\"opportunityName\":null,\"closedDate\":null,\"owner\":null,\"accountId\":null,\"status\":null,\"probability\":null,\"opportunityType\":null,\"companyName\":null,\"website\":null,\"billingAddress\":null,\"shippingAddress\":null,\"location\":null,\"salesRepName\":null,\"expectedRevenue\":0.0,\"opportunityAmount\":0.0,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"erpOpportunityCompetitor\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityCompetitorDocumentRefId\":null,\"competitorName\":null,\"opportunityId\":null,\"strengths\":null,\"weaknesses\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"url\":null,\"documentRefId\":null},\"erpOrderItem\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"itemDocumentId\":null,\"itemId\":null,\"itemName\":null,\"upccode\":null,\"quantity\":null,\"totalValue\":null,\"itemType\":null,\"cost\":null,\"createdDate\":null,\"createdBy\":null,\"lastModifiedDate\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"erpSalesOrder\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"salesOrderDocumentRefId\":null,\"orderId\":null,\"orderOwner\":null,\"accountName\":null,\"opportunityId\":null,\"activatedDate\":null,\"orderInvoiceId\":null,\"customerPo\":null,\"items\":[],\"salesAmount\":null,\"customerId\":null,\"salesAccountCurrentOrders\":[],\"salesOrdeAccountYTD\":null,\"leadSource\":null,\"partner\":null,\"status\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"activatedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null}}',1,1,25,'{\"id\":2,\"value\":\"filter2\"}|{\"id\":1,\"value\":\"filter1\"}',NULL,NULL,'2015-12-11 10:34:39','guest@phaladata.com');
/*!40000 ALTER TABLE `saved_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_authority`
--

DROP TABLE IF EXISTS `user_authority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_authority` (
  `username` varchar(100) NOT NULL,
  `authority_name` varchar(50) NOT NULL,
  PRIMARY KEY (`username`,`authority_name`),
  KEY `FK_tnnyxjpcvg2aj0d0i6ufnabm2` (`authority_name`),
  CONSTRAINT `FK_h5t8nplqarkfi7tscc9unyr7y` FOREIGN KEY (`username`) REFERENCES `user_info` (`username`),
  CONSTRAINT `FK_tnnyxjpcvg2aj0d0i6ufnabm2` FOREIGN KEY (`authority_name`) REFERENCES `authority` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_authority`
--

LOCK TABLES `user_authority` WRITE;
/*!40000 ALTER TABLE `user_authority` DISABLE KEYS */;
INSERT INTO `user_authority` VALUES ('admin@phaladata.com','ROLE_ADMIN'),('guest@phaladata.com','ROLE_GUEST');
/*!40000 ALTER TABLE `user_authority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_info` (
  `username` varchar(100) NOT NULL,
  `active` bit(1) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_info`
--

LOCK TABLES `user_info` WRITE;
/*!40000 ALTER TABLE `user_info` DISABLE KEYS */;
INSERT INTO `user_info` VALUES ('admin@phaladata.com','','Admin','Admin','$2a$10$n2usJ4tUqZF8CydUlqgupOgBjxW5QomRuDhlSJrSTjCM4iUAiy6W.'),('guest@phaladata.com','','Guest','Guest','$2a$10$E2PSxeWK79SKFNXp4SZ6C.qPN3vQZ4W4.QMFi7TpovSAFpoteyWu2');
/*!40000 ALTER TABLE `user_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_login_token`
--

DROP TABLE IF EXISTS `user_login_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_login_token` (
  `id` varchar(255) NOT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `user` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_nv6inptdyrxxwyap5fax7erin` (`user`),
  CONSTRAINT `FK_nv6inptdyrxxwyap5fax7erin` FOREIGN KEY (`user`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_login_token`
--

LOCK TABLES `user_login_token` WRITE;
/*!40000 ALTER TABLE `user_login_token` DISABLE KEYS */;
INSERT INTO `user_login_token` VALUES ('admin@phaladata.com#1452684886248#682c0f25b34e105c9491fa246dc824e5','2016-01-13 10:35:29','admin@phaladata.com'),('admin@phaladata.com#1452690290342#48afc092021c467e2b83f8620c843b37','2016-01-13 12:33:14','admin@phaladata.com'),('admin@phaladata.com#1452708132893#57f463958ee2a95b6b40c4cb57576390','2016-01-13 17:24:42','admin@phaladata.com'),('admin@phaladata.com#1452764209112#5ad69cfabbb83fd54f1c3f7e3da14b1f','2016-01-14 08:37:40','admin@phaladata.com'),('admin@phaladata.com#1452768711864#bdc25216e29038ca4639aa6daaca34e6','2016-01-14 10:44:22','admin@phaladata.com'),('admin@phaladata.com#1453118008197#e847d4b34fbf66fb883a6c7d8a6759c7','2016-01-18 13:03:21','admin@phaladata.com'),('admin@phaladata.com#1453276025545#d0f6778c05d9cd9c3dc0c8ecde2412dd','2016-01-20 07:18:47','admin@phaladata.com'),('admin@phaladata.com#1453466926870#fcfdd08c91df524a86c7aca87a2c4298','2016-01-22 12:42:54','admin@phaladata.com'),('admin@phaladata.com#1453467046358#377e091115c809b002c088029425f53a','2016-01-22 12:42:43','admin@phaladata.com'),('admin@phaladata.com#1453649394729#6d3d2f90e8419367ebb0f9de1f3cb38d','2016-01-24 14:30:32','admin@phaladata.com'),('guest@phaladata.com#1452770802801#aaaf1bd652ec04a36de2cc02e02dfbe6','2016-01-14 10:34:01','guest@phaladata.com');
/*!40000 ALTER TABLE `user_login_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_service_vendor`
--

DROP TABLE IF EXISTS `web_service_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_service_vendor` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `vendor_type` varchar(250) NOT NULL,
  `instance_name` varchar(250) NOT NULL,
  `vendor_name` varchar(250) NOT NULL DEFAULT '',
  `version` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendor_type_instance` (`vendor_type`,`instance_name`,`vendor_name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_service_vendor`
--

LOCK TABLES `web_service_vendor` WRITE;
/*!40000 ALTER TABLE `web_service_vendor` DISABLE KEYS */;
INSERT INTO `web_service_vendor` VALUES (10,'dataArrMAP','oracle_eloqua-0','oracle_eloqua','0',1),(11,'dataArrMAP','pardot-1','pardot','0',1);
/*!40000 ALTER TABLE `web_service_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_service_vendor_configuration_detail`
--

DROP TABLE IF EXISTS `web_service_vendor_configuration_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_service_vendor_configuration_detail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `web_service_vendor_id` bigint(20) NOT NULL,
  `attribute_name` varchar(250) NOT NULL,
  `attribute_value` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendor_attribute` (`web_service_vendor_id`,`attribute_name`),
  CONSTRAINT `web_service_vendor_FK` FOREIGN KEY (`web_service_vendor_id`) REFERENCES `web_service_vendor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_service_vendor_configuration_detail`
--

LOCK TABLES `web_service_vendor_configuration_detail` WRITE;
/*!40000 ALTER TABLE `web_service_vendor_configuration_detail` DISABLE KEYS */;
INSERT INTO `web_service_vendor_configuration_detail` VALUES (109,10,'apiUserKey',''),(110,10,'class','class com.miri.search.data.DatasourceSetup'),(111,10,'clientId',''),(112,10,'clientSecret',''),(113,10,'companyName','TechnologyPartnerPhalaData111'),(114,10,'datasourceId','0'),(115,10,'email',''),(116,10,'isConnected','false'),(117,10,'password','Phaladata#1'),(118,10,'showApiUserKey','false'),(119,10,'showClientId','false'),(120,10,'showClientSecret','false'),(121,10,'showCompanyName','true'),(122,10,'showEmail','false'),(123,10,'showPassword','true'),(124,10,'showUrl','true'),(125,10,'showUsername','true'),(126,10,'system','oracle_eloqua'),(127,10,'url','https://secure.p02.eloqua.com/API/REST/2.0/data/contacts'),(128,10,'username','Chandra.Shekar'),(129,11,'apiUserKey','22210bffbd7e2b5f5521531f62f6d2f8'),(130,11,'class','class com.miri.search.data.DatasourceSetup'),(131,11,'clientId',''),(132,11,'clientSecret',''),(133,11,'companyName',''),(134,11,'datasourceId','0'),(135,11,'email','june@phaladata.com'),(136,11,'isConnected','false'),(137,11,'password','Phaladata#1'),(138,11,'showApiUserKey','true'),(139,11,'showClientId','false'),(140,11,'showClientSecret','false'),(141,11,'showCompanyName','false'),(142,11,'showEmail','true'),(143,11,'showPassword','true'),(144,11,'showUrl','true'),(145,11,'showUsername','false'),(146,11,'system','pardot'),(147,11,'url','https://pi.pardot.com/api/login/version/3'),(148,11,'username','');
/*!40000 ALTER TABLE `web_service_vendor_configuration_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-01-26 14:43:02
