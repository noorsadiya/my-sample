-- MySQL dump 10.13  Distrib 5.6.24, for linux-glibc2.5 (x86_64)
--
-- Host: 127.0.0.1    Database: phaladata
-- ------------------------------------------------------
-- Server version	5.6.27-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(45) DEFAULT NULL,
  `business_unit` varchar(45) DEFAULT NULL,
  `address1` varchar(50) DEFAULT NULL,
  `address2` varchar(50) DEFAULT NULL,
  `address3` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zip_code` varchar(50) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `industry_id` int(11) DEFAULT NULL,
  `no_of_employees` int(11) DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `annual_revenue` double DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `logo` mediumblob,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_account_country_id` (`country_id`),
  KEY `fk_account_industry_id` (`industry_id`),
  KEY `fk_account_currency_id` (`currency_id`),
  CONSTRAINT `fk_account_country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`),
  CONSTRAINT `fk_account_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`id`),
  CONSTRAINT `fk_account_industry_id` FOREIGN KEY (`industry_id`) REFERENCES `industry` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (7,'supraja','B1','Add1','Add2','Add3','Bangalore','Karnataka','5600455',111,4,76544,63,4444999888,'http://gooogle.com','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEX///8AAAD5+fn8/Pz19fXv7+/p6en6+vru7u7z8/Pn5+fi4uLLy8vf39/CwsLc3NzU1NS4uLh1dXWurq6ZmZlhYWHR0dHJycmIiIhycnKBgYGnp6ekpKS1tbUwMDBoaGhXV1dDQ0OQkJBLS0ucnJwpKSl9fX03NzdTU1MiIiIQEBBGRkYcHBwoKCgODg4XFxfBgx40AAAgAElEQVR4nN09h7aqurZMQJaVIkWKSlOw+/9/95LQQgiILve69745xjl7iSAps7cIwv8KTFbGRv5PD+I7oCeci87a3ZpW5v6/mOOVM0P/UP4RqH86ln8CDmzZS2K6qv/WOt/+z0EKOnvJo684wR8O5l+ABrBiLplG6+NO+7vR/AOY7gEWzLWQ+ex2nvpfIk4P8sekfUllx39gN3mW/sshfRkAUmBmmInMPXOLuTAF9pb/XlDhmF2Y4drsTdKVuSDD/w73WcPSZDZE6YrHmJH7MnRW4b8WQhBVaI/f6c7wqrQ/TyH/l4P6KlxB1GHeurTk7GH7DqQknP9XCFGBs7SCtrzTWL7S3cMtwPRfDuuLoAOSdY9d69ok69x2Y+azfsJ/TgvQVAr0yYu7E8wUQwYtWYEvrPbMhf0G/l7mSxNloRkusOCaqwGESrDGZjLye8vqOAmDtz8P5W9nmHhrz96XM4rXZgXbZF1cPQV9e0lmOIf2xSnLaliVYHEW/myGsha4eTG11EaQsfs1Ua3sjr/e+w7n+YTQ05khKnfW+rhbM08Z9h/NUFLtJx58vpjNZgMUJ+n2iWyl+sN+VcwwY0xA2ac/TfasZLDNP5mhnuFR31V9Oe52F69GwtxczHATMzcvqSnPO+ajiETFP56hpKjrI8a8wzs8e6p66KGbSxsK64Lrd6Tbxq8QlcM1MWfqWs1fBCm/EcLKPniJhpntqZF/t0Jjyw7sjYtTgjmqEz66i7g30DayBtUXISHT20qfPq8imrwcStKCgo1q0L1v4+XPPaK4DiwBo67S/eI7YGKekY4jvT7QbYBnQWnlDIXrjnfjjHdRiAO8JPzvfg8WZp09RK5srMxOC9lxtF3LXM47vLMEMkfsjIFyLxwYjRPLC/7f+b1xj4XNs2//FMMrhPvlGPmu60bHB/l0TTb8oatngGiOZlhK97hDiX2Q45UxWJv4O4A0+pizf1MzRJOJXFVTWsQhKfoui9E3AY9mfjz0UKDCvViB0YQVEBUvYZWAb4CDBtv1HYhGCmCbq14kmxgR2ngemRloiva5Eu67cc6lSSFeeBzot7DFugt7cY6Yf+a8IqHZ5gxno3t9fsZcq/rk8aIXHbCLzTt+Xxw6AJ19WIS9XIeFXQyX7rLLV3g0wt4e8VtWwXtljnT5JQQA7CbMstHzw6B7kHeZVFyzGqxJvNyYTbnMy9P4F48DhKIsrzPh/KZqOFtDzGoiEqLiWrKJ5xdTJB4BDO63nYloB5nZzE7gv6/VOFfIWL/gg1o7ZT+4aA5E5V/3L+tsS4BN+4oB6Zx/7wtQ7yw5r4BmonY3RNE8C5V7Y/FlX6LSocEERvE9HogR2G2Fy2kNN+sgcv0NnCqsSb6LpHNkDLSvhL3GmazpCLRBnTGBxxC5HSDkfC2aAI1Z/F1n6QyJrNYPStGZj6HzBOmkj/P5fHsczYHwO5L0Q5q7voc8WdKvlA2kxobNS4MBVP4AbNaBHnWcCsXAPNhbTqF6zfRtnvfbV126boOaYk0gs1RH19XEi7HuQ1mJk+/aFS4wvxdyJ6jFsG4T0MLuhucrUAGGGdU0qH132JhxWzrruusT/wVs2OVOuO70BMKu4rx87PucHC681kKni5WmO46jMbrid2OHG1ZXM3j+EcnuanSrHBFOP8/N4WPVeYxyNxo6BDPlYZ4Uc5wm2NcRICUk5zu8VfjUhFW/GTlcdJheyvv505Nj2ulIxiBtRQp7nGJ7du1G7szsq2wmYJHM5P38ms81DiaaZYBVWu7Yd+C1PsvPcYpYzvOcfwo/N2ZwYse+EPBQ+4XbAm+UwXtKmD1u7QvejXNXB8KvikILmDBXEnVvmgwqcCqmUP4UbQZNde5dDLhoBCKG17eOAYD2gs14rhTvOWhiWPiZjLfNJjBi7dplyAzoa4jCmIjIfZSZv46RLmhNEIPPkbT6K66fwALndXVHMwfGXWbBPhs2yHzIwyQwHFl0VDOxj2Abv2E7s5w1Cvec99vQ5xKtIAPvDvDs4hUwaTQqKP6wNjdhmJFiphCNwO0eMIGhMJPj0ZxDN+bOwhYh1RKiznWbkaI6OILzvBtvGdbSLobkVSi9ByyWhVw7njasfY1YwokzRdymw5BcRlJqGGUkbCW9R2D6vV8BHoSQYaTKo3uPdHyhQTfgdyR/wHCWRcl6nBAu1qrBYOelfyqB1z6sLoisNyvgeJmR9T8WQ6T9mUE/lVn6Rc1ciT14t92dYZjeOX/tDNeeH6i5Kkt1J85vaDA+yKUxskdwGA/6oiU+Vqq7jrBcGKXDiCn766/BZpUoXoqOip2MEyewkgOHSAVJlilT32V+QWf2UGMFJOZR1li+M2CN8kG6MBdWPLvQgsfeLs3UjvY5c7ER2+ThS0w+ocM8ojFca3IC740waDRut2uYs1lIG57d6ZMsE89fZzZEzHcmxKcTDvZDUj5ptMUDa2pu2kPcwOWtOKx0fs/Tb3rsBY49pz3gZJSsZsMgsUVSDSSkaOF8jeJa3PrRLSMP258PYL9ZSzJ/jxR9n7lwYDcVDyLtZdINo5rj4KJHRrtp8SWXwQqXTjNdf+CR3b2VvWCzL+jO0OtwhgYkejk3SGu77zDLyOlfDZlfpD/bH6XLnN4JDOfsDA2WDulBSEYWhS1e315NHP3HrG5Dk8qDQapnjTZi/CbXKGHxDj+9sTN0GPPeo5Rkk+TXDBG6uCvY4r5RY+Re81rMOwUY1TeLbRjvz8/jPs0Cp6vz+zCedm8sHS7a0uzQjG92gvSw0Ywuzk6tYNV+pdmkd6nMki0r9QhNkCskpB3RAJ7x2j+fiTd1y7L32RuqzbFjM7QwYNPQoIJTKviww1mJj9OWGnAjIbC5ToNbutbF/MnTBHUX4GYHdUquqB3yrsKTjQ9KnTpB1owiYxHqvXhR+RAAuFeIVElQyNz8WrvdM8tdqQbxo2vVTnFExKfQUqx+nDFtluPZ6bpDVTr1sNfg0fWFgbh47nHcCJ4FEq4qi1ljSEYpqcDuuvP0ECduNp+nu3MpWFc31j8yXsgEXddKVDvi9eZ3Di9pe3o+T65gVR7gvFx1jzHOdsWSJh0a1JBamFE7M8GKVMUlFsD4GKKu2O4BvVuUotSutxiaa69JW4oAx5LKZQ8K9JdZdCpyonasFYn1BdqGn9iAs3HrHXUYt+u2jw134OfStSVUiImEMBrSW4+KkmyfAGG51pNCg99G7VsmBIl1xigWEXtpZUQ7ECmze04NLWG12dHc1GcDv+RxeHhJWiVq4S1khUoPLBrD5EqW58xwQZLFNWM0SwNg3ULaLeIsGpMVAhH9acL6eAfG1E2gwc4tM0mi5hXWB5m6AWboG0a/kgn5xS3KUBB2t/HIRaitsa80W/j+8xxNiAgBb3wmQikOT47v5hUs8GRYv8oBb2Fyo81ds7PE68sUTZAVgWKbfUbjy4WkHCLe9SbnA73utS+xC/edoDIU8INFRMvyUHJYMyS+zn8QEnalr3ukP4VvGBgzgKhz8SehGNn2ozCnG05YLuZvsQuA2rJd12eQpGiHYw6VLVvssz9PhAOrJzzbty8yxNsakWyP8ZZ2wGFdzYKGSTNqmJZyhTXrnyHJmRYvPrVq6ZPhW6s+jQHSuqBH3CDZFM6a2ghp/9EMRTZgIezRJhiND0HlOH0UvK46n7Fd6I0NOwl4w2ASR8t+H+dEmc8QdmX1Bkx57HYEsKmm6y1mprX67sKpyyyOmMEc+SqZTTtYQojeHI6TnM4XYv7ZBuGhcT0+Dc9w8X5VgNcW6yYeUlTj1onnOkiwoNz1BPJCaH34JOdNmiIoqe+n4cYIm0z039vRykOLXaxwCpda6bzKkRdrXBAh15fN6t+pDyGwFUbvgtIsGJqdb72L9wgMegwypi2pqhFdwYm3YJHOPkZDSH/x+xmqUf2ngmwi9GJ6R0bt54Ra8x9iJlYJsQ5fC9yQV1z6fDdRRH34/QzprLkYMz2DVu5fVsUS2NeILu0x0S1K1cjgW9PiA9+/7B15a4YRsJ7edyGhhI+Jq9fyVth2lDA6VQJ/XgivMo5r9gTyXbKoYS/fbuVnnD5PfS3BphnBFbPY1te7MXgaliyjLLxbFmqX1SN7pqRgSHz2/hzNCZCM/m3DnitNDXLK2ljamFjDuhhSFYwqkrsPfT7SQgBrvXbait76n/NnMpoCJt1QZUQUp6dFF4h0m5/zQgCpZAuTPuN8VogjqzeHQaWfFH9fqH984SUYUwiBwz7bmiOQoobeCQrbwjuX9vIw90m5amZvxGx7oCcDuoZ0RIbLJt8da7ZJFNKg371yI3si9msqrWzCZd0wQ14oHxWBio8XM/R4SCKFMf22DcCtvg1zG6MftbRiapteGdD2c+8qxoBDJUdvFONrw8sZHnisLGyncW4grN+MqVAfSP7zi70+9Pqdly2j3i9cPT8peImPa+l5if+DIN5eyHST40XQYNeqptNhUm/p3hh0Sf6U1mh/YnDbxE8LAVSmBYpLG7qm5jCI3KACBeox79xhecKEHgfSPo/RliAmrlrOB3whm9Kx1J8w09KLJ0VXl00jFFcR8BJ8+0G8veAkquvAmuHsGFNoXWiFprXYRefMEVJV8IcUyTIqKfZmBi9bOUsmkJU80QZPMFze0YFX1peaCcoJot1ivviRxJmiIFbuoXX9uTdbW9onomEfQVoOOsdKFjTrDU5GLfHkEdV90vaQLd7Tc15p7jv0ip+Ybt8SScRtrTZr01hgooYGZfcv8fJSENG0b4Zae3+KzHuDdZ1H7yQxvKqTOBClxsgRF0Pz3C4SOIYm2b51vbAKPV7JyWBv9nCDKsjI60hAIGyliDhFlmc3eLF+w+KIXtChm9tEMbQQvjjH2wIpVY97QZd5pVoqzHhx+O3AneO19GjoPTNctHfLB6IArbuOand8+zNObUwL8iSEFC/hIo5lEu1fPMsCGSmyi2mwM8RJl3cIunMUK6db3wyzdjrgsdDeb5ycjAOMrW9PhhVb3JFjbhcc3EUqIrb55nXhTRko6s6QDOHWkXlaxYV6mkQo7ZxiBwrvQcrLOgkGkmPaNw5z3iILVb8RoahiXxyySFePai+cZ47kINs1qQQL2GIKo7qRuyaIZNrUFZXKrstlh9uRKSybYSu+LLKWMvJzK7RuU8S6naZXgZpCsOgREDMXwhaPsCqPDr9Zi9He2QWUMaMtX6T54xLfpsMRQ7fSMFQyJ/mWIVnmYT04V4kUnkYgLwGufC1MCVsRw7SmnYjj0ZswQqHOFFv2TOU0iqH+DN/V8OkVeZ+YeyTdPQoNgNiL9tiLvEvVO8R8PczJKfG8r5fT5IQF47bkUmrTsAenBWmc5B+coU45CmckjUu8+0hNDNBLJcOL7ylOU996RJfqYcsGXCskbkY069YpZJf2837DLfMeduiMcgC4Q+Ki1dtCPuIpyrcE8UmN7qnhYtmPY/T8JZXDUlH5oXwuPuuJYgL4iFQbDdXvs0TcMcVV6oCnZ9ZWJuQLZtAKGmcc+9RjpTqN1P5uLxEC24KzT6kY1JTxElrsdmSU2qL2KmnnEYkHkwEVz2SWaEaGqIM2aXWdOFf82OjbxiKJhJ4hupfi4pLHMleFdtDMugJRjfZ5qI7D06j/qyM73jn5wQDa8rYJA85sOHENzlmei0K7Kdu6maJ2ZpvSMim3e/ZrRBI2VpTV6JViLbQIcRe3stM42e5Ferjn0Z3lFRqXOfHsAjAatr38PkSaJMw0x+M0koGWLspaqA4cMZEuXLiMkPtGPaIEvAONOzx5s8VrJoOWNDN0Wpli87wnKWcDKmP9o9W47anUeAqi9qRNxm3rVcg5j0ao4Eo1IB10ZzdphqtyXYIhJsDdsQkdC9tj+w6vp3Qd6SiMFJyZ2dpVOUkwG+Yn5ozb9tFIsWREIVNU/hu6OuLQWb14Z246knTBVBdRdOixq2ghK5n36Hyse1c6sjem7c+00W+99mn4JaOAxV6xkhohDj3apoMZ7JLC5nOHfwY9u8iW1fRB0vHWGW3MH5udVoJTLMgMZrEQWUE5w3mvdUIQtPE2KJyMCgNyrnm06484UbDqLpDUzgq130ttmj0ITi1g9rRADMvlO/VmmkqXBd3dcsfTGjV4cjHAGxOQ5GW+W605bUfn8xFwyv0AdWohGi/kmdXm7MpGpyoIY0Fv/Ck2V7PV4M5bIXFEhpPPCx23y7K1UbhQQ1ZmtoV5k9Kut8LnGk6ZpbQYe5PU05J7Ir0qRG+NooYlJ08UgU/rXj9veYXFtAzpIZ3rWi6f8qC1KPOIN9lsJM/0cavVUqOPP24+i087wO+Xo7So5q2CaDUTwoLFBY99qSC0WpVU6Ro6nUtcvy7qjTBu3/NNF7DsbXXj09Swe6dfiK2yvTillObGcl3VvqvVXLOWuMpAzpL3fvaR2j3gpAKRXjD5nYYhN5FRsdEEaVZF2Um1mttw6wP0Gm+I6b4ntvC2P/pj0gHNtN9oJUlw0KD0XPUMNyrOLBNNSyP2tlO+Q25oL3/M+gPh42zwBtZwG+IgOYWn+vh05oxsUZ1fOPWQJuzRdhzmF9OCkc5KRd6t9xjpeUu3n9y8d86PWewbfwcXWnW4vEptPjxLPkp+e4V7epsC7VXy8Pi9Eitzgs3TRtyvz2o2j3p/fPJGWZ4F8KKPRqtYYjG2j69W4lh6dowM9yA/KQgJKcZ8xH9X/C0mAiCuqVYG6+cspP2p2MnY3EncEnWwiQaGGc0Bx7YI25ZyfFeEzki2T8uHjZdKr8Q/meGh4dQWeEKssNYbBdNxlOickEIxgvHSKRDyyCz+qHxExoV3XrGKRtR8L+EZrsoZilhM7hptR4RkLySqzJbCS41I83sCKOI5qXZ+au7hYo0TLHQd1HaUQ1i6V788D/SKg1qUgkRmKJSVExrioVvKpXIAIXNUt9O922jIT+uTiRFCmNPa83A77Zs1tlZ0SsdGj2PwQ+OVpLQMABK19Ysp2PY0onR8vKXLTImQGGu5n+RH2NzVp9iYdQc+/x3Vx6B+jzt4Fnj9P4Tc2m1quUQamxIxIdkAKc0b/RzNPv+5o42K6Oevh1XDYKI+byV4qp8EL9sys2BTFZvrEV1BfZ7R/YCo8ZgVKo0Oqb2HqMXtirYQNs7EACqbfZZnNBdgj2SpwR3ftp0G6dk4T6X7a2aT8lQuNLtch2exXZtilxfWwWE8ofsT5t0BsprR7XW0PCBKe1IHcxcsG6pg9eGRFkvKZnFeK+A80ydAVBXOQzckM5L6kN3LphgXtTPSlV1LKxciLg+r2leMrid8iuD8SZWVUNT0VeC/6if2w3FVGPiExkTbJstCvPZo1oe4XJ8zbITdSSCx0G1tDk8rg3nea2B4n3YPtql9iV/g6ZxDC2vV3QqWZrpy4SpQuL0bVDxwG2t3uPZKB0FHuqp/ad63LIVz/wzNN/oJtEA8H+snV9HwvUvODCMhSARvblhCSUG8TdyQ8W93ZKAqyQDay+aTHrJboHc/li4/Tv9dQFT/bQ4rb0YXUeRQsA6CLQSmcCynv+8Qq1qQgo6JDx9GJSNatDLGrXjbFqPpe7nyeQq3Simo4SDDIjVKbdiqQrZDG+k6Ql7OULsziLYryU0m/nxZFqSzjmwbhrEVmRdqv1j+xbGOW8r/Ndhay+r6Ha8S7uSW4QNu6w12WrszsWv0iisZsV8iS4ndEhLJtvrt/LEZMTxwG1nTPT+Kvq+jvK5CfGiYkginqdCsvgN1NvTKpzrNu9VK4lyMJ6sfrfHkBk4j+Kgot/7xJhNAH+hj43dUKksVZpeflSXsp5ItSGqVR74+wzVzfaS4eZQnpW6RezXoxgUl4Nqt1YDLaHwlOg+iZopGv+D3O5Yd0k30p7Ax0AbKnkBH5zTXvtpuuzulVHWIjMgMGRUaH49jD0zjzfgKC6fmfbxOrOU3zQwnB9JJPCJLbzpKLijJ4cQNSlAQluuIsTRmR6zfhTS0+tf3N3SIQLw2tJj1IfyhniHOcsqPN6yJuKGQTLVUmFt3cfLCpXUoCTlGy7kPGdmzORkQ9jsbp78+IjdvmJvdY2lX/odZft8RnoutfM8SXBnptA6yNld9enMJZUAAnxPzAyojwgPYH3rLn7DE/20nbzFtFini76JRcJqmH4aP1K6TIYTSJkRiVUV69YuXhOQVIpL4c3CY5OQoFQW9P5ll9/uTyCSqeC/lUrVTsIFjbdTjA6aRlRtNfIh9xAad6MU7SESYqGZL0Nvds+ZY7xwwb5JvtJsPG5ET8XjaJML/pw5kxDdFbgJ7X9fj85hQ5A2LRBVN7XDU45YLIEI/uxvwUKQvO/qOAa9h97wpSthvplNiH/2pXcAi6LNAX1ovc41NvG8JMuRDTw2TtVFHUskXA+4w+TkgqN+ABOqalzDtYgWu0KLcDJKPBlbt6ARoZtsL95P0g6kBdlayAds+x+Rw+AmWVquBzITlryt8S9jCrVJCklvHXAlFYUPx7KkrLGp7Cpd9BK9F1gb2Ocn+VsKdjk1KJTgdT94TY687YAF2Ey4+BbWpogk6EgjxTovSUlolo/ggLW7pGgP42IQFWknpvFJKD5S8UTGii0OFH/fvHeq4ag61cNgem7uNQPuXFvSQcEtra0z/gTWuJzutJUBCvBXADQZK6Vb8cP1ngLuPVX/GbanMnAq+oGTK4ahuBWuUYrXDZKeqJ4TY9AwLTt0D7q/lfQuoKpqkZcZJbW/moiH+gDBh9nzpXkAKrB+0U24VewAN5QevJfwv4NA0qFiCTfmn7JZSNa9lSxlucsfOMI2E+6JMsSUwY50abTC/xmcq2EB9TK0UUgzHbEnJZb2lcUGe3sgZKqBiT/4M7J2uyKKse3AabPB0eS/nZwzMqao9FcdBq6HRBl9cuarVkqmOnWHyIAg9Q2yVND99+sP1umwD9+9ACGGF+mKzjXR3WgcelUVb/puOSyaUkc6Nmf/YQ+DlX3cs4UMA16bmGvICixJqE7PtvkBOpVJnB6mlYRUmzJfYOFRGukDd4WMhPged6gQlJeBj2biiLPP9rKz/NMsB/IwcCdJ+SW6EMk6KLzrNs74GSBzWmIpPHsNN4KkspHNVLl+1b9THnSRgwkQj3vPNuFSleHwjvffBp6s+Aniqa+qwwLhKHqssCmtU10LpkZXttMfdb/3afTEIO6CqO2e4i/6x1njiqkKwEiFDpfUNJCCXLWi5RigL6ujyzw9B30Ncb2MIoMpQyea8ahFd2gS7UVa4gjh/UeArjtkc5R/xURrcOhvWhUgQmrN/Ull4kqFOCMOYjeP9p1O19WPy2Ga384dBtXcAGVQnvI1LSAnCaqWBFepCRuFZNMpENUGTyqVwR1R17r9nNA3BYk/aOcK59JRMU0KL6hoJjxqD3VHmjQJZfYYN23i+C1I6+iSbX4KMAxBrype5JafXPKeIbZDekdJyZBvm3K6DuSO6b7/RcPXXEED7DK+JC7EZItsiuACcnxDvY2f1mtG4MNcqtSB8lWu52PPLMP4RTGwmjj7FogOLNcVZauKM9I+M1OFJmrAUL3UNyotUS5NSN/4Eun5wUV7W+xrGu6LhR8j2/6JggYjwWNmUXijMHLXXppC8XzeXexPm3JxxHW7majJXibdDPUIUnBDF9gx7dbSluuGBDuGJLInH5SXOA+D+3YN/X8GWz0lmHhkm6YUhSC6kyixk8tnqWyEV0mOFxjnAerdaGRmv0auUwe68FZN/YRX2wrpvQWeqZdabNsd1eA6yau0OriqXfBJX2QxI4a1MSXnPOZo+mxzAmJlgf3RayWcwfLJ7AzuIFQHp50fGVNw8z+q9spQRazbqKMSEOVZG3YNjpdttDid199mBLJ8A9wRLLsi4R7SBGSvNey04bptqEuYoJI+S65scbWmA1aPJ9Weg+c7XgZfw1QcIyQQlbg56IsOOMkjKn5BChmtJeZU3vbthU6bIzbLItD85F+8jcN7RD3WIcI1bVW6/QUzz0jAUFfYs+9TInVpWNkHZH3Qkcwrd7qtnOA+B+pYGPD2nxemViagnRwDE+qPyeUR1HDkXwso6w5EcC4VI+QaeMCtY23CW1hdBfU8Fnt4iJP/SIjX78YB8KYryTFmaIax5chWZKxBXESF8XN1UkIuP8a/PjB0JzpsnPUxIkH6Lp4fhUuahp0GPtZc2nVF3vrSpFe6/4zRjXZs1aGVTjAcQJIXLHQK9X5E+NJys1bom/V0SzRswe9vrvCOa+hLczR0cJTMqxxwf9NpOWlD9Q8T8yL37X4B0fv8cTKJju8im30ek5GuoMlusXa1mkzm8iqN3X/oLaLXNHgVise3eQyTnXuWKkA+kWlTucu2I061OGFMlT/1Vst6bkLCHwb4GtbAo92vEp34E5yooAyZ7cR6SMIXtz+EYHks9P/pCDs1YeE8gFhAST+cC6ZZ2QA5ASPp9OV5haeKaZAn9FxVq3Y4vXP4J9BXSDz9DREByF1YPLHBE9kxACsJihgFGVmSY7ErTY2OD/1f7eH+n4ruEsvYQLU66JInaWa971y6wVPEDMzkpdUQSu6Tf6yL7OVgf5JX9FCp28pjt0ASSp7DprS6vrC0X16fhblaNLrP+dRvycbD6JJRe5NwinexsG6YHOwsyle9DrGYhpeDefcOm35Z9I2lvBOw/KMtRinTM2HYCN/Q8246QVfUwuwOeNJNwrgs/azfZtD+gkA+g73iGQSAtqISQCnFKqzXsO3FGlZrDPGeFivzB+WcfgFSH7d+ANbEKgzaaqchY1JSWkprRJDA/GpO29N2+U6n/OSQfVDwciObsMLaX6gd2es/9ZpLtOpuf7HxpjI2f8ZXYvwTx/taxyQSK869FrhycBpdq4k7HV1k3frT2EE8E+7cnc4yDZU/LqgEwS4nIT+nTKuo7dVag7Con5k9Tsxa4ZPFPwH3b054UujOvVmIZZkLZ+GHVZdNlynjVf2r2RwJDyN81hAtVReatTEfYKY0AAAO+SURBVCJoqlkWyXL0gCtmn2bNRAdLzr4I8+ebfLtYEYfBUuWKCPogqJpLxEbCwwySUxTXyOm/zQI+hAW8pUKVSRedvLR5Zke5FxcnlLl8eR4mJKuhBPe3R+SMBgfe2cWyb7zB8dTJ2q5gQ2FPxpN4cYyGeWffTr/sB+0xfoqVb4I9k1XDO+sGByRfF3mvRuZA1CRN/ZnfVCDHPI19m1XyyJThhPp9O1eS3Wk9x+emyLIsch0IJjRx57/JyaggGyk0pmXkaNGplZgFuPqSuBmfz/PtjIyPiNNeya/3fsqaXfLy4LtJkmyNHmPld2COO74lL/1zCYOk5NnA2uU4tKGR7ZXmqn8Hui3L7Hi5QV1wiTSbbX1gKLqXnK55u0an9IiW6Ri6CL6q2Dlwed1Exa4MerZJm4Nlh6+q+dT0c9yQpVwA/UrVlVppsFXNkiBkWMr+JV0HZmKnJK34kalKEYIUpysnsCxT+3Jegwv+i1+0q6LppIPUwTWKj5AWAkBcNrUBuybV7erOzfUFgBzapJ/TZCpMN7tgp5oh5MlfWFMO3IbsRWVfdRdCLDHMO/GKLGvaG1AhgyYTbPmA9eGw3ZI6k60rqFGcHbaJHUeHv3K/yV7fCQCIrKx63xb4rFLRWPvbTZlSRCTI2j2UD2vZucFNqim+DlsrW3tefEdoie02Sd9sln8ViipgYcM94ERbZoemeMqp6hokbRvu72EwFcxT4sb3Kgoe5hQqaPdGvUNIknquoaqr1WbxV5HgDix8xO6MdtsnI4TYLPMQRLcd8J0uD5jSJgbYJZ8t/KSzzTZJXC+ntTvpz3zBwyAZSLAds0CdTmaz2TKJIT5UNKck5RHVomb69umaRqFlGODOraOXlDeRFKIDIlXPMjf/JXPqgOxsvVsZAj3UBYnzIMKf9U2QpUigrw87VVV31hrfSQVclrAVFo8/yJL9Pfzg5rqPvR3atn2K8TziM5n00W6X3YlLN4ekxt0DDHaq+O8CtTmq6xkGK0HWl47D1TS05FI7Lp7a5P1zk/9TsNiDO9V0fT4iL1Tz96E6F0mD7/knHXb/MyBHb/TnkBz/Bnci6ozfdGb5Y7DA69bNi8527a2R9M4CvY212rLI8/+foUQBtydsm4/SfBdhFhRF0fWMzaV9Zmqs44zTgeq/GUw4bgvJJulmiLhqZFaCTlwsrRAn18TeVl1V1Irs4D9Kyf8aGLgZZ3rFSe72tps/OVMP6/hBbKA49E4A1z814L8D8sowTWMxYJSKyko1D4nrJuZXjfT/A6ZeJFADYtKFAAAAAElFTkSuQmCC','2016-01-14 08:37:40','2016-01-14 08:37:40');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authority`
--

DROP TABLE IF EXISTS `authority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authority` (
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authority`
--

LOCK TABLES `authority` WRITE;
/*!40000 ALTER TABLE `authority` DISABLE KEYS */;
INSERT INTO `authority` VALUES ('ROLE_ADMIN'),('ROLE_GUEST'),('ROLE_USER');
/*!40000 ALTER TABLE `authority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `continent`
--

DROP TABLE IF EXISTS `continent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `continent` (
  `id` int(11) NOT NULL,
  `continent_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `continent`
--

LOCK TABLES `continent` WRITE;
/*!40000 ALTER TABLE `continent` DISABLE KEYS */;
INSERT INTO `continent` VALUES (1,'Africa'),(2,'Antarctica'),(3,'Asia'),(4,'Europe'),(5,'North America'),(6,'Oceania'),(7,'South America');
/*!40000 ALTER TABLE `continent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(50) NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `continent_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `3_geo_id` int(11) NOT NULL,
  `4_geo_id` int(11) NOT NULL,
  `is_selected` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_continent_id` (`continent_id`),
  KEY `fk_country_region_id` (`region_id`),
  KEY `fk_3_geo_id` (`3_geo_id`),
  KEY `fk_4_geo_id` (`4_geo_id`),
  CONSTRAINT `fk_3_geo_id` FOREIGN KEY (`3_geo_id`) REFERENCES `geo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_4_geo_id` FOREIGN KEY (`4_geo_id`) REFERENCES `geo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_continent_id` FOREIGN KEY (`continent_id`) REFERENCES `continent` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_country_region_id` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'Antigua Barbuda',0,1,1,1,2,1),(2,'Argentina',0,1,1,1,2,1),(3,'Bahamas',0,1,1,1,2,1),(4,'Barbados',0,1,1,1,2,1),(5,'Belize',0,1,1,1,2,1),(6,'Bermuda',0,1,1,1,2,1),(7,'Bolivia',0,1,1,1,2,1),(8,'Brazil',0,1,1,1,2,1),(9,'Canada',0,1,1,1,2,1),(10,'Chile',0,1,1,1,2,1),(11,'Colombia',0,1,1,1,2,1),(12,'Costa Rica',0,1,1,1,2,1),(13,'Cuba',0,1,1,1,2,1),(14,'Dominica',0,1,1,1,2,1),(15,'Dominican Republic',0,1,1,1,2,1),(16,'Ecuador',0,1,1,1,2,1),(17,'El Salvador',0,1,1,1,2,1),(18,'French Guyana',0,1,1,1,2,1),(19,'Greenland',0,1,1,1,2,1),(20,'Grenada',0,1,1,1,2,1),(21,'Guadelupe',0,1,1,1,2,1),(22,'Guatemala',0,1,1,1,2,1),(23,'Guyana',0,1,1,1,2,1),(24,'Haiti',0,1,1,1,2,1),(25,'Honduras',0,1,1,1,2,1),(26,'Jamaica',0,1,1,1,2,1),(27,'Martinique',0,1,1,1,2,1),(28,'Mexico',0,1,1,1,2,1),(29,'Netherland Antilles',0,1,1,1,2,1),(30,'Nicaragua',0,1,1,1,2,1),(31,'Panama',0,1,1,1,2,1),(32,'Paraguay',0,1,1,1,2,1),(33,'Peru',0,1,1,1,2,1),(34,'Puerto Rico',0,1,1,1,2,1),(35,'St. Kitts & Nevis',0,1,1,1,2,1),(36,'Suriname',0,1,1,1,2,1),(37,'Trinidad and Tobago',0,1,1,1,2,1),(38,'U.S. Virgin Islands',0,1,1,1,2,1),(39,'United States',0,1,1,1,2,1),(40,'Uruguay',0,1,1,1,2,1),(41,'Venezuela',0,1,1,1,2,1),(42,'Albania',0,1,2,1,2,1),(43,'Algeria',0,1,2,1,2,1),(44,'Andorra',0,1,2,1,2,1),(45,'Angola',0,1,2,1,2,1),(46,'Austria',0,1,2,1,2,1),(47,'Bahrain',0,1,2,1,2,1),(48,'Belarus',0,1,2,1,2,1),(49,'Belgium',0,1,2,1,2,1),(50,'Benin',0,1,2,1,2,1),(51,'Bosnia and Herzegovina',0,1,2,1,2,1),(52,'Botswana',0,1,2,1,2,1),(53,'Bulgaria',0,1,2,1,2,1),(54,'Burkina Faso',0,1,2,1,2,1),(55,'Burundi',0,1,2,1,2,1),(56,'Cameroon',0,1,2,1,2,1),(57,'Cape Verde',0,1,2,1,2,1),(58,'Central African Republic',0,1,2,1,2,1),(59,'Chad',0,1,2,1,2,1),(60,'Comoros',0,1,2,1,2,1),(61,'Croatia',0,1,2,1,2,1),(62,'Cyprus',0,1,2,1,2,1),(63,'Czech Republic',0,1,2,1,2,1),(64,'Democratic Republic of the Congo',0,1,2,1,2,1),(65,'Denmark',0,1,2,1,2,1),(66,'Djibouti',0,1,2,1,2,1),(67,'Egypt',0,1,2,1,2,1),(68,'Equatorial Guinea',0,1,2,1,2,1),(69,'Eritrea',0,1,2,1,2,1),(70,'Estonia',0,1,2,1,2,1),(71,'Ethiopia',0,1,2,1,2,1),(72,'Faroe Islands',0,1,2,1,2,1),(73,'Finland',0,1,2,1,2,1),(74,'France',0,1,2,1,2,1),(75,'Gabon',0,1,2,1,2,1),(76,'Gambia',0,1,2,1,2,1),(77,'Georgia',0,1,2,1,2,1),(78,'Germany',0,1,2,1,2,1),(79,'Ghana',0,1,2,1,2,1),(80,'Gibraltar',0,1,2,1,2,1),(81,'Greece',0,1,2,1,2,1),(82,'Guernsey',0,1,2,1,2,1),(83,'Guinea',0,1,2,1,2,1),(84,'Guinea-Bissau',0,1,2,1,2,1),(85,'Hungary',0,1,2,1,2,1),(86,'Iceland',0,1,2,1,2,1),(87,'Iran',0,1,2,1,2,1),(88,'Iraq',0,1,2,1,2,1),(89,'Ireland',0,1,2,1,2,1),(90,'Isle Of Man',0,1,2,1,2,1),(91,'Israel',0,1,2,1,2,1),(92,'Italy',0,1,2,1,2,1),(93,'Ivory Coast',0,1,2,1,2,1),(94,'Jersey',0,1,2,1,2,1),(95,'Jordan',0,1,2,1,2,1),(96,'Kenya',0,1,2,1,2,1),(97,'Kuwait',0,1,2,1,2,1),(98,'Latvia',0,1,2,1,2,1),(99,'Lebanon',0,1,2,1,2,1),(100,'Lesotho',0,1,2,1,2,1),(101,'Liberia',0,1,2,1,2,1),(102,'Libya',0,1,2,1,2,1),(103,'Liechtenstein',0,1,2,1,2,1),(104,'Lithuania',0,1,2,1,2,1),(105,'Luxembourg',0,1,2,1,2,1),(106,'Macedonia',0,1,2,1,2,1),(107,'Madagascar',0,1,2,1,2,1),(108,'Malawi',0,1,2,1,2,1),(109,'Mali',0,1,2,1,2,1),(110,'Malta',0,1,2,1,2,1),(111,'Mauritania',0,1,2,1,2,1),(112,'Mauritius',0,1,2,1,2,1),(113,'Moldova',0,1,2,1,2,1),(114,'Monaco',0,1,2,1,2,1),(115,'Montenegro',0,1,2,1,2,1),(116,'Morocco',0,1,2,1,2,1),(117,'Mozambique',0,1,2,1,2,1),(118,'Namibia',0,1,2,1,2,1),(119,'Netherlands',0,1,2,1,2,1),(120,'Niger',0,1,2,1,2,1),(121,'Nigeria',0,1,2,1,2,1),(122,'Norway',0,1,2,1,2,1),(123,'Oman',0,1,2,1,2,1),(124,'Palestine',0,1,2,1,2,1),(125,'Poland',0,1,2,1,2,1),(126,'Portugal',0,1,2,1,2,1),(127,'Qatar',0,1,2,1,2,1),(128,'Romania',0,1,2,1,2,1),(129,'Rwanda',0,1,2,1,2,1),(130,'San Marino',0,1,2,1,2,1),(131,'Sao Tome & Principe',0,1,2,1,2,1),(132,'Saudi Arabia',0,1,2,1,2,1),(133,'Senegal',0,1,2,1,2,1),(134,'Serbia',0,1,2,1,2,1),(135,'Slovakia',0,1,2,1,2,1),(136,'Slovenia',0,1,2,1,2,1),(137,'Somalia',0,1,2,1,2,1),(138,'South Africa',0,1,2,1,2,1),(139,'Spain',0,1,2,1,2,1),(140,'Sudan',0,1,2,1,2,1),(141,'Swaziland',0,1,2,1,2,1),(142,'Sweden',0,1,2,1,2,1),(143,'Switzerland',0,1,2,1,2,1),(144,'Syria',0,1,2,1,2,1),(145,'Tanzania',0,1,2,1,2,1),(146,'Togo',0,1,2,1,2,1),(147,'Tunisia',0,1,2,1,2,1),(148,'Turkey',0,1,2,1,2,1),(149,'Uganda',0,1,2,1,2,1),(150,'Ukraine',0,1,2,1,2,1),(151,'United Arab Emirates',0,1,2,1,2,1),(152,'United Kingdom',0,1,2,1,2,1),(153,'Vatican City',0,1,2,1,2,1),(154,'Western Sahara',0,1,2,1,2,1),(155,'Yemen',0,1,2,1,2,1),(156,'Zambia',0,1,2,1,2,1),(157,'Zimbabwe (Rhodesia)',0,1,2,1,2,1),(158,' Afghanistan',0,1,3,1,2,1),(159,' American Samoa',0,1,3,1,2,1),(160,' Australia',0,1,3,1,2,1),(161,' Bangladesh',0,1,3,1,2,1),(162,' Bhutan',0,1,3,1,2,1),(163,' Brunei',0,1,3,1,2,1),(164,' Cambodia',0,1,3,1,2,1),(165,' China',0,1,3,1,2,1),(166,' Cook Islands',0,1,3,1,2,1),(167,' East Timor',0,1,3,1,2,1),(168,' Federated States of Micronesia',0,1,3,1,2,1),(169,' Fiji',0,1,3,1,2,1),(170,' French Polynesia',0,1,3,1,2,1),(171,' Guam',0,1,3,1,2,1),(172,' Hong Kong (China)',0,1,3,1,2,1),(173,' India',0,1,3,1,2,1),(174,' Indonesia',0,1,3,1,2,1),(175,' Japan',0,1,3,1,0,1),(176,' Kiribati',0,1,3,1,2,1),(177,' Laos',0,1,3,1,2,1),(178,' Macau (China)',0,1,3,1,2,1),(179,' Malaysia',0,1,3,1,2,1),(180,' Maldives',0,1,3,1,2,1),(181,' Marshall Islands',0,1,3,1,2,1),(182,' Mongolia',0,1,3,1,2,1),(183,' Myanmar',0,1,3,1,2,1),(184,' Nauru',0,1,3,1,2,1),(185,' Nepal',0,1,3,1,2,1),(186,' New Caledonia (associate member)',0,1,3,1,2,1),(187,' New Zealand',0,1,3,1,2,1),(188,' Niue',0,1,3,1,2,1),(189,' North Korea',0,1,3,1,2,1),(190,' Northern Mariana Islands',0,1,3,1,2,1),(191,' Pakistan',0,1,3,1,2,1),(192,' Palau',0,1,3,1,2,1),(193,' Papua New Guinea',0,1,3,1,2,1),(194,' Philippines',0,1,3,1,2,1),(195,' Pitcairn Islands',0,1,3,1,2,1),(196,' Samoa',0,1,3,1,2,1),(197,' Singapore',0,1,3,1,2,1),(198,' Solomon Islands',0,1,3,1,2,1),(199,' South Korea',0,1,3,1,2,1),(200,' Sri Lanka',0,1,3,1,2,1),(201,' Taiwan',0,1,3,1,2,1),(202,' Thailand',0,1,3,1,2,1),(203,' Tokelau',0,1,3,1,2,1),(204,' Tonga',0,1,3,1,2,1),(205,' Tuvalu',0,1,3,1,2,1),(206,' Vanuatu',0,1,3,1,2,1),(207,' Vietnam',0,1,3,1,2,1),(208,' Wallis and Futuna',0,1,3,1,2,1),(209,'Japan',0,1,4,0,2,1);
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_instance`
--

DROP TABLE IF EXISTS `crm_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_instance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_instance`
--

LOCK TABLES `crm_instance` WRITE;
/*!40000 ALTER TABLE `crm_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_instance_sales_stage`
--

DROP TABLE IF EXISTS `crm_instance_sales_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_instance_sales_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crm_instance_id` int(11) NOT NULL,
  `crm_sales_stage_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_crm_instance_sales_stage_crm_instance_id` (`crm_instance_id`),
  KEY `idx_crm_instance_sales_stage_crm_sales_stage_id` (`crm_sales_stage_id`),
  CONSTRAINT `fk_crm_instance_sales_stage_ciid` FOREIGN KEY (`crm_instance_id`) REFERENCES `crm_instance` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_crm_instance_sales_stage_cssid` FOREIGN KEY (`crm_sales_stage_id`) REFERENCES `crm_sales_stage` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_instance_sales_stage`
--

LOCK TABLES `crm_instance_sales_stage` WRITE;
/*!40000 ALTER TABLE `crm_instance_sales_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_instance_sales_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_sales_stage`
--

DROP TABLE IF EXISTS `crm_sales_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_sales_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stage` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_sales_stage`
--

LOCK TABLES `crm_sales_stage` WRITE;
/*!40000 ALTER TABLE `crm_sales_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_sales_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(64) DEFAULT NULL,
  `currency_code` char(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_currency_name` (`currency_name`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES (1,'Andorran Peseta','ADP'),(2,'United Arab Emirates Dirham','AED'),(3,'Afghanistan Afghani','AFA'),(4,'Albanian Lek','ALL'),(5,'Netherlands Antillian Guilder','ANG'),(6,'Angolan Kwanza','AOK'),(7,'Argentine Peso','ARS'),(8,'Australian Dollar','AUD'),(9,'Aruban Florin','AWG'),(10,'Barbados Dollar','BBD'),(11,'Bangladeshi Taka','BDT'),(12,'Bulgarian Lev','BGN'),(13,'Bahraini Dinar','BHD'),(14,'Burundi Franc','BIF'),(15,'Bermudian Dollar','BMD'),(16,'Brunei Dollar','BND'),(17,'Bolivian Boliviano','BOB'),(18,'Brazilian Real','BRL'),(19,'Bahamian Dollar','BSD'),(20,'Bhutan Ngultrum','BTN'),(21,'Burma Kyat','BUK'),(22,'Botswanian Pula','BWP'),(23,'Belize Dollar','BZD'),(24,'Canadian Dollar','CAD'),(25,'Swiss Franc','CHF'),(26,'Chilean Unidades de Fomento','CLF'),(27,'Chilean Peso','CLP'),(28,'Yuan (Chinese) Renminbi','CNY'),(29,'Colombian Peso','COP'),(30,'Costa Rican Colon','CRC'),(31,'Czech Republic Koruna','CZK'),(32,'Cuban Peso','CUP'),(33,'Cape Verde Escudo','CVE'),(34,'Cyprus Pound','CYP'),(35,'Danish Krone','DKK'),(36,'Dominican Peso','DOP'),(37,'Algerian Dinar','DZD'),(38,'Ecuador Sucre','ECS'),(39,'Egyptian Pound','EGP'),(40,'Estonian Kroon (EEK)','EEK'),(41,'Ethiopian Birr','ETB'),(42,'Euro','EUR'),(43,'Fiji Dollar','FJD'),(44,'Falkland Islands Pound','FKP'),(45,'British Pound','GBP'),(46,'Ghanaian Cedi','GHC'),(47,'Gibraltar Pound','GIP'),(48,'Gambian Dalasi','GMD'),(49,'Guinea Franc','GNF'),(50,'Guatemalan Quetzal','GTQ'),(51,'Guinea-Bissau Peso','GWP'),(52,'Guyanan Dollar','GYD'),(53,'Hong Kong Dollar','HKD'),(54,'Honduran Lempira','HNL'),(55,'Haitian Gourde','HTG'),(56,'Hungarian Forint','HUF'),(57,'Indonesian Rupiah','IDR'),(58,'Irish Punt','IEP'),(59,'Israeli Shekel','ILS'),(60,'Indian Rupee','INR'),(61,'Iraqi Dinar','IQD'),(62,'Iranian Rial','IRR'),(63,'Jamaican Dollar','JMD'),(64,'Jordanian Dinar','JOD'),(65,'Japanese Yen','JPY'),(66,'Kenyan Schilling','KES'),(67,'Kampuchean (Cambodian) Riel','KHR'),(68,'Comoros Franc','KMF'),(69,'North Korean Won','KPW'),(70,'(South) Korean Won','KRW'),(71,'Kuwaiti Dinar','KWD'),(72,'Cayman Islands Dollar','KYD'),(73,'Lao Kip','LAK'),(74,'Lebanese Pound','LBP'),(75,'Sri Lanka Rupee','LKR'),(76,'Liberian Dollar','LRD'),(77,'Lesotho Loti','LSL'),(78,'Libyan Dinar','LYD'),(79,'Moroccan Dirham','MAD'),(80,'Malagasy Franc','MGF'),(81,'Mongolian Tugrik','MNT'),(82,'Macau Pataca','MOP'),(83,'Mauritanian Ouguiya','MRO'),(84,'Maltese Lira','MTL'),(85,'Mauritius Rupee','MUR'),(86,'Maldive Rufiyaa','MVR'),(87,'Malawi Kwacha','MWK'),(88,'Mexican Peso','MXP'),(89,'Malaysian Ringgit','MYR'),(90,'Mozambique Metical','MZM'),(91,'Namibian Dollar','NAD'),(92,'Nigerian Naira','NGN'),(93,'Nicaraguan Cordoba','NIO'),(94,'Norwegian Kroner','NOK'),(95,'Nepalese Rupee','NPR'),(96,'New Zealand Dollar','NZD'),(97,'Omani Rial','OMR'),(98,'Panamanian Balboa','PAB'),(99,'Peruvian Nuevo Sol','PEN'),(100,'Papua New Guinea Kina','PGK'),(101,'Philippine Peso','PHP'),(102,'Pakistan Rupee','PKR'),(103,'Polish Zloty','PLN'),(104,'Paraguay Guarani','PYG'),(105,'Qatari Rial','QAR'),(106,'Romanian Leu','RON'),(107,'Rwanda Franc','RWF'),(108,'Saudi Arabian Riyal','SAR'),(109,'Solomon Islands Dollar','SBD'),(110,'Seychelles Rupee','SCR'),(111,'Sudanese Pound','SDP'),(112,'Swedish Krona','SEK'),(113,'Singapore Dollar','SGD'),(114,'St. Helena Pound','SHP'),(115,'Sierra Leone Leone','SLL'),(116,'Somali Schilling','SOS'),(117,'Suriname Guilder','SRG'),(118,'Sao Tome and Principe Dobra','STD'),(119,'Russian Ruble','RUB'),(120,'El Salvador Colon','SVC'),(121,'Syrian Potmd','SYP'),(122,'Swaziland Lilangeni','SZL'),(123,'Thai Baht','THB'),(124,'Tunisian Dinar','TND'),(125,'Tongan Paanga','TOP'),(126,'East Timor Escudo','TPE'),(127,'Turkish Lira','TRY'),(128,'Trinidad and Tobago Dollar','TTD'),(129,'Taiwan Dollar','TWD'),(130,'Tanzanian Schilling','TZS'),(131,'Uganda Shilling','UGX'),(132,'US Dollar','USD'),(133,'Uruguayan Peso','UYU'),(134,'Venezualan Bolivar','VEF'),(135,'Vietnamese Dong','VND'),(136,'Vanuatu Vatu','VUV'),(137,'Samoan Tala','WST'),(138,'CommunautÃ© FinanciÃ¨re Africaine BEAC, Francs','XAF'),(139,'Silver, Ounces','XAG'),(140,'Gold, Ounces','XAU'),(141,'East Caribbean Dollar','XCD'),(142,'International Monetary Fund (IMF) Special Drawing Rights','XDR'),(143,'CommunautÃ© FinanciÃ¨re Africaine BCEAO - Francs','XOF'),(144,'Palladium Ounces','XPD'),(145,'Comptoirs FranÃ§ais du Pacifique Francs','XPF'),(146,'Platinum, Ounces','XPT'),(147,'Democratic Yemeni Dinar','YDD'),(148,'Yemeni Rial','YER'),(149,'New Yugoslavia Dinar','YUD'),(150,'South African Rand','ZAR'),(151,'Zambian Kwacha','ZMK'),(152,'Zaire Zaire','ZRZ'),(153,'Zimbabwe Dollar','ZWD'),(154,'Slovak Koruna','SKK'),(155,'Armenian Dram','AMD');
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_view`
--

DROP TABLE IF EXISTS `dashboard_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_view` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `metadata` mediumtext,
  `filter` varchar(100) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dashboard_view_url_unique` (`url`,`filter`),
  KEY `FK_dashoard_view_created_by` (`created_by`),
  CONSTRAINT `FK_dashoard_view_created_by` FOREIGN KEY (`created_by`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_view`
--

LOCK TABLES `dashboard_view` WRITE;
/*!40000 ALTER TABLE `dashboard_view` DISABLE KEYS */;
INSERT INTO `dashboard_view` VALUES (12,'dashboard/analyze/measure/win-loss-trend-analysis/competitor?chartType=columnStacked','view metadata','view filter','2015-12-11 10:50:22','guest@phaladata.com');
/*!40000 ALTER TABLE `dashboard_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo`
--

DROP TABLE IF EXISTS `geo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo`
--

LOCK TABLES `geo` WRITE;
/*!40000 ALTER TABLE `geo` DISABLE KEYS */;
INSERT INTO `geo` VALUES (1,'3 Geo Setup'),(2,'4 Geo Setup');
/*!40000 ALTER TABLE `geo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_business_strategy`
--

DROP TABLE IF EXISTS `global_business_strategy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global_business_strategy` (
  `id` int(11) NOT NULL,
  `total_revenue_target` double NOT NULL,
  `marketing_inf_revenue_target` double NOT NULL,
  `fiscal_start` varchar(15) NOT NULL COMMENT 'MM/DD',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_business_strategy`
--

LOCK TABLES `global_business_strategy` WRITE;
/*!40000 ALTER TABLE `global_business_strategy` DISABLE KEYS */;
/*!40000 ALTER TABLE `global_business_strategy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `impact_indicator_target`
--

DROP TABLE IF EXISTS `impact_indicator_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impact_indicator_target` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indicator_name` varchar(50) NOT NULL,
  `target_value` decimal(10,0) NOT NULL,
  `valid_from` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `valid_upto` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impact_indicator_target`
--

LOCK TABLES `impact_indicator_target` WRITE;
/*!40000 ALTER TABLE `impact_indicator_target` DISABLE KEYS */;
INSERT INTO `impact_indicator_target` VALUES (1,'NEWCUSTOMER',400,'2015-11-01 06:30:00','2015-11-30 06:30:00','2015-11-30 10:10:40','2015-11-30 10:10:40'),(2,'NEWCUSTOMER',400,'2015-07-01 06:30:00','2015-07-30 06:30:00','2015-11-30 10:10:40','2015-11-30 10:18:51'),(3,'NEWCUSTOMER',400,'2015-10-01 06:30:00','2015-10-30 06:30:00','2015-11-30 10:10:40','2015-11-30 10:18:51');
/*!40000 ALTER TABLE `impact_indicator_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `industry`
--

DROP TABLE IF EXISTS `industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `industry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `industry_name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_industry_name` (`industry_name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `industry`
--

LOCK TABLES `industry` WRITE;
/*!40000 ALTER TABLE `industry` DISABLE KEYS */;
INSERT INTO `industry` VALUES (1,'Consumer Goods and Services'),(2,'Energy'),(3,'Financials'),(4,'Government Agencies'),(5,'Healthcare'),(6,'High Technology'),(7,'Industrials'),(8,'Materials'),(9,'Retail'),(10,'Telecommunications'),(11,'Utilities');
/*!40000 ALTER TABLE `industry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_history`
--

DROP TABLE IF EXISTS `job_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_history` (
  `id` bigint(20) NOT NULL,
  `from_time` datetime DEFAULT NULL,
  `batch_size` int(11) NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `offset_record` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `to_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_history`
--

LOCK TABLES `job_history` WRITE;
/*!40000 ALTER TABLE `job_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manual_campaign_input`
--

DROP TABLE IF EXISTS `manual_campaign_input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manual_campaign_input` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(45) DEFAULT NULL,
  `campaign_name` varchar(45) DEFAULT NULL,
  `parent_campaign_id` varchar(45) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `touch_point_label` varchar(50) DEFAULT NULL,
  `total_campaign_cost` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaign_id_UNIQUE` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manual_campaign_input`
--

LOCK TABLES `manual_campaign_input` WRITE;
/*!40000 ALTER TABLE `manual_campaign_input` DISABLE KEYS */;
/*!40000 ALTER TABLE `manual_campaign_input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persistent_login`
--

DROP TABLE IF EXISTS `persistent_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `persistent_login` (
  `username` varchar(64) NOT NULL,
  `series` varchar(64) NOT NULL,
  `token` varchar(64) NOT NULL,
  `last_used` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`series`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persistent_login`
--

LOCK TABLES `persistent_login` WRITE;
/*!40000 ALTER TABLE `persistent_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `persistent_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` VALUES (1,'AMS'),(2,'EMEA'),(3,'APJ'),(4,'Japan');
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region_country`
--

DROP TABLE IF EXISTS `region_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region_country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_region_country_region_id` (`region_id`),
  KEY `fk_country_id` (`country_id`),
  CONSTRAINT `fk_country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_region_id` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region_country`
--

LOCK TABLES `region_country` WRITE;
/*!40000 ALTER TABLE `region_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `region_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_search`
--

DROP TABLE IF EXISTS `saved_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saved_search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `search_key` varchar(100) NOT NULL,
  `columns` mediumtext,
  `start_page_no` int(11) NOT NULL,
  `current_page_no` int(11) NOT NULL,
  `page_size` int(11) NOT NULL,
  `filters` varchar(255) DEFAULT NULL,
  `sort_on_doc` varchar(50) DEFAULT NULL,
  `sort_on_field` varchar(50) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_saved_search_created_by` (`created_by`),
  CONSTRAINT `FK_saved_search_created_by` FOREIGN KEY (`created_by`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_search`
--

LOCK TABLES `saved_search` WRITE;
/*!40000 ALTER TABLE `saved_search` DISABLE KEYS */;
INSERT INTO `saved_search` VALUES (15,'search-hugh','hugh','{\"manualBusinessStrategy\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"businessStrategyDocumentRefId\":null,\"businessRevenueTarget\":null,\"marketingInfluencedRevenueTarget\":[],\"marketingBudgetSpend\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"manualCampaignStrategy\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"campaignStrategyDocumentRefId\":null,\"campaignId\":null,\"parentCampaignName\":null,\"parentCampaignId\":null,\"subCampaignName\":null,\"campaignStart\":null,\"campaignRuntime\":null,\"productFamily\":[],\"customerSeg\":[],\"targetAudience\":[],\"targetRegions\":[],\"leadSources\":[],\"touchpoints\":[],\"assets\":[],\"totalCost\":null,\"dealsClosed\":null,\"marketingInfluencedRevenue\":null,\"createdBy\":null,\"createdDate\":null,\"updatedBy\":null,\"updatedDate\":null,\"documentRefId\":null},\"mapCampaign\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"campaignId\":null,\"campaignName\":null,\"parentCampaignId\":null,\"parentCampaignName\":null,\"campaignDocumentRefId\":null,\"startDate\":null,\"actualCost\":0.0,\"campaignType\":null,\"products\":[],\"createdDate\":null,\"createdBy\":null,\"currentStatus\":null,\"budgetedCost\":0.0,\"description\":null,\"campaignOwner\":null,\"runtime\":null,\"endDate\":null,\"expectedRevenue\":0.0,\"leadSources\":[],\"touchPoints\":[],\"assets\":[],\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"mapLead\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"leadId\":null,\"leadName\":null,\"website\":null,\"annualRevenue\":0.0,\"noOfEmployees\":0,\"industry\":null,\"email\":null,\"jobTitle\":null,\"companyName\":null,\"companyId\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"leadOwner\":null,\"leadSource\":null,\"leadStatus\":null,\"createdBy\":null,\"campaignId\":null,\"campaignName\":null,\"billingAddress\":null,\"shippingAddress\":null,\"phone\":null,\"mobilePhone\":null,\"sicCode\":null,\"lastName\":null,\"rating\":null,\"leadScore\":null,\"middleName\":null,\"department\":null,\"leadDocumentRefId\":null,\"assets\":[],\"lastModifiedBy\":null,\"touchPoints\":null,\"documentRefId\":null},\"mapOpportunity\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityDocumentRefId\":null,\"opportunityId\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"amount\":0.0,\"annualRevenue\":0.0,\"closedDate\":null,\"expectedRevenue\":0.0,\"companyInformation\":null,\"companyName\":null,\"opportunityOwner\":null,\"isWon\":null,\"isClosed\":null,\"leadSource\":null,\"name\":null,\"nextStep\":null,\"probability\":0.0,\"stage\":null,\"opportunityType\":null,\"createdBy\":null,\"status\":null,\"accountId\":null,\"address\":null,\"industry\":null,\"noOfEmployees\":0,\"productInterest\":null,\"mainCompetitors\":null,\"partners\":null,\"fiscal\":null,\"fiscalQuarter\":null,\"fiscalYear\":null,\"forecastCategoryName\":null,\"productQuantity\":0,\"campaignId\":null,\"campaignName\":null,\"assetId\":null,\"assetType\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"mapAccount\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"accountDocumentRefId\":null,\"accountId\":null,\"name\":null,\"company\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"annualRevenue\":0.0,\"organizationName\":null,\"organizationId\":null,\"billingAddress\":null,\"accountOwner\":null,\"accountOwnerId\":null,\"industry\":null,\"mainPhone\":null,\"noOfEmployees\":null,\"sicCode\":null,\"accountType\":null,\"website\":null,\"tickerSymbol\":null,\"shippingAddress\":null,\"email\":null,\"leadSource\":null,\"contactOwner\":null,\"documentRefId\":null},\"mapAsset\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"assetDocumentRefId\":null,\"assetId\":null,\"assetName\":null,\"createdBy\":null,\"createdAt\":null,\"updatedBy\":null,\"updatedAt\":null,\"documentRefId\":null},\"mapSalesPerson\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"userDocumentRefId\":null,\"userId\":null,\"firstName\":null,\"lastName\":null,\"userName\":null,\"email\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"createdBy\":null,\"mobilePhone\":null,\"title\":null,\"active\":null,\"lastModifiedBy\":null,\"company\":null,\"documentRefId\":null},\"crmAccount\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"accountDocumentRefId\":null,\"accountId\":null,\"accountName\":null,\"externalCompanyId\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"annualRevenue\":0.0,\"billingAddress\":null,\"shippingAddress\":null,\"industry\":null,\"sicCode\":null,\"website\":null,\"accountOwner\":null,\"parentAccount\":null,\"accountNumber\":null,\"accountSource\":null,\"contactOwner\":null,\"tickerSymbol\":null,\"numberOfLocations\":0,\"upsellOpportunity\":null,\"tradeStyle\":null,\"site\":null,\"documentRefId\":null},\"crmCampaign\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"campaignDocumentRefId\":null,\"campaignId\":null,\"campaignName\":null,\"parentCampaignId\":null,\"startDate\":null,\"actualCost\":0.0,\"campaignType\":null,\"createdDate\":null,\"createdBy\":null,\"status\":null,\"budgetedCost\":0.0,\"campaignOwner\":null,\"numTotalOpportunities\":0,\"numWonOpportunities\":0,\"totalContacts\":0,\"totalValueWonOpportunities\":0.0,\"runtime\":null,\"endDate\":null,\"expectedRevenue\":0.0,\"lastModifiedDate\":null,\"numOfLeads\":0,\"totalValueOpportunities\":0.0,\"description\":null,\"lastModifiedBy\":null,\"parentCampaignName\":null,\"documentRefId\":null},\"crmContact\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"contactDocumentRefId\":null,\"contactId\":null,\"accountId\":null,\"contactName\":null,\"contactNumber\":null,\"contactOwner\":null,\"email\":null,\"createdBy\":null,\"lastModifiedBy\":null,\"status\":null,\"activatedDate\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"name\":null,\"leadSource\":null,\"documentRefId\":null},\"crmContract\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"contractDocumentRefId\":null,\"accountId\":null,\"contractId\":null,\"contractName\":null,\"contractNumber\":null,\"contractOwner\":null,\"status\":null,\"activatedDate\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmInvoice\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"invoiceDocumentRefId\":null,\"invoiceId\":null,\"createdBy\":null,\"description\":null,\"lastModifiedBy\":null,\"invoiceName\":null,\"orderId\":null,\"status\":null,\"createdDate\":null,\"invoiceAmount\":0.0,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmLead\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"leadDocumentRefId\":null,\"leadId\":null,\"leadName\":null,\"annualRevenue\":0.0,\"noOfEmployees\":0,\"industry\":null,\"email\":null,\"title\":null,\"company\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"leadOwner\":null,\"leadSource\":null,\"leadStatus\":null,\"createdBy\":null,\"campaignId\":null,\"campaignName\":null,\"billingAddress\":null,\"shippingAddress\":null,\"phone\":null,\"sicCode\":null,\"rating\":null,\"leadScore\":null,\"accountName\":null,\"accountId\":null,\"website\":null,\"productInterest\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"crmOpportunity\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityDocumentRefId\":null,\"opportunityId\":null,\"createdOn\":null,\"lastModifiedDate\":null,\"amount\":0.0,\"closedDate\":null,\"expectedRevenue\":0.0,\"companyInformation\":null,\"owner\":null,\"leadSource\":null,\"opportunityName\":null,\"nextStep\":null,\"probabilityPerc\":0,\"stage\":null,\"opportunityType\":null,\"createdBy\":null,\"opportunityStatus\":null,\"accountId\":null,\"companyName\":null,\"location\":null,\"annualRevenue\":0.0,\"industry\":null,\"mainCompetitors\":[],\"site\":null,\"fiscal\":null,\"fiscalQuarter\":null,\"fiscalYear\":null,\"fiscalCategory\":null,\"quantity\":0,\"primaryCampSource\":null,\"description\":null,\"painPoints\":[],\"orderNumber\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"crmOpportunityCompetitor\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityCompetitorDocumentRefId\":null,\"createdBy\":null,\"competitorName\":null,\"opportunityId\":null,\"strengths\":null,\"weaknesses\":null,\"lastModifiedBy\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"url\":null,\"documentRefId\":null},\"crmOpportunityPartner\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"partnerDocumentRefId\":null,\"partnerId\":null,\"partnerRole\":null,\"accountFromId\":null,\"accountToId\":null,\"opportunityId\":null,\"createdBy\":null,\"lastModifiedBy\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmOpportunityProduct\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityProductDocumentRefId\":null,\"opportunityId\":null,\"product\":null,\"quantity\":0,\"listPrice\":0.0,\"total\":0.0,\"salesPrice\":0.0,\"sortOrder\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"lineDescription\":null,\"productCode\":null,\"createdBy\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"crmProduct\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"productDocumentRefId\":null,\"productId\":null,\"active\":null,\"createdBy\":null,\"lastModifiedBy\":null,\"productCode\":null,\"productDescription\":null,\"productFamily\":null,\"productName\":null,\"createdDate\":null,\"defaultPrice\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmOrderDetails\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"orderDetailsDocumentRefId\":null,\"accountId\":null,\"activatedBy\":null,\"activatedDate\":null,\"billingAddress\":null,\"billToContact\":null,\"createdBy\":null,\"contractName\":null,\"contractNumber\":null,\"opportunityId\":null,\"orderName\":null,\"orderNumber\":null,\"amount\":0,\"orderOwner\":null,\"orderReferenceNumber\":null,\"poNumber\":null,\"poDate\":null,\"status\":null,\"lastModBy\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmOrderProduct\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"orderProductDocumentRefId\":null,\"createdBy\":null,\"order\":null,\"orderProductNumber\":null,\"productId\":null,\"productCode\":null,\"totalPrice\":0,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"quantity\":0,\"unitPrice\":0,\"createdDate\":null,\"documentRefId\":null},\"crmUser\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"userDocumentRefId\":null,\"userId\":null,\"firstname\":null,\"lastname\":null,\"email\":null,\"lastModifiedDate\":null,\"createdBy\":null,\"mobilePhone\":null,\"title\":null,\"company\":null,\"active\":null,\"username\":null,\"timezone\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"erpAccount\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"accountDocumentRefId\":null,\"accountId\":null,\"salesOwner\":null,\"salesOwnerId\":null,\"sicCode\":null,\"customerName\":null,\"parentAccountId\":null,\"parentAccountName\":null,\"site\":null,\"geo\":null,\"industry\":null,\"annualRevenue\":0.0,\"company\":null,\"emailAddress\":null,\"companyId\":null,\"companyWebsite\":null,\"phone\":null,\"noOfEmployees\":0,\"billingAddress\":null,\"shippingAddress\":null,\"leadSource\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"erpInvoice\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"invoiceDocumentRefId\":null,\"invoiceId\":null,\"invoiceName\":null,\"opportunityId\":null,\"saleOrderId\":null,\"accountId\":null,\"description\":null,\"status\":null,\"leadSource\":null,\"salesPerson\":null,\"accountName\":null,\"salesAmount\":0.0,\"productQuantity\":0,\"productUnitPrice\":0.0,\"salesCurrency\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"erpOpportunity\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityDocumentRefId\":null,\"opportunityId\":null,\"opportunityName\":null,\"closedDate\":null,\"owner\":null,\"accountId\":null,\"status\":null,\"probability\":null,\"opportunityType\":null,\"companyName\":null,\"website\":null,\"billingAddress\":null,\"shippingAddress\":null,\"location\":null,\"salesRepName\":null,\"expectedRevenue\":0.0,\"opportunityAmount\":0.0,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"erpOpportunityCompetitor\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityCompetitorDocumentRefId\":null,\"competitorName\":null,\"opportunityId\":null,\"strengths\":null,\"weaknesses\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"url\":null,\"documentRefId\":null},\"erpOrderItem\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"itemDocumentId\":null,\"itemId\":null,\"itemName\":null,\"upccode\":null,\"quantity\":null,\"totalValue\":null,\"itemType\":null,\"cost\":null,\"createdDate\":null,\"createdBy\":null,\"lastModifiedDate\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"erpSalesOrder\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"salesOrderDocumentRefId\":null,\"orderId\":null,\"orderOwner\":null,\"accountName\":null,\"opportunityId\":null,\"activatedDate\":null,\"orderInvoiceId\":null,\"customerPo\":null,\"items\":[],\"salesAmount\":null,\"customerId\":null,\"salesAccountCurrentOrders\":[],\"salesOrdeAccountYTD\":null,\"leadSource\":null,\"partner\":null,\"status\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"activatedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null}}',1,1,25,'{\"id\":2,\"value\":\"filter2\"}|{\"id\":1,\"value\":\"filter1\"}',NULL,NULL,'2015-12-11 10:34:39','guest@phaladata.com');
/*!40000 ALTER TABLE `saved_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_authority`
--

DROP TABLE IF EXISTS `user_authority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_authority` (
  `username` varchar(100) NOT NULL,
  `authority_name` varchar(50) NOT NULL,
  PRIMARY KEY (`username`,`authority_name`),
  KEY `FK_tnnyxjpcvg2aj0d0i6ufnabm2` (`authority_name`),
  CONSTRAINT `FK_h5t8nplqarkfi7tscc9unyr7y` FOREIGN KEY (`username`) REFERENCES `user_info` (`username`),
  CONSTRAINT `FK_tnnyxjpcvg2aj0d0i6ufnabm2` FOREIGN KEY (`authority_name`) REFERENCES `authority` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_authority`
--

LOCK TABLES `user_authority` WRITE;
/*!40000 ALTER TABLE `user_authority` DISABLE KEYS */;
INSERT INTO `user_authority` VALUES ('admin@phaladata.com','ROLE_ADMIN'),('guest@phaladata.com','ROLE_GUEST');
/*!40000 ALTER TABLE `user_authority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_info` (
  `username` varchar(100) NOT NULL,
  `active` bit(1) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_info`
--

LOCK TABLES `user_info` WRITE;
/*!40000 ALTER TABLE `user_info` DISABLE KEYS */;
INSERT INTO `user_info` VALUES ('admin@phaladata.com','','Admin','Admin','$2a$10$n2usJ4tUqZF8CydUlqgupOgBjxW5QomRuDhlSJrSTjCM4iUAiy6W.'),('guest@phaladata.com','','Guest','Guest','$2a$10$E2PSxeWK79SKFNXp4SZ6C.qPN3vQZ4W4.QMFi7TpovSAFpoteyWu2');
/*!40000 ALTER TABLE `user_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_login_token`
--

DROP TABLE IF EXISTS `user_login_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_login_token` (
  `id` varchar(255) NOT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `user` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_nv6inptdyrxxwyap5fax7erin` (`user`),
  CONSTRAINT `FK_nv6inptdyrxxwyap5fax7erin` FOREIGN KEY (`user`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_login_token`
--

LOCK TABLES `user_login_token` WRITE;
/*!40000 ALTER TABLE `user_login_token` DISABLE KEYS */;
INSERT INTO `user_login_token` VALUES ('admin@phaladata.com#1452684886248#682c0f25b34e105c9491fa246dc824e5','2016-01-13 10:35:29','admin@phaladata.com'),('admin@phaladata.com#1452690290342#48afc092021c467e2b83f8620c843b37','2016-01-13 12:33:14','admin@phaladata.com'),('admin@phaladata.com#1452708132893#57f463958ee2a95b6b40c4cb57576390','2016-01-13 17:24:42','admin@phaladata.com'),('admin@phaladata.com#1452764209112#5ad69cfabbb83fd54f1c3f7e3da14b1f','2016-01-14 08:37:40','admin@phaladata.com');
/*!40000 ALTER TABLE `user_login_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_service_vendor`
--

DROP TABLE IF EXISTS `web_service_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_service_vendor` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `vendor_type` varchar(250) NOT NULL,
  `instance_name` varchar(250) NOT NULL,
  `vendor_name` varchar(250) NOT NULL DEFAULT '',
  `version` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendor_type_instance` (`vendor_type`,`instance_name`,`vendor_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_service_vendor`
--

LOCK TABLES `web_service_vendor` WRITE;
/*!40000 ALTER TABLE `web_service_vendor` DISABLE KEYS */;
INSERT INTO `web_service_vendor` VALUES (5,'dataArrMAP','oracle_eloqua-0','oracle_eloqua','0',1);
/*!40000 ALTER TABLE `web_service_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_service_vendor_configuration_detail`
--

DROP TABLE IF EXISTS `web_service_vendor_configuration_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_service_vendor_configuration_detail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `web_service_vendor_id` bigint(20) NOT NULL,
  `attribute_name` varchar(250) NOT NULL,
  `attribute_value` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendor_attribute` (`web_service_vendor_id`,`attribute_name`),
  CONSTRAINT `web_service_vendor_FK` FOREIGN KEY (`web_service_vendor_id`) REFERENCES `web_service_vendor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_service_vendor_configuration_detail`
--

LOCK TABLES `web_service_vendor_configuration_detail` WRITE;
/*!40000 ALTER TABLE `web_service_vendor_configuration_detail` DISABLE KEYS */;
INSERT INTO `web_service_vendor_configuration_detail` VALUES (8,5,'apiUserKey',''),(9,5,'class','class com.miri.search.data.DatasourceSetup'),(10,5,'clientId',''),(11,5,'clientSecret',''),(12,5,'companyName','hhhhhh'),(13,5,'datasourceId','0'),(14,5,'email',''),(15,5,'isConnected','false'),(16,5,'password','admin123'),(17,5,'securityToken',''),(18,5,'showApiUserKey','false'),(19,5,'showClientId','false'),(20,5,'showClientSecret','false'),(21,5,'showCompanyName','true'),(22,5,'showEmail','false'),(23,5,'showPassword','true'),(24,5,'showUrl','true'),(25,5,'showUsername','true'),(26,5,'system','oracle_eloqua'),(27,5,'url','test'),(28,5,'username','admin@phaladata.com');
/*!40000 ALTER TABLE `web_service_vendor_configuration_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-01-14 14:38:48
