-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: phaladata
-- ------------------------------------------------------
-- Server version	5.7.9-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(45) NOT NULL,
  `business_unit` varchar(45) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) DEFAULT NULL,
  `address3` varchar(50) DEFAULT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `zip_code` varchar(50) NOT NULL,
  `country_id` int(11) NOT NULL,
  `industry` varchar(45) NOT NULL,
  `no_of_employees` int(11) DEFAULT NULL,
  `preferred_currency` varchar(3) NOT NULL,
  `annual_revenue` double DEFAULT NULL,
  `website` varchar(100) NOT NULL,
  `logo` mediumblob,
  PRIMARY KEY (`id`),
  KEY `fk_account_country_id` (`country_id`),
  CONSTRAINT `fk_account_country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authority`
--

DROP TABLE IF EXISTS `authority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authority` (
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authority`
--

LOCK TABLES `authority` WRITE;
/*!40000 ALTER TABLE `authority` DISABLE KEYS */;
INSERT INTO `authority` VALUES ('ROLE_ADMIN'),('ROLE_GUEST'),('ROLE_USER');
/*!40000 ALTER TABLE `authority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `continent`
--

DROP TABLE IF EXISTS `continent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `continent` (
  `id` int(11) NOT NULL,
  `continent_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `continent`
--

LOCK TABLES `continent` WRITE;
/*!40000 ALTER TABLE `continent` DISABLE KEYS */;
INSERT INTO `continent` VALUES (1,'Africa'),(2,'Antarctica'),(3,'Asia'),(4,'Australia'),(5,'Europe'),(6,'North America'),(7,'South America');
/*!40000 ALTER TABLE `continent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(50) NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `continent_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_country_continent_id` (`continent_id`),
  CONSTRAINT `fk_country_continent_id` FOREIGN KEY (`continent_id`) REFERENCES `continent` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'United States of America',1,6),(2,'India',0,3);
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_instance`
--

DROP TABLE IF EXISTS `crm_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_instance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_instance`
--

LOCK TABLES `crm_instance` WRITE;
/*!40000 ALTER TABLE `crm_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_instance_sales_stage`
--

DROP TABLE IF EXISTS `crm_instance_sales_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_instance_sales_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crm_instance_id` int(11) NOT NULL,
  `crm_sales_stage_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_crm_instance_sales_stage_crm_instance_id` (`crm_instance_id`),
  KEY `idx_crm_instance_sales_stage_crm_sales_stage_id` (`crm_sales_stage_id`),
  CONSTRAINT `fk_crm_instance_sales_stage_ciid` FOREIGN KEY (`crm_instance_id`) REFERENCES `crm_instance` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_crm_instance_sales_stage_cssid` FOREIGN KEY (`crm_sales_stage_id`) REFERENCES `crm_sales_stage` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_instance_sales_stage`
--

LOCK TABLES `crm_instance_sales_stage` WRITE;
/*!40000 ALTER TABLE `crm_instance_sales_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_instance_sales_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_sales_stage`
--

DROP TABLE IF EXISTS `crm_sales_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crm_sales_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stage` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_sales_stage`
--

LOCK TABLES `crm_sales_stage` WRITE;
/*!40000 ALTER TABLE `crm_sales_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_sales_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_view`
--

DROP TABLE IF EXISTS `dashboard_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_view` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `metadata` mediumtext,
  `filter` varchar(100) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dashboard_view_url_unique` (`url`,`filter`),
  KEY `FK_dashoard_view_created_by` (`created_by`),
  CONSTRAINT `FK_dashoard_view_created_by` FOREIGN KEY (`created_by`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_view`
--

LOCK TABLES `dashboard_view` WRITE;
/*!40000 ALTER TABLE `dashboard_view` DISABLE KEYS */;
INSERT INTO `dashboard_view` VALUES (12,'dashboard/analyze/measure/win-loss-trend-analysis/competitor?chartType=columnStacked','view metadata','view filter','2015-12-11 10:50:22','guest@phaladata.com');
/*!40000 ALTER TABLE `dashboard_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_business_strategy`
--

DROP TABLE IF EXISTS `global_business_strategy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global_business_strategy` (
  `id` int(11) NOT NULL,
  `total_revenue_target` double NOT NULL,
  `marketing_inf_revenue_target` double NOT NULL,
  `fiscal_start` varchar(15) NOT NULL COMMENT 'MM/DD',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_business_strategy`
--

LOCK TABLES `global_business_strategy` WRITE;
/*!40000 ALTER TABLE `global_business_strategy` DISABLE KEYS */;
/*!40000 ALTER TABLE `global_business_strategy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `impact_indicator_target`
--

DROP TABLE IF EXISTS `impact_indicator_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impact_indicator_target` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indicator_name` varchar(50) NOT NULL,
  `target_value` decimal(10,0) NOT NULL,
  `valid_from` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `valid_upto` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impact_indicator_target`
--

LOCK TABLES `impact_indicator_target` WRITE;
/*!40000 ALTER TABLE `impact_indicator_target` DISABLE KEYS */;
INSERT INTO `impact_indicator_target` VALUES (1,'NEWCUSTOMER',400,'2015-11-01 06:30:00','2015-11-30 06:30:00','2015-11-30 10:10:40','2015-11-30 10:10:40'),(2,'NEWCUSTOMER',400,'2015-07-01 06:30:00','2015-07-30 06:30:00','2015-11-30 10:10:40','2015-11-30 10:18:51'),(3,'NEWCUSTOMER',400,'2015-10-01 06:30:00','2015-10-30 06:30:00','2015-11-30 10:10:40','2015-11-30 10:18:51');
/*!40000 ALTER TABLE `impact_indicator_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_history`
--

DROP TABLE IF EXISTS `job_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_history` (
  `id` bigint(20) NOT NULL,
  `from_time` datetime DEFAULT NULL,
  `batch_size` int(11) NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `offset_record` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `to_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_history`
--

LOCK TABLES `job_history` WRITE;
/*!40000 ALTER TABLE `job_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manual_campaign_input`
--

DROP TABLE IF EXISTS `manual_campaign_input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manual_campaign_input` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(45) DEFAULT NULL,
  `campaign_name` varchar(45) DEFAULT NULL,
  `parent_campaign_id` varchar(45) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `touch_point_label` varchar(50) DEFAULT NULL,
  `total_campaign_cost` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaign_id_UNIQUE` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manual_campaign_input`
--

LOCK TABLES `manual_campaign_input` WRITE;
/*!40000 ALTER TABLE `manual_campaign_input` DISABLE KEYS */;
/*!40000 ALTER TABLE `manual_campaign_input` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persistent_login`
--

DROP TABLE IF EXISTS `persistent_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `persistent_login` (
  `username` varchar(64) NOT NULL,
  `series` varchar(64) NOT NULL,
  `token` varchar(64) NOT NULL,
  `last_used` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`series`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persistent_login`
--

LOCK TABLES `persistent_login` WRITE;
/*!40000 ALTER TABLE `persistent_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `persistent_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region_country`
--

DROP TABLE IF EXISTS `region_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region_country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_region_country_region_id` (`region_id`),
  KEY `fk_country_id` (`country_id`),
  CONSTRAINT `fk_country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_region_id` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region_country`
--

LOCK TABLES `region_country` WRITE;
/*!40000 ALTER TABLE `region_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `region_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_search`
--

DROP TABLE IF EXISTS `saved_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saved_search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `search_key` varchar(100) NOT NULL,
  `columns` mediumtext,
  `start_page_no` int(11) NOT NULL,
  `current_page_no` int(11) NOT NULL,
  `page_size` int(11) NOT NULL,
  `filters` varchar(255) DEFAULT NULL,
  `sort_on_doc` varchar(50) DEFAULT NULL,
  `sort_on_field` varchar(50) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_saved_search_created_by` (`created_by`),
  CONSTRAINT `FK_saved_search_created_by` FOREIGN KEY (`created_by`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_search`
--

LOCK TABLES `saved_search` WRITE;
/*!40000 ALTER TABLE `saved_search` DISABLE KEYS */;
INSERT INTO `saved_search` VALUES (15,'search-hugh','hugh','{\"manualBusinessStrategy\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"businessStrategyDocumentRefId\":null,\"businessRevenueTarget\":null,\"marketingInfluencedRevenueTarget\":[],\"marketingBudgetSpend\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"manualCampaignStrategy\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"campaignStrategyDocumentRefId\":null,\"campaignId\":null,\"parentCampaignName\":null,\"parentCampaignId\":null,\"subCampaignName\":null,\"campaignStart\":null,\"campaignRuntime\":null,\"productFamily\":[],\"customerSeg\":[],\"targetAudience\":[],\"targetRegions\":[],\"leadSources\":[],\"touchpoints\":[],\"assets\":[],\"totalCost\":null,\"dealsClosed\":null,\"marketingInfluencedRevenue\":null,\"createdBy\":null,\"createdDate\":null,\"updatedBy\":null,\"updatedDate\":null,\"documentRefId\":null},\"mapCampaign\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"campaignId\":null,\"campaignName\":null,\"parentCampaignId\":null,\"parentCampaignName\":null,\"campaignDocumentRefId\":null,\"startDate\":null,\"actualCost\":0.0,\"campaignType\":null,\"products\":[],\"createdDate\":null,\"createdBy\":null,\"currentStatus\":null,\"budgetedCost\":0.0,\"description\":null,\"campaignOwner\":null,\"runtime\":null,\"endDate\":null,\"expectedRevenue\":0.0,\"leadSources\":[],\"touchPoints\":[],\"assets\":[],\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"mapLead\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"leadId\":null,\"leadName\":null,\"website\":null,\"annualRevenue\":0.0,\"noOfEmployees\":0,\"industry\":null,\"email\":null,\"jobTitle\":null,\"companyName\":null,\"companyId\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"leadOwner\":null,\"leadSource\":null,\"leadStatus\":null,\"createdBy\":null,\"campaignId\":null,\"campaignName\":null,\"billingAddress\":null,\"shippingAddress\":null,\"phone\":null,\"mobilePhone\":null,\"sicCode\":null,\"lastName\":null,\"rating\":null,\"leadScore\":null,\"middleName\":null,\"department\":null,\"leadDocumentRefId\":null,\"assets\":[],\"lastModifiedBy\":null,\"touchPoints\":null,\"documentRefId\":null},\"mapOpportunity\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityDocumentRefId\":null,\"opportunityId\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"amount\":0.0,\"annualRevenue\":0.0,\"closedDate\":null,\"expectedRevenue\":0.0,\"companyInformation\":null,\"companyName\":null,\"opportunityOwner\":null,\"isWon\":null,\"isClosed\":null,\"leadSource\":null,\"name\":null,\"nextStep\":null,\"probability\":0.0,\"stage\":null,\"opportunityType\":null,\"createdBy\":null,\"status\":null,\"accountId\":null,\"address\":null,\"industry\":null,\"noOfEmployees\":0,\"productInterest\":null,\"mainCompetitors\":null,\"partners\":null,\"fiscal\":null,\"fiscalQuarter\":null,\"fiscalYear\":null,\"forecastCategoryName\":null,\"productQuantity\":0,\"campaignId\":null,\"campaignName\":null,\"assetId\":null,\"assetType\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"mapAccount\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"accountDocumentRefId\":null,\"accountId\":null,\"name\":null,\"company\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"annualRevenue\":0.0,\"organizationName\":null,\"organizationId\":null,\"billingAddress\":null,\"accountOwner\":null,\"accountOwnerId\":null,\"industry\":null,\"mainPhone\":null,\"noOfEmployees\":null,\"sicCode\":null,\"accountType\":null,\"website\":null,\"tickerSymbol\":null,\"shippingAddress\":null,\"email\":null,\"leadSource\":null,\"contactOwner\":null,\"documentRefId\":null},\"mapAsset\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"assetDocumentRefId\":null,\"assetId\":null,\"assetName\":null,\"createdBy\":null,\"createdAt\":null,\"updatedBy\":null,\"updatedAt\":null,\"documentRefId\":null},\"mapSalesPerson\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"userDocumentRefId\":null,\"userId\":null,\"firstName\":null,\"lastName\":null,\"userName\":null,\"email\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"createdBy\":null,\"mobilePhone\":null,\"title\":null,\"active\":null,\"lastModifiedBy\":null,\"company\":null,\"documentRefId\":null},\"crmAccount\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"accountDocumentRefId\":null,\"accountId\":null,\"accountName\":null,\"externalCompanyId\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"annualRevenue\":0.0,\"billingAddress\":null,\"shippingAddress\":null,\"industry\":null,\"sicCode\":null,\"website\":null,\"accountOwner\":null,\"parentAccount\":null,\"accountNumber\":null,\"accountSource\":null,\"contactOwner\":null,\"tickerSymbol\":null,\"numberOfLocations\":0,\"upsellOpportunity\":null,\"tradeStyle\":null,\"site\":null,\"documentRefId\":null},\"crmCampaign\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"campaignDocumentRefId\":null,\"campaignId\":null,\"campaignName\":null,\"parentCampaignId\":null,\"startDate\":null,\"actualCost\":0.0,\"campaignType\":null,\"createdDate\":null,\"createdBy\":null,\"status\":null,\"budgetedCost\":0.0,\"campaignOwner\":null,\"numTotalOpportunities\":0,\"numWonOpportunities\":0,\"totalContacts\":0,\"totalValueWonOpportunities\":0.0,\"runtime\":null,\"endDate\":null,\"expectedRevenue\":0.0,\"lastModifiedDate\":null,\"numOfLeads\":0,\"totalValueOpportunities\":0.0,\"description\":null,\"lastModifiedBy\":null,\"parentCampaignName\":null,\"documentRefId\":null},\"crmContact\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"contactDocumentRefId\":null,\"contactId\":null,\"accountId\":null,\"contactName\":null,\"contactNumber\":null,\"contactOwner\":null,\"email\":null,\"createdBy\":null,\"lastModifiedBy\":null,\"status\":null,\"activatedDate\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"name\":null,\"leadSource\":null,\"documentRefId\":null},\"crmContract\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"contractDocumentRefId\":null,\"accountId\":null,\"contractId\":null,\"contractName\":null,\"contractNumber\":null,\"contractOwner\":null,\"status\":null,\"activatedDate\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmInvoice\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"invoiceDocumentRefId\":null,\"invoiceId\":null,\"createdBy\":null,\"description\":null,\"lastModifiedBy\":null,\"invoiceName\":null,\"orderId\":null,\"status\":null,\"createdDate\":null,\"invoiceAmount\":0.0,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmLead\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"leadDocumentRefId\":null,\"leadId\":null,\"leadName\":null,\"annualRevenue\":0.0,\"noOfEmployees\":0,\"industry\":null,\"email\":null,\"title\":null,\"company\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"leadOwner\":null,\"leadSource\":null,\"leadStatus\":null,\"createdBy\":null,\"campaignId\":null,\"campaignName\":null,\"billingAddress\":null,\"shippingAddress\":null,\"phone\":null,\"sicCode\":null,\"rating\":null,\"leadScore\":null,\"accountName\":null,\"accountId\":null,\"website\":null,\"productInterest\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"crmOpportunity\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityDocumentRefId\":null,\"opportunityId\":null,\"createdOn\":null,\"lastModifiedDate\":null,\"amount\":0.0,\"closedDate\":null,\"expectedRevenue\":0.0,\"companyInformation\":null,\"owner\":null,\"leadSource\":null,\"opportunityName\":null,\"nextStep\":null,\"probabilityPerc\":0,\"stage\":null,\"opportunityType\":null,\"createdBy\":null,\"opportunityStatus\":null,\"accountId\":null,\"companyName\":null,\"location\":null,\"annualRevenue\":0.0,\"industry\":null,\"mainCompetitors\":[],\"site\":null,\"fiscal\":null,\"fiscalQuarter\":null,\"fiscalYear\":null,\"fiscalCategory\":null,\"quantity\":0,\"primaryCampSource\":null,\"description\":null,\"painPoints\":[],\"orderNumber\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"crmOpportunityCompetitor\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityCompetitorDocumentRefId\":null,\"createdBy\":null,\"competitorName\":null,\"opportunityId\":null,\"strengths\":null,\"weaknesses\":null,\"lastModifiedBy\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"url\":null,\"documentRefId\":null},\"crmOpportunityPartner\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"partnerDocumentRefId\":null,\"partnerId\":null,\"partnerRole\":null,\"accountFromId\":null,\"accountToId\":null,\"opportunityId\":null,\"createdBy\":null,\"lastModifiedBy\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmOpportunityProduct\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityProductDocumentRefId\":null,\"opportunityId\":null,\"product\":null,\"quantity\":0,\"listPrice\":0.0,\"total\":0.0,\"salesPrice\":0.0,\"sortOrder\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"lineDescription\":null,\"productCode\":null,\"createdBy\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"crmProduct\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"productDocumentRefId\":null,\"productId\":null,\"active\":null,\"createdBy\":null,\"lastModifiedBy\":null,\"productCode\":null,\"productDescription\":null,\"productFamily\":null,\"productName\":null,\"createdDate\":null,\"defaultPrice\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmOrderDetails\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"orderDetailsDocumentRefId\":null,\"accountId\":null,\"activatedBy\":null,\"activatedDate\":null,\"billingAddress\":null,\"billToContact\":null,\"createdBy\":null,\"contractName\":null,\"contractNumber\":null,\"opportunityId\":null,\"orderName\":null,\"orderNumber\":null,\"amount\":0,\"orderOwner\":null,\"orderReferenceNumber\":null,\"poNumber\":null,\"poDate\":null,\"status\":null,\"lastModBy\":null,\"createdDate\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"crmOrderProduct\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"orderProductDocumentRefId\":null,\"createdBy\":null,\"order\":null,\"orderProductNumber\":null,\"productId\":null,\"productCode\":null,\"totalPrice\":0,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"quantity\":0,\"unitPrice\":0,\"createdDate\":null,\"documentRefId\":null},\"crmUser\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"userDocumentRefId\":null,\"userId\":null,\"firstname\":null,\"lastname\":null,\"email\":null,\"lastModifiedDate\":null,\"createdBy\":null,\"mobilePhone\":null,\"title\":null,\"company\":null,\"active\":null,\"username\":null,\"timezone\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"erpAccount\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"accountDocumentRefId\":null,\"accountId\":null,\"salesOwner\":null,\"salesOwnerId\":null,\"sicCode\":null,\"customerName\":null,\"parentAccountId\":null,\"parentAccountName\":null,\"site\":null,\"geo\":null,\"industry\":null,\"annualRevenue\":0.0,\"company\":null,\"emailAddress\":null,\"companyId\":null,\"companyWebsite\":null,\"phone\":null,\"noOfEmployees\":0,\"billingAddress\":null,\"shippingAddress\":null,\"leadSource\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"erpInvoice\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"invoiceDocumentRefId\":null,\"invoiceId\":null,\"invoiceName\":null,\"opportunityId\":null,\"saleOrderId\":null,\"accountId\":null,\"description\":null,\"status\":null,\"leadSource\":null,\"salesPerson\":null,\"accountName\":null,\"salesAmount\":0.0,\"productQuantity\":0,\"productUnitPrice\":0.0,\"salesCurrency\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"erpOpportunity\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityDocumentRefId\":null,\"opportunityId\":null,\"opportunityName\":null,\"closedDate\":null,\"owner\":null,\"accountId\":null,\"status\":null,\"probability\":null,\"opportunityType\":null,\"companyName\":null,\"website\":null,\"billingAddress\":null,\"shippingAddress\":null,\"location\":null,\"salesRepName\":null,\"expectedRevenue\":0.0,\"opportunityAmount\":0.0,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null},\"erpOpportunityCompetitor\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"opportunityCompetitorDocumentRefId\":null,\"competitorName\":null,\"opportunityId\":null,\"strengths\":null,\"weaknesses\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"lastModifiedDate\":null,\"url\":null,\"documentRefId\":null},\"erpOrderItem\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"itemDocumentId\":null,\"itemId\":null,\"itemName\":null,\"upccode\":null,\"quantity\":null,\"totalValue\":null,\"itemType\":null,\"cost\":null,\"createdDate\":null,\"createdBy\":null,\"lastModifiedDate\":null,\"lastModifiedBy\":null,\"documentRefId\":null},\"erpSalesOrder\":{\"vendorType\":null,\"vendorName\":null,\"instanceName\":null,\"tags\":[],\"salesOrderDocumentRefId\":null,\"orderId\":null,\"orderOwner\":null,\"accountName\":null,\"opportunityId\":null,\"activatedDate\":null,\"orderInvoiceId\":null,\"customerPo\":null,\"items\":[],\"salesAmount\":null,\"customerId\":null,\"salesAccountCurrentOrders\":[],\"salesOrdeAccountYTD\":null,\"leadSource\":null,\"partner\":null,\"status\":null,\"createdBy\":null,\"createdDate\":null,\"lastModifiedBy\":null,\"activatedBy\":null,\"lastModifiedDate\":null,\"documentRefId\":null}}',1,1,25,'{\"id\":2,\"value\":\"filter2\"}|{\"id\":1,\"value\":\"filter1\"}',NULL,NULL,'2015-12-11 10:34:39','guest@phaladata.com');
/*!40000 ALTER TABLE `saved_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_authority`
--

DROP TABLE IF EXISTS `user_authority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_authority` (
  `username` varchar(100) NOT NULL,
  `authority_name` varchar(50) NOT NULL,
  PRIMARY KEY (`username`,`authority_name`),
  KEY `FK_tnnyxjpcvg2aj0d0i6ufnabm2` (`authority_name`),
  CONSTRAINT `FK_h5t8nplqarkfi7tscc9unyr7y` FOREIGN KEY (`username`) REFERENCES `user_info` (`username`),
  CONSTRAINT `FK_tnnyxjpcvg2aj0d0i6ufnabm2` FOREIGN KEY (`authority_name`) REFERENCES `authority` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_authority`
--

LOCK TABLES `user_authority` WRITE;
/*!40000 ALTER TABLE `user_authority` DISABLE KEYS */;
INSERT INTO `user_authority` VALUES ('admin@phaladata.com','ROLE_ADMIN'),('guest@phaladata.com','ROLE_GUEST');
/*!40000 ALTER TABLE `user_authority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_info` (
  `username` varchar(100) NOT NULL,
  `active` bit(1) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_info`
--

LOCK TABLES `user_info` WRITE;
/*!40000 ALTER TABLE `user_info` DISABLE KEYS */;
INSERT INTO `user_info` VALUES ('admin@phaladata.com','','Admin','Admin','$2a$10$n2usJ4tUqZF8CydUlqgupOgBjxW5QomRuDhlSJrSTjCM4iUAiy6W.'),('guest@phaladata.com','','Guest','Guest','$2a$10$E2PSxeWK79SKFNXp4SZ6C.qPN3vQZ4W4.QMFi7TpovSAFpoteyWu2');
/*!40000 ALTER TABLE `user_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_login_token`
--

DROP TABLE IF EXISTS `user_login_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_login_token` (
  `id` varchar(255) NOT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `user` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_nv6inptdyrxxwyap5fax7erin` (`user`),
  CONSTRAINT `FK_nv6inptdyrxxwyap5fax7erin` FOREIGN KEY (`user`) REFERENCES `user_info` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_login_token`
--

LOCK TABLES `user_login_token` WRITE;
/*!40000 ALTER TABLE `user_login_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_login_token` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-11 16:20:58
