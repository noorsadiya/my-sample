package com.miri.web.admin.manual.facade;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.ManualBusinessStrategy;
import com.miri.cis.entity.MarketingInfluencedRevenueTarget;
import com.miri.cis.entity.MonthlyTarget;
import com.miri.cis.utilities.DateUtilities;
import com.miri.data.jpa.domain.BusinessStrategyConfigurations;
import com.miri.data.jpa.domain.CampaignStrategy;
import com.miri.data.jpa.domain.CrmInstanceSalesStage;
import com.miri.data.jpa.domain.LocalCrmSalesStage;
import com.miri.data.jpa.domain.WebServiceVendor;
import com.miri.data.jpa.domain.WebServiceVendorConfiguration;
import com.miri.data.jpa.service.ManualInputService;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.BusinessStrategySetup;
import com.miri.search.data.CampaignStrategySetup;
import com.miri.search.data.FiscalDatesData;
import com.miri.search.data.FiscalDatesStrData;
import com.miri.search.data.RevenueTarget;
import com.miri.search.service.crm.CRMCampaignService;
import com.miri.search.service.manual.ManualAccountStrategyService;
import com.miri.search.service.manual.ManualBusinessStrategySearchService;
import com.miri.search.service.manual.ManualCampaignStrategyService;
import com.miri.search.service.map.MapCampaignService;
import com.miri.search.utils.MiriComparators;
import com.miri.search.utils.MiriDateUtils;
import com.miri.web.admin.manual.data.DataSourceData;

@Component
public class ManualInputFacade {
	private static final Logger LOGGER = LogManager.getLogger(ManualInputFacade.class);

	private static final String VENDORNAME_CSV = "csv";

	private static final String FE_DATEPATTERN = "yyyy-MM-dd'T'hh:mm:ss.SSS'Z'";
	private static final String OTHERS_OPTION = "Others";

	public static final String SALE_STAGE_VERIFIED = "bool_salesStagesVerified";

	@Value("http://${custom.webapp.host}/${custom.webapp.path}")
	private String cisEndpoint;

	@Autowired
	private ManualCampaignStrategyService campaignStrategyService;

	@Autowired
	private CRMCampaignService crmCampaignService;

	@Autowired
	private MapCampaignService mapCampaignService;

	@Autowired
	private ManualAccountStrategyService manualAccountStrategyService;

	@Autowired
	private ManualInputService manualInputDbService;

	@Autowired
	private ManualBusinessStrategySearchService manualBusinessStrategySearchService;

	public String getLogo() {
		return manualInputDbService.getAccountLogo();
	}

	public BusinessStrategySetup getBusinessStrategyDetails() {
		return manualBusinessStrategySearchService.getBusinessStrategyDetails();
	}

	public void saveBusinessStrategyDetails(BusinessStrategySetup businessStrategySetup) throws IOException {
		LOGGER.info("enter into the saveBusinessStrategyDetails service" + businessStrategySetup.getBusRevTargets());

		FiscalDatesData fiscalDates = manualAccountStrategyService.get1YearDates();
		FiscalMonthGreaterChecker fiscalMonthGreaterChecker = new FiscalMonthGreaterChecker(
				fiscalDates.getFiscalStartDate());

		Map<String, Map<String, BusinessStrategyConfigurations>> allConfigs = manualInputDbService
				.getBusinessStrategyConfigurations();

		BusinessStrategyConfigurations businessStrategyConfigurations = null;
		List<BusinessStrategyConfigurations> businessRevenueList = new ArrayList<BusinessStrategyConfigurations>();
		List<BusinessStrategyConfigurations> miRevenueList = new ArrayList<BusinessStrategyConfigurations>();
		List<MonthlyTarget> businessRevenueTarget = new ArrayList<MonthlyTarget>();
		List<MonthlyTarget> monthlyBusinessRevenueTarget = new ArrayList<MonthlyTarget>();
		List<MonthlyTarget> quaterlyBusinessRevenuetarget = new ArrayList<MonthlyTarget>();
		List<MarketingInfluencedRevenueTarget> marketingInfluencedRevenueTarget = new ArrayList<MarketingInfluencedRevenueTarget>();
		List<MarketingInfluencedRevenueTarget> monthlymarketingInfluencedRevenueTarget = new ArrayList<MarketingInfluencedRevenueTarget>();
		List<MarketingInfluencedRevenueTarget> quaterlyMarketingInfluencedRevenueTarget = new ArrayList<MarketingInfluencedRevenueTarget>();

		MonthlyTarget quaterlyTarget = null;
		MonthlyTarget yearlyTarget = null;
		int currentMonth = Calendar.getInstance().get(Calendar.MONTH);
		boolean isNew = false;
		for (RevenueTarget revenueTarget : businessStrategySetup.getBusRevTargets()) {
			for (MonthlyTarget monthlyTarget : revenueTarget.getMonthlyTarget()) {
				// reset loop references
				isNew = false;
				businessStrategyConfigurations = null;
				quaterlyTarget = new MonthlyTarget();
				yearlyTarget = new MonthlyTarget();
				// reset loop references - END
				String monthName = monthlyTarget.getMonth().substring(0, 3);
				int monthId = ArrayUtils.indexOf(MiriDateUtils.MONTH_NAMES, monthName);
				// get existing values - if any
				Map<String, BusinessStrategyConfigurations> monthwiseMap = allConfigs
						.get(SearchConstants.BUSINESS_REVENUE_TARGET);
				if (MapUtils.isNotEmpty(monthwiseMap)) {
					businessStrategyConfigurations = monthwiseMap.get(monthName);
				}
				if (businessStrategyConfigurations == null) {
					businessStrategyConfigurations = new BusinessStrategyConfigurations();
					businessStrategyConfigurations.setRevenueName(SearchConstants.BUSINESS_REVENUE_TARGET);
					isNew = true;
				}
				businessStrategyConfigurations.setMonthName(monthName);
				businessStrategyConfigurations.setMonthlyTarget(monthlyTarget.getValue().doubleValue());
				businessStrategyConfigurations.setQuaterlyTarget(revenueTarget.getQuarterTarget());

				quaterlyTarget.setId(monthId);
				quaterlyTarget.setMonth(monthName);
				quaterlyTarget.setValue(revenueTarget.getQuarterTarget().doubleValue());
				yearlyTarget.setId(monthId);
				yearlyTarget.setMonth(monthName);
				// Override fiscal values for months > current month in fiscal
				// OR if there was no record in DB
				// NOTE: This is required only for Yearly/Fiscal targets
				if (fiscalMonthGreaterChecker.isGreaterFiscalMonth(currentMonth, monthId) || isNew) {
					businessStrategyConfigurations.setYearlyTarget(businessStrategySetup.getBusinessRevenueTarget());
					yearlyTarget.setValue(businessStrategySetup.getBusinessRevenueTarget());
				} else {
					yearlyTarget.setValue(businessStrategyConfigurations.getYearlyTarget());
				}

				// add to list
				monthlyTarget.setId(monthId);
				monthlyTarget.setMonth(monthName);
				monthlyBusinessRevenueTarget.add(monthlyTarget);
				quaterlyBusinessRevenuetarget.add(quaterlyTarget);
				businessRevenueTarget.add(yearlyTarget);

				businessStrategyConfigurations.setDraft(businessStrategySetup.isDraft());
				businessRevenueList.add(businessStrategyConfigurations);
			}
		}

		MarketingInfluencedRevenueTarget monthlyMITarget = null;
		MarketingInfluencedRevenueTarget quaterlyMITarget = null;
		MarketingInfluencedRevenueTarget yearlyMITarget = null;
		BusinessStrategyConfigurations miBusinessStrategyConfigurations = null;
		for (RevenueTarget revenueTarget : businessStrategySetup.getMirTarget()) {
			for (MonthlyTarget monthlyTarget : revenueTarget.getMonthlyTarget()) {
				// reset loop references
				isNew = false;
				miBusinessStrategyConfigurations = null;
				monthlyMITarget = new MarketingInfluencedRevenueTarget();
				quaterlyMITarget = new MarketingInfluencedRevenueTarget();
				yearlyMITarget = new MarketingInfluencedRevenueTarget();
				// reset loop references - END
				String monthName = monthlyTarget.getMonth().substring(0, 3);
				int monthId = ArrayUtils.indexOf(MiriDateUtils.MONTH_NAMES, monthName);
				// get existing values - if any
				Map<String, BusinessStrategyConfigurations> monthwiseMap = allConfigs
						.get(SearchConstants.MI_REVENUE_TARGET);
				if (MapUtils.isNotEmpty(monthwiseMap)) {
					miBusinessStrategyConfigurations = monthwiseMap.get(monthName);
				}
				if (miBusinessStrategyConfigurations == null) {
					miBusinessStrategyConfigurations = new BusinessStrategyConfigurations();
					miBusinessStrategyConfigurations.setRevenueName(SearchConstants.MI_REVENUE_TARGET);
					isNew = true;
				}
				miBusinessStrategyConfigurations.setMonthName(monthName);
				miBusinessStrategyConfigurations.setMonthlyTarget(monthlyTarget.getValue().doubleValue());
				miBusinessStrategyConfigurations.setQuaterlyTarget(revenueTarget.getQuarterTarget());
				miBusinessStrategyConfigurations.setDraft(businessStrategySetup.isDraft());
				miRevenueList.add(miBusinessStrategyConfigurations);
				monthlyMITarget.setId(monthId);
				monthlyMITarget.setMonth(monthName);
				monthlyMITarget.setValue(monthlyTarget.getValue().doubleValue());
				quaterlyMITarget.setId(monthId);
				quaterlyMITarget.setMonth(monthName);
				quaterlyMITarget.setValue(revenueTarget.getQuarterTarget());
				yearlyMITarget.setId(monthId);
				yearlyMITarget.setMonth(monthName);
				// Override fiscal target values for months > current month in
				// fiscal OR if there was no record in DB
				// NOTE: This is required only for Yearly/Fiscal targets
				if (fiscalMonthGreaterChecker.isGreaterFiscalMonth(currentMonth, monthId) || isNew) {
					miBusinessStrategyConfigurations.setYearlyTarget(businessStrategySetup.getMarketingInflRevTarget());
					yearlyMITarget.setValue(businessStrategySetup.getMarketingInflRevTarget());
				} else {
					yearlyMITarget.setValue(miBusinessStrategyConfigurations.getYearlyTarget());
				}
				monthlymarketingInfluencedRevenueTarget.add(monthlyMITarget);
				quaterlyMarketingInfluencedRevenueTarget.add(quaterlyMITarget);
				marketingInfluencedRevenueTarget.add(yearlyMITarget);
			}
		}
		// save to DB
		manualInputDbService.saveOrUpdateBusinessStrategy(businessRevenueList, miRevenueList);

		ManualBusinessStrategy mbs = manualBusinessStrategySearchService.getLatestBusinessStrategy();

		if (mbs == null) {
			mbs = new ManualBusinessStrategy();
			mbs.setBusinessStrategyDocumentRefId("1");
		}
		mbs.setBusinessRevenueTarget(businessRevenueTarget);
		mbs.setMonthlyBusinessRevenueTarget(monthlyBusinessRevenueTarget);
		mbs.setQuaterlyBusinessRevenuetarget(quaterlyBusinessRevenuetarget);
		mbs.setMarketingInfluencedRevenueTarget(marketingInfluencedRevenueTarget);
		mbs.setMonthlymarketingInfluencedRevenueTarget(monthlymarketingInfluencedRevenueTarget);
		mbs.setQuaterlyMarketingInfluencedRevenueTarget(quaterlyMarketingInfluencedRevenueTarget);
		mbs.setCreatedDate(DateUtilities.dateToString(new Date()));
		mbs.setLastModifiedDate(DateUtilities.dateToString(new Date()));
		mbs.setVendorName(SearchConstants.BUSINESS_STRATEGY);
		mbs.setVendorType(SearchConstants.MANUAL);
		mbs.setDraft(businessStrategySetup.isDraft());
		// save to ES
		manualBusinessStrategySearchService.indexBusinessStrategy(mbs);
	}

	public Map<String, Set<Map<String, String>>> getAllCampaigns() {
		Map<String, Set<Map<String, String>>> campaignData = new HashMap<>();

		FiscalDatesData fiscalDates = manualAccountStrategyService.get1YearDates();
		FiscalDatesStrData fiscalDatesStrData = manualAccountStrategyService.convertFiscalDatetoStr(fiscalDates);
		String reviewStartDate = fiscalDatesStrData.getFiscalStartDateStr();
		String reviewEndDate = fiscalDatesStrData.getFiscalEndDateStr();

//		Set<String> vendorNameCollector = new HashSet<>();
//		SortedSet<Map<String, String>> campaigns = crmCampaignService.getAllCampaignsWithVendorName(reviewStartDate,
//				reviewEndDate, vendorNameCollector);
		SortedSet<Map<String, String>> campaigns = mapCampaignService.getAllCampaignsWithVendorName(reviewStartDate,
				reviewEndDate);
		campaignData.put("campaigns", campaigns);

		Set<Map<String, String>> parentCampaignSet = new TreeSet<>(campaigns.comparator());
		// Whether the CRM vendor has provides parent campaign(s) information
		/*if (manualInputDbService.checkParentCampaignAvailability(vendorNameCollector)) {*/
			// NOTE: parent campaigns are fetched from CRM as we don't have that info in MAP Campaigns
			addParentCampaigns(parentCampaignSet, reviewStartDate, reviewEndDate);
			// remove parent campaigns from campaigns - if present
			for (Map<String, String> parentCampaign : parentCampaignSet) {
				String parentCampaignId = parentCampaign.get(MiriComparators.CampaignSetComparator.VALUE_FIELD);
				for (Iterator<Map<String, String>> it = campaigns.iterator(); it.hasNext();) {
					Map<String, String> campaignMap = it.next();
					if (campaignMap!= null && StringUtils.equals(parentCampaignId, campaignMap.get(MiriComparators.CampaignSetComparator.VALUE_FIELD))) { //NOSONAR
						it.remove();
					}
				}
			}
		/*}*/
		addExistingParentCampaigns(parentCampaignSet, fiscalDates);

		// Adding 'Others' Option
		Map<String, String> othersOption = new HashMap<>();
		othersOption.put(MiriComparators.CampaignSetComparator.NAME_FIELD, OTHERS_OPTION);
		othersOption.put(MiriComparators.CampaignSetComparator.VALUE_FIELD, OTHERS_OPTION);
		parentCampaignSet.add(othersOption);

		campaignData.put("parentCampaigns", parentCampaignSet);

		LOGGER.debug("All Campaign size::>>" + campaigns.size());
		return campaignData;
	}

	/**
	 * Return parent campaigns from ES created in the given date range
	 *
	 * @param parentCampaignSet
	 *            Set to collect parent campaigns
	 * @param reviewEndDate
	 *            start date of the date range
	 * @param reviewStartDate
	 *            end date of the date range
	 * @return parent campaigns from ES created in the given date range
	 */
	private void addParentCampaigns(final Set<Map<String, String>> parentCampaignSet, final String reviewStartDate,
			final String reviewEndDate) {
		LOGGER.debug("Enter into addParentCampaigns");

		// TODO: add date clause for parent campaigns
		// Map<String, String> parentCampigns =
		// crmCampaignService.getAllParentCampaigns(reviewStartDate,
		// reviewEndDate);
		Map<String, String> parentCampigns = crmCampaignService.getAllParentCampaigns();
		if (MapUtils.isNotEmpty(parentCampigns)) {
			transformToValueNameMap(parentCampaignSet, parentCampigns);
		}
	}

	/**
	 * Return parent campaigns from DB associated in the given date range
	 *
	 * @param parentCampaignSet
	 *            Set to collect parent campaigns
	 * @param fiscalDates
	 *            date range to use
	 */
	private void addExistingParentCampaigns(final Set<Map<String, String>> parentCampaignSet,
			final FiscalDatesData fiscalDates) {
		Map<String, String> existingParentCampaignInfo = manualInputDbService.getParentCampaignInfo(
				fiscalDates.getFiscalStartDate().getTime(), fiscalDates.getFiscalEndDate().getTime());
		if (MapUtils.isNotEmpty(existingParentCampaignInfo)) {
			transformToValueNameMap(parentCampaignSet, existingParentCampaignInfo);
		}
	}

	private static void transformToValueNameMap(final Set<Map<String, String>> parentCampaignSet,
			final Map<String, String> parentCampigns) {
		Iterator<Map.Entry<String, String>> entries = parentCampigns.entrySet().iterator();
		while (entries.hasNext()) {
			Map.Entry<String, String> entry = entries.next();
			String key = entry.getKey();
			String value = entry.getValue();

			Map<String, String> campaigns = new HashMap<String, String>();
			campaigns.put(MiriComparators.CampaignSetComparator.VALUE_FIELD, key);
			campaigns.put(MiriComparators.CampaignSetComparator.NAME_FIELD, value);

			parentCampaignSet.add(campaigns);
		}
	}

	public CampaignStrategySetup getCampaignByName(String campaignName) {
		CampaignStrategySetup campaignStrategySetup = new CampaignStrategySetup();
		// 1. check previous manual campaign in ES
		Map<String, Object> campaignByName = campaignStrategyService.getCampaignByName(campaignName);
		if (campaignByName != null) {
			campaignStrategySetup.updateWithManualCampaign(campaignByName);
		} else {
			// 2. check previous manual campaign in DB
			FiscalDatesData fiscalDates = manualAccountStrategyService.get1YearDates();
			Date rangeStart = fiscalDates.getFiscalStartDate().getTime();
			Date rangeEnd = fiscalDates.getFiscalEndDate().getTime();

			CampaignStrategy campaignStrategy = manualInputDbService.getCampaignStrategy(campaignName, rangeStart,
					rangeEnd);
			if (campaignStrategy != null) {
				campaignStrategySetup.updateWithManualCampaign(campaignStrategy);
			} else {
				// 3. check crm campaign from ES
				campaignByName = mapCampaignService.getCampaignByName(campaignName);
				if (campaignByName != null) {
					campaignStrategySetup.updateWithCrmCampaign(campaignByName);
				}
				campaignStrategySetup.setDraft(true);
			}
		}
		return campaignStrategySetup;
	}

	public void saveCampaignStrategySetup(CampaignStrategySetup campaignStrategySetup) throws IOException {
		String campaignId = StringUtils.defaultString(campaignStrategySetup.getCampaignId());
		String campaignName = StringUtils.defaultString(campaignStrategySetup.getCampaignName());
		String parentCampaignId = StringUtils.defaultString(campaignStrategySetup.getParentCampaignId());
		String parentCampaignName = StringUtils.defaultString(campaignStrategySetup.getParentCampaignName());
		String newCampaignName = StringUtils.defaultString(campaignStrategySetup.getNewParentCampaignName());
		if (OTHERS_OPTION.equalsIgnoreCase(parentCampaignName)) {
			parentCampaignName = newCampaignName;
			newCampaignName = "";
		}

		Double campaignCost = campaignStrategySetup.getCampaignCost();
		String startDateStr = StringUtils.defaultString(campaignStrategySetup.getCampaignStartDate());
		boolean isDraft = campaignStrategySetup.isDraft();
		Set<String> editableFields = campaignStrategySetup.getEditableFields();
		Date startDate = DateUtilities.stringToDateByPattern(startDateStr, FE_DATEPATTERN);
		Date currentDate = new Date();

		// 1. first save in DB
		FiscalDatesData fiscalDates = manualAccountStrategyService.get1YearDates();
		Date rangeStart = fiscalDates.getFiscalStartDate().getTime();
		Date rangeEnd = fiscalDates.getFiscalEndDate().getTime();
		manualInputDbService.updateCampaignManualInput(campaignId, campaignName, parentCampaignId, parentCampaignName,
				newCampaignName, campaignCost, startDate, currentDate, isDraft, editableFields, rangeStart, rangeEnd);

		// 2. then index in ES
		campaignStrategyService.indexCampaignStrategy(campaignId, campaignName, parentCampaignId, parentCampaignName,
				newCampaignName, campaignCost, startDateStr, currentDate, isDraft, editableFields);
	}

	public CampaignStrategySetup getMostRecentlyUpdated() {
		CampaignStrategySetup campaignStrategySetup = new CampaignStrategySetup();

		String campaignId = "";
		String campaignName = "";
		String parentCampaignId = "";
		String parentCampaignName = "";
		String newParentCampaignName = "";
		String campaignStartDate = "";
		double campaignCost = 0.0d;
		boolean isDraft = false;
		Set<String> editableFields = Collections.emptySet();

		Map<String, Object> campaignDetails = campaignStrategyService.getMostRecentlyUpdated();
		if (MapUtils.isNotEmpty(campaignDetails)) {
			campaignId = StringUtils.defaultString((String) campaignDetails.get("campaignId"));
			campaignName = StringUtils.defaultString((String) campaignDetails.get("campaignName"));
			parentCampaignId = StringUtils.defaultString((String) campaignDetails.get("parentCampaignId"));
			parentCampaignName = StringUtils.defaultString((String) campaignDetails.get("parentCampaignName"));
			newParentCampaignName = StringUtils.defaultString((String) campaignDetails.get("newCampaignName"));
			campaignStartDate = StringUtils.defaultString((String) campaignDetails.get("campaignStart"));
			campaignCost = (Integer) campaignDetails.get("totalCost");
			isDraft = Boolean.valueOf(String.valueOf(campaignDetails.get("draft")));
			@SuppressWarnings("unchecked")
			List<String> editFields = (List<String>)campaignDetails.get("editableFields");
			if(CollectionUtils.isNotEmpty(editFields)){
				editableFields  = new HashSet<String>(editFields);
			}
			campaignStrategySetup = new CampaignStrategySetup(campaignName, campaignId, campaignStartDate,
					parentCampaignId, parentCampaignName, newParentCampaignName, campaignCost, isDraft, editableFields);
		} else {
			CampaignStrategy campaignStrategy = manualInputDbService.getRecentlyUpdatedManualCampaignInput();
			if (campaignStrategy != null) {
				campaignId = StringUtils.defaultString(campaignStrategy.getCampaignId());
				campaignName = StringUtils.defaultString(campaignStrategy.getCampaignName());
				parentCampaignId = StringUtils.defaultString(campaignStrategy.getParentCampaignId());
				parentCampaignName = StringUtils.defaultString(campaignStrategy.getParentCampaignName());
				newParentCampaignName = StringUtils.defaultString(campaignStrategy.getNewCampaignName());
				campaignStartDate = DateUtilities.dateToString(campaignStrategy.getCampaignStartDate());
				campaignCost = campaignStrategy.getTotalCampaignCost();
				isDraft = campaignStrategy.isDraft();

				if(CollectionUtils.isNotEmpty(campaignStrategy.getEditableFields())){
					editableFields  = campaignStrategy.getEditableFields();
				}

				campaignStrategySetup = new CampaignStrategySetup(campaignName, campaignId, campaignStartDate,
						parentCampaignId, parentCampaignName, newParentCampaignName, campaignCost, isDraft,
						editableFields);
			}
		}

		return campaignStrategySetup;
	}

	public DataSourceData getDatasourceSetupDetails() {
		return getDataSourceDataFromVendorConfig(manualInputDbService.getDatasourceSetupDetails());
	}

	private DataSourceData getDataSourceDataFromVendorConfig(List<WebServiceVendor> datasourceSetupDetails) {
		DataSourceData dataSourceData = new DataSourceData();

		if (CollectionUtils.isNotEmpty(datasourceSetupDetails)) {
			for (WebServiceVendor webServiceVendor : datasourceSetupDetails) {
				Map<String, Object> vendorConfig = manualInputDbService.getFlattenedConfig(webServiceVendor);

				dataSourceData.setDraft(webServiceVendor.isDraft());
				String vendorType = webServiceVendor.getVendorType();
				String vendorName = webServiceVendor.getVendorName();
				switch (StringUtils.lowerCase(vendorType)) {
				case "map":
					if (VENDORNAME_CSV.equalsIgnoreCase(vendorName)) {
						dataSourceData.addFtpVendorConfig(vendorType, vendorConfig);
					} else {
						dataSourceData.addMapVendorConfig(vendorConfig);
					}
					break;
				case "crm":
					if (VENDORNAME_CSV.equalsIgnoreCase(vendorName)) {
						dataSourceData.addFtpVendorConfig(vendorType, vendorConfig);
					} else {
						dataSourceData.addCrmVendorConfig(vendorConfig);
					}
					break;
				case "erp":
					if (VENDORNAME_CSV.equalsIgnoreCase(vendorName)) {
						dataSourceData.addFtpVendorConfig(vendorType, vendorConfig);
					} else {
						dataSourceData.addErpVendorConfig(vendorConfig);
					}
					break;
				default:
					LOGGER.info("Unknown Vendor Type : " + vendorType);
				}
			}
		} else {
			dataSourceData.setDraft(true);
		}

		return dataSourceData;
	}

	public void updateDataSourceSetup(DataSourceData datasourceDetails) {
		LOGGER.debug("datasourceDetails :: " + datasourceDetails);

		boolean draft = datasourceDetails.isDraft();
		List<Map<String, Object>> mapVendors = datasourceDetails.getMapVendors();
		if (CollectionUtils.isNotEmpty(mapVendors)) {
			manualInputDbService.saveOrUpdateVendors(mapVendors, draft, false);
		}
		List<Map<String, Object>> crmVendors = datasourceDetails.getCrmVendors();
		if (CollectionUtils.isNotEmpty(crmVendors)) {
			List<WebServiceVendor> crmVendorsList = manualInputDbService.saveOrUpdateVendors(crmVendors, draft, true);
			// initiate sales stage fetching added for crm vendors
			for (WebServiceVendor webServiceVendor : crmVendorsList) {
				boolean salesStagesFetched = initiateSalesStageFetch(webServiceVendor.getVendorName(), webServiceVendor.getInstanceName());
				Set<WebServiceVendorConfiguration> configuration = webServiceVendor.getConfiguration();
				for (WebServiceVendorConfiguration webServiceVendorConfiguration : configuration) {
					if (SALE_STAGE_VERIFIED.equals(webServiceVendorConfiguration.getAttributeName())) { //NOSONAR
						webServiceVendorConfiguration.setAttributeValue(String.valueOf(salesStagesFetched));
						manualInputDbService.saveWebServiceVendorConguration(webServiceVendorConfiguration);
						break;
					}
				}
			}
		}
		List<Map<String, Object>> erpVendors = datasourceDetails.getErpVendors();
		if (CollectionUtils.isNotEmpty(erpVendors)) {
			manualInputDbService.saveOrUpdateVendors(erpVendors, draft, false);
		}
		Map<String, Map<String, Object>> ftpVendorsMap = datasourceDetails.getFtpVendors();
		if (MapUtils.isNotEmpty(ftpVendorsMap)) {
			Collection<Map<String, Object>> ftpVendors = ftpVendorsMap.values();
			if (CollectionUtils.isNotEmpty(ftpVendors)) {
				List<Map<String, Object>> ftpVendorsList = new ArrayList<>(ftpVendors);
				manualInputDbService.saveOrUpdateVendors(ftpVendorsList, draft, false);
			}
		}
	}

	private boolean initiateSalesStageFetch(String vendorName, String instanceName) {
		RestTemplate template = new RestTemplate();
		Map<String, String> uriVariables = new HashMap<>();
		uriVariables.put("vendorName", vendorName);
		uriVariables.put("instanceName", instanceName);

		String urlStr = cisEndpoint + "/admin/fetch/sale-stage/{vendorName}/{instanceName}";
		LOGGER.debug("Requesting Miri urlStr : " + urlStr + " with variables " + uriVariables);
		ResponseEntity<Object> responseEntity = template.postForEntity(urlStr, null,
				Object.class, uriVariables);
		LOGGER.info("Sales Stage fetched responseEntity: " + responseEntity);

		if (HttpStatus.OK.equals(responseEntity.getStatusCode())) {
			@SuppressWarnings("unchecked")
			Map<String, Object> body = (Map<String, Object>) responseEntity.getBody();
			LOGGER.info("Sales Stage body: " + body);
			Object successfulObj = body.get("successful");

			return Boolean.valueOf(String.valueOf(successfulObj));
		} else {
			return false;
		}
	}

	public ResponseEntity<Object> testDataSource(Map<String, String> dataSourceConfig) {
		RestTemplate template = new RestTemplate();
		Map<String, ?> uriVariables = Collections.emptyMap();
		return template.postForEntity(cisEndpoint + "/admin/config/test", dataSourceConfig, Object.class, uriVariables);
	}

	public List<String> getCrmVendors() {
		return manualInputDbService.getVendorNames(ElasticSearchEnums.CRM.getText());
	}

	/**
	 * Get Sales Stage Mapping
	 *
	 * @param instanceName
	 * @return
	 */
	public List<SalesStageInfo> getSalesStageMapping(String vendorName, String instanceName) {
		List<SalesStageInfo> salesStageInfoList = new ArrayList<>();
		List<CrmInstanceSalesStage> salesStageMapping = manualInputDbService.getSalesStageMapping(vendorName, instanceName);
		for (CrmInstanceSalesStage crmInstanceSalesStage : salesStageMapping) {
			salesStageInfoList.add(new SalesStageInfo(crmInstanceSalesStage));
		}
		return salesStageInfoList;
	}

	private Map<Long, CrmInstanceSalesStage> getCrmInstanceSalesStageMap(String vendorName, String instanceName) {
		Map<Long, CrmInstanceSalesStage> localSalesStagesMap = Collections.emptyMap();
		List<CrmInstanceSalesStage> salesStageMapping = manualInputDbService.getSalesStageMapping(vendorName, instanceName);
		if (CollectionUtils.isNotEmpty(salesStageMapping)) {
			localSalesStagesMap = new LinkedHashMap<>();
			for (CrmInstanceSalesStage crmInstanceSalesStage : salesStageMapping) {
				localSalesStagesMap.put(crmInstanceSalesStage.getId(), crmInstanceSalesStage);
			}
		}

		return localSalesStagesMap;
	}

	public Map<Long, String> getLocalSalesStages() {
		Map<Long, String> localSalesStagesMap = Collections.emptyMap();
		List<LocalCrmSalesStage> localSalesStages = manualInputDbService.getLocalSalesStages();
		if (CollectionUtils.isNotEmpty(localSalesStages)) {
			localSalesStagesMap = new LinkedHashMap<>();
			for (LocalCrmSalesStage localCrmSalesStage : localSalesStages) {
				localSalesStagesMap.put(localCrmSalesStage.getId(), localCrmSalesStage.getStageName());
			}
		}

		return localSalesStagesMap;
	}

	public void saveCrmSalesStageMapping(List<SalesStageInfo> salesStagesMapping, String vendorName, String instanceName) {
		Map<Long, CrmInstanceSalesStage> crmInstanceSalesStageMap = getCrmInstanceSalesStageMap(vendorName, instanceName);
		Map<String, LocalCrmSalesStage> localSalesStageMap = getLocalSalesStageObjects();

		for (SalesStageInfo salesStageMappingInfo : salesStagesMapping) {
			Long crmInstanceSalesStageId = salesStageMappingInfo.getId();
			CrmInstanceSalesStage crmInstanceSalesStage = crmInstanceSalesStageMap.get(crmInstanceSalesStageId);

			LocalCrmSalesStage localCrmSalesStage = localSalesStageMap.get(salesStageMappingInfo.getAssignedTo());
			crmInstanceSalesStage.setLocalCrmSalesStage(localCrmSalesStage);
		}

		Collection<CrmInstanceSalesStage> crmInstanceSalesStageMappings = crmInstanceSalesStageMap.values();
		manualInputDbService.saveCrmSalesStageMapping(crmInstanceSalesStageMappings);
	}

	private Map<String, LocalCrmSalesStage> getLocalSalesStageObjects() {
		Map<String, LocalCrmSalesStage> localSalesStagesMap = Collections.emptyMap();
		List<LocalCrmSalesStage> localSalesStages = manualInputDbService.getLocalSalesStages();
		if (CollectionUtils.isNotEmpty(localSalesStages)) {
			localSalesStagesMap = new LinkedHashMap<>();
			for (LocalCrmSalesStage localCrmSalesStage : localSalesStages) {
				localSalesStagesMap.put(localCrmSalesStage.getStageId(), localCrmSalesStage);
			}
		}

		return localSalesStagesMap;
	}

	public static final class SalesStageInfo {
		private Long id;
		private String name;
		private String assignedTo;
		private String assignedToId;
		private boolean selected;
		private boolean selectable;

		public SalesStageInfo() {
			super();
		}

		public SalesStageInfo(CrmInstanceSalesStage crmInstanceSalesStage) {
			this.id = crmInstanceSalesStage.getId();
			this.name = crmInstanceSalesStage.getSalesStageName();
			LocalCrmSalesStage localCrmSalesStage = crmInstanceSalesStage.getLocalCrmSalesStage();
			if (localCrmSalesStage != null) {
				this.assignedToId = localCrmSalesStage.getStageId();
				this.assignedTo = /* localCrmSalesStage.getStageName() */localCrmSalesStage.getStageId();// update
																											// if
																											// FE
																											// changes
				this.selected = true;
			} else {
				this.selected = false;
			}
			this.selectable = true;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getAssignedTo() {
			return assignedTo;
		}

		public void setAssignedTo(String assignedTo) {
			this.assignedTo = assignedTo;
		}

		public String getAssignedToId() {
			return assignedToId;
		}

		public void setAssignedToId(String assignedToId) {
			this.assignedToId = assignedToId;
		}

		public boolean isSelected() {
			return selected;
		}

		public void setSelected(boolean selected) {
			this.selected = selected;
		}

		public boolean isSelectable() {
			return selectable;
		}

		public void setSelectable(boolean selectable) {
			this.selectable = selectable;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("SalesStageInfo [id=");
			builder.append(id);
			builder.append(", name=");
			builder.append(name);
			builder.append(", assignedTo=");
			builder.append(assignedTo);
			builder.append(", assignedToId=");
			builder.append(assignedToId);
			builder.append(", selected=");
			builder.append(selected);
			builder.append(", selectable=");
			builder.append(selectable);
			builder.append("]");
			return builder.toString();
		}
	}

	private static class FiscalMonthGreaterChecker {
		// java.util.Calendar based months - Jan is 0th
		private int[] months = new int[12];

		FiscalMonthGreaterChecker(Calendar startCal) {
			for (int i = 0; i < months.length; i++) {
				months[i] = startCal.get(Calendar.MONTH);
				startCal.add(Calendar.MONTH, 1);
			}
		}

		public boolean isGreaterFiscalMonth(int currentMonth, int monthToCheck) {
			int currentMonthIndex = ArrayUtils.indexOf(months, currentMonth);
			int monthToCheckIndex = ArrayUtils.indexOf(months, monthToCheck);

			return monthToCheckIndex >= currentMonthIndex;
		}
	}
}
