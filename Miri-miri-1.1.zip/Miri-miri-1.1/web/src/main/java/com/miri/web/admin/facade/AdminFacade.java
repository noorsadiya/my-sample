package com.miri.web.admin.facade;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.miri.data.jpa.domain.WebServiceGlobalConfiguration;
import com.miri.data.jpa.service.AdminService;
import com.miri.data.jpa.util.AppConfigContainer;

/**
 * @author supraja
 *
 */
@Component
public class AdminFacade {

	private static final Logger LOG = Logger.getLogger(AdminFacade.class);

	@Autowired
	private AppConfigContainer appConfigContainer;

	@Autowired
	private AdminService adminService;

	@Value("http://${custom.webapp.host}/${custom.webapp.path}")
	private String cisEndpoint;

	public ResponseEntity<Object> runScheduler() {
		RestTemplate template = new RestTemplate();
		Map<String, ?> uriVariables = Collections.emptyMap();
		String urlPath = cisEndpoint + appConfigContainer.getSchedulerRunPath();
		LOG.debug("cis request url ::>" + urlPath);
		return template.postForEntity(urlPath, Object.class, Object.class, uriVariables);
	}

	public ResponseEntity<Object> getSchedulerStatus() {
		RestTemplate template = new RestTemplate();
		Map<String, ?> uriVariables = Collections.emptyMap();
		String urlPath = cisEndpoint + appConfigContainer.getSchedulerStatusPath();
		LOG.debug("cis request url ::>" + urlPath);
		return template.postForEntity(urlPath, Object.class, Object.class, uriVariables);
	}

	/**
	 *
	 * @param frequencyDetails
	 * @return
	 */
	public ResponseEntity<Object> updateSchedulerFrequency(Map<String, Object> frequencyDetails) {
		// update vendor config
		List<WebServiceGlobalConfiguration> configsList = new ArrayList<WebServiceGlobalConfiguration>();
		String jobName = (String)frequencyDetails.get("jobName");
		for (Map.Entry<String, Object> entry : frequencyDetails.entrySet()) {
			WebServiceGlobalConfiguration webServiceGlobalConfiguration = null;
			String key = entry.getKey();
			if (key.equals("startTime")) {
				webServiceGlobalConfiguration = new WebServiceGlobalConfiguration();
				webServiceGlobalConfiguration.setAttributeName(jobName+".start-time-of-the-day");
				webServiceGlobalConfiguration.setAttributeValue(String.valueOf(entry.getValue()));
			}
			else if (key.equals("frequency")) {
				webServiceGlobalConfiguration = new WebServiceGlobalConfiguration();
				webServiceGlobalConfiguration.setAttributeName(jobName+".schedule-interval-millis");
				webServiceGlobalConfiguration.setAttributeValue(String.valueOf(entry.getValue()));
			}
			if(webServiceGlobalConfiguration != null)
				configsList.add(webServiceGlobalConfiguration);
		}
		Map<String, Object> backUpconfigs = getSchedulerFrequency(jobName); // TODO: Seems unnecessary
		adminService.saveOrUpdateVendorGlobalConfigs(configsList,jobName);

		RestTemplate template = new RestTemplate();
		String urlPath = cisEndpoint + appConfigContainer.getSchedulerRestartPath();
		LOG.debug("cis request url for frequency ::>" + urlPath);
		backUpconfigs = null;
		return template.postForEntity(urlPath, Object.class, Object.class, frequencyDetails);
	}

	/**
	 *
	 * @param jobName
	 * @return
	 */
	public Map<String, Object> getSchedulerFrequency(String jobName) {

		List<WebServiceGlobalConfiguration> configs = adminService.getSchedulerFrequencyByJob(jobName);
		Map<String, Object> frequencyMap = new HashMap<String, Object>();
		for (Iterator iterator = configs.iterator(); iterator.hasNext();) {
			WebServiceGlobalConfiguration webServiceGlobalConfiguration = (WebServiceGlobalConfiguration) iterator
					.next();
			if (webServiceGlobalConfiguration.getAttributeName().endsWith("start-time-of-the-day")) {
				frequencyMap.put("startTime", webServiceGlobalConfiguration.getAttributeValue());
			}
			else if (webServiceGlobalConfiguration.getAttributeName().endsWith("schedule-interval-millis")) {
				frequencyMap.put("frequency", webServiceGlobalConfiguration.getAttributeValue());
			}
		}

		return frequencyMap;
	}

	public ResponseEntity<Object> getSchedulerJobNames() {
		RestTemplate template = new RestTemplate();
		Map<String, ?> uriVariables = Collections.emptyMap();
		String urlPath = cisEndpoint + appConfigContainer.getSchedulerJobPropertyPath();
		LOG.debug("cis request url ::>" + urlPath);
		return template.postForEntity(urlPath, Object.class, Object.class, uriVariables);
	}

}
