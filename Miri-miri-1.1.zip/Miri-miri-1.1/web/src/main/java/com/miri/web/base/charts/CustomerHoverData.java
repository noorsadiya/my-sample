package com.miri.web.base.charts;

import java.io.Serializable;

public class CustomerHoverData implements Serializable{
	String customerName;

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
}
