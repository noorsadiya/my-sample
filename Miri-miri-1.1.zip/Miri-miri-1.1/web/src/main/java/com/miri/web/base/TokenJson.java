/**
 *
 */
package com.miri.web.base;

import org.springframework.stereotype.Component;

import com.miri.web.common.Token;

/**
 * ViewJson : Represents the response any chart plotting request for a given
 * Metric.
 *
 * @author Chandra
 *
 */
@Component
public class TokenJson extends ViewResponse {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6588732465326902102L;
	
	private Token token;

	@Override
	public boolean isAuthenticated() {
		return isAuthenticated;
	}

	@Override
	public void setAuthenticated(boolean isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}

	public boolean isSuccess() {
		return isSuccess;
	}

	@Override
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public Token getToken() {
		return token;
	}

	public void setToken(Token token) {
		this.token = token;
	}

}
