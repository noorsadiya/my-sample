package com.miri.web.admin.controllers;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.miri.web.admin.facade.MailConfigFacade;
import com.miri.web.base.ResponseStatus;
import com.miri.web.base.ViewResponse;
import com.miri.web.base.WrappedViewResponse;
import com.miri.web.common.services.MetricJSONCacheService;
import com.miri.web.constants.WebConstants;
import com.miri.web.interceptors.ErrorCodeContainer.ErrorCodeEnum;

/**
 * @author supraja
 *
 */
@RestController
@RequestMapping("/mailConfig")
public class MailConfigController {

	private static final Logger LOG = Logger.getLogger(MailConfigController.class);

	@Autowired
	private MailConfigFacade mailConfigFacade;

	@RequestMapping(value = WebConstants.SAVE, method = RequestMethod.POST)
	public ViewResponse saveEmailConfigDetails(@RequestBody(required = true)
	final Map<String, Object> emailConfigs) throws Exception {
		LOG.info("Enter into saveEmailConfigDetails" + emailConfigs);
		ViewResponse viewResponse = new ViewResponse();
		mailConfigFacade.saveEmailConfigDetails(emailConfigs);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
		// Clear cache on successful update
		MetricJSONCacheService.getInstance().clearCache();
		return viewResponse;

	}

	@RequestMapping(value = WebConstants.GET, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse getEmailConfigDetails(final HttpServletRequest request) {
		Map<String, Object> mailConfigs = mailConfigFacade.getEmailConfigDetails();
		ViewResponse viewResponse = new WrappedViewResponse<Map<String, Object>>(mailConfigs);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	/**
	 *
	 * @param datasourceResponse
	 * @param isSuccess
	 * @param code
	 */
	private void getResponse(ViewResponse viewResponse, boolean isSuccess, String code, String msg) {
		viewResponse.setSuccess(isSuccess);
		viewResponse.setAuthenticated(true);
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(code);
		responseStatus.setMessage(msg);
		viewResponse.setResponseStatus(responseStatus);
	}

}
