package com.miri.web.base.charts.builders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.miri.search.data.ColumnDrillDownData;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.web.base.Chart;
import com.miri.web.base.ChartTypeEnum;
import com.miri.web.base.IChart;
import com.miri.web.base.charts.component.ChartComponent;
import com.miri.web.base.charts.component.ChartSeriesData;
import com.miri.web.base.charts.component.HoverData;
import com.miri.web.base.charts.component.IndustryHoverData;
import com.miri.web.base.charts.component.MetricResponse;
import com.miri.web.base.charts.component.Series;
import com.miri.web.base.charts.component.SeriesDrillDown;
import com.miri.web.constants.ControllerConstants;
import com.miri.web.constants.WebConstants;

/**
 * Bar Action Chart Builder - Top Industry Data
 * @author Noor
 *
 */
@Component
@Scope("prototype")
public class ColumnDrillDownChartBuilder extends GenericChartBuilder {

	ColumnDrillDownChart columnDrillDownChart;

	SeriesDrillDown seriesDrillDown;



	/**
	 * BarActionChart : Chart containing attributes specific to Bar Action Chart
	 */
	public static class ColumnDrillDownChart extends Chart implements Serializable {

		/**
		 * Generated Serial Version UID
		 */
		private static final long serialVersionUID = 998084432717603796L;
		private ChartComponent drilldown;

		public ChartComponent getDrilldown() {
			return drilldown;
		}

		public void setDrilldown(ChartComponent drilldown) {
			this.drilldown = drilldown;
		}
		
	}
    
    @Override
	public IChart buildChart(MetricResponse metricResponse) {
    	columnDrillDownChart = new ColumnDrillDownChart();
    	columnDrillDownChart.setChartMetadata(populateMetadata(metricResponse));
    	columnDrillDownChart.setyAxis(populateYAxisData(metricResponse));
    	columnDrillDownChart.setxAxis(populateXAxisData(metricResponse));
    	columnDrillDownChart.setSeries(populateSeries(metricResponse));
    	columnDrillDownChart.setDrilldown(populateDrillDownData(metricResponse));
    	columnDrillDownChart.setRanges(populateDollarRanges(metricResponse));
		return columnDrillDownChart;
    }


	
	@Override
	public ChartComponent populateMetadata(MetricResponse metricResponse) {
		//chartMetadata.setTitle(metricResponse.getTitle());
		chartMetadata.setGraphType(ChartTypeEnum.COLUMN_DRILL_DOWN.getText());
		return chartMetadata;
	}

	@Override
	public ChartComponent populateXAxisData(MetricResponse metricResponse) {
		xaxisData.setLabel((String)metricResponse.getItems().get(ControllerConstants.X_AXIS_LABEL));
		return xaxisData;
	}

	@Override
	public ChartComponent populateYAxisData(MetricResponse metricResponse) {
		yaxisData.setLabel((String)metricResponse.getItems().get(ControllerConstants.Y_AXIS_LABEL));
		return yaxisData;
	}

	@Override
	public ChartComponent populateLegends(MetricResponse metricResponse) {
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Series> populateSeries(MetricResponse metricResponse) {

		List<ColumnDrillDownData> metricDataList=(List<ColumnDrillDownData>)metricResponse.getItems().get(WebConstants.METRIC_DATA);

		Series series1 = new Series();
		//series1.setName("Industries");
		List<Series> seriesList = new ArrayList<>();
		List<ChartSeriesData> seriesDataList= new ArrayList<ChartSeriesData>();
		boolean isAnySeriesExists = false;
		if(CollectionUtils.isNotEmpty(metricDataList)){
			double value = 0;
			for(ColumnDrillDownData industryPojo:metricDataList){
				ChartSeriesData data=new ChartSeriesData();
				HoverData hoverData=new HoverData();
				data.setName(industryPojo.getName());
				if(industryPojo.getRevenueAmount() != null){
					data.setY(MiriSearchUtils.removeDecimalPoint(industryPojo.getRevenueAmount().longValue()));
					value += industryPojo.getRevenueAmount();
				}
				if(industryPojo.getNumberOfPartners() != null){
					data.setY(industryPojo.getNumberOfPartners());
					value += industryPojo.getNumberOfPartners();
				}
				if(industryPojo.getIndustryDrillDown() != null && industryPojo.getIndustryDrillDown().size() > 0){
					data.setDrilldown(industryPojo.getName());
				}

				if(industryPojo.getRevenueAmount() != null){
					hoverData.setRevenueAmount(MiriSearchUtils.removeDecimalPoint(industryPojo.getRevenueAmount()));
				}
				hoverData.setDealsClosed(industryPojo.getDealsClosed());
				if(null !=  industryPojo.getAverageDealSize()){
					hoverData.setAverageDealSize(MiriSearchUtils.removeDecimalPoint(industryPojo.getAverageDealSize()));
				}
				if(null != industryPojo.getAverageSellPrice()){
					hoverData.setAverageSellPrice(MiriSearchUtils.removeDecimalPoint(industryPojo.getAverageSellPrice()));

				}
				hoverData.setDealsClosed(industryPojo.getDealsClosed());

				hoverData.setPartnerRole(industryPojo.getPartnerRole());
				hoverData.setIndustryName(industryPojo.getIndustryName());
				hoverData.setPartnerName(industryPojo.getPartnerName());
				hoverData.setNumberOfPartners(industryPojo.getNumberOfPartners());
				hoverData.setOpportunityCount(industryPojo.getOpportunityCount());
				data.setHover(hoverData);
				seriesDataList.add(data); 
			}
			series1.setData(seriesDataList);
			seriesList.add(series1);
			if(value > 0){
				isAnySeriesExists = true;
			}
		}
		if(!isAnySeriesExists){
			seriesList = new ArrayList<>();
		}
		return seriesList;
	}

	@SuppressWarnings("unchecked")
	public ChartComponent populateDrillDownData(MetricResponse metricResponse) {
		List<ColumnDrillDownData> metricDataList=(List<ColumnDrillDownData>)metricResponse.getItems().get(WebConstants.METRIC_DATA);
		List<Series> seriesList=new ArrayList<>();
		Series series = null;
		List<ChartSeriesData> seriesDataList = null;
		for(ColumnDrillDownData industryPojo:metricDataList){
			if(industryPojo.getIndustryDrillDown() != null){
			series = new Series();
			series.setId(industryPojo.getName());
			series.setName(industryPojo.getName());
			 seriesDataList = new ArrayList<ChartSeriesData>();
				for(ColumnDrillDownData drillDownPojo:industryPojo.getIndustryDrillDown()){
					ChartSeriesData data = new ChartSeriesData();
					IndustryHoverData hoverData = new IndustryHoverData();
					hoverData.setRevenueAmount(drillDownPojo.getRevenueAmount());
					hoverData.setAverageDealSize(drillDownPojo.getAverageDealSize());
					hoverData.setAverageSellPrice(drillDownPojo.getAverageSellPrice());
					hoverData.setDealsClosed(drillDownPojo.getDealsClosed());
					hoverData.setIndustryName(drillDownPojo.getIndustryName());
					//hoverData.setPartnerName(drillDownPojo.getPartnerName());
					//hoverData.setPartnerRole(drillDownPojo.getPartnerRole());
					hoverData.setRevenueAmount(drillDownPojo.getRevenueAmount());
					hoverData.setOpportunityCount(drillDownPojo.getOpportunityCount());
					
					data.setName(drillDownPojo.getName());
					data.setY(drillDownPojo.getRevenueAmount());
					data.setHover(hoverData);
					seriesDataList.add(data);
				}
				series.setData(seriesDataList);
				seriesList.add(series);
			}
		}
		seriesDrillDown = new SeriesDrillDown();
		seriesDrillDown.setSeries(seriesList);
		return seriesDrillDown;
	}

	@Override
	public ChartComponent populateHover(MetricResponse metricResponse) {
		return null;
	}

	
	@Override
	public ChartComponent populateGuage(MetricResponse metricResponse) {
		return super.populateGuage(metricResponse);
	}
	
	
	@Override
	public double populateGuagePercentage(MetricResponse metricResponse) {
		return super.populateGuagePercentage(metricResponse);
	}

}
