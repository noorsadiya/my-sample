package com.miri.web.auth;

import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.miri.data.jpa.domain.Authority;
import com.miri.data.jpa.domain.User;
import com.miri.data.jpa.repository.UserRepository;

/**
 * Authenticate a user from the database.
 */
@Component("userDetailsService")
public class CustomUserDetailsService implements org.springframework.security.core.userdetails.UserDetailsService {

	private final Logger log = LoggerFactory.getLogger(CustomUserDetailsService.class);

	@Inject
	private UserRepository userRepository;

	@Override
	@Transactional
	public UserDetails loadUserByUsername(final String userName) {
		log.debug("Authenticating {}", userName);
		String lowercaseUserName = userName.toLowerCase();
		User user = userRepository.findActiveOneByUserName(userName);
		if (user != null) {
			if (!user.getActive()) {
				throw new UserNotActivatedException("User " + userName + " was not activated");
			}
			List<GrantedAuthority> grantedAuthorities = new LinkedList<>();
			for (Authority authority : user.getAuthorities()) {
				grantedAuthorities.add(new SimpleGrantedAuthority(authority.getNameAsString()));
			}
			return new org.springframework.security.core.userdetails.User(lowercaseUserName, user.getPassword(),
					grantedAuthorities);
		} else {
			throw new UsernameNotFoundException("User " + userName + " was not found in the database");
		}
	}
}
