package com.miri.web.admin.manual.controllers;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.miri.web.admin.manual.data.DataSourceData;
import com.miri.web.admin.manual.facade.ManualInputFacade;
import com.miri.web.admin.manual.facade.ManualInputFacade.SalesStageInfo;
import com.miri.web.base.ResponseStatus;
import com.miri.web.base.ViewResponse;
import com.miri.web.base.WrappedViewResponse;
import com.miri.web.common.services.MetricJSONCacheService;
import com.miri.web.constants.WebConstants;
import com.miri.web.interceptors.ErrorCodeContainer.ErrorCodeEnum;

/**
 * DatasourceSetupController: Save and get for datasource Setup.
 *
 * @author supraja
 *
 */
@RestController
@RequestMapping("/datasourceSetup")
public class DatasourceSetupController {
	private static final Logger LOG = Logger.getLogger(DatasourceSetupController.class);

//	@Autowired
//	private MessageSource messageSource;

	@Autowired
	private ManualInputFacade manualInputFacade;

//	/**
//	 *
//	 * @param datasourceSetup
//	 * @return
//	 */
//	@RequestMapping(value = WebConstants.CONNECT_DATASOURCE, method = RequestMethod.POST)
//	@ResponseBody
//	public ViewResponse connectToDatasource(@RequestBody(required = true)
//	final DatasourceSetup datasourceSetup) {
//		LOG.debug("Enter into connect to datasource" + datasourceSetup);
//		Map<String, String> params = new HashMap<String, String>();
//		ViewResponse viewResponse = new ViewResponse();
//		try {
//			boolean isValid = true;
//			if (datasourceSetup.getSystem().equals(WebConstants.MAP_ORACLE_ELOQUA)) {
//				// wbApiConfig = new EloquaRestAPIConfig();
//				params.put(WebConstants.COMPANY_NAME, datasourceSetup.getCompanyName());
//				params.put(WebConstants.URL, datasourceSetup.getUrl());
//				params.put(WebConstants.USERNAME, datasourceSetup.getUsername());
//				params.put(WebConstants.PASSWORD, datasourceSetup.getPassword());
//				isValid = validations(datasourceSetup, WebConstants.MAP_ORACLE_ELOQUA);
//			}
//			else if (datasourceSetup.getSystem().equals(WebConstants.MAP_PARDOT)) {
//				// wbApiConfig = new PardotRestAPIConfig();
//				params.put(WebConstants.EMAIL, datasourceSetup.getEmail());
//				params.put(WebConstants.PASSWORD, datasourceSetup.getPassword());
//				params.put(WebConstants.API_USER_KEY, datasourceSetup.getApiUserKey());
//				params.put(WebConstants.URL, datasourceSetup.getUrl());
//				isValid = validations(datasourceSetup, WebConstants.MAP_PARDOT);
//			}
//			else if (datasourceSetup.getSystem().equals(WebConstants.MAP_MARKETO)) {
//				// wbApiConfig = new MarketoRestAPIConfig();
//				params.put(WebConstants.CLIENT_ID, datasourceSetup.getClientId());
//				params.put(WebConstants.CLIENT_SECRET, datasourceSetup.getClientSecret());
//				params.put(WebConstants.URL, datasourceSetup.getUrl());
//				isValid = validations(datasourceSetup, WebConstants.MAP_MARKETO);
//			}
//			else if (datasourceSetup.getSystem().equals(WebConstants.CRM_SALES_FORCE)) {
//				// wbApiConfig = new SalesForceRestAPIConfig();
//				params.put(WebConstants.CLIENT_ID, datasourceSetup.getClientId());
//				params.put(WebConstants.CLIENT_SECRET, datasourceSetup.getClientSecret());
//				params.put(WebConstants.URL, datasourceSetup.getUrl());
//				params.put(WebConstants.USERNAME, datasourceSetup.getUsername());
//				params.put(WebConstants.PASSWORD, datasourceSetup.getPassword());
//				params.put(WebConstants.SECURITY_TOKEN, datasourceSetup.getSecurityToken());
//				isValid = validations(datasourceSetup, WebConstants.CRM_SALES_FORCE);
//			}
//
//			if (!isValid) {
//				getResponse(viewResponse, false, HttpStatus.BAD_REQUEST.toString(),
//						messageSource.getMessage("default.forbidden.error.msg", null, Locale.US));
//			}
//			else {
//				int response = 0;
//
//				// response = wbApiConfig.getAuthorizationResponse(params);
//				if (response == 200) {
//					getResponse(viewResponse, true, HttpStatus.OK.toString(),
//							messageSource.getMessage("datasource.success.msg", null, Locale.US));
//				}
//				else {
//					getResponse(viewResponse, false, HttpStatus.UNAUTHORIZED.toString(),
//							messageSource.getMessage("datasource.invalid.authorization", null, Locale.US));
//				}
//			}
//		}
//		catch (Exception e) {
//			LOG.error("Error while connect to datasource" + e.getMessage());
//			e.printStackTrace();
//			getResponse(viewResponse, false, HttpStatus.BAD_REQUEST.toString(),
//					messageSource.getMessage("default.error", null, Locale.US));
//		}
//
//		return viewResponse;
//	}

	/**
	 *
	 * @param datasourceResponse
	 * @param isSuccess
	 * @param code
	 */
	private void getResponse(ViewResponse viewResponse, boolean isSuccess, String code, String msg) {
		viewResponse.setSuccess(isSuccess);
		viewResponse.setAuthenticated(true);
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(code);
		responseStatus.setMessage(msg);
		viewResponse.setResponseStatus(responseStatus);
	}

	/**
	 *
	 * @param datasourceSetup
	 * @param vendorName
	 * @return
	 */
//	private boolean validations(DatasourceSetup datasourceSetup, String vendorName) {
//		boolean isvalid = true;
//		if (StringUtils.isEmpty(datasourceSetup.getInstanceName())) {
//			isvalid = false;
//			return isvalid;
//		}
//		if (vendorName.equals(WebConstants.MAP_ORACLE_ELOQUA)) {
//			if (StringUtils.isEmpty(datasourceSetup.getUrl())) {
//				isvalid = false;
//			}
//			else if (StringUtils.isEmpty(datasourceSetup.getUsername())) {
//				isvalid = false;
//			}
//			else if (StringUtils.isEmpty(datasourceSetup.getPassword())) {
//				isvalid = false;
//			}
//			else if (StringUtils.isEmpty(datasourceSetup.getCompanyName())) {
//				isvalid = false;
//			}
//		}
//		else if (vendorName.equals(WebConstants.MAP_PARDOT)) {
//			if (StringUtils.isEmpty(datasourceSetup.getUrl())) {
//				isvalid = false;
//			}
//			else if (StringUtils.isEmpty(datasourceSetup.getEmail())) {
//				isvalid = false;
//			}
//			else if (StringUtils.isEmpty(datasourceSetup.getPassword())) {
//				isvalid = false;
//			}
//			else if (StringUtils.isEmpty(datasourceSetup.getApiUserKey())) {
//				isvalid = false;
//			}
//		}
//		else if (vendorName.equals(WebConstants.MAP_MARKETO)) {
//			if (StringUtils.isEmpty(datasourceSetup.getUrl())) {
//				isvalid = false;
//			}
//			else if (StringUtils.isEmpty(datasourceSetup.getClientSecret())) {
//				isvalid = false;
//			}
//			else if (StringUtils.isEmpty(datasourceSetup.getClientId())) {
//				isvalid = false;
//			}
//		}
//
//		return isvalid;
//	}

	/**
	 * fetch the datasource details
	 *
	 * @param request
	 * @return
	 */
	@RequestMapping(value = WebConstants.GET, method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse getDatasourceSetup() {
		DataSourceData datasourceDetails = manualInputFacade.getDatasourceSetupDetails();
		ViewResponse viewResponse = new WrappedViewResponse<DataSourceData>(datasourceDetails);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	@RequestMapping(value = "config/test", method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse testDataSource(@RequestBody(required = true) final Map<String, String> dataSourceConfig) {
		ResponseEntity<Object> responseEntity = manualInputFacade.testDataSource(dataSourceConfig);
		Object body = responseEntity.getBody();
		HttpStatus statusCode = responseEntity.getStatusCode();

		ViewResponse viewResponse = new WrappedViewResponse<Object>(body);
		viewResponse.setSuccess(HttpStatus.OK.equals(statusCode));

		return viewResponse;
	}

	/**
	 * Save/Submit datasource details to DB and elastic search
	 *
	 * @param datasourceMap
	 * @return
	 */
	@RequestMapping(value = WebConstants.SAVE, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse saveDatasourceSetup(
			@RequestBody(required = true) final DataSourceData datasourceDetails) {
		manualInputFacade.updateDataSourceSetup(datasourceDetails);
		DataSourceData updatedDatasourceDetails = manualInputFacade.getDatasourceSetupDetails();
		ViewResponse viewResponse = new WrappedViewResponse<DataSourceData>(updatedDatasourceDetails);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
		// Clear cache on successful update
		MetricJSONCacheService.getInstance().clearCache();
		return viewResponse;
	}

//	/**
//	 *
//	 * @param request
//	 * @param vendorName
//	 * @return
//	 */
//	@RequestMapping(value = WebConstants.VERIFY_SALES_STAGES+"/{vendorName}", method = { RequestMethod.POST })
//	@ResponseBody
//	public ViewResponse verifySalesStages(
//			@PathVariable("vendorName") final String vendorName){
//		ViewResponse viewResponse = null;
//		List<SalesStage> sales = new ArrayList<SalesStage>();
//		SalesStage salesStage = new SalesStage();
//		salesStage.setAssignedTo("others");
//		salesStage.setName("Prospecting");
//		salesStage.setId("Prospecting");
//		salesStage.setSelectable(true);
//		salesStage.setSelected(true);
//		SalesStage salesStage1 = new SalesStage();
//		salesStage1.setAssignedTo("others");
//		salesStage1.setId("qualification");
//		salesStage1.setName("Qualification");
//		salesStage1.setSelectable(true);
//		salesStage1.setSelected(true);
//		sales.add(salesStage1);
//		sales.add(salesStage);
//		viewResponse = new WrappedViewResponse<List<SalesStage>>(sales);
//		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
//
//		return viewResponse;
//	}

	/**
	 *
	 * @param salesStages
	 * @return
	 */
	@RequestMapping(value = WebConstants.SAVE_SALES + "/{vendorName}/{instanceName}", method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse saveSalesStages(@PathVariable String vendorName, @PathVariable String instanceName,
			@RequestBody(required = true) final List<SalesStageInfo> salesStagesMapping) {
		manualInputFacade.saveCrmSalesStageMapping(salesStagesMapping, vendorName, instanceName);
		ViewResponse viewResponse = new ViewResponse();
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
		// Clear cache on successful update
		MetricJSONCacheService.getInstance().clearCache();

		return viewResponse;
	}

	@RequestMapping(value = WebConstants.GET_SALES + "/{vendorName}/{instanceName}", method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse getSalesStages(@PathVariable String vendorName, @PathVariable String instanceName) {
		LOG.info("Vendor Instance Name :" + vendorName);
		List<SalesStageInfo> salesStageMapping = manualInputFacade.getSalesStageMapping(vendorName, instanceName);
		ViewResponse viewResponse = new WrappedViewResponse<List<SalesStageInfo>>(salesStageMapping);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	@RequestMapping(value = "/salesStages/local/list", method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse getLocalSalesStages() {
		Map<Long, String> localStages = manualInputFacade.getLocalSalesStages();
		ViewResponse viewResponse = new WrappedViewResponse<Map<Long, String>>(localStages);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	@RequestMapping(value = "salesStages/vendor/list", method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse getCrmVendors() {
		List<String> vendorNames = manualInputFacade.getCrmVendors();
		ViewResponse viewResponse = new WrappedViewResponse<List<String>>(vendorNames);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	public static class SalesStageMappingInfo {
		private Long id;
		private String name;
		private List<Long> assignedStages;
		private boolean active;

		public SalesStageMappingInfo() {
			super();
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public List<Long> getAssignedStages() {
			return assignedStages;
		}

		public void setAssignedStages(List<Long> assignedStages) {
			this.assignedStages = assignedStages;
		}

		public boolean isActive() {
			return active;
		}

		public void setActive(boolean active) {
			this.active = active;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("SalesStageMappingInfo [id=");
			builder.append(id);
			builder.append(", name=");
			builder.append(name);
			builder.append(", assignedStages=");
			builder.append(assignedStages);
			builder.append(", active=");
			builder.append(active);
			builder.append("]");
			return builder.toString();
		}
	}
}
