/**
 * 
 */
package com.miri.web.admin.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * @author Chandra
 *
 */
@Component
@Service
public class ManualEntryService {/*

	@Autowired
	CampaignService campaignService;
	
	public boolean createOrUpdateCampaign(ManualEntryPojo entryPojo) {
		System.out.println("CreateOrUpdateCampaign method");
		//campaignService.updateCampaign(entryPojo);
		return true;
	}

	public List<ManualEntryPojo> fetchAllCampaigns() {
		//List<ManualEntryPojo> entryPojos = new ArrayList<>();
		
		return null;
	}


*/}
