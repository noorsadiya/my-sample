package com.miri.web.base.charts.builders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.miri.search.constants.SearchConstants;
import com.miri.search.data.LargeOpenOpportunitiesMetricData;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.web.base.Chart;
import com.miri.web.base.IChart;
import com.miri.web.base.charts.component.ChartComponent;
import com.miri.web.base.charts.component.ChartSeriesData;
import com.miri.web.base.charts.component.LargeOpenOppHoverData;
import com.miri.web.base.charts.component.MetricResponse;
import com.miri.web.base.charts.component.Series;
import com.miri.web.constants.ControllerConstants;

@Component
@Scope("prototype")
public class ColumnRotatedLabelsChartBuilder  extends GenericChartBuilder{

	ColumnRotated columnRotated;
	
	/**
	 * MultipleAxesChart : Chart containing attributes specific to Multiple Axes
	 * Chart
	 */
	public static class ColumnRotated extends Chart implements Serializable {

		/**
		 * Generated Serial Version UID
		 */
		private static final long serialVersionUID = 4190766473673030960L;
		
	}

	@Override
	public ChartComponent populateMetadata(MetricResponse metricResponse) {
		chartMetadata.setTitle(ControllerConstants.LARGE_OPEN_OPPORTINITIES);
		chartMetadata.setSubtitle(ControllerConstants.OPEN_OPPORTINITIES);
		chartMetadata.setGraphType(ControllerConstants.LARGE_OPEN_OPPORTINITIES_CHART_TYPE);
		return chartMetadata;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ChartComponent populateXAxisData(MetricResponse metricResponse) {
		xaxisData.setLabel((String) metricResponse.getItems().get(ControllerConstants.X_AXIS_LABEL));
		List<LargeOpenOpportunitiesMetricData> metricData = (List<LargeOpenOpportunitiesMetricData>) metricResponse.getItems().get(SearchConstants.CAMPAIGN_DATA);
		List<String> xAxisNames = new ArrayList<String>();
		for (LargeOpenOpportunitiesMetricData entry : metricData) {
			xAxisNames.add(entry.getName());
		}
		xaxisData.setData(xAxisNames);
		return xaxisData;
	}

	@Override
	public ChartComponent populateYAxisData(MetricResponse metricResponse) {
		yaxisData.setLabel((String) metricResponse.getItems().get(ControllerConstants.Y_AXIS_LABEL));
		return yaxisData;
	}

	@Override
	public ChartComponent populateLegends(MetricResponse metricResponse) {
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Series> populateSeries(MetricResponse metricResponse) {
		List<Series> seriesList = new ArrayList<Series>();
		List<LargeOpenOpportunitiesMetricData>  metricData = (List<LargeOpenOpportunitiesMetricData>) metricResponse.getItems().get(SearchConstants.CAMPAIGN_DATA);
		Series series = new Series();
		List<ChartSeriesData> seriesDataList = null;
		int i = 0;
		double value = 0;
		ChartSeriesData data = null;
		boolean isAnySeriesExists = false;
		if(metricData.size() > 0){
			seriesDataList = new ArrayList<ChartSeriesData>();
		}
		for (LargeOpenOpportunitiesMetricData graphData : metricData) {
			data = new ChartSeriesData();
			LargeOpenOppHoverData hoverData = new LargeOpenOppHoverData();
			value += graphData.getAmount();
			data.setY(MiriSearchUtils.removeDecimalPoint(graphData.getAmount()));
			//miri-1832 - Set y value to z placeholder for FE 
			data.setZ(MiriSearchUtils.removeDecimalPoint(graphData.getzValue()));
			hoverData.setStage(graphData.getStage());
			hoverData.setProbability(graphData.getProbability());
//			hoverData.setCustomerName(mapData.get(CRMConstants.OPPORTUNITY_COMPANY_NAME));
			hoverData.setCampaignName(graphData.getCampaignName());
			hoverData.setOpportunityCount(graphData.getOpportunityCount());
			//hoverData.setCustomerName(graphData.getCustomerName());
			data.setHover(hoverData);
			data.setX(i);
			seriesDataList.add(data);
			series.setName(ControllerConstants.LARGE_OPEN_OPPORTINITIES);
			series.setData(seriesDataList);
			i++;
		}
		seriesList.add(series);
		if(value > 0){
			isAnySeriesExists = true;
		}
		if(!isAnySeriesExists){
			seriesList = new ArrayList<>();
		}
		return seriesList;
	}


	@Override
	public IChart buildChart(MetricResponse metricResponse) {
		columnRotated = new ColumnRotated();
		columnRotated.setxAxis(populateXAxisData(metricResponse));
		columnRotated.setyAxis(populateYAxisData(metricResponse));
		columnRotated.setSeries(populateSeries(metricResponse));
		columnRotated.setChartMetadata(populateMetadata(metricResponse));
		columnRotated.setParentData(super.populateCampaignHierarchy(metricResponse));
		columnRotated.setRanges(populateDollarRanges(metricResponse));
		return columnRotated;
	}

	@Override
	public ChartComponent populateHover(MetricResponse metricResponse) {
		return null;
	}
	
}
