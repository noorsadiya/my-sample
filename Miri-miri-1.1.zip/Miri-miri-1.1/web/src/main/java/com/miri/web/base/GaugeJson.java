package com.miri.web.base;

import java.util.List;

import org.springframework.stereotype.Component;

import com.miri.web.base.charts.component.ChartComponent;
import com.miri.web.dashboard.dataquality.data.IndexData;

@Component
public class GaugeJson extends ViewResponse{
	
	
	List<IndexData> indicesList;
	
	public List<IndexData> getIndicesList() {
		return indicesList;
	}
	
	public void setIndicesList(List<IndexData> indicesList) {
		this.indicesList = indicesList;
	}
	
	
	/*private boolean isGaugeAvailable;
	
	private double guagePercentage;
	
	private boolean showGaugeTable;
	
	private ChartComponent guageTable;

	public boolean isGaugeAvailable() {
		return null != guageTable;
	}

	public void setGaugeAvailable(boolean isGaugeAvailable) {
		this.isGaugeAvailable = isGaugeAvailable;
	}

	public double getGuagePercentage() {
		return guagePercentage;
	}

	public void setGuagePercentage(double guagePercentage) {
		this.guagePercentage = guagePercentage;
	}

	public ChartComponent getGuageTable() {
		return guageTable;
	}

	public void setGuageTable(ChartComponent guageTable) {
		this.guageTable = guageTable;
	}

	public boolean isShowGaugeTable() {
		return showGaugeTable;
	}

	public void setShowGaugeTable(boolean showGaugeTable) {
		this.showGaugeTable = showGaugeTable;
	}*/
	
	
	
	
	

}
