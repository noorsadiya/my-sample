/**
 *
 */
package com.miri.configuration;

import javax.inject.Inject;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.data.repository.query.SecurityEvaluationContextExtension;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.access.ExceptionTranslationFilter;

import com.miri.web.auth.AuthenticationProvider;
import com.miri.web.auth.Http401UnauthorizedEntryPoint;
import com.miri.web.auth.RestExceptionTranslationFilter;
import com.miri.web.common.services.UserLoginTokenService;
import com.miri.web.common.services.UserService;
import com.miri.web.security.xauth.XAuthTokenConfigurer;

/**
 * @author Chandra
 *
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	private static final String ROLE_MASTER = "ROLE_MASTER";
	private static final String ROLE_ADMIN = "ROLE_ADMIN";
	private static final String ROLE_EXECUTIVE = "ROLE_EXECUTIVE";
	private static final String ROLE_USER = "ROLE_USER";

	@Inject
    private Http401UnauthorizedEntryPoint authenticationEntryPoint;

	@Inject
    private UserDetailsService customUserDetailsService;

	@Inject
    private UserLoginTokenService authTokenService;

	@Inject
    private UserService userService;

	private AccessDeniedHandler accessDeniedHandler = new MiriAccessDeniedHandler();

	@Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    public AuthenticationProvider getAuthenticationProvider(){
    	return new com.miri.web.auth.AuthenticationProvider(passwordEncoder(),userService);
    }

    @Inject
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(getAuthenticationProvider());
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring()
//            .antMatchers("/scripts/**/*.{js,html}")
//            .antMatchers("/bower_components/**")
//            .antMatchers("/i18n/**")
//            .antMatchers("/assets/**")
            .antMatchers(HttpMethod.OPTIONS, "/**") // for CORS
            .antMatchers("/api/authenticate") // ignore for authentication request
            .antMatchers("/accountSetup/logo") // allow logo request without auth
            .antMatchers("/download/**") //will allow downloads
            .antMatchers("/accountSetup/logo")
            .antMatchers("/master/**")
            .antMatchers("/license/**")
//            .antMatchers("/dashboard/**")
            .antMatchers("/api/profile/forgetPassword")
            ;
    }

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
	        .exceptionHandling()
	        .authenticationEntryPoint(authenticationEntryPoint)
	    .and()
	        .csrf()
	        .disable()
	        .headers()
	        .frameOptions()
	        .disable();
		http
	        .sessionManagement()
	        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
	    .and()
	        .authorizeRequests()
	    	.antMatchers("/api/logout").permitAll()
	    	.antMatchers("/api/profile/changePassword").permitAll()
	    	.antMatchers("/api/profile/update").permitAll()
	    	.antMatchers("/api/profile/get").permitAll()
	    	.antMatchers("/api/profile/changebgImg").permitAll()
	    	.antMatchers("/api/user/getRoles").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN)
	    	.antMatchers("/api/user/delete").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN)
	    	.antMatchers("/api/user/save").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN)
	    	.antMatchers("/api/user/update").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN)
	    	.antMatchers("/api/user/getAll").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN)
	    	.antMatchers("/admin/**").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN)
	    	.antMatchers("/dashboard/**").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN, ROLE_EXECUTIVE, ROLE_USER)
	    	.antMatchers(HttpMethod.GET, "/assess/**").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN, ROLE_EXECUTIVE, ROLE_USER)
	    	.antMatchers(HttpMethod.POST, "/assess/**").hasAuthority(ROLE_EXECUTIVE)
	    	.antMatchers("/accountSetup/**").hasAnyAuthority(ROLE_MASTER)
	    	.antMatchers("/businessImpactIndicator/**").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN, ROLE_EXECUTIVE, ROLE_USER)
	    	.antMatchers("/businessStrategy/**").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN, ROLE_EXECUTIVE, ROLE_USER)
	    	.antMatchers("/campaignStrategy/**").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN, ROLE_EXECUTIVE, ROLE_USER)
	    	.antMatchers("/datasourceSetup/**").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN)
	    	.antMatchers("/mailConfig/**").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN)
	    	.antMatchers("/token/download/**").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN, ROLE_EXECUTIVE, ROLE_USER)
	    	.antMatchers("/email/**").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN, ROLE_EXECUTIVE, ROLE_USER)
	    	.antMatchers("/dataQuality/**").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN, ROLE_EXECUTIVE, ROLE_USER)
//	    	.antMatchers("/master/**").hasAnyAuthority(ROLE_MASTER)
//	    	.antMatchers("/license/**").hasAnyAuthority(ROLE_MASTER, ROLE_ADMIN, ROLE_EXECUTIVE, ROLE_USER)
	    .and()
            .apply(securityConfigurerAdapter())
        .and()
        	.exceptionHandling().accessDeniedHandler(accessDeniedHandler);

		http.authorizeRequests().anyRequest().authenticated();
	}

	private XAuthTokenConfigurer securityConfigurerAdapter() {
		return new XAuthTokenConfigurer(customUserDetailsService, authTokenService);
    }

    @Bean
    public SecurityEvaluationContextExtension securityEvaluationContextExtension() {
        return new SecurityEvaluationContextExtension();
    }

    @Bean
    public ExceptionTranslationFilter exceptionTranslationFilter() {
	    RestExceptionTranslationFilter exceptionTranslationFilter = new  RestExceptionTranslationFilter(authenticationEntryPoint);
	    exceptionTranslationFilter.afterPropertiesSet();
	    return exceptionTranslationFilter;
    }
}
