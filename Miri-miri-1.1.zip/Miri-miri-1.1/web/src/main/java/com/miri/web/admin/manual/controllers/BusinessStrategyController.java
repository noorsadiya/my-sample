package com.miri.web.admin.manual.controllers;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.miri.search.data.BusinessStrategySetup;
import com.miri.web.admin.manual.facade.ManualInputFacade;
import com.miri.web.base.ResponseStatus;
import com.miri.web.base.ViewResponse;
import com.miri.web.base.WrappedViewResponse;
import com.miri.web.common.services.MetricJSONCacheService;
import com.miri.web.constants.WebConstants;
import com.miri.web.interceptors.ErrorCodeContainer.ErrorCodeEnum;

/**
 * @author supraja
 *
 */
@RestController
@RequestMapping("/businessStrategy")
public class BusinessStrategyController {
	private static final Logger LOG = Logger.getLogger(BusinessStrategyController.class);

	@Autowired
	private ManualInputFacade manualInputFacade;

	/**
	 *
	 * @param businessStrategySetup
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = WebConstants.SAVE, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse saveBusinessStrategyDetails(
			@RequestBody(required = true) final BusinessStrategySetup businessStrategySetup) throws IOException {
		LOG.info("Enter into saveBusinessStrategyDetails" + businessStrategySetup);
		ViewResponse viewResponse = new ViewResponse();
		manualInputFacade.saveBusinessStrategyDetails(businessStrategySetup);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
		// Clear cache on successful update
		MetricJSONCacheService.getInstance().clearCache();
		return viewResponse;

	}

	/**
	 *
	 * @param request
	 * @return
	 */
	@RequestMapping(value = WebConstants.GET, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse getBusinessStrategyDetails(
			final HttpServletRequest request) {
		BusinessStrategySetup businessStrategySetup = manualInputFacade.getBusinessStrategyDetails();
		ViewResponse viewResponse = new WrappedViewResponse<BusinessStrategySetup>(businessStrategySetup);
		getResponse(viewResponse,true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}
	/**
	 *
	 * @param datasourceResponse
	 * @param isSuccess
	 * @param code
	 */
	private void getResponse(ViewResponse viewResponse, boolean isSuccess, String code, String msg) {
		viewResponse.setSuccess(isSuccess);
		viewResponse.setAuthenticated(true);
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(code);
		responseStatus.setMessage(msg);
		viewResponse.setResponseStatus(responseStatus);
	}
}
