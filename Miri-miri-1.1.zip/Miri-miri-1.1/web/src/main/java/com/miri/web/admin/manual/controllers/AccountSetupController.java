package com.miri.web.admin.manual.controllers;

import java.io.IOException;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.miri.search.data.AccountSetup;
import com.miri.search.service.manual.ManualAccountStrategyService;
import com.miri.web.admin.manual.facade.ManualInputFacade;
import com.miri.web.base.ResponseStatus;
import com.miri.web.base.ViewResponse;
import com.miri.web.base.WrappedViewResponse;
import com.miri.web.common.services.MetricJSONCacheService;
import com.miri.web.constants.WebConstants;
import com.miri.web.interceptors.ErrorCodeContainer.ErrorCodeEnum;

/**
 * AccountSetupController: Save and get for Account Setup.
 *
 * @author supraja
 *
 */
@RestController
@RequestMapping("/accountSetup")
public class AccountSetupController {
	private static final Logger LOG = Logger.getLogger(AccountSetupController.class);

	@Autowired
	private ManualAccountStrategyService accountSetupService;

	@Autowired
	private ManualInputFacade manualInputFacade;

	@Autowired
	private MessageSource messageSource;

	/**
	 * Get the currency, industry and country data
	 *
	 * @return
	 */
	@RequestMapping(value = WebConstants.POPULATE_DATA, method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse populateFormData() {
		Map<String, Object> accountDetails = accountSetupService.populateAccountSetupData();
		ViewResponse viewResponse = new WrappedViewResponse<Map<String, Object>>(accountDetails);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	/**
	 * Save or update the details
	 *
	 * @param accountSetup
	 * @return
	 * @throws IOException if saving the setup details fails
	 */
	@RequestMapping(value = WebConstants.SAVE, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse saveAccountSetup(@RequestBody(required = true) final AccountSetup accountSetup) throws IOException {
		LOG.debug("Enter into saveAccountSetup" + accountSetup);

		ViewResponse viewResponse = new ViewResponse();
		String errorMsg = null;
		// check saveAsDraft or Submit request.
		if (!accountSetup.isDraft()) {
			errorMsg = validations(accountSetup);
		}
		if (errorMsg != null && errorMsg.length() > 0) {
			getResponse(viewResponse, false, ErrorCodeEnum.MIRI_404.toString(), errorMsg);
		} else {
			accountSetupService.saveAccountSetupDetails(accountSetup);
			getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
			// Clear cache on successful update
			MetricJSONCacheService.getInstance().clearCache();
		}

		return viewResponse;
	}

	/**
	 * validating the fields
	 *
	 * @param accountSetup
	 * @return
	 */
	private String validations(AccountSetup accountSetup) {
		StringBuilder errorMsg = new StringBuilder();
		String[] args = new String[10];
		String messageCode = "account.submit.field.validation";
		if (StringUtils.isEmpty(accountSetup.getCompanyName())) {
			args[0] = "CompanyName";
			errorMsg.append(messageSource.getMessage(messageCode, args, Locale.US));
		}
		if (StringUtils.isEmpty(accountSetup.getBusinessUnit())) {
			args[0] = "BusinessUnit";
			errorMsg.append(messageSource.getMessage(messageCode, args, Locale.US));
		}
		if (StringUtils.isEmpty(accountSetup.getAddress1())) {
			args[0] = "Address1";
			errorMsg.append(messageSource.getMessage(messageCode, args, Locale.US));
		}
		if (StringUtils.isEmpty(accountSetup.getState())) {
			args[0] = "State";
			errorMsg.append(messageSource.getMessage(messageCode, args, Locale.US));
		}
		if (StringUtils.isEmpty(accountSetup.getZipCode())) {
			args[0] = "ZipCode";
			errorMsg.append(messageSource.getMessage(messageCode, args, Locale.US));
		}
		if (accountSetup.getCountryId() == 0) {
			args[0] = "Country";
			errorMsg.append(messageSource.getMessage(messageCode, args, Locale.US));
		}
		if (accountSetup.getIndustryId() == 0) {
			args[0] = "Industry";
			errorMsg.append(messageSource.getMessage(messageCode, args, Locale.US));
		}
		if (accountSetup.getCurrencyId() == 0) {
			args[0] = "Currency";
			errorMsg.append(messageSource.getMessage(messageCode, args, Locale.US));
		}
		if (StringUtils.isEmpty(accountSetup.getWebsite())) {
			args[0] = "Website";
			errorMsg.append(messageSource.getMessage(messageCode, args, Locale.US));
		}
		if (StringUtils.isEmpty(accountSetup.getFiscalStart())) {
			args[0] = "FiscalStart";
			errorMsg.append(messageSource.getMessage(messageCode, args, Locale.US));
		}
		return errorMsg.toString();
	}

	/**
	 *
	 * @param request
	 * @param accountId
	 * @return
	 */
	@RequestMapping(value = WebConstants.GET, method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse getAccountDetails() {
		AccountSetup accountSetup = accountSetupService.getAccountDetails();

		ViewResponse viewResponse = new WrappedViewResponse<AccountSetup>(accountSetup);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	@RequestMapping(value = WebConstants.LOGO, method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public ViewResponse getLogo() {
		String logo = manualInputFacade.getLogo();

		ViewResponse viewResponse = new WrappedViewResponse<String>(logo);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	/**
	 *
	 * @param datasourceResponse
	 * @param isSuccess
	 * @param code
	 */
	private void getResponse(ViewResponse viewResponse, boolean isSuccess, String code, String msg) {
		viewResponse.setSuccess(isSuccess);
		viewResponse.setAuthenticated(true);
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(code);
		responseStatus.setMessage(msg);
		viewResponse.setResponseStatus(responseStatus);
	}
}
