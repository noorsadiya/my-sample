package com.miri.web.base.charts.builders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.miri.search.data.CampaignRevenueData;
import com.miri.search.data.StackedColumnData;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.web.base.Chart;
import com.miri.web.base.IChart;
import com.miri.web.base.charts.component.ChartComponent;
import com.miri.web.base.charts.component.ChartSeriesData;
import com.miri.web.base.charts.component.HoverData;
import com.miri.web.base.charts.component.MetricResponse;
import com.miri.web.base.charts.component.Series;
import com.miri.web.constants.WebConstants;

/**
 * Column Stacked Builder for Win Loss Trend Analysis
 * @author rammoole
 *
 */
@Component
@Scope("prototype")
public class ColumnStackedChartBuilder extends GenericChartBuilder {

	@SuppressWarnings("unused")
	private static final Logger LOG = LogManager.getLogger(ColumnStackedChartBuilder.class);

	ColumnStackedChart columnStackedChart;

	public static class ColumnStackedChart extends Chart implements Serializable {
		/**
		 * Generated Serial Version UID
		 */
		private static final long serialVersionUID = -1743224504015425767L;
		private ChartComponent drilldown;

		/**
		 * @return the drilldown
		 */
		public ChartComponent getDrilldown() {
			return drilldown;
		}

		/**
		 * @param drilldown the drilldown to set
		 */
		public void setDrilldown(ChartComponent drilldown) {
			this.drilldown = drilldown;
		}
	}

	@Override
	public ChartComponent populateMetadata(MetricResponse metricResponse) {
		chartMetadata.setTitle((String)metricResponse.getItems().get(WebConstants.GRAPH_TITLE));
		chartMetadata.setSubtitle((String)metricResponse.getItems().get(WebConstants.SUBTITLE));
		chartMetadata.setSubtitle((String)metricResponse.getItems().get(WebConstants.GRAPH_TYPE));
		return chartMetadata;
	}

	@Override
	public ChartComponent populateXAxisData(MetricResponse metricResponse) {
		xaxisData.setLabel((String)metricResponse.getItems().get(WebConstants.X_AXIS_LABEL));
		xaxisData.setData(metricResponse.getItems().get(WebConstants.X_AXIS_DATA));
		return xaxisData;
	}

	@Override
	public ChartComponent populateYAxisData(MetricResponse metricResponse) {
		yaxisData.setLabel((String)metricResponse.getItems().get(WebConstants.Y_AXIS_LABEL));
		return yaxisData;
	}

	@Override
	public ChartComponent populateLegends(MetricResponse metricResponse) {
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Series> populateSeries(MetricResponse metricResponse) {
		Series seriesOne = new Series();
		//Series seriesTwo = new Series();
		List<StackedColumnData> stackedColumnData = (List<StackedColumnData>) metricResponse.getItems().get(WebConstants.STACKED_COLUMN_METRIC);
		//List<String> xaxisCategories = (List<String>) metricResponse.getItems().get(WebConstants.X_AXIS_DATA);
		List<ChartSeriesData> seriesDataOne = new ArrayList<>();
		//List<ChartSeriesData> seriesDataTwo = new ArrayList<>();
		ChartSeriesData chartSeriesDataOne;
//		/ChartSeriesData chartSeriesDataTwo;
		HoverData hoverOne;
		int index = 0;
		//String seriesOneName = metricResponse.getItems().get(WebConstants.SERIES_ONE_NAME).toString();
		//String seriesTwoName = metricResponse.getItems().get(WebConstants.SERIES_TWO_NAME).toString();
		List<Series> seriesList = new ArrayList<>();
		boolean isAnySeriesExists = false;
		for(StackedColumnData stackedColumn: stackedColumnData) {
			seriesOne = new Series();
			List<CampaignRevenueData> campaignRevenueDatas = stackedColumn.getStackedData();
			double value  = 0;
			seriesDataOne = new ArrayList<>();
			for(CampaignRevenueData campaignRevenueData :  campaignRevenueDatas) {
				chartSeriesDataOne = new ChartSeriesData();
				hoverOne = new HoverData();
				chartSeriesDataOne.setX(index);
				if(null != campaignRevenueData.getRevenueAmount()){
					chartSeriesDataOne.setY(MiriSearchUtils.removeDecimalPoint(campaignRevenueData.getRevenueAmount()));
					value += campaignRevenueData.getRevenueAmount();
					hoverOne.setRevenueAmount(MiriSearchUtils.removeDecimalPoint(campaignRevenueData.getRevenueAmount()));
				}
				
				hoverOne.setDealsClosed(campaignRevenueData.getNoOfDeals());
				
				if(StringUtils.isNotEmpty(campaignRevenueData.getCampaignName())){
					hoverOne.setCampaignName(campaignRevenueData.getCampaignName());
				}
				if(StringUtils.isNotEmpty(campaignRevenueData.getProductName())){
					hoverOne.setProductName(campaignRevenueData.getProductName());
				}
				if(StringUtils.isNotEmpty(campaignRevenueData.getSalesPerson())){
					hoverOne.setSalesPersonName(campaignRevenueData.getSalesPerson());
				}
				if(StringUtils.isNotEmpty(campaignRevenueData.getCompetitorName())){
					hoverOne.setCompetitorName(campaignRevenueData.getCompetitorName());
				}
				chartSeriesDataOne.setHover(hoverOne);
				seriesDataOne.add(chartSeriesDataOne);
			}
			seriesOne.setData(seriesDataOne);
			seriesOne.setName(stackedColumn.getName());
			seriesList.add(seriesOne);
			if(value > 0){
				isAnySeriesExists = true;
			}
/*			chartSeriesDataOne = new ChartSeriesData();
			//chartSeriesDataOne.setName(xaxisCategories.get(index));
			chartSeriesDataOne.setX(index);
			chartSeriesDataOne.setY(stackedColumn.getTotalAmount());
			hoverOne = new HoverData();
			hoverOne.setRevenueWon(stackedColumn.getWonRevenue());
			hoverOne.setWonCount(stackedColumn.getWonCount());
			chartSeriesDataOne.setHover(hoverOne);

			chartSeriesDataTwo = new ChartSeriesData();
			//chartSeriesDataTwo.setName(xaxisCategories.get(index));
			chartSeriesDataTwo.setX(index);
			chartSeriesDataTwo.setY(stackedColumn.getQualifiedAmount());
			hoverOne = new HoverData();
			hoverOne.setRevenueLost(stackedColumn.getLostRevenue());
			hoverOne.setLostCount(stackedColumn.getLostCount());
			chartSeriesDataTwo.setHover(hoverOne);

			if(stackedColumn.getCoutriesWinLossData() != null && !stackedColumn.getCoutriesWinLossData().isEmpty()) {
				// If the countries data is not null and non empty then add drilldown information
				chartSeriesDataOne.setDrilldown(stackedColumn.getxAxis().toString() + "-" + seriesOneName);
				chartSeriesDataTwo.setDrilldown(stackedColumn.getxAxis().toString() + "-" + seriesTwoName);
			}
			seriesDataTwo.add(chartSeriesDataTwo);
			seriesDataOne.add(chartSeriesDataOne);
*/			index++;
		}
		//seriesOne.setName(seriesOneName);
		//seriesOne.setData(seriesDataOne);
		//seriesTwo.setName(seriesTwoName);
		//seriesTwo.setData(seriesDataTwo);
		if(!isAnySeriesExists){
			seriesList = new ArrayList<>();
		}
		return seriesList;
	}

	@Override
	public ChartComponent populateHover(MetricResponse metricResponse) {
		return null;
	}

	@Override
	public IChart buildChart(MetricResponse metricResponse) {
		columnStackedChart = new ColumnStackedChart();
		columnStackedChart.setChartMetadata(populateMetadata(metricResponse));
		columnStackedChart.setyAxis(populateYAxisData(metricResponse));
		columnStackedChart.setxAxis(populateXAxisData(metricResponse));
		columnStackedChart.setSeries(populateSeries(metricResponse));
		columnStackedChart.setRanges(populateDollarRanges(metricResponse));
		columnStackedChart.setDrilldown(populateDrillDown(metricResponse));
		columnStackedChart.setyTDTarget(populateYTDTarget(metricResponse));
		return columnStackedChart;
	}

	/**
	 * Populating drill down object to the series
	 * @param metricResponse
	 * @return
	 */
	public ChartComponent populateDrillDown(MetricResponse metricResponse) {
//		List<StackedColumnData> stackedColumnData = (List<StackedColumnData>) metricResponse.getItems().get(WebConstants.STACKED_COLUMN_METRIC);
//
//		String seriesOneName = metricResponse.getItems().get(WebConstants.SERIES_ONE_NAME).toString();
//		String seriesTwoName = metricResponse.getItems().get(WebConstants.SERIES_TWO_NAME).toString();
//		List<Series> drillDownSeries = new ArrayList<>();
//		SeriesDrillDown seriesDrillDown = new SeriesDrillDown();
//		for(StackedColumnData stackedColumn: stackedColumnData) {
//			if(!MapUtils.isEmpty(stackedColumn.getCoutriesWinLossData())) {
//				Series seriesOne = new Series();
//				Series seriesTwo = new Series();
//
//				seriesOne.setId(stackedColumn.getxAxis().toString() + "-" + seriesOneName);
//				seriesOne.setName(seriesOneName);
//
//				seriesTwo.setId(stackedColumn.getxAxis().toString() + "-" + seriesTwoName);
//				seriesTwo.setName(seriesTwoName);
//				List<ChartSeriesData> seriesDataListOne = new ArrayList<ChartSeriesData>();
//				List<ChartSeriesData> seriesDataListTwo = new ArrayList<ChartSeriesData>();
//				int index = 0;
//				for(Map.Entry<String, StackedColumnData> drillDownPojo: stackedColumn.getCoutriesWinLossData().entrySet()) {
//					ChartSeriesData  chartSeriesDataOne = new ChartSeriesData();
//					chartSeriesDataOne.setY(drillDownPojo.getValue().getTotalAmount());
//					chartSeriesDataOne.setName(drillDownPojo.getKey());
//					chartSeriesDataOne.setX(index);
//					HoverData hoverOne = new HoverData();
//					hoverOne.setRevenueWon(drillDownPojo.getValue().getWonRevenue());
//					hoverOne.setWonCount(drillDownPojo.getValue().getWonCount());
//					chartSeriesDataOne.setHover(hoverOne);
//
//					ChartSeriesData chartSeriesDataTwo = new ChartSeriesData();
//					chartSeriesDataTwo.setY(drillDownPojo.getValue().getQualifiedAmount());
//					chartSeriesDataTwo.setName(drillDownPojo.getKey());
//					chartSeriesDataTwo.setX(index);
//					HoverData hoverTwo = new HoverData();
//					hoverTwo.setRevenueLost(drillDownPojo.getValue().getLostRevenue());
//					hoverTwo.setLostCount(drillDownPojo.getValue().getLostCount());
//					chartSeriesDataTwo.setHover(hoverTwo);
//
//					seriesDataListOne.add(chartSeriesDataOne);
//					seriesDataListTwo.add(chartSeriesDataTwo);
//					index++;
//				}	
//				seriesOne.setData(seriesDataListOne);
//				seriesTwo.setData(seriesDataListTwo);
//				drillDownSeries.add(seriesOne);
//				drillDownSeries.add(seriesTwo);
//			}
//			seriesDrillDown.setSeries(drillDownSeries);
//		}
		return null;
	}
}
