package com.miri.web.auth.data;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.util.StringUtils;

import com.miri.data.jpa.domain.Authority;

public class UserProfile {

	private String userName;

	private String password;

	private String firstName;

	private String lastName;

	private Boolean active;

	private String profilePic;

	private String backGroundImg;

	private String designation;

	private Set<String> authorities = new HashSet<>();

	public UserProfile() {
		super();
	}

	public UserProfile(String userName, String firstName, String lastName, Boolean active,
			String backGroundImg, String designation) {
		this.userName = userName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.active = active;
		this.backGroundImg = backGroundImg;
		this.designation = designation;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the active
	 */
	public Boolean getActive() {
		return active;
	}

	/**
	 * @param active the active to set
	 */
	public void setActive(Boolean active) {
		this.active = active;
	}

	/**
	 * @return the profilePic
	 */
	public String getProfilePic() {
		return profilePic;
	}

	/**
	 * @param profilePic the profilePic to set
	 */
	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	/**
	 * @return the backGroundImg
	 */
	public String getBackGroundImg() {
		return backGroundImg;
	}

	/**
	 * @param backGroundImg the backGroundImg to set
	 */
	public void setBackGroundImg(String backGroundImg) {
		this.backGroundImg = backGroundImg;
	}

	/**
	 * @return the designation
	 */
	public String getDesignation() {
		return designation;
	}

	/**
	 * @param designation the designation to set
	 */
	public void setDesignation(String designation) {
		this.designation = designation;
	}

	/**
	 * @return the authorities
	 */
	public Set<String> getAuthorities() {
		return authorities;
	}

	/**
	 * @param authorities the authorities to set
	 */
	public void setAuthorities(Set<String> authorities) {
		this.authorities = authorities;
	}

	public void updateAuthorities(Set<Authority> authorities) {
		if (CollectionUtils.isEmpty(this.authorities)) {
			this.authorities = new TreeSet<>();
			for (Authority authority : authorities) {
				this.authorities.add(authority.getNameAsString());
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserProfile [userName=");
		builder.append(userName);
		builder.append(", password=");
		builder.append(!StringUtils.isEmpty(password));
		builder.append(", firstName=");
		builder.append(firstName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", active=");
		builder.append(active);
		builder.append(", profilePic=");
		builder.append(profilePic);
		builder.append(", backGroundImg=");
		builder.append(backGroundImg);
		builder.append(", designation=");
		builder.append(designation);
		builder.append("]");
		return builder.toString();
	}
}
