/*
 * See the NOTICE file distributed with this work for additional information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General
 * Public License as published by the Free Software Foundation; either version 2.1 of the License, or (at your
 * option) any later version.
 *
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
 * implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this software; if not,
 * write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA, or see
 * the FSF site: http://www.fsf.org.
 */
package com.miri.web.base;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.miri.web.base.charts.builders.AbstractChartBuilder;
import com.miri.web.base.charts.builders.BarChartBuilder;
import com.miri.web.base.charts.builders.BasicLineChartBuilder;
import com.miri.web.base.charts.builders.BubbleChartBuilder;
import com.miri.web.base.charts.builders.ColumnBasicChartBuilder;
import com.miri.web.base.charts.builders.ColumnDrillDownChartBuilder;
import com.miri.web.base.charts.builders.ColumnRotatedLabelsChartBuilder;
import com.miri.web.base.charts.builders.ColumnStackedChartBuilder;
import com.miri.web.base.charts.builders.ComboChartBuilder;
import com.miri.web.base.charts.builders.DualAxisLineAndColumnBuilder;
import com.miri.web.base.charts.builders.FunnelChartBuilder;
import com.miri.web.base.charts.builders.GeoChartBuilder;
import com.miri.web.base.charts.builders.LargeTreeMapBuilder;
import com.miri.web.base.charts.builders.LineLabelsChartBuilder;
import com.miri.web.base.charts.builders.MultipleAxesChartBuilder;
import com.miri.web.base.charts.builders.PieChartBuilder;
import com.miri.web.base.charts.builders.PolarWindRoseChartBuilder;
import com.miri.web.base.charts.builders.ScatterChartBuilder;
import com.miri.web.base.charts.builders.SplineIrregularChartBuilder;
import com.miri.web.base.charts.builders.SplineIrregularTimeChartBuilder;
import com.miri.web.base.charts.builders.StackedColumnBuilder;
import com.miri.web.base.charts.builders.WordCloudChartBuilder;

/**
 * ChartBuilderFactory: Provides chart builder instance based on the requested chart type.
 *
 * @author Chandra
 *
 */
@Component
@Scope("prototype")
public class ChartBuilderFactory {

    @Autowired
    private DualAxisLineAndColumnBuilder dualAxisLineAndColumnBuilder;

    @Autowired
    private BarChartBuilder barChartBuilder;

    @Autowired
    private ScatterChartBuilder scatterChartBuilder;
    
	@Autowired
	private GeoChartBuilder geoChartBuilder;
	
	@Autowired
	private SplineIrregularChartBuilder splineIrregularChartBuilder;
	
	@Autowired
	private MultipleAxesChartBuilder multiAxesChartBuilder;

	@Autowired
	private ColumnDrillDownChartBuilder barActionChartBuilder;
	
	@Autowired
	private LargeTreeMapBuilder largeTreeMapBuilder;

	@Autowired
	private ColumnRotatedLabelsChartBuilder columnRotatedLabelsChartBuilder;

	@Autowired
	private BasicLineChartBuilder basicLineChartBuilder;

	@Autowired
	private BubbleChartBuilder bubbleChartBuilder;
	
	@Autowired
	private FunnelChartBuilder funnelChartBuilder;
	
	@Autowired
	private LineLabelsChartBuilder lineLabelsChartBuilder;

	@Autowired
	private ColumnBasicChartBuilder columnBasicChartBuilder;
	
	@Autowired
	private PieChartBuilder pieChartBuilder;
	
	@Autowired
	private ComboChartBuilder comboChartBuilder;
	
	@Autowired
	private StackedColumnBuilder stackedColumnBuilder;

	@Autowired
	private ColumnStackedChartBuilder columnStackedChartBuilder;
	
	@Autowired
	private	SplineIrregularTimeChartBuilder splineIrregularTimeChartBuilder;
	
	@Autowired
	private WordCloudChartBuilder wordCloudChartBuilder;
	
	@Autowired
	private PolarWindRoseChartBuilder windRoseChartBuilder;
	
    /**
     * Returns chart builder instance based on given chart type.
     *
     * @param graphType
     * @return
     */
    public AbstractChartBuilder getChartBuilder(final ChartTypeEnum graphType) {
        AbstractChartBuilder chartBuilder = null;

        switch (graphType) {
        case BASIC_BAR:
            chartBuilder = barChartBuilder;
            break;
        case BASIC_LINE: 
        	chartBuilder = basicLineChartBuilder;
            break;
        case PIE:
        	chartBuilder = pieChartBuilder;
            break;
        case SPLINE:
            break;
        case WORD_CLOUD:
        	chartBuilder = wordCloudChartBuilder;
            break;
        case DUAL_AXIS_LINE_COLUMN:
            chartBuilder = dualAxisLineAndColumnBuilder;
            break;
        case SCATTER:
            chartBuilder = scatterChartBuilder;
            break;
        case GEO:
        	chartBuilder = geoChartBuilder;
        	break;
        case MULTI_AXES:
        	chartBuilder=multiAxesChartBuilder;
        	break;
        case COLUMN_DRILL_DOWN:
        	chartBuilder = barActionChartBuilder;
        	break;
        case LARGE_OPEN_OPP_BARCHART:
        	chartBuilder = columnRotatedLabelsChartBuilder;
        	break;
        case SPLINE_IRREGULAR:
        	chartBuilder = splineIrregularChartBuilder;
        	break;
        case FUNNEL_CHART:
        	chartBuilder = funnelChartBuilder;
        	break;
        case LINE_LABELS_CHART:
        	chartBuilder = lineLabelsChartBuilder;
        	break;
        case BUBBLE_CHART:
        	chartBuilder = bubbleChartBuilder;
        	break;
        case COLUMN_BASIC:
        	chartBuilder = columnBasicChartBuilder;
        	break;
        case COMBO:
        	chartBuilder = comboChartBuilder;
        	break;
        case STACKED_COLUMN_CHART:
        	chartBuilder = stackedColumnBuilder;
        	break;
        case COLUMN_STACKED:
        	chartBuilder = columnStackedChartBuilder;
        	break;
        case LARGE_TREE_MAP:
        	chartBuilder = largeTreeMapBuilder;
        	break;
        case SPLINE_IRREGULAR_TIME: 
        	chartBuilder = splineIrregularTimeChartBuilder;
        	break;
        case POLAR_WIND_ROSE: 
        	chartBuilder = windRoseChartBuilder;
        	break;
        }

        return chartBuilder;
    }
}