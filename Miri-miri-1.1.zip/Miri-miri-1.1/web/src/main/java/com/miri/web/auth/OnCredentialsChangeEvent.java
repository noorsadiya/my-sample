package com.miri.web.auth;

import org.springframework.context.ApplicationEvent;

public class OnCredentialsChangeEvent extends ApplicationEvent {

	private static final long serialVersionUID = 1L;

	private String userName;

	public OnCredentialsChangeEvent(String userName) {
		super(userName);
		this.userName = userName;
	}

	public String getUserName() {
		return userName;
	}

}
