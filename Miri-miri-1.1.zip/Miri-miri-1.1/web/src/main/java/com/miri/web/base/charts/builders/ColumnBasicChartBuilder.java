package com.miri.web.base.charts.builders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.miri.search.data.ColumnBasicData;
import com.miri.search.data.SalesPersonRevenueData;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.web.base.Chart;
import com.miri.web.base.IChart;
import com.miri.web.base.charts.component.ChartComponent;
import com.miri.web.base.charts.component.ChartSeriesData;
import com.miri.web.base.charts.component.HoverData;
import com.miri.web.base.charts.component.MetricResponse;
import com.miri.web.base.charts.component.Series;
import com.miri.web.constants.WebConstants;

/**
 * Column Basic Chart Builder for Visualize - Understand - Top Sales Person By Revenue Achieved
 * @author rammoole
 *
 */
@Component
@Scope("prototype")
public class ColumnBasicChartBuilder extends GenericChartBuilder {

	private static final Logger LOG = LogManager.getLogger(ColumnBasicChartBuilder.class);

	private ColumnBasicChart columnBasicChart;

	@Override
	public IChart buildChart(MetricResponse metricResponse) {
		LOG.debug("Building Column Basic Chart JSON");
		columnBasicChart = new ColumnBasicChart();
		columnBasicChart.setChartMetadata(populateMetadata(metricResponse));
		columnBasicChart.setyAxis(populateYAxisData(metricResponse));
		columnBasicChart.setxAxis(populateXAxisData(metricResponse));
		columnBasicChart.setRanges(populateDollarRanges(metricResponse));
		columnBasicChart.setSeries(populateSeries(metricResponse));
		return columnBasicChart;
	}

	public static class ColumnBasicChart extends Chart implements Serializable {

		/**
		 * Generated Serial Version UID
		 */
		private static final long serialVersionUID = 4887062731163276026L;
		
	}

	@Override
	public ChartComponent populateMetadata(MetricResponse metricResponse) {
		chartMetadata.setTitle(metricResponse.getItems().get(WebConstants.GRAPH_TITLE).toString());
		chartMetadata.setSubtitle(metricResponse.getItems().get(WebConstants.SUBTITLE).toString());
		chartMetadata.setGraphType(metricResponse.getItems().get(WebConstants.GRAPH_TYPE).toString());
		return chartMetadata;
	}

	@Override
	public ChartComponent populateXAxisData(MetricResponse metricResponse) {
		xaxisData.setLabel(metricResponse.getItems().get(WebConstants.X_AXIS_LABEL).toString());
		xaxisData.setData(metricResponse.getItems().get(WebConstants.X_AXIS_DATA));
		return xaxisData;
	}

	@Override
	public ChartComponent populateYAxisData(MetricResponse metricResponse) {
		yaxisData.setLabel(metricResponse.getItems().get(WebConstants.Y_AXIS_LABEL).toString());
		return yaxisData;
	}

	@Override
	public ChartComponent populateLegends(MetricResponse metricResponse) {
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Series> populateSeries(MetricResponse metricResponse) {
		List<ColumnBasicData> metricData = (List<ColumnBasicData>) metricResponse.getItems().get(WebConstants.METRIC_DATA);
		List<String> xAxisValues = new ArrayList<>((Collection<String>) metricResponse.getItems().get(WebConstants.X_AXIS_DATA));
		List<Series> seriesList = new ArrayList<>();
		Series series;
		List<ChartSeriesData> seriesData;
		ChartSeriesData data;
		boolean isAnySeriesExists = false;
		for(ColumnBasicData columnBasicData: metricData) {
			series = new Series();
			seriesData = new ArrayList<>();
			double value = 0;
			for(SalesPersonRevenueData salesPersonRevenueData: columnBasicData.getSalesPersonRevenue()) {
				data = new ChartSeriesData();
				data.setX(xAxisValues.indexOf(salesPersonRevenueData.getxAxisLabel()));
				if(null !=  salesPersonRevenueData.getxAxisParam()){
					data.setY(MiriSearchUtils.removeDecimalPoint((double) salesPersonRevenueData.getxAxisParam()));
					value += (double) salesPersonRevenueData.getxAxisParam();
				}
				
				// Setting Hover data
				HoverData hover = new HoverData();
				//hover.setSalesPersonName(salesPersonRevenueData.getSalesPerson());
				hover.setRevenueAmount(salesPersonRevenueData.getRevenue());
				hover.setWinRate(salesPersonRevenueData.getWinRate());
				hover.setLostRate(salesPersonRevenueData.getLostRate());
				hover.setRevenueWon(salesPersonRevenueData.getWonAmount());
				hover.setCampaignName(salesPersonRevenueData.getCampaignName());
				hover.setRevenueType(salesPersonRevenueData.getOpportunityType());
				hover.setIndustryName(salesPersonRevenueData.getIndustryName());
				hover.setCustomerName(salesPersonRevenueData.getCustomerName());
				hover.setSalesPersonName(salesPersonRevenueData.getSalesPersonName());
				hover.setProductName(salesPersonRevenueData.getProductName());
				hover.setCountry(salesPersonRevenueData.getCountry());
				hover.setRevenueLost(salesPersonRevenueData.getLostAmount());
				hover.setDealsClosed(salesPersonRevenueData.getNoOfDealsClosed());
				hover.setDealsLost(salesPersonRevenueData.getNoOfDealsLost());
				hover.setAverageDealSize(salesPersonRevenueData.getAvgDealSize());
				hover.setAverageSellPrice(salesPersonRevenueData.getAvgSellPrice());
				data.setHover(hover);
				seriesData.add(data);
			}
			series.setData(seriesData);
			series.setName(columnBasicData.getName());
			seriesList.add(series);
			if(value > 0){
				isAnySeriesExists = true;
			}
		}
		if(!isAnySeriesExists){
			seriesList = new ArrayList<>();
		}
		
		return seriesList;
	}

	@Override
	public ChartComponent populateHover(MetricResponse metricResponse) {
		return null;
	}

}
