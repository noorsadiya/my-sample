
package com.miri.web.base;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Chandra
 *
 */
public enum DrillDownType {

	//Top-level Dill downs
    DEALS_CLOSED("deals-closed"), COMPETITIVE_WIN_RATE("competitive-win-rate"),OVERALL("overall"),
    SALES_GENERATED("sales-generated"), MARKETING_INFLUENCED("marketing-influenced"),
    SALES_CAMPAIGN("sales-campaign"), MARKETING_CAMPAIGN("marketing-campaign"),
    
    LEAD_TO_OPPORTUNITY_CONVERSION("lead-to-opportunity-conversion"),
    OPPORTUNITY_TO_DEAL_CONVERSION("opportunity-to-deal-conversion"),// OverAll Filter DrillDowns
   
    //DrillDowns
    PROBABILITY("probability-close"),STAGE("oppurtunity-stage"),

    LARGE_OPEN_OPPORTUNITIES_MARKET("large-open-opp-marketing"), LARGE_OPEN_OPPORTUNITIES_Sales("large-open-opp-sales"),
    
    // Overall Filter DrillDowns
    FIRST_QUARTER("firstQuarter"),SECOND_QUARTER("secondQuarter"),THIRD_QUARTER("thirdQuarter"),
    FOURTH_QUARTER("fourthQuarter"),ONEYEARPLUS("onePlusYears"), CAMPAIGN_HIERARCHY("campaign-hierarchy"),
    PARENT_CAMPAIGN("parentcampaign"),AVERAGE_COST_TO_LEAD("average-cost-lead"),AVERAGE_COST_TO_OPPORTUNITY("average-cost-opportunity"),
    AVERAGE_COST_TO_DEAL("average-cost-deal"),AVERAGE_COST("average-cost"),
   
    //DrillDowns
    PRODUCT("product"), CAMPAIGN("campaign"), LEAD_SOURCE("lead-source"), AVERAGE_SELL_PRICE("average-sell-price"),
    SALES_PERSON("sales-person"), COMPETITOR("competitor"), AVERAGE_DEAL_SIZE("average-deal-size"),
    NO_OF_DEALS_CLOSED("no-of-deals-closed"), NEW_OR_EXISTING("new-or-existing"), CUSTOMERS("customers"), 
    REGION_OR_COUNTRY("region-or-country"), INDUSTRY("industry"), DEFAULT("default"),
    BY_OPPORTUNITY_STAGE("opportunity-stage"), BY_PROBABILITY_TO_CLOSE("probability-to-close"),PARTNER("partner"),PERSON("person"),
    
	//Inner Level DrillDowns
	CAMPAIGN_INDUSTRIES("campaignIndustries"), PRODUCT_INDUSTRIES("productIndustries"),
	SALES_PERSON_INDUSTRIES("salesPersonIndustries"),COMPETITOR_INDUSTRIES("competitorIndustries"),INDUSTRIES("industries"),REGION("region"),SCHEDULER("scheduler"),
	LEAD_TO_DEAL_CONVERSION("lead-to-deal-conversion"), HIERARCHY("hierarchy"), COMBO("combo");
	
	
	private String value;
    

    private static Map<String, DrillDownType> drillDownMapper = new HashMap<>();

    static {
        for (final DrillDownType drillDownEnum : DrillDownType.values()) {
            drillDownMapper.put(drillDownEnum.getValue(), drillDownEnum);
        }
        drillDownMapper = Collections.unmodifiableMap(drillDownMapper);
    }

    public static Map<String, DrillDownType> getDrillDownMapper() {
        return drillDownMapper;
    }

    private DrillDownType(final String text) {
        this.value = text;
    }

    public String getValue() {
        return value;
    }

    /**
     * Returns String value corresponding to enum.
     *
     * @param text
     * @return
     */
    public static DrillDownType fromString(final String text) {
        if (text != null) {
            for (final DrillDownType drillDownEnum : DrillDownType.values()) {
                if (text.equalsIgnoreCase(drillDownEnum.getValue())) {
                    return drillDownEnum;
                }
            }
        }
        return null;
    }
}

