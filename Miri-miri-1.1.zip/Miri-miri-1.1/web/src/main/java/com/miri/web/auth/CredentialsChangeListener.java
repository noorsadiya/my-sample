package com.miri.web.auth;

import java.util.List;

import javax.inject.Inject;

import org.springframework.context.ApplicationListener;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.miri.data.jpa.domain.UserLoginToken;
import com.miri.data.jpa.repository.UserLoginTokenRepository;

@Component
public class CredentialsChangeListener implements ApplicationListener<OnCredentialsChangeEvent> {

	@Inject
	private UserLoginTokenRepository authenticationTokenRepository;

	@Override
	public void onApplicationEvent(OnCredentialsChangeEvent event) {
		System.out.println("Event class : " + event.getClass() + " timestamp : " + event.getTimestamp());
		String userName = event.getUserName();
		deleteAllAuthenticationTokens(userName);

	}

	private void deleteAllAuthenticationTokens(String userName) {
		List<UserLoginToken> tokens = authenticationTokenRepository.findAllByUserName(userName);
		authenticationTokenRepository.deleteInBatch(tokens);
		SecurityContextHolder.getContext().setAuthentication(null);
	}
}
