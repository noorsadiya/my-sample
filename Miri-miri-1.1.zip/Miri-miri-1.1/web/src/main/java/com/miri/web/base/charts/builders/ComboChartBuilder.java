package com.miri.web.base.charts.builders;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.miri.search.data.CampaignRevenueData;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.web.base.Chart;
import com.miri.web.base.IChart;
import com.miri.web.base.charts.builders.ComboChartBuilder.ComboChart.SeriesObject;
import com.miri.web.base.charts.component.ChartComponent;
import com.miri.web.base.charts.component.ChartSeriesData;
import com.miri.web.base.charts.component.HoverData;
import com.miri.web.base.charts.component.MetricResponse;
import com.miri.web.base.charts.component.Series;
import com.miri.web.base.charts.component.SeriesData;
import com.miri.web.constants.WebConstants;

/**
 * Combo Chart Builder for Marketing Spend ROI Graph
 * @author rammoole
 *
 */
@Component
@Scope("prototype")
public class ComboChartBuilder extends GenericChartBuilder {

	private static final Logger LOG = LogManager.getLogger(ComboChartBuilder.class);

	ComboChart comboChart;

	/**
	 * Chart Builder Method using metric response
	 */
	@Override
	public IChart buildChart(MetricResponse metricResponse) {
		comboChart = new ComboChart();
		comboChart.setSeries(populateSeriesData(metricResponse));
		comboChart.setxAxis(populateXAxisData(metricResponse));
		comboChart.setyAxis(populateYAxisData(metricResponse));
		comboChart.setChartMetadata(populateMetadata(metricResponse));
		comboChart.setRanges(populateDollarRanges(metricResponse));
		comboChart.setParentData(super.populateCampaignHierarchy(metricResponse));
		comboChart.setyTDTarget(populateYTDTarget(metricResponse));
		return comboChart;
	}

	/**
	 * Populate Series data to chart
	 * @author rammoole
	 * @param metricResponse
	 */
	@Override
	public List<Series> populateSeries(MetricResponse metricResponse) {
		return null;
	}

	@SuppressWarnings("unchecked")
	private List<Series> populateSeriesData(MetricResponse metricResponse) {
		LOG.info("Populating Series data");
		
		DecimalFormat df = new DecimalFormat("#.00");
		
		Map<String, Object> comboMetricResponse = metricResponse.getItems();

		List<CampaignRevenueData> comboMetric = (List<CampaignRevenueData>) comboMetricResponse.get(WebConstants.METRIC_DATA);

		List<String> xaxisCategories = (ArrayList<String>) comboMetricResponse.get(WebConstants.X_AXIS_DATA);

		Series columnOne = new Series();
		columnOne.setName(comboMetricResponse.get(WebConstants.COLUMN_NAME_ONE).toString());

		Series columnTwo = new Series();
		columnTwo.setName(comboMetricResponse.get(WebConstants.COLUMN_NAME_TWO).toString());

		List<ChartSeriesData> dataOne = new ArrayList<>();
		List<ChartSeriesData> dataTwo = new ArrayList<>();

		List<ChartSeriesData> dataPie = new ArrayList<>();
		List<ChartSeriesData> dataSpline = new ArrayList<>();
		
		List<Object> column = new ArrayList<>();
		
		double roi = 0;
		double columnOneTotal = 0;
		double columnTwoTotal = 0;
		ChartSeriesData chartSeriesData;
		HoverData hover;
		double revenueValue = 0;
		double campaignSpend = 0;
		double roiValue = 0;
		boolean isAnySeriesExists = false;
		for(int i = 0; i < xaxisCategories.size(); i++) {
			ChartSeriesData chartSeriesDataTwo = new ChartSeriesData();
			hover = new HoverData();
			chartSeriesDataTwo.setX(i);
			if(null != comboMetric.get(i).getRevenueAmount()){
				chartSeriesDataTwo.setY(MiriSearchUtils.removeDecimalPoint(comboMetric.get(i).getRevenueAmount()));
				hover.setRevenueAmount(MiriSearchUtils.removeDecimalPoint(comboMetric.get(i).getRevenueAmount()));
				revenueValue += comboMetric.get(i).getRevenueAmount();
			}
			
			
			
			if(null != comboMetric.get(i).getAverageSellPrice()){
				hover.setAverageSellPrice(MiriSearchUtils.removeDecimalPoint(comboMetric.get(i).getAverageSellPrice())); // Average Sell Price

			}
			hover.setDealsClosed(comboMetric.get(i).getNoOfDeals()); // No Of Deals closed
			if(null != comboMetric.get(i).getAverageDealSize()){
				hover.setAverageDealSize(MiriSearchUtils.removeDecimalPoint(comboMetric.get(i).getAverageDealSize())); // average deal size

			}
			
			chartSeriesDataTwo.setHover(hover);
			
			ChartSeriesData chartSeriesDataOne = new ChartSeriesData();
			hover = new HoverData();

			chartSeriesDataOne.setX(i);
			if(null != comboMetric.get(i).getCampaignSpend()){
				chartSeriesDataOne.setY(MiriSearchUtils.removeDecimalPoint(comboMetric.get(i).getCampaignSpend()));
				hover.setCampaignSpend(MiriSearchUtils.removeDecimalPoint(comboMetric.get(i).getCampaignSpend()));
				campaignSpend += comboMetric.get(i).getCampaignSpend();
			}
			
			hover.setCampaignName(comboMetric.get(i).getCampaignName());
			chartSeriesDataOne.setHover(hover);
			
			dataOne.add(chartSeriesDataOne);
			dataTwo.add(chartSeriesDataTwo);
			
			// Creating ROI Spline data
			if(comboMetric.get(i).getRevenueAmount() != null  && comboMetric.get(i).getCampaignSpend() != null) {
				if(comboMetric.get(i).getCampaignSpend() != 0) {
					roi = ((comboMetric.get(i).getRevenueAmount() - comboMetric.get(i).getCampaignSpend()) / comboMetric.get(i).getCampaignSpend()) * 100;
				} else {
					roi = 0;
				}
				chartSeriesData = new ChartSeriesData();
				chartSeriesData.setX(i);
				chartSeriesData.setY(Double.isNaN(roi) ? 0 : Double.valueOf(df.format(roi)));
				roiValue += Double.isNaN(roi) ? 0 : Double.valueOf(df.format(roi)); 
				hover = new HoverData();
				hover.setROI(Double.isNaN(roi) ? 0 : Double.valueOf(df.format(roi)));
				chartSeriesData.setHover(hover);
				dataSpline.add(chartSeriesData);
				
				columnOneTotal += comboMetric.get(i).getCampaignSpend();
				columnTwoTotal += comboMetric.get(i).getRevenueAmount();
			}
		}
		
		double pieValue = 0;
		chartSeriesData = new ChartSeriesData();
		chartSeriesData.setY(MiriSearchUtils.removeDecimalPoint(columnOneTotal));
		pieValue += columnOneTotal;
		chartSeriesData.setName(WebConstants.TOTAL + " " + columnOne.getName());
		hover = new HoverData();
		hover.setTotalAmount(MiriSearchUtils.removeDecimalPoint(columnOneTotal));
		chartSeriesData.setHover(hover);
		dataPie.add(chartSeriesData);

		chartSeriesData = new ChartSeriesData();
		chartSeriesData.setY(MiriSearchUtils.removeDecimalPoint(columnTwoTotal));
		pieValue += columnTwoTotal;
		chartSeriesData.setName(WebConstants.TOTAL + " " + columnTwo.getName());
		hover = new HoverData();
		hover.setTotalAmount(MiriSearchUtils.removeDecimalPoint(columnTwoTotal));
		chartSeriesData.setHover(hover);
		dataPie.add(chartSeriesData);

		columnOne.setData(dataOne);
		columnTwo.setData(dataTwo);

		column.add(columnOne);
		column.add(columnTwo);
		
		SeriesData splineData = new SeriesData();
		splineData.setData(dataSpline);
		splineData.setName(comboMetricResponse.get(WebConstants.SPLINE_NAME).toString());
		
		ChartComponent pieData = new ChartComponent();
		pieData.setData(dataPie);
		
		SeriesObject seriesObject = new SeriesObject();
		seriesObject.setColumn(column);
		seriesObject.setSpline(splineData);
		seriesObject.setPie(pieData);
		
		List<Series> seriesList = new ArrayList<Series>();
		seriesList.add(seriesObject);
		if(campaignSpend > 0 || revenueValue > 0 || roiValue > 0 || pieValue > 0){
			isAnySeriesExists = true;
		}
		if(!isAnySeriesExists){
			seriesList = new ArrayList<>();
		}
		return seriesList;
	}

	/**
	 * Fill Chart Series Data from the metric response
	 * @param index
	 * @param columnData
	 * @param hoverDataOne
	 * @param hoverDataTwo
	 * @param hoverDataThree
	 * @return
	 */
	public ChartSeriesData fillChartSeriesData(final int index, final Map<Integer, Double> columnData, final Map<Integer, Double> hoverDataOne, final Map<Integer, Long> hoverDataTwo, Map<Integer, Double> hoverDataThree) {
		ChartSeriesData chartSeriesData = new ChartSeriesData();
		
		DecimalFormat df = new DecimalFormat("#.00");
		
		chartSeriesData.setX(index);
		chartSeriesData.setY(columnData.get(index));
		HoverData hover = new HoverData();
		if(hoverDataOne != null) {
			hover.setAverageSellPrice(Double.valueOf(df.format(hoverDataOne.get(index)))); // Average Sell Price
		}
		if(hoverDataTwo != null) {
			hover.setDealsClosed(hoverDataTwo.get(index)); // No Of Deals closed
		}
		if(hoverDataThree != null) {
			hover.setAverageDealSize(Double.valueOf(df.format(hoverDataThree.get(index)))); // average deal size
		}
		chartSeriesData.setHover(hover);
		return chartSeriesData;
	}

	/**
	 * ComboChart 
	 * @author rammoole
	 *
	 */
	@Component
	public static class ComboChart extends Chart implements Serializable {
		/**
		 * Generated Serial Version UID
		 */
		private static final long serialVersionUID = 1L;

		public static class SeriesObject extends Series {
			/**
			 * Generated Serial Version UID
			 */
			private static final long serialVersionUID = 1L;
			private List<Object> column;
			private Object spline;
			private Object pie;
			
			/**
			 * @return the column
			 */
			public List<Object> getColumn() {
				return column;
			}
			/**
			 * @param column the column to set
			 */
			public void setColumn(List<Object> column) {
				this.column = column;
			}
			/**
			 * @return the spline
			 */
			public Object getSpline() {
				return spline;
			}
			/**
			 * @param spline the spline to set
			 */
			public void setSpline(Object spline) {
				this.spline = spline;
			}
			/**
			 * @return the pie
			 */
			public Object getPie() {
				return pie;
			}
			/**
			 * @param pie the pie to set
			 */
			public void setPie(Object pie) {
				this.pie = pie;
			}
		}

		private ChartComponent parentData;
		
		public void setParentData(ChartComponent parentData) {
			this.parentData = parentData;
		}
		
		public ChartComponent getParentData() {
			return parentData;
		
		}
		
		public static class ParentData{
			private String name;
			private String value;
			
			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			public String getValue() {
				return value;
			}
			public void setValue(String value) {
				this.value = value;
			}
		}

	}

	@Override
	public ChartComponent populateMetadata(MetricResponse metricResponse) {
		chartMetadata.setTitle(metricResponse.getItems().get(WebConstants.GRAPH_TITLE).toString());
		chartMetadata.setGraphType(metricResponse.getItems().get(WebConstants.GRAPH_TYPE).toString());
		return chartMetadata;
	}

	@Override
	public ChartComponent populateXAxisData(MetricResponse metricResponse) {
		xaxisData.setData(metricResponse.getItems().get(WebConstants.X_AXIS_DATA));
		xaxisData.setLabel(metricResponse.getItems().get(WebConstants.X_AXIS_LABEL).toString());
		return xaxisData;
	}

	@Override
	public ChartComponent populateYAxisData(MetricResponse metricResponse) {
		yaxisData.setLabel(metricResponse.getItems().get(WebConstants.Y_AXIS_LABEL).toString());
		return yaxisData;
	}

	@Override
	public ChartComponent populateLegends(MetricResponse metricResponse) {
		return null;
	}

	@Override
	public ChartComponent populateHover(MetricResponse metricResponse) {
		return null;
	}

}