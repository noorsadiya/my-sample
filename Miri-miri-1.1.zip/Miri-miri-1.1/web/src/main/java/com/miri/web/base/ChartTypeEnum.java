/**
 * 
 */
package com.miri.web.base;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * @author chavanka
 *
 */
public enum ChartTypeEnum {

	BASIC_BAR("basicBar"), PIE("pie"), SPLINE("spline"), WORD_CLOUD("wordCloud"), BASIC_LINE("basicLine"), 

	DUAL_AXIS_LINE_COLUMN("dualAxisLineAndColumn"), SCATTER("scatter"), GEO("geo"),MULTI_AXES("multiAxes"),
	
	COLUMN_DRILL_DOWN("columnDrilldown"),SPLINE_IRREGULAR("splineIrregular"),

	LARGE_OPEN_OPP_BARCHART("columnRotated"),FUNNEL_CHART("funnelChart"),LINE_LABELS_CHART("lineLabels"),

	COLUMN_BASIC("columnBasic"), COMBO("combo"), COLUMN_STACKED("columnStacked"), STACKED_COLUMN_CHART("stackedChart"),

	BUBBLE_CHART("bubbleChart"),LARGE_TREE_MAP("largeTreeMap"), SPLINE_IRREGULAR_TIME("splineIrregularTime"),POLAR_WIND_ROSE("polar-wind-rose");


	private String text;

	private static Map<String, ChartTypeEnum> chartMapper = new HashMap<>();

	static {
		for (ChartTypeEnum chartEnum : ChartTypeEnum.values()) {
			chartMapper.put(chartEnum.getText(), chartEnum);
		}
		chartMapper = Collections.unmodifiableMap(chartMapper);
	}
	
	public static Map<String, ChartTypeEnum> getChartMapper() {
		return chartMapper;
	}

	private ChartTypeEnum(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}

	/**
	 * Returns String value corresponding to enum.
	 * 
	 * @param text
	 * @return
	 */
	public static ChartTypeEnum fromString(String text) {
		if (text != null) {
			for (ChartTypeEnum graphType : ChartTypeEnum.values()) {
				if (text.equalsIgnoreCase(graphType.getText())) {
					return graphType;
				}
			}
		}
		return null;
	}

}
