/**
 * 
 */
package com.miri.web.base;

import java.io.Serializable;
import java.util.List;

/**
 * Holds request params.
 * 
 * @author Chandra
 *
 */
public class MiriRequest implements Serializable {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 5546803164405550163L;

	private String category;

    private String drildown;

    private String subDrillDown;

    private String section;

    private String metric;

    private String chartType;
    
    private boolean gauge;
    
    private String timeFrame;
    
    private List<String> campaignIds;
    
    private String graphBase64;
    
    private String graphName;
    
    // Default constructor
    public MiriRequest() {
    	
    }
    
    //Parameterized Constructor
    public MiriRequest(String category, String section, String metric, String drildown, String chartType,
    		String subDrillDown, String timeFrame, List<String> campaignIds) {
    	super();
		this.category = category;
		this.drildown = drildown;
		this.subDrillDown = subDrillDown;
		this.section = section;
		this.metric = metric;
		this.chartType = chartType;
		this.timeFrame = timeFrame;
		this.campaignIds = campaignIds;
	}
    
    public String getCategory() {
        return category;
    }

	public void setCategory(String category) {
        this.category = category;
    }

    public String getDrildown() {
        return drildown;
    }

    public void setDrildown(String drildown) {
        this.drildown = drildown;
    }

    public String getSubDrillDown() {
        return subDrillDown;
    }

    public void setSubDrillDown(String subDrillDown) {
        this.subDrillDown = subDrillDown;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getMetric() {
        return metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public String getChartType() {
        return chartType;
    }

    public void setChartType(String chartType) {
        this.chartType = chartType;
    }

	public boolean getGauge() {
		return gauge;
	}

	public void setGauge(boolean gauge) {
		this.gauge = gauge;
	}

	public String getTimeFrame() {
		return timeFrame;
	}

	public void setTimeFrame(String timeFrame) {
		this.timeFrame = timeFrame;
	}

	public List<String> getCampaignIds() {
		return campaignIds;
	}

	public void setCampaignIds(List<String> campaignIds) {
		this.campaignIds = campaignIds;
	}

	public String getGraphBase64() {
		return graphBase64;
	}

	public void setGraphBase64(String graphBase64) {
		this.graphBase64 = graphBase64;
	}

	public String getGraphName() {
		return graphName;
	}

	public void setGraphName(String graphName) {
		this.graphName = graphName;
	}

}
