/**
 * 
 */
package com.miri.web.base;

import java.io.Serializable;

import org.springframework.stereotype.Component;

/**
 * Holds filters such as Campaigns, Products, Customers, Sales Person, Competitors, Regions & Industries
 * 
 * @author Chandra
 *
 */
@Component
public class ExploreFilter implements Serializable {
	private static final long serialVersionUID = 4446424720368247019L;

	private int id;

	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
