package com.miri.web.base;

public class MiriRequestBody {
	
	private String subDilldown;
	
	private String chartType;
	
	private String timeFrame;
	
	private String moreData;
	
	
	
	

}
