package com.miri.web.auth;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;
import org.hibernate.exception.JDBCConnectionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.miri.data.jpa.domain.CrmInstance;
import com.miri.data.jpa.domain.CrmInstanceSalesStage;
import com.miri.data.jpa.domain.Currency;
import com.miri.data.jpa.domain.LicenseAccessFlow;
import com.miri.data.jpa.domain.User;
import com.miri.data.jpa.domain.UserLoginToken;
import com.miri.data.jpa.service.ManualInputService;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.utils.MiriDateUtils;
import com.miri.web.auth.data.ApplicationInfo;
import com.miri.web.auth.data.UserProfile;
import com.miri.web.auth.response.AuthResponse;
import com.miri.web.base.ResponseStatus;
import com.miri.web.common.services.AuthenticationService;
import com.miri.web.common.services.UserService;
import com.miri.web.constants.ControllerConstants;
import com.miri.web.interceptors.ErrorCodeContainer.ErrorCodeEnum;
import com.miri.web.license.LicenseValidationService;

@RestController
@RequestMapping("/api")
public class UserXAuthTokenController {

	private static final Logger LOG = Logger.getLogger(UserXAuthTokenController.class);

	@Autowired
	private AuthenticationService authenticationService;

	@Autowired
	private UserService userService;

	@Autowired
	CurrencyUtil currencyUtil;

	@Autowired
	LicenseValidationService licenseValidationService;
	
	@Autowired
	private ManualInputService manualInputDbService;

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public AuthResponse authorize(final HttpServletResponse response,
			@RequestBody(required = true) final Map<String, String> credentialsMap) {
		String username = credentialsMap.get("username");
		String password = credentialsMap.get("password");
		
		AuthResponse authResponse = null;
		ResponseStatus responseStatus = null;
		try {
			UserLoginToken token = authenticationService.authenticate(username, password);
			ApplicationInfo applicationInfo = getApplicationInfo();
			UserProfile profileDetails = userService.toUserProfile(token.getUser());
			String currencySymbol = currencyUtil.getCurrencySymbol();
			authResponse = new AuthResponse(token.getId(), applicationInfo, profileDetails, currencySymbol);
			authResponse.setAuthenticated(true);
			authResponse.setSuccess(true);
			responseStatus = new ResponseStatus(HttpStatus.OK.toString(), "", AuthResponse.class.getName());
			authResponse.setResponseStatus(responseStatus);

			LicenseAccessFlow accessFlow = licenseValidationService.getCurrentActiveLicense();
			try {
				byte[] parseBase64Binary = DatatypeConverter.parseBase64Binary(accessFlow.getEndDate());
				String endDateStr = new String(parseBase64Binary, "UTF-8");
				authResponse.setLicenseExpiryDate(endDateStr);
				Calendar endDateCal = MiriDateUtils.parseStrDateToCalendar(endDateStr,
						MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
				Calendar currentDate = Calendar.getInstance();
				long dateDiff = endDateCal.getTimeInMillis() - currentDate.getTimeInMillis();
				int days = MiriSearchUtils.getDaysfromMillis(dateDiff);
				authResponse.setNoOfDaysToExpireKey(days);
				authResponse.setTrail(licenseValidationService.isTrailProduct());
			} catch (Exception ex) {
				LOG.error("Exception while fetching license end date.");
			}
		} catch (BadCredentialsException bce) {
			LOG.error("Exception occurred: " + bce.getMessage());
			authResponse = new AuthResponse(null);
			authResponse.setAuthenticated(false);
			authResponse.setSuccess(false);
			responseStatus = new ResponseStatus(HttpStatus.BAD_REQUEST.toString(), bce.getMessage(),
					AuthResponse.class.getName());
			authResponse.setResponseStatus(responseStatus);
		} catch (JDBCConnectionException | PersistenceException | CannotCreateTransactionException dbex) {
			LOG.error("DB Connect Exception occurred: " + dbex.getMessage());
			authResponse = new AuthResponse(null);
			authResponse.setAuthenticated(false);
			authResponse.setSuccess(false);
			responseStatus = new ResponseStatus(ErrorCodeEnum.MIRI_305.toString(),
					ErrorCodeEnum.MIRI_305.getErrorMessage(), AuthResponse.class.getName());
			authResponse.setResponseStatus(responseStatus);
		} catch (Exception ex) {
			LOG.error(" Exception occurred: " + ex.getMessage());
			authResponse = new AuthResponse(null);
			authResponse.setAuthenticated(false);
			authResponse.setSuccess(false);
			responseStatus = new ResponseStatus(HttpStatus.BAD_REQUEST.toString(), ex.getMessage(),
					AuthResponse.class.getName());
			authResponse.setResponseStatus(responseStatus);
		}
		return authResponse;
	}

	private ApplicationInfo getApplicationInfo() {
		ApplicationInfo applicationInfo = new ApplicationInfo();
		String completedSetupStage = null;
		try {
			completedSetupStage = getCompletedSetupStage();
			applicationInfo.setCompletedStage(completedSetupStage);
			Currency currency = manualInputDbService.getAccountCurrency();
			if (currency != null) {
				applicationInfo.setCurrencyCode(currency.getCode());
			}

			// Get sale stage verification information
			CrmInstance crmInstance = manualInputDbService.getCrmInstanceByName(ControllerConstants.CSV);
			if (crmInstance != null) {
				List<CrmInstanceSalesStage> allExistingCrmInstanceSalesStageList = manualInputDbService
						.getSalesStageMapping(crmInstance.getWebServiceVendor().getVendorName(),
								crmInstance.getWebServiceVendor().getInstanceName());
				// List<CrmInstanceSalesStage> nullCrmInstanceSaleStageList =
				// manualInputDbService.getSalesStageMappingAndNullLocalStage(crmInstance.getWebServiceVendor().getVendorName(),
				// crmInstance.getWebServiceVendor().getInstanceName());

				// List<String> existingSaleStageList =
				// getExistingSaleStagesListString(allExistingCrmInstanceSalesStageList);
				Boolean isNotNull = false;
				for (CrmInstanceSalesStage crmInstanceSalesStage : allExistingCrmInstanceSalesStageList) {
					if (crmInstanceSalesStage.getLocalCrmSalesStage() != null) {
						isNotNull = true;
					}
				}

				if (!isNotNull) {
					applicationInfo.setSaleStageLevel(ControllerConstants.WARN);
				} else {
					applicationInfo.setSaleStageLevel(ControllerConstants.INFO);
				}
				applicationInfo.setIsSaleStagesVerified(isNotNull);
			}
		} catch (Exception e) {
			LOG.debug(e.getMessage(), e);
			LOG.error("Error occurred while retrieving completedSetupStage." + e.getMessage());
		}

		return applicationInfo;
	}

	/**
	 * @param allExistingCrmInstanceSalesStageList
	 */
	/*
	 * private List<String>
	 * getExistingSaleStagesListString(List<CrmInstanceSalesStage>
	 * allExistingCrmInstanceSalesStageList) { List<String> existingSaleStages =
	 * new ArrayList<>(); for (CrmInstanceSalesStage
	 * existingcrmInstanceSalesStage : allExistingCrmInstanceSalesStageList) {
	 * existingSaleStages.add(existingcrmInstanceSalesStage.getSalesStageName())
	 * ; } return existingSaleStages; }
	 */

	private String getCompletedSetupStage() {
		String completedSetupStage = null;
		try {
			completedSetupStage = manualInputDbService.getCompletedSetupStage();
		} catch (Exception e) {
			LOG.debug(e.getMessage(), e);
			LOG.info("Error occurred while retrieving completedSetupStage.");
		}
		return completedSetupStage;
	}

	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	public AuthResponse logout(final HttpServletResponse response,
			@RequestHeader(value = "x-auth-token", required = true) final String authToken) {

		AuthResponse authResponse = null;
		ResponseStatus responseStatus = null;
		try {
			authenticationService.logout(authToken);
			authResponse = new AuthResponse(null);
			authResponse.setAuthenticated(true);
			authResponse.setSuccess(true);
			responseStatus = new ResponseStatus(HttpStatus.OK.toString(), "", AuthResponse.class.getName());
			authResponse.setResponseStatus(responseStatus);
		} catch (Exception e) {
			LOG.error("Exception occured: " + e.getMessage());
			authResponse = new AuthResponse(null);
			authResponse.setAuthenticated(false);
			authResponse.setSuccess(false);
			responseStatus = new ResponseStatus(ErrorCodeEnum.MIRI_100.toString(),
					ErrorCodeEnum.MIRI_100.getErrorMessage(), AuthResponse.class.getName());
			authResponse.setResponseStatus(responseStatus);
		}
		return authResponse;
	}

	/**
	 * POST /register -> Create a new User.
	 */
	// @RequestMapping(value = "/register", method = RequestMethod.POST,
	// produces = MediaType.APPLICATION_JSON_VALUE)
	public AuthResponse register(final HttpServletResponse response,
			@RequestBody(required = true) final UserProfile userDetails) {
		LOG.debug("REST request to save User : {}" + userDetails);
		AuthResponse authResponse = null;
		ResponseStatus responseStatus = null;
		try {
			User newUser = userService.registerUser(userDetails);
			if (newUser != null) {
				authResponse = new AuthResponse(newUser);
				authResponse.setAuthenticated(true);
				authResponse.setSuccess(true);
				responseStatus = new ResponseStatus(HttpStatus.CREATED.toString(), "User created successfully.",
						AuthResponse.class.getName());
				authResponse.setResponseStatus(responseStatus);
			} else {
				authResponse = new AuthResponse(null);
				authResponse.setAuthenticated(false);
				authResponse.setSuccess(false);
				responseStatus = new ResponseStatus(HttpStatus.BAD_REQUEST.toString(), "Unable to create user.",
						AuthResponse.class.getName());
				authResponse.setResponseStatus(responseStatus);
			}
		} catch (Exception e) {
			LOG.error("Exception occured: " + e.getMessage());
			authResponse = new AuthResponse(null);
			authResponse.setAuthenticated(false);
			authResponse.setSuccess(false);
			responseStatus = new ResponseStatus(HttpStatus.BAD_REQUEST.toString(), e.getMessage(),
					AuthResponse.class.getName());
			authResponse.setResponseStatus(responseStatus);
		}
		return authResponse;
	}
}
