package com.miri.web.admin.facade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.data.jpa.domain.MailConfig;
import com.miri.web.admin.service.MailConfigService;

/**
 * @author supraja
 *
 */
@Component
public class MailConfigFacade {

	private static final String MAIL_SMTP_STARTTLS_ENABLE = "mail.smtp.starttls.enable";
	private static final String MAIL_SMTP_AUTH = "mail.smtp.auth";
	private static final String MAIL_FROM_EMAIL = "mail.smtp.from-address";
	private static final String MAIL_PASSWORD = "mail.smtp.password"; //NOSONAR
	private static final String MAIL_USER_NAME = "mail.smtp.username";
	private static final String MAIL_SMTP_PORT = "mail.smtp.port";
	private static final String MAIL_SMTP_HOST = "mail.smtp.host";

	// FE specific names
	private static final String ENABLE_STARTTLS = "enableStartTls";
	private static final String AUTH_REQUIRED = "authRequired";
	private static final String FROM_ADDRESS = "fromAddress";
	private static final String PASSWORD = "password"; //NOSONAR
	private static final String USERNAME = "username";
	private static final String PORT = "port";
	private static final String HOST = "host";

	@Autowired
	private MailConfigService mailConfigService;

	public void saveEmailConfigDetails(Map<String, Object> emailConfigs) { //NOSONAR

		List<MailConfig> configList = new ArrayList<>();
		for (Map.Entry<String, Object> entry : emailConfigs.entrySet()) {
			MailConfig mailConfig = new MailConfig();
		    String key = entry.getKey();
		    switch (key) {
			case HOST:
				mailConfig.setAttributeName(MAIL_SMTP_HOST);
				break;
			case PORT:
				mailConfig.setAttributeName(MAIL_SMTP_PORT);
				break;
			case USERNAME:
				mailConfig.setAttributeName(MAIL_USER_NAME);
				break;
			case PASSWORD:
				mailConfig.setAttributeName(MAIL_PASSWORD);
				break;
			case FROM_ADDRESS:
				mailConfig.setAttributeName(MAIL_FROM_EMAIL);
				break;
			case AUTH_REQUIRED:
				mailConfig.setAttributeName(MAIL_SMTP_AUTH);
				break;
			case ENABLE_STARTTLS:
				mailConfig.setAttributeName(MAIL_SMTP_STARTTLS_ENABLE);
				break;
			default:
				break;
			}
		    Object value = entry.getValue();
		    mailConfig.setAttributeValue(value != null ? String.valueOf(value) : null);
		    configList.add(mailConfig);

		   mailConfigService.saveEmailConfigDetails(configList);
		}
	}


	public Map<String,Object> getEmailConfigDetails(){
		Map<String, Object> mailConfigs = new HashMap<>();

		List<MailConfig> configs = mailConfigService.getAllMailConfigs();
		for (Iterator<MailConfig> iterator = configs.iterator(); iterator.hasNext();) {
			MailConfig mailConfig = iterator.next();

		    String key = mailConfig.getAttributeName();

			switch (key) {
			case MAIL_SMTP_HOST:
				mailConfigs.put(HOST, mailConfig.getAttributeValue());
				break;
			case MAIL_SMTP_PORT:
				mailConfigs.put(PORT, NumberUtils.createInteger(mailConfig.getAttributeValue()));
				break;
			case MAIL_USER_NAME:
				mailConfigs.put(USERNAME, mailConfig.getAttributeValue());
				break;
			case MAIL_PASSWORD:
				//skip sending password
				break;
			case MAIL_FROM_EMAIL:
				mailConfigs.put(FROM_ADDRESS, mailConfig.getAttributeValue());
				break;
			case MAIL_SMTP_AUTH:
				mailConfigs.put(AUTH_REQUIRED, Boolean.valueOf(mailConfig.getAttributeValue()));
				break;
			case MAIL_SMTP_STARTTLS_ENABLE:
				mailConfigs.put(ENABLE_STARTTLS, Boolean.valueOf(mailConfig.getAttributeValue()));
				break;
			default:
				break;
			}
		}
		return mailConfigs;
	}
}
