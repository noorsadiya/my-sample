/**
 *
 */
package com.miri.web.base;

/**
 * @author Chandra
 *
 */
public interface IChart {

}
