package com.miri.configuration;

import javax.inject.Inject;

import org.springframework.boot.bind.RelaxedPropertyResolver;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.miri.data.jpa.repository.UserLoginTokenRepository;
import com.miri.web.common.services.UserService;
import com.miri.web.security.xauth.TokenProvider;

/**
 * Configures x-auth-token security.
 */
@Configuration
public class XAuthConfiguration implements EnvironmentAware {

	private RelaxedPropertyResolver propertyResolver;
	@Inject
	private UserService userService;
	@Inject
	private UserLoginTokenRepository userLoginTokenRepository;

	@Override
	public void setEnvironment(Environment environment) {
		this.propertyResolver = new RelaxedPropertyResolver(environment, "authentication.xauth.");
	}

	@Bean
	public TokenProvider tokenProvider() {
		String secret = propertyResolver.getProperty("secret", String.class, "mySecretXAuthSecret");
		int validityInSeconds = propertyResolver.getProperty("tokenValidityInSeconds", Integer.class, 3600);
		return new TokenProvider(secret, validityInSeconds, userService, userLoginTokenRepository);
	}
}
