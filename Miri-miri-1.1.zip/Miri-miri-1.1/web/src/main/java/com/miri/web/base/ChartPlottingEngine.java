/**
 *
 */
package com.miri.web.base;


import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.web.base.charts.builders.AbstractChartBuilder;
import com.miri.web.base.charts.component.GuageTable;
import com.miri.web.base.charts.component.MetricResponse;
import com.miri.web.base.charts.factory.MetricFactory;
import com.miri.web.base.download.ExcelBuilder;
import com.miri.web.cache.DontCache;

/**
 * GraphPlottingEngine : Identifies chart builder and returns the final chart pojo.
 *
 * @author Chandra
 *
 */
@Component
public class ChartPlottingEngine {
	
	private static final Logger LOGGER = Logger.getLogger(ChartPlottingEngine.class);

    @Autowired
    private ViewJson viewJson;

    @Autowired
    ChartBuilderFactory chartBuilderFactory;

    @Autowired
    MetricFactory metricFacotry;
    
    @Autowired 
	private ExcelBuilder excelBuilder;
    
    @Autowired 
	protected GuageTable guageTable;
    /**
     * Returns final Pojo with graph response for incoming metric, chart and drill down type.
     *
     * @param metric
     * @param chartType
     * @param drillDownType
     * @return
     */
    @DontCache
    public ViewResponse plotChart(final MiriRequest miriRequest) {

    	//Identify the metric from the category, graph name and graph filter
        MiriMetric viewPojo = metricFacotry.getInstanceByMetric(miriRequest);

        //Identify the Chart type from the graph type received in the request
        ChartTypeEnum chartTypeEnum = ChartTypeEnum.getChartMapper().get(miriRequest.getChartType());

        //check chart type and if supported plot the same, if not plot default chart defined
        chartTypeEnum = viewPojo.getFinalGraphToBePlotted(chartTypeEnum);
        
        //Identify the builder by the graph type
        final AbstractChartBuilder chartBuilder = chartBuilderFactory.getChartBuilder(chartTypeEnum);

        //Pass the metric to the builder and build the chart, return the Chart Object the way the chart expects
        final IChart chart = chartBuilder.buildChart(viewPojo.fetchMetricResponse());

        //Set the chart to view json which will be converted to the expected json
        viewJson.setChart(chart);

        return viewJson;

    }
    
    
   /* *//**
     * Returns  Gauge Json with  for the incoming metric, chart and drill down type.
     * @param metric
     * @param chartType
     * @param drillDownType
     * @return
     *//*
    public ViewResponse plotGauge(final MiriRequest miriRequest) {

    	//Identify the metric from the category, graph name and graph filter
        MiriMetric viewPojo = metricFacotry.getInstanceByMetric(miriRequest);

        // Get the gauge pojo from respective metric identified above
        GaugePojo guagePojo = viewPojo.fetchMetricGauge();
        
        //set the gauge percentage to gauge json
        gaugeJson.setGuagePercentage(guagePojo.getGuagePercentage());
    
        //Set the gauge header and gauge row into gauge table
        guageTable.setGuageHeader(guagePojo.getGaugeHeaders());
        guageTable.setGuageRow(guagePojo.getGuageRow());
        
        LOGGER.debug("Gauge row size in engine:- "+guagePojo.getGuageRow().size());
        LOGGER.info("Guage Percent:-" + guagePojo.getGuagePercentage());
      
        gaugeJson.setGuageTable(guageTable);
        gaugeJson.setShowGaugeTable(guagePojo.isShowGaugeTable());
        
        LOGGER.debug("is Show Gauge Table:="+gaugeJson.isShowGaugeTable());
      
        return gaugeJson;

    }*/
    
    public XSSFWorkbook createExcelWorkBook(final MiriRequest miriRequest){
    	
    	
    	//Identify the metric from the category, graph name and graph filter
        MiriMetric viewPojo = metricFacotry.getInstanceByMetric(miriRequest);
        
        //Get the more data(Top 100) from respective metric identified above
        MetricResponse response = viewPojo.fetchMetricMoreData();
        
        XSSFWorkbook workbook = excelBuilder.buildExcelWorkBook(response);
    	
//        excelJson.setWorkbook(workbook);
        
        return workbook;
        
    }
    
}
