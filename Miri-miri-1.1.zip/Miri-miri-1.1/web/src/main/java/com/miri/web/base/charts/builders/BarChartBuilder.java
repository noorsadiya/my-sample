package com.miri.web.base.charts.builders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.miri.search.data.TopCustomersData;
import com.miri.search.data.TopHighestCustomerData;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.web.base.Chart;
import com.miri.web.base.IChart;
import com.miri.web.base.charts.component.ChartComponent;
import com.miri.web.base.charts.component.ChartSeriesData;
import com.miri.web.base.charts.component.HoverData;
import com.miri.web.base.charts.component.MetricResponse;
import com.miri.web.base.charts.component.Series;
import com.miri.web.constants.WebConstants;

/**
 * Bar Chart Builder for Top Customer Wins Graph
 * @author Prabhakar
 *
 */
@Component
@Scope("prototype")
public class BarChartBuilder extends GenericChartBuilder {
	
	private static final Logger LOG = LogManager.getLogger(BarChartBuilder.class);
	
	BarChart barChart;

	@Override
	public IChart buildChart(MetricResponse metricResponse) {
		barChart = new BarChart();
		barChart.setxAxis(populateXAxisData(metricResponse));
		barChart.setyAxis(populateYAxisData(metricResponse));
		barChart.setSeries(populateSeries(metricResponse));
		barChart.setRanges(populateDollarRanges(metricResponse));
		barChart.setyTDTarget(populateYTDTarget(metricResponse));
		return barChart;
	}

	@Override
	public ChartComponent populateMetadata(MetricResponse metricResponse) {
		Map<String, Object> graphInfo = metricResponse.getItems();
		chartMetadata.setTitle((String)graphInfo.get(WebConstants.GRAPH_TITLE));
		chartMetadata.setSubtitle((String)graphInfo.get(WebConstants.SUBTITLE));
		chartMetadata.setGraphType((String)graphInfo.get(WebConstants.GRAPH_TYPE));
		return chartMetadata;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ChartComponent populateXAxisData(MetricResponse metricResponse) {
		Map<String, Object> metricInfo = metricResponse.getItems();
		Map<String, Object> topCustomer = (Map<String, Object>) metricInfo.get(WebConstants.METRIC_DATA);
		List<String> xAxisCustomers = new ArrayList<>();
		try{
			for (String customerName : topCustomer.keySet()) {
				xAxisCustomers.add(customerName);
			}
			xaxisData.setData(xAxisCustomers);
		}catch(Exception ex){
			LOG.error("Exception while getting x-axis data:",ex);
		}
		return xaxisData;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ChartComponent populateYAxisData(MetricResponse metricResponse) {
		Map<String, Object> metricInfo = metricResponse.getItems();
		Map<String, Object> annualRevenuePercent = (Map<String, Object>) metricInfo.get("metricData");
		Set<String> customers = annualRevenuePercent.keySet();
		List<Double> amounts = new ArrayList<>();
		try{
			for (String customer : customers) {
				TopCustomersData topCustomerData = (TopCustomersData) annualRevenuePercent.get(customer);
				topCustomerData.getTopHighestcustomer().getTotalSalesAmount();
				amounts.add(topCustomerData.getTopHighestcustomer().getTotalSalesAmount());
			}
			yaxisData.setData(amounts);
		}catch(Exception ex){
			LOG.error("Exception wile getting Y-axis data:",ex);
		}
		return yaxisData;
	}

	@Override
	public ChartComponent populateLegends(MetricResponse metricResponse) {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Series> populateSeries(MetricResponse metricResponse) {
		Map<String,Object> result = (HashMap<String, Object>)metricResponse.getItems();
		Series series=new  Series();
		List<Series> seriesList=new ArrayList<>();
		TopCustomersData topCustomersData;
		series.setName((String)result.get(WebConstants.SUBTITLE));
		List<ChartSeriesData> seriesDataList= new ArrayList<ChartSeriesData>();
		Map<String, Object> graphInfo = (Map<String, Object>) result.get(WebConstants.METRIC_DATA);
		double value = 0;
		boolean isAnySeriesExists = false;
		if(graphInfo.size() > 0){
				try{
					int count=0;
					for(Map.Entry<String, Object> pair: graphInfo.entrySet()) {
						HoverData hoverData = new HoverData();
						value = 0;
						ChartSeriesData data = new ChartSeriesData();
						topCustomersData = (TopCustomersData) pair.getValue();
						if(null != topCustomersData){
							//data.setName(topCustomersData.getxAxisName());
							if(null != topCustomersData.getyAxisValue()){
								data.setY(MiriSearchUtils.removeDecimalPoint(topCustomersData.getyAxisValue()));
								value += topCustomersData.getyAxisValue();
							}
							
							//miri-1832 - Set y value to z placeholder for FE 
							if(null != topCustomersData.getzAxisValue()){
								data.setZ(MiriSearchUtils.removeDecimalPoint(topCustomersData.getzAxisValue()));
								value += topCustomersData.getzAxisValue();
							}
							
							data.setX(count);
							
							TopHighestCustomerData tophighestCustomer = topCustomersData.getTopHighestcustomer();
							hoverData.setRevenueAmount(MiriSearchUtils.removeDecimalPoint(tophighestCustomer.getTotalSalesAmount()));
							
							// commenting the below as there is no average deal size value coming from the topCustomerData Object
							hoverData.setDealsClosed(topCustomersData.getHoverDealsClosed());
							hoverData.setCustomerName(tophighestCustomer.getCustomerName());
							data.setHover(hoverData);
							seriesDataList.add(data); 
							count++;
						}
					}
					series.setData(seriesDataList);
					seriesList.add(series);
					if(value > 0){
						isAnySeriesExists = true;
					}
			}catch(Exception ex){
				LOG.error("Exception while data adding to series:",ex);
			}
		}
		if(!isAnySeriesExists){
			seriesList = new ArrayList<>();
		}
		return seriesList;
	}

	/**
	 * BarChart : Chart containing attributes specific to Multiple Axes Chart
	 */
	public static class BarChart extends Chart implements Serializable {

		/**
		 * Generated Serial Version UID
		 */
		private static final long serialVersionUID = 1922625599653569844L;
		
	}

	@Override
	public ChartComponent populateHover(MetricResponse metricResponse) {
		return null;
	}

}
