package com.miri.web.admin.controllers;

import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.miri.web.auth.UserXAuthTokenController;
import com.miri.web.auth.data.UserProfile;
import com.miri.web.base.ResponseStatus;
import com.miri.web.base.ViewResponse;
import com.miri.web.base.WrappedViewResponse;
import com.miri.web.common.services.UserService;
import com.miri.web.constants.WebConstants;
import com.miri.web.interceptors.ErrorCodeContainer.ErrorCodeEnum;
import com.miri.web.utils.WebUtils;

@RestController
@RequestMapping("/api")
public class UserManagementController {
	private static final Logger LOG = Logger.getLogger(UserXAuthTokenController.class);

	@Autowired
	private UserService userService;

	/**
	 * Change password API
	 * @param response
	 * @param userDetails
	 * @param principal
	 * @return
	 */
	@RequestMapping(value = WebConstants.CHANGE_PASSWORD, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse changePassword(final HttpServletResponse response,
			@RequestBody(required = true) final Map<String, String> userDetails, final Principal principal) {
		LOG.debug("Enter into changePassword" + userDetails);
		boolean isSuccess = false;
		ViewResponse viewResponse = new ViewResponse();
		userService.changePassword(userDetails, findUsername(principal));
		getResponse(viewResponse, isSuccess, ErrorCodeEnum.MIRI_200.toString(),
				ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	/**
	 *
	 * @param response
	 * @param userDetails
	 * @param principal
	 * @return
	 */
	@RequestMapping(value = WebConstants.PROFILE_UPDATE, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse updateProfile(final HttpServletResponse response, final HttpServletRequest request,
			@RequestBody(required = true) final UserProfile userDetails, final Principal principal) {
		LOG.debug("Enter into updateProfile" + userDetails);
		ViewResponse viewResponse = new ViewResponse();
		String miriUrl = WebUtils.buildHostUrl(request);
		userService.updateProfile(userDetails, findUsername(principal), true, miriUrl);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	/**
	 *
	 * @param response
	 * @param principal
	 * @return
	 */
	@RequestMapping(value = WebConstants.PROFILE_GET, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse getProfileDetails(final HttpServletResponse response, final Principal principal) {

		UserProfile user = userService.getProfileDetails(findUsername(principal));
		ViewResponse viewResponse = new WrappedViewResponse<UserProfile>(user);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	@RequestMapping(value = WebConstants.PROFILE_CHANGE_BACKGROUND_IMG, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse changeBackGroundImage(final HttpServletResponse response,
			@RequestBody(required = true) final Map<String, String> imagePath, Principal principal) {
		ViewResponse viewResponse = new ViewResponse();
		userService.changeBackGroundImage(imagePath, findUsername(principal));
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	@RequestMapping(value = WebConstants.FORGET_PASSWORD, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse forgetPassword(final HttpServletResponse response, final HttpServletRequest request,
			@RequestBody(required = true) final Map<String, String> userDetails) {
		LOG.debug("Enter into forgetPassword" + request.getRequestURL());

		ViewResponse viewResponse = new ViewResponse();
		String miriUrl = WebUtils.buildHostUrl(request);
		userService.forgetPassword(userDetails, miriUrl);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	@RequestMapping(value = WebConstants.USER_GET_ROLES, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse getRoles(final HttpServletResponse response, final Principal principal) {
		String loggedInUser = principal != null ? principal.getName() : null;
		Set<String> roles = userService.getRoles(loggedInUser);
		ViewResponse viewResponse = new WrappedViewResponse<Set<String>>(roles);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	/**
	 * Delete User
	 *
	 * @param response
	 * @param userDetails
	 * @return
	 */
	@RequestMapping(value = WebConstants.USER_DELETE, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse deleteUser(final HttpServletResponse response,
			@RequestBody(required = true) final Map<String, String> userDetails) {
		ViewResponse viewResponse = new ViewResponse();
		userService.deleteUser(userDetails);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
		return viewResponse;
	}

	/**
	 * Save user
	 *
	 * @param response
	 * @param userDetails
	 * @return
	 */
	@RequestMapping(value = WebConstants.USER_SAVE, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse saveUser(final HttpServletResponse response, final HttpServletRequest request,
			@RequestBody(required = true) final UserProfile userDetails) {
		LOG.debug("Enter into saveUser" + userDetails);

		ViewResponse viewResponse = new ViewResponse();
		String miriUrl = WebUtils.buildHostUrl(request);
		userService.updateProfile(userDetails, null, false, miriUrl);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	/**
	 * Edit user details
	 * @param response
	 * @param userDetails
	 * @return
	 */
	@RequestMapping(value = WebConstants.USER_EDIT, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse editUser(final HttpServletResponse response, final HttpServletRequest request,
			@RequestBody(required = true) UserProfile userDetails) {
		LOG.debug("Enter into editUser" + userDetails);

		ViewResponse viewResponse = new ViewResponse();
		String miriUrl = WebUtils.buildHostUrl(request); // TODO: Check the URL. Should come from FE
		userService.updateProfile(userDetails, null, true, miriUrl);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	/**
	 *
	 * @param response
	 * @return
	 */
	@RequestMapping(value = WebConstants.USER_LIST, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse getAllUsers(final HttpServletResponse response) {

		List<UserProfile> userList = userService.getAllUsers();
		ViewResponse viewResponse = new WrappedViewResponse<List<UserProfile>>(userList);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	/**
	 *
	 * @param viewResponse
	 * @param isSuccess
	 * @param code
	 */
	private void getResponse(ViewResponse viewResponse, boolean isSuccess, String code, String msg) {
		viewResponse.setSuccess(isSuccess);
		viewResponse.setAuthenticated(true);
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(code);
		responseStatus.setMessage(msg);
		viewResponse.setResponseStatus(responseStatus);
	}

	/**
	 *
	 * @param principal
	 * @return
	 */
	private static String findUsername(Principal principal) {
		String userName = null;
		if (principal != null) {
			userName = principal.getName();
		}
		return userName;
	}
}
