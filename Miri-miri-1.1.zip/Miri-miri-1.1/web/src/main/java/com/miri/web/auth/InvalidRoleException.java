package com.miri.web.auth;

public class InvalidRoleException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public InvalidRoleException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidRoleException(String message) {
		super(message);
	}
}
