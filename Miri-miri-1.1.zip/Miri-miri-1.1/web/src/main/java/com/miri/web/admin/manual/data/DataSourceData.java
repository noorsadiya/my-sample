package com.miri.web.admin.manual.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DataSourceData {
	private boolean draft;
	private List<Map<String, Object>> mapVendors = new ArrayList<>();
	private List<Map<String, Object>> crmVendors = new ArrayList<>();
	private List<Map<String, Object>> erpVendors = new ArrayList<>();
	private Map<String, Map<String, Object>> ftpVendors = new HashMap<>();

	public void addMapVendorConfig(final Map<String, Object> vendorConfig) {
		mapVendors.add(vendorConfig);
	}

	public void addCrmVendorConfig(final Map<String, Object> vendorConfig) {
		crmVendors.add(vendorConfig);
	}

	public void addErpVendorConfig(final Map<String, Object> vendorConfig) {
		erpVendors.add(vendorConfig);
	}

	public void addFtpVendorConfig(final String vendorType, final Map<String, Object> vendorConfig) {
		ftpVendors.put(StringUtils.lowerCase(vendorType), vendorConfig);
	}

	/**
	 * @return the draft
	 */
	public boolean isDraft() {
		return draft;
	}

	/**
	 * @param draft the draft to set
	 */
	public void setDraft(boolean draft) {
		this.draft = this.draft || draft;
	}

	/**
	 * @return the mapVendors
	 */
	@JsonProperty("dataArrMAP")
	public List<Map<String, Object>> getMapVendors() {
		return mapVendors;
	}

	/**
	 * @param mapVendors the mapVendors to set
	 */
	public void setMapVendors(final List<Map<String, Object>> mapVendors) {
		this.mapVendors = mapVendors;
	}

	/**
	 * @return the crmVendors
	 */
	@JsonProperty("dataArrCRM")
	public List<Map<String, Object>> getCrmVendors() {
		return crmVendors;
	}

	/**
	 * @param crmVendors the crmVendors to set
	 */
	public void setCrmVendors(final List<Map<String, Object>> crmVendors) {
		this.crmVendors = crmVendors;
	}

	/**
	 * @return the erpVendors
	 */
	@JsonProperty("dataArrERP")
	public List<Map<String, Object>> getErpVendors() {
		return erpVendors;
	}

	/**
	 * @param erpVendors the erpVendors to set
	 */
	public void setErpVendors(final List<Map<String, Object>> erpVendors) {
		this.erpVendors = erpVendors;
	}

	/**
	 * @return the ftpVendors
	 */
	@JsonProperty("ftpConfig")
	public Map<String, Map<String, Object>> getFtpVendors() {
		return ftpVendors;
	}

	/**
	 * @param ftpVendors the ftpVendors to set
	 */
	public void setFtpVendors(Map<String, Map<String, Object>> ftpVendors) {
		this.ftpVendors = ftpVendors;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DataSourceData [mapVendors=");
		builder.append(mapVendors);
		builder.append(", crmVendors=");
		builder.append(crmVendors);
		builder.append(", erpVendors=");
		builder.append(erpVendors);
		builder.append(", ftpVendors=");
		builder.append(ftpVendors);
		builder.append("]");
		return builder.toString();
	}
}