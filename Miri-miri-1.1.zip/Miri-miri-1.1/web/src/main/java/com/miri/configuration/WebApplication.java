package com.miri.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.context.embedded.ErrorPage;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.miri.search.service.map.MapLeadService;
import com.miri.web.auth.AuthenticationController;
import com.rits.cloning.Cloner;

@SpringBootApplication
@Configuration
@ComponentScan("com.miri.*")
@EnableAutoConfiguration
@Import(MvcConfig.class)
@EnableConfigurationProperties
//@PropertySource(value = "file:${miri.config.dir}/application-${miri.profile}.properties")
@EnableAspectJAutoProxy
@EnableScheduling
public class WebApplication extends SpringBootServletInitializer implements CommandLineRunner {
	@Autowired
	MapLeadService mapLeadService;

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {

		return application.sources(WebApplication.class);
	}


	@Autowired
	public static void main(String[] args) {
		SpringApplication.run(WebApplication.class, args);
	}

	@Bean
	public InternalResourceViewResolver internalResourceViewResolver() {
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		resolver.setPrefix("/WEB-INF/view/");
		resolver.setSuffix(".jsp");
		return resolver;
	}

	@Bean
	public EmbeddedServletContainerCustomizer containerCustomizer() {

		return new EmbeddedServletContainerCustomizer() {
			@Override
			public void customize(ConfigurableEmbeddedServletContainer container) {

				ErrorPage error401Page = new ErrorPage(HttpStatus.UNAUTHORIZED, "/error.jsp");
				ErrorPage error404Page = new ErrorPage(HttpStatus.FORBIDDEN, "/WEB-INF/view/error.jsp");
				ErrorPage error500Page = new ErrorPage(HttpStatus.INTERNAL_SERVER_ERROR, "/error");

				//container.addErrorPages(error401Page, error404Page, error500Page);
			}
		};
	}

	@Bean(name = "authenticationController")
	public AuthenticationSuccessHandler authenticationSuccessHandler() {
		return new AuthenticationController();
	}

	@Bean(name = "cloner")
	public Cloner cloner() {
		return new Cloner();
	}


	@Override
	public void run(String... args) throws Exception {
		//mapLeadService.getMonthWiseLeadsWithInDateRange(null, null);
	}
}

