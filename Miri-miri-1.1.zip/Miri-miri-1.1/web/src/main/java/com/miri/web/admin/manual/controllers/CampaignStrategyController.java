package com.miri.web.admin.manual.controllers;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.miri.search.data.CampaignStrategySetup;
import com.miri.web.admin.manual.facade.ManualInputFacade;
import com.miri.web.base.ResponseStatus;
import com.miri.web.base.ViewResponse;
import com.miri.web.base.WrappedViewResponse;
import com.miri.web.common.services.MetricJSONCacheService;
import com.miri.web.constants.WebConstants;
import com.miri.web.interceptors.ErrorCodeContainer.ErrorCodeEnum;

/**
 * @author supraja
 *
 */
@RestController
@RequestMapping("/campaignStrategy")
public class CampaignStrategyController {
	private static final Logger LOGGER = Logger.getLogger(CampaignStrategyController.class);

	@Autowired
	private ManualInputFacade manualInputFacade;

	/**
	 *
	 * @return
	 */
	@RequestMapping(value = WebConstants.GET_CAMPAIGN_LIST, method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse getCampaignData() {
		LOGGER.debug("Enter into the getCampaignData to get all campaigns");
		Map<String, Set<Map<String, String>>> campaignData = manualInputFacade.getAllCampaigns();
		ViewResponse viewResponse = new WrappedViewResponse<Map<String, Set<Map<String, String>>>>(campaignData);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	@RequestMapping(value = WebConstants.GET_CAMPAIGN_BY_NAME + "/{campaignName:.+}", method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse getCampaignByName(
			@PathVariable("campaignName") final String campaignName) throws UnsupportedEncodingException {
		LOGGER.debug("Enter into the getCampaign details by Name" + campaignName);

		String name = URLDecoder.decode(campaignName, "UTF-8");
		CampaignStrategySetup campaignDetails = manualInputFacade.getCampaignByName(name);
		ViewResponse viewResponse = new WrappedViewResponse<CampaignStrategySetup>(campaignDetails);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	/**
	 *
	 * @param campaignStrategySetup
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = WebConstants.SAVE, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse saveCampaignStrategySetup(
			@RequestBody(required = true) final CampaignStrategySetup campaignStrategySetup) throws IOException {
		LOGGER.debug("Enter into saveCampaignStrategySetup" + campaignStrategySetup);

		ViewResponse viewResponse = new ViewResponse();
		manualInputFacade.saveCampaignStrategySetup(campaignStrategySetup);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
		// Clear cache on successful update
		MetricJSONCacheService.getInstance().clearCache();

		return viewResponse;
	}

	/**
	 *
	 * @param request
	 * @return
	 */
	@RequestMapping(value = WebConstants.GET, method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse getCampaignSetupDetails() {
		CampaignStrategySetup campaignStrategySetup = manualInputFacade.getMostRecentlyUpdated();
		ViewResponse viewResponse = new WrappedViewResponse<CampaignStrategySetup>(campaignStrategySetup);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	private void getResponse(ViewResponse viewResponse, boolean isSuccess, String code, String msg) {
		viewResponse.setSuccess(isSuccess);
		viewResponse.setAuthenticated(true);
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(code);
		responseStatus.setMessage(msg);
		viewResponse.setResponseStatus(responseStatus);
	}
}
