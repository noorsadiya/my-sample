package com.miri.web.base;

public class WrappedViewResponse<T> extends ViewResponse {
	private static final long serialVersionUID = 6596210394563270385L;

	private T wrapped;

	public WrappedViewResponse(T wrapped) {
		this.wrapped = wrapped;
	}

	public T getWrapped() {
		return wrapped;
	}
}
