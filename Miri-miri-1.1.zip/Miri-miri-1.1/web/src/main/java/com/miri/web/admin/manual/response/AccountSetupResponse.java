package com.miri.web.admin.manual.response;

import org.springframework.stereotype.Component;

import com.miri.search.data.AccountSetupData;
import com.miri.web.base.ViewResponse;

/**
 * @author supraja
 *
 */
@Component
public class AccountSetupResponse extends ViewResponse {

	private AccountSetupData accountSetupData;
	private int accountId;

	public AccountSetupData getAccountSetupData() {
		return accountSetupData;
	}

	public void setAccountSetupData(AccountSetupData accountSetupData) {
		this.accountSetupData = accountSetupData;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

}
