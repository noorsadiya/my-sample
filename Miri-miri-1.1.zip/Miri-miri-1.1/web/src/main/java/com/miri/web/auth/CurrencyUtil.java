/**
 * 
 */
package com.miri.web.auth;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.data.jpa.domain.Currency;
import com.miri.data.jpa.service.ManualInputService;
import com.miri.web.common.services.MetricJSONCacheService;

/**
 * @author prekumar
 *
 */
@Component
public class CurrencyUtil {

	@Autowired
	private ManualInputService manualInputDbService;

	/**
	 * Returns currency symbol from cache and if not available in cache then
	 * fetches from DB.
	 * 
	 * @return
	 */
	public String getCurrencySymbol() {
		MetricJSONCacheService metricJSONCacheService = MetricJSONCacheService.getInstance();
		String cacheKey = "MIRI_CURRENCY_SYMBOL";

		String symbol = (String) metricJSONCacheService.getCachedDataByKey(cacheKey);

		if (StringUtils.isBlank(symbol)) {
			Currency accountCurrency = manualInputDbService.getAccountCurrency();
			symbol = accountCurrency.getCurrencySymbol();
			metricJSONCacheService.addToCache(cacheKey, symbol);
		}

		return symbol;
	}
}
