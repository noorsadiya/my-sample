package com.miri.web.auth.response;

import com.miri.web.auth.data.ApplicationInfo;
import com.miri.web.auth.data.UserProfile;
import com.miri.web.base.ViewResponse;

public class AuthResponse extends ViewResponse {
	private static final long serialVersionUID = 1500824868051652460L;

	private final Object token;

	private final ApplicationInfo applicationInfo;

	private final UserProfile profile;
	
	private String licenseExpiryDate;
	
	private int noOfDaysToExpireKey;
	
	private boolean trail;
	
	public boolean isTrail() {
		return trail;
	}
	
	public void setTrail(boolean trail) {
		this.trail = trail;
	}
	
	public int getNoOfDaysToExpireKey() {
		return noOfDaysToExpireKey;
	}
	
	public void setNoOfDaysToExpireKey(int noOfDaysToExpireKey) {
		this.noOfDaysToExpireKey = noOfDaysToExpireKey;
	}
	
	public String getLicenseExpiryDate() {
		return licenseExpiryDate;
	}

	public void setLicenseExpiryDate(String licenseExpiryDate) {
		this.licenseExpiryDate = licenseExpiryDate;
	}
	private final String currencySymbol;
	
	

	public AuthResponse(Object token) {
		this(token, null, null, null);
	}

	public AuthResponse(Object token, ApplicationInfo applicationInfo, UserProfile profile, String currencySymbol) {
		this.token = token;
		this.applicationInfo = applicationInfo;
		this.profile = profile;
		this.currencySymbol = currencySymbol;
	}

	public String getCurrencySymbol() {
		return currencySymbol;
	}
	
	public Object getToken() {
		return token;
	}

	public ApplicationInfo getApplicationInfo() {
		return applicationInfo;
	}

	public UserProfile getProfile() {
		return profile;
	}
}
