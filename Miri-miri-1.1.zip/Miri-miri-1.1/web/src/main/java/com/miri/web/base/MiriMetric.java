/**
 * 
 */
package com.miri.web.base;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.miri.search.constants.SearchConstants;
import com.miri.search.data.FiscalDatesData;
import com.miri.search.domain.guage.GaugePojo;
import com.miri.web.base.charts.component.MetricResponse;
import com.miri.web.dashboard.assess.helper.AssessBusinessIndicatorHelper;
import com.miri.web.dashboard.visualize.measure.misgrevenueachieved.ManualAccountStrategyHelper;

/**
 * @author Chandra
 *
 */
@SuppressWarnings("unused")
public abstract class MiriMetric {

	@Autowired
	private MetricResponse metricResponse;
	
	@Autowired
	ManualAccountStrategyHelper accountMetricHelper;
	
	@Autowired
	public AssessBusinessIndicatorHelper indicatorHelper;

	private DrillDownType drillDownType;
	
	private DrillDownType subDrillDownType;
	
	private boolean gauge;
	
	private String timeFrame;
	
	private List<String> campaignIds;
	
	private MiriRequest miriRequest;
	
	@Value("${custom.metric.default-metric-size}")
	private int defaultSize;
	
	@Value("${custom.csv.default-more-download-size}")
	private int topCsvSize;
	
	@Value("${custom.probability.probability-qualified-pipeline-start-range}")
	private int qualifiedProbabilityStartRange;
	
	@Value("${custom.probability.probability-qualified-pipeline-end-range}")
	private int qualifiedProbabilityEndRange;
	
	
	public void setDefaultSize(int defaultSize) {
		this.defaultSize = defaultSize;
	}

    public int getDefaultSize() {
		return defaultSize;
	}

	public void setTopCsvSize(int topCsvSize) {
		this.topCsvSize = topCsvSize;
	}

    public int getTopCsvSize() {
		return topCsvSize;
	}

	public DrillDownType getDrillDownType() {
        return DrillDownType.getDrillDownMapper().get(miriRequest.getDrildown());
	}

	public void setDrillDownType(DrillDownType drillDownType) {
		this.drillDownType = drillDownType;
	}

	public DrillDownType getSubDrillDownType() {
		return DrillDownType.getDrillDownMapper().get(miriRequest.getSubDrillDown());
	}

	public void setSubDrillDownType(DrillDownType subDrillDownType) {
		this.subDrillDownType = subDrillDownType;
	}

	public boolean getGauge() {
		return miriRequest.getGauge();
	}

	public void setGauge(boolean gauge) {
		this.gauge = gauge;
	}

	public String getTimeFrame() {
		return miriRequest.getTimeFrame();
	}

	public void setTimeFrame(String timeFrame) {
		this.timeFrame = timeFrame;
	}

	public List<String> getCampaignIds() {
		return miriRequest.getCampaignIds();
	}

	public void setCampaignIds(List<String> campaignIds) {
		this.campaignIds = campaignIds;
	}

	public MiriRequest getMiriRequest() {
		return miriRequest;
	}

	public void setMiriRequest(MiriRequest miriRequest) {
		this.miriRequest = miriRequest;
	}

	public abstract MetricResponse fetchMetricResponse();

	public abstract ChartTypeEnum getDefaultChartType();

	public List<ChartTypeEnum> getAllSupportedCharts() {
		final List<ChartTypeEnum> supportedChartTypes = new ArrayList<ChartTypeEnum>();
        supportedChartTypes.add(getDefaultChartType());
        return supportedChartTypes;
	}

	/**
	 * Returns whether the requested graph type is supported.
	 * 
	 * @param incomingGraphType
	 * @return
	 */
	public boolean isChartCompatible(ChartTypeEnum incomingGraphType) {
		return getAllSupportedCharts().contains(incomingGraphType);
	}

	/**
	 * Returns the chart type based on incoming request and compatibility.
	 * 
	 * @param incomingGraphType
	 * @return
	 */
	public ChartTypeEnum getFinalGraphToBePlotted(final ChartTypeEnum incomingGraphType) {
		if(incomingGraphType != null) {
			return this.getAllSupportedCharts().contains(incomingGraphType) ? incomingGraphType : this.getDefaultChartType();
		} else {
			return this.getDefaultChartType();
		}
	}

	/**
	 * Returns the chart type based on incoming request and compatibility.
	 * 
	 * @param incomingGraphType
	 * @return
	 */
	public ChartTypeEnum getFinalGraphToBePlotted(final String incomingGraphTypeStr) {
		ChartTypeEnum graphTypeEnum = ChartTypeEnum.getChartMapper().get(incomingGraphTypeStr);
		return getAllSupportedCharts().contains(graphTypeEnum) ? graphTypeEnum : getDefaultChartType();
	}

	public MetricResponse getMetricResponse() {
		return metricResponse;
	}

	public void setMetricResponse(MetricResponse metricResponse) {
		this.metricResponse = metricResponse;
	}

	//public abstract GuagePojo fetchMetricGauge();
	
	public  GaugePojo fetchMetricGauge(){
		return null;
	}
	
	public MetricResponse fetchMetricMoreData(){
		return null;
	}
	
	public int getQualifiedProbabilityStartRange() {
		return qualifiedProbabilityStartRange;
	}

	public void setQualifiedProbabilityStartRange(int qualifiedProbabilityStartRange) {
		this.qualifiedProbabilityStartRange = qualifiedProbabilityStartRange;
	}

	public int getQualifiedProbabilityEndRange() {
		return qualifiedProbabilityEndRange;
	}

	public void setQualifiedProbabilityEndRange(int qualifiedProbabilityEndRange) {
		this.qualifiedProbabilityEndRange = qualifiedProbabilityEndRange;
	}

	/**
	 * Generate the time frame dates based on the provided the time frame period.
	 * 
	 * @param timeFrame
	 */
	public FiscalDatesData generateTimeFrameDates(String timeFrame) {
		if (StringUtils.isEmpty(timeFrame)) {
			timeFrame = SearchConstants.ONE_YEAR;
		}
	 return accountMetricHelper.getTimeFrameDates(timeFrame);
	}
	
	public Number fetchYTDTarget(){
		return 0.0;
	}
	
	public Number fetchYTDTarget(DrillDownType drillDownType){
		return 0.0;
	}

}
