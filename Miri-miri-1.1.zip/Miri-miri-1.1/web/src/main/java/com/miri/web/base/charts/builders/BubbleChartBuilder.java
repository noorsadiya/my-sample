package com.miri.web.base.charts.builders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.w3c.dom.ls.LSInput;

import com.miri.search.data.LargestDealsClosedData;
import com.miri.web.base.Chart;
import com.miri.web.base.IChart;
import com.miri.web.base.charts.component.ChartComponent;
import com.miri.web.base.charts.component.ChartSeriesData;
import com.miri.web.base.charts.component.HoverData;
import com.miri.web.base.charts.component.MetricResponse;
import com.miri.web.base.charts.component.Series;
import com.miri.web.constants.WebConstants;

@Component
@Scope("prototype")
public class BubbleChartBuilder  extends GenericChartBuilder{


	BubbleChart bubbleChart;

	public static class BubbleChart extends Chart implements Serializable {

		/**
		 * Generated serial version UID
		 */
		private static final long serialVersionUID = 6428598058955888750L;
	}

	@Override
	public IChart buildChart(MetricResponse metricResponse) {
		//BubbleChart.metaData = (Map<String,String>) metricResponse.getItems().get(WebConstants.META_DATA);
		//BubbleChart.graphData = (Map<String,String>) metricResponse.getItems().get(WebConstants.GRAPH_LABEL);
		bubbleChart = new BubbleChart();
		bubbleChart.setChartMetadata(populateMetadata(metricResponse));
		bubbleChart.setxAxis(populateXAxisData(metricResponse));
		bubbleChart.setyAxis(populateYAxisData(metricResponse));
		bubbleChart.setSeries(populateSeries(metricResponse));
		bubbleChart.setRanges(populateDollarRanges(metricResponse));
		bubbleChart.setyTDTarget(populateYTDTarget(metricResponse));
		return bubbleChart;
	}


	@Override
	public ChartComponent populateMetadata(MetricResponse metricResponse) {
		chartMetadata.setGraphType((String) metricResponse.getItems().get(WebConstants.GRAPH_TYPE));
		chartMetadata.setTitle((String) metricResponse.getItems().get(WebConstants.GRAPH_TITLE));
		chartMetadata.setSubtitle((String) metricResponse.getItems().get(WebConstants.SUBTITLE));
		return chartMetadata;
	}

	@Override
	public ChartComponent populateXAxisData(MetricResponse metricResponse) {
		xaxisData.setLabel((String) metricResponse.getItems().get(WebConstants.X_AXIS_LABEL));
		xaxisData.setData(metricResponse.getItems().get(WebConstants.X_AXIS_DATA));
		return xaxisData;
	}

	@Override
	public ChartComponent populateYAxisData(MetricResponse metricResponse) {
		yaxisData.setLabel((String) metricResponse.getItems().get(WebConstants.Y_AXIS_LABEL));
		//yaxisData.setData(BubbleChart.graphData.get(WebConstants.Y_AXIS_DATA));
		return yaxisData;
	}

	@Override
	public ChartComponent populateLegends(MetricResponse metricResponse) {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Series> populateSeries(MetricResponse metricResponse) {
		List<LargestDealsClosedData> metricData = (List<LargestDealsClosedData>) metricResponse.getItems().get(WebConstants.METRIC_DATA);
		Series series = new Series();
		series.setName((String) metricResponse.getItems().get(WebConstants.SERIES_NAME));
		List<ChartSeriesData> chartSeriesDataList = new ArrayList<ChartSeriesData>();
		boolean isAnySeriesExists = false;

		for(LargestDealsClosedData deal : metricData) {
			ChartSeriesData seriesData = new ChartSeriesData();	
			seriesData.setX(deal.getxAxisIndex());
			seriesData.setY(deal.getRevenueAmount());
			if(deal.getRevenueAmount() > 0){
				isAnySeriesExists = true;
			}
			seriesData.setZ(deal.getRevenueAmount());

			HoverData hoverData = new HoverData();
			hoverData.setRevenueAmount((deal.getRevenueAmount()));
			hoverData.setCustomerName(deal.getCustomerName());
			seriesData.setHover(hoverData);
			chartSeriesDataList.add(seriesData);
		}

		series.setData(chartSeriesDataList);
		List<Series> seriesList =  new ArrayList<>();
		seriesList.add(series);
		if(!isAnySeriesExists){
			seriesList = new ArrayList<>();
		}
		return seriesList;
	}

	@Override
	public ChartComponent populateHover(MetricResponse metricResponse) {
		// TODO Auto-generated method stub
		return null;
	}

}
