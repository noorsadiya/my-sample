/**
 *
 */
package com.miri.web.base;

import org.springframework.stereotype.Component;

/**
 * ViewJson : Represents the response any chart plotting request for a given Metric.
 *
 * @author Chandra
 *
 */
@Component
public class ViewJson extends ViewResponse {
	private IChart chart;

	@Override
    public boolean isAuthenticated() {
		return isAuthenticated;
	}

	@Override
    public void setAuthenticated(boolean isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}

	public boolean isSuccess() {
		return isSuccess;
	}

	@Override
    public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

    public IChart getChart() {
        return chart;
    }

    public void setChart(final IChart chart) {
        this.chart = chart;
    }

}
