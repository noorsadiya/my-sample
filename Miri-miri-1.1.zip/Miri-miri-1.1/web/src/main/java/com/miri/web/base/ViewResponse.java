/**
 *
 */
package com.miri.web.base;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * ViewResponse : Parent Response class that represents response for any incoming request.
 *
 * @author Chandra
 *
 */
@Component
public class ViewResponse implements Serializable {

	private static final long serialVersionUID = 7991572783960989149L;

	public boolean isAuthenticated;

    public boolean isSuccess = true;

    protected boolean pinnedOnDashboard;
    
    public String timeTaken;

    @Autowired
    private ResponseStatus responseStatus;

    public ViewResponse() {
        super();
    }

    public boolean isAuthenticated() {
        return isAuthenticated;
    }

    public void setAuthenticated(final boolean isAuthenticated) {
        this.isAuthenticated = isAuthenticated;
    }

    public void setSuccess(final boolean isSuccess) {
        this.isSuccess = isSuccess;
    }

	public boolean isPinnedOnDashboard() {
		return pinnedOnDashboard;
	}

	public void setPinnedOnDashboard(boolean isPinnedOnDashboard) {
		this.pinnedOnDashboard = isPinnedOnDashboard;
	}

    public ResponseStatus getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(final ResponseStatus responseStatus) {
        this.responseStatus = responseStatus;
    }

	public String getTimeTaken() {
		return timeTaken;
	}

	public void setTimeTaken(String timeTaken) {
		this.timeTaken = timeTaken;
	}

    
}
