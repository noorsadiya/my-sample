package com.miri.web.base.charts.builders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.crsh.console.jline.internal.Log;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.miri.search.data.CampaignRevenueData;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.web.base.Chart;
import com.miri.web.base.ChartTypeEnum;
import com.miri.web.base.IChart;
import com.miri.web.base.charts.component.ChartComponent;
import com.miri.web.base.charts.component.ChartSeriesData;
import com.miri.web.base.charts.component.HoverData;
import com.miri.web.base.charts.component.MetricResponse;
import com.miri.web.base.charts.component.Series;
import com.miri.web.constants.ControllerConstants;
import com.miri.web.constants.WebConstants;

@Component
@Scope("prototype")
public class BasicLineChartBuilder  extends GenericChartBuilder {

	BasicLineChart basicLineChart;

	public static class BasicLineChart extends Chart implements Serializable {

		/**
		 * Generated serial version UID
		 */
		private static final long serialVersionUID = 6018209464225482622L;

	}

	@Override
	public IChart buildChart(MetricResponse metricResponse) {
		basicLineChart = new BasicLineChart();
		basicLineChart.setChartMetadata(populateMetadata(metricResponse));
		basicLineChart.setyAxis(populateYAxisData(metricResponse));
		basicLineChart.setxAxis(populateXAxisData(metricResponse));
		basicLineChart.setSeries(populateSeries(metricResponse));
		basicLineChart.setRanges(populateDollarRanges(metricResponse));
		basicLineChart.setParentData(super.populateCampaignHierarchy(metricResponse));
		return basicLineChart;
	}


	@Override
	public ChartComponent populateMetadata(MetricResponse metricResponse) {
		Log.debug(metricResponse.getItems());
		chartMetadata.setTitle((String)metricResponse.getItems().get(WebConstants.GRAPH_TITLE));

		chartMetadata.setSubtitle((String)metricResponse.getItems().get(WebConstants.SUBTITLE));
//		chartMetadata.setSubtitle(metricResponse.getItems().get(WebConstants.SUBTITLE).toString());
		chartMetadata.setGraphType(ChartTypeEnum.BASIC_LINE.getText());
		return chartMetadata;
	}

	@Override
	public ChartComponent populateXAxisData(MetricResponse metricResponse) {
		xaxisData.setData(metricResponse.getItems().get(WebConstants.X_AXIS_DATA));

		xaxisData.setLabel((String)metricResponse.getItems().get(ControllerConstants.X_AXIS_LABEL));
		return xaxisData;
	}

	@Override
	public ChartComponent populateYAxisData(MetricResponse metricResponse) {
		yaxisData.setLabel((String)metricResponse.getItems().get(WebConstants.Y_AXIS_LABEL));
		return yaxisData;
	}

	@Override
	public ChartComponent populateLegends(MetricResponse metricResponse) {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Series> populateSeries(MetricResponse metricResponse) {

		List<CampaignRevenueData> metricDataList=(List<CampaignRevenueData>) metricResponse.getItems().get(WebConstants.BASIC_LINE_METRIC);
		List<Series> seriesList=new ArrayList<>();
		
		boolean isAnySeriesExists = false;
		for(CampaignRevenueData campaignData:metricDataList){
			Series series=new  Series();
			if(!StringUtils.isEmpty(campaignData.getCampaignName())) {
				series.setName(campaignData.getCampaignName());
			} else if(StringUtils.isNotBlank(campaignData.getParentCampaignName())) {
				series.setName(campaignData.getParentCampaignName());
			} else {
				series.setName(metricResponse.getItems().get(WebConstants.SERIES_NAME).toString());
			}
			boolean isDataAvailable = false;
			List<ChartSeriesData> chartSeriesDataList = new ArrayList<ChartSeriesData>();
			Map<Object,CampaignRevenueData> monthData = campaignData.getRevenuesByMonth();

			if(monthData != null){
				for (Entry<Object, CampaignRevenueData> revenueData : monthData.entrySet()){
					if(null != revenueData.getValue()){
					ChartSeriesData seriesData=new ChartSeriesData();
					seriesData.setX(revenueData.getKey());
					if(null != revenueData.getValue().getRevenueAmount()){
						seriesData.setY(MiriSearchUtils.removeDecimalPoint(revenueData.getValue().getRevenueAmount()));
						if(revenueData.getValue().getRevenueAmount() > 0){
							isDataAvailable = true;
						}
					}
					
					HoverData hover = new HoverData();
					if(revenueData.getValue().getAverageDealSize() != null) {
						hover.setParentCampaignName(campaignData.getParentCampaignName());
						hover.setCampaignName(campaignData.getCampaignName());
						//hover.setRevenueAmount(revenueData.getValue().getRevenueAmount());
						if(null != revenueData.getValue().getAverageDealSize()){
							hover.setAverageDealSize(MiriSearchUtils.removeDecimalPoint(revenueData.getValue().getAverageDealSize()));
						}
						hover.setDealsClosed(revenueData.getValue().getNoOfDeals());
						if(null != revenueData.getValue().getAverageSellPrice()){
							hover.setAverageSellPrice(MiriSearchUtils.removeDecimalPoint(revenueData.getValue().getAverageSellPrice()));
						}
					}
					seriesData.setHover(hover);
					chartSeriesDataList.add(seriesData);
				}else
				{
					ChartSeriesData seriesData=new ChartSeriesData();
					seriesData.setX(revenueData.getKey());
					seriesData.setY(null);
					chartSeriesDataList.add(seriesData);
				}
				}
			}
			series.setData(chartSeriesDataList);
			seriesList.add(series);
			if(isDataAvailable){
				isAnySeriesExists = true;
			}
		}
		if(!isAnySeriesExists){
			seriesList = new ArrayList<>();
		}
		return seriesList;
	}

	@Override
	public ChartComponent populateHover(MetricResponse metricResponse) {
		return null;
	}
}
