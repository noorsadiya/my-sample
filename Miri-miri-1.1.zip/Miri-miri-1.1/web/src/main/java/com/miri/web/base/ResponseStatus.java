/**
 * 
 */
package com.miri.web.base;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

/**
 * @author Chandra
 *
 */
@Component
public class ResponseStatus implements Serializable {

	private static final long serialVersionUID = -6639896666869874100L;

	private String code;

	private String message;

	private String type;

	private Map<String, String> errors = new HashMap<>();

	public ResponseStatus() {
		super();
	}

	public Map<String, String> getErrors() {
		return errors;
	}

	public void setErrors(Map<String, String> errors) {
		this.errors = errors;
	}

	public ResponseStatus(String code, String message, String type) {
		super();
		this.code = code;
		this.message = message;
		this.type = type;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
