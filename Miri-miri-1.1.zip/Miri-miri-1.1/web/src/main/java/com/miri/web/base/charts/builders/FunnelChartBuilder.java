package com.miri.web.base.charts.builders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.miri.search.esutils.MiriSearchUtils;
import com.miri.web.base.Chart;
import com.miri.web.base.ChartTypeEnum;
import com.miri.web.base.IChart;
import com.miri.web.base.charts.component.ChartComponent;
import com.miri.web.base.charts.component.ChartSeriesData;
import com.miri.web.base.charts.component.MetricResponse;
import com.miri.web.base.charts.component.Series;
import com.miri.web.constants.ControllerConstants;
import com.miri.web.constants.WebConstants;

@Component
@Scope("prototype")
public class FunnelChartBuilder extends GenericChartBuilder {
	
	FunnelBuilder funnelBuilder;
	
	public static class FunnelBuilder extends Chart implements Serializable{

		/**
		 * Generated Serial Version UID
		 */
		private static final long serialVersionUID = -947149496046221867L;
		
	}

	@Override
	public ChartComponent populateMetadata(MetricResponse metricResponse) {
		chartMetadata.setTitle((String) metricResponse.getItems().get(ControllerConstants.GRAPH_TITLE));
		chartMetadata.setSubtitle((String) metricResponse.getItems().get(ControllerConstants.GRAPH_SUB_TITLE));
		chartMetadata.setGraphType(ChartTypeEnum.FUNNEL_CHART.toString());
		return chartMetadata;
	}

	@Override
	public ChartComponent populateXAxisData(MetricResponse metricResponse) {
		xaxisData.setLabel((String)metricResponse.getItems().get(ControllerConstants.X_AXIS_LABEL));
		return xaxisData;
	}

	@Override
	public ChartComponent populateYAxisData(MetricResponse metricResponse) {
		yaxisData.setLabel((String) metricResponse.getItems().get(ControllerConstants.Y_AXIS_LABEL));
		return yaxisData;
	}

	@Override
	public ChartComponent populateLegends(MetricResponse metricResponse) {
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Series> populateSeries(MetricResponse metricResponse) {
		List<Series> seriesList = new ArrayList<Series>();
		Map<String, Double> metricData=(LinkedHashMap<String, Double>)metricResponse.getItems().get(WebConstants.LINE_LABELS_METRIC_DATA);
		Series series = new Series();
		List<ChartSeriesData> seriesDataList= new ArrayList<ChartSeriesData>();
		boolean isDataAvailable =  false;
		boolean isAnySeriesExists = false;
		for (Entry<String, Double> entry1 : metricData.entrySet()) {
			ChartSeriesData data=new ChartSeriesData();
			data.setName(entry1.getKey());
			if(entry1.getValue() != null){
				data.setY(MiriSearchUtils.removeDecimalPoint(entry1.getValue()));
				if(entry1.getValue() > 0){
					isDataAvailable = true;
				}

			}
			seriesDataList.add(data); 
		}
		series.setData(seriesDataList);
		seriesList.add(series);
		if(isDataAvailable){
			isAnySeriesExists = true;
		}
		if(!isAnySeriesExists){
			seriesList = new ArrayList<>();
		}
		return seriesList;
	}

	@Override
	public ChartComponent populateHover(MetricResponse metricResponse) {
		return null;
	}

	@Override
	public IChart buildChart(MetricResponse metricResponse) {
		funnelBuilder = new FunnelBuilder();
		funnelBuilder.setxAxis(populateXAxisData(metricResponse));
		funnelBuilder.setyAxis(populateYAxisData(metricResponse));
		funnelBuilder.setSeries(populateSeries(metricResponse));
		funnelBuilder.setChartMetadata(populateMetadata(metricResponse));
		funnelBuilder.setyTDTarget(populateYTDTarget(metricResponse));
        return funnelBuilder;
	}

	@Override
	public List<Double[]> populateDollarRanges(MetricResponse metricResponse) {
		// TODO Auto-generated method stub
		return null;
	}

}
