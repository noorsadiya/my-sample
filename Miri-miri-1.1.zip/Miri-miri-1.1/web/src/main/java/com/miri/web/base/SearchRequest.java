/**
 * 
 */
package com.miri.web.base;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.miri.web.dashboard.viewhelper.explore.search.Pagination;

/**
 * @author Chandra
 *
 */
@Component
public class SearchRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String searchKey;

	private Set<TuplePojo> filters;

	private int sPageNo;

	private int cPageNo;

	private int pageSize;

	private long start;

	private long end;

	private String sortOnDoc;

	private String sortOnField;

	private String sortBy;

	private long totalHits;

	private long totalRecords;

	private long totalPages;

	public String getSearchKey() {
		return searchKey;
	}

	public void setSearchKey(String searchKey) {
		this.searchKey = searchKey;
	}

	public Set<TuplePojo> getFilters() {
		if(null == filters)
			filters = new HashSet<>();
		return filters;
	}

	/**
	 * Returns filter values.
	 *
	 * @return
	 */
	public Set<String> getFilterValues() {
		Set<String> values = new HashSet<>();
		for (Iterator<TuplePojo> iterator = getFilters().iterator(); iterator.hasNext();) {
			TuplePojo tuplePojo = (TuplePojo) iterator.next();
			values.add(tuplePojo.getValue());
		}
		return values;
	}


	/**
	 * Returns filter values.
	 *
	 * @return
	 */
	public Set<String> getFilterTuples() {
		Set<String> values = new HashSet<>();
		for (Iterator<TuplePojo> iterator = getFilters().iterator(); iterator.hasNext();) {
			TuplePojo tuplePojo = (TuplePojo) iterator.next();
			values.add(tuplePojo.getValue());
		}
		return values;
	}


	public void setFilters(Set<TuplePojo> filters) {
		this.filters = filters;
	}

	public int getsPageNo() {
		return sPageNo;
	}

	public void setsPageNo(int sPageNo) {
		this.sPageNo = sPageNo;
	}

	public int getPageSize() {
		if (pageSize == 0)
			pageSize = Pagination.DEFAULT_PAGE_SIZE;
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getSortOnDoc() {
		return sortOnDoc;
	}

	public void setSortOnDoc(String sortOnDoc) {
		this.sortOnDoc = sortOnDoc;
	}

	public String getSortOnField() {
		return sortOnField;
	}

	public void setSortOnField(String sortOnField) {
		this.sortOnField = sortOnField;
	}

	public int getcPageNo() {
		return cPageNo;
	}

	public void setcPageNo(int cPageNo) {
		this.cPageNo = cPageNo;
	}

	public SearchRequest buildSearchRequest() {
		return this;
	}

	public long getStart() {
		if (start == 0)
			start = Pagination.DEFAULT_PAGE_START;

		return start;
	}

	public void setStart(long start) {
		this.start = start;
	}

	public long getEnd() {
		if (end == 0)
			end = Pagination.DEFAULT_PAGE_END;
		return end;
	}

	public void setEnd(long end) {
		this.end = end;
	}

	public long getTotalHits() {
		return totalHits;
	}

	public void setTotalHits(long totalHits) {
		this.totalHits = totalHits;
	}

	public long getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(long totalRecords) {
		this.totalRecords = totalRecords;
	}

	public long getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(long totalPages) {
		this.totalPages = totalPages;
	}

	public SearchRequest sortOnDoc(final String sortOnDoc) {
		this.setSortOnDoc(sortOnDoc);
		return this;
	}

	public SearchRequest cPageNo(final int cPageNo) {
		this.setcPageNo(cPageNo);
		return this;
	}

	public SearchRequest sPageNo(final int sPageNo) {
		this.setsPageNo(sPageNo);
		return this;
	}

	public SearchRequest start(final long start) {
		this.setStart(start);
		return this;
	}

	public SearchRequest end(final long end) {
		this.setEnd(end);
		return this;
	}

	public SearchRequest totalPages(final int totalPages) {
		this.setTotalPages(totalPages);
		return this;
	}

	public SearchRequest totalHits(final long totalHits) {
		this.setTotalHits(totalHits);
		return this;
	}

	public SearchRequest totalRecords(final long totalRecords) {
		this.setTotalRecords(totalRecords);
		return this;
	}

	public SearchRequest pageSize(final int pageSize) {
		this.setPageSize(pageSize);
		return this;
	}

	public SearchRequest filters(final Set<TuplePojo> filters) {
		this.setFilters(filters);
		return this;
	}

	public SearchRequest filter(final TuplePojo filter) {
		this.getFilters().add(filter);
		return this;
	}

	public SearchRequest searchKey(final String searchKey) {
		this.setSearchKey(searchKey);
		return this;
	}

	public SearchRequest sortBy(final String sortBy) {
		this.setSortBy(sortBy);
		return this;
	}

	public SearchRequest sortOnField(final String sortOnField) {
		this.setSortOnField(sortOnField);
		return this;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}


	/*
	 * public static void main(String[] args) { Set<String> filters = new
	 * TreeSet<>(); filters.add("Products"); filters.add("Industries");
	 * SearchRequest searchRequest = new
	 * SearchRequest().buildSearchRequest().searchKey("Think Big"
	 * ).filters(filters).pageSize(50).sortOnDoc("MapCampaign").sortOnField(
	 * "CampaignName").sPageNo(12);
	 *
	 * JSONObject jsonObject = new JSONObject(searchRequest);
	 *
	 *
	 * System.out.println("output: "+jsonObject.toString());
	 *
	 * }
	 */

}
