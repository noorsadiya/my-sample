package com.miri.web.admin.data;

import java.util.HashMap;
import java.util.Map;

public class JobInitResponse {


	private String executionType;
	private boolean scheduled;
	private Integer corePoolSize;
	private Map<String, JobInfo> results;
	private boolean initiated;
	private String message;

	public JobInitResponse() {
		this.results = new HashMap<>();
	}

	public String getExecutionType() {
		return executionType;
	}

	public void setExecutionType(String executionType) {
		this.executionType = executionType;
	}

	public boolean isScheduled() {
		return scheduled;
	}

	public void setScheduled(boolean scheduled) {
		this.scheduled = scheduled;
	}

	public Integer getCorePoolSize() {
		return corePoolSize;
	}

	public void setCorePoolSize(Integer corePoolSize) {
		this.corePoolSize = corePoolSize;
	}

	public Map<String, JobInfo> getResults() {
		return results;
	}

	public void addJobInfo(String jobName, boolean done, String futurGet) {
		results.put(jobName, new JobInfo(done, futurGet));
	}

	public void addJobInfo(String jobName, JobInfo jobInfo) {
		results.put(jobName, jobInfo);
	}

	public void setResults(Map<String, JobInfo> results) {
		this.results = results;
	}

	public boolean isInitiated() {
		return initiated;
	}

	public void setInitiated(boolean initiated) {
		this.initiated = initiated;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("JobInitResponse [executionType=");
		builder.append(executionType);
		builder.append(", scheduled=");
		builder.append(scheduled);
		builder.append(", corePoolSize=");
		builder.append(corePoolSize);
		builder.append(", results=");
		builder.append(results);
		builder.append(", initiated=");
		builder.append(initiated);
		builder.append(", message=");
		builder.append(message);
		builder.append("]");
		return builder.toString();
	}

	public static class JobInfo {
		private boolean done;
		private String futureResult;

		public JobInfo(boolean done, String futurGet) {
			super();
			this.done = done;
			this.futureResult = futurGet;
		}

		public boolean isDone() {
			return done;
		}

		public String getFutureResult() {
			return futureResult;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("JobInfo [done=");
			builder.append(done);
			builder.append(", futureResult=");
			builder.append(futureResult);
			builder.append("]");
			return builder.toString();
		}
	}


}
