package com.miri.configuration;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.miri.search.interceptors.ESQueryInterceptor;
import com.miri.search.interceptors.MiriSearchServiceInterceptor;
import com.miri.web.base.ViewResponseAspect;
import com.miri.web.interceptors.MiriChartBuilderInterceptor;
import com.miri.web.interceptors.MiriChartEngineInterceptor;
import com.miri.web.interceptors.MiriDollarFloorInterceptor;
import com.miri.web.interceptors.MiriGaugeInterceptor;
import com.miri.web.interceptors.MiriMetricHelperCacheInterceptor;
import com.miri.web.interceptors.MiriMetricInterceptor;

@Configuration
@EnableAutoConfiguration
@EnableConfigurationProperties
@ComponentScan
@EnableAspectJAutoProxy
public class AopConfig {

	@Bean
	public ViewResponseAspect getViewResponseAspect() {
		return new ViewResponseAspect();
	}

	@Bean
	public MiriChartEngineInterceptor getMiriChartEngineInterceptor() {
		return new MiriChartEngineInterceptor();
	}

	@Bean
	public MiriChartBuilderInterceptor getMiriChartBuilderInterceptor() {
		return new MiriChartBuilderInterceptor();
	}

	@Bean
	public MiriDollarFloorInterceptor getMiriDollarFloorInterceptor() {
		return new MiriDollarFloorInterceptor();
	}

	@Bean
	public MiriGaugeInterceptor getMiriGaugeInterceptor() {
		return new MiriGaugeInterceptor();
	}
	
	
	@Bean
	public MiriMetricInterceptor getMiriMetricInterceptor() {
		return new MiriMetricInterceptor();
	}
	
	@Bean
	public MiriSearchServiceInterceptor getMiriSearchServiceInterceptor() {
		return new MiriSearchServiceInterceptor();
	}

	@Bean
	public ESQueryInterceptor getESQueryInterceptor() {
		return new ESQueryInterceptor();
	}
	
	@Bean
	public MiriMetricHelperCacheInterceptor getMiriMetricHelperCacheInterceptor() {
		return new MiriMetricHelperCacheInterceptor();
	}
}
