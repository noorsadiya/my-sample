package com.miri.web.admin.manual.controllers;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.miri.search.data.BusinessImpactIndicatorData;
import com.miri.web.base.ResponseStatus;
import com.miri.web.base.ViewResponse;
import com.miri.web.base.WrappedViewResponse;
import com.miri.web.constants.WebConstants;
import com.miri.web.dashboard.assess.facade.AssessFacade;
import com.miri.web.interceptors.ErrorCodeContainer.ErrorCodeEnum;

/**
 * @author supraja
 *
 */
@RestController
@RequestMapping("/businessImpactIndicator")
public class BusinessImpactIndicatorController {
	private static final Logger LOG = Logger.getLogger(BusinessImpactIndicatorController.class);

	@Autowired
	private AssessFacade assessHelper;

	/**
	 *
	 * @param businessImpactIndicatorData
	 * @return
	 */
	@RequestMapping(value = WebConstants.SAVE, method = RequestMethod.POST)
	@ResponseBody
	public ViewResponse saveBusinessImpactIndicator(
			@RequestBody(required = true) final BusinessImpactIndicatorData bid) {
		LOG.debug("Enter into saveBusinessImpactIndicator" + bid);
		ViewResponse viewResponse = new ViewResponse();
		assessHelper.saveBusinessImpactIndicator(bid);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	@RequestMapping(value = WebConstants.GET, method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse getBusinessImpactindicatorDetails() {
		BusinessImpactIndicatorData businessImpactIndicatorData = assessHelper.getBusinessImpactindicatorDetails();
		ViewResponse viewResponse = new WrappedViewResponse<BusinessImpactIndicatorData>(businessImpactIndicatorData);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());

		return viewResponse;
	}

	/**
	 *
	 * @param datasourceResponse
	 * @param isSuccess
	 * @param code
	 */
	private void getResponse(ViewResponse viewResponse, boolean isSuccess, String code, String msg) {
		viewResponse.setSuccess(isSuccess);
		viewResponse.setAuthenticated(true);
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(code);
		responseStatus.setMessage(msg);
		viewResponse.setResponseStatus(responseStatus);
	}

}
