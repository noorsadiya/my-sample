package com.miri.configuration;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.miri.web.base.ResponseStatus;
import com.miri.web.base.WrappedViewResponse;

public class MiriAccessDeniedHandler implements AccessDeniedHandler {

    private ObjectMapper mapper = new ObjectMapper();

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response,
			AccessDeniedException accessDeniedException) throws IOException, ServletException {
		Map<String, Object> accessDeniedInfo = new HashMap<>();
		String message = "";
		Principal principal = request.getUserPrincipal();
		if (principal != null) {
			UsernamePasswordAuthenticationToken token = (UsernamePasswordAuthenticationToken) principal;
			User user = (User) token.getPrincipal();
			Collection<GrantedAuthority> authorities = user.getAuthorities();
			String commaDelimitedRoles = StringUtils.collectionToCommaDelimitedString(authorities);
			message = "Operation not permitted for role: " + commaDelimitedRoles;
			accessDeniedInfo.put("role", commaDelimitedRoles);
		}

		WrappedViewResponse<?> authResponse = new WrappedViewResponse<>(accessDeniedInfo);
		authResponse.setAuthenticated(false);
		authResponse.setSuccess(false);
		ResponseStatus responseStatus = new ResponseStatus(HttpStatus.FORBIDDEN.toString(), message, WrappedViewResponse.class.getName());
		authResponse.setResponseStatus(responseStatus);

		PrintWriter out = response.getWriter();
		out.print(mapper.writeValueAsString(authResponse));
		response.setContentType("application/json");
		response.setStatus(Integer.parseInt(HttpStatus.FORBIDDEN.toString()));
		out.close();
	}
}
