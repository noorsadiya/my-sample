package com.miri.web.auth;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.ExceptionTranslationFilter;


public class RestExceptionTranslationFilter extends ExceptionTranslationFilter {

	private static final String ERROR = "Error";
	private static final String APPLICATION_JSON = "application/json";

	private JSONObject jsonObject = null;

	public RestExceptionTranslationFilter(AuthenticationEntryPoint authenticationEntryPoint) {
		super(authenticationEntryPoint);
	}

	@Override
	protected void sendStartAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain,
			AuthenticationException reason) throws ServletException, IOException {

		response.setContentType(APPLICATION_JSON);
		response.setStatus(401);
		PrintWriter out = response.getWriter();

		jsonObject = new JSONObject();
		try {
			jsonObject.put(ERROR, reason.getMessage());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// These should not be passed in response
		jsonObject.remove("username");
		jsonObject.remove("password");

		out.print(jsonObject);
		out.flush();
		out.close();
		return;
	}
}
