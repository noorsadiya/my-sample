package com.miri.web.auth.data;

import java.io.Serializable;

/**
 * Application level information for the UI to perform action according to this response.
 * @author abhishek
 * Includes information such as Currency, completed setup page and sale stage verified etc.
 */
public class ApplicationInfo implements Serializable {
	
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -2354219179835521258L;
	
	private String currencyCode;
	private String completedStage;
	private Boolean isSaleStagesVerified;
	private String saleStageLevel;
	
	public ApplicationInfo() {
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getCompletedStage() {
		return completedStage;
	}

	public void setCompletedStage(String completedStage) {
		this.completedStage = completedStage;
	}
	
	/**
	 * @return the isSaleStagesVerified
	 */
	public Boolean getIsSaleStagesVerified() {
		return isSaleStagesVerified;
	}

	/**
	 * @param isSaleStagesVerified the isSaleStagesVerified to set
	 */
	public void setIsSaleStagesVerified(Boolean isSaleStagesVerified) {
		this.isSaleStagesVerified = isSaleStagesVerified;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ApplicationInfo [currencyCode=");
		builder.append(currencyCode);
		builder.append(", completedStage=");
		builder.append(completedStage);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the saleStageLevel
	 */
	public String getSaleStageLevel() {
		return saleStageLevel;
	}

	/**
	 * @param saleStageLevel the saleStageLevel to set
	 */
	public void setSaleStageLevel(String saleStageLevel) {
		this.saleStageLevel = saleStageLevel;
	}
}
