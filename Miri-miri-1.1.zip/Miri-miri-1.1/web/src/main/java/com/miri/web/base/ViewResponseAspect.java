package com.miri.web.base;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

import com.miri.search.utils.TimerUtil;
import com.miri.web.interceptors.ErrorCodeContainer.ErrorCodeEnum;

@Aspect
public class ViewResponseAspect {
	private static final Logger LOGGER = Logger.getLogger(ViewResponseAspect.class);

	@Pointcut("execution(public * com.miri.web.common.GenericChartController.*(..)) "
			+ "|| execution(public * com.miri.web.common.TokenController.*(..)) "
			+ "|| execution(public * com.miri.web.common.EmailController.*(..)) "
			+ "|| execution(public * com.miri.web.dashboard.controllers.explore.*.*(..)) "
			+ "|| execution(public * com.miri.web.dashboard.assess.controllers.*.*(..)) "
			+ "|| execution(public * com.miri.web.admin.controllers.*.*(..)) "
			+ "|| execution(public * com.miri.web.admin.manual.controllers.*.*(..)) "
			+ "|| execution(public * com.miri.web.dashboard.dataquality.controllers.*.*(..)) "
			+ "|| execution(public * com.miri.web.dashboard.explore.ExploreController.*(..)) "
			+ "|| execution(public * com.miri.web.license.LicenseCreationController.*(..)) "
			+ "|| execution(public * com.miri.web.license.LicenseValidationController.*(..)) "
			+ "|| execution(public * com.miri.web.auth.UserXAuthTokenController.*(..)) && !@annotation(com.miri.web.cache.DontIntercept)")

	public void interceptController() {
	}

	@Around("interceptController()")
	public Object interceptAndProcessRequest(ProceedingJoinPoint joinPoint) throws Throwable {
		TimerUtil timerUtil = new TimerUtil();
		timerUtil.start();
		ViewResponse viewResponse = null;
		Object returnValue = null;
		String interceptMessage = StringUtils.EMPTY;
		try {
			interceptMessage = joinPoint.getClass().getSimpleName() + " : " + joinPoint.getSignature().getName();
			LOGGER.info("Initiate controller request: " + interceptMessage);
			returnValue = joinPoint.proceed();
		} catch (Throwable e) {
			LOGGER.info("Error while processing request.", e);
			return handleNullResponse(viewResponse);
		}
		if (null == returnValue) {
			return handleNullResponseStatus(viewResponse);
		}

		viewResponse = (ViewResponse) returnValue;
		if (!viewResponse.isSuccess && (null == viewResponse.getResponseStatus()
				|| StringUtils.isBlank(viewResponse.getResponseStatus().getCode()))) {
			return handleNullResponseStatus(viewResponse);
		}
		if (viewResponse.isSuccess) {
			if (viewResponse.getResponseStatus() == null) {
				viewResponse.setResponseStatus(new ResponseStatus());
			}

			viewResponse.getResponseStatus().setCode(ErrorCodeEnum.MIRI_200.toString());
			if (StringUtils.isNotBlank(viewResponse.getResponseStatus().getMessage()))
				viewResponse.getResponseStatus().setMessage(ErrorCodeEnum.MIRI_200.getErrorMessage());
		}
		LOGGER.info("Time taken to complete the execution for: " + interceptMessage + " : "
				+ timerUtil.timeTakenInMillis());
		return viewResponse;
	}

	/**
	 *
	 * @param viewResponse
	 * @param miri404
	 * @param errorMessage
	 * @return
	 */
	private Object handleNullResponseStatus(ViewResponse viewResponse) {
		if (null == viewResponse)
			viewResponse = new ViewResponse();
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(ErrorCodeEnum.MIRI_400.toString());
		responseStatus.setMessage(ErrorCodeEnum.MIRI_400.getErrorMessage());
		viewResponse.setResponseStatus(responseStatus);
		return viewResponse;
	}

	private Object handleNullResponse(ViewResponse viewResponse) {
		if (null == viewResponse) {
			viewResponse = new ViewResponse();
			ResponseStatus responseStatus = new ResponseStatus();
			responseStatus.setCode(ErrorCodeEnum.MIRI_404.toString());
			responseStatus.setMessage(ErrorCodeEnum.MIRI_404.getErrorMessage());
			viewResponse.setResponseStatus(responseStatus);
		}

		return viewResponse;
	}

}
