package com.miri.web.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miri.data.jpa.domain.MailConfig;
import com.miri.data.jpa.repository.MailConfigRepository;

@Service
public class MailConfigService {

	@Autowired
	private MailConfigRepository mailConfigRepository;

	public void saveEmailConfigDetails(List<MailConfig> mailConfigs) {
		mailConfigRepository.deleteAll();
		mailConfigRepository.save(mailConfigs);
	}

	public List<MailConfig> getAllMailConfigs() {
		return mailConfigRepository.findAll();
	}
}
