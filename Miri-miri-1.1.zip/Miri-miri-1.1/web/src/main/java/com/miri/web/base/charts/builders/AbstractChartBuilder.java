/**
 * 
 */
package com.miri.web.base.charts.builders;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.miri.search.domain.guage.GaugePojo;
import com.miri.web.base.IChart;
import com.miri.web.base.charts.component.ChartComponent;
import com.miri.web.base.charts.component.GuageTable;
import com.miri.web.base.charts.component.MetricResponse;
import com.miri.web.constants.WebConstants;
import com.miri.web.utils.RangeCalculator;

/**
 * AbstractChartBuilder : provides single point entry to all chart building
 * requests.
 * 
 * @author Chandra
 *
 */

public abstract class AbstractChartBuilder {

	@Autowired 
	protected GuageTable guageTable;

	public abstract IChart buildChart(MetricResponse metricResponse);

	@SuppressWarnings("unchecked")
	public  List<Double[]> populateDollarRanges(MetricResponse metricResponse)
	{
		List<Double> allInvoices = (List<Double>)metricResponse.getItems().get(WebConstants.DOLLAR_DATA);
		List<Double[]> dollarRangeData = new  ArrayList<>();
		if(CollectionUtils.isNotEmpty(allInvoices)){
			dollarRangeData=RangeCalculator.getDollarFloorRangeList(allInvoices);
		}
		if(dollarRangeData.size() <= 1){
			return null;
		}
		return dollarRangeData;

	}

	public ChartComponent populateGuage(MetricResponse metricResponse) {
		GaugePojo guagePojo=(GaugePojo)metricResponse.getItems().get(WebConstants.GUAGE_DATA);

		String[] guageHeaders=(String[])metricResponse.getItems().get(WebConstants.GUAGE_HEADERS);

		if(guagePojo!=null){
			guageTable.setGuageRow(guagePojo.getGuageRow());
			guageTable.setGuageHeader(guageHeaders);
		}
		return guageTable;
	}

	public  double populateGuagePercentage(MetricResponse metricResponse) {
		double overAllGuagePercentage=0;
		GaugePojo guagePojo=(GaugePojo)metricResponse.getItems().get(WebConstants.GUAGE_DATA);

		if(guagePojo!=null){
			overAllGuagePercentage=guagePojo.getGuagePercentage();
		}
		return overAllGuagePercentage;
	}
	
	public Number populateYTDTarget(MetricResponse metricResponse){
		Number ytdTarget= (Number)metricResponse.getItems().get(WebConstants.CHART_YTD_TARGET);
		if(null != ytdTarget){
			return Math.round(ytdTarget.doubleValue());
		}
		return null;
	}

}
