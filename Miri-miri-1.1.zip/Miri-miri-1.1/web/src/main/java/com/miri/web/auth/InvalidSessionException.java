package com.miri.web.auth;

public class InvalidSessionException extends RuntimeException {

	public InvalidSessionException() {
		super();
	}

	public InvalidSessionException(String explanation) {
		super(explanation);
	}
}
