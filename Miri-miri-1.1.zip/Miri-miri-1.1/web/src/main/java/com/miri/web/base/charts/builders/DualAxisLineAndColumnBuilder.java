/**
 * 
 */
package com.miri.web.base.charts.builders;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.miri.web.base.IChart;
import com.miri.web.base.charts.component.MetricResponse;

/**
 * @author Chandra
 *
 */
@Component
@Scope("prototype")
public class DualAxisLineAndColumnBuilder extends AbstractChartBuilder {

	public IChart buildChart(MetricResponse metricResponse) {
		// TODO Auto-generated method stub
		return null;
	}

}
