/**
 * 
 */
package com.miri.web.base;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.miri.web.base.charts.component.ChartComponent;
import com.miri.web.base.charts.component.ChartMetadata;
import com.miri.web.base.charts.component.Series;

/**
 * @author Chandra
 *
 */
@Component
@JsonInclude(Include.NON_NULL)
@Scope("prototype")
public class Chart implements IChart {

	private ChartTypeEnum graphType;

	private boolean isFilterAvailable;

	private DrillDownType drillDownType;

	private ChartComponent xAxis;

	private ChartComponent legends;

	private ChartComponent yAxis;

	private ChartComponent chartMetadata;

	private List<Series> series;
	
	private ChartComponent hover;
	
	private List<Double[]> ranges;
	
	private ChartComponent parentData;
	
	private Number yTDTarget;
	
	private ChartComponent subTitle;
	
	private String footNote;
	
	public String getFootNote() {
		return footNote;
	}
	public void setFootNote(String footNote) {
		this.footNote = footNote;
	}

	public ChartComponent getChartMetadata() {
		return chartMetadata;
	}

	public void setChartMetadata(ChartComponent chartMetadata) {
		this.chartMetadata = chartMetadata;
	}


	public ChartComponent getLegends() {
		return legends;
	}

	public void setLegends(ChartComponent legends) {
		this.legends = legends;
	}


	public ChartTypeEnum getGraphType() {
		if (null == graphType && getChartMetadata() != null) {
			String type = ((ChartMetadata) getChartMetadata()).getGraphType();
			graphType = ChartTypeEnum.getChartMapper().get(type);
			setGraphType(graphType);
		}
		return graphType;
	}

	public void setGraphType(ChartTypeEnum graphType) {
		this.graphType = graphType;
	}


	public boolean isFilterAvailable() {
		return isFilterAvailable;
	}

	public void setFilterAvailable(boolean isFilterAvailable) {
		this.isFilterAvailable = isFilterAvailable;
	}

	public DrillDownType getDrillDownType() {
		return drillDownType;
	}

	public void setDrillDownType(DrillDownType drillDownType) {
		this.drillDownType = drillDownType;
	}

	public ChartComponent getxAxis() {
		return xAxis;
	}

	public void setxAxis(ChartComponent xAxis) {
		this.xAxis = xAxis;
	}

	public ChartComponent getyAxis() {
		return yAxis;
	}

	public void setyAxis(ChartComponent yAxis) {
		this.yAxis = yAxis;
	}

	public ChartComponent getHover() {
		return hover;
	}

	public void setHover(ChartComponent hover) {
		this.hover = hover;
	}

	public List<Series> getSeries() {
		return series;
	}

	public void setSeries(List<Series> series) {
		this.series = series;
	}
	
	public List<Double[]> getRanges() {
		return ranges;
	}

	public void setRanges(List<Double[]> ranges) {
		this.ranges = ranges;
	}

	public ChartComponent getParentData() {
		return parentData;
	}

	public void setParentData(ChartComponent parentData) {
		this.parentData = parentData;
	}
	
	public ChartComponent getSubTitle() {
		return subTitle;
	}

	public void setSubTitle(ChartComponent subTitle) {
		this.subTitle = subTitle;
	}
	
	public Number getyTDTarget() {
		return yTDTarget;
	}

	public void setyTDTarget(Number yTDTarget) {
		this.yTDTarget = yTDTarget;
	}
	
	
}
