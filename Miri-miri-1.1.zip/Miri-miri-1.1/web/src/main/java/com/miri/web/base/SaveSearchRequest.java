package com.miri.web.base;

import com.miri.web.dashboard.explore.ExploreSearchRequest;

public class SaveSearchRequest extends ExploreSearchRequest {
	private static final long serialVersionUID = -4417905822679145542L;

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}