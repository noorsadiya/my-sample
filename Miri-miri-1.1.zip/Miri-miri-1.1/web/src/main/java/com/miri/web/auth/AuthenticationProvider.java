package com.miri.web.auth;

import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.miri.data.jpa.domain.Authority;
import com.miri.data.jpa.domain.User;
import com.miri.web.common.services.UserService;

public class AuthenticationProvider extends DaoAuthenticationProvider {

	private final Logger log = LoggerFactory.getLogger(AuthenticationProvider.class);

	private PasswordEncoder passwordEncoder;

	@Inject
	private UserService userService;

	public AuthenticationProvider(PasswordEncoder passwordEncoder, UserService userService) {
		this.passwordEncoder = passwordEncoder;
		this.userService = userService;
	}

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		UsernamePasswordAuthenticationToken token = (UsernamePasswordAuthenticationToken) authentication;
		String login = token.getName().toLowerCase();
		log.debug("login : " + login);

		User user = getUserByLogin(login);

		String password = user.getPassword();
		String tokenPassword = (String) token.getCredentials();

		matchPasswords(password, tokenPassword);

		UserDetails userDetails = buildUserDetails(user);

		return new UsernamePasswordAuthenticationToken(userDetails, user.getPassword(), userDetails.getAuthorities());
	}

	/**
	 * Returns User from DB if User is Not ( Active | Deleted )
	 *
	 * @param login
	 * @return User
	 */
	private User getUserByLogin(String login) {
		User user = userService.findOneByUserName(login);
		if (user != null) {
			return user;
		} else {
			throw new UsernameNotFoundException("User does not exists");
		}

	}

	/**
	 * Handles password verification
	 *
	 * @param password
	 * @param tokenPassword
	 */
	private void matchPasswords(String password, String tokenPassword) {
		if (!passwordEncoder.matches(tokenPassword, password)) {
			throw new BadCredentialsException("Invalid username/password");
		}
	}

	/**
	 * build UserDetails Object with granted authorities
	 *
	 * @param user
	 * @return UserDetails
	 */
	private UserDetails buildUserDetails(User user) {
		List<GrantedAuthority> grantedAuthorities = new LinkedList<>();
		for (Authority authority : user.getAuthorities()) {
			grantedAuthorities.add(new SimpleGrantedAuthority(authority.getNameAsString()));
		}
		return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(),
				grantedAuthorities);
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return UsernamePasswordAuthenticationToken.class.equals(authentication);
	}
}
