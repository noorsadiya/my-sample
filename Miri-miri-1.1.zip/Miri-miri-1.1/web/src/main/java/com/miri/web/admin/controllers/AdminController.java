package com.miri.web.admin.controllers;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.miri.web.admin.facade.AdminFacade;
import com.miri.web.base.ResponseStatus;
import com.miri.web.base.ViewResponse;
import com.miri.web.base.WrappedViewResponse;
import com.miri.web.constants.WebConstants;
import com.miri.web.interceptors.ErrorCodeContainer.ErrorCodeEnum;

/**
 * @author supraja
 *
 */
@RestController
@RequestMapping("/admin")
public class AdminController {

	private static final Logger LOG = Logger.getLogger(AdminController.class);

	@Autowired
	AdminFacade adminFacade;

	@RequestMapping(value = WebConstants.SCHEDULER_STATUS, method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse getSchedulerStatus() {
		ViewResponse viewResponse = null;
		ResponseEntity<Object> schedulerStatus = adminFacade.getSchedulerStatus();
		Object jobResponse = schedulerStatus.getBody();
		viewResponse = new WrappedViewResponse<Object>(jobResponse);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
		return viewResponse;
	}

	@RequestMapping(value = WebConstants.SCHEDULER_RUN, method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse runScheduler() {
		LOG.debug("Enter into runScheduler");
		ViewResponse viewResponse = null;
		ResponseEntity<Object> responseEntity = adminFacade.runScheduler();
		Object jobResponse = responseEntity.getBody();
		viewResponse = new WrappedViewResponse<Object>(jobResponse);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
		return viewResponse;
	}

	@RequestMapping(value = WebConstants.SCHEDULER_UPDATE, method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse updateSchedulerFrequency(@RequestBody(required = true) Map<String, Object> frequencyDetails) {
		ViewResponse viewResponse = null;
		ResponseEntity<Object> responseEntity = adminFacade.updateSchedulerFrequency(frequencyDetails);
		Object jobResponse = responseEntity.getBody();
		viewResponse = new WrappedViewResponse<Object>(jobResponse);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
		return viewResponse;
	}

	@RequestMapping(value = WebConstants.GET_SCHEDULER_FREQUENCY+"/{jobName}", method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse getSchedulerFrequency(@PathVariable("jobName") final String jobName) {
		ViewResponse viewResponse = null;
		Map<String, Object> frequency = adminFacade.getSchedulerFrequency(jobName);
		viewResponse = new WrappedViewResponse<Map<String, Object>>(frequency);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
		return viewResponse;
	}

	@RequestMapping(value = WebConstants.SCHEDULER_JOB_NAMES, method = { RequestMethod.POST })
	@ResponseBody
	public ViewResponse getSchedulerJobNames() {
		ViewResponse viewResponse = null;
		ResponseEntity<Object> schedulerJobProperty = adminFacade.getSchedulerJobNames();
		Object jobPropertyResponse = schedulerJobProperty.getBody();
		viewResponse = new WrappedViewResponse<Object>(jobPropertyResponse);
		getResponse(viewResponse, true, ErrorCodeEnum.MIRI_200.toString(), ErrorCodeEnum.MIRI_200.getErrorMessage());
		return viewResponse;
	}


	/**
	 *
	 * @param datasourceResponse
	 * @param isSuccess
	 * @param code
	 */
	private void getResponse(ViewResponse viewResponse, boolean isSuccess, String code, String msg) {
		viewResponse.setSuccess(isSuccess);
		viewResponse.setAuthenticated(true);
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(code);
		responseStatus.setMessage(msg);
		viewResponse.setResponseStatus(responseStatus);
	}



}
