package com.miri.data.jpa.service;

import java.util.List;

import com.miri.data.jpa.domain.WebServiceGlobalConfiguration;

public interface AdminService {
	
	void saveOrUpdateVendorGlobalConfigs(List<WebServiceGlobalConfiguration>  configs, String jobName);
	
	List<WebServiceGlobalConfiguration> getSchedulerFrequencyByJob(String jobName);

}
