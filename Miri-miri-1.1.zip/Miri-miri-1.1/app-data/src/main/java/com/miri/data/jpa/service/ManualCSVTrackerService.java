/**
 * 
 */
package com.miri.data.jpa.service;

import java.util.List;

import com.miri.data.jpa.domain.ManualCSVTracker;

/**
 * @author Chandra
 *
 */
public interface ManualCSVTrackerService {

	public List<ManualCSVTracker> finalAllActive();
	
	public ManualCSVTracker saveOrUpdateCSVTracker(ManualCSVTracker manualCSVTracker);
	
	public ManualCSVTracker findByfileName(String fileName);
	
	public List<ManualCSVTracker> findByFileNameStartsWith(String fileName);
}
