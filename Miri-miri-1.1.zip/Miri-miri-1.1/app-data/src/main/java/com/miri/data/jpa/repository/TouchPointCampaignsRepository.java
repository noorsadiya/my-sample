package com.miri.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.TouchPointCampaigns;

@Repository
public interface TouchPointCampaignsRepository extends JpaRepository<TouchPointCampaigns, Long>{

	@Query("FROM TouchPointCampaigns tp WHERE tp.campaignId = ?1")
	public TouchPointCampaigns getTouchPointData(String campaignId);
	
	@Query("FROM TouchPointCampaigns tp WHERE tp.campaignId in (?1)")
	public List<TouchPointCampaigns> getTouchPointData(List<String> campaignIds);
	
	
}
