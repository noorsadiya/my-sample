package com.miri.data.jpa.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author noor
 * Entity for the database table  miri_document_critical_field which has all the fields and 
 * mapping to the documents
 */
@Entity
@Table(name="miri_document_critical_field")
public class MiriDocumentCriticalField implements  Serializable{
	
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -3593868579459046446L;

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	@JsonIgnore
	private Long id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="description")
	private String desctiption;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "miri_document_id")
	private MiriIndexDocument miriDocumentId;
	
	@Column(name="type")
	private String Type;
	
	@Column(name="sort_order")
	private int sortOrder;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesctiption() {
		return desctiption;
	}

	public void setDesctiption(String desctiption) {
		this.desctiption = desctiption;
	}

	public MiriIndexDocument getMiriDocumentId() {
		return miriDocumentId;
	}

	public void setMiriDocumentId(MiriIndexDocument miriDocumentId) {
		this.miriDocumentId = miriDocumentId;
	}

	public int getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}
	
	public String getType() {
		return Type;
	}
	
	public void setType(String type) {
		Type = type;
	}
	
	

}
