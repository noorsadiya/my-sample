package com.miri.data.jpa.repository;

import java.util.Date;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.ImpactIndicatorName;
import com.miri.data.jpa.domain.ImpactIndicatorTarget;

@Repository
public interface ImpactIndicatorTargetRepository extends JpaRepository<ImpactIndicatorTarget, Long> {

	@Query("FROM ImpactIndicatorTarget iit WHERE iit.indicatorName = ?1 AND iit.validFrom >= ?2")
	Page<ImpactIndicatorTarget> findByName(ImpactIndicatorName impactIndicatorName, Date fiscalStartDate, Pageable pageable);

	@Modifying(clearAutomatically = true)
	@Query("UPDATE ImpactIndicatorTarget iit SET iit.targetValue = ?2 WHERE iit.indicatorName = ?1 AND iit.validFrom >= ?3 ")
	void updateAllTargetValuesForIndicatorName(ImpactIndicatorName indicatorName, Number targetValue, Date fiscalStartDate);

}
