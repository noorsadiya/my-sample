package com.miri.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.MiriDocumentCriticalField;
import com.miri.data.jpa.domain.MiriIndexDocument;

/**
 * MiriDocumentCriticalFieldRepository: that provides  methods to perform database operations on miri_document_critical_field table
 * @author noor
 */
@Repository
public interface MiriDocumentCriticalFieldRepository extends JpaRepository<MiriDocumentCriticalField, Long>{
	
	List<MiriDocumentCriticalField> findAll();
	
	@Query("from MiriDocumentCriticalField mid where mid.miriDocumentId = ?1")
	List<MiriDocumentCriticalField> findAllByDocumentId(MiriIndexDocument documentId);
	
}
