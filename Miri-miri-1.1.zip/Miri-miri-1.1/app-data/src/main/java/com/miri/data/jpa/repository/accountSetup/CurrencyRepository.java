package com.miri.data.jpa.repository.accountSetup;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.miri.data.jpa.domain.Currency;

public interface CurrencyRepository extends JpaRepository<Currency, Long> {

	@Query("from Currency cc where LOWER(cc.name) = ?1")
	Currency findOneByName(String currencyName);

	List<Currency> findByCodeIn(Collection<String> currencyCodes);
}
