package com.miri.data.jpa.service;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.miri.data.jpa.domain.BusinessStrategyConfigurations;
import com.miri.data.jpa.domain.CampaignStrategy;
import com.miri.data.jpa.domain.CrmInstance;
import com.miri.data.jpa.domain.CrmInstanceSalesStage;
import com.miri.data.jpa.domain.Currency;
import com.miri.data.jpa.domain.LocalCrmSalesStage;
import com.miri.data.jpa.domain.WebServiceVendor;
import com.miri.data.jpa.domain.WebServiceVendorConfiguration;

public interface ManualInputService {

	void updateCampaignManualInput(String campaignId, String campaignName, String parentCampaignId,
			String parentCampaignName, String newCampaignName, Double campaignCost, Date startDate, Date currentDate,
			boolean isDraft, Set<String> editableFields, Date rangeStart, Date rangeEnd);

	CampaignStrategy getRecentlyUpdatedManualCampaignInput();

	CampaignStrategy getCampaignStrategy(String campaignName, Date rangeStart, Date rangeEnd);

	Map<String, String> getParentCampaignInfo(Date rangeStart, Date rangeEnd);

	boolean checkParentCampaignAvailability(Set<String> vendors);

	String getCompletedSetupStage();

	Currency getAccountCurrency();

	String getAccountLogo();

	Date getFiscalStartDate();

	List<WebServiceVendor> getDatasourceSetupDetails();

	WebServiceVendor getDatasourceSetup(String vendorType, String vendorName, String instanceName, String version);

	Map<String, Object> getFlattenedConfig(WebServiceVendor webServiceVendor);

	List<WebServiceVendor> saveOrUpdateVendors(List<Map<String, Object>> vendorsConfigs, boolean isDraft, boolean isCrmVendor);

	List<String> getVendorNames(String vendorType);

	List<CrmInstanceSalesStage> getSalesStageMapping(String vendorName, String instanceName);

	List<LocalCrmSalesStage> getLocalSalesStages();

	void saveCrmSalesStageMapping(Collection<CrmInstanceSalesStage> crmInstanceSalesStageMappings);

	List<CrmInstanceSalesStage> getCrmInstanceSaleStages();

	List<BusinessStrategyConfigurations> findAllBusinessStrategyConfigurations();

	Map<String, Map<String, BusinessStrategyConfigurations>> getBusinessStrategyConfigurations();

	void saveOrUpdateBusinessStrategy(List<BusinessStrategyConfigurations> businessRevenueList,
			List<BusinessStrategyConfigurations> miRevenueList);

	CrmInstance getCrmInstanceByName(String instanceName);

	LocalCrmSalesStage getLocalCrmSaleStageByName(String stageName);

	void saveWebServiceVendorConguration(WebServiceVendorConfiguration webServiceVendorConfiguration);

	List<CrmInstanceSalesStage> getSalesStageMappingAndNullLocalStage(String vendorName, String instanceName);
	
	void saveCrmInstanceData(CrmInstance crmInstance);
	
	void deleteCrmSaleStages(List<CrmInstanceSalesStage> crmSaleStages);
}
