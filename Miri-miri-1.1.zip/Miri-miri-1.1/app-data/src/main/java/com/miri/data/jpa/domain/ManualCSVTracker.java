package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "manual_csv_tracker")
public class ManualCSVTracker implements Serializable {

	private static final long serialVersionUID = -9086174469738215387L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@JsonIgnore
	private Long id;

	@Column(name = "filename")
	private String fileName;

	@Column(name = "from_value")
	private int fromValue;

	@Column(name = "to_value")
	private int toValue;

	@Column(name = "vendor_type")
	private String vendorType;

	@Column(name = "status")
	@JsonIgnore
	private String status;

	@Column(name = "created_date", insertable = false, updatable = false)
	@JsonIgnore
	private Date createdDate;

	@Column(name = "last_modified_date", insertable = false, updatable = false)
	@JsonIgnore
	private Date lastModifiedDate;

	public ManualCSVTracker(String fileName, int fromNumber, int toNumber, String vendorType, String status) {
		super();
		this.fileName = fileName;
		this.fromValue = fromNumber;
		this.toValue = toNumber;
		this.vendorType = vendorType;
		this.status = status;
	}
	
	// Default constructor
	public ManualCSVTracker() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getFromNumber() {
		return fromValue;
	}

	public void setFromValue(int fromValue) {
		this.fromValue = fromValue;
	}

	public int getToValue() {
		return toValue;
	}

	public void setToValue(int toValue) {
		this.toValue = toValue;
	}

	public String getVendorType() {
		return vendorType;
	}

	public void setVendorType(String vendorType) {
		this.vendorType = vendorType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	/*@Override
	public String toString() {
		return "ManualCSVTracker [id=" + id + ", fileName=" + fileName + ", from=" + fromValue + ", to=" + toValue
				+ ", vendorType=" + vendorType + ", status=" + status + ", createdDate=" + createdDate
				+ ", lastModifiedDate=" + lastModifiedDate + "]";
	}*/

}