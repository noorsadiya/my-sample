package com.miri.data.jpa.service;

import java.util.List;

import com.miri.data.jpa.domain.SavedSearch;

public interface SaveSearchService {

	SavedSearch retrieveLasteSavedSearch(String userName);

	List<SavedSearch> retrieveSavedSearches(String userName);

	void saveSearchRequest(String name, String searchKey,  String userName);

	void deleteSavedSearch(String name, String createdBy);
}
