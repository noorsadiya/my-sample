package com.miri.data.jpa.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.miri.data.jpa.domain.ImpactIndicatorHistory;
import com.miri.data.jpa.domain.ImpactIndicatorName;
import com.miri.data.jpa.domain.ImpactIndicatorTarget;

public interface ImpactIndicatorService {

	/**
	 * Fetch the latest manual input target for given {@link ImpactIndicatorName}
	 *
	 * @param impactIndicatorName manualInputType for which latest target value is to be fetched
	 * @param fiscalStartDate fiscal start date
	 * @return latest manual input target for given manualInputType
	 */
	ImpactIndicatorTarget fetchImpactIndicatorTarget(ImpactIndicatorName impactIndicatorName, Date fiscalStartDate);

	/**
	 * Fetch all the latest manual input target for given {@link ImpactIndicatorName}
	 *
	 * @param impactIndicatorName manualInputType for which latest target value is to be fetched
	 * @param fiscalStartDate fiscal start date
	 * @return latest manual input target for given manualInputType
	 */
	List<ImpactIndicatorTarget> fetchAllImpactIndicatorTarget(ImpactIndicatorName indicatorName, Date fiscalStartDate);

	/**
	 * Update the given targetValue for the given {@link ImpactIndicatorName} along with other data. ValidityPeriod
	 * would be expanded to the validFrom & validTo dates by the implementation.
	 *
	 * @param impactIndicatorName manualInputType for which latest target value is to be updated
	 * @param targetValue target value to update
	 * @param validityPeriod ValidityPeriod for which the value is to be updated
	 * @param fiscalStartDate fiscal start date
	 */
	void updateImpactIndicatorTarget(ImpactIndicatorName impactIndicatorName, Number targetValue,
			ValidityPeriod validityPeriod, Date fiscalStartDate);

	void updateImpactIndicatorTarget(ImpactIndicatorName impactIndicatorName, Number targetValue,
			ValidityPeriod validityPeriod, Date fiscalStartDate, Date createdDate, Date lastModifiedDate);
	
	/**
	 *  Save the all impact indicator history values
	 * @param indicatorHistory
	 */
	void saveImpactIndicatorHistory(Map<ImpactIndicatorName, Number> indicatorHistory);
	
	/**
	 * Fetch history/Trend values
	 * @param impactIndicatorName
	 * @return
	 */
	ImpactIndicatorHistory getImpactIndicatorTrendvalue(ImpactIndicatorName impactIndicatorName);

	enum ValidityPeriod {
		Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec, FISCAL
	}
}
