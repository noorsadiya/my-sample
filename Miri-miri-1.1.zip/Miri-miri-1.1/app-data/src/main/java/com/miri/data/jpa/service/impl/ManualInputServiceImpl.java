package com.miri.data.jpa.service.impl;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.parboiled.common.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.miri.data.jpa.domain.Account;
import com.miri.data.jpa.domain.BusinessStrategyConfigurations;
import com.miri.data.jpa.domain.CampaignStrategy;
import com.miri.data.jpa.domain.CrmInstance;
import com.miri.data.jpa.domain.CrmInstanceSalesStage;
import com.miri.data.jpa.domain.Currency;
import com.miri.data.jpa.domain.LocalCrmSalesStage;
import com.miri.data.jpa.domain.WebServiceVendor;
import com.miri.data.jpa.domain.WebServiceVendorConfiguration;
import com.miri.data.jpa.repository.accountSetup.AccountSetupRepository;
import com.miri.data.jpa.repository.businessStrategy.BusinessStrategyConfigurationRepository;
import com.miri.data.jpa.repository.campaignStrategy.CampaignStrategyRepository;
import com.miri.data.jpa.repository.datasourceSetup.CrmInstanceRepository;
import com.miri.data.jpa.repository.datasourceSetup.CrmInstanceSalesStageRepository;
import com.miri.data.jpa.repository.datasourceSetup.LocalCrmSalesStageRepository;
import com.miri.data.jpa.repository.datasourceSetup.WebServiceVendorConfigurationRepository;
import com.miri.data.jpa.repository.datasourceSetup.WebServiceVendorRepository;
import com.miri.data.jpa.service.ManualInputService;
import com.miri.data.jpa.util.EncryptionUtil;

@Service
@Transactional
public class ManualInputServiceImpl implements ManualInputService {
	private static final Logger LOGGER = Logger.getLogger(ManualInputServiceImpl.class);

	private static final Set<String> vendorConfigKeysToSkip = new HashSet<>();
	private static final String WEBSERVICE_VENDORTYPE = "vendorType";
	private static final String WEBSERVICE_VENDORNAME = "vendorName";
	private static final String WEBSERVICE_INSTANCENAME = "instanceName";
	private static final String WEBSERVICE_VENDORVERSION = "version";

	static {
		vendorConfigKeysToSkip.add(WEBSERVICE_VENDORTYPE);
		vendorConfigKeysToSkip.add(WEBSERVICE_VENDORNAME);
		vendorConfigKeysToSkip.add(WEBSERVICE_INSTANCENAME);
		vendorConfigKeysToSkip.add(WEBSERVICE_VENDORVERSION);
	}

	@Autowired
	private AccountSetupRepository accountSetupRepository;

	@Autowired
	private CampaignStrategyRepository campaignStrategyRepository;

	@Autowired
	private WebServiceVendorRepository webServiceVendorRepository;

	@Autowired
	private CrmInstanceSalesStageRepository crmInstanceSalesStageRepository;

	@Autowired
	private LocalCrmSalesStageRepository localCrmSalesStageRepository;

	@Autowired
	private BusinessStrategyConfigurationRepository businessStrategyConfigurationRepository;

	@Autowired
	private CrmInstanceRepository crmInstanceRepository;

	@Autowired
	private WebServiceVendorConfigurationRepository webServiceVendorConfigurationRepository;

	@Override
	public Map<String, String> getParentCampaignInfo(final Date rangeStart, final Date rangeEnd) {
		Map<String, String> parentCampaignsInfo = Collections.emptyMap();

		Sort sort = new Sort(Direction.ASC, "parentCampaignName");
		List<Object[]> parentCampaignIdAndNames = campaignStrategyRepository.getParentCampaignIdAndName(rangeStart, rangeEnd, sort);
		if (!CollectionUtils.isEmpty(parentCampaignIdAndNames)) {
			parentCampaignsInfo = new LinkedHashMap<>();
			for (Object[] parentCampaignIdAndName : parentCampaignIdAndNames) {
				String parentCampaignId = (String)parentCampaignIdAndName[0];
				String parentCampaignName = (String)parentCampaignIdAndName[1];
				// use name as Id, we don't always get parentCampaignId from data sources
				parentCampaignId = StringUtils.isNotEmpty(parentCampaignId) ? parentCampaignId : parentCampaignName;
				parentCampaignsInfo.put(parentCampaignId, parentCampaignName);
			}
		}
		return parentCampaignsInfo;
	}

	public boolean checkParentCampaignAvailability(final Set<String> vendors) {
		return !CollectionUtils.isEmpty(vendors) && vendors.contains("crm_salesforce") || true;
	}

	@Override
	public void updateCampaignManualInput(final String campaignId, final String campaignName, final String parentCampaignId, final String parentCampaignName,
			final String newCampaignName, final Double campaignCost, final Date startDate, final Date currentDate, final boolean isDraft,
			Set<String> editableFields, final Date rangeStart, final Date rangeEnd) {
		// 1. Save/Update in DB
		String lowerCampaignName = campaignName != null ? campaignName.toLowerCase() : campaignName;
		CampaignStrategy campaignStrategy = campaignStrategyRepository.findOneByCampaignName(lowerCampaignName, rangeStart, rangeEnd);
		if (campaignStrategy == null) {
			campaignStrategy = new CampaignStrategy();
			campaignStrategy.setCreatedDate(currentDate);
		}
		campaignStrategy.setCampaignId(campaignId);
		campaignStrategy.setCampaignName(campaignName);
		campaignStrategy.setCampaignStartDate(startDate);
		campaignStrategy.setParentCampaignId(parentCampaignId);
		campaignStrategy.setParentCampaignName(parentCampaignName);
		campaignStrategy.setNewCampaignName(newCampaignName);
		campaignStrategy.setTotalCampaignCost(campaignCost);
		campaignStrategy.setUpdatedDate(currentDate);
		campaignStrategy.setDraft(isDraft);
		campaignStrategy.setEditableFields(editableFields);
		// save into DB
		campaignStrategyRepository.saveAndFlush(campaignStrategy);
	}

	@Override
	public CampaignStrategy getRecentlyUpdatedManualCampaignInput() {
		CampaignStrategy campaignStrategy = null;

		Pageable pageable = new PageRequest(0, 1, Direction.DESC, "updatedDate");
		Page<CampaignStrategy> campaignPage = campaignStrategyRepository.findAll(pageable);

		if (campaignPage.hasContent()) {
			List<CampaignStrategy> content = campaignPage.getContent();
			campaignStrategy = content.get(0);
		}

		return campaignStrategy;
	}

	@Override
	public CampaignStrategy getCampaignStrategy(String campaignName, Date rangeStart, Date rangeEnd) {
		return campaignStrategyRepository.findOneByCampaignName(campaignName, rangeStart, rangeEnd);
	}

	@Override
	public String getCompletedSetupStage() {
		String completedSetupStage = "";

		Account account = accountSetupRepository.findOne(Long.valueOf(1l));

		if (account != null && !account.isDraft()) {
			completedSetupStage = "accountSetup";
		}

		if (StringUtils.isNotEmpty(completedSetupStage)) {
			List<WebServiceVendor> activeConfigs = webServiceVendorRepository.findActiveConfigurations();
			if (!CollectionUtils.isEmpty(activeConfigs)) {
				boolean isAnyConfigInDraft = false;
				for (WebServiceVendor webServiceVendor : activeConfigs) {
					isAnyConfigInDraft = isAnyConfigInDraft || webServiceVendor.isDraft();
				}
				if (!isAnyConfigInDraft) {
					completedSetupStage = "dataSourceSetup";
				}
			}
		}

		return completedSetupStage;
	}

	@Override
	public Currency getAccountCurrency() {
		Currency currency = null;
		List<Account> accounts = accountSetupRepository.findAll();
		if (!CollectionUtils.isEmpty(accounts)) {
			Account account = accounts.get(0);
			currency = account.getCurrency();
		}
		return currency;
	}

	@Override
	public String getAccountLogo() {
		byte[] logo = accountSetupRepository.getLogo();
		if (logo != null) {
			return new String(logo, Charset.forName("UTF-8"));
		}
		return "";
	}

	@Override
	public Date getFiscalStartDate() {
		Date fiscalStartDate = null;
		Sort sort = new Sort(Direction.DESC, "createdAt");
		List<Account> accounts = accountSetupRepository.findAll(sort);
		if (!CollectionUtils.isEmpty(accounts)) {
			Account account = accounts.get(0);
			fiscalStartDate = account.getFiscalStart();
		}
		return fiscalStartDate;
	}

	@Override
	public List<WebServiceVendor> getDatasourceSetupDetails() {
		return webServiceVendorRepository.findActiveConfigurations();
	}

	@Override
	public WebServiceVendor getDatasourceSetup(String vendorType, String vendorName, String instanceName,
			String version) {
		WebServiceVendor webServiceVendor = null;
		Sort sort = new Sort(Direction.DESC, "lastModifiedDate");
		List<WebServiceVendor> content = webServiceVendorRepository.findVendorConfig(vendorType, vendorName, instanceName, sort);

		if (!CollectionUtils.isEmpty(content)) {
			for (WebServiceVendor webServiceVendorToCompare : content) {
				String versionToCompare = webServiceVendorToCompare.getVersion();
				String instanceNameToCompare = webServiceVendorToCompare.getInstanceName();
				if (instanceNameToCompare.equals(instanceName) && (versionToCompare.equals(version)
						|| (StringUtils.isEmpty(versionToCompare) &&  StringUtils.isEmpty(version)))) {
					webServiceVendor = webServiceVendorToCompare;
					break;
				}
			}
		}
		return webServiceVendor;
	}


	public Map<String, Object> getFlattenedConfig(WebServiceVendor webServiceVendor) {
		Map<String, Object> vendorConfig = new HashMap<>();

		vendorConfig.put(WEBSERVICE_VENDORTYPE, webServiceVendor.getVendorType());
		vendorConfig.put(WEBSERVICE_VENDORNAME, webServiceVendor.getVendorName());
		vendorConfig.put(WEBSERVICE_INSTANCENAME, webServiceVendor.getInstanceName());
		vendorConfig.put(WEBSERVICE_VENDORVERSION, webServiceVendor.getVersion());

		Set<WebServiceVendorConfiguration> configurations = webServiceVendor.getConfiguration();
		for (WebServiceVendorConfiguration configuration : configurations) {
			String attributeName = configuration.getAttributeName();
			String attributeValue = configuration.getAttributeValue();
			if (attributeName.startsWith("show")) { // detect show/hide FE props
				vendorConfig.put(attributeName, Boolean.valueOf(attributeValue));
			} else if ("isConnected".equals(attributeName) || attributeName.startsWith("bool_")) {
				vendorConfig.put(attributeName, Boolean.valueOf(attributeValue));
			}else {
				vendorConfig.put(attributeName, attributeValue);
			}
		}
		return vendorConfig;
	}

	public List<WebServiceVendor> saveOrUpdateVendors(List<Map<String, Object>> vendorConfigs, boolean isDraft, boolean isCrmVendor) {
		List<WebServiceVendor> webServiceVendorList = new ArrayList<>();
		for (Map<String, Object> vendorConfig : vendorConfigs) {
			if (skipSave(vendorConfig)) { // values might be coming null/empty
				continue;
			}
			String vendorType = castValue(vendorConfig.get(WEBSERVICE_VENDORTYPE));
			String vendorName = castValue(vendorConfig.get(WEBSERVICE_VENDORNAME));
			String instanceName = castValue(vendorConfig.get(WEBSERVICE_INSTANCENAME));
			String version = castValue(vendorConfig.get(WEBSERVICE_VENDORVERSION));
			version = version != null ? version : "";

			WebServiceVendor webServiceVendor = getDatasourceSetup(vendorType, vendorName, instanceName, version);
			if (webServiceVendor != null) {
				crmInstanceRepository.deleteForWebServiceVendor(webServiceVendor.getId());
				webServiceVendorRepository.delete(webServiceVendor);
				crmInstanceRepository.flush();
				webServiceVendorRepository.flush();
			}
			if (StringUtils.isEmpty(instanceName)) {
				//TODO: decide instance name logic
				instanceName = String.valueOf(System.currentTimeMillis());
			}
			webServiceVendor = new WebServiceVendor(vendorType, instanceName, vendorName, version);
			webServiceVendor.setStatus(true);
			webServiceVendor.setDraft(isDraft);

			Object isConnectedValue = vendorConfig.get("isConnected");
			webServiceVendor.setConnected(Boolean.valueOf(String.valueOf(isConnectedValue)));

			Set<WebServiceVendorConfiguration> newConfiguration = new HashSet<>();

			Set<Entry<String, Object>> entrySet = vendorConfig.entrySet();
			for (Entry<String, Object> entry : entrySet) {
				String attributeName = entry.getKey();
				if (vendorConfigKeysToSkip.contains(attributeName)/* || attributeName.startsWith("show")*/) {
					continue;
				}
				String attributeValue = String.valueOf(entry.getValue());
				if (isPasswordField(attributeName)) {
					attributeValue = EncryptionUtil.encrypt(attributeValue);
				}
				newConfiguration.add(new WebServiceVendorConfiguration(webServiceVendor, attributeName, attributeValue));
			}
			webServiceVendor.setConfiguration(newConfiguration);
			webServiceVendorRepository.saveAndFlush(webServiceVendor);

			if (isCrmVendor) {
				CrmInstance crmInstance = new CrmInstance();
				crmInstance.setName(vendorName+"_"+instanceName);
				crmInstance.setWebServiceVendor(webServiceVendor);
				crmInstanceRepository.saveAndFlush(crmInstance);
				LOGGER.debug("After : "+webServiceVendor);
			}
			webServiceVendorList.add(webServiceVendor);
		}
		return webServiceVendorList;
	}

	private boolean skipSave(Map<String, Object> vendorConfig) {
		boolean skipSave = false;
		String vendorName = castValue(vendorConfig.get(WEBSERVICE_VENDORNAME));
		if (StringUtils.isEmpty(vendorName)) {
			skipSave = true;
		} else if ("csv".equals(vendorName)) {
			Object ftpHost = vendorConfig.get("ftp_host");
			if (ftpHost instanceof String && StringUtils.isEmpty((String)ftpHost)) {
				skipSave = true;
			}
		}
		return skipSave;
	}

	private boolean isPasswordField(String attributeName) {
		return attributeName != null &&
				(attributeName.toLowerCase().endsWith("password")
						//						&& attributeName.toLowerCase().endsWith("clientsecret")
						&& !attributeName.startsWith("show"));
	}

	private static String castValue(Object value) {
		return (String) value;
	}

	@Override
	public List<String> getVendorNames(String vendorType) {
		List<String> allVendorNames = webServiceVendorRepository.getAllVendorNames(vendorType);
		allVendorNames.add("csv"); // TODO: to be removed once we integrate with crm vendors
		return allVendorNames;
	}

	@Override
	public List<CrmInstanceSalesStage> getSalesStageMapping(String vendorName, String instanceName) {
		Sort sort = new Sort(Direction.DESC, "salesStageName");
		String vendor = "";
		if(StringUtils.isNotEmpty(vendorName) && StringUtils.isNotEmpty(instanceName)) {
			vendor = vendorName + "_" + instanceName;
		} else {
			vendor = vendorName;
		}
		return crmInstanceSalesStageRepository.findByVendor(vendor, sort);
	}

	@Override
	public List<LocalCrmSalesStage> getLocalSalesStages() {
		return localCrmSalesStageRepository.findAll();
	}

	@Override
	public void saveCrmSalesStageMapping(Collection<CrmInstanceSalesStage> crmInstanceSalesStageMappings) {
		crmInstanceSalesStageRepository.save(crmInstanceSalesStageMappings);
		crmInstanceSalesStageRepository.flush();
	}

	@Override
	public List<CrmInstanceSalesStage> getCrmInstanceSaleStages() {
		return crmInstanceSalesStageRepository.findAll();
	}

	@Override
	public List<BusinessStrategyConfigurations> findAllBusinessStrategyConfigurations() {
		return businessStrategyConfigurationRepository.findAll();
	}

	@Override
	public Map<String, Map<String, BusinessStrategyConfigurations>> getBusinessStrategyConfigurations() {
		Map<String, Map<String, BusinessStrategyConfigurations>> configsMap = new HashMap<>();

		List<BusinessStrategyConfigurations> configs = businessStrategyConfigurationRepository.findAll();
		for (BusinessStrategyConfigurations businessStrategyConfiguration : configs) {
			Map<String, BusinessStrategyConfigurations> revenueMap = configsMap.get(businessStrategyConfiguration.getRevenueName());
			if (revenueMap == null) {
				revenueMap = new HashMap<>();
				configsMap.put(businessStrategyConfiguration.getRevenueName(), revenueMap);
			}
			revenueMap.put(businessStrategyConfiguration.getMonthName(), businessStrategyConfiguration);
		}


		return configsMap;
	}

	@Override
	public void saveOrUpdateBusinessStrategy(List<BusinessStrategyConfigurations> businessRevenueList,
			List<BusinessStrategyConfigurations> miRevenueList) {
		businessStrategyConfigurationRepository.save(businessRevenueList);
		businessStrategyConfigurationRepository.save(miRevenueList);
	}

	@Override
	public CrmInstance getCrmInstanceByName(String instanceName) {
		return crmInstanceRepository.findByName(instanceName);
	}

	@Override
	public LocalCrmSalesStage getLocalCrmSaleStageByName(String stageName) {
		return localCrmSalesStageRepository.findByStageName(stageName);
	}

	@Override
	public void saveWebServiceVendorConguration(WebServiceVendorConfiguration webServiceVendorConfiguration) {
		webServiceVendorConfigurationRepository.saveAndFlush(webServiceVendorConfiguration);
	}

	@Override
	public List<CrmInstanceSalesStage> getSalesStageMappingAndNullLocalStage(String vendorName, String instanceName) {
		return crmInstanceSalesStageRepository.findByCrmInstanceNameAndLocalCrmSalesStageIsNull(vendorName + "_" + instanceName);
	}

	@Override
	public void saveCrmInstanceData(CrmInstance crmInstance) {
		crmInstanceRepository.saveAndFlush(crmInstance);
	}

	@Override
	public void deleteCrmSaleStages(List<CrmInstanceSalesStage> crmSaleStages) {
		for(CrmInstanceSalesStage crmInstanceSaleStage: crmSaleStages)
			crmInstanceSalesStageRepository.deleteById(crmInstanceSaleStage.getId());
	}
}
