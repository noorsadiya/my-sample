package com.miri.data.jpa.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miri.data.jpa.domain.WebServiceGlobalConfiguration;
import com.miri.data.jpa.repository.datasourceSetup.WebServiceGlobalConfigurationRepository;
import com.miri.data.jpa.service.AdminService;

/**
 * @author supraja
 *
 */
@Transactional
@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	WebServiceGlobalConfigurationRepository webServiceGlobalConfigurationRepository;

	@Override
	public void saveOrUpdateVendorGlobalConfigs(List<WebServiceGlobalConfiguration> configsList, String jobName) {
		
		webServiceGlobalConfigurationRepository.deleteAllByAttributeName(jobName);

		webServiceGlobalConfigurationRepository.save(configsList);
	}

	@Override
	public List<WebServiceGlobalConfiguration> getSchedulerFrequencyByJob(String jobName) {
		return webServiceGlobalConfigurationRepository.findAllByAttributeName(jobName);
	}

}
