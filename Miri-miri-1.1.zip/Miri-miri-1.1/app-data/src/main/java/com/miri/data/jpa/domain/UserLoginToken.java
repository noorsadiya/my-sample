package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.miri.data.jpa.domain.util.CustomDateTimeSerializer;

/**
 * A UserLoginToken.
 */
@Entity
@Table(name = "USER_LOGIN_TOKEN")
public class UserLoginToken implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@JsonSerialize(using = CustomDateTimeSerializer.class)
	@Column(name = "created_time", length = 200)
	private Date createdTime;

	@ManyToOne
	private User user;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		UserLoginToken userLoginToken = (UserLoginToken) o;

		if (!Objects.equals(id, userLoginToken.id))
			return false;

		return true;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(id);
	}

	@Override
	public String toString() {
		return "UserLoginToken{" + "id=" + id + ", createdTime='" + createdTime + "'" + '}';
	}
}
