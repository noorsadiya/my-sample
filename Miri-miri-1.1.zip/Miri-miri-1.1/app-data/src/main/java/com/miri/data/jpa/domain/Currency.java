package com.miri.data.jpa.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.miri.data.jpa.util.CurrencyConstants;

@Entity
@Table(name = "currency")
public class Currency implements Serializable {

	private static final long serialVersionUID = 5455880101940769635L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long value;

	@Column(name = "currency_name")
	private String name;

	@Column(name = "currency_code")
	private String code;

	public Currency() {

	}

	public Long getValue() {
		return value;
	}

	public void setValue(Long value) {
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Currency other = (Currency) obj;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Currency [value=").append(value).append(", name=").append(name).append(", code=").append(code)
				.append("]");
		return builder.toString();
	}
	
	public String getCurrencySymbol(){
		String symbol = CurrencyConstants.USD_SYMBOL;
		switch(code) {
		case CurrencyConstants.USD:
			symbol = CurrencyConstants.USD_SYMBOL;
			break;
		case CurrencyConstants.GBP:
			symbol = CurrencyConstants.GBP_SYMBOL;
			break;
		case CurrencyConstants.EUR:
			symbol = CurrencyConstants.EUR_SYMBOL;
			break;
		default:
			symbol = CurrencyConstants.USD_SYMBOL;
		}
		return symbol;
	}

}
