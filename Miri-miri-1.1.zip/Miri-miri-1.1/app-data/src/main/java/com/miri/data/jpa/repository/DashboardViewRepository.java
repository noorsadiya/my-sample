package com.miri.data.jpa.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.DashboardView;

@Repository
public interface DashboardViewRepository extends JpaRepository<DashboardView, Long> {

	@Modifying(clearAutomatically = true)
	@Query("DELETE FROM DashboardView dv WHERE dv.url = ?1 AND dv.createdBy = ?2")
	void delete(String url, String createdBy);
	
	Page<DashboardView> findByCreatedBy(String createdBy, Pageable pageable);
	
	List<DashboardView> findByCreatedBy(String createdBy);
	
	long countByCreatedBy(String createdBy);
}
