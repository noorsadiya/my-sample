package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.miri.data.jpa.domain.util.StringSetConverter;

/**
 * @author supraja
 *
 */
@Entity
@Table(name = "manual_campaign_input")
public class CampaignStrategy implements Serializable {
	private static final long serialVersionUID = 8442364944134603399L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "campaign_id")
	private String campaignId;

	@Column(name = "campaign_name")
	private String campaignName;

	@Column(name = "parent_campaign_id")
	private String parentCampaignId;

	@Column(name = "parent_campaign_name")
	private String parentCampaignName;

	@Column(name = "start_date")
	private Date campaignStartDate;

	@Column(name = "touch_point_label")
	private String touchPointLable;

	@Column(name = "new_campaign_name")
	private String newCampaignName;

	@Column(name = "total_campaign_cost")
	private Double totalCampaignCost;

	@Column(name = "draft")
	@JsonIgnore
	private boolean draft;

	@Column(name = "editable_column")
	@Convert(converter=StringSetConverter.class)
	@JsonIgnore
	private Set<String> editableFields;

	@Column(name = "created_date", insertable = false, updatable = false)
	private Date createdDate;

	@Column(name="last_modified_date", insertable=false, updatable=false)
	private Date updatedDate;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the campaignId
	 */
	public String getCampaignId() {
		return campaignId;
	}

	/**
	 * @param campaignId the campaignId to set
	 */
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	/**
	 * @return the campaignName
	 */
	public String getCampaignName() {
		return campaignName;
	}

	/**
	 * @param campaignName the campaignName to set
	 */
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	/**
	 * @return the parentCampaignId
	 */
	public String getParentCampaignId() {
		return parentCampaignId;
	}

	/**
	 * @param parentCampaignId the parentCampaignId to set
	 */
	public void setParentCampaignId(String parentCampaignId) {
		this.parentCampaignId = parentCampaignId;
	}

	/**
	 * @return the parentCampaignName
	 */
	public String getParentCampaignName() {
		return parentCampaignName;
	}

	/**
	 * @param parentCampaignName the parentCampaignName to set
	 */
	public void setParentCampaignName(String parentCampaignName) {
		this.parentCampaignName = parentCampaignName;
	}

	/**
	 * @return the campaignStartDate
	 */
	public Date getCampaignStartDate() {
		return campaignStartDate;
	}

	/**
	 * @param campaignStartDate the campaignStartDate to set
	 */
	public void setCampaignStartDate(Date campaignStartDate) {
		this.campaignStartDate = campaignStartDate;
	}

	/**
	 * @return the touchPointLable
	 */
	public String getTouchPointLable() {
		return touchPointLable;
	}

	/**
	 * @param touchPointLable the touchPointLable to set
	 */
	public void setTouchPointLable(String touchPointLable) {
		this.touchPointLable = touchPointLable;
	}

	/**
	 * @return the newCampaignName
	 */
	public String getNewCampaignName() {
		return newCampaignName;
	}

	/**
	 * @param newCampaignName the newCampaignName to set
	 */
	public void setNewCampaignName(String newCampaignName) {
		this.newCampaignName = newCampaignName;
	}

	/**
	 * @return the totalCampaignCost
	 */
	public Double getTotalCampaignCost() {
		return totalCampaignCost;
	}

	/**
	 * @param totalCampaignCost the totalCampaignCost to set
	 */
	public void setTotalCampaignCost(Double totalCampaignCost) {
		this.totalCampaignCost = totalCampaignCost;
	}

	/**
	 * @return the draft
	 */
	public boolean isDraft() {
		return draft;
	}

	/**
	 * @param draft the draft to set
	 */
	public void setDraft(boolean draft) {
		this.draft = draft;
	}

	/**
	 * @return the editableFields
	 */
	public Set<String> getEditableFields() {
		return editableFields;
	}

	/**
	 * @param editableFields the editableFields to set
	 */
	public void setEditableFields(Set<String> editableFields) {
		this.editableFields = editableFields;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((campaignId == null) ? 0 : campaignId.hashCode());
		result = prime * result + ((campaignName == null) ? 0 : campaignName.hashCode());
		result = prime * result + ((campaignStartDate == null) ? 0 : campaignStartDate.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CampaignStrategy other = (CampaignStrategy) obj;
		if (campaignId == null) {
			if (other.campaignId != null)
				return false;
		}
		else if (!campaignId.equals(other.campaignId))
			return false;
		if (campaignName == null) {
			if (other.campaignName != null)
				return false;
		}
		else if (!campaignName.equals(other.campaignName))
			return false;
		if (campaignStartDate == null) {
			if (other.campaignStartDate != null)
				return false;
		}
		else if (!campaignStartDate.equals(other.campaignStartDate))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CampaignStrategy [id=");
		builder.append(id);
		builder.append(", campaignId=");
		builder.append(campaignId);
		builder.append(", campaignName=");
		builder.append(campaignName);
		builder.append(", parentCampaignId=");
		builder.append(parentCampaignId);
		builder.append(", parentCampaignName=");
		builder.append(parentCampaignName);
		builder.append(", campaignStartDate=");
		builder.append(campaignStartDate);
		builder.append(", touchPointLable=");
		builder.append(touchPointLable);
		builder.append(", newCampaignName=");
		builder.append(newCampaignName);
		builder.append(", totalCampaignCost=");
		builder.append(totalCampaignCost);
		builder.append(", draft=");
		builder.append(draft);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", updatedDate=");
		builder.append(updatedDate);
		builder.append("]");
		return builder.toString();
	}
}
