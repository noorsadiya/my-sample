/**
 * 
 */
package com.miri.data.jpa.service;

import java.util.List;

import com.miri.data.jpa.domain.MiriMetricReference;

/**
 * MiriMetricRefService: Provides methods to fetch data from Miri metric
 * reference table.
 * 
 * @author Chandra
 *
 */
public interface MiriMetricRefService {

	public List<MiriMetricReference> getAllMetricReferences();

	public List<MiriMetricReference> getMetricReferencesByCategoryAndSection(final String category,
			final String section);
}
