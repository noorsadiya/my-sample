package com.miri.data.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.Assets;

@Repository
public interface AssetRepository extends JpaRepository<Assets, Long>{
	

}
