/**
 * 
 */
package com.miri.data.jpa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miri.data.jpa.domain.MiriMetricReference;
import com.miri.data.jpa.repository.MetricStatusRepository;
import com.miri.data.jpa.service.MiriMetricRefService;

/**
 * @author Chandra
 *
 */
@Service
public class MiriMetricRefServiceImpl implements MiriMetricRefService {

	@Autowired
	MetricStatusRepository metricStatusRepository;

	@Override
	public List<MiriMetricReference> getAllMetricReferences() {
		return metricStatusRepository.findAll();
	}

	@Override
	public List<MiriMetricReference> getMetricReferencesByCategoryAndSection(final String category, final String section) {
		return metricStatusRepository.findByCategoryAndSection(category, section); 
	}

}
