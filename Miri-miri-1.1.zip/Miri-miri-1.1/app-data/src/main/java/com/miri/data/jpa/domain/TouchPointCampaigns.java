package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name = "touch_point_campaigns")
public class TouchPointCampaigns implements Serializable {
	
	private static final long serialVersionUID = -8651466969838393078L;
	
	@Id
	@Column(name="id")
	@GeneratedValue()
	private Long id;
	
	@Column(name="campaign_id")
	private String campaignId;
	
	@Column(name="last_run")
	private Date lastRundate;
	
	@Column(name="campaign_name")
	private String campaignName;
		
	@OneToMany(mappedBy = "touchPointCampaigns")
	@Cascade(CascadeType.ALL)
	private List<TouchPoint>  touchPoints;
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public Date getLastRundate() {
		return lastRundate;
	}
	
	public void setLastRundate(Date lastRundate) {
		this.lastRundate = lastRundate;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public List<TouchPoint> getTouchPoints() {
		return touchPoints;
	}

	public void setTouchPoints(List<TouchPoint> touchPoints) {
		this.touchPoints = touchPoints;
	}
	
	

}
