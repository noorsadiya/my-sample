package com.miri.data.jpa.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.SavedSearch;

@Repository
public interface SaveSearchRepository extends JpaRepository<SavedSearch, Long> {

	@Query("FROM SavedSearch ss WHERE ss.createdBy = ?1")
	List<SavedSearch> findAllForUser(String userName, Sort sort);

	@Query("FROM SavedSearch ss WHERE ss.createdBy = ?1")
	Page<SavedSearch> findAllForUser(String userName, Pageable pageable);

	@Modifying(clearAutomatically = true)
	@Query("DELETE FROM SavedSearch ss WHERE ss.name = ?1 AND ss.createdBy = ?2")
	void deleteSavedSearchByName(String searchName, String createdBy);
}
