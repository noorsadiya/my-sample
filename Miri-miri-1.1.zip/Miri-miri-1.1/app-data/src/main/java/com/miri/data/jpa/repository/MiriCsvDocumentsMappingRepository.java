package com.miri.data.jpa.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.MiriCsvDocumentsMapping;

@Repository
public interface MiriCsvDocumentsMappingRepository extends JpaRepository<MiriCsvDocumentsMapping, Serializable> {
	
}
