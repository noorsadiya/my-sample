package com.miri.data.jpa.service;

public class MaxViewLimitReachedException extends RuntimeException {
	private static final long serialVersionUID = -3166576343623493890L;

	public MaxViewLimitReachedException(String message, Throwable cause) {
		super(message, cause);
	}

	public MaxViewLimitReachedException(String message) {
		super(message);
	}

}
