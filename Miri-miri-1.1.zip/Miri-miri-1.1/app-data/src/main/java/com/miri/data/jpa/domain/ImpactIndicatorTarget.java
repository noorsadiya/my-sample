package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="impact_indicator_target")
public class ImpactIndicatorTarget implements Serializable {
	private static final long serialVersionUID = -8651466969838393076L;

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;

	@Enumerated(EnumType.STRING)
	@Column(name="indicator_name")
	private ImpactIndicatorName indicatorName;

	@Column(name="target_value")
	private Double targetValue;

	@Column(name="valid_from")
	private Date validFrom;

	@Column(name="valid_upto")
	private Date validUpto;

	@Column(name="created_date", insertable=false, updatable=false)
	private Date createdDate;

	@Column(name="last_modified_date", insertable=false, updatable=false)
	private Date lastModifiedDate;

	public ImpactIndicatorTarget() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ImpactIndicatorName getIndicatorName() {
		return indicatorName;
	}

	public void setIndicatorName(ImpactIndicatorName indicatorName) {
		this.indicatorName = indicatorName;
	}

	public Double getTargetValue() {
		return targetValue;
	}

	public void setTargetValue(Double targetValue) {
		this.targetValue = targetValue;
	}

	public Date getValidFrom() {
		return validFrom;
	}

	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}

	public Date getValidUpto() {
		return validUpto;
	}

	public void setValidUpto(Date validUpto) {
		this.validUpto = validUpto;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((indicatorName == null) ? 0 : indicatorName.hashCode());
		result = prime * result + ((validFrom == null) ? 0 : validFrom.hashCode());
		result = prime * result + ((validUpto == null) ? 0 : validUpto.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ImpactIndicatorTarget other = (ImpactIndicatorTarget) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (indicatorName != other.indicatorName)
			return false;
		if (validFrom == null) {
			if (other.validFrom != null)
				return false;
		}
		else if (!validFrom.equals(other.validFrom))
			return false;
		if (validUpto == null) {
			if (other.validUpto != null)
				return false;
		}
		else if (!validUpto.equals(other.validUpto))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ImpactIndicatorTarget [id=");
		builder.append(id);
		builder.append(", indicatorName=");
		builder.append(indicatorName);
		builder.append(", targetValue=");
		builder.append(targetValue);
		builder.append(", validFrom=");
		builder.append(validFrom);
		builder.append(", validUpto=");
		builder.append(validUpto);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", lastModifiedDate=");
		builder.append(lastModifiedDate);
		builder.append("]");
		return builder.toString();
	}
}
