package com.miri.data.jpa.repository.datasourceSetup;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.miri.data.jpa.domain.WebServiceGlobalConfiguration;

public interface WebServiceGlobalConfigurationRepository extends JpaRepository<WebServiceGlobalConfiguration, Long>{

	@Query("FROM WebServiceGlobalConfiguration wsc WHERE wsc.attributeName LIKE %:attributeName%")
	List<WebServiceGlobalConfiguration> findAllByAttributeName(@Param("attributeName") String attributeName);
	
	@Modifying(clearAutomatically = true)
	@Query("DELETE WebServiceGlobalConfiguration wsc where wsc.attributeName LIKE %:attributeName%")
	void deleteAllByAttributeName(@Param("attributeName") String attributeName);
	
	
}
