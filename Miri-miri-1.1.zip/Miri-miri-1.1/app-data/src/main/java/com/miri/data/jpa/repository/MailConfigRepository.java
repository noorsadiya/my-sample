package com.miri.data.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.miri.data.jpa.domain.MailConfig;

public interface MailConfigRepository extends JpaRepository<MailConfig, Long>{

}
