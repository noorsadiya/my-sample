package com.miri.data.constants;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public enum OpportunityStagesEnum {
	
	PROSPECTING("Prospecting"), 
	QUALIFICATION("Qualification"), 
	NEED_ANALYSIS("Needs Analysis"), 
	VALUE_PROPOSITION("Value Proposition"), 
	DECISION_MAKERS("Id. Decision Makers "), 
	PERCEPTION_ANALYSIS("Perception Analysis "), 
	
	//Qualified Stages
	PRICE_QUOTE("Proposal/Price Quote"), 
	NEGOTIATION("Negotiation/Review"),
	
	//Closed Stages
	CLOSED_WON("Closed Won"),
	CLOSED_LOST("Closed Lost"),
	QUALIFIED_PIPELINE("Qualified Pipeline"),
	
	//Error stage
	STAGE_EMPTY(""),
	OTHERS("Others");
	
	private String text;
	
    private static Map<String, OpportunityStagesEnum> metricMapper = new HashMap<>();

    static {
        for (final OpportunityStagesEnum metric : OpportunityStagesEnum.values()) {
            metricMapper.put(metric.getText(), metric);
        }
        metricMapper = Collections.unmodifiableMap(metricMapper);
    }

    public static Map<String, OpportunityStagesEnum> getMetricMapper() {
        return metricMapper;
    }

    private OpportunityStagesEnum(final String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    /**
     * Returns String value corresponding to enum.
     *
     * @param text
     * @return
     */
    public static OpportunityStagesEnum fromString(final String text) {
        if (text != null) {
            for (final OpportunityStagesEnum metricsEnum : OpportunityStagesEnum.values()) {
                if (text.equalsIgnoreCase(metricsEnum.getText())) {
                    return metricsEnum;
                }
            }
        }
        return null;
    }
}
