/**
 * 
 */
package com.miri.data.jpa.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author Chandra
 *
 */
@Entity
@Table(name = "MIRI_ACCESS_FLOW_CONTROL", uniqueConstraints = @UniqueConstraint(columnNames = { "type" }))
public class LicenseAccessFlow implements Serializable {

	private static final long serialVersionUID = 2351192933892168972L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@JsonIgnore
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "license_manager_id", nullable = false)
	private LicenseManager licenseManager;
	
	@Column(name = "type")
	@NotNull
	private String licenseType;

	@Column(name = "no_of_api_instances")
	private int noOfInstances;

	@Column(name = "is_csv_allowed")
	private boolean isCSVAllowed;

	@Column(name = "start_date")
	private String startDate;

	@Column(name = "end_date")
	private String endDate;

	@Column(name = "support_type")
	private String supportType;

	public LicenseAccessFlow(String licenseType) {
		super();
		this.licenseType = licenseType;
	}

	public LicenseAccessFlow() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLicenseType() {
		return licenseType;
	}

	public void setLicenseType(String licenseType) {
		this.licenseType = licenseType;
	}

	public int getNoOfInstances() {
		return noOfInstances;
	}

	public void setNoOfInstances(int noOfInstances) {
		this.noOfInstances = noOfInstances;
	}

	public boolean isCSVAllowed() {
		return isCSVAllowed;
	}

	public void setCSVAllowed(boolean isCSVAllowed) {
		this.isCSVAllowed = isCSVAllowed;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getSupportType() {
		return supportType;
	}

	public void setSupportType(String supportType) {
		this.supportType = supportType;
	}

	public LicenseManager getLicenseManager() {
		return licenseManager;
	}

	public void setLicenseManager(LicenseManager licenseManager) {
		this.licenseManager = licenseManager;
	}
	
	

}
