package com.miri.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.MiriCriticalFieldImpactMetric;
import com.miri.data.jpa.domain.MiriDocumentCriticalField;

/**
 * MiriCriticalFieldMetricsRepository: that provides  methods to perform database operations on miri_critical_field_impact_metric table
 * @author noor
 */
@Repository
public interface MiriCriticalFieldMetricsRepository extends JpaRepository<MiriCriticalFieldImpactMetric, Long>{
	
	List<MiriCriticalFieldImpactMetric> findAll();
	
	@Query("from MiriCriticalFieldImpactMetric mid where mid.miriCriticalField = ?1")
	List<MiriCriticalFieldImpactMetric> findAllByFieldId(MiriDocumentCriticalField miriCriticalField);

}
