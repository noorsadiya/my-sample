package com.miri.data.jpa.repository.accountSetup;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.miri.data.jpa.domain.Industry;

public interface IndustryRepository extends JpaRepository<Industry, Long> {
	
	@Query("from Industry i where LOWER(i.industryName) = ?1")
	Industry findOneByIndustryName(String industryName);

}