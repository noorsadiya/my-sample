package com.miri.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.miri.data.jpa.domain.User;

/**
 * Spring Data JPA repository for the User entity.
 */
public interface UserRepository extends JpaRepository<User, String> {

	@Query("from User user where LOWER(user.userName) = ?1 and user.active = true")
	User findActiveOneByUserName(String userName);

	@Query("from User user where LOWER(user.userName) = ?1")
	User findOneByUserName(String userName);

	@Query("from User user where user.active = true")
	List<User> findAllActiveUsers();

	@Query("from User user where LOWER(user.userName) LIKE %:name%  or LOWER(user.firstName) LIKE %:name% or LOWER(user.lastName) LIKE %:name%  or LOWER(user.designation) LIKE %:name% ")
	List<User> searchUserByDetails(@Param("name") String name);

	@Override
	void delete(User t);

}
