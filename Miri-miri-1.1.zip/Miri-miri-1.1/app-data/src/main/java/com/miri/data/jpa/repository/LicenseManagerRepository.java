package com.miri.data.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.LicenseManager;

@Repository
public interface LicenseManagerRepository extends JpaRepository<LicenseManager, Long> {
	public LicenseManager findByKey(String key);
}
