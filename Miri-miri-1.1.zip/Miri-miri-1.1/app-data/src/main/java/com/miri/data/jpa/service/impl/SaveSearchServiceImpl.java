package com.miri.data.jpa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.miri.data.jpa.domain.SavedSearch;
import com.miri.data.jpa.repository.SaveSearchRepository;
import com.miri.data.jpa.service.SaveSearchService;

@Service
@Transactional
public class SaveSearchServiceImpl implements SaveSearchService {

	@Autowired
	private SaveSearchRepository saveSearchRepository;

	@Override
	public SavedSearch retrieveLasteSavedSearch(String userName) {
		SavedSearch savedSearch = null;
		PageRequest pageRequest = new PageRequest(0, 1, Direction.DESC, "createdDate");
		Page<SavedSearch> page = saveSearchRepository.findAllForUser(userName, pageRequest);

		if (page.hasContent()) {
			savedSearch = page.getContent().get(0);
		}
		return savedSearch;
	}

	@Override
	public List<SavedSearch> retrieveSavedSearches(String userName) {
		Sort sort = new Sort(Direction.DESC, "createdDate");
		return saveSearchRepository.findAllForUser(userName, sort);
	}

	@Override
	public void saveSearchRequest(String name, String searchKey, String userName) {

		SavedSearch searchCriteria = new SavedSearch(name, searchKey, userName);

		saveSearchRepository.save(searchCriteria);
	}

	@Override
	public void deleteSavedSearch(String name, String createdBy) {
		saveSearchRepository.deleteSavedSearchByName(name, createdBy);
	}

}
