package com.miri.data.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.ImpactIndicatorHistory;
import com.miri.data.jpa.domain.ImpactIndicatorName;

@Repository
public interface ImpactIndicatorHistoryRepository extends JpaRepository<ImpactIndicatorHistory, Long> {

	@Query("from ImpactIndicatorHistory ct where LOWER(ct.indicatorName) = ?1")
	ImpactIndicatorHistory findOneByIndicatorName(ImpactIndicatorName indicatorName);
}
