package com.miri.data.jpa.repository.campaignStrategy;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.miri.data.jpa.domain.CampaignStrategy;

public interface CampaignStrategyRepository extends JpaRepository<CampaignStrategy, Long> {

	@Query("from CampaignStrategy cs where LOWER(cs.campaignName) = ?1 AND (cs.campaignStartDate = null OR (cs.campaignStartDate BETWEEN ?2 AND ?3))")
	CampaignStrategy findOneByCampaignName(String campaignName, Date rangeStart, Date rangeEnd);

	@Query("SELECT cs.parentCampaignId, cs.parentCampaignName FROM CampaignStrategy cs WHERE cs.parentCampaignName != null AND cs.createdDate BETWEEN ?1 AND ?2")
	List<Object[]> getParentCampaignIdAndName(Date rangeStart, Date rangeEnd, Sort sort);
}
