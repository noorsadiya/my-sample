package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "web_service_vendor")
public class WebServiceVendor implements Serializable {
	private static final long serialVersionUID = 991014334052153214L;
	
	private static final Logger LOG = LogManager.getLogger(WebServiceVendor.class);

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@JsonIgnore
	private Long id;

	@Column(name = "vendor_type")
	private String vendorType;

	@Column(name = "instance_name")
	private String instanceName;

	@Column(name = "vendor_name")
	private String vendorName;

	@Column(name = "version")
	private String version;

	@Column(name = "status")
	@JsonIgnore
	private boolean status;

	@Column(name = "draft")
	@JsonIgnore
	private boolean draft;

	@Column(name = "connected")
	@JsonIgnore
	private boolean connected;

	@Column(name = "created_date", insertable = false, updatable = false)
	@JsonIgnore
	private Date createdDate;

	@Column(name = "last_modified_date", insertable = false, updatable = false)
	@JsonIgnore
	private Date lastModifiedDate;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "webServiceVendor")
	private Set<WebServiceVendorConfiguration> configuration;

	public WebServiceVendor() {
		super();
	}

	public WebServiceVendor(String vendorType, String instanceName, String vendorName, String version) {
		super();
		this.vendorType = vendorType;
		this.instanceName = instanceName;
		this.vendorName = vendorName;
		this.version = version;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVendorType() {
		return vendorType;
	}

	public void setVendorType(String vendorType) {
		this.vendorType = vendorType;
	}

	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Set<WebServiceVendorConfiguration> getConfiguration() {
		return configuration;
	}

	public void setConfiguration(Set<WebServiceVendorConfiguration> configuration) {
		this.configuration = configuration;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public boolean isDraft() {
		return draft;
	}

	public void setDraft(boolean draft) {
		this.draft = draft;
	}

	public boolean isConnected() {
		return connected;
	}

	public void setConnected(boolean connected) {
		this.connected = connected;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((instanceName == null) ? 0 : instanceName.hashCode());
		result = prime * result + (status ? 1231 : 1237);
		result = prime * result + ((vendorName == null) ? 0 : vendorName.hashCode());
		result = prime * result + ((vendorType == null) ? 0 : vendorType.hashCode());
		result = prime * result + ((version == null) ? 0 : version.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WebServiceVendor other = (WebServiceVendor) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (instanceName == null) {
			if (other.instanceName != null)
				return false;
		} else if (!instanceName.equals(other.instanceName))
			return false;
		if (status != other.status)
			return false;
		if (vendorName == null) {
			if (other.vendorName != null)
				return false;
		} else if (!vendorName.equals(other.vendorName))
			return false;
		if (vendorType == null) {
			if (other.vendorType != null)
				return false;
		} else if (!vendorType.equals(other.vendorType))
			return false;
		if (version == null) {
			if (other.version != null)
				return false;
		} else if (!version.equals(other.version))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("WebServiceVendor [id=");
		builder.append(id);
		builder.append(", vendorType=");
		builder.append(vendorType);
		builder.append(", instanceName=");
		builder.append(instanceName);
		builder.append(", vendorName=");
		builder.append(vendorName);
		builder.append(", version=");
		builder.append(version);
		builder.append(", status=");
		builder.append(status);
		builder.append(", draft=");
		builder.append(draft);
		builder.append(", connected=");
		builder.append(connected);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", lastModifiedDate=");
		builder.append(lastModifiedDate);
		builder.append(", configuration=");
		builder.append(configuration != null ? configuration.size() : null);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * Converts set of configuration into Map that contains attributes.
	 * 
	 * @return
	 */
	public Map<String, String> getPropertiesAsMap() {
		try {
			Set<WebServiceVendorConfiguration> configurations = getConfiguration();
			// System.out.println(configurations);
			Map<String, String> propertiesAsMap = new HashMap<>();
			if (null != configurations && !configurations.isEmpty()) {
				Iterator<WebServiceVendorConfiguration> iterator = configurations.iterator();
				while (iterator.hasNext()) {
					WebServiceVendorConfiguration configuration = iterator.next();
					// System.out.println("configuration :" + configuration.getAttributeName() + "|" + configuration.getAttributeValue());
					propertiesAsMap.put(configuration.getAttributeName(), configuration.getAttributeValue());
				}
			}
			return propertiesAsMap;
		} catch(Exception e) {
			//e.printStackTrace();
			LOG.error("Exception while retrieveing properties as Map :" + e.getMessage());
		}
		return null;
	}
}