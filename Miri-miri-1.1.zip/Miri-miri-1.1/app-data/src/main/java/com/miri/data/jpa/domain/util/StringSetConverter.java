package com.miri.data.jpa.domain.util;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Pattern;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import org.springframework.util.CollectionUtils;

@Converter
public class StringSetConverter implements AttributeConverter<Set<String>, String> {

	private static final String DELIMITER = "|";

	@Override
	public String convertToDatabaseColumn(final Set<String> attribute) {
		String convertedString = null;
		if (!CollectionUtils.isEmpty(attribute)) {
			StringBuilder builder = new StringBuilder();
			for (String element : attribute) {
				if (builder.length() > 0) {
					builder.append(DELIMITER);
				}
				builder.append(element);
			}
			convertedString = builder.toString();
		}
		return convertedString;
	}

	@Override
	public Set<String> convertToEntityAttribute(final String dbData) {
		Set<String> converted = Collections.emptySet();
		if (dbData != null) {
			String[] split = dbData.split(Pattern.quote(DELIMITER));
			converted = new LinkedHashSet<>(Arrays.asList(split));
		}
		return converted;
	}

}
