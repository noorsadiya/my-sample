/**
 * 
 */
package com.miri.data.jpa.service;

import java.util.List;

import com.miri.data.jpa.domain.MiriCISInteractionConfig;

/**
 * MiriAppConfigService: Provides methods to access MIRI application
 * configuration details.
 * 
 * @author Chandra
 *
 */
public interface MiriAppConfigService {

	public MiriCISInteractionConfig getValueByActionAndType(final String action, final String type);

	public List<MiriCISInteractionConfig> getAllConfigDetails();
}
