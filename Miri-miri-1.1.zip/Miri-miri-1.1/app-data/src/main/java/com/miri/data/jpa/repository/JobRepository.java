package com.miri.data.jpa.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.JobLog;

@Repository
public interface JobRepository extends JpaRepository<JobLog, Long> {

	@Query("FROM JobLog jl WHERE jl.vendorType = ?1 AND jl.vendorName = ?2 AND jl.instanceName = ?3 AND jl.jobName = ?4")
	Page<JobLog> findRecentCompleteJob(String vendorType, String vendorName, String instanceName, String jobName, Pageable pageable);
	
	@Query(value="SELECT * FROM job_log AS jobLog INNER JOIN (SELECT distinct job_group_name FROM job_log ORDER BY job_group_name DESC LIMIT 2) as log ON jobLog.job_group_name = log.job_group_name", nativeQuery = true)
	List<JobLog> findCurrentAndLastJobDetails();
	
	@Query("FROM JobLog jl WHERE jl.jobGroupName like ?1")
	List<JobLog> findJobLogBySchedulerRunId(String jobGroupPattern);
}
