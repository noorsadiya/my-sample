package com.miri.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.MiriIndexDocument;
import com.miri.data.jpa.domain.MiriIndex;

/**
 * MiriIndexDocumentsRepository: that provides  methods to perform database operations on miri_index_document table
 * @author noor
 */
@Repository
public interface MiriIndexDocumentsRepository extends JpaRepository<MiriIndexDocument, Long>{
	
	List<MiriIndexDocument> findAll();
	
	@Query("from MiriIndexDocument mid where mid.miriIndex = ?1")
	List<MiriIndexDocument> findAllByIndexId(MiriIndex indexId);
	

}
