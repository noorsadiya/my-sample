package com.miri.data.jpa.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.miri.data.jpa.domain.MiriHistoryData;

/**
 * MiriHistoryDataService interface has method definitions to fetch the any history data that is maintained in the database
 * @author noor
 *
 */
@Component
public interface MiriHistoryDataService {

	public  List<MiriHistoryData> getExpiredPipelineByTypeAndCriteria(String type,String criteriaType);
	
	public void createHistoryRecord(List<MiriHistoryData> miriHistoryDataList);
	
	
	
}
