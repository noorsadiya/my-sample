/**
 * 
 */
package com.miri.data.jpa.service.impl;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miri.data.jpa.domain.CurrencyExchangeKey;
import com.miri.data.jpa.domain.CurrencyExchangeRates;
import com.miri.data.jpa.repository.accountSetup.CurrencyExchangeRepository;
import com.miri.data.jpa.service.CurrencyExchangeService;

/**
 * CurrencyExchangeServiceImpl: Provides methods to save and retrieve currency information.
 * 
 * @author Chandra
 *
 */
@Transactional
@Service
public class CurrencyExchangeServiceImpl implements CurrencyExchangeService {

	@Autowired
	CurrencyExchangeRepository currencyExchangeRepository;

	@Override
	public boolean saveCurrencyEntry(CurrencyExchangeRates currencyExchangeRates) {
		currencyExchangeRepository.saveAndFlush(currencyExchangeRates);
		return true;
	}

	@Override
	public boolean saveCurrencyEntries(List<CurrencyExchangeRates> currencyExchangeRatesList) {
		currencyExchangeRepository.save(currencyExchangeRatesList);
		return true;
	}

	@Override
	public CurrencyExchangeRates getExchangeRate(String symbol, Date date) {
		return getExchangeRate(new CurrencyExchangeKey(symbol, new java.sql.Date(date.getTime())));
	}

	@Override
	public CurrencyExchangeRates getExchangeRate(String baseCurrency, String quoteCurrency, Date date) {
		return currencyExchangeRepository.findByDateBaseAndQuoteCurrency(baseCurrency, quoteCurrency, date);
	}

	@Override
	public List<CurrencyExchangeRates> getExchangeRates(Date date) {
		return currencyExchangeRepository.findByCurrencyExchangeKeyDate(date);
	}

	@Override
	public CurrencyExchangeRates getExchangeRate(CurrencyExchangeKey currencyExchangeKey) {
		return currencyExchangeRepository.findOne(currencyExchangeKey);

	}

}
