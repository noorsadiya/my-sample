/**
 * 
 */
/**
 * @author chavanka
 *
 */
package com.miri.data.jpa.util;