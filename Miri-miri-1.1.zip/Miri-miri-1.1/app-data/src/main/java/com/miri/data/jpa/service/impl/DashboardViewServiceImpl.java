package com.miri.data.jpa.service.impl;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.miri.data.jpa.domain.DashboardView;
import com.miri.data.jpa.repository.DashboardViewRepository;
import com.miri.data.jpa.service.DashboardViewService;
import com.miri.data.jpa.service.MaxViewLimitReachedException;

@Service
@Transactional
public class DashboardViewServiceImpl implements DashboardViewService {
	//private static final Logger LOG = LogManager.getLogger(DashboardViewServiceImpl.class);
	
	private static final int MAX_LIMIT = 6;

	@Autowired
	private DashboardViewRepository dashboardViewRepository;

	private final Object addViewLock = new Object();

	@Override
	public void addViewToDashboard(String url, String metadata, String filter, String createdBy) {
		boolean countExceeded = false;

		long count = dashboardViewRepository.countByCreatedBy(createdBy);
		if (count < MAX_LIMIT) {
			synchronized (addViewLock) {
				count = dashboardViewRepository.countByCreatedBy(createdBy);
				if (count < MAX_LIMIT) {
					DashboardView viewToAdd = new DashboardView(url, metadata, filter, createdBy);
					dashboardViewRepository.save(viewToAdd);
				} else {
					countExceeded = true;
				}
			}
		} else {
			countExceeded = true;
		}

		if (countExceeded) {
			throw new MaxViewLimitReachedException("Cannot add more view to dashboard. "
					+ "Max views allowed: " + MAX_LIMIT + ". Existing view count: " + count);
		}
	}

	@Override
	public List<DashboardView> retrieveDashboardView(String createdBy) {
		List<DashboardView> dashboardView = Collections.emptyList();

		PageRequest pageRequest = new PageRequest(0, MAX_LIMIT, Direction.DESC, "createdDate");
		Page<DashboardView> resultPage = dashboardViewRepository.findByCreatedBy(createdBy, pageRequest);
		//LOG.info("Dashbpard view results :" + resultPage.getContent());
		if (resultPage.hasContent()) {
			dashboardView = resultPage.getContent();
		}
		return dashboardView;
	}

	@Override
	public void removeViewFromDashboard(String url, String createdBy) {
		//LOG.info("remove URL: " + url +  "|" + createdBy);
		dashboardViewRepository.delete(url, createdBy);
	}

}
