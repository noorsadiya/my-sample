package com.miri.data.jpa.repository.datasourceSetup;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.CrmInstance;

@Repository
public interface CrmInstanceRepository extends JpaRepository<CrmInstance, Long> {

	@Query("SELECT ci.name FROM CrmInstance ci")
	List<String> findAllNames();

	CrmInstance findByName(String name);

	@Modifying(clearAutomatically = true)
	@Query("DELETE FROM CrmInstance ci WHERE ci.webServiceVendor.id = ?1")
	void deleteForWebServiceVendor(Long id);
}
