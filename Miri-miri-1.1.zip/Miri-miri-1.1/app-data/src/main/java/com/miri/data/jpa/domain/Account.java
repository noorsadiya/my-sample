package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author supraja
 *
 */

@Entity
@Table(name = "account")
public class Account implements Serializable {

	private static final long serialVersionUID = -5177358964740511306L;

	@Id
	@Column(name = "id")
	private Long id;

	@Column(name = "company_name")
	private String companyName;

	@Column(name = "business_unit")
	private String businessUnit;

	@Column(name = "address1")
	private String address1;

	@Column(name = "address2")
	private String address2;

	@Column(name = "address3")
	private String address3;

	@Column(name = "city")
	private String city;

	@Column(name = "state")
	private String state;

	@Column(name = "zip_code")
	private String zipCode;

	@OneToOne
	@JoinColumn(name = "country_id")
	private Country country;

	@OneToOne
	@JoinColumn(name = "industry_id")
	private Industry industry;

	@Column(name = "no_of_employees")
	private Integer numOfEmployee;

	@OneToOne
	@JoinColumn(name = "currency_id")
	private Currency currency;

	@Column(name = "annual_revenue")
	private Double annualRevenue;

	@Column(name = "website")
	private String website;

	@Column(name = "logo")
	private byte[] logo;

	@Column(name = "draft")
	@JsonIgnore
	private boolean draft;

	@Column(name = "created_date", insertable = false, updatable = false)
	private Date createdAt;

	@Column(name = "last_modified_date")
	private Date updatedAt;

	@Column(name="fiscal_start")
	private Date fiscalStart;

	public Account() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Integer getNumOfEmployee() {
		return numOfEmployee;
	}

	public void setNumOfEmployee(Integer numOfEmployee) {
		this.numOfEmployee = numOfEmployee;
	}

	public Double getAnnualRevenue() {
		return annualRevenue;
	}

	public void setAnnualRevenue(Double annualRevenue) {
		this.annualRevenue = annualRevenue;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public byte[] getLogo() {
		return logo;
	}

	public void setLogo(byte[] logo) {
		this.logo = logo;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Industry getIndustry() {
		return industry;
	}

	public void setIndustry(Industry industry) {
		this.industry = industry;
	}

	public Currency getCurrency() {
		return currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public boolean isDraft() {
		return draft;
	}

	public void setDraft(boolean draft) {
		this.draft = draft;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	/**
	 * @return the fiscalStart
	 */
	public Date getFiscalStart() {
		return fiscalStart;
	}

	/**
	 * @param fiscalStart the fiscalStart to set
	 */
	public void setFiscalStart(Date fiscalStart) {
		this.fiscalStart = fiscalStart;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Account [id=");
		builder.append(id);
		builder.append(", companyName=");
		builder.append(companyName);
		builder.append(", businessUnit=");
		builder.append(businessUnit );
		builder.append(", address1=");
		builder.append(address1 );
		builder.append(", address2=");
		builder.append( address2 );
		builder.append( ", address3=" );
		builder.append( address3);
		builder.append( ", city=" );
		builder.append(city );
		builder.append(", state=");
		builder.append(state);
		builder.append(", zipCode=");
		builder.append( zipCode );
		builder.append(", country=");
		builder.append( country );
		builder.append( ", industry=");
		builder.append( industry );
		builder.append( ", numOfEmployee=");
		builder.append(numOfEmployee );
		builder.append( ", currency=" );
		builder.append(currency);
		builder.append( ", annualRevenue=" );
		builder.append( annualRevenue );
		builder.append(", website=" );
		builder.append(website);
		builder.append( ", logo=");
		builder.append( Arrays.toString(logo));
		builder.append( ", draft=" );
		builder.append(draft);
		builder.append( ", createdAt=" );
		builder.append( createdAt );
		builder.append( ", updatedAt=");
		builder.append( updatedAt);
		builder.append( ", fiscalStart=");
		builder.append(fiscalStart);

		return builder.toString();
	}
}
