package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "touch_point")
public class TouchPoint implements Serializable{
	
	private static final long serialVersionUID = -8651466969838393077L;
	
	@Id
	@Column(name="touch_point_id")
	@GeneratedValue()
	private Long id;
	
	@Column(name="touchpoint_date")
	private Date touchPointDate;
	
	@Column(name="leads_associated")
	private String leadsAssociated;
	
	@Column(name="unique_combinations")
	private String uniqueCombinations;
	
	@Column(name="touch_point_name")
	private String touchPointName;
	
	@Column(name="opportunities")
	private String opportunities;
	
	@ManyToOne
	@JoinColumn(name = "touch_point_campaign_id", nullable = false)
	private TouchPointCampaigns touchPointCampaigns;
	
	public String getOpportunities() {
		return opportunities;
	}
	
	public void setOpportunities(String opportunities) {
		this.opportunities = opportunities;
	}
	
	public TouchPointCampaigns getTouchPointCampaigns() {
		return touchPointCampaigns;
	}

	public void setTouchPointCampaigns(TouchPointCampaigns touchPointCampaigns) {
		this.touchPointCampaigns = touchPointCampaigns;
	}

	public String getTouchPointName() {
		return touchPointName;
	}
	
	public void setTouchPointName(String touchPointName) {
		this.touchPointName = touchPointName;
	}
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getTouchPointDate() {
		return touchPointDate;
	}

	public void setTouchPointDate(Date touchPointDate) {
		this.touchPointDate = touchPointDate;
	}

	public String getLeadsAssociated() {
		return leadsAssociated;
	}

	public void setLeadsAssociated(String leadsAssociated) {
		this.leadsAssociated = leadsAssociated;
	}

	public String getUniqueCombinations() {
		return uniqueCombinations;
	}

	public void setUniqueCombinations(String uniqueCombinations) {
		this.uniqueCombinations = uniqueCombinations;
	}
	
	

}
