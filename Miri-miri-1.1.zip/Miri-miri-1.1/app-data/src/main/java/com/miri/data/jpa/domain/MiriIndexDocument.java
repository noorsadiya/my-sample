package com.miri.data.jpa.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author noor
 * Entity for the database table  miri_index_document which has all documents and 
 * mapping to the index
 */
@Entity
@Table(name="miri_index_document")
public class MiriIndexDocument implements Serializable{

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 5302731188249548443L;

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	@JsonIgnore
	private Long id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="description")
	private String desctiption;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "miri_index_id")
	private MiriIndex miriIndex;
	
	@Column(name="type")
	private String Type;
	
	@Column(name="sort_order")
	private int sortOrder;
	
	@Column(name="date_field")
	private String dateField;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesctiption() {
		return desctiption;
	}

	public void setDesctiption(String desctiption) {
		this.desctiption = desctiption;
	}

	public MiriIndex getMiriIndex() {
		return miriIndex;
	}

	public void setMiriIndex(MiriIndex miriIndex) {
		this.miriIndex = miriIndex;
	}
	
	public String getType() {
		return Type;
	}
	
	public void setType(String type) {
		Type = type;
	}

	public int getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getDateField() {
		return dateField;
	}

	public void setDateField(String dateField) {
		this.dateField = dateField;
	}
	
	
	

}
