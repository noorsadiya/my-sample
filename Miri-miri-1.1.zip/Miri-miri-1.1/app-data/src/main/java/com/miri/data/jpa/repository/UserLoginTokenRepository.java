package com.miri.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.miri.data.jpa.domain.UserLoginToken;

/**
 * Spring Data JPA repository for the UserLoginToken entity.
 */
public interface UserLoginTokenRepository extends JpaRepository<UserLoginToken, String> {

	@Query("from UserLoginToken token where token.user.userName = ?1")
	List<UserLoginToken> findAllByUserName(String userName);

}
