/**
 * 
 */
package com.miri.data.jpa.service;

/**
 * @author chavanka
 *
 */
public interface JobService {

public void getLastJobDetails(String jobType);

	boolean isLastJobSuccess(String jobType);

	void getJobHistory(String jobType);

}
