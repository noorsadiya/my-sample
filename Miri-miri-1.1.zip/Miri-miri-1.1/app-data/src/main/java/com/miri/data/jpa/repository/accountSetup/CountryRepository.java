package com.miri.data.jpa.repository.accountSetup;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.miri.data.jpa.domain.Country;

public interface CountryRepository extends JpaRepository<Country, Long> {
	
	@Query("from Country ct where LOWER(ct.countryName) = ?1")
	Country findOneByCountryName(String countryName);
}
