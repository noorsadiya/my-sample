package com.miri.data.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.miri.data.jpa.domain.Authority;
import com.miri.data.jpa.domain.AuthorityName;

/**
 * Spring Data JPA repository for the Authority entity.
 */
public interface AuthorityRepository extends JpaRepository<Authority, AuthorityName> {
}
