package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * MIRI CSV Documents table for storing the documents.
 * @author rammoole
 *
 */
@Entity
@Table(name="miri_csv_documents")
public class MiriCsvDocuments implements Serializable {
	
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -8693108645345142990L;

	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@JsonIgnore
	@Id
	private int id;
	
	@Column(name="document_name")
	private String documentName;
	
	@OneToOne
	@JoinColumn(name = "manual_csv_tracker_id")
	private ManualCSVTracker manualCSVTracker;
	
	@Column(name = "created_date", insertable = false, updatable = false)
	private Date createdDate;

	@Column(name = "last_modified_date")
	private Date lastModifiedDate;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the documentName
	 */
	public String getDocumentName() {
		return documentName;
	}

	/**
	 * @param documentName the documentName to set
	 */
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	/**
	 * @return the manualCSVTracker
	 */
	public ManualCSVTracker getManualCSVTracker() {
		return manualCSVTracker;
	}

	/**
	 * @param manualCSVTracker the manualCSVTracker to set
	 */
	public void setManualCSVTracker(ManualCSVTracker manualCSVTracker) {
		this.manualCSVTracker = manualCSVTracker;
	}

	/**
	 * @return the createdAt
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(Date createdAt) {
		this.createdDate = createdAt;
	}

	/**
	 * @return the lastModifiedDate
	 */
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * @param lastModifiedDate the lastModifiedDate to set
	 */
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
}
