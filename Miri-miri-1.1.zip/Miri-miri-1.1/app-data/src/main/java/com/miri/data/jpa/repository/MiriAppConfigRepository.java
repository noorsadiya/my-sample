/**
 * 
 */
package com.miri.data.jpa.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.miri.data.jpa.domain.MiriCISInteractionConfig;

/**
 * @author Chandra
 *
 */
public interface MiriAppConfigRepository extends JpaRepository<MiriCISInteractionConfig, Serializable> {

	public MiriCISInteractionConfig findByActionAndType(String action, String type);

}
