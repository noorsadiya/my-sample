package com.miri.data.jpa.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.miri.data.jpa.domain.MiriCriticalFieldImpactMetric;
import com.miri.data.jpa.domain.MiriDocumentCriticalField;
import com.miri.data.jpa.domain.MiriIndexDocument;
import com.miri.data.jpa.domain.MiriMetric;
import com.miri.data.jpa.domain.MiriIndex;

/**
 * MiriIndexMappingService : provides method definitions to get the indices, documents, fields and metric names impacted.
 * @author noor
 */
@Component
public interface MiriIndexMappingService {

	List<MiriIndex> getAllIndices();
	
	List<MiriIndexDocument> getAllDocumentsByIndexId(MiriIndex index);
	
	List<MiriDocumentCriticalField> getAllFieldsByDocumentId(MiriIndexDocument documentId);
	
	List<MiriCriticalFieldImpactMetric> getAllMetricsByCriticalFieldId(MiriDocumentCriticalField fieldId);
	
	MiriMetric  getMetricByMetricId(Long id);
	
	List<MiriIndexDocument> getAllDocuments();
	
	List<MiriDocumentCriticalField> getAllCriticalFields();
	
	List<MiriCriticalFieldImpactMetric> getAllCriticalFieldMetrics();
	
	List<MiriMetric> getAllMetrics();
	
}
