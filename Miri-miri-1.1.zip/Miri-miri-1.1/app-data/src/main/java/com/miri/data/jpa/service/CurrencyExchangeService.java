/**
 * 
 */
package com.miri.data.jpa.service;

import java.util.Date;
import java.util.List;

import com.miri.data.jpa.domain.CurrencyExchangeKey;
import com.miri.data.jpa.domain.CurrencyExchangeRates;

/**
 * CurrencyExchangeService: Interface that provides methods to save and retrieve currency information.
 *  
 * @author Chandra
 *
 */
public interface CurrencyExchangeService {

	boolean saveCurrencyEntry(CurrencyExchangeRates currencyExchangeRates);

	boolean saveCurrencyEntries(List<CurrencyExchangeRates> currencyExchangeRatesList);

	CurrencyExchangeRates getExchangeRate(String symbol, Date date);
	
	CurrencyExchangeRates getExchangeRate(CurrencyExchangeKey currencyExchangeKey);

	CurrencyExchangeRates getExchangeRate(String baseCurrency, String quoteCurrency, Date date);

	List<CurrencyExchangeRates> getExchangeRates(Date date);

}
