/**
 * 
 */
package com.miri.data.jpa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miri.data.jpa.domain.MiriCISInteractionConfig;
import com.miri.data.jpa.repository.MiriAppConfigRepository;
import com.miri.data.jpa.service.MiriAppConfigService;

/**
 * MiriAppConfigServiceImpl: provides implementation to MIRI app config access
 * methods.
 * 
 * @author Chandra
 *
 */
@Service
public class MiriAppConfigServiceImpl implements MiriAppConfigService {

	@Autowired
	MiriAppConfigRepository miriAppConfigRepository;

	@Override
	public MiriCISInteractionConfig getValueByActionAndType(String action, String type) {
		return miriAppConfigRepository.findByActionAndType(action, type);
	}

	@Override
	public List<MiriCISInteractionConfig> getAllConfigDetails() {
		return miriAppConfigRepository.findAll();
	}

}
