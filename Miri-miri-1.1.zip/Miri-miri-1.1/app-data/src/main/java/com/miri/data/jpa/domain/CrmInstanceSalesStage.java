package com.miri.data.jpa.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="crm_instance_sales_stage")
public class CrmInstanceSalesStage implements Serializable {
	private static final long serialVersionUID = -1560471213672266653L;

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	@JsonIgnore
	private Long id;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "crm_instance_id")
	private CrmInstance crmInstance;

	@Column(name="sales_stage_name")
	private String salesStageName;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "local_crm_sales_stage_id")
	private LocalCrmSalesStage localCrmSalesStage;

	public CrmInstanceSalesStage() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public CrmInstance getCrmInstance() {
		return crmInstance;
	}

	public void setCrmInstance(CrmInstance crmInstance) {
		this.crmInstance = crmInstance;
	}

	public String getSalesStageName() {
		return salesStageName;
	}

	public void setSalesStageName(String salesStageName) {
		this.salesStageName = salesStageName;
	}

	public LocalCrmSalesStage getLocalCrmSalesStage() {
		return localCrmSalesStage;
	}

	public void setLocalCrmSalesStage(LocalCrmSalesStage localCrmSalesStage) {
		this.localCrmSalesStage = localCrmSalesStage;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((crmInstance == null) ? 0 : crmInstance.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((salesStageName == null) ? 0 : salesStageName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CrmInstanceSalesStage other = (CrmInstanceSalesStage) obj;
		if (crmInstance == null) {
			if (other.crmInstance != null)
				return false;
		}
		else if (!crmInstance.equals(other.crmInstance))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (salesStageName == null) {
			if (other.salesStageName != null)
				return false;
		}
		else if (!salesStageName.equals(other.salesStageName))
			return false;
		return true;
	}

	/*@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CrmInstanceSalesStage [id=");
		builder.append(id);
		builder.append(", crmInstance=");
		builder.append(crmInstance);
		builder.append(", salesStageName=");
		builder.append(salesStageName);
		builder.append(", localCrmSalesStage=");
		builder.append(localCrmSalesStage);
		builder.append("]");
		return builder.toString();
	}*/
}
