package com.miri.data.jpa.repository.accountSetup;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.miri.data.jpa.domain.Account;
import com.miri.data.jpa.domain.Currency;

@Transactional
public interface AccountSetupRepository extends JpaRepository<Account, Long> {

	@Query("SELECT a.logo FROM Account a")
	byte[] getLogo();
	
	@Query("SELECT a.currency from Account a")
	Currency getCurrency();
}
