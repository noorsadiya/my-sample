/**
 * 
 */
package com.miri.data.jpa.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.ManualCSVTracker;

/**
 * @author Chandra
 *
 */
@Repository
public interface ManualCSVTrackerRepository extends JpaRepository<ManualCSVTracker, Serializable> {

	@Query("FROM ManualCSVTracker mt WHERE mt.status in('INPROGRESS','NEW')")
	List<ManualCSVTracker> findAllActive();
	
	@Query("FROM ManualCSVTracker mt WHERE mt.fileName = ?1")
	ManualCSVTracker findByFileName(String fileName);
	
	List<ManualCSVTracker> findByFileNameStartingWith(String fileName);
}
