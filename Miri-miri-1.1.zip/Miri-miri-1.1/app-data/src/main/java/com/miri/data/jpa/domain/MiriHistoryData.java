package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.miri.data.jpa.domain.util.CustomDateTimeSerializer;

/**
 * @author noor
 * Entity for the database table  miri_history_data which has all documents and 
 * mapping to the index
 */
@Entity
@Table(name="miri_history_data")
public class MiriHistoryData implements Serializable{

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 5302731188249548443L;

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	@JsonIgnore
	private Long id;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="index_id")
	private MiriIndex index;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="document_id")
	private MiriIndexDocument indexDocument;
	
	@Column(name="type")
	private String type;

	@Column(name="criteria_type")
	private String criteriaType;
	
	@Column(name="criteria_value")
	private String criteriaValue;
	
	@Column(name="amount")
	private double amount;
	
	@Column(name="count")
	private int count;
	
	@Column(name="sort_order")
	private int sortOrder;
	
	@Column(name="status")
	private String status;
	
	@JsonSerialize(using = CustomDateTimeSerializer.class)
	@Column(name = "created_date", length = 200)
	private Date createdDate;
	
	@JsonSerialize(using = CustomDateTimeSerializer.class)
	@Column(name = "last_updated_date", length = 200)
	private Date lastUpdatedDate;
	
	@Column(name="opportunities")
	private String opportunities;
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public MiriIndex getIndex() {
		return index;
	}

	public void setIndex(MiriIndex index) {
		this.index = index;
	}

	public MiriIndexDocument getIndexDocument() {
		return indexDocument;
	}

	public void setIndexDocument(MiriIndexDocument indexDocument) {
		this.indexDocument = indexDocument;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCriteriaType() {
		return criteriaType;
	}

	public void setCriteriaType(String criteriaType) {
		this.criteriaType = criteriaType;
	}

	public String getCriteriaValue() {
		return criteriaValue;
	}

	public void setCriteriaValue(String criteriaValue) {
		this.criteriaValue = criteriaValue;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getOpportunities() {
		return opportunities;
	}

	public void setOpportunities(String opportunities) {
		this.opportunities = opportunities;
	}

	
}
