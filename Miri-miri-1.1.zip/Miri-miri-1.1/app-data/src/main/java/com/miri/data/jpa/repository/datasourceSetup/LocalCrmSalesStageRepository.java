package com.miri.data.jpa.repository.datasourceSetup;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.LocalCrmSalesStage;

@Repository
public interface LocalCrmSalesStageRepository extends JpaRepository<LocalCrmSalesStage, Long> {
	
	List<LocalCrmSalesStage> findAll();
	
	LocalCrmSalesStage findByStageName(String stageName);
}
