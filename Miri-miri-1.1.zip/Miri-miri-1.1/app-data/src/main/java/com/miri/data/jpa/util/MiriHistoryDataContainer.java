package com.miri.data.jpa.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.parboiled.common.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.data.jpa.domain.MiriHistoryData;
import com.miri.data.jpa.service.MiriHistoryDataService;

/**
 * MiriHistoryDataContainer contains methods to retrieve the history maintained data
 * @author noor 
 *
 */
@Component
public class MiriHistoryDataContainer {
	
	 public static Map<String,MiriHistoryData>  overAllExpiredPipelineByMonth;
	 public static Map<String,MiriHistoryData>  miExpiredPipelineByMonth;
	 public static Map<String,MiriHistoryData>  sgExpiredPipelineByMonth;
	 
	 public static String EXPIRED_PIPELINE_LITERAL="expired_pipeline";
	 public static String EXPIRED_PIPELINE_DATE_CRITERIA="overall";
	 public static String  EXPIRED_PIPELINE_MARKETING_INFLUENCED = "marketing-influenced";
	 public  static String  EXPIRED_PIPELINE_SALES_GENERATED = "sales-generated";
	 
	@Autowired
	MiriHistoryDataService misiHistoryDataService;
	 
	/**
	 * getExpiredPipelineByMonth return the expired pipeline stored in the database
	 * @return
	 */
	public Map<String, MiriHistoryData> getExpiredPipelineByMonth(String drillDown) {
		if(StringUtils.equalsIgnoreCase(drillDown, EXPIRED_PIPELINE_MARKETING_INFLUENCED)){
			return getMIExpiredPipelineByMonth();
		}else if(StringUtils.equalsIgnoreCase(drillDown, EXPIRED_PIPELINE_SALES_GENERATED)){
			return getSGExpiredPipelineByMonth();
		}else {
			return getOverallExpiredPipelineByMonth();
		}
	}
	
	/**
	 * getExpiredPipelineByMonth return the expired pipeline stored in the database
	 * @return
	 */
	public Map<String, MiriHistoryData> getOverallExpiredPipelineByMonth() {
		MiriHistoryData miriHistoryData=null;
		if (MapUtils.isEmpty(overAllExpiredPipelineByMonth)) {
			overAllExpiredPipelineByMonth=new HashMap<>();
			List<MiriHistoryData> expirePipelineDataList = misiHistoryDataService
					.getExpiredPipelineByTypeAndCriteria(EXPIRED_PIPELINE_LITERAL, EXPIRED_PIPELINE_DATE_CRITERIA);

			for (Iterator<MiriHistoryData> iterator = expirePipelineDataList.iterator(); iterator.hasNext();) {
				 miriHistoryData = iterator.next();

				 overAllExpiredPipelineByMonth.put(miriHistoryData.getCriteriaValue(), miriHistoryData);
			}
		}
		return overAllExpiredPipelineByMonth;
	}
	
	/**
	 * getExpiredPipelineByMonth return the expired pipeline stored in the database
	 * @return
	 */
	public Map<String, MiriHistoryData> getMIExpiredPipelineByMonth() {
		MiriHistoryData miriHistoryData=null;
		if (MapUtils.isEmpty(miExpiredPipelineByMonth)) {
			miExpiredPipelineByMonth=new HashMap<>();
			List<MiriHistoryData> expirePipelineDataList = misiHistoryDataService
					.getExpiredPipelineByTypeAndCriteria(EXPIRED_PIPELINE_LITERAL, EXPIRED_PIPELINE_MARKETING_INFLUENCED);

			for (Iterator<MiriHistoryData> iterator = expirePipelineDataList.iterator(); iterator.hasNext();) {
				 miriHistoryData = iterator.next();

				 miExpiredPipelineByMonth.put(miriHistoryData.getCriteriaValue(), miriHistoryData);
			}
		}
		return miExpiredPipelineByMonth;
	}
	
	/**
	 * getExpiredPipelineByMonth return the expired pipeline stored in the database
	 * @return
	 */
	public Map<String, MiriHistoryData> getSGExpiredPipelineByMonth() {
		MiriHistoryData miriHistoryData=null;
		if (MapUtils.isEmpty(sgExpiredPipelineByMonth)) {
			sgExpiredPipelineByMonth=new HashMap<>();
			List<MiriHistoryData> expirePipelineDataList = misiHistoryDataService
					.getExpiredPipelineByTypeAndCriteria(EXPIRED_PIPELINE_LITERAL, EXPIRED_PIPELINE_SALES_GENERATED);

			for (Iterator<MiriHistoryData> iterator = expirePipelineDataList.iterator(); iterator.hasNext();) {
				 miriHistoryData = iterator.next();

				 sgExpiredPipelineByMonth.put(miriHistoryData.getCriteriaValue(), miriHistoryData);
			}
		}
		return sgExpiredPipelineByMonth;
	}
	
	
	
}
