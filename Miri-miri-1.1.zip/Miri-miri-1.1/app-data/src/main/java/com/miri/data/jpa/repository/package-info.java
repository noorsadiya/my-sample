/**
 * 
 */
/**
 * @author chavanka
 *
 */
package com.miri.data.jpa.repository;