package com.miri.data.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.ProductInfo;

@Repository
public interface ProductInfoRepository extends JpaRepository<ProductInfo, Long>{
	
	@Query("FROM ProductInfo pi WHERE pi.productCode = ?1")
	ProductInfo getProductByCode(String productCode);

}
