package com.miri.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.MiriIndex;

/**
 * MiriIndexRepository: that provides  methods to perform database operations on miri_index table
 * @author noor
 */
@Repository
public interface MiriIndexRepository extends JpaRepository<MiriIndex, Long>{
	
	List<MiriIndex> findAll();
	

}
