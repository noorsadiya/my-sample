package com.miri.data.jpa.util;

public final class CurrencyConstants {
	
	public static final String USD = "USD";
	public static final String EUR = "EUR";
	public static final String GBP = "GBP";
	public static final String USD_SYMBOL = "$";
	public static final String EUR_SYMBOL = "€";
	public static final String GBP_SYMBOL = "£";

}
