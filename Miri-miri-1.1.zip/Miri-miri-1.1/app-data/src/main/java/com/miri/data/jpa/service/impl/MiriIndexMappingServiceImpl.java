package com.miri.data.jpa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.data.jpa.domain.MiriCriticalFieldImpactMetric;
import com.miri.data.jpa.domain.MiriDocumentCriticalField;
import com.miri.data.jpa.domain.MiriIndexDocument;
import com.miri.data.jpa.domain.MiriMetric;
import com.miri.data.jpa.domain.MiriIndex;
import com.miri.data.jpa.repository.MiriCriticalFieldMetricsRepository;
import com.miri.data.jpa.repository.MiriDocumentCriticalFieldRepository;
import com.miri.data.jpa.repository.MiriIndexDocumentsRepository;
import com.miri.data.jpa.repository.MiriIndexRepository;
import com.miri.data.jpa.repository.MiriMetricRepository;
import com.miri.data.jpa.service.MiriIndexMappingService;


/**
 * MiriIndexMappingServiceImpl : provides method implementation to get the indices, 
 * documents, fields and metric names impacted.
 * @author noor
 */

@Component
public class MiriIndexMappingServiceImpl implements MiriIndexMappingService {
	
	@Autowired
	MiriIndexRepository miriIndicesRepo;
	
	@Autowired
	MiriIndexDocumentsRepository miriIndexDocumentRepo;
	
	@Autowired
	MiriDocumentCriticalFieldRepository miriDocumentFieldRepo;

	@Autowired
	MiriCriticalFieldMetricsRepository mirifieldMetricRepo;
	
	@Autowired
	MiriMetricRepository mirMetricRepo;
	
	/**
	 * getAllIndices : Retrieves all indices from the  MiriIndexRepository
	 * @return List<MiriIndex>
	 */
	@Override
	public List<MiriIndex> getAllIndices() {
		return miriIndicesRepo.findAll();
	}

	/**
	 * getAllDocumentsByIndexId : Retrieves all documents of the index from MiriIndexDocumentsRepository
	 * @return List<MiriIndexDocument>
	 */
	@Override
	public List<MiriIndexDocument> getAllDocumentsByIndexId(MiriIndex indexId) {
		return miriIndexDocumentRepo.findAllByIndexId(indexId);
	}

	
	/**
	 * getAllFieldsByDocumentId : Retrieves all critical fields of the document from  MiriDocumentCriticalFieldRepository
	 * @return List<MiriDocumentCriticalField> 
	 */
	@Override
	public List<MiriDocumentCriticalField> getAllFieldsByDocumentId(MiriIndexDocument documentId) {
		return miriDocumentFieldRepo.findAllByDocumentId(documentId);
	}

	/**
	 * getAllMetricsByCriticalFieldId : Retrieves all metrics of the critical field from the  MiriCriticalFieldMetricsRepository
	 * @return List<MiriCriticalFieldImpactMetric> 
	 */
	@Override
	public List<MiriCriticalFieldImpactMetric> getAllMetricsByCriticalFieldId(MiriDocumentCriticalField fieldId) {
		return mirifieldMetricRepo.findAllByFieldId(fieldId);
	}

	
	/**
	 * getMetricByMetricId : Retrieves all metrics from the  MiriMetricRepository
	 * @return MiriMetric
	 */
	@Override
	public MiriMetric getMetricByMetricId(Long id) {
		return mirMetricRepo.findMetricById(id);
	}

	
	/**
	 * getAllDocuments : Retrieves all documents from the  MiriIndexDocumentsRepository
	 * @return MiriMetric
	 */
	@Override
	public List<MiriIndexDocument> getAllDocuments() {
		return miriIndexDocumentRepo.findAll();
	}

	/**
	 * getAllCriticalFields : Retrieves all critical fields from the  MiriDocumentCriticalFieldRepository
	 * @return MiriMetric
	 */
	@Override
	public List<MiriDocumentCriticalField> getAllCriticalFields() {
		return miriDocumentFieldRepo.findAll();
	}

	/**
	 * getAllCriticalFieldMetrics : Retrieves all metrics of the critical field from the  MiriDocumentCriticalFieldRepository
	 * @return MiriMetric
	 */
	@Override
	public List<MiriCriticalFieldImpactMetric> getAllCriticalFieldMetrics() {
		return mirifieldMetricRepo.findAll();
	}

	/**
	 * getAllMetrics : Retrieves all metrics from  MiriMetricRepository
	 * @return MiriMetric
	 */
	@Override
	public List<MiriMetric> getAllMetrics() {
		return mirMetricRepo.findAll();
	}


}
