package com.miri.data.jpa.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author supraja
 *
 */
@Entity
@Table(name = "business_strategy_configuration_details")
public class BusinessStrategyConfigurations implements Serializable {

	private static final long serialVersionUID = 730489721607656233L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "revenue_name")
	private String revenueName;

	@Column(name = "month_name")
	private String monthName;

	@Column(name = "monthly_target")
	private Double monthlyTarget;

	@Column(name = "quaterly_target")
	private Double quaterlyTarget;

	@Column(name = "yearly_target")
	private Double yearlyTarget;

	@Column(name = "draft")
	@JsonIgnore
	private boolean draft;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRevenueName() {
		return revenueName;
	}

	public void setRevenueName(String revenueName) {
		this.revenueName = revenueName;
	}

	public String getMonthName() {
		return monthName;
	}

	public void setMonthName(String monthName) {
		this.monthName = monthName;
	}

	public Double getMonthlyTarget() {
		return monthlyTarget;
	}

	public void setMonthlyTarget(Double monthlyTarget) {
		this.monthlyTarget = monthlyTarget;
	}

	public Double getQuaterlyTarget() {
		return quaterlyTarget;
	}

	public void setQuaterlyTarget(Double quaterlyTarget) {
		this.quaterlyTarget = quaterlyTarget;
	}

	public Double getYearlyTarget() {
		return yearlyTarget;
	}

	public void setYearlyTarget(Double yearlyTarget) {
		this.yearlyTarget = yearlyTarget;
	}

	/**
	 * @return the draft
	 */
	public boolean isDraft() {
		return draft;
	}

	/**
	 * @param draft the draft to set
	 */
	public void setDraft(boolean draft) {
		this.draft = draft;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((monthName == null) ? 0 : monthName.hashCode());
		result = prime * result + ((revenueName == null) ? 0 : revenueName.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BusinessStrategyConfigurations other = (BusinessStrategyConfigurations) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (monthName == null) {
			if (other.monthName != null)
				return false;
		} else if (!monthName.equals(other.monthName))
			return false;
		if (revenueName == null) {
			if (other.revenueName != null)
				return false;
		} else if (!revenueName.equals(other.revenueName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BusinessStrategyConfigurations [id=").append(id);
		builder.append(", revenueName=").append( revenueName);
		builder.append(", monthName=").append(monthName);
		builder.append(", monthlyTarget=").append( monthlyTarget);
		builder.append(", quaterlyTarget=").append( quaterlyTarget);
		builder.append(", yearlyTaget=").append(yearlyTarget);
		builder.append( ", draft=" ).append(draft).append("]");
		return builder.toString();
	}
}
