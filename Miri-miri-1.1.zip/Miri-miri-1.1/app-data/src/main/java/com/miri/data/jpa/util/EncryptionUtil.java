package com.miri.data.jpa.util;

import java.security.Key;

import javax.crypto.spec.SecretKeySpec;

import org.apache.log4j.Logger;

public class EncryptionUtil {
	private static final Logger LOGGER = Logger.getLogger(EncryptionUtil.class);
	private static final String ALGORITHM = "AES";

	private static final String KEY = "1Hbfh667adfDEJ78";

	public static String encrypt(String value) throws EncryptionException {
		/*Key key = generateKey();
		String encryptedValue = null;
		try {
			Cipher cipher = Cipher.getInstance(ALGORITHM);
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] encryptedByteValue = cipher.doFinal(value.getBytes("utf-8"));
			encryptedValue = new BASE64Encoder().encode(encryptedByteValue);
		}
		catch (Exception e) {
			LOGGER.warn("Error while encrypting password.");
			throw new EncryptionException(e.getMessage(), e);
		}
		return encryptedValue;*/
		return value;
	}

	public static String decrypt(String value) throws DecryptionException {
/*		Key key = generateKey();
		String decryptedValue = null;
		try {
			Cipher cipher = Cipher.getInstance(ALGORITHM);
			cipher.init(Cipher.DECRYPT_MODE, key);
			byte[] decryptedValue64 = new BASE64Decoder().decodeBuffer(value);
			byte[] decryptedByteValue = cipher.doFinal(decryptedValue64);
			decryptedValue = new String(decryptedByteValue, "utf-8");
		}
		catch (Exception e) {
			LOGGER.warn("Error while dencrypting password.");
			throw new DecryptionException(e.getMessage(), e);
		}
		return decryptedValue;*/
		return value;

	}

	private static Key generateKey() {
		Key key = new SecretKeySpec(KEY.getBytes(), ALGORITHM);
		return key;
	}

	public static void main(String[] args) {
		try {
//			String password = "Phaladata#1";
			String password = "Phaladata#1";
			System.out.println("plain pass=" + password);
			String encryptedPassword = encrypt(password);
			System.out.println("encrypted pass=" + encryptedPassword);
			String decryptedPassword = decrypt(encryptedPassword);
			System.out.println("decrypted pass=" + decryptedPassword);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static class EncryptionException extends RuntimeException {
		private static final long serialVersionUID = 8606679469293197800L;

		public EncryptionException(String message, Throwable cause) {
			super(message, cause);
		}

		public EncryptionException(String message) {
			super(message);
		}
	}

	public static class DecryptionException extends RuntimeException {
		private static final long serialVersionUID = -8678138836214909986L;

		public DecryptionException(String message, Throwable cause) {
			super(message, cause);
		}

		public DecryptionException(String message) {
			super(message);
		}
	}
}
