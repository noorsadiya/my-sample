/**
 * 
 */
package com.miri.data.jpa.util;

/**
 * @author chavanka
 *
 */
public enum JobStatus {

	SUCCESS, FAILED, IN_PROGRESS, SUSPENDED

}
