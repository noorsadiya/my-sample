package com.miri.data.jpa.repository.businessStrategy;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.miri.data.jpa.domain.BusinessStrategyConfigurations;

public interface BusinessStrategyConfigurationRepository extends JpaRepository<BusinessStrategyConfigurations, Long> {
	@Query("from BusinessStrategyConfigurations bsc where bsc.revenueName = ?1")
	List<BusinessStrategyConfigurations> findAllByRevenueName(String revenueName);
	
	@Modifying(clearAutomatically = true)
	@Query("UPDATE BusinessStrategyConfigurations bsc SET bsc.yearlyTarget = ?2 WHERE bsc.revenueName = ?1")
	void updateAllTargetValuesForRevenueName(String revenueName, Number targetValue);
	
	@Modifying(clearAutomatically = true)
	@Query("UPDATE BusinessStrategyConfigurations bsc SET bsc.yearlyTarget = ?2 WHERE bsc.revenueName = ?1 and bsc.monthName = ?3")
	void updateTargetValuesForCurrentMonth(String revenueName, Number targetValue, String monthName);

}
