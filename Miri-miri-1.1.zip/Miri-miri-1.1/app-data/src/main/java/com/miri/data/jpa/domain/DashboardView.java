package com.miri.data.jpa.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name="dashboard_view")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "url")
public class DashboardView implements Serializable {
	private static final long serialVersionUID = 6653566641240057078L;

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	@JsonIgnore
	public Long id;

	@Column(name="url")
	public String url;

	@Column(name="metadata")
	public String metadata;

	@Column(name="filter")
	public String filter;

	@JsonIgnore
	@Column(name="created_date", insertable=false, updatable=false)
	public String createdDate;

	@Column(name="created_by")
	@JsonIgnore
	public String createdBy;

	public DashboardView() {
		super();
	}

	public DashboardView(String url, String metadata, String filter, String createdBy) {
		this.url = url;
		this.metadata = metadata;
		this.filter = filter;
		this.createdBy = createdBy;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

	public String getFilter() {
		return filter;
	}

	public void setFilter(String filter) {
		this.filter = filter;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((url == null) ? 0 : url.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DashboardView other = (DashboardView) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (url == null) {
			if (other.url != null)
				return false;
		}
		else if (!url.equals(other.url))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DashboardView [id=");
		builder.append(id);
		builder.append(", url=");
		builder.append(url);
		builder.append(", metadata-is-null=");
		builder.append((metadata == null));
		builder.append(", filter=");
		builder.append(filter);
		builder.append("]");
		return builder.toString();
	}
}
