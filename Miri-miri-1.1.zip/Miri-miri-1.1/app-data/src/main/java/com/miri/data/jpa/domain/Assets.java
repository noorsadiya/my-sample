package com.miri.data.jpa.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "assets")
public class Assets implements Serializable {
	
	private static final long serialVersionUID = 6764707922790384700L;

	@Id
	@Column(name="id")
	@GeneratedValue()
	private Long id;
	
	@Column(name="asset_name")
	private String asset;
	
	@Column(name="opportunities")
	private String opportunities;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAsset() {
		return asset;
	}

	public void setAsset(String asset) {
		this.asset = asset;
	}

	public String getOpportunities() {
		return opportunities;
	}

	public void setOpportunities(String opportunities) {
		this.opportunities = opportunities;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

}
