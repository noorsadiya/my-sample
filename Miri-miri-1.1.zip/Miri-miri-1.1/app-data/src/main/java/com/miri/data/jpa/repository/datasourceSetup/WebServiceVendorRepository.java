package com.miri.data.jpa.repository.datasourceSetup;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.WebServiceVendor;

@Repository
public interface WebServiceVendorRepository extends JpaRepository<WebServiceVendor, Long> {

	@Query("FROM WebServiceVendor wsv WHERE wsv.status=true")
	List<WebServiceVendor> findAllActive(Sort sort);

	@Query("FROM WebServiceVendor wsv WHERE wsv.status=true")
	List<WebServiceVendor> findActiveConfigurations();

	@Query("FROM WebServiceVendor wsv WHERE wsv.status=true AND wsv.vendorType = ?1 AND wsv.vendorName = ?2 AND wsv.instanceName = ?3")
	List<WebServiceVendor> findVendorConfig(String vendorType, String vendorName, String instanceName, Sort sort);

	@Query("FROM WebServiceVendor wsv WHERE wsv.status=true AND wsv.vendorType = ?1 AND wsv.vendorName = ?2 AND wsv.instanceName = ?3 AND wsv.version = ?4")
	List<WebServiceVendor> findVendorConfig(String vendorType, String vendorName, String instanceName, String version,
			Sort sort);

	@Query("SELECT wsv.vendorName FROM WebServiceVendor wsv WHERE wsv.status=true AND LOWER(wsv.vendorType) = LOWER(?1)")
	List<String> getAllVendorNames(String vendorType);
}
