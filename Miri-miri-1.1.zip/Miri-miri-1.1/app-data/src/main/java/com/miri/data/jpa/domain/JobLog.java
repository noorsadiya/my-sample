package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.miri.data.jpa.domain.util.StringSetConverter;

@Entity
@Table(name="job_log")
public class JobLog implements Serializable {
	private static final long serialVersionUID = -2632325065763158777L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "vendor_type")
	private String vendorType;

	@Column(name = "instance_name")
	private String instanceName;

	@Column(name = "vendor_name")
	private String vendorName;

	@Column(name = "version")
	private String version;

	@Column(name = "job_name")
	private String jobName;

	@Column(name = "job_group_name")
	private String jobGroupName;

	@Column(name = "start_time")
	private Date startTime;

	@Column(name = "finish_time")
	private Date finishTime;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private JobStatus status;

	@Column(name = "info")
	private String info;

	@Column(name = "fetch_from_date")
	private Date fetchFromDate;

	@Column(name = "fetch_from")
	private int fetchFrom;

	@Column(name = "fetch_size")
	private int fetchSize;

	@Column(name = "next_record_token")
	private String nextRecordToken;

	@Column(name = "succeeded_record_count")
	private int succeededRecordCount;

	@Column(name = "failed_records")
	@Convert(converter=StringSetConverter.class)
	private Set<String> failedRecords;

	@Column(name="created_date", insertable=false, updatable=false)
	private Date createdDate;

	public JobLog() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVendorType() {
		return vendorType;
	}

	public void setVendorType(String vendorType) {
		this.vendorType = vendorType;
	}

	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobGroupName() {
		return jobGroupName;
	}

	public void setJobGroupName(String jobGroupName) {
		this.jobGroupName = jobGroupName;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getFinishTime() {
		return finishTime;
	}

	public void setFinishTime(Date finishTime) {
		this.finishTime = finishTime;
	}

	public JobStatus getStatus() {
		return status;
	}

	public void setStatus(JobStatus status) {
		this.status = status;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public Date getFetchFromDate() {
		return fetchFromDate;
	}

	public void setFetchFromDate(Date fetchFromDate) {
		this.fetchFromDate = fetchFromDate;
	}

	public int getFetchFrom() {
		return fetchFrom;
	}

	public void setFetchFrom(int fetchFrom) {
		this.fetchFrom = fetchFrom;
	}

	public int getFetchSize() {
		return fetchSize;
	}

	public void setFetchSize(int fetchSize) {
		this.fetchSize = fetchSize;
	}

	public String getNextRecordToken() {
		return nextRecordToken;
	}

	public void setNextRecordToken(String nextRecordToken) {
		this.nextRecordToken = nextRecordToken;
	}

	public int getSucceededRecordCount() {
		return succeededRecordCount;
	}

	public void setSucceededRecordCount(int succeededRecordCount) {
		this.succeededRecordCount = succeededRecordCount;
	}

	public void addToSucceededRecordCount(int succeededRecordCountToAdd) {
		this.succeededRecordCount += succeededRecordCountToAdd;
	}

	public Set<String> getFailedRecords() {
		return failedRecords;
	}

	public void setFailedRecords(Set<String> failedRecords) {
		this.failedRecords = failedRecords;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((instanceName == null) ? 0 : instanceName.hashCode());
		result = prime * result + ((jobName == null) ? 0 : jobName.hashCode());
		result = prime * result + ((startTime == null) ? 0 : startTime.hashCode());
		result = prime * result + ((vendorName == null) ? 0 : vendorName.hashCode());
		result = prime * result + ((vendorType == null) ? 0 : vendorType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		JobLog other = (JobLog) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (instanceName == null) {
			if (other.instanceName != null)
				return false;
		}
		else if (!instanceName.equals(other.instanceName))
			return false;
		if (jobName == null) {
			if (other.jobName != null)
				return false;
		}
		else if (!jobName.equals(other.jobName))
			return false;
		if (jobGroupName == null) {
			if (other.jobGroupName != null)
				return false;
		}
		else if (!jobGroupName.equals(other.jobGroupName))
			return false;
		if (startTime == null) {
			if (other.startTime != null)
				return false;
		}
		else if (!startTime.equals(other.startTime))
			return false;
		if (vendorName == null) {
			if (other.vendorName != null)
				return false;
		}
		else if (!vendorName.equals(other.vendorName))
			return false;
		if (vendorType == null) {
			if (other.vendorType != null)
				return false;
		}
		else if (!vendorType.equals(other.vendorType))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("JobLog [id=");
		builder.append(id);
		builder.append(", vendorType=");
		builder.append(vendorType);
		builder.append(", instanceName=");
		builder.append(instanceName);
		builder.append(", vendorName=");
		builder.append(vendorName);
		builder.append(", version=");
		builder.append(version);
		builder.append(", jobName=");
		builder.append(jobName);
		builder.append(", jobGroupName=");
		builder.append(jobGroupName);
		builder.append(", startTime=");
		builder.append(startTime);
		builder.append(", finishTime=");
		builder.append(finishTime);
		builder.append(", status=");
		builder.append(status);
		builder.append(", fetchFromDate=");
		builder.append(fetchFromDate);
		builder.append(", fetchFrom=");
		builder.append(fetchFrom);
		builder.append(", fetchSize=");
		builder.append(fetchSize);
		builder.append(", nextRecordToken=");
		builder.append(nextRecordToken);
		builder.append(", succeededRecordCount=");
		builder.append(succeededRecordCount);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append("]");
		return builder.toString();
	}
}
