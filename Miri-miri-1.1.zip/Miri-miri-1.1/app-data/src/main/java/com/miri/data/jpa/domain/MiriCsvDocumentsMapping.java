package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Manual CSV Document field mapping between csv and elasticsearch
 * @author rammoole
 *
 */
@Entity
@Table(name="miri_csv_documents_field_mapping")
public class MiriCsvDocumentsMapping implements Serializable {
	
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 3407010602295666261L;

	@Id
	@Column(name="id")
	@JsonIgnore
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@OneToOne
	@JoinColumn(name = "manual_csv_tracker_id")
	private ManualCSVTracker manualCSVTracker;
	
	@Column(name="csv_document_field_name")
	private String csvDocumentFieldName;
	
	@Column(name="es_document_field_name")
	private String esDocumentFieldName;
	
	@Column(name="creataed_date")
	private Date createdDate;
	
	@Column(name="last_modified_name")
	private Date lastModifiedDate;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the manualCSVTracker
	 */
	public ManualCSVTracker getManualCSVTracker() {
		return manualCSVTracker;
	}

	/**
	 * @param manualCSVTracker the manualCSVTracker to set
	 */
	public void setManualCSVTracker(ManualCSVTracker manualCSVTracker) {
		this.manualCSVTracker = manualCSVTracker;
	}

	/**
	 * @return the csvDocumentFieldName
	 */
	public String getCsvDocumentFieldName() {
		return csvDocumentFieldName;
	}

	/**
	 * @param csvDocumentFieldName the csvDocumentFieldName to set
	 */
	public void setCsvDocumentFieldName(String csvDocumentFieldName) {
		this.csvDocumentFieldName = csvDocumentFieldName;
	}

	/**
	 * @return the esDocumentFieldName
	 */
	public String getEsDocumentFieldName() {
		return esDocumentFieldName;
	}

	/**
	 * @param esDocumentFieldName the esDocumentFieldName to set
	 */
	public void setEsDocumentFieldName(String esDocumentFieldName) {
		this.esDocumentFieldName = esDocumentFieldName;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the lastModifiedDate
	 */
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * @param lastModifiedDate the lastModifiedDate to set
	 */
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
}
