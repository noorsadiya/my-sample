package com.miri.data.jpa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.data.jpa.domain.MiriHistoryData;
import com.miri.data.jpa.repository.MiriHistoryDataRepository;
import com.miri.data.jpa.service.MiriHistoryDataService;

/**
 * MiriHistoryDataServiceImpl interface has methods to fetch the any history data that is maintained in the database
 * @author noor
 *
 */
@Component
public class MiriHistoryDataServiceImpl implements MiriHistoryDataService{

	@Autowired
	MiriHistoryDataRepository repository;

	@Override
	public List<MiriHistoryData> getExpiredPipelineByTypeAndCriteria(String type, String criteriaType) {
		return repository.findAllByTypeAndCriteria(type, criteriaType);
	}

	@Override
	public void createHistoryRecord(List<MiriHistoryData> miriHistoryDataList) {
		repository.save(miriHistoryDataList);
		
	}
	
	

	
	
	

}