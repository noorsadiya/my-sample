package com.miri.data.jpa.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.data.constants.OpportunityStagesEnum;
import com.miri.data.jpa.domain.CrmInstanceSalesStage;
import com.miri.data.jpa.service.ManualInputService;

/**
 * Application Sales Stage Container
 * @author rammoole
 *
 */
@Component
public class AppSalesStageContainer {
	
	private static final Logger LOGGER = Logger.getLogger(AppSalesStageContainer.class);
	
	@Autowired
	private ManualInputService manualInputService;
	
	private static Map<String, List<String>> salesStageMap = new HashMap<>();
	
	/**
	 * Get Sales Stage map
	 * @return
	 */
	public Map<String, List<String>> getSalesStageMap() {
		if (MapUtils.isEmpty(salesStageMap)) {
			List<CrmInstanceSalesStage> salesStageList = manualInputService.getCrmInstanceSaleStages();
			for (CrmInstanceSalesStage salesStage : salesStageList) {
				if(salesStageMap.containsKey(salesStage.getLocalCrmSalesStage().getStageName())) {
					salesStageMap.get(salesStage.getLocalCrmSalesStage().getStageName()).add(salesStage.getSalesStageName());
				} else {
					salesStageMap.put(salesStage.getLocalCrmSalesStage().getStageName(), new ArrayList<>(Arrays.asList(salesStage.getSalesStageName())));
				}
			}
			LOGGER.info(salesStageMap);
		}
		return salesStageMap;
	}
	
	/**
	 * Get Closed Won Mapped sale stages
	 * @return
	 */
	public List<String> getClosedWonMappedStages() {
		if(CollectionUtils.isNotEmpty(this.getSalesStageMap().get(OpportunityStagesEnum.CLOSED_WON.getText()))) {
			return this.getSalesStageMap().get(OpportunityStagesEnum.CLOSED_WON.getText());
		} else {
			return new ArrayList<>();
		}
	}
	
	/**
	 * Get Closed Lost Mapped sale stages
	 * @return
	 */
	public List<String> getClosedLostMappedStages() {
		if(CollectionUtils.isNotEmpty(this.getSalesStageMap().get(OpportunityStagesEnum.CLOSED_LOST.getText()))) {
			return this.getSalesStageMap().get(OpportunityStagesEnum.CLOSED_LOST.getText());
		} else {
			return new ArrayList<>();
		}
	}
	
	/**
	 * Get Qualified Pipeline Mapped sale stages
	 * @return
	 */
	public List<String> getQualifiedPipelineMappedStages() {
		if(CollectionUtils.isNotEmpty(this.getSalesStageMap().get(OpportunityStagesEnum.QUALIFIED_PIPELINE.getText()))) {
			return this.getSalesStageMap().get(OpportunityStagesEnum.QUALIFIED_PIPELINE.getText());
		} else {
			return new ArrayList<>();
		}
	}
	
	/**
	 * Get Others Mapped sale stages
	 * @return
	 */
	public List<String> getOtherMappedStages() {
		if(CollectionUtils.isNotEmpty(this.getSalesStageMap().get(OpportunityStagesEnum.OTHERS.getText()))) {
			return this.getSalesStageMap().get(OpportunityStagesEnum.OTHERS.getText());
		} else {
			return new ArrayList<>();
		}
	}
	
	/**
	 * This returns the mapped sale stage for the specified stage 
	 * @param stage
	 * @return
	 */
	public List<String> getMappedSaleStage(String stage) {
		if(CollectionUtils.isNotEmpty(this.getSalesStageMap().get(stage))) {
			return this.getSalesStageMap().get(stage);
		} else {
			return new ArrayList<>();
		}
	}
}
