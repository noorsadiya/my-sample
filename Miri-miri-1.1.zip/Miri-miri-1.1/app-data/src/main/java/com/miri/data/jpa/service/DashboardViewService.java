package com.miri.data.jpa.service;

import java.util.List;

import com.miri.data.jpa.domain.DashboardView;

public interface DashboardViewService {

	void addViewToDashboard(String url, String metadata, String filter, String createdBy);

	List<DashboardView> retrieveDashboardView(String createdBy);

	void removeViewFromDashboard(String url, String createdBy);
}
