package com.miri.data.jpa.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.miri.data.jpa.domain.ImpactIndicatorHistory;
import com.miri.data.jpa.domain.ImpactIndicatorName;
import com.miri.data.jpa.domain.ImpactIndicatorTarget;
import com.miri.data.jpa.repository.ImpactIndicatorHistoryRepository;
import com.miri.data.jpa.repository.ImpactIndicatorTargetRepository;
import com.miri.data.jpa.repository.businessStrategy.BusinessStrategyConfigurationRepository;
import com.miri.data.jpa.service.ImpactIndicatorService;

@Service
@Transactional
public class ImpactIndicatorServiceImpl implements ImpactIndicatorService {
	
	private static final Logger LOG = Logger.getLogger(ImpactIndicatorServiceImpl.class);
	
	@Autowired
	ImpactIndicatorTargetRepository impactIndicatorTargetRepository;
	
	@Autowired
	ImpactIndicatorHistoryRepository impactIndicatorHistoryRepository;
	
	@Autowired
	BusinessStrategyConfigurationRepository businessStrategyConfigurationRepository;
	
	//fetch the latest ImpactIndicatorTarget for the current fiscal
	@Override
	public ImpactIndicatorTarget fetchImpactIndicatorTarget(ImpactIndicatorName indicatorName, Date fiscalStartDate) {
		ImpactIndicatorTarget recentTarget = null;

		PageRequest pageRequest = new PageRequest(1, 1, Direction.DESC, "validUpto");
		Page<ImpactIndicatorTarget> page = impactIndicatorTargetRepository.findByName(indicatorName, fiscalStartDate, pageRequest);
		List<ImpactIndicatorTarget> contents = page.getContent();

		if (!CollectionUtils.isEmpty(contents)) {
			recentTarget = contents.get(0);
		}

		return recentTarget;
	}

	@Override
	public List<ImpactIndicatorTarget> fetchAllImpactIndicatorTarget(ImpactIndicatorName indicatorName, Date fiscalStartDate) {
		// Fetch up to 12 Targets max - 1 for each month
		PageRequest pageRequest = new PageRequest(0, 12, Direction.DESC, "validUpto");
		Page<ImpactIndicatorTarget> page = impactIndicatorTargetRepository.findByName(indicatorName, fiscalStartDate, pageRequest);
		return page.getContent();
	}
	
	@Override
	public void updateImpactIndicatorTarget(ImpactIndicatorName indicatorName, Number targetValue,
			ValidityPeriod validityPeriod, Date fiscalStartDate, Date createdDate, Date lastModifiedDate) {

		ImpactIndicatorTarget latestImpactIndicatorTarget = fetchImpactIndicatorTarget(indicatorName, fiscalStartDate);

		// Fetch latest value and update it. If latest value is not for current month,
		// create new entity for current month and save it
		if (latestImpactIndicatorTarget == null || !isValidForCurrentMonth(latestImpactIndicatorTarget)) {
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.HOUR, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);

			cal.set(Calendar.DAY_OF_MONTH, 1);
			Date newValidFrom = cal.getTime();

			cal.add(Calendar.MONTH, 1);
			cal.add(Calendar.DATE, -1);
			Date newValidUpto = cal.getTime();

			latestImpactIndicatorTarget = new ImpactIndicatorTarget();
			latestImpactIndicatorTarget.setIndicatorName(indicatorName);
			latestImpactIndicatorTarget.setValidFrom(newValidFrom);
			latestImpactIndicatorTarget.setValidUpto(newValidUpto);
			
			if(null == latestImpactIndicatorTarget.getCreatedDate())
				latestImpactIndicatorTarget.setCreatedDate(createdDate);
			
			latestImpactIndicatorTarget.setLastModifiedDate(lastModifiedDate); 
		}

		latestImpactIndicatorTarget.setTargetValue(targetValue.doubleValue());
		impactIndicatorTargetRepository.saveAndFlush(latestImpactIndicatorTarget);

		if (ValidityPeriod.FISCAL.equals(validityPeriod)) {
			impactIndicatorTargetRepository.updateAllTargetValuesForIndicatorName(indicatorName, targetValue, fiscalStartDate);
		}

	}


	
	@Override
	public void updateImpactIndicatorTarget(ImpactIndicatorName indicatorName, Number targetValue,
			ValidityPeriod validityPeriod, Date fiscalStartDate) {
		
		ImpactIndicatorTarget latestImpactIndicatorTarget = fetchImpactIndicatorTarget(indicatorName, fiscalStartDate);
		
		// Fetch latest value and update it. If latest value is not for current month,
		// create new entity for current month and save it
		if (latestImpactIndicatorTarget == null || !isValidForCurrentMonth(latestImpactIndicatorTarget)) {
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.HOUR, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);

			cal.set(Calendar.DAY_OF_MONTH, 1);
			Date newValidFrom = cal.getTime();

			cal.add(Calendar.MONTH, 1);
			cal.add(Calendar.DATE, -1);
			Date newValidUpto = cal.getTime();

			latestImpactIndicatorTarget = new ImpactIndicatorTarget();
			latestImpactIndicatorTarget.setIndicatorName(indicatorName);
			latestImpactIndicatorTarget.setValidFrom(newValidFrom);
			latestImpactIndicatorTarget.setValidUpto(newValidUpto);
		}

		latestImpactIndicatorTarget.setTargetValue(targetValue.doubleValue());
		if(indicatorName.equals(ImpactIndicatorName.OVERALLREVENUEACHIEVED)){
			businessStrategyConfigurationRepository.updateTargetValuesForCurrentMonth("businessRevenueTarget", targetValue, validityPeriod.name());
		}
		else{
			impactIndicatorTargetRepository.saveAndFlush(latestImpactIndicatorTarget);
		}

		if (ValidityPeriod.FISCAL.equals(validityPeriod)) {
			if(indicatorName.equals(ImpactIndicatorName.OVERALLREVENUEACHIEVED)){
				businessStrategyConfigurationRepository.updateAllTargetValuesForRevenueName("businessRevenueTarget", targetValue);
			}
			else{
				impactIndicatorTargetRepository.updateAllTargetValuesForIndicatorName(indicatorName, targetValue, fiscalStartDate);
			}
		}

	}

	private boolean isValidForCurrentMonth(
			ImpactIndicatorTarget latestImpactIndicatorTarget) {
		boolean isValidForCurrentMonth = false;
		Date validFrom = latestImpactIndicatorTarget.getValidFrom();
		Date validUpto = latestImpactIndicatorTarget.getValidUpto();
		long currentTimeMillis = System.currentTimeMillis();

		if (currentTimeMillis >= validFrom.getTime() && currentTimeMillis <= validUpto.getTime()) {
			isValidForCurrentMonth = true;
		}
		return isValidForCurrentMonth;
	}

	@Override
	public void saveImpactIndicatorHistory(Map<ImpactIndicatorName, Number> indicatorHistory) {
		try {
			for (Map.Entry<ImpactIndicatorName, Number> entry : indicatorHistory.entrySet()) {
				ImpactIndicatorHistory impactIndicatorHistory = impactIndicatorHistoryRepository
						.findOneByIndicatorName(entry.getKey());
				if (impactIndicatorHistory == null) {
					impactIndicatorHistory = new ImpactIndicatorHistory();
				}
				impactIndicatorHistory.setIndicatorName(entry.getKey());
				impactIndicatorHistory.setValue(entry.getValue().doubleValue());
				impactIndicatorHistoryRepository.saveAndFlush(impactIndicatorHistory);
			}
		}
		catch (Exception e) {
			LOG.error("error while saveBusinessImpactIndicatorHistory" + e.toString());
			LOG.debug(e.getMessage(), e);
		}

	}

	@Override
	public ImpactIndicatorHistory getImpactIndicatorTrendvalue(ImpactIndicatorName impactIndicatorName) {
		ImpactIndicatorHistory impactIndicatorHistory = null;
		try{
		impactIndicatorHistory = impactIndicatorHistoryRepository
				.findOneByIndicatorName(impactIndicatorName);
		}
		catch(Exception e){
			LOG.error("error while getImpactIndicatorTrendvalue" + e.toString());
			LOG.debug(e.getMessage(), e);
		}
		return impactIndicatorHistory;
	}
}
