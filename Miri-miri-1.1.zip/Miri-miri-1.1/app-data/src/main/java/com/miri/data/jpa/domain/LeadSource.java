package com.miri.data.jpa.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "lead_source")
public class LeadSource implements Serializable{
	
	private static final long serialVersionUID = -5243902889979720502L;

	@Id
	@Column(name="id")
	@GeneratedValue()
	private Long id;
	
	@Column(name="lead_source")
	private String leadSource;
	
	@Column(name="opportunities")
	private String opportunities;
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getLeadSource() {
		return leadSource;
	}
	
	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}
	
	public String getOpportunities() {
		return opportunities;
	}
	
	public void setOpportunities(String opportunities) {
		this.opportunities = opportunities;
	}
}
