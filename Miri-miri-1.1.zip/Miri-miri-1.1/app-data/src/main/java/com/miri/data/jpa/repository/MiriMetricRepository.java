package com.miri.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.MiriMetric;

/**
 * MiriMetricRepository: that provides  methods to perform database operations on miri_metric table
 * @author noor
 */
@Repository
public interface MiriMetricRepository extends JpaRepository<MiriMetric, Long>{
	
	List<MiriMetric> findAll();
	
	@Query("from MiriMetric mid where mid.id = ?1")
	MiriMetric findMetricById(Long Id);
	

}
