/**
 * 
 */
package com.miri.data.jpa.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.data.jpa.domain.MiriCISInteractionConfig;
import com.miri.data.jpa.service.MiriAppConfigService;

/**
 * Holds configuration details in memory.
 * 
 * @author Chandra
 *
 */
@Component
public class AppConfigContainer {

	@Autowired
	MiriAppConfigService miriAppConfigService;

	private static Map<String, String> configMap = new HashMap<>();

	public Map<String, String> getConfigMap() {
		if (MapUtils.isEmpty(configMap)) {
			configMap = new HashMap<>();
			List<MiriCISInteractionConfig> configDetailsList = miriAppConfigService.getAllConfigDetails();
			for (MiriCISInteractionConfig miriCISInteractionConfig : configDetailsList) {
				configMap.put(miriCISInteractionConfig.getApp() + miriCISInteractionConfig.getType()
						+ miriCISInteractionConfig.getAction(), miriCISInteractionConfig.getValue());

			}
		}
		return configMap;
	}

	public String getCacheClearURL() {
		return getConfigMap().get(App.MIRI.getValue() + Type.CACHE.getValue() + Action.CACHE_CLEAR.getValue());
	}

	public String getCacheDisbaleURL() {
		return getConfigMap().get(App.MIRI.getValue() + Type.CACHE.getValue() + Action.CACHE_DISABLE.getValue());
	}

	public String getCacheEnableURL() {
		return getConfigMap().get(App.MIRI.getValue() + Type.CACHE.getValue() + Action.CACHE_ENABLE.getValue());
	}

	public String getMiriStatusCheck() {
		return getConfigMap().get(App.CIS.getValue() + Type.STATUS.getValue() + Action.CHECK.getValue());
	}
	
	public String getSchedulerRunPath(){
		//call cache
		return getConfigMap().get(App.CIS.getValue() +Type.SCHEDULER.getValue() + Action.RUN.getValue());
	}
	
	public String getSchedulerRestartPath(){
		return getConfigMap().get(App.CIS.getValue() + Type.SCHEDULER.getValue() + Action.RESTART.getValue());
	}
	
	public String getSchedulerStatusPath(){
		return getConfigMap().get(App.CIS.getValue() + Type.SCHEDULER.getValue() + Action.STATUS.getValue());
	}

	public String getSchedulerJobPropertyPath(){
		return getConfigMap().get(App.CIS.getValue() + Type.SCHEDULER.getValue() + Action.JOB_NAMES.getValue());
	}

	public static enum Type {
		CACHE("cache"), ES("es"), SCHEDULER("scheduler"), STATUS("status");

		private String value;

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}

		private Type(String value) {
			this.value = value;
		}
	}

	public static enum Action {
		CACHE_CLEAR("cache-clear"), CACHE_DISABLE("cache-disable"), CACHE_ENABLE("cache-enable"), RUN("run"), CHECK(
				"check"),RESTART("restart"),STATUS("status"),JOB_NAMES("jobNames");

		private String value;

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}

		private Action(String value) {
			this.value = value;
		}
	}

	public static enum App {
		MIRI("miri"), CIS("cis");

		private String value;

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}

		private App(String value) {
			this.value = value;
		}
	}

}
