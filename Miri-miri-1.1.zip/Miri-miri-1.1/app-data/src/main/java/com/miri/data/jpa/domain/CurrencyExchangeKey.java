/**
 * 
 */
package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Acts as composite key for CurrencyExchangerates entity.
 * 
 * @author Chandra
 *
 */
@Embeddable
public class CurrencyExchangeKey implements Serializable {

	private static final long serialVersionUID = 1221875563263282291L;

	@Column(name = "symbol")
	private String symbol;

	@Column(name = "date")
	private Date date;
	
	public CurrencyExchangeKey(String symbol, Date date) {
		super();
		this.symbol = symbol;
		this.date = date;
	}
	
	public CurrencyExchangeKey() {
		super();
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
