package com.miri.data.jpa.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author noor
 * Entity for the database table  miri_critical_field_impact_metric which has all the metrics and 
 * mapping to the critical field
 */
@Entity
@Table(name="miri_critical_field_impact_metric")
public class MiriCriticalFieldImpactMetric implements Serializable{
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 6953417046275987281L;

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	@JsonIgnore
	private Long id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="description")
	private String desctiption;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "miri_field_id")
	private MiriDocumentCriticalField miriCriticalField;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "miri_metric_id")
	private MiriMetric mriMetricId;
	
	@Column(name="sort_order")
	private int sortOrder;
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesctiption() {
		return desctiption;
	}

	public void setDesctiption(String desctiption) {
		this.desctiption = desctiption;
	}

	public MiriDocumentCriticalField getMiriCriticalField() {
		return miriCriticalField;
	}

	public void setMiriCriticalField(MiriDocumentCriticalField miriCriticalField) {
		this.miriCriticalField = miriCriticalField;
	}

	public MiriMetric getMriMetricId() {
		return mriMetricId;
	}

	public void setMriMetricId(MiriMetric mriMetricId) {
		this.mriMetricId = mriMetricId;
	}

	public int getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}
	
	
	
	
}
