/**
 * 
 */
package com.miri.data.jpa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miri.data.jpa.domain.ManualCSVTracker;
import com.miri.data.jpa.repository.ManualCSVTrackerRepository;
import com.miri.data.jpa.service.ManualCSVTrackerService;

/**
 * @author Chandra
 *
 */
@Service
public class ManualCSVTrackerServiceImpl implements ManualCSVTrackerService {

	@Autowired
	ManualCSVTrackerRepository manualCSVTrackerRepository;

	@Override
	public List<ManualCSVTracker> finalAllActive() {
		return manualCSVTrackerRepository.findAllActive();

	}

	@Override
	public ManualCSVTracker saveOrUpdateCSVTracker(ManualCSVTracker manualCSVTracker) {
		manualCSVTracker = manualCSVTrackerRepository.saveAndFlush(manualCSVTracker);
		return manualCSVTracker;
	}

	@Override
	public ManualCSVTracker findByfileName(String fileName) {
		return manualCSVTrackerRepository.findByFileName(fileName);
	}

	@Override
	public List<ManualCSVTracker> findByFileNameStartsWith(String fileName) {
		return manualCSVTrackerRepository.findByFileNameStartingWith(fileName);
	}
}
