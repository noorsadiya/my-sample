package com.miri.data.jpa.repository.accountSetup;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.CurrencyExchangeKey;
import com.miri.data.jpa.domain.CurrencyExchangeRates;

@Repository
public interface CurrencyExchangeRepository extends JpaRepository<CurrencyExchangeRates, CurrencyExchangeKey> {

	@Query("SELECT cer FROM CurrencyExchangeRates cer WHERE cer.currencyExchangeKey.date=?1")
	List<CurrencyExchangeRates> findByCurrencyExchangeKeyDate(Date date);

	@Query("SELECT cer FROM CurrencyExchangeRates cer WHERE cer.baseCurrency=?1 and cerquoteCurrency=?2 and cer.currencyExchangeKey.date=?3")
	CurrencyExchangeRates findByDateBaseAndQuoteCurrency(String baseCurrency, String quoteCurrency, Date date);
}
