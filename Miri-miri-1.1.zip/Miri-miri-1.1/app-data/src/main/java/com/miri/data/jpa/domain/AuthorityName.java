package com.miri.data.jpa.domain;

public enum AuthorityName {
	ROLE_MASTER,
	ROLE_ADMIN,
	ROLE_EXECUTIVE,
	ROLE_USER;

	public static boolean isRoleMaster(AuthorityName name) {
		return ROLE_MASTER.equals(name);
	}

	public static boolean isRoleAdmin(AuthorityName name) {
		return ROLE_ADMIN.equals(name);
	}

	public static boolean isRoleExecutive(AuthorityName name) {
		return ROLE_EXECUTIVE.equals(name);
	}
}
