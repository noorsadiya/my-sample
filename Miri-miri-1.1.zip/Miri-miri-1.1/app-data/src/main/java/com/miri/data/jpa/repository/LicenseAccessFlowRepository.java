package com.miri.data.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.LicenseAccessFlow;

@Repository
public interface LicenseAccessFlowRepository extends JpaRepository<LicenseAccessFlow, Long> {

	@Query("FROM LicenseAccessFlow lc WHERE lc.licenseType = ?1")
	public LicenseAccessFlow getLicenseAccessFlow(String type);

}
