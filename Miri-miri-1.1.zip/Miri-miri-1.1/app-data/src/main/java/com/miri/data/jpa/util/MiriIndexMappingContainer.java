package com.miri.data.jpa.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.data.jpa.domain.MiriCriticalFieldImpactMetric;
import com.miri.data.jpa.domain.MiriDocumentCriticalField;
import com.miri.data.jpa.domain.MiriIndex;
import com.miri.data.jpa.domain.MiriIndexDocument;
import com.miri.data.jpa.domain.MiriMetric;
import com.miri.data.jpa.service.MiriIndexMappingService;

/**
 * MiriIndexMappingContainer : provides methods to fetch data from the MiriIndexMappingService
 * and cache it in in-memory cache 
 * @author noor
 *
 */
@Component
public class MiriIndexMappingContainer {
	
	private static List<MiriIndex> indicesList = new ArrayList<>();
		
	private static Map<String,String> indicesMap=new HashMap<>();
			
	private static  Map<String,List<MiriIndexDocument>> indexAndDocuments=new HashMap<>();
	
	private static  Map<String,List<MiriDocumentCriticalField>> documentAndFields=new HashMap<>();
	
	private static  Map<String,List<MiriCriticalFieldImpactMetric>> fieldsAndImpactedMetrics=new HashMap<>();
	
	private static Map<String,String>  miriMetricMap=new HashMap<>();
	
	@Autowired
	MiriIndexMappingService miriIndexMappingService;
	
	/**
	 * getAllIndices : Retrieves all indices from the database 
	 * and stored in a static list
	 * @return List<MiriIndex>
	 */
	public List<MiriIndex> getAllIndices() {
		if(CollectionUtils.isEmpty(indicesList)){
			indicesList=miriIndexMappingService.getAllIndices();
		}
		return indicesList;
	}
	
	public Map<String,String> getAllIndexMap(){
		if(MapUtils.isEmpty(indicesMap)){
			MiriIndex miriIndex=null;
			List<MiriIndex> indexList= getAllIndices();
			for (Iterator<MiriIndex> iterator = indexList.iterator(); iterator.hasNext();) {
				miriIndex= iterator.next();
				indicesMap.put(String.valueOf(miriIndex.getId()), miriIndex.getType());
			}
		}
		return indicesMap;
	}

	public String getIndexTypeById(String id){
		Map<String,String> indicesMap=getAllIndexMap();
		return indicesMap.get(id);
	}
	/**
	 * getAllIndicesAndDocuments : Retrieves and indices, documents for each index
	 * and stores in Map<indexId,list of documents>
	 * @return Map<String,List<MiriIndexDocument>>
	 */
	public Map<String,List<MiriIndexDocument>> getAllIndicesAndDocuments(){
		MiriIndex miriIndex =null;
		List<MiriIndexDocument> documentsList=null;
		if(MapUtils.isEmpty(indexAndDocuments)){
			List<MiriIndex> indexList= getAllIndices();
			for (Iterator iterator = indexList.iterator(); iterator.hasNext();) {
				 miriIndex = (MiriIndex) iterator.next();
				documentsList=miriIndexMappingService.getAllDocumentsByIndexId(miriIndex);
				indexAndDocuments.put(String.valueOf(miriIndex.getId()), documentsList);
			}
		}
		return indexAndDocuments;
	}
	
	
	/**
	 * getAllDocumentsAndCriticalFields :  Retrieves all documents and critical fields for each document
	 * and stores in Map<document,list of fields>
	 * @return Map<String,List<MiriDocumentCriticalField>>
	 */
	public Map<String,List<MiriDocumentCriticalField>> getAllDocumentsAndCriticalFields(){
		MiriIndexDocument miriDocument=null;
		List<MiriDocumentCriticalField> fieldsList=null;
		if(MapUtils.isEmpty(documentAndFields)){
			List<MiriIndexDocument> documentList= miriIndexMappingService.getAllDocuments();
			for (Iterator iterator = documentList.iterator(); iterator.hasNext();) {
				miriDocument = (MiriIndexDocument) iterator.next();
				fieldsList=miriIndexMappingService.getAllFieldsByDocumentId(miriDocument);
				documentAndFields.put(String.valueOf(miriDocument.getId()), fieldsList);
			}
		}
		return documentAndFields;
	}
	
	/**
	 * getAllCriticalFieldsAndImpactedMetrics :  Retrieves all critical fields and  metric for each document
	 * and stores in Map<field,list of metrics>
	 * @return Map<String,List<MiriCriticalFieldImpactMetric>>
	 */
	public Map<String,List<MiriCriticalFieldImpactMetric>> getAllCriticalFieldsAndImpactedMetrics(){
		MiriDocumentCriticalField field =null;
		List<MiriCriticalFieldImpactMetric> metricList=null;
		if(MapUtils.isEmpty(fieldsAndImpactedMetrics)){
			List<MiriDocumentCriticalField> fieldList= miriIndexMappingService.getAllCriticalFields();
			for (Iterator iterator = fieldList.iterator(); iterator.hasNext();) {
				field = (MiriDocumentCriticalField) iterator.next();
				metricList=miriIndexMappingService.getAllMetricsByCriticalFieldId(field);
				fieldsAndImpactedMetrics.put(String.valueOf(field.getId()), metricList);
			}
		}
		return fieldsAndImpactedMetrics;
	}
	
	
	/**
	 * getAllCriticalFieldsAndImpactedMetrics :  Retrieves all critical fields and  metric for each document
	 * and stores in Map<metric id ,metric name>
	 * @return Map<String,String>
	 */
	public Map<String,String> getAllMiriMerics(){
		MiriMetric miriMetric =null;
		if(MapUtils.isEmpty(miriMetricMap)){
			List<MiriMetric> miriMterics =miriIndexMappingService.getAllMetrics();
			for (Iterator iterator = miriMterics.iterator(); iterator.hasNext();) {
				miriMetric = (MiriMetric) iterator.next();
				miriMetricMap.put(String.valueOf(miriMetric.getId()), miriMetric.getDescription());
			} 
			
		}
		return miriMetricMap;
	}
	
	/**
	 * getAllDocumentsByIndexId :  Retrieves all the documents of the index
	 * @return List<MiriIndexDocument>
	 */
	public List<MiriIndexDocument> getAllDocumentsByIndexId(String indexId) {
		if(MapUtils.isEmpty(indexAndDocuments)){
			indexAndDocuments=getAllIndicesAndDocuments();
		}
		return indexAndDocuments.get(indexId);
	}
	
	/**
	 * getAllFieldsByDocumentId :  Retrieves all the critical fields of the document
	 * @return List<MiriDocumentCriticalField>
	 */
	public List<MiriDocumentCriticalField> getAllFieldsByDocumentId(MiriIndexDocument documentId) {
		
		if(MapUtils.isEmpty(documentAndFields)){
			documentAndFields=getAllDocumentsAndCriticalFields();
		}
		return documentAndFields.get(String.valueOf(documentId.getId()));		
	}

	/**
	 * getAllMetricsByCriticalFieldId :  Retrieves all the metrics of the critical field id
	 * @return List<MiriDocumentCriticalField>
	 */
	public List<MiriCriticalFieldImpactMetric> getAllMetricsByCriticalFieldId(MiriDocumentCriticalField fieldId) {
		if(MapUtils.isEmpty(fieldsAndImpactedMetrics)){
			fieldsAndImpactedMetrics=getAllCriticalFieldsAndImpactedMetrics();
		}
		return fieldsAndImpactedMetrics.get(String.valueOf(fieldId.getId()));
	}

	
	/**
	 * getMetricByMetricId : returns the metric name of the metric id
	 * @return List<MiriDocumentCriticalField>
	 */
	public String getMetricByMetricId(Long id) {
		
		if(MapUtils.isEmpty(miriMetricMap)){
			miriMetricMap=getAllMiriMerics();
		}
		return miriMetricMap.get(String.valueOf(id));
	}
	

}