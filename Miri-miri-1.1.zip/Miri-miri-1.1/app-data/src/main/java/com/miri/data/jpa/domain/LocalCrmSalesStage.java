package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="local_crm_sales_stage")
public class LocalCrmSalesStage implements Serializable {
	private static final long serialVersionUID = 6898057002413485733L;

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	@JsonIgnore
	private Long id;

	@Column(name="stage_id")
	private String stageId;

	@Column(name="stage")
	private String stageName;

	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="localCrmSalesStage")
	private Set<CrmInstanceSalesStage> crmInstanceSalesStages;

	public LocalCrmSalesStage() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStageName() {
		return stageName;
	}

	public String getStageId() {
		return stageId;
	}

	public void setStageId(String stageId) {
		this.stageId = stageId;
	}

	public void setStageName(String stageName) {
		this.stageName = stageName;
	}

	public Set<CrmInstanceSalesStage> getCrmInstanceSalesStages() {
		return crmInstanceSalesStages;
	}

	public void setCrmInstanceSalesStages(Set<CrmInstanceSalesStage> crmInstanceSalesStages) {
		this.crmInstanceSalesStages = crmInstanceSalesStages;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((stageId == null) ? 0 : stageId.hashCode());
		result = prime * result + ((stageName == null) ? 0 : stageName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LocalCrmSalesStage other = (LocalCrmSalesStage) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (stageId == null) {
			if (other.stageId != null)
				return false;
		}
		else if (!stageId.equals(other.stageId))
			return false;
		if (stageName == null) {
			if (other.stageName != null)
				return false;
		}
		else if (!stageName.equals(other.stageName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("LocalCrmSalesStage [id=");
		builder.append(id);
		builder.append(", stageId=");
		builder.append(stageId);
		builder.append(", stageName=");
		builder.append(stageName);
		builder.append(", crmInstanceSalesStages=");
		builder.append(crmInstanceSalesStages);
		builder.append("]");
		return builder.toString();
	}
}
