package com.miri.data.jpa.repository.datasourceSetup;

import org.springframework.data.jpa.repository.JpaRepository;

import com.miri.data.jpa.domain.WebServiceVendorConfiguration;

public interface WebServiceVendorConfigurationRepository extends JpaRepository<WebServiceVendorConfiguration, Long>{
	
}
