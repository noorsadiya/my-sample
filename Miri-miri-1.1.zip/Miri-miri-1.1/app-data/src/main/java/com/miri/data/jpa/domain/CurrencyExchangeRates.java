package com.miri.data.jpa.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "currency_exchange_rates")
public class CurrencyExchangeRates implements Serializable {

	private static final long serialVersionUID = -5338741229620382166L;

	@Column(name = "base_currency")
	private String baseCurrency;

	@Column(name = "quote_currency")
	private String quoteCurrency;

	@EmbeddedId
	private CurrencyExchangeKey currencyExchangeKey;

	@Column(name = "exchange_rate")
	private float exchangeRate;

	public CurrencyExchangeRates(String baseCurrency, String quoteCurrency, CurrencyExchangeKey currencyExchangeKey,
			float exchangeRate) {
		super();
		this.baseCurrency = baseCurrency;
		this.quoteCurrency = quoteCurrency;
		this.currencyExchangeKey = currencyExchangeKey;
		this.exchangeRate = exchangeRate;
	}

	public CurrencyExchangeRates() {
		super();
	}

	public CurrencyExchangeRates(String baseCurrency, String quoteCurrency, String symbol, Date date,
			float exchangeRate) {
		super();
		this.currencyExchangeKey = new CurrencyExchangeKey(symbol, new java.sql.Date(date.getTime())); 
		new CurrencyExchangeRates(baseCurrency, quoteCurrency, currencyExchangeKey, exchangeRate);

	}

	public CurrencyExchangeKey getCurrencyExchangeKey() {
		return currencyExchangeKey;
	}

	public void setCurrencyExchangeKey(CurrencyExchangeKey currencyExchangeKey) {
		this.currencyExchangeKey = currencyExchangeKey;
	}

	public String getBaseCurrency() {
		return baseCurrency;
	}

	public void setBaseCurrency(String baseCurrency) {
		this.baseCurrency = baseCurrency;
	}

	public String getQuoteCurrency() {
		return quoteCurrency;
	}

	public void setQuoteCurrency(String quoteCurrency) {
		this.quoteCurrency = quoteCurrency;
	}

	public float getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(float exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

}
