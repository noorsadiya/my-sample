package com.miri.data.jpa.repository.datasourceSetup;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.miri.data.jpa.domain.CrmInstanceSalesStage;

@Repository
public interface CrmInstanceSalesStageRepository extends JpaRepository<CrmInstanceSalesStage, Long> {

	@Query("FROM CrmInstanceSalesStage ciss WHERE ciss.crmInstance.name = ?1 ")
	List<CrmInstanceSalesStage> findByVendor(String vendorInstanceName, Sort sort);

	List<CrmInstanceSalesStage> findAll();

	List<CrmInstanceSalesStage> findByCrmInstanceNameAndLocalCrmSalesStageIsNull(String name);

	void deleteById(Long id);
}
