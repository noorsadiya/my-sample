/**
 * 
 */
package com.miri.cache.client;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.util.DigestUtils;

/**
 * @author Chandra
 *
 */
@Component
public class CacheKeyUtil {
	private static final Logger LOGGER = Logger.getLogger(CacheKeyUtil.class);
	private static final String MD5_HASH = "MD5";

	/**
	 * Creates cache key based on the input arguments.
	 * 
	 * @param args
	 * @return
	 */
	public static String createKey(Object... args) {
		try {
			MessageDigest digest = getHashingInstance();
			feedDigest(digest, args);
			return getHexStringofHashData(digest);
		} catch (IOException | NoSuchAlgorithmException exception) {
			LOGGER.error("Exception while creating key: " + exception.getMessage(), exception);
		}
		return StringUtils.EMPTY;

	}
	
	public static void main(String[] args) {
		System.out.println(createKey("test","something")); 
	}

	private static String getHexStringofHashData(MessageDigest digest) {
		return DigestUtils.md5DigestAsHex(digest.digest());
	}

	private static void feedDigest(MessageDigest digest, Object... args) throws IOException {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
		for (Object obj : args) {
			objectOutputStream.writeObject(obj);
			digest.update(byteArrayOutputStream.toByteArray());
		}
	}

	private static MessageDigest getHashingInstance() throws NoSuchAlgorithmException {
		MessageDigest digest = MessageDigest.getInstance(MD5_HASH);
		return digest;
	}

}
