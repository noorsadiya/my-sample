/**
 * 
 */
package com.miri.cache.client;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import net.spy.memcached.MemcachedClient;

/**
 * @author Chandra
 * 
 *         CacheClientConfig: Contains cache client connection information such
 *         as host, port etc.
 * 
 *         TODO: Externalize properties.
 *
 */
@Component
public class MiriCacheClient {
	private static final Logger LOGGER = Logger.getLogger(MiriCacheClient.class);

	public static final int EXPIRE_IN_ONE_MIN = 60;

	public static final int EXPIRE_IN_ONE_SEC = 1;

	public static final int EXPIRE_IN_ONE_DAY = 60 * 60 * 24;

	public static final int EXPIRE_IN_ONE_HOUR = 60 * 60;

	public static final int EXPIRE_IN_ONE_MONTH = 60 * 60 * 24 * 30;

	public static final int EXPIRE_IN_HALF_DAY = 60 * 60 * 12;

	public static final int EXPIRE_IN_DEFAULT_TIME = EXPIRE_IN_ONE_DAY;

	private static MemcachedClient memcachedClient = null;

	private static MiriCacheClient miriCacheClient = null;

	private static boolean isEnabled = true;

	private static String host;
	
	public static String getHost() {
		return host;
	}

	@Value("${custom.memcached.host}")
	public void setHost(String host) {
		MiriCacheClient.host = host;
	}

	private MiriCacheClient() {
		super();
	}

	private static Map<String, Object> cacheMap = new ConcurrentHashMap<>();

	public static Map<String, Object> getCacheMap() {
		if (null == cacheMap)
			cacheMap = new ConcurrentHashMap<>();
		return cacheMap;
	}

	public static void setCacheMap(Map<String, Object> cacheMap) {
		MiriCacheClient.cacheMap = cacheMap;
	}

	/**
	 * Get Memcache client instance
	 * @return
	 */
	public static MemcachedClient getClientInstance() {
		// LOGGER.info("inside getClientInstance() method"); 
		if (null == memcachedClient) {
			try {
				if (StringUtils.isNotBlank(host)) {
					String[] str = host.split(":");
					// LOGGER.info("host name : " + host);
					memcachedClient = new MemcachedClient(new InetSocketAddress(str[0], Integer.valueOf(str[1])));
					// LOGGER.info("memcache object :" + memcachedClient);
				}
			} catch (IOException e) {
				LOGGER.error("IOException while getting the client instance: " + e.getMessage());
			}
		}
		return memcachedClient;
	}

	public static MiriCacheClient getInstance() {
		if (null == miriCacheClient) {
			miriCacheClient = new MiriCacheClient();
		}
		return miriCacheClient;
	}

	public Object get(final String key) {
		if (isEnabled) {
			try {
				if (StringUtils.isNotEmpty(key))
					if (null != memcachedClient)
						return getClientInstance().get(key);
					else
						return getCacheMap().get(key);

			} catch (Throwable throwable) {
				LOGGER.error("Exception while fetching cached data: ", throwable);
			}
		}
		return null;
	}

	public boolean set(final String key, final Object value) {
		return set(key, EXPIRE_IN_DEFAULT_TIME, value);
	}

	public boolean set(final String key, int time, final Object value) {
		if (isEnabled) {
			try {
				if (null != value) {
					// getClientInstance().set(key, time, value);
					if (null != memcachedClient)
						getClientInstance().set(key, EXPIRE_IN_DEFAULT_TIME, value);
					else
						getCacheMap().put(key, value);

					return true;
				}
			} catch (Throwable throwable) {
				LOGGER.error("Exception while caching data: ", throwable);
			}
		}
		return false;
	}

	public boolean clear() {
		try {
			if (null != getClientInstance())
				getClientInstance().flush();

			cacheMap = null;
			return true;
		} catch (Exception ex) {
			LOGGER.error("Exception while clearing memcache.", ex);
		}
		return false;
	}

	public void disable() {
		isEnabled = false;
	}

	public void enable() {
		isEnabled = true;
	}
}