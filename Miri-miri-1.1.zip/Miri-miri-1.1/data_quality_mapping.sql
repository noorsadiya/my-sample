insert into phaladata.miri_critical_field_impact_metric (name, description, miri_field_id, miri_metric_id, sort_order) values('','',42,24,7);

insert into phaladata.miri_critical_field_impact_metric (name, description, miri_field_id, miri_metric_id, sort_order) values('','',42,21,7);

insert into phaladata.miri_critical_field_impact_metric (name, description, miri_field_id, miri_metric_id, sort_order) values('','',21,6,7);

insert into phaladata.miri_critical_field_impact_metric (name, description, miri_field_id, miri_metric_id, sort_order) values('','',24,20,7);
