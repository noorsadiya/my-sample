# Miri
Phaladata -Miri backend repository

Git steps:

1. Clone the repository
2. Create Branch
3. Make changes and push the changes to your branch
4. Raise pull request

Application Setup:

Run mvn clean on phaladata -pom.xml
goto -> WebApplication.java available in "web" module.
Run As -> Spring boot App.

Application will be deployed to embedded Tomcat application server.

Run below to create basic tables required for spring security.
Dump20150921.sql

Graphs Service Urls : Dev Environment

Graph 1 :- V-M-1-Marketing Influenced/Sales Generated Revenue Achieved
http://10.132.160.129:9200:8080/miri/dashboard/visualize/measure/misgar/overall?chartType=multiAxes
http://10.132.160.129:9200:8080/miri/dashboard/visualize/measure/misgar/firstQuarter?chartType=multiAxes
http://10.132.160.129:9200:8080/miri/dashboard/visualize/measure/misgar/secondQuarter?chartType=multiAxes
http://10.132.160.129:9200:8080/miri/dashboard/visualize/measure/misgar/thirdQuarter?chartType=multiAxes
http://10.132.160.129:9200:8080/miri/dashboard/visualize/measure/misgar/thirdQuarter?chartType=multiAxes

Graph 2 :-V-M-5-Competitive win-rate
http://10.132.160.129:9200/miri/dashboard/visualize/measure/competitive-win-rate/overall
http://10.132.160.129:9200/miri/dashboard/visualize/measure/competitive-win-rate/marketing-campaign
http://10.132.160.129:9200/miri/dashboard/visualize/measure/competitive-win-rate/sales-campaign

Graph 3 :-V-U3-Top Regions
http://10.132.160.129:9200:8090/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved/overall
http://10.132.160.129:9200:8090/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved/sales-campaign
http://10.132.160.129:9200:8090/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved/marketing-campaign
http://10.132.160.129:9200:8090/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved/marketing-campaign?subDrillDown=sales-person
http://10.132.160.129:9200:8090/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved/marketing-campaign?subDrillDown=product
http://10.132.160.129:9200:8090/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved/marketing-campaign?subDrillDown=competitor
http://10.132.160.129:9200:8090/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved/sales-campaign?subDrillDown=sales-person
http://10.132.160.129:9200:8090/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved/sales-campaign?subDrillDown=product
http://10.132.160.129:9200:8090/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved/sales-campaign?subDrillDown=competitor
http://10.132.160.129:9200:8090/miri/dashboard/visualize/understand/top-regions-by-revenue-achieved/sales-campaign?subDrillDown=campaign

Graph 4 :-V-U4-Top Industries 
Overall
http://10.132.160.129:9200:8080/miri/dashboard/visualize/understand/top-industry-by-revenue/overall?chartType=barAction
MarketingInfluenced
http://10.132.160.129:9200:8080/miri/dashboard/visualize/understand/top-industry-by-revenue/marketing-campaign?chartType=barAction
http://10.132.160.129:9200:8080/miri/dashboard/visualize/understand/top-industry-by-revenue/marketing-campaign?chartType=barAction&subDrillDown=campaign
http://10.132.160.129:9200:8080/miri/dashboard/visualize/understand/top-industry-by-revenue/marketing-campaign?chartType=barAction&subDrillDown=sales-person
http://10.132.160.129:9200:8080/miri/dashboard/visualize/understand/top-industry-by-revenue/sales-campaign?chartType=barAction&subDrillDown=product
http://10.132.160.129:9200:8080/miri/dashboard/visualize/understand/top-industry-by-revenue/sales-campaign?chartType=barAction&subDrillDown=competitor
Sales Generated
http://10.132.160.129:9200:8080miri/dashboard/visualize/understand/top-industry-by-revenue/sales-campaign?chartType=barAction
http://10.132.160.129:9200:8080miri/dashboard/visualize/understand/top-industry-by-revenue/sales-campaign?chartType=barAction&subDrillDown=product
http://10.132.160.129:9200:8080/miri/dashboard/visualize/understand/top-industry-by-revenue/sales-campaign?chartType=barAction&subDrillDown=sales-person
http://10.132.160.129:9200:8080/miri/dashboard/visualize/understand/top-industry-by-revenue/sales-campaign?chartType=barAction&subDrillDown=competitor

Graph 5-V-M4-Best Performing Campaigns
http://10.132.160.129:9200:8080/miri/dashboard/visualize/connect/best-performing-campaigns/overall?chartType=basicLine
http://10.132.160.129:9200:8080/miri/dashboard/visualize/connect/best-performing-campaigns/firstQuarter?chartType=basicLine
http://10.132.160.129:9200:8080/miri/dashboard/visualize/connect/best-performing-campaigns/secondQuarter?chartType=basicLine
http://10.132.160.129:9200:8080/miri/dashboard/visualize/connect/best-performing-campaigns/thirdQuarter?chartType=basicLine
http://10.132.160.129:9200:8080/miri/dashboard/visualize/connect/best-performing-campaigns/fourthQuarter?chartType=basicLine
http://10.132.160.129:9200:8080/miri/dashboard/visualize/connect/best-performing-campaigns/oneyearplus?chartType=basicLine
http://10.132.160.129:9200:8080/miri/dashboard/visualize/connect/best-performing-campaigns/parentcampaign?chartType=basicLine