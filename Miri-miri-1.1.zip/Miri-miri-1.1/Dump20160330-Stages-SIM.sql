INSERT INTO `crm_instance_sales_stage`
VALUES (1,1,'07 - Closed Won',1),(2,1,'09 - Closed Lost',2),
(3,1,'05 - Negotiation',4),(4,1,'08 - Booked',1),(5,1,'01 - Prospect',3),
(6,1,'02 - Business Qualification',3),(7,1,'03 - Technical Qualification',3),
(8,1,'04 - Evaluation',4),(9,1,'06 - Approval',4),(10,1,'10 - Cancelled',2);
