/**
 * @author chavanka
 *
 */
package com.miri.search.service.visualize.connect;