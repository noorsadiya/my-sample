package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

/**
 * Geo Data for holding filter information for each country/region.
 * @author rammoole
 *
 */
public class GeoData implements Serializable {
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -7207768592347799082L;
	private List<String> filterData; //campaign, sales person, competitor, products
	private List<Double> filterRevenue;
	private List<Long> filterDeals;
	public List<String> getFilterData() {
		return filterData;
	}
	public void setFilterData(List<String> filterName) {
		this.filterData = filterName;
	}
	public List<Double> getFilterRevenue() {
		return filterRevenue;
	}
	public void setFilterRevenue(List<Double> revenue) {
		this.filterRevenue = revenue;
	}
	public List<Long> getDeals() {
		return filterDeals;
	}
	public void setDeals(List<Long> deals) {
		this.filterDeals = deals;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GeoData [filterData=" + filterData + ", filterRevenue=" + filterRevenue + ", filterDeals=" + filterDeals
				+ "]";
	}
}