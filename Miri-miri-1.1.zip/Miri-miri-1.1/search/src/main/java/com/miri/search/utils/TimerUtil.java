/**
 * 
 */
package com.miri.search.utils;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @author Chandra
 *
 */
@Component
@Scope("prototype")
public class TimerUtil {

	private long startTime = -1;

	private long endTime = -1;

	/**
	 * Sets start time of the timer.
	 */
	public void start() {
		startTime = System.currentTimeMillis();
	}

	/**
	 * Sets the end time of ther timer.
	 */
	public void end() {
		endTime = System.currentTimeMillis();
	}

	/**
	 * Checks the total time taken by subtracting the start time from end time.
	 * @return long time taken
	 */
	public long timeTakenInMillis() {
		if (endTime < 0) {
			this.end();
		}
		return endTime - startTime;
	}

	/**
	 * Checks the total time taken by subtracting the start time from end time.
	 * @return long time taken
	 */
	public double timeTakenInSec() {
		return timeTakenInMillis() / 1000;
	}

}
