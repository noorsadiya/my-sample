package com.miri.search.constants;

/**
 * CRM index related field constants - prefix the document type to the field
 * @author rammoole
 *
 */

public class CRMConstants {

	public final static String PRODUCT_RAW = "product.raw";
	
	public final static String PRODUCT = "product";
	
	// CRM/crm_campaign Constants 
	public final static String CAMPAIGN_ID = "campaignId";
	public final static String CAMPAIGN_ID_RAW = "campaignId.raw";
	
	public final static String CAMPAIGN_NAME = "campaignName";
	public final static String CAMPAIGN_NAME_RAW = "campaignName.raw";
	
	public final static String CAMPAIGN_PARENT_CAMPAIGN_ID = "parentCampaignId";
	public final static String CAMPAIGN_PARENT_CAMPAIGN_ID_RAW = "parentCampaignId.raw";

	public final static String CAMPAIGN_PRIMARY_CAMP_SOURCE ="primaryCampSource";
	public final static String CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW ="primaryCampSource.raw";

	//lead constants
	public static final String LEAD_CREATED_DATE = "createdDate";
	public static final String LEAD_ID_RAW = "leadId.raw";
	
	// CRM/crm_opportunity constants..
	public static final String OPPORTUNITY_PRIMARY_CAMP_SOURCE = "primaryCampSource";
	public static final String OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW = "primaryCampSource.raw";

	public static final String OPPORTUNITY_STAGE = "stage";
	public static final String OPPORTUNITY_STAGE_RAW = "stage.raw";
	
	public static final String OPPORTUNITY_OWNER = "owner";
	public static final String OPPORTUNITY_OWNER_RAW = "owner.raw";
	
	public static final String OPPORTUNITY_ID = "opportunityId";
	public static final String OPPORTUNITY_ID_RAW = "opportunityId.raw";
	
	public static final String OPPORTUNITY_NAME = "opportunityName";
	public static final String OPPORTUNITY_NAME_RAW = "opportunityName.raw";
	
	public static final String OPPORTUNITY_CREATED_ON = "createdOn";
	public static final String OPPORTUNITY_CREATED_DATE = "createdDate";
	public static final String OPPORTUNITY_CLOSED_DATE = "closedDate";
	
	public static final String OPPORTUNITY_AMOUNT = "amount";
	
	public static final String OPPORTUNITY_ACCOUNT_ID = "accountId";
	public static final String OPPORTUNITY_ACCOUNT_ID_RAW = "accountId.raw";
	
	public static final String OPPORTUNITY_TYPE = "opportunityType";
	public static final String OPPORTUNITY_TYPE_RAW = "opportunityType.raw";
	public static final String OPPORTUNITY_LEAD_SOURCE_RAW = "leadSource.raw";
	public static final String OPPORTUNITY_LEAD_SOURCE = "leadSource";
	public static final String OPPORTUNITY_TAGS_RAW = "tags.raw";
	

	public static final String OPPORTUNITY_INDUSTRY = "industry";
	public static final String OPPORTUNITY_LOCATION = "location";
	public static final String OPPORTUNITY_INDUSTRY_RAW = "industry.raw";
	
	public static final String OPPORTUNITY_COMPANY_NAME = "companyName";
	public static final String OPPORTUNITY_COMPANY_NAME_RAW = "companyName.raw";

	public final static String OPPORTUNITY_TYPE_NEW = "New";
	public final static String OPPORTUNITY_TYPE_EXISTING = "Existing";
	
	public static final String LEAD_SOURCE = "leadSource";
	public static final String LEAD_SOURCE_RAW = "leadSource.raw";		

	// CRM Account fields
	public static final String ACCOUNT_REGION_RAW = "region.raw";
	public static final String ACCOUNT_REGION = "region";
	
	public static final String SALES_PERSON = "owner";
	public static final String SALES_PERSON_RAW = "owner.raw";
	public static final String ACCOUNT_NAME = "accountName";
	
	
	public static final String ACCOUNT_INDUSTRY = "industry";
	public static final String ACCOUNT_INDUSTRY_RAW = "industry.raw";
	
	public static final String ACCOUNT_ID = "accountId";
	public static final String ACCOUNT_ID_RAW = "accountId.raw";
	
	public static final String ACCOUNT_NAME_RAW = "accountName.raw";
	
	//crm Partner Fields
	public static final String ACCOUNT_TO_ID = "accountToId";
	public static final String ACCOUNT_FROM_ID = "accountFromId";
	
	public static final String PROBABILITY_PERC = "probabilityPerc";
	public static final String PARTNER_ROLE = "partnerRole";
	public static final String PARTNER_ROLE_RAW = "partnerRole.raw";
	
	public static final String ACCOUNT_BILLING_ADDRESS_COUNTRY_RAW = "billingAddress.countryName.raw";
	public static final String ACCOUNT_BILLING_ADDRESS_COUNTRY= "billingAddress.countryName";
	
	public static final String ACCOUNT_CREATED_DATE = "createdDate";

	public static final String OPPORTUNITY_COMPETITOR_NAME_RAW = "competitorName.raw";
	public static final String CAMPAIGN_START_DATE = "startDate";

	public static final String PRODUCT_NAME_RAW = "productName.raw";
	public static final String PRODUCT_ID = "productId";
	
	public static final String PRODUCT_ID_RAW = "productId.raw";

	public static final String OPPORTUNITY_PRODUCT = "product";
	
	public static final String OPPORTUNITY_COMPETITOR_NAME = "competitorName";
	
	public static final String CAMPAIGN_ACTUALL_COST="actualCost";
	
	public static final String OPPORTUNITY_ASSETS="assets";

	public static final String OPPORTUNITY_PAIN_POINTS = "painPoints";
	public static final String ASSETS_COMBINED_RAW = "assetsCombined.raw";
	public static final String ASSETS_COMBINED = "assetsCombined";

	
	// crm Product
	public static final String CRM_PRODUCT_CODE = "productCode";
	public static final String CRM_PRODUCT_CODE_RAW = "productCode.raw";
	
	public static final String CRM_PRODUCT_LEVEL_ONE = "levelOne";
	public static final String CRM_PRODUCT_LEVEL_ONE_RAW = "levelOne.raw";
	
	public static final String CRM_PRODUCT_LEVEL_TWO = "levelTwo";
	public static final String CRM_PRODUCT_LEVEL_TWO_RAW = "levelTwo.raw";
	
	public static final String CRM_PRODUCT_LEVEL_THREE = "levelThree";
	public static final String CRM_PRODUCT_LEVEL_THREE_RAW = "levelThree.raw";
	
	public static final String CRM_PRODUCT_SOLUTION_FAMILY = "productFamily";
	public static final String CRM_PRODUCT_SOLUTION_FAMILY_RAW = "productFamily.raw";
	
	public static final String CRM_PRODUCT_PRODUCT_NAME = "productName";
	public static final String CRM_PRODUCT_PRODUCT_NAME_RAW = "productName.raw";
	
	public static final String CRM_PRODUCT_SOLUTION_LEVEL = "Solution_Area__c";
	public static final String CRM_PRODUCT_SOLUTION_LEVEL_RAW = "Solution_Area__c.raw";

	// CRM User
	public static final String CRM_USER_NAME = "username";
	public static final String COUNTRY = "country";
	public static final String COMPETITOR_RAW = "competitor.raw";
	public static final String CRM_USER_ID = "userId";
	public static final String OPPORTUNITY_COUNTRY_RAW = "country.raw";
	public static final String CRM_PRODUCT_ID_RAW = "productId.raw";
	public static final String CRM_PARENT_CAMPAIGN_NAME_RAW = "parentCampaignName.raw";

	public static final String CRM_PARENT_CAMPAIGN_NAME = "parentCampaignName";
	public static final String CRM_OPPORTUNITY_PARTNERS_RAW = "partners.raw";
	

}
