package com.miri.search.service.erp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHitsBuilder;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.SearchConstants;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;

/**
 * Services pertaining to erp/erp_opportunity_competitor document in elastic
 * search
 * 
 * @author noor
 *
 */

@Component
public class OpportunityCompetitorService extends MiriSearchService {

	private static final Logger LOG = LogManager.getLogger(OpportunityCompetitorService.class);

	/**
	 * Gets the Competitor name(s) by Opportunities
	 * @param list
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String,List<String>> getCompetitorByOpportunity(List<String> list, String startDate, String endDate){
		
		Map<String, List<String>> competitorMap = new HashMap<String,List<String>>();

		Client client=getTransportClient();
		
		BoolQueryBuilder boolQueryBuilder = MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW, list, 1000); 
		boolQueryBuilder.must(QueryBuilders.rangeQuery(SearchConstants.CREATED_DATE).from(startDate).to(endDate));
				
		SearchResponse opportunityRespose= client
				.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY_COMPETITOR.getText())
				.setSearchType(SearchType.DEFAULT).setQuery(boolQueryBuilder).setSize(1010).execute().actionGet();
		
			for(SearchHit hit : opportunityRespose.getHits()){
				
				String opportunity = hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString();
				String competitor = hit.getSource().get(SearchConstants.COMPETITOR_NAME).toString();
				
				addValues(opportunity, competitor, competitorMap);
			}
			
		return competitorMap;
	}	
	
	/**
	 * Handles if opportunity have multiple competitors.
	 * @param key
	 * @param value
	 * @param competitorMap
	 */
	private void addValues(String key, String value, Map<String, List<String>> competitorMap) {
		
		if (competitorMap.containsKey(key)) {

			List<String> tempList = competitorMap.get(key);

			tempList.add(value);
			competitorMap.put(key, tempList);
		} else {
			
			List<String> tempList = new ArrayList<String>();
			tempList.add(value);
			competitorMap.put(key, tempList);
		}
		
	}

	/**
	 * Get Competitor and Opportunities
	 * @param opportunitiesList
	 * @return
	 */
	public Map<String, List<String>> getCompetitorAndOpportunities(List<String> opportunitiesList) {
		Map<String, List<String>> compOpportunityMap = new HashMap<String, List<String>>();

		TopHitsBuilder tophits = AggregationBuilders.topHits(SearchConstants.TOTAL_HITS_AGGR).setSize(1000)
				.setFetchSource(SearchConstants.OPPORTUNITY_ID, null);

		TermsBuilder aggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(SearchConstants.COMPETITOR_NAME_RAW).size(0).subAggregation(tophits);
		
		BoolQueryBuilder termsQuery=MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW, 
				opportunitiesList, 1000);

		SearchResponse response = getTransportClient().prepareSearch(SearchConstants.ERP)
				.setTypes(SearchConstants.ERP_OPPORTUNTITY_COMPETITOR)
				.setQuery(termsQuery)
				.addAggregation(aggr)
				.setSize(0)
				.setSearchType(SearchType.QUERY_AND_FETCH).execute().actionGet();

		Terms aggTerms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);

		for (Bucket bucket : aggTerms.getBuckets()) {
			bucket.getKeyAsText();
			List<String> opportunitesListFoCampaign = new ArrayList<>();
			TopHits topHitsAggr = bucket.getAggregations().get(SearchConstants.TOTAL_HITS_AGGR);
			SearchHit[] opportunityHits = topHitsAggr.getHits().getHits();
			for (SearchHit searchhit : opportunityHits) {
				opportunitesListFoCampaign.add(searchhit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			compOpportunityMap.put(bucket.getKeyAsText().string(), opportunitesListFoCampaign);

		}

		LOG.info("getCompetitorAndOpportunities :- " + compOpportunityMap);
		return compOpportunityMap;

	}
	

    @Override
    public String getIndex() {
        return ElasticSearchEnums.ERP.getText();
    }

    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.CRM_OPPORTUNITY.getText();
    }

}
