/**
 * 
 */
package com.miri.search.service.crm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.base.VendorTypeEnum;
import com.miri.cis.entity.CrmOpportunityCompetitor;
import com.miri.cis.entity.ESEntity;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.FilterData;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;

/**
 * CRM Opportunity Competitor Service
 * @author rammoole
 *
 */
@Component
public class CRMOpportunityCompetitorService extends MiriSearchService {
    
	private static final Logger LOG = LogManager.getLogger(CRMOpportunityCompetitorService.class);
	
	@Autowired
	ESQueryUtils esQueryUtils;
	
	@Autowired
	ERPInvoiceService erpInvoiceService;
	
    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getIndex()
     */
    @Override
    public String getIndex() {
        return ElasticSearchEnums.CRM.getText();
    }

    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getDocumentType()
     */
    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.CRM_OPPORTUNITY_COMPETITOR.getText();
    }

    /**
     * Returns all competitors for the given opportunity.
     * 
     * @param OpportunityId
     * @return
     */
    public List<ESEntity> getAllCompetitorsByOpportunityId(final String opportunityId) {
        return esQueryUtils.getMultipleDocsByFKId(getDocumentType(), getIndex(), "opportunityId.raw", opportunityId);
    }
    
    /**
     * 
     * @param OpportunityId
     * @return
     */
    public CrmOpportunityCompetitor getCompetitorById(final String competitorName) {
        return (CrmOpportunityCompetitor)esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), "competitorName.raw", competitorName);
    }
	
	public CrmOpportunityCompetitor getCrmOpportunityCompetitorByOppId(String oppId) {
		CrmOpportunityCompetitor crmOpportunityCompetitor = null;
		SearchResponse oppSearch = getTransportClient()
				.prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY_COMPETITOR)
				.setQuery(QueryBuilders.boolQuery()
				.must(QueryBuilders.matchQuery(SearchConstants.OPPORTUNITY_ID_RAW, oppId)))
				.execute().actionGet();
		
		if(oppSearch.getHits().getHits().length > 0) {
			SearchHit searchHit = oppSearch.getHits().getAt(0);
			crmOpportunityCompetitor = (CrmOpportunityCompetitor) ESObjectMapper.getObject(searchHit.getSource(), ElasticSearchEnums.CRM_OPPORTUNITY_COMPETITOR.getText(), VendorTypeEnum.CRM.getText());
		}
				
		return crmOpportunityCompetitor;
	}
	

	public String getCompetitorByOppId(String oppId) {
		List<String> competitorNames = new ArrayList<>();
		SearchResponse oppSearch = getTransportClient()
				.prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY_COMPETITOR)
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.addField("competitorName")
				.setQuery(QueryBuilders.boolQuery()
				.must(QueryBuilders.matchQuery(SearchConstants.OPPORTUNITY_ID_RAW, oppId)))
				.execute().actionGet();
		
		while(true){
			for (SearchHit hit : oppSearch.getHits()) {
				// Whatever the records that we get are the map opportunities
				competitorNames.add(hit.field("competitorName").getValue().toString());
			}
			oppSearch = getTransportClient().prepareSearchScroll(oppSearch.getScrollId()).setScroll(new TimeValue(6000)).get();

			if(oppSearch.getHits().getHits().length == 0) {
				break;
			}
		}
				
		return StringUtils.join(competitorNames, ",");
	}
	
	/**
	 * Opportunities and competitors
	 * @param opportunityIds
	 * @return
	 */
	public List<FilterData> getDealsByCompetitorForOpportunities(List<String> opportunityIds, int size) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION).field(CRMConstants.OPPORTUNITY_COMPETITOR_NAME_RAW).size(0).minDocCount(1));
		
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Terms competitorTerms = searchResponse.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
		Collection<Terms.Bucket> competitorBuckets = competitorTerms.getBuckets();
		long maxHits = 0;
		for(Terms.Bucket bucket: competitorBuckets) {
			maxHits = bucket.getDocCount();
			break;
		}
		searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION).field(CRMConstants.OPPORTUNITY_COMPETITOR_NAME_RAW).size(0).minDocCount(1)
						.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITY_HITS).setSize((int) maxHits)));
		searchResponse = esQueryUtils.execute(searchRequestBuilder);
		competitorTerms = searchResponse.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
		competitorBuckets = competitorTerms.getBuckets();
		List<FilterData> competitorDeals = new ArrayList<>();
		FilterData filterData;
		List<String> opportunityids;
		for(Terms.Bucket bucket: competitorBuckets) {
			//LOG.info("competitor Bucket :" + bucket.getKey() + " opportunity Ids :"+ bucket.getDocCount());
			filterData = new FilterData();
			filterData.setDeals(bucket.getDocCount());
			filterData.setName(bucket.getKey());
			TopHits topHits = bucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITY_HITS);
			opportunityids = new ArrayList<>();
			for(SearchHit hit: topHits.getHits()) {
				opportunityids.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			double revenueAmount = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityids, null, null);
			filterData.setRevenue(revenueAmount);
			competitorDeals.add(filterData);
		}
		//LOG.info(competitorDeals);
		Collections.sort(competitorDeals);
		//LOG.info(competitorDeals);
		if(competitorDeals.size() > size) {
			return competitorDeals.subList(0, size);
		} else {
			return competitorDeals;
		}
	}
	
	/**
	 * Gets the opportunities of a competitor
	 * @param competitorName
	 * @return
	 */
	public List<String> getOpportunitiesOfCompetitor(String competitorName, final String startDate, final String endDate){
		
		List<String> opportunities = new ArrayList<>();
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_COMPETITOR_NAME_RAW, competitorName));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).from(startDate).to(endDate));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
													.setTypes(getDocumentType())
													.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
													.setSearchType(SearchType.SCAN)
													.setScroll(new TimeValue(6000));
		
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		while(true){
			for (SearchHit hit : searchResponse.getHits()) {
				opportunities.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));;
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return opportunities;
		
	}
}
