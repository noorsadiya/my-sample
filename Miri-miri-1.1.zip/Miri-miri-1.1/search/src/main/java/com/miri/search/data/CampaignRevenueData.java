package com.miri.search.data;

import java.io.Serializable;
import java.util.Map;

public class CampaignRevenueData implements Serializable {
	
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 8696558136485823383L;
	private String campaignName;
	private String parentCampaignName;
	private Long noOfDeals;
	private Double averageDealSize;
	private Double averageSellPrice;
	private Double revenueAmount;
	private Map<Object, CampaignRevenueData> revenuesByMonth;
	private Long noOfProducts;
	private Double campaignSpend;
	private String campaignId;
	private double invoiceCount;
	
	private String name;
	
	private String productName;
	
	private String competitorName;
	
	private String salesPerson;
	
	private Long dealsLost;
	
	private Double lostAmount;
	
	public double getInvoiceCount() {
		return invoiceCount;
	}
	
	public void setInvoiceCount(double invoiceCount) {
		this.invoiceCount = invoiceCount;
	}
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCompetitorName() {
		return competitorName;
	}
	public void setCompetitorName(String competitorName) {
		this.competitorName = competitorName;
	}
	public String getSalesPerson() {
		return salesPerson;
	}
	public void setSalesPerson(String salesPerson) {
		this.salesPerson = salesPerson;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}

	public Double getRevenueAmount() {
		if(null == revenueAmount)
			revenueAmount = 0.0;
		return revenueAmount;
	}
	public void setRevenueAmount(Double revenueAmount) {
		this.revenueAmount = revenueAmount;
	}
	public Map<Object, CampaignRevenueData> getRevenuesByMonth() {
		return revenuesByMonth;
	}
	public void setRevenuesByMonth(Map<Object, CampaignRevenueData> revenuesByMonth) {
		this.revenuesByMonth = revenuesByMonth;
	}
	public String getCampaignName() {
		return campaignName;
	}
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}
	
	/**
	 * @return the parentCampaignName
	 */
	public String getParentCampaignName() {
		return parentCampaignName;
	}
	/**
	 * @param parentCampaignName the parentCampaignName to set
	 */
	public void setParentCampaignName(String parentCampaignName) {
		this.parentCampaignName = parentCampaignName;
	}
	public Long getNoOfDeals() {
		return noOfDeals;
	}
	public void setNoOfDeals(Long noOfDeals) {
		this.noOfDeals = noOfDeals;
	}
	public Double getAverageDealSize() {
		return averageDealSize;
	}
	public void setAverageDealSize(Double averageDealSize) {
		this.averageDealSize = averageDealSize;
	}
	public Double getAverageSellPrice() {
		return averageSellPrice;
	}
	public void setAverageSellPrice(Double averageSellPrice) {
		this.averageSellPrice = averageSellPrice;
	}
	
	public void setNoOfProducts(Long noOfProducts) {
		this.noOfProducts = noOfProducts;
	}
	
	public Long getNoOfProducts() {
		return noOfProducts;
	}
	
	/**
	 * @return the campaignSpend
	 */
	public Double getCampaignSpend() {
		return campaignSpend;
	}
	/**
	 * @param campaignSpend the campaignSpend to set
	 */
	public void setCampaignSpend(Double campaignSpend) {
		this.campaignSpend = campaignSpend;
	}
	
	/**
	 * @return the campaignId
	 */
	public String getCampaignId() {
		return campaignId;
	}
	/**
	 * @param campaignId the campaignId to set
	 */
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}
	@Override
	public String toString() {
		return String.format(
				"CampaignRevenueData [campaignName=%s, noOfDeals=%s, averageDealSize=%s, averageSellPrice=%s, revenueAmount=%s, revenuesByMonth=%s]",
				campaignName, noOfDeals, averageDealSize, averageSellPrice, revenueAmount, revenuesByMonth);
	}
	/**
	 * @return the dealsLost
	 */
	public Long getDealsLost() {
		return dealsLost;
	}
	/**
	 * @param dealsLost the dealsLost to set
	 */
	public void setDealsLost(Long dealsLost) {
		this.dealsLost = dealsLost;
	}
	/**
	 * @return the lostAmount
	 */
	public Double getLostAmount() {
		return lostAmount;
	}
	/**
	 * @param lostAmount the lostAmount to set
	 */
	public void setLostAmount(Double lostAmount) {
		this.lostAmount = lostAmount;
	}
}
