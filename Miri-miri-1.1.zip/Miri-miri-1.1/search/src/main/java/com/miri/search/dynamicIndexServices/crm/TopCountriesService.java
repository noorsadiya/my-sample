package com.miri.search.dynamicIndexServices.crm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.children.ChildrenBuilder;
import org.elasticsearch.search.aggregations.bucket.children.InternalChildren;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Order;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.ColumnDrillDownData;
import com.miri.search.data.FilterData;
import com.miri.search.data.GeoData;
import com.miri.search.data.TopProductData;
import com.miri.search.dynamicIndexServices.MappedConstants;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;
import com.miri.search.service.map.MapCampaignService;

@Component
public class TopCountriesService extends MiriSearchService{
	
	@Autowired
	MapCampaignService mapCampaignService;
	
	@Autowired
	TopProductsByRevenueService productService;
	
	@Autowired
	ERPInvoiceService erpInvoiceService;
	
	@Override
	public String getIndex() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDocumentType() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	/**
	 * Gets top indistries By Opportunities
	 * @param size
	 * @param startDate
	 * @param endDate
	 * @param industries
	 * @param opportunities
	 * @return
	 */
	public Map<String, Object> getTopCountriesByOpportunities(String startDate, String endDate, Boolean isMarketing){
		Map<String, Object> countriesByRevenue = new LinkedHashMap<String, Object>();
		GeoData geoData;
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
				.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));	
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_COUNTRY_RAW, ""));
		
		if(null != isMarketing){
			List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();	
			if(isMarketing){
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
			}else
				boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}
		
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
												.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(parentSumBuilder).subAggregation(opportunityAggregation);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.COUNTRY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_COUNTRY_RAW).subAggregation(parentBuilder).size(0).order(Order.aggregation(MappedConstants.CHILDREN + ">" +SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		InternalChildren internalChildren = null;
		Sum sum = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.COUNTRY_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				List<String> fieldOpportunities = new ArrayList<>();
				internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
				for (Bucket opportunityBucket : opportunityBuckets) {
					fieldOpportunities.add(opportunityBucket.getKey());
				}
				revenue = erpInvoiceService.getInvoiceAmountByOpportunityIds(fieldOpportunities, startDate, endDate);
				if(revenue > 0){
					geoData = new GeoData();
					geoData.setDeals(Arrays.asList((long)opportunityBuckets.size(), 0l, 0l));
					geoData.setFilterData(Arrays.asList(SearchConstants.OVERALL_LABEL, SearchConstants.AVERAGE_SELL_PRICE_LABEL, SearchConstants.AVERAGE_DEAL_SIZE_LABEL));
					double asp = internalChildren.getDocCount() != 0 ? (revenue / (internalChildren.getDocCount() )) : 0;
					double ads =  opportunityBuckets.size() != 0 ? (revenue / (opportunityBuckets.size() )) : 0;
					geoData.setFilterRevenue(Arrays.asList(revenue, asp, ads));
					countriesByRevenue.put(termBucket.getKey(), geoData);
				}
			}
		}
		return countriesByRevenue;
	}
	
	
	/**
	 * Gets Top Countries with fields
	 * @param startDate
	 * @param endDate
	 * @param topIndusties
	 * @param opportunities
	 * @param field
	 * @param size
	 * @return 
	 */
	public Map<String, Object> topCountriesByField(String startDate, String endDate, String field, int size, Boolean isMarketing){
		Map<String, Object> countriesByCampaignMarketingInfluencedRevenue = new LinkedHashMap<String, Object>();
		GeoData geoData;
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
				.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));	
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_COUNTRY_RAW, ""));
		if(null != isMarketing){
			List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();	
			if(isMarketing){
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
			}else
				boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
											   .field(CRMConstants.OPPORTUNITY_ID_RAW)
											   .size(0);
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
									  .field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
										.childType(MappedConstants.CRM_ERP_MAPPED)
										.subAggregation(parentSumBuilder)
										.subAggregation(opportunityAggregation);
		
		TermsBuilder fieldAggregator =  AggregationBuilders.terms(SearchConstants.FIELD_AGGREGATION)
										.field(field)
										.size(size)
										.order(Order.aggregation(MappedConstants.CHILDREN + ">" +SearchConstants.SUM_AGGREGATION, false))
										.subAggregation(parentBuilder);
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.COUNTRY_AGGREGATION)
											.field(CRMConstants.OPPORTUNITY_COUNTRY_RAW)
											.size(0)
											.order(Order.aggregation(MappedConstants.CHILDREN + ">" +SearchConstants.SUM_AGGREGATION, false))
											.subAggregation(fieldAggregator)
											.subAggregation(parentBuilder);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
													.setTypes("crm_Opportunity_campaign_mapped")
													.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
													.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		Collection<Terms.Bucket> termsBuckets = null;
		InternalChildren internalChildren = null;
		Sum sum = null;
		List<String> filterData;
		List<Double> filterRevenue;
		List<Long> filterDeals;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.COUNTRY_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				List<String> opportunities =  new ArrayList<>();
				geoData = new GeoData();
				filterData = new ArrayList<>();
				filterRevenue = new ArrayList<>();
				filterDeals = new ArrayList<>();
				internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
				for(Bucket opportunityBucket :  opportunityBuckets){
					opportunities.add(opportunityBucket.getKey());
				}
				revenue = sum.getValue();
				double asp = internalChildren.getDocCount() != 0 ? (revenue / (internalChildren.getDocCount() )) : 0;
				double ads =  opportunityBuckets.size() != 0 ? (revenue / (opportunityBuckets.size() )) : 0;
				filterDeals.addAll(Arrays.asList((long)opportunityBuckets.size(), 0l, 0l));
				filterData.addAll(Arrays.asList(SearchConstants.MARKETING_INFLUENCED_LABEL, SearchConstants.AVERAGE_SELL_PRICE_LABEL, SearchConstants.AVERAGE_DEAL_SIZE_LABEL));
				filterRevenue.addAll(Arrays.asList(revenue, asp, ads));
				List<FilterData> dealsByCampaign = this.getChildData(termBucket);
				for(FilterData filterInfo: dealsByCampaign) {
					filterData.add(filterInfo.getName());
					filterRevenue.add(filterInfo.getRevenue());
					filterDeals.add(filterInfo.getDeals());
				}
				geoData.setDeals(filterDeals);
				geoData.setFilterData(filterData);
				geoData.setFilterRevenue(filterRevenue);
				countriesByCampaignMarketingInfluencedRevenue.put(termBucket.getKey(), geoData);
			}
		}
		return countriesByCampaignMarketingInfluencedRevenue;
	}
	/**
	 * Gets Top Countries with fields
	 * @param startDate
	 * @param endDate
	 * @param topIndusties
	 * @param opportunities
	 * @param field
	 * @param size
	 * @return 
	 */
	public Map<String, Object> topCountriesByProducts(String startDate, String endDate,int size, Boolean isMarketing){
		Map<String, Object> countriesByCampaignMarketingInfluencedRevenue = new LinkedHashMap<String, Object>();
		GeoData geoData;
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
				.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));	
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_COUNTRY_RAW, ""));
		if(null != isMarketing){
			List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();	
			if(isMarketing){
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
			}else
				boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW)
				.size(0);
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED)
				.subAggregation(parentSumBuilder)
				.subAggregation(opportunityAggregation);
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.COUNTRY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_COUNTRY_RAW)
				.size(0)
				.order(Order.aggregation(MappedConstants.CHILDREN + ">" +SearchConstants.SUM_AGGREGATION, false))
				.subAggregation(parentBuilder);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		Collection<Terms.Bucket> termsBuckets = null;
		InternalChildren internalChildren = null;
		Sum sum = null;
		List<String> filterData;
		List<Double> filterRevenue;
		List<Long> filterDeals;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.COUNTRY_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				List<String> opportunities =  new ArrayList<>();
				geoData = new GeoData();
				filterData = new ArrayList<>();
				filterRevenue = new ArrayList<>();
				filterDeals = new ArrayList<>();
				internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
				for(Bucket opportunityBucket :  opportunityBuckets){
					opportunities.add(opportunityBucket.getKey());
				}
				revenue = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunities, startDate, endDate);
				double asp = internalChildren.getDocCount() != 0 ? (revenue / (internalChildren.getDocCount() )) : 0;
				double ads =  opportunityBuckets.size() != 0 ? (revenue / (opportunityBuckets.size() )) : 0;
				filterDeals.addAll(Arrays.asList((long)opportunityBuckets.size(), 0l, 0l));
				filterData.addAll(Arrays.asList(SearchConstants.MARKETING_INFLUENCED_LABEL, SearchConstants.AVERAGE_SELL_PRICE_LABEL, SearchConstants.AVERAGE_DEAL_SIZE_LABEL));
				filterRevenue.addAll(Arrays.asList(revenue, asp, ads));
				List<FilterData> dealsByCampaign = this.getProductData(opportunities, startDate, endDate, SearchConstants.SUB_LEVEL_SIZE);
				for(FilterData filterInfo: dealsByCampaign) {
					filterData.add(filterInfo.getName());
					filterRevenue.add(filterInfo.getRevenue());
					filterDeals.add(filterInfo.getDeals());
				}
				geoData.setDeals(filterDeals);
				geoData.setFilterData(filterData);
				geoData.setFilterRevenue(filterRevenue);
				countriesByCampaignMarketingInfluencedRevenue.put(termBucket.getKey(), geoData);
			}
		}
		return countriesByCampaignMarketingInfluencedRevenue;
	}
		
	
	/**
	 * Extracts child Data From the Bucket
	 * @param termBucket
	 * @return
	 */
	public List<FilterData> getChildData(Bucket termBucket){
		List<FilterData> fieldData = new ArrayList<>();
		FilterData filterData = null;
		InternalChildren internalChildren = null;
		Terms terms = termBucket.getAggregations().get(SearchConstants.FIELD_AGGREGATION);
		List<Bucket> termsBuckets = terms.getBuckets();
		Sum sum = null;
		for (Terms.Bucket bucket : termsBuckets) {
			if(StringUtils.isNotBlank(bucket.getKey())){
				internalChildren  = bucket.getAggregations().get(MappedConstants.CHILDREN);
				sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				List<Bucket> opportunityTermBuckets = opportunityTerms.getBuckets();
				filterData = new FilterData();
				filterData.setName(bucket.getKey());
				filterData.setRevenue(sum.getValue());
				filterData.setDeals((long) opportunityTermBuckets.size());
				fieldData.add(filterData);
			}
		}
		return fieldData;
	}
	
	public List<FilterData> getProductData(List<String> opportunities, String startDate, String endDate, int size){
		List<TopProductData> topProductsByOpportunities = productService.getTopProductsByOpportunities(size, startDate, endDate, opportunities);
		List<FilterData> fieldData = new ArrayList<>();
		FilterData filterData = null;
		for(TopProductData topProductData : topProductsByOpportunities){
			filterData = new FilterData();
			filterData.setName(topProductData.getName());
			filterData.setRevenue(topProductData.getValue());
			filterData.setDeals(topProductData.getDealsClosed());
			fieldData.add(filterData);
		}
		return fieldData;
	}
}
