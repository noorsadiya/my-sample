package com.miri.search.constants;

/**
 * Contains Search Module Constants
 *
 * @author rammoole
 *
 */
public final class SearchConstants {

	// Elastic Search - Indices
	public final static String ERP = "erp";
	public final static String MANUAL = "manual";
	public final static String MAP = "map";
	public final static String CRM = "crm";

	// Elastic Search-Document Types- Map
	public static final String MAP_CAMPAIGN = "map_campaign";
	public static final String MAP_LEAD = "map_lead";
	public static final String MAP_OPPORTUNITY = "map_opportunity";
	// Elastic Search-Document Types- CRM
	public final static String CRM_OPPORTUNITY = "crm_opportunity";
	public final static String CRM_ACCOUNT = "crm_account";
	public final static String CRM_CAMPAIGN = "crm_campaign";
	public final static String CRM_PRODUCT = "crm_product";
	public final static String CRM_LEAD = "crm_lead";
	public final static String CRM_OPPORTUNITY_PRODUCT = "crm_opportunity_product";
	public final static String CRM_OPPORTUNITY_COMPETITOR = "crm_opportunity_competitor";

	// Elastic Search-Document Types- ERP
	public final static String ERP_INVOICE = "erp_invoice";
	public final static String ERP_SALES_ORDER = "erp_sales_order";

	public final static String ERP_OPPORTUNTITY_COMPETITOR = "erp_opportunity_competitor";
	public final static String ERP_ACCOUNT = "erp_account";

	// Elastic Search-Document Types- MANUAL
	public final static String ACCOUNT_STRATEGY = "account_strategy";
	public final static String BUSINESS_STRATEGY = "business_strategy";
	public final static String CAMPAIGN_STRATEGY = "campaign_strategy";
	public static final String MANUAL_INDICATOR_TYPE = "impact_indicators";

	// Elastic Search -Document Fields -ERP Manual

	public final static String FISCAL_YEAR = "fiscalYear";
	public final static String SG_REVENUE_ACHIEVED = "sgRevenueAchived";
	public final static String MI_REVENUE_TARGET = "marketingInfluencedRevenueTarget";
	public final static String BUSINESS_REVENUE_TARGET = "businessRevenueTarget";
	public final static String CAMPAIGN_ID = "campaignId";
	public final static String CAMPAIGN_NAME = "campaignName";
	public final static String PARENT_CAMPAIGN_ID_RAW = "parentCampaignId.raw";
	public final static String PARENT_CAMPAIGN_ID = "parentCampaignId";
	public final static String PRIMARY_CAMP_SOURCE = "primaryCampSource.raw";

	public final static String CAMPAIGN_NAME_RAW = "campaignName.raw";

	// Elastic Search -Document Fields -ERP Invoice
	public final static String INVOICE_CREATION_DATE = "createdDate";
	public final static String ERP_INVOICE_CREATION_DATE = "createdDate";
	public final static String ERP_INVOICE_PRODUCT_QUANTITY = "productQuantity";

	// Elastic Search -Document Fields - CRM Product
	public final static String PRODUCT_ID_RAW = "productId.raw";
	public final static String PRODUCT_ID = "productId";
	public final static String OPPORTUNITY_TYPE_NEW = "New";
	public final static String OPPORTUNITY_TYPE_EXISTING = "Existing";
	public final static String CUSTOMER_TYPE_NEW = "New";
	public final static String PRODUCT_NAME = "productName";

	public final static String ITEM_ID_RAW = "itemId.raw";
	public final static String ACCOUNT_ID = "accountId";
	public final static String ACCOUNT_ID_RAW = "accountId.raw";
	public final static String ORDER_ID = "orderId";
	public final static String ORDER_ID_RAW = "orderId.raw";
	public final static String SALE_ORDER_ID_RAW = "saleOrderId.raw";
	public final static String OPPORTUNITY_ID_RAW = "opportunityId.raw";
	public final static String ACCOUNT_OWNER_RAW = "accountOwner.raw";
	public final static String SALES_OWNER_RAW = "salesOwner.raw";
	public final static String LEAD_ID = "leadId";
	public final static String LEAD_SOURCE_RAW = "leadSource.raw";
	public final static String SALES_PERSON_RAW = "owner.raw";
	public final static String SALES_AMOUNT = "salesAmount";
	public final static String STAGE_RAW = "stage.raw";
	public final static String OPPORTUNITY_ID = "opportunityId";
	public final static String AMOUNT = "amount";
	public final static String OWNER_RAW = "owner.raw";
	public final static String CREATED_ON = "createdOn";
	public final static String PRODUCT_QUANTITY = "productQuantity";
	public static final String CAMPAIGN_SPEND = "actualCost";
	public static final String STAGE = "stage";
	public static final String LAST_MODIFIED_DATE = "lastModifiedDate";
	public static final Object MARKETING_INFLUENCED_REVENUE_TARGET = "marketingInfluencedRevenueTarget";
	public final static String CRM_CAMPAIGN_NAME = "campaignName";
	public static final String START_DATE = "startDate";
	public static final String END_DATE = "endDate";

	public final static String COUNTRY = "country";
	public final static String CODES = "codes";
	public static final String CREATED_DATE = "createdDate";
	public static final String UPDATED_DATE = "updatedDate";
	public static final String OTHERS = "others";
	public static final String OPPORTUNITY_NAME = "opportunityName";
	public static final String PROBABILITY_PERC = "probabilityPerc";
	public static final String COMPETITOR_NAME_RAW = "competitorName.raw";

	public final static String MAP_CAMPAIGN_ID = "campaignId";
	public final static String MAP_CAMPAIGN_NAME = "campaignName";

	public static final String ACCOUNT_NAME = "accountName";
	public static final String ACCOUNT_NAME_RAW = "accountName.raw";
	public static final String OPPORTUNITY_TYPE = "opportunityType";
	public static final String BILLING_ADDRESS = "billingAddress";
	public static final String COUNTRY_NAME = "countryName";
	public static final String CAMPAIGN_ID_RAW = "campaignId.raw";
	public static final String PRIMARY_CAMPAIGN_SOURCE_RAW = "primaryCampSource.raw";
	public final static String ERP_SALES_PERSON_RAW = "salesPerson.raw";

	public final static String MANUAL_CAMPAIGN_NAME = "campaignName";

	// Elastic Search - Document Field Values
	public final static String EXPECTED_REVENUE = "expectedRevenue";

	// Elastic Search -Document Fields -ERP Competitor
	public final static String COMPETITOR_NAME = "competitorName";

	// Aggregation names
	public final static String INVOICE_DATE_AGGEGATION = "invoiceSortByMonth";
	public final static String SUM_INVOICE_AMOUNT_BY_MONTH = "invoiceSumByMonth";
	public final static String TERMS_AGGREGATION = "termsAggr";
	public final static String DATE_RANGE = "dateRange";
	public final static String PROBABILITY_AGGREGATION = "probabilityAggregation";
	public final static String AMOUNT_AGGREGATION = "amountAggregation";
	public static final String COUNTRY_AGGREGATION = "countryAggregation";
	// Manual Account Strategy Document fields
	public static final String MIRT_ID = "id";
	public static final String MIRT_VALUE = "value";

	// DrillDownnTypes
	public final static String BUSINESS_STRATEGY_DATE_AGGEGATION = "BusinessStrategyDate";
	public final static String SUM_BUSINESS_STRATEGY_BY_MONTH = "BusinessStrategySumAggr";
	public final static String MI_REVENUE_TARGET_AGGEGATION = "MIRevenueDateAggr";
	public final static String SUM_MI_REVENUE_TARGET_BY_MONTH = "MIRevenueSumAggr";
	public final static String WON_AGGREGATION = "wonAggregation";
	public final static String LOST_AGGREGATION = "lostAggregation";
	public final static String LOST_OPPORTUNITIES_AMOUNT = "lostOpportunitiesAmount";
	public final static String TOP_WON_OPPORTUNITY_HITS = "topWonOpportunityHits";
	public final static String SUM_INVOICE_AMOUNT_BY_CUSTOMER = "invoiceByCustomer";
	public final static String SALES_PERSON_AGGREGATION = "salesPersonAggregation";
	public final static String SUM_AGGREGATION = "sumAggregation";
	public final static String CAMPAIGN_AGGREGATION = "campaignAggregation";
	public final static String TOP_OPPORTUNITIES_AGGREGATION = "topOpportunities";
	public static final String AVG_AGGREGATION = "avgAggregation";
	public static final String RANGE_AGGREGATION = "rangeAggregation";
	public static final String INVOICE_AMOUNT_AGGREGATION = "invoiceAmountAggregation";
	public static final String QUANTITY_AGGREGATION = "quantityAggregation";
	public static final String DATE_HISTOGRAM = "dateHistoggramAggregation";
	public static final String PRODUCT_QUANTITY_DATE_AGGREGATION = "prodDateAggr";
	public static final String PRODUCT_QUANTITY_SUM_AGGREGATION = "prodSumAggr";
	public static final String CAMPAIGN_ACCOUNT_ID = "campaignAccountId";
	public static final String SALES_ORDER_ITEMS_AGGREGATION = "salesOrderAggr";
	public static final String ERP_OPPORTUNITY_COMPETITOR_AGGREGATION = "erpOpportunityCompetitorAggr";
	public static final String ERP_ORDER_ITEMS_AGGREGATION = "erpOrderItemsAggr";

	public static final String ACCOUNT_AGGREGATION = "accountAggregation";
	public static final String OPPORTUNITY_TYPE_AGGREGATION = "opportunityTypeAggrregation";
	public static final String OPPORTUNITY_AGGREGATION = "opportunityAggregation";

	public static final String FISCAL_RANGE_FILTER = "fiscalRangeFilter";
	public static final String TOTAL_HITS_AGGR = "opportunityHitAggr";

	public static final String WORD_CLOUD_OPP_PAIN_POINTS = "wordCloudAggregation";
	public static final String MONTH_WISE_AGGREGATION = "monthAggregation";

	// DrillDownnTypes
	public final static String OVERALL = "overall";
	public final static String MARKETING_CAMPAIGN = "marketing-campaign";
	public final static String SALES_CAMPAIGN = "sales-campaign";
	public final static String MARKETING_INFLUENCED = "marketing-influenced";
	public final static String SALES_GENERATED = "sales-generated";
	public static final String PRIMARY_CAMPAIGN_SOURCE = "primaryCampSource";

	public static final String FISCAL_YEAR_START = "2015-01-01";
	public static final String FISCAL_YEAR_END = "2015-12-31";

	public static final String CREATED_AT = "createdAt";
	public static final String STAGE_AGGREGATION = "stageAggregation";
	public static final String TOP_HITS_AGGREGATION = "topHitsAggregation";
	public static final String OWNER = "owner";
	public static final String CAMPAIGN_DATA = "campaignData";
	public static final String NAME = "name";
	public static final String CAPTURE_DATE = "createdDate";
	public static final String ITEMS = "items";

	// Commons

	public static final String FIRST_QUARTER = "firstQuarter";
	public static final String SECOND_QUARTER = "secondQuarter";
	public static final String THIRD_QUARTER = "thirdQuarter";
	public static final String FOURTH_QUARTER = "fourthQuarter";
	public static final String ONE_YEAR = "oneYear";
	public static final String ONE_PLUS_YEAR = "onePlusYears";
	public static final String LEADS = "Leads";
	public static final String OPPORTUNITIES = "Opportunities";
	public static final String DEALS = "Deals";
	public static final String ACTUAL_COST = "actualCost";
	public static final String TOTAL_COST = "totalCost";

	public static final String OPPORTUNITY_STAGE_WON = "won";
	public static final Object FISCAL_START = "fiscalStart";

	public static final String SUM_AGGREGATION_TYPE = "sum";
	public static final String AVG_AGGREGATION_TYPE = "avg";
	public static final String MIN_AGGREGATION_TYPE = "min";
	public static final String MAX_AGGREGATION_TYPE = "max";
	public static final double EPSILON = .0000001;
	public static final String SUBTITLE = "subTitle";

	public static final Integer NO_OF_ITEMS = 25;
	public static final int BATCH_SIZE_1000 = 1000;
	public static final int BATCH_SIZE_500 = 500;

	public static final Integer TOP_25_ITEMS = 25;
	public static final Integer TOP_100_ITEMS = 100;
	public static final Integer TOP_1000_ITEMS = 1000;
	public static final Integer UNLIMITED_AGGREGATION_ITEMS = 0;

	public static final String OPPORTUNITY_INDUSTRY = "industry";
	public static final String OPPORTUNITY_INDUSTRY_RAW = "industry.raw";
	public final static String OPPORTUNITY_TYPE_RAW = "opportunityType.raw";

	// CRM Opportunities
	public static final String OPPORTUNITY_AMOUNT = "amount";
	public final static String TAGS = " tags";

	// MISG Pipeline
	public final static String MISG_PIPELINE_DATE_AGGEGATION = "MISGPipelineStrategyDate";
	public final static String CREATION_DATE = "createdDate";
	public final static String TOTAL_PIPELINE = "totalPipeline";
	public final static String QUALIFIED_PIPELINE = "qualifiedPipeline";
	public final static String PROPOSE_SOLUTION = "Propose Solution";
	public final static String NEGOTIATE_CLOSE = "Negotiate & Close";
	public final static String OPPORTUNITY_STAGE = "stage";
	public final static String SUM_OPPORTUNITY_AGGREGATION = "opportunitySum";
	public final static String OPPORTUNITY_CLOSED_LOST = "Closed Lost";

	public final static String MISG_TOTAL_PIPELINE = "Total Pipeline";
	public final static String MISG_QUALIFIED_PIPELINE = "Qualified Pipeline";

	public final static String GUAGE_STATUS_COMPLETE = "Complete";
	public final static String GUAGE_STATUS_INCOMPLETE = "InComplete";

	public static final String TOP_ITEMS = "topItems";
	public static final String OTHER_ITEMS = "otherItems";
	public static final String NOT_APPLICABLE = "N/A";

	public final static String MONTHLY_MI_REVENUE_TARGET = "monthlymarketingInfluencedRevenueTarget";
	public final static String MONTHLY_BUSINESS_REVENUE_TARGET = "monthlyBusinessRevenueTarget";
	public final static String LEAD_AGGREGATION = "Lead Aggregation";

	// AccountSetup
	public static final String CURRENCY = "currency";
	public static final String INDUSTRY = "industry";
	public static final String COMPANY_NAME = "companyName";
	public static final String BUSINESS_UNIT = "businessUnit";
	public static final String ADDRESS1 = "address1";
	public static final String ADDRESS2 = "address2";
	public static final String ADDRESS3 = "address3";
	public static final String CITY = "city";
	public static final String STATE = "state";
	public static final String ZIP_CODE = "zipCode";
	public static final String COUNTRY_ID = "countryId";
	public static final String INDUSTRY_ID = "industryId";
	public static final String NO_OF_EMPLOYEES = "numOfEmployee";
	public static final String CURRENCY_ID = "currencyId";
	public static final String ANNUAL_REVENUE = "annualRevenue";
	public static final String WEBSITE = "website";
	public static final String LOGO = "logo";
	public static final String UPDATED_AT = "lastModifiedDate";
	public static final long ACCOUNT_DB_ID = 1;
	public static final String MONTH = "month";
	public static final String VALUE = "value";
	public static final String MANUAL_INSTANCE = "manualInstance";

	public static final String INDUSTRY_AGGREGATION = "industryAggregation";
	public static final String WON_OPPORTUNITIES = "wonOpportunities";
	public static final String LOST_OPPORTUNITIES = "lostOpportunities";

	public final static String CAMPAIGN_COST = "campaignCost";
	public final static String NEW_PARENT_CAMPAIGN_NAME = "newParentCampaignName";
	public final static String PARENT_CAMPAIGN_NAME = "parentCampaignName";
	public static final String AVG_CREATION_DATE = "avgCreationDate";
	public static final String COUNT = "count";
	public static final String MARKETING_INFLUENCED_LABEL = "Marketing Influenced";
	public static final String SALES_GENERATED_LABEL = "Sales Generated";

	public static final String LEADS_TO_OPPORTUNITY = "Leads to Opportunity";
	public static final String AVERAGE_COST = "Average Cost";
	public static final String OVERALL_LABEL = "Overall";
	public static final String ADS = "ads";
	public static final String ASP = "asp";
	public static final String REVENUE_AMOUNT = "revenueAmount";
	public static final String AVERAGE_SELL_PRICE_LABEL = "Average Sell Price";
	public static final String AVERAGE_DEAL_SIZE_LABEL = "Average Deal Size";
	public static final String NO_OF_DEALS_LABEL = "No Of Deals";
	public static final String PRODUCT_AGGREGATION = "productAggregation";
	public static final String VALID_OPPORTUNITIES = "validOpportunities";
	public static final String TOUCH_POINT = "Touch Points";
	public static final String TOUCH_POINT_NAME = "TouchPoint";
	public static final String LEAD_SOURCE = "Lead Source";
	public static final String ASSETS = "Assets";

	public static final String VENDOR_NAME = "vendorName";
	public static final String VENDOR_TYPE = "vendorType";

	public static final boolean MARKETING_INFLUENCED_FLAG = true;
	public static final boolean SALES_GENERATED_FLAG = false;

	// DataSourcesetup
	public final static String DATASOURCE_SETUP = "datasource_strategy";
	public static final String SYSTEM = "system";
	public static final String URL = "url";
	public static final String USERNAME = "username";
	public static final String PASSWORD = "password";
	public static final String CLIENT_ID = "clientId";
	public static final String SECURITY_TOKEN = "securityToken";
	public static final String CLIENT_SECRET = "clientSecret";
	public static final String EMAIL = "email";
	public static final String API_USER_KEY = "user_key";
	public static final String TOP_WON_OPPORTUNITIES_AGGREGATION = "topWonOpporutnitiesAggr";
	public static final String TOP_LOST_OPPORTUNITIES_AGGREGATION = "topLostOpporutnitiesAggr";
	public static final String OPPORTUNITIES_LOST = "Lost";
	public static final String DEALS_WON = "Won";
	public final static String CLOSED_ON = "closedDate";
	
	public static final String CAMPAIGNS = "campaigns";
	public static final String ACCOUNTS = "accounts";
	public static final String TOTALLEADSOURCEREVENUE = "total Lead Source Revenue";
	public static final String TOTALASSETREVENUE = "total asset Revenue";
	public static final String WORD_CLOUD_OPP_NAME = "wordCloudOppName";
	
	
	public static final String TAGS_RAW = "tags.raw";
	public static final String PREVIOUS_YEAR = "previousYear";
	public static final String NBC_REVENUE = "Revenue from New Customers";
	public static final String NBC_COUNT = "Count of New Customers";
	public static final String DATA = "data";
	public static final String DOLLAR_DATA = "dollarData";
	public static final String FIELD_AGGREGATION = "fieldAggregation";
	public static final String X_AXIS_DATA = "xaxis data";
	public static final String PARTNER_ROLE_AGGREGATION = "partnerRoleAggregation";
	
	public final static String PARENT_DATA = "parentData";
	public final static String WON = "Won";
	public final static String LOST = "Lost";
	public static final String PRODUCT_LEVEL_AGGREGATION = "productLevelAggregation";
	public static final String SOLUTION_LEVEL_AGGREGATION = "solutionLevelAggregation";
	public static final String LEVEL_1_AGGREGATION = "levelOneAggregation";
	public static final String LEVEL_2_AGGREGATION = "levelTwoAggregation";
	public static final String LEVEL_3_AGGREGATION = "levelThreeAggregation";
	public static final String EXCEL_COLUMN_HEADER_SEPARATOR = "|";
	
	public static final String PRODUCT_COMBO_SEPARATOR = ",";
	public static final String PRODUCT_CODE_AGGREGATION = "productCodeAggregation";
	public static final String FOOT_NOTE = "footNote";
	public static final String NULL_VALUE = "null";
	public static final String LEAD_SOURCE_REVENUE = "Lead Source - None:  ";
	public static final String ASSET_REVENUE = "Assets - None: ";
	public static final String COUNTRY_CODE_NAME = "name";
	public static final String COUNTRY_CODE = "code";
	public static final String COUNTRY_DOCUMENT_ID = "1";
	public static final String COMMA = ", ";
	

	public static final int  SUB_LEVEL_SIZE = 25;
	
	 public static String EXPIRED_PIPELINE_LITERAL="expired_pipeline";
	 public static String EXPIRED_PIPELINE_DATE_CRITERIA	="date";
	}
