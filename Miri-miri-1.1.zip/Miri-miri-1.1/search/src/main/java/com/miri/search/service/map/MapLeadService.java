package com.miri.search.service.map;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.elasticsearch.action.count.CountRequestBuilder;
import org.elasticsearch.action.count.CountResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.bucket.histogram.InternalHistogram;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.CrmOpportunity;
import com.miri.cis.entity.ESEntity;
import com.miri.cis.entity.MapCampaign;
import com.miri.cis.entity.MapLead;
import com.miri.cis.entity.MapOpportunity;
import com.miri.search.constants.MAPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.esutils.AggregationUtil;
import com.miri.search.esutils.BoolQueryBuilderRequest;
import com.miri.search.esutils.BoolQueryBuilderRequest.BoolType;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.crm.CRMCampaignService;
import com.miri.search.service.crm.CRMOpportunityService;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.TimerUtil;

/**
 * @author Chandra
 *
 */
@Component
public class MapLeadService extends MiriSearchService {

	private static final Logger LOGGER = Logger.getLogger(MapLeadService.class);

	@Autowired
	CRMOpportunityService crmOpportunityService;

	@Autowired
	CRMCampaignService crmCampaignService;

	@Autowired
	ESQueryUtils esQueryUtils;

	@Autowired
	TimerUtil timeUtil;

	/**
	 * 
	 * This method gives the number of leads captured between the provided dates
	 * 
	 * @param startDate
	 *            Date from which we need to get the lead count
	 * @param endDate
	 *            Date till which we need to get the lead count
	 * @return {@link Long} number of leads between the provided dates
	 */
	public Double getLeadCountByDate(String startDate, String endDate) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).from(startDate).to(endDate));
		CountRequestBuilder countRequestBuilder = this.getTransportClient().prepareCount(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));

		return (double) countRequestBuilder.get().getCount();
	}

	/**
	 * This method is used to get the Month wise leads response for a campaign
	 * 
	 * @param camapaignId
	 *            Id of a campaign
	 * @return {@link SearchResponse} Elastic search response
	 */
	public SearchResponse getMonthWiseLeadsForCampaignResponse(String campaignId, String startDate, String endDate) {

		Client client = getTransportClient();
		Map<String, String> subCampaigns = crmCampaignService.getSubCampaigns(campaignId);
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.CAMPAIGN_ID_RAW, subCampaigns.keySet()));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).gt(startDate).lt(endDate));

		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.CAMPAIGN_AGGREGATION).field(SearchConstants.CREATED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0)
				.extendedBounds(startDate, endDate);
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.addAggregation(dateAggregation).setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		return response;
	}

	/**
	 * Get Month wise leads information with in date range. if no dates are
	 * passed dates are ignored.
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<Integer, List<MapLead>> getMonthWiseLeadsWithInDateRange(final String startDate, final String endDate) {
		Client client = getTransportClient();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).gt(startDate).lt(endDate));
		}

		AbstractAggregationBuilder dateAggregation = AggregationBuilders.dateHistogram(SearchConstants.DATE_HISTOGRAM)
				.field(SearchConstants.CREATED_DATE).interval(DateHistogram.Interval.MONTH)
				.format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate);
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.addAggregation(dateAggregation).setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.QUERY_AND_FETCH);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		// LOGGER.info("SearchRequestBuilder :" + searchRequestBuilder);

		InternalHistogram dateHistogram = searchResponse.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
		Collection<InternalHistogram.Bucket> termsBuckets = dateHistogram.getBuckets();
		Calendar monthStart = Calendar.getInstance();
		Calendar monthEnd = Calendar.getInstance();
		Map<Integer, List<MapLead>> mapLeadsByMonth = new LinkedHashMap<>();
		String monthStartStr;
		String monthEndStr;
		for (InternalHistogram.Bucket dateBucket : termsBuckets) {
			monthStart.setTime(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					dateBucket.getKeyAsText().toString()));
			int month = monthStart.get(Calendar.MONTH);
			monthEnd.setTime(monthStart.getTime());
			monthEnd.set(Calendar.DAY_OF_MONTH, monthStart.getActualMaximum(Calendar.DAY_OF_MONTH));
			monthStartStr = MiriDateUtils.parseDateToString(monthStart, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			monthEndStr = MiriDateUtils.parseDateToString(monthEnd, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			// LOGGER.info("month Start Date :" + monthStartStr);
			// LOGGER.info("month End Date :" + monthEndStr);
			boolFilterBuilder = FilterBuilders.boolFilter();

			searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
					.setQuery(QueryBuilders.rangeQuery(MAPConstants.LEAD_CREATED_DATE).gte(monthStartStr)
							.lte(monthEndStr))
					.setSize(500).setScroll(new TimeValue(6000)).setSearchType(SearchType.SCAN);
			searchResponse = esQueryUtils.execute(searchRequestBuilder);
			List<MapLead> mapLeads = new ArrayList<>();
			while (true) {
				for (SearchHit hit : searchResponse.getHits().getHits()) {
					mapLeads.add((MapLead) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
				}
				SearchScrollRequestBuilder searchScrollRequestBuilder = client
						.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
				searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
				if (searchResponse.getHits().getHits().length == 0) {
					break;
				}
			}
			mapLeadsByMonth.put(month, mapLeads);
		}
		return mapLeadsByMonth;
	}

	/**
	 * Utility method to interact with the Elastic search
	 * 
	 * @param queryBuilder
	 * @param index
	 * @param type
	 * @param fields
	 * @return
	 */
	public CountResponse getResponse(QueryBuilder queryBuilder, String index, String type, String[] fields) {
		Client client = getTransportClient();
		return client.prepareCount().setIndices(index).setTypes(type).setQuery(queryBuilder).execute().actionGet();
	}

	/**
	 * Returns list of Map Leads for the given campaign Id.
	 * 
	 * @param campaignId
	 * @return
	 */
	public List<MapLead> getAllLeadsByCampaignId(final String campaignId) {
		return getAllLeadsByCampaignIdAndOptionalAttributes(campaignId, null);
	}

	/**
	 * Returns list of Map Leads for the given campaign Id.
	 * 
	 * @param campaignId
	 * @return
	 */
	public List<MapLead> getAllLeadsByLeadOwnerId(final String campaignId) {

		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery()
				.must(QueryBuilders.termQuery("leadOwner.raw", campaignId));

		SearchResponse response = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(boolQueryBuilder).execute().actionGet();
		SearchHits searchHits = response.getHits();

		List<MapLead> mapLeads = new ArrayList<>();
		MapLead mapLead = null;
		for (SearchHit searchHit : searchHits) {
			mapLead = (MapLead) ESObjectMapper.getObject(searchHit.getSource(), getDocumentType(), getIndex());
			if (null != mapLead) {
				mapLeads.add(mapLead);
			}
		}
		LOGGER.info("Number of Leads matched for the given Lead Owner id: " + mapLeads.size());
		return mapLeads;

	}

	/**
	 * Gets all campaigns from Lead Document by given campaignId and optional
	 * attributes.
	 * 
	 * @param campaignId
	 * @param optionalParams
	 * @return
	 */
	public List<MapLead> getAllLeadsByCampaignIdAndOptionalAttributes(final String campaignId,
			Map<String, Object> optionalParams) {

		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery()
				.must(QueryBuilders.termQuery("campaignId.raw", campaignId));
		if (!MapUtils.isEmpty(optionalParams)) {
			for (String param : optionalParams.keySet()) {
				boolQueryBuilder.should(QueryBuilders.termQuery(param, optionalParams.get(param)));
			}
		}

		SearchRequestBuilder srb = getTransportClient().prepareSearch(getIndex());
		SearchResponse response = srb.setTypes(getDocumentType()).setQuery(boolQueryBuilder).execute().actionGet();
		SearchHits searchHits = response.getHits();

		List<MapLead> mapLeads = new ArrayList<>();
		MapLead mapLead = null;
		for (SearchHit searchHit : searchHits) {
			Map<String, Object> map = searchHit.getSource();
			mapLead = (MapLead) ESObjectMapper.getObject(map, getDocumentType(), getIndex());
			if (null != mapLead) {
				mapLeads.add(mapLead);
			}
		}
		LOGGER.info("Number of campaigns matched for the given campaign id: " + mapLeads.size());
		return mapLeads;
	}

	/**
	 * Gets all campaigns from Lead Document by given campaignId and optional
	 * attributes.
	 * 
	 * @param campaignIds
	 * @param optionalParams
	 * @return
	 */
	public List<String> getAllLeadIdsByCampaignIds(final List<String> campaignIds) {

		BoolQueryBuilderRequest queryBuilderRequest = new BoolQueryBuilderRequest()
				.fieldName(MAPConstants.CAMPAIGNID_RAW).fieldValues(campaignIds).type(BoolType.MUST);
		BoolQueryBuilder boolQueryBuilder = MiriSearchUtils.createBoolQueryBuilder(queryBuilderRequest);

		SearchRequestBuilder srb = getTransportClient().prepareSearch(getIndex());
		SearchResponse response = srb.setTypes(getDocumentType()).setQuery(boolQueryBuilder)
				.setSearchType(SearchType.SCAN).setScroll(new TimeValue(6000)).addField(MAPConstants.LEAD_ID_RAW)
				.execute().actionGet();

		List<String> leadIds = new ArrayList<>();
		while (true) {
			SearchHits searchHits = response.getHits();
			for (SearchHit searchHit : searchHits.getHits()) {
				if (StringUtils.isNotBlank((String) searchHit.field(MAPConstants.LEAD_ID_RAW).getValue())) {
					leadIds.add((String) searchHit.field(MAPConstants.LEAD_ID_RAW).getValue());
				}
			}
			response = getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000))
					.get();
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}
		return leadIds;
	}

	@Override
	public String getIndex() {
		return ElasticSearchEnums.MAP.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.MAP_LEAD.getText();
	}

	/**
	 * Get Leads by Opportunity information
	 * 
	 * @param crmOpportunities
	 * @return
	 */
	public List<MapLead> getLeadsByOpportunities(List<CrmOpportunity> crmOpportunities) {
		if (!CollectionUtils.isEmpty(crmOpportunities)) {
			Set<String> campaignIds = new HashSet<>();
			Set<String> accountNames = new HashSet<>();
			Set<String> owners = new HashSet<>();
			Set<String> leadSources = new HashSet<>();
			for (CrmOpportunity crmOpportunity : crmOpportunities) {
				campaignIds.add(crmOpportunity.getPrimaryCampSource());
				accountNames.add(crmOpportunity.getCompanyName());
				owners.add(crmOpportunity.getOwner());
				leadSources.add(crmOpportunity.getLeadSource());
			}
			return this.getAllLeadsByCampaignAccountNameAndOwner(campaignIds, accountNames, owners, leadSources);
		} else {
			return Arrays.asList();
		}
	}

	/**
	 * Get all the leads of a campaign (Using Scroll API for getting the results
	 * 
	 * @param parentCampaignId
	 * @return
	 */
	public List<MapLead> getLeadsByCampaignId(String parentCampaignId) {
		// if the passed camp_aign Id is parent campaign then get all the sub
		// campaigns of that campaign and
		// get the opportunities of that campaign
		Map<String, String> subCampaigns = this.crmCampaignService.getSubCampaigns(parentCampaignId);
		List<String> campaignIds = new ArrayList<>(subCampaigns.keySet());
		campaignIds.add(parentCampaignId);

		Client client = this.getTransportClient();
		SearchResponse scrollResponse = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN).setScroll(new TimeValue(60000)).setSize(500)
				.setQuery(QueryBuilders.termsQuery(SearchConstants.CAMPAIGN_ID_RAW, campaignIds)).get();
		// Scroll until no hits are returned
		List<MapLead> mapLeadList = new ArrayList<>();
		while (true) {
			for (SearchHit hit : scrollResponse.getHits().getHits()) {
				mapLeadList.add((MapLead) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
			}
			scrollResponse = client.prepareSearchScroll(scrollResponse.getScrollId()).setScroll(new TimeValue(60000))
					.execute().actionGet();
			// Break condition: No hits are returned
			if (scrollResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return mapLeadList;
	}

	/**
	 * Get All the leads for the campaignIds, accountName and
	 * 
	 * @param campaignIds
	 * @param accountNames
	 * @param owner
	 * @return
	 */
	public List<MapLead> getAllLeadsByCampaignAccountNameAndOwner(Set<String> campaignIds, Set<String> accountNames,
			Set<String> owner, Set<String> leadSources) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.CAMPAIGN_ID_RAW, campaignIds));
		boolFilterBuilder.must(FilterBuilders.termsFilter(MAPConstants.LEAD_COMPANY_NAME_RAW, accountNames));
		boolFilterBuilder.should(FilterBuilders.termsFilter(MAPConstants.LEAD_SOURCE_RAW, campaignIds));
		boolFilterBuilder.should(FilterBuilders.termsFilter(MAPConstants.LEAD_OWNER_RAW, owner));
		Client client = this.getTransportClient();
		SearchResponse scrollResponse = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN).setScroll(new TimeValue(60000)).setSize(500).get();
		List<MapLead> mapLeadObjects = new ArrayList<>();
		if (scrollResponse != null) {
			while (true) {
				for (SearchHit hit : scrollResponse.getHits().getHits()) {
					mapLeadObjects
							.add((MapLead) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
				}
				scrollResponse = client.prepareSearchScroll(scrollResponse.getScrollId())
						.setScroll(new TimeValue(60000)).execute().actionGet();
				if (scrollResponse.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		return mapLeadObjects;
	}

	/**
	 * Get all the leads by sales person with in the time frame
	 * 
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<MapLead> getLeadsBySalesPerson(String salesPersonName, String startDate, String endDate) {

		// if the passed campaign Id is parent campaign then get all the sub
		// campaigns of that campaign and
		// get the opportunities of that campaign

		Client client = this.getTransportClient();
		SearchResponse scrollResponse = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN).setScroll(new TimeValue(60000)).setSize(500)
				.setQuery(QueryBuilders.termQuery(MAPConstants.LEAD_OWNER_RAW, salesPersonName))
				.setPostFilter(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).gte(startDate).lte(endDate))
				.get();
		// Scroll until no hits are returned
		List<MapLead> mapLeadList = new ArrayList<>();
		while (true) {
			for (SearchHit hit : scrollResponse.getHits().getHits()) {
				mapLeadList.add((MapLead) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
			}
			scrollResponse = client.prepareSearchScroll(scrollResponse.getScrollId()).setScroll(new TimeValue(60000))
					.execute().actionGet();
			// Break condition: No hits are returned
			if (scrollResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return mapLeadList;
	}

	/**
	 * Average Lead Creation Date for Map Leads
	 * 
	 * @param mapLeads
	 * @return
	 */
	public double getAvgLeadCreationDate(List<MapLead> mapLeads) {
		if (!CollectionUtils.isEmpty(mapLeads)) {
			List<String> leadIds = new ArrayList<>();
			for (MapLead mapLead : mapLeads) {
				leadIds.add(mapLead.getLeadId());
			}
			return getAvgLeadCreationTime(leadIds);
		} else {
			return 0;
		}
	}

	/**
	 * Get Average Lead Creation Time
	 * 
	 * @param leadIds
	 * @return
	 */
	public double getAvgLeadCreationTime(List<String> leadIds) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(MAPConstants.LEAD_ID_RAW, leadIds));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(
						AggregationBuilders.avg(SearchConstants.AVG_AGGREGATION).field(MAPConstants.LEAD_CREATED_DATE));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		return AggregationUtil.getAggregationValue(searchResponse, SearchConstants.AVG_AGGREGATION,
				SearchConstants.AVG_AGGREGATION_TYPE);
	}

	/**
	 * Returns List of Map Leads associated with the given account id.
	 * 
	 * @param accountId
	 */
	public List<ESEntity> getLeadsByAccountId(String accountId) {
		return esQueryUtils.getMultipleDocsByFKId(getDocumentType(), getIndex(), "accountId.raw", accountId);

	}

	/**
	 * Returns List of Map Leads associated with the given opportunity and
	 * campaign.
	 * 
	 * @param accountId
	 */
	public List<MapLead> getLeadsByCampaignAndOpporunityDetails(final MapCampaign mapCampaign,
			final MapOpportunity mapOpportunity) {

		List<MapLead> mapLeads = new ArrayList<>();

		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery()
				.must(QueryBuilders.termQuery("campaignId.raw", mapCampaign.getCampaignId()));

		if (null != mapOpportunity) {
			boolQueryBuilder.must(QueryBuilders.termQuery("campaignId.raw", mapOpportunity.getCampaignId()))
					.must(QueryBuilders.termQuery("leadSource.raw", mapOpportunity.getLeadSource()))
					.must(QueryBuilders.termQuery("leadOwner.raw", mapOpportunity.getOpportunityOwner()))
					.must(QueryBuilders.termQuery("companyId.raw", mapOpportunity.getAccountId()));

			boolQueryBuilder.must(
					QueryBuilders.rangeQuery(MAPConstants.LEAD_CREATED_DATE).lte(mapOpportunity.getCreatedDate()));
			boolQueryBuilder
					.must(QueryBuilders.rangeQuery(MAPConstants.LEAD_CREATED_DATE).gte(mapCampaign.getCreatedDate()));
		}

		SearchResponse opportunityRespose = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(boolQueryBuilder).execute().actionGet();

		SearchHits oppSearchHits = opportunityRespose.getHits();
		
		if(oppSearchHits == null || oppSearchHits.getTotalHits() == 0) {
			boolQueryBuilder = QueryBuilders.boolQuery()
					.must(QueryBuilders.termQuery("campaignId.raw", mapCampaign.getCampaignId()));

			if (null != mapOpportunity) {
				boolQueryBuilder.must(QueryBuilders.termQuery("campaignId.raw", mapOpportunity.getCampaignId()))
						.should(QueryBuilders.termQuery("leadSource.raw", mapOpportunity.getLeadSource()))
						.should(QueryBuilders.termQuery("leadOwner.raw", mapOpportunity.getOpportunityOwner()))
						.must(QueryBuilders.termQuery("companyId.raw", mapOpportunity.getAccountId()));

				boolQueryBuilder.must(
						QueryBuilders.rangeQuery(MAPConstants.LEAD_CREATED_DATE).lte(mapOpportunity.getCreatedDate()));
				boolQueryBuilder
						.must(QueryBuilders.rangeQuery(MAPConstants.LEAD_CREATED_DATE).gte(mapCampaign.getCreatedDate()));
			}

			opportunityRespose = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
					.setQuery(boolQueryBuilder).execute().actionGet();
		}
		for (SearchHit hit : oppSearchHits) {
			mapLeads.add((MapLead) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
		}
		return mapLeads;

	}

	/**
	 * Returns list of Map Leads for the given campaign Id.
	 * 
	 * @param campaignId
	 * @return
	 */
	public MapLead getLeadByLeadId(final String leadId) {
		return (MapLead) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), "leadId.raw", leadId);
	}

	/**
	 * Get Month wise leads for campaigns with in date range
	 * 
	 * @param campaignIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, List<MapLead>> getMonthWiseLeadForCampaignsWithInDateRange(List<String> campaignIds,
			String startDate, String endDate) {
		Client client = this.getTransportClient();
		timeUtil.start();
		AbstractAggregationBuilder aggregation = AggregationBuilders.dateHistogram(SearchConstants.LEAD_AGGREGATION)
				.field(MAPConstants.LEAD_CREATED_DATE).extendedBounds(startDate, endDate).minDocCount(0)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).subAggregation(
						AggregationBuilders.avg(SearchConstants.AVG_AGGREGATION).field(MAPConstants.LEAD_CREATED_DATE));
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();

		if (CollectionUtils.isNotEmpty(campaignIds)) {
			boolFilter.must(FilterBuilders.termsFilter(MAPConstants.CAMPAIGNID_RAW, campaignIds));
		}

		boolFilter.must(FilterBuilders.rangeFilter(MAPConstants.OPPORTUNITY_CREATED_DATE).gt(startDate).lt(endDate));

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(aggregation).setSize(0);
		// LOGGER.info("SearchRequest Builder :" + searchRequestBuilder);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.LEAD_AGGREGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();

		Calendar monthStart = Calendar.getInstance();
		Calendar monthEnd = Calendar.getInstance();
		Map<Integer, List<MapLead>> mapLeadsForCampaignsByMonth = new LinkedHashMap<>();
		String monthStartStr;
		String monthEndStr;
		for (InternalHistogram.Bucket bucket : buckets) {
			monthStart.setTime(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					bucket.getKeyAsText().toString()));
			int month = monthStart.get(Calendar.MONTH);
			monthEnd.setTime(monthStart.getTime());
			monthEnd.set(Calendar.DAY_OF_MONTH, monthStart.getActualMaximum(Calendar.DAY_OF_MONTH));
			boolFilter = FilterBuilders.boolFilter();

			if (CollectionUtils.isNotEmpty(campaignIds)) {
				boolFilter.must(FilterBuilders.termsFilter(MAPConstants.CAMPAIGNID_RAW, campaignIds));
			}
			monthStartStr = MiriDateUtils.parseDateToString(monthStart, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			monthEndStr = MiriDateUtils.parseDateToString(monthEnd, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			// LOGGER.info("month Start Date :" + monthStartStr);
			// LOGGER.info("month End Date :" + monthEndStr);

			boolFilter.must(
					FilterBuilders.rangeFilter(MAPConstants.LEAD_CREATED_DATE).gte(monthStartStr).lte(monthEndStr));

			searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter)).setSize(500)
					.setScroll(new TimeValue(6000)).setSearchType(SearchType.SCAN);
			// LOGGER.info("SearchRequestBuilderMOnth:" + searchRequestBuilder);
			searchResponse = esQueryUtils.execute(searchRequestBuilder);
			List<MapLead> mapLeads = new ArrayList<>();
			while (true) {
				for (SearchHit hit : searchResponse.getHits().getHits()) {
					mapLeads.add((MapLead) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
				}
				SearchScrollRequestBuilder searchScrollRequestBuilder = client
						.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
				searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
				if (searchResponse.getHits().getHits().length == 0) {
					break;
				}
			}
			mapLeadsForCampaignsByMonth.put(month, mapLeads);
		}
		timeUtil.end();
		LOGGER.debug("ES time getMonthWiseLeadForCampaignsWithInDateRange : " + timeUtil.timeTakenInMillis());
		return mapLeadsForCampaignsByMonth;
	}
	
	/**
	 * Checks for existing unique combination 
	 * @param mapOfTouchpointAndUniqueCombination
	 * @param uniqueCombination
	 * @return
	 */
	public Date checkForExistingTouchPointCombination(Map<Date, Set<String>> mapOfTouchpointAndUniqueCombination, String uniqueCombination){
		for(Map.Entry<Date, Set<String>> map : mapOfTouchpointAndUniqueCombination.entrySet()){
			TreeSet<String> combinations = (TreeSet<String>) map.getValue();
			if(combinations.contains(uniqueCombination)){
				return map.getKey();
			}
		}
		return null;
		
	}
    	
    
    /**
     * get Leads between dates for sub-campaigns
     * @param date TODO
     * @param leadIds 
     * @param gte
     * @param lt
     * @param subCampaigns
     * @return
     */
    public List<MapLead> getLeadsFromMapLeadBetweenDates(Date from, Date to, String subCampaign, Map<Date, Set<String>> mapOfCombinations, 
    		Date date, List<String> leadIds){
    	BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		
		if(StringUtils.isNotBlank(subCampaign)) {
			boolFilter.must(FilterBuilders.termFilter(MAPConstants.CAMPAIGNID_RAW, subCampaign));
		}
		
		boolFilter.must(FilterBuilders.rangeFilter(MAPConstants.MAP_LEAD_CREATED_DATE).from(from).to(to));
		boolFilter.must(FilterBuilders.termsFilter(MAPConstants.LEAD_ID_RAW, leadIds));
    	
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000));
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		List<MapLead> mapleads =  new ArrayList<>();
		String uniqueCombination = null;
		Date touchPointDate = null;
		while(true){
			for (SearchHit hit : response.getHits()) {
				MapLead mapLeadObject = (MapLead) ESObjectMapper.getObject(hit.getSource(),
		                getDocumentType(), getIndex());
				uniqueCombination = mapLeadObject.getIdentifier();
				touchPointDate = checkForExistingTouchPointCombination(mapOfCombinations, uniqueCombination);
				if(touchPointDate == null){
					if(mapOfCombinations.get(date) == null){
						mapOfCombinations.put(date, new TreeSet<>(Arrays.asList(uniqueCombination)));
					}else{
						mapOfCombinations.get(date).add(uniqueCombination);
					}
				}
				else{
					mapOfCombinations.get(touchPointDate).add(uniqueCombination);
				}
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
 			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if(response.getHits().getHits().length == 0) {
				break;
			}
		}
		return mapleads;
		
	}
    
    /**
     * Get leads by the Less than the given Date
     * @param leadIds 
     * @param lt
     * @param camapaignId
     * @return
     */
    public List<MapLead> getLeadsFromMapLeadLessThanDate(Date to, String subCampaign, Map<Date, Set<String>> mapOfCombinations, 
    		Date date, List<String> leadIds){
    	
    	BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		
		if(StringUtils.isNotBlank(subCampaign)) {
			boolFilter.must(FilterBuilders.termFilter(MAPConstants.CAMPAIGNID_RAW, subCampaign));
		}
		
		boolFilter.must(FilterBuilders.rangeFilter(MAPConstants.MAP_LEAD_CREATED_DATE).to(to));
		boolFilter.must(FilterBuilders.termsFilter(MAPConstants.LEAD_ID_RAW, leadIds));
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000));
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		List<MapLead> mapleads =  new ArrayList<>();
		String uniqueCombination = null;
		Date touchPointDate = null;
		while(true){
			for (SearchHit hit : response.getHits()) {
				MapLead mapLeadObject = (MapLead) ESObjectMapper.getObject(hit.getSource(),
		                getDocumentType(), getIndex());
				uniqueCombination = mapLeadObject.getIdentifier();
				touchPointDate = checkForExistingTouchPointCombination(mapOfCombinations, uniqueCombination);
				if(touchPointDate == null){
					if(mapOfCombinations.get(date) == null){
						mapOfCombinations.put(date, new TreeSet<>(Arrays.asList(uniqueCombination)));
					}else{
						mapOfCombinations.get(date).add(uniqueCombination);
					}
				}
				else{
					mapOfCombinations.get(touchPointDate).add(uniqueCombination);
				}
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
 			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if(response.getHits().getHits().length == 0) {
				break;
			}
		}
		return mapleads;
	}
    
    /**
     * Get leads by the from the given Date
     * @param leadIds 
     * @param lt
     * @param camapaignId
     * @return
     */
    public List<MapLead> getLeadsFromMapLeadGreaterhanDate(Date from, String subCampaign, Map<Date, Set<String>> mapOfCombinations, 
    		Date date, List<String> leadIds){
    	
    	BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		
		if(StringUtils.isNotBlank(subCampaign)) {
			boolFilter.must(FilterBuilders.termFilter(MAPConstants.CAMPAIGNID_RAW, subCampaign));
		}
		
		boolFilter.must(FilterBuilders.rangeFilter(MAPConstants.MAP_LEAD_CREATED_DATE).from(from));
		boolFilter.must(FilterBuilders.termsFilter(MAPConstants.LEAD_ID_RAW, leadIds));
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000));
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
    			List<MapLead> mapleads =  new ArrayList<>();
    			String uniqueCombination = null;
    			Date touchPointDate = null;
    	while(true){
				for (SearchHit hit : response.getHits()) {
					MapLead mapLeadObject = (MapLead) ESObjectMapper.getObject(hit.getSource(),
			                getDocumentType(), getIndex());
					uniqueCombination = mapLeadObject.getIdentifier();
					touchPointDate = checkForExistingTouchPointCombination(mapOfCombinations, uniqueCombination);
					if(touchPointDate == null){
						if(mapOfCombinations.get(date) == null){
							mapOfCombinations.put(date, new TreeSet<>(Arrays.asList(uniqueCombination)));
						}else{
							mapOfCombinations.get(date).add(uniqueCombination);
						}
					}
					else{
						mapOfCombinations.get(touchPointDate).add(uniqueCombination);
					}
				}
				SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
	 			response = esQueryUtils.execute(searchScrollRequestBuilder);
				if(response.getHits().getHits().length == 0) {
					break;
				}
    	}
    			return mapleads;
    }
   
    /**
     * Calculates the Maximum Deviation for a campaign
     * @param campignId
     * @param startDate
     * @param endDate
     * @return
     */
    @SuppressWarnings("rawtypes")
	public double getMaxDevForCampaign(String campignId, String startDate, String endDate){
    	Date startDateCal = MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD, startDate);
    	Date endDateCal = MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD, endDate);
    	int diffInDays = (int)( (endDateCal.getTime() - startDateCal.getTime()) 
                / (1000 * 60 * 60 * 24) );
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termFilter(MAPConstants.CAMPAIGNID_RAW, campignId));
		boolFilter.must(FilterBuilders.rangeFilter(MAPConstants.MAP_LEAD_CREATED_DATE).from(startDate).to(endDate));
		AbstractAggregationBuilder aggregation = AggregationBuilders
				.dateHistogram(SearchConstants.LEAD_AGGREGATION).field(MAPConstants.MAP_LEAD_CREATED_DATE)
				.extendedBounds(startDate, endDate)
				.minDocCount(0)
				.interval(DateHistogram.Interval.DAY).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		
		SearchRequestBuilder searchRequestBulder =  getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
    			.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
    			.addAggregation(aggregation)
    			.setSearchType(SearchType.DEFAULT);
    			
		
		SearchResponse searchResponse = searchRequestBulder.get();
    	InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.LEAD_AGGREGATION);
		@SuppressWarnings("unchecked")
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		List<Long> arrayValues = new ArrayList<>();
		Long leadCount = 0l;
		for (InternalHistogram.Bucket bucket : buckets) {
			arrayValues.add(bucket.getDocCount());
			leadCount += bucket.getDocCount();
		}
		
		double mean = leadCount/diffInDays;
		double variance = this.getVariance(arrayValues, mean, diffInDays);
		double deviation=Math.sqrt(variance);  
	
		return mean + deviation;
    }
    
    /**
     * Calculates the Variance from values and mean
     * @param values
     * @param mean
     * @param size
     * @return
     */
    public double getVariance(List<Long> values, double mean, int size){
    	double temp = 0;
    	for(long a :values)
            temp += Math.pow((a-mean),2);  
        return temp/size;
    	
    }
    
    /**
     * Gets the TouchPoint Dates using Maximum deviation of a campaign
     * @param campaignId
     * @param maximumStandardDeviation
     * @param startDate
     * @param endDate
     * @return
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public List<Date> getTouchPointDatesFromMaximumDeviation(String campaignId, long maximumStandardDeviation, String startDate, String endDate){
    	List<Date> touchPointDates = new ArrayList<>();
    	BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termFilter(MAPConstants.CAMPAIGNID_RAW, campaignId));
		boolFilter.must(FilterBuilders.rangeFilter(MAPConstants.MAP_LEAD_CREATED_DATE).from(startDate).to(endDate));
		AbstractAggregationBuilder aggregation = AggregationBuilders
				.dateHistogram(SearchConstants.LEAD_AGGREGATION).field(MAPConstants.MAP_LEAD_CREATED_DATE)
				.extendedBounds(startDate, endDate)
				.minDocCount(maximumStandardDeviation)
				.interval(DateHistogram.Interval.DAY).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		SearchRequestBuilder searchRequestBulder =  getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
    			.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
    			.addAggregation(aggregation)
    			.setSearchType(SearchType.DEFAULT);
		SearchResponse searchResponse = searchRequestBulder.get();
    	InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.LEAD_AGGREGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		for (InternalHistogram.Bucket bucket : buckets) {
			touchPointDates.add(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD, bucket.getKey()));
		}
		Collections.sort(touchPointDates);
		return touchPointDates;
    }
    
	/**
	 * Get Leads with in date range
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getLeadsWithInDateRange(String startDate, String endDate) {
		Client client = this.getTransportClient();
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN).setSize(0).setScroll(new TimeValue(6000))
				.setFetchSource(MAPConstants.LEAD_ID, null)
				.setPostFilter(FilterBuilders.rangeFilter(MAPConstants.LEAD_CREATED_DATE).gte(startDate).lte(endDate));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> leadIds = new ArrayList<>();
		do {
			for (SearchHit hit : searchResponse.getHits()) {
				leadIds.add(hit.getSource().get(MAPConstants.LEAD_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = client
					.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
		} while (searchResponse.getHits().getHits().length != 0);
		return leadIds;
	}

	/**
	 * Gets the Campaigns and By month leads
	 * 
	 * @param campaignId
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public SearchResponse getCamapignsAndLeadsByMonth(String campaignId, String startDate, String endDate) {
		Map<String, String> subCampaigns = crmCampaignService.getSubCampaigns(campaignId);
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.CAMPAIGN_ID_RAW, subCampaigns.keySet()));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).from(startDate).to(endDate));

		AbstractAggregationBuilder subaggregation = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(SearchConstants.CAMPAIGN_ID_RAW);

		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.CAMPAIGN_AGGREGATION).field(SearchConstants.CREATED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0)
				.extendedBounds(startDate, endDate).subAggregation(subaggregation);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).addAggregation(dateAggregation).setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		return searchResponse;

	}
	
	/**
	 * Get Leads with in date range
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getLeadsWithInDateRangeFromOppDetails(String startDate, String endDate, String campaignId, 
					String industry, String leadSource, String companyId, String salesPerson) {
		Client client = this.getTransportClient();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termFilter(SearchConstants.CAMPAIGN_ID_RAW, campaignId));
		boolFilterBuilder.must(FilterBuilders.termFilter(MAPConstants.LEAD_COMPANY_ID_RAW, companyId));
		boolFilterBuilder.must(FilterBuilders.termFilter(MAPConstants.LEAD_INDUSTRY_RAW, industry));
		boolFilterBuilder.must(FilterBuilders.termFilter(MAPConstants.LEAD_SOURCE_RAW, leadSource));
		boolFilterBuilder.must(FilterBuilders.termFilter(MAPConstants.LEAD_OWNER_RAW, salesPerson));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(MAPConstants.LEAD_CREATED_DATE).from(startDate).to(endDate));
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> leadIds = new ArrayList<>();
		do {
			for(SearchHit hit: searchResponse.getHits()) {
				leadIds.add((String) hit.getSource().get(MAPConstants.LEAD_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
		} while(searchResponse.getHits().getHits().length != 0);
		return leadIds;
	}

	
	
	/**
	 * Gets the OverAll Assets
	 * @return 
	 */
	public Map<String, List<MapLead>> getAssetsAndLeads(){

		Map<String, List<MapLead>> assetAndLeads = new HashMap<>();
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setSearchType(SearchType.SCAN).setScroll(new TimeValue(6000));
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		String uniqueCombination = null;
		while (true) {
			for (SearchHit hit : response.getHits()) {
				MapLead mapLeadObject = (MapLead) ESObjectMapper.getObject(hit.getSource(), getDocumentType(),
						getIndex());
				uniqueCombination = mapLeadObject.getMapAssets();
				if (assetAndLeads.containsKey(uniqueCombination)) {
					assetAndLeads.get(uniqueCombination).add(mapLeadObject);
				} else {
					assetAndLeads.put(uniqueCombination, new ArrayList<MapLead>(Arrays.asList(mapLeadObject)));
				}
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient()
					.prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}
		return assetAndLeads;
	}
	/**
	 * Gets the OverAll Leadsource
	 * @return 
	 */
	public Map<String, List<MapLead>> getLeadSourceAndLeads(){
		
		Map<String, List<MapLead>> leadSourceAndLeads = new HashMap<>();
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setSearchType(SearchType.SCAN).setScroll(new TimeValue(6000));
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		
		String leadSource = null;
		while (true) {
			for (SearchHit hit : response.getHits()) {
				MapLead mapLeadObject = (MapLead) ESObjectMapper.getObject(hit.getSource(), getDocumentType(),
						getIndex());
				leadSource = mapLeadObject.getLeadSource();
				if (leadSourceAndLeads.containsKey(leadSource)) {
					leadSourceAndLeads.get(leadSource).add(mapLeadObject);
				} else {
					leadSourceAndLeads.put(leadSource, new ArrayList<MapLead>(Arrays.asList(mapLeadObject)));
				}
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient()
					.prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}
		return leadSourceAndLeads;
	}
}
