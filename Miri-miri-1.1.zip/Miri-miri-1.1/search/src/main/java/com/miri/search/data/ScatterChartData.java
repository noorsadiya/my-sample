package com.miri.search.data;

import java.io.Serializable;

public class ScatterChartData implements Serializable{

	private String hoverName;

	private String xAxisPointer;

	private Double hoverAmount;
	
	private String drillDownXaxisPointer;

	public String getHoverName() {
		return hoverName;
	}

	public void setHoverName(String hoverName) {
		this.hoverName = hoverName;
	}

	public String getxAxisPointer() {
		return xAxisPointer;
	}

	public void setxAxisPointer(String xAxisPointer) {
		this.xAxisPointer = xAxisPointer;
	}
	
	public String getDrillDownXaxisPointer() {
		return drillDownXaxisPointer;
	}

	public void setDrillDownXaxisPointer(String drillDownXaxisPointer) {
		this.drillDownXaxisPointer = drillDownXaxisPointer;
	}
	
	public Double getHoverAmount() {
		return hoverAmount;
	}
	
	public void setHoverAmount(Double hoverAmount) {
		this.hoverAmount = hoverAmount;
	}
	
}
