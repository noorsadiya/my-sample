package com.miri.search.esutils;

import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;

public interface IESQueryUtils {
	  public SearchResponse execute(final SearchRequestBuilder searchRequestBuilder);
}
