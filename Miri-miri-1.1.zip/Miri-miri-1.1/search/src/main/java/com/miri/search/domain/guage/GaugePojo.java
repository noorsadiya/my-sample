package com.miri.search.domain.guage;

import java.io.Serializable;
import java.util.List;

public class GaugePojo implements Serializable{
	
	private double guagePercentage;
	private List<GaugeRow> guageRowList;
	private String[] gaugeHeaders;
	
	private boolean showGaugeTable;
	
	public double getGuagePercentage() {
		return guagePercentage;
	}
	public void setGuagePercentage(double guagePercentage) {
		this.guagePercentage = guagePercentage;
	}
	public List<GaugeRow> getGuageRow() {
		return guageRowList;
	}
	public void setGuageRow(List<GaugeRow> guageRow) {
		this.guageRowList = guageRow;
	}
	
	public String[] getGaugeHeaders() {
		return gaugeHeaders;
	}
	
	public void setGaugeHeaders(String[] gaugeHeaders) {
		this.gaugeHeaders = gaugeHeaders;
	}
	public List<GaugeRow> getGuageRowList() {
		return guageRowList;
	}
	public void setGuageRowList(List<GaugeRow> guageRowList) {
		this.guageRowList = guageRowList;
	}
	
	public boolean isShowGaugeTable() {
		return showGaugeTable;
	}
	public void setShowGaugeTable(boolean showGaugeTable) {
		this.showGaugeTable = showGaugeTable;
	}
	
}
