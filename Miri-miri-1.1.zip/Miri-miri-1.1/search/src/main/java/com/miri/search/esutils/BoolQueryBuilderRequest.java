/**
 * 
 */
package com.miri.search.esutils;

import java.util.List;

/**
 * Holds request data for creating bool query.
 * 
 * @author Chandra
 *
 */
public class BoolQueryBuilderRequest {

	public enum BoolType {MUST, SHOULD, MUST_NOT}

	private static final int DEFAULT_BATCH_SIZE = 1000;

	private String fieldName;

	private List<String> fieldValues;
	
	private int batchSize;

	private BoolType type;

	public BoolQueryBuilderRequest() {
		
	}

	public BoolQueryBuilderRequest(String fieldName, List<String> fieldValues, int batchSize, BoolType boolType) {
		this.fieldName = fieldName;
		this.fieldValues = fieldValues;
		this.batchSize = batchSize;
		this.type = boolType;
	}

	public BoolQueryBuilderRequest fieldName(final String fieldName) {
		this.setFieldName(fieldName);
		return this;
	}

	public BoolQueryBuilderRequest type(final BoolType type) {
		this.setType(type);
		return this;
	}
	
	public BoolQueryBuilderRequest batchSize(final int batchSize) {
		this.setBatchSize(batchSize); 
		return this;
	}
	
	
	public BoolQueryBuilderRequest fieldValues(final List<String> fieldValues) {
		this.setFieldValues(fieldValues);
		return this;
	}
	
	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public List<String> getFieldValues() {
		return fieldValues;
	}

	public void setFieldValues(List<String> fieldValues) {
		this.fieldValues = fieldValues;
	}

	/**
	 * @return the batchSize
	 */
	public int getBatchSize() {
		if(batchSize == 0)
			batchSize = DEFAULT_BATCH_SIZE;

		return batchSize;
	}

	/**
	 * @param batchSize the batchSize to set
	 */
	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

	public BoolType getType() {
		return type;
	}

	public void setType(BoolType type) {
		this.type = type;
	}

	
}
