package com.miri.search.dynamicIndexServices.crm;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.children.ChildrenBuilder;
import org.elasticsearch.search.aggregations.bucket.children.InternalChildren;
import org.elasticsearch.search.aggregations.bucket.filter.Filter;
import org.elasticsearch.search.aggregations.bucket.filter.FilterAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.bucket.histogram.InternalHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Order;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.data.jpa.util.AppSalesStageContainer;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.MAPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.CampaignRevenueData;
import com.miri.search.data.MultipleAxesChartData;
import com.miri.search.data.SalesPersonRevenueData;
import com.miri.search.data.SplineIrregularData;
import com.miri.search.data.StackedColumnData;
import com.miri.search.data.TopCustomersData;
import com.miri.search.data.TopHighestCustomerData;
import com.miri.search.data.TopProductData;
import com.miri.search.data.TopSalesPersonData;
import com.miri.search.data.WinLossData;
import com.miri.search.dynamicIndexServices.MappedConstants;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;
import com.miri.search.service.map.MapCampaignService;
import com.miri.search.utils.MiriDateUtils;

@Component
public class CrmOpportunityService extends MiriSearchService {
	
	public static final String OPPORTUNITY_COMPETITOR_RAW = "competitor.raw";
	public static final String PRODUCT_RAW = "product.raw";
	public static final String PRODUCT = "product";
	public static final String OPPORTUNITY_ACCOUNTNAME_RAW = "accountName.raw";
	
	
	@Autowired
	private AppSalesStageContainer appSalesStageContainer;


	@Autowired
	private MapCampaignService mapCampaignService;
	
	@Autowired
	ERPInvoiceService erpInvoiceService;
	
	@Autowired
	TopProductsByRevenueService productService;



	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_CAMPAIGN_OPPORTUNITY_MAPPED.getText();
	}

	/**
	 * Gets the Top sales Person with in time frame and opportunities By Revenue
	 * 
	 * @param startDate
	 * @param endDate
	 * @param opportunities
	 * @param size
	 * @return
	 */
	public Map<String, TopSalesPersonData> getTopSalesPersonsWithInFiscalByRevenue(List<String> opportunities, int size,
			String startDate, String endDate) {
		BoolFilterBuilder boolFilter = null;

		if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter = FilterBuilders.boolFilter();
			boolFilter.must(
					FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE).from(startDate).to(endDate));
		}
		if (CollectionUtils.isNotEmpty(opportunities)) {
			if (null == boolFilter) {
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		SumBuilder sumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(MappedConstants.ORDER_BY_ERP_SALES_AMOUNT);
		TermsBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(opportunityAggregation)
				.subAggregation(sumBuilder);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_OWNER_RAW).size(0)
				.order(Order.aggregation(MappedConstants.CHILDREN + ">" + SearchConstants.SUM_AGGREGATION, false))
				.size(0);

		BoolFilterBuilder childBoolFilter = FilterBuilders.boolFilter();
		childBoolFilter.must(FilterBuilders.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, boolFilter));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), childBoolFilter)).setSize(0)
				.addAggregation(aggregationBuilders.subAggregation(childrenBuilder));

		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}

		TopSalesPersonData topSalesPersonData = null;
		List<String> salesPersonopportunities = null;

		double revenue = 0;
		double invoiceCount = 0;
		Map<String, TopSalesPersonData> topSalsPersonsMap = new HashMap<>();
		InternalChildren internalChildren = null;
		double ads = 0;
		double asp = 0;
		for (Terms.Bucket termBucket : termsBuckets) {
			String salesPerson = termBucket.getKey();
			if (StringUtils.isNotEmpty(salesPerson)) {
				topSalesPersonData = new TopSalesPersonData();
				salesPersonopportunities = new ArrayList<>();
				Collection<Terms.Bucket> opportunityBuckets = null;
				if (size != 0 && topSalsPersonsMap.size() >= size) {
					break;
				}
				if (null != termBucket.getAggregations()) {
					internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
					Sum sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
					revenue = sum.getValue();
					Terms opportunityTerms = internalChildren.getAggregations()
							.get(SearchConstants.OPPORTUNITY_AGGREGATION);
					opportunityBuckets = opportunityTerms.getBuckets();
					invoiceCount = internalChildren.getDocCount();

				}

				for (Terms.Bucket oppBucket : opportunityBuckets) {
					salesPersonopportunities.add(oppBucket.getKey());
				}
				ads = salesPersonopportunities.size() > 0 ? revenue / salesPersonopportunities.size() : 0.0;
				asp = invoiceCount > 0 ? revenue / invoiceCount : 0.0;
				topSalesPersonData.setRevenueAmount(revenue);
				topSalesPersonData.setSalesPerson(salesPerson);
				topSalesPersonData.setOpportunities(salesPersonopportunities);
				topSalesPersonData.setDealsClosed(salesPersonopportunities.size());
				topSalesPersonData.setAds(ads);
				topSalesPersonData.setAsp(asp);
				topSalsPersonsMap.put(salesPerson, topSalesPersonData);
			}
		}
		return topSalsPersonsMap;
	}
	
	/**
	 * Gets the Top sales Person with in time frame and opportunities By Revenue
	 * 
	 * @param startDate
	 * @param endDate
	 * @param opportunities
	 * @param size
	 * @return
	 */
	public Map<String, TopSalesPersonData> getSalesPersonsRevenueByName(int size,
			String startDate, String endDate, List<String> salesPersons, Boolean isMarketing) {
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_OWNER_RAW, salesPersons));
		if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter.must(FilterBuilders.hasChildFilter(MappedConstants.CRM_ERP_MAPPED,
					QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		}
		if(null != isMarketing){
			List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();	
			if(isMarketing){
				boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
			}else
				boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}
		SumBuilder sumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(MappedConstants.ORDER_BY_ERP_SALES_AMOUNT);
		TermsBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(opportunityAggregation)
				.subAggregation(sumBuilder);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_OWNER_RAW).size(0).order(Terms.Order.term(true)).size(0);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter)).setSize(0)
				.addAggregation(aggregationBuilders.subAggregation(childrenBuilder));

		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}

		TopSalesPersonData topSalesPersonData = null;
		List<String> salesPersonopportunities = null;
		double revenue = 0;
		double invoiceCount = 0;
		Map<String, TopSalesPersonData> topSalsPersonsMap = new HashMap<>();
		double ads = 0;
		double asp = 0;
		InternalChildren internalChildren = null;
		for (Terms.Bucket termBucket : termsBuckets) {
			String salesPerson = termBucket.getKey();
			if (StringUtils.isNotEmpty(salesPerson)) {
				topSalesPersonData = new TopSalesPersonData();
				salesPersonopportunities = new ArrayList<>();
				Collection<Terms.Bucket> opportunityBuckets = null;
				if (size != 0 && topSalsPersonsMap.size() >= size) {
					break;
				}
				if (null != termBucket.getAggregations()) {
					internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
					Sum sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
					revenue = sum.getValue();
					Terms opportunityTerms = internalChildren.getAggregations()
							.get(SearchConstants.OPPORTUNITY_AGGREGATION);
					opportunityBuckets = opportunityTerms.getBuckets();
					invoiceCount = internalChildren.getDocCount();
					for (Terms.Bucket oppBucket : opportunityBuckets) {
						salesPersonopportunities.add(oppBucket.getKey());
					}
					revenue = erpInvoiceService.getInvoiceAmountByOpportunityIds(salesPersonopportunities, startDate, endDate);
				}

				
				ads = salesPersonopportunities.size() > 0 ? revenue / salesPersonopportunities.size() : 0.0;
				asp = invoiceCount > 0 ? revenue / invoiceCount : 0.0;
				topSalesPersonData.setRevenueAmount(revenue);
				topSalesPersonData.setSalesPerson(salesPerson);
				topSalesPersonData.setOpportunities(salesPersonopportunities);
				topSalesPersonData.setAds(ads);
				topSalesPersonData.setAsp(asp);
				topSalsPersonsMap.put(salesPerson, topSalesPersonData);
			}
		}
		return topSalsPersonsMap;
	}

	public Map<String, List<CampaignRevenueData>> getCampaignWiseSalesPerson(List<String> oppor,
			List<String> salesPersons, String startDate, String endDate, int size) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_OWNER_RAW, salesPersons));
		List<String> marketingCamapigns = mapCampaignService.getMarketingSubCampaigns();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCamapigns));
		if (CollectionUtils.isNotEmpty(oppor)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, oppor));
		}
		boolFilterBuilder.must(FilterBuilders.hasChildFilter(MappedConstants.CRM_ERP_MAPPED,
				QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));

		SumBuilder sumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(sumBuilder);
		TermsBuilder salesAggre = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.CRM_PARENT_CAMPAIGN_NAME_RAW).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">" + SearchConstants.SUM_AGGREGATION, false)).subAggregation(parentBuilder);

		TermsBuilder accountAggre = AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_OWNER_RAW).size(0).subAggregation(salesAggre);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(accountAggre);
		SearchResponse searchResponse = searchRequestBuilder.get();

		Collection<Terms.Bucket> termsBuckets = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		Map<String, List<CampaignRevenueData>> mapCcampaignRevenueDatas = new HashMap<>();
		List<CampaignRevenueData> campaignRevenueDatas = null;
		Collection<Terms.Bucket> childrenTermsBuckets = null;
		CampaignRevenueData  campaignRevenueData = null;
		for (Terms.Bucket termBucket : termsBuckets) {
			campaignRevenueDatas = new ArrayList<>();
			Terms childrenTermsAggregation = termBucket.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			childrenTermsBuckets = childrenTermsAggregation.getBuckets();
			for (Terms.Bucket childrenTermsBucket : childrenTermsBuckets) {
				campaignRevenueData = new CampaignRevenueData();
				campaignRevenueData.setCampaignName(childrenTermsBucket.getKey());
				InternalChildren internalChildren = childrenTermsBucket.getAggregations().get(MappedConstants.CHILDREN);
				Sum sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				campaignRevenueData.setRevenueAmount(sum.getValue());
				campaignRevenueDatas.add(campaignRevenueData);
			}
			mapCcampaignRevenueDatas.put(termBucket.getKey(), campaignRevenueDatas);
		 }
		return mapCcampaignRevenueDatas;
	}
/*	public Map<String, List<CampaignRevenueData>> getCampaignWiseSalesPerson(List<String> oppor,
			List<String> salesPersons, String startDate, String endDate) {
		List<String> marketingCamapigns = getAllCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_OWNER_RAW, salesPersons));
		boolFilterBuilder
		.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCamapigns));
		if (CollectionUtils.isNotEmpty(oppor)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, oppor));
		}
		
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.hasChildFilter(MappedConstants.OPPORTUNITY_CAMPAIGN_MAPPED, boolFilterBuilder));
		
		SumBuilder sumAggregation = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		FilterAggregationBuilder Grandfilter = AggregationBuilders.filter(MappedConstants.GRAND_FILTERED_AGGREGATION)
				.filter(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate))
				.subAggregation(sumAggregation);
		
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.GRAND_CHILDREN)
				.childType(MappedConstants.OPPORTUNITY_INVOICE_MAPPED).subAggregation(Grandfilter);
		TermsBuilder termsAggregation = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_OWNER_RAW).subAggregation(childrenBuilder).size(0);
		TermsQueryBuilder builder = QueryBuilders.termsQuery(CRMConstants.OPPORTUNITY_OWNER_RAW, salesPersons);
		FilterAggregationBuilder filter = AggregationBuilders.filter(MappedConstants.FILTERED_AGGREGATION)
				.filter(FilterBuilders.queryFilter(builder)).subAggregation(termsAggregation);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.OPPORTUNITY_CAMPAIGN_MAPPED).subAggregation(filter);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(MAPConstants.CAMPAIGN_ID)
				.field(CRMConstants.CAMPAIGN_PARENT_CAMPAIGN_ID_RAW).subAggregation(parentBuilder).size(0);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_campaign")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter)).setSize(0)
				.addAggregation(aggregationBuilders);
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		Collection<Terms.Bucket> termsBuckets = null;
		Collection<Terms.Bucket> childrenTermsBuckets = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(MAPConstants.CAMPAIGN_ID);
			termsBuckets = terms.getBuckets();
		}
		
		double revenue = 0;
		InternalChildren internalChildren = null;
		InternalChildren grandChildren = null;
		Filter terms = null;
		Terms childrenTermsAggregation = null;
		String salesPerson = "";
		CampaignRevenueData campaignRevenueData = null;
		Sum sum = null;
		
		Map<String, List<CampaignRevenueData>> campaignWiseSalesPerson = new HashMap<>();
		List<CampaignRevenueData> campaignRevenueDatas = null;
		String campaign = "";
		for (Terms.Bucket termBucket : termsBuckets) {
			campaign = termBucket.getKey();
			if (StringUtils.isNotBlank(campaign)) {
				if (null != termBucket.getAggregations()) {
					internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
					if (null != internalChildren.getAggregations()) {
						terms = internalChildren.getAggregations().get(MappedConstants.FILTERED_AGGREGATION);
						if (null != terms.getAggregations()) {
							childrenTermsAggregation = terms.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
							childrenTermsBuckets = childrenTermsAggregation.getBuckets();
							for (Terms.Bucket bucket : childrenTermsBuckets) {
								campaignRevenueData = new CampaignRevenueData();
								campaignRevenueData.setCampaignName(termBucket.getKey());
								salesPerson = bucket.getKey();
								if (bucket.getAggregations() != null) {
									grandChildren = bucket.getAggregations().get(MappedConstants.GRAND_CHILDREN);
									if (null != grandChildren.getAggregations()) {
										terms = grandChildren.getAggregations()
												.get(MappedConstants.GRAND_FILTERED_AGGREGATION);
										sum = terms.getAggregations().get(SearchConstants.SUM_AGGREGATION);
										revenue = sum.getValue();
										if (revenue > 0) {
											campaignRevenueData.setRevenueAmount(revenue);
											if (campaignWiseSalesPerson.containsKey(salesPerson)) {
												campaignWiseSalesPerson.get(salesPerson).add(campaignRevenueData);
											} else {
												campaignRevenueDatas = new ArrayList<>();
												campaignRevenueDatas.add(campaignRevenueData);
												campaignWiseSalesPerson.put(salesPerson, campaignRevenueDatas);
											}
										}
									}
								}
								
							}
							
						}
					}
				}
			}
			
		}
		return campaignWiseSalesPerson;
	}
*/
	/*
	 * public static void main(String[] args) { Map<String, TopSalesPersonData>
	 * topSalesPersonsWithInFiscalByRevenue =
	 * getTopSalesPersonsWithInFiscalByRevenue(null, 25, "2015-04-01",
	 * "2016-03-31"); List<String> opportunities = new ArrayList<>();
	 * List<String> salesPeson = new ArrayList<>(); for(Entry<String,
	 * TopSalesPersonData> map :
	 * topSalesPersonsWithInFiscalByRevenue.entrySet()){
	 * opportunities.addAll(map.getValue().getOpportunities());
	 * salesPeson.add(map.getKey());
	 * 
	 * 
	 * } List<String> salesPeson = new ArrayList<>(Arrays.asList("Meghan Riley",
	 * "Andy Mitchelmore", "John Ywanciow", "Derek Myers", "Mark Gillum",
	 * "Robert Klase", "Doug Zimmerman", "Michael Staples", "Garrun Abrahams",
	 * "Gillian Cowhig", "Justin Brown", "Wesley Sarro", "Steven Meringolo",
	 * "Ryan Bentley", "Steve Dauncey", "Hartmut Mohn", "Kyle Keefner",
	 * "David Jackson", "Jerrod Wagner", "Anthony Gutierrez", "Peter McMillan2",
	 * "Chris Adams", "Jeremy Finchum", "Hubert Schiffer", "Kristi Ritzer"));
	 * getCampaignWiseSalesPerson(null,salesPeson, "2015-04-01", "2016-03-31");
	 * }
	 */

	/*public List<String> getAllCampaigns() {
		List<String> campaignsIds = new ArrayList<>();
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.MAP.getText())
				.setSearchType(SearchType.SCAN).setScroll(new TimeValue(6000))
				.setTypes(ElasticSearchEnums.MAP_CAMPAIGN.getText()).setQuery(QueryBuilders.matchAllQuery())
				.setSize(10000);

		SearchResponse searchResponse = searchRequestBuilder.get();
		SearchScrollRequestBuilder searchScrollRequestBuilder = null;

		while (true) {
			for (SearchHit hit : searchResponse.getHits()) {
				campaignsIds.add(hit.getId());
			}
			searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId())
					.setScroll(new TimeValue(1000));
			searchResponse = searchScrollRequestBuilder.get();
			if (searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return campaignsIds;
	}*/
	
	
	public List<SalesPersonRevenueData> getSalesPersionDataByWinRate(String startDate, String endDate, List<String> salesPersons, boolean isMarketing, List<Double> dollarDataList){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate));
		List<String> wonStages = appSalesStageContainer.getClosedWonMappedStages();
		List<String> lostStages = appSalesStageContainer.getClosedLostMappedStages();
		List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();	
		if(isMarketing){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}else
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_OWNER_RAW, salesPersons));
		SumBuilder lostSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_AMOUNT);
		
		SumBuilder wonSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		
		FilterAggregationBuilder lostfilterdAggregation = AggregationBuilders.filter(MappedConstants.FILTERED_AGGREGATION)
				.filter(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, lostStages))
				.subAggregation(lostSumBuilder);
		
		
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		
		
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				  .childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(wonSumBuilder).subAggregation(opportunityAggregation);
		
		FilterAggregationBuilder wonfilterdAggregation = AggregationBuilders.filter(MappedConstants.GRAND_FILTERED_AGGREGATION)
				.filter(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, wonStages))
				.subAggregation(childrenBuilder);
		
		TermsBuilder salesPersonAggregation  = AggregationBuilders.terms(SearchConstants.SALES_PERSON_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_OWNER_RAW).size(0).subAggregation(wonfilterdAggregation).subAggregation(lostfilterdAggregation);
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(salesPersonAggregation);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		WinLossData winLossData = new WinLossData();
		List<SalesPersonRevenueData> salesPersonRevenueDatas = new ArrayList<>();
		SalesPersonRevenueData salesPersonRevenueData = null;
		DecimalFormat df = new DecimalFormat("#.00");
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.SALES_PERSON_AGGREGATION);
			List<Bucket> termsBuckets = terms.getBuckets();
			for (Terms.Bucket termBucket : termsBuckets) {
				salesPersonRevenueData = new SalesPersonRevenueData();
				Filter losrTerms = termBucket.getAggregations()
						.get(MappedConstants.FILTERED_AGGREGATION);
				Sum lostSum = losrTerms.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				winLossData.setLostAmount(lostSum.getValue());
				winLossData.setLostCount(losrTerms.getDocCount());
				Filter wonTerms = termBucket.getAggregations()
						.get(MappedConstants.GRAND_FILTERED_AGGREGATION);
				InternalChildren invoiceChildren =  wonTerms.getAggregations().get(MappedConstants.CHILDREN);
				Sum wonSum = invoiceChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				Terms opportunityTerms = invoiceChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
				winLossData.setWonAmount(wonSum.getValue());
				winLossData.setWonCount(opportunityBuckets.size());
				salesPersonRevenueData.setSalesPersonName(termBucket.getKey());
				salesPersonRevenueData.setxAxisLabel(termBucket.getKey());
				salesPersonRevenueData.setxAxisParam(opportunityBuckets.size());
				salesPersonRevenueData.setRevenue(wonSum.getValue());
				salesPersonRevenueData.setNoOfDealsClosed((long) opportunityBuckets.size());
				salesPersonRevenueData.setNoOfDealsLost(losrTerms.getDocCount());
				double winPercentage;
				if((salesPersonRevenueData.getNoOfDealsClosed() == null || salesPersonRevenueData.getNoOfDealsClosed() == 0) && (salesPersonRevenueData.getNoOfDealsLost() == null || salesPersonRevenueData.getNoOfDealsLost() == 0)) {
					winPercentage = 0;
				} else {
					winPercentage = ((double) salesPersonRevenueData.getNoOfDealsClosed() / (salesPersonRevenueData.getNoOfDealsLost() + salesPersonRevenueData.getNoOfDealsClosed()))  * 100;
				}
				winPercentage = Double.valueOf(df.format(Double.isNaN(winPercentage) ? 0 : winPercentage));
				salesPersonRevenueData.setxAxisParam(winPercentage);
				salesPersonRevenueData.setWinRate(winPercentage);
				
				if(null != dollarDataList){
					dollarDataList.add(wonSum.getValue());
				}
				
				salesPersonRevenueDatas.add(salesPersonRevenueData);
			}
			
		}
		
		return salesPersonRevenueDatas;
	}
	
	public Map<String, SalesPersonRevenueData> getSalesPersionDataByWinRate(String startDate, String endDate, List<String> salesPersons, boolean isMarketing){
	
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate));
		
		List<String> wonStages = appSalesStageContainer.getClosedWonMappedStages();
		List<String> lostStages = appSalesStageContainer.getClosedLostMappedStages();
		List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();	

		if(isMarketing){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}else
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_OWNER_RAW, salesPersons));
		
		SumBuilder lostSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_AMOUNT);
		
		SumBuilder wonSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		
		FilterAggregationBuilder lostfilterdAggregation = AggregationBuilders.filter(MappedConstants.FILTERED_AGGREGATION)
				.filter(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, lostStages))
				.subAggregation(lostSumBuilder);
		
		
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		
		
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				  .childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(wonSumBuilder).subAggregation(opportunityAggregation);
		
		FilterAggregationBuilder wonfilterdAggregation = AggregationBuilders.filter(MappedConstants.GRAND_FILTERED_AGGREGATION)
				.filter(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, wonStages))
				.subAggregation(childrenBuilder);
		
		TermsBuilder salesPersonAggregation  = AggregationBuilders.terms(SearchConstants.SALES_PERSON_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_OWNER_RAW).size(0).subAggregation(wonfilterdAggregation).subAggregation(lostfilterdAggregation);
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(salesPersonAggregation);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		WinLossData winLossData = new WinLossData();
		Map<String, SalesPersonRevenueData> salesPersonRevenueDatas = new HashMap<String, SalesPersonRevenueData>();
		SalesPersonRevenueData salesPersonRevenueData = null;
		DecimalFormat df = new DecimalFormat("#.00");
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.SALES_PERSON_AGGREGATION);
			List<Bucket> termsBuckets = terms.getBuckets();
			for (Terms.Bucket termBucket : termsBuckets) {
				salesPersonRevenueData = new SalesPersonRevenueData();
				Filter losrTerms = termBucket.getAggregations()
						.get(MappedConstants.FILTERED_AGGREGATION);
				Sum lostSum = losrTerms.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				winLossData.setLostAmount(lostSum.getValue());
				winLossData.setLostCount(losrTerms.getDocCount());
				Filter wonTerms = termBucket.getAggregations()
						.get(MappedConstants.GRAND_FILTERED_AGGREGATION);
				InternalChildren invoiceChildren =  wonTerms.getAggregations().get(MappedConstants.CHILDREN);
				Sum wonSum = invoiceChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				Terms opportunityTerms = invoiceChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
				winLossData.setWonAmount(wonSum.getValue());
				winLossData.setWonCount(opportunityBuckets.size());
				salesPersonRevenueData.setSalesPersonName(termBucket.getKey());
				salesPersonRevenueData.setxAxisLabel(termBucket.getKey());
				salesPersonRevenueData.setxAxisParam(opportunityBuckets.size());
				salesPersonRevenueData.setRevenue(wonSum.getValue());
				salesPersonRevenueData.setNoOfDealsClosed((long) opportunityBuckets.size());
				salesPersonRevenueData.setNoOfDealsLost(losrTerms.getDocCount());
				double winPercentage;
				if((salesPersonRevenueData.getNoOfDealsClosed() == null || salesPersonRevenueData.getNoOfDealsClosed() == 0) && (salesPersonRevenueData.getNoOfDealsLost() == null || salesPersonRevenueData.getNoOfDealsLost() == 0)) {
					winPercentage = 0;
				} else {
					winPercentage = ((double) salesPersonRevenueData.getNoOfDealsClosed() / (salesPersonRevenueData.getNoOfDealsLost() + salesPersonRevenueData.getNoOfDealsClosed()))  * 100;
				}
				winPercentage = Double.valueOf(df.format(Double.isNaN(winPercentage) ? 0 : winPercentage));
				salesPersonRevenueData.setxAxisParam(winPercentage);
				salesPersonRevenueData.setWinRate(winPercentage);
				
				salesPersonRevenueDatas.put(termBucket.getKey(), salesPersonRevenueData);
			}
			
		}
		
		return salesPersonRevenueDatas;
	}

	/**
	 * Get Overall Sales person Data Object
	 * 
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @param opportunityIds
	 * @return
	 * @author rammoole
	 */
	public List<SalesPersonRevenueData> getSalesPersonDataByRevenue(Map<String, TopSalesPersonData> topSalesPersonDatas,
			List<Double> dollarData) {

		List<SalesPersonRevenueData> salesPersonRevenueDatas = new ArrayList<>();
		SalesPersonRevenueData salesPersonRevenueData = null;
		TopSalesPersonData topSalesPersonData = null;
		for (Entry<String, TopSalesPersonData> salesPerson : topSalesPersonDatas.entrySet()) {
			topSalesPersonData = salesPerson.getValue();
			salesPersonRevenueData = new SalesPersonRevenueData();
			salesPersonRevenueData.setSalesPersonName(salesPerson.getKey());
			salesPersonRevenueData.setxAxisLabel(salesPerson.getKey());
			salesPersonRevenueData.setxAxisParam(topSalesPersonData.getRevenueAmount());
			salesPersonRevenueData.setRevenue(topSalesPersonData.getRevenueAmount());
			dollarData.add(topSalesPersonData.getRevenueAmount());
			salesPersonRevenueDatas.add(salesPersonRevenueData);
		}
		return salesPersonRevenueDatas;
	}

	/**
	 * Get Overall Sales person Data Object
	 * 
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @param opportunityIds
	 * @return
	 * @author rammoole
	 */
	public List<SalesPersonRevenueData> getSalesPersonDataByADS(Map<String, TopSalesPersonData> topSalesPersonDatas,
			List<Double> dollarData) {

		List<SalesPersonRevenueData> salesPersonRevenueDatas = new ArrayList<>();
		SalesPersonRevenueData salesPersonRevenueData = null;
		TopSalesPersonData topSalesPersonData = null;
		for (Entry<String, TopSalesPersonData> salesPerson : topSalesPersonDatas.entrySet()) {
			topSalesPersonData = salesPerson.getValue();
			salesPersonRevenueData = new SalesPersonRevenueData();
			salesPersonRevenueData.setSalesPersonName(salesPerson.getKey());
			salesPersonRevenueData.setxAxisLabel(salesPerson.getKey());
			salesPersonRevenueData.setxAxisParam(topSalesPersonData.getAds());
			salesPersonRevenueData.setRevenue(topSalesPersonData.getRevenueAmount());
			salesPersonRevenueData.setAvgDealSize(topSalesPersonData.getAds());
			dollarData.add(topSalesPersonData.getRevenueAmount());
			salesPersonRevenueDatas.add(salesPersonRevenueData);
		}
		return salesPersonRevenueDatas;
	}

	/**
	 * Get Overall Sales person Data Object
	 * 
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @param opportunityIds
	 * @return
	 * @author rammoole
	 */
	public List<SalesPersonRevenueData> getSalesPersonDataByASP(Map<String, TopSalesPersonData> topSalesPersonDatas,
			List<Double> dollarData) {

		List<SalesPersonRevenueData> salesPersonRevenueDatas = new ArrayList<>();
		SalesPersonRevenueData salesPersonRevenueData = null;
		TopSalesPersonData topSalesPersonData = null;
		for (Entry<String, TopSalesPersonData> salesPerson : topSalesPersonDatas.entrySet()) {
			topSalesPersonData = salesPerson.getValue();
			salesPersonRevenueData = new SalesPersonRevenueData();
			salesPersonRevenueData.setSalesPersonName(salesPerson.getKey());
			salesPersonRevenueData.setxAxisLabel(salesPerson.getKey());
			salesPersonRevenueData.setxAxisParam(topSalesPersonData.getAsp());
			salesPersonRevenueData.setRevenue(topSalesPersonData.getRevenueAmount());
			salesPersonRevenueData.setAvgSellPrice(topSalesPersonData.getAsp());
			dollarData.add(topSalesPersonData.getRevenueAmount());
			salesPersonRevenueDatas.add(salesPersonRevenueData);
		}
		return salesPersonRevenueDatas;
	}

	/**
	 * Get Overall Sales person Data Object
	 * 
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @param opportunityIds
	 * @return
	 * @author rammoole
	 */
	public List<SalesPersonRevenueData> getSalesPersonDataByDealsClosed(
			Map<String, TopSalesPersonData> topSalesPersonDatas, List<Double> dollarData) {

		List<SalesPersonRevenueData> salesPersonRevenueDatas = new ArrayList<>();
		SalesPersonRevenueData salesPersonRevenueData = null;
		TopSalesPersonData topSalesPersonData = null;
		for (Entry<String, TopSalesPersonData> salesPerson : topSalesPersonDatas.entrySet()) {
			topSalesPersonData = salesPerson.getValue();
			salesPersonRevenueData = new SalesPersonRevenueData();
			salesPersonRevenueData.setSalesPersonName(salesPerson.getKey());
			salesPersonRevenueData.setxAxisParam(topSalesPersonData.getDealsClosed());
			salesPersonRevenueData.setRevenue(topSalesPersonData.getRevenueAmount());
			dollarData.add(topSalesPersonData.getRevenueAmount());
			salesPersonRevenueData.setNoOfDealsClosed(topSalesPersonData.getDealsClosed());
			salesPersonRevenueDatas.add(salesPersonRevenueData);
		}
		return salesPersonRevenueDatas;
	}

	/**
	 * Gets the Top sales Person with in time frame and opportunities By Revenue
	 * 
	 * @param startDate
	 * @param endDate
	 * @param opportunities
	 * @param size
	 * @return
	 */
	public Map<String, Object> getTopCustomersWithInFiscalByRevenue(Boolean isMarketing, int size,
			String startDate, String endDate, List<String> accountIds) {
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();

		if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter.must(FilterBuilders
					.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		}
		if (null != isMarketing) {
			List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();
			if (isMarketing) {
				boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
			}else{
				boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
			}
		}
		if(CollectionUtils.isNotEmpty(accountIds)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_NAME_RAW, accountIds));
		}
		SumBuilder sumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(MappedConstants.ORDER_BY_ERP_SALES_AMOUNT);
		TermsBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(opportunityAggregation)
				.subAggregation(sumBuilder);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.ACCOUNT_NAME_RAW).size(0)
				.order(Order.aggregation(MappedConstants.CHILDREN + ">" + SearchConstants.SUM_AGGREGATION, false))
				.size(size);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter)).setSize(0)
				.addAggregation(aggregationBuilders.subAggregation(childrenBuilder));

		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}

		TopCustomersData topCustomersData = null;
		List<String> customeropportunities = null;

		double revenue = 0;
		Map<String, Object> topcustomersMap = new HashMap<>();
		InternalChildren internalChildren = null;
		for (Terms.Bucket termBucket : termsBuckets) {
			String customer = termBucket.getKey();
			if (StringUtils.isNotEmpty(customer)) {
				topCustomersData = new TopCustomersData();
				customeropportunities = new ArrayList<>();
				Collection<Terms.Bucket> opportunityBuckets = null;
				if (null != termBucket.getAggregations()) {
					internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
					Terms opportunityTerms = internalChildren.getAggregations()
							.get(SearchConstants.OPPORTUNITY_AGGREGATION);
					opportunityBuckets = opportunityTerms.getBuckets();
					for (Terms.Bucket oppBucket : opportunityBuckets) {
						customeropportunities.add(oppBucket.getKey());
					}
					revenue = erpInvoiceService.getInvoiceAmountByOpportunityIds(customeropportunities, startDate, endDate);
					if(revenue > 0){
						topCustomersData.setxAxisName(customer);
						topCustomersData.setyAxisValue(revenue);
						topCustomersData.setzAxisValue(revenue);
						topCustomersData.setHoverDealsClosed((long) customeropportunities.size());
	
						TopHighestCustomerData customerData = new TopHighestCustomerData();
						customerData.setCustomerName(customer);
						customerData.setTotalSalesAmount(revenue);
	
						topCustomersData.setTopHighestcustomer(customerData);
						topcustomersMap.put(customer, topCustomersData);
					}
				}
			}
		}
		return topcustomersMap;
	}

	public Collection<Bucket> getTopCustomersByCamapaign(List<String> oppor,
			List<String> topCustomers, String startDate, String endDate, int size) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_NAME_RAW, topCustomers));
		List<String> marketingCamapigns = mapCampaignService.getMarketingSubCampaigns();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCamapigns));
		if (CollectionUtils.isNotEmpty(oppor)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, oppor));
		}
		boolFilterBuilder.must(FilterBuilders.hasChildFilter(MappedConstants.CRM_ERP_MAPPED,
				QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));

		SumBuilder sumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(sumBuilder);
		TermsBuilder salesAggre = AggregationBuilders.terms(SearchConstants.SALES_PERSON_AGGREGATION)
				.field(CRMConstants.CRM_PARENT_CAMPAIGN_NAME_RAW).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">" + SearchConstants.SUM_AGGREGATION, false)).subAggregation(parentBuilder);

		TermsBuilder accountAggre = AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
				.field(CRMConstants.ACCOUNT_NAME_RAW).size(0).subAggregation(salesAggre);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(accountAggre);
		SearchResponse searchResponse = searchRequestBuilder.get();

		Collection<Terms.Bucket> termsBuckets = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		return termsBuckets;
	}
/*	public Map<String, List<CampaignRevenueData>> getTopCustomersByCamapaign(List<String> oppor,
			List<String> topCustomers, String startDate, String endDate) {
		List<String> marketingCamapigns = mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_NAME_RAW, topCustomers));
		boolFilterBuilder
		.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCamapigns));
		if (CollectionUtils.isNotEmpty(oppor)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, oppor));
		}
		
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.hasChildFilter(MappedConstants.OPPORTUNITY_CAMPAIGN_MAPPED, boolFilterBuilder));
		
		SumBuilder sumAggregation = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		FilterAggregationBuilder Grandfilter = AggregationBuilders.filter(MappedConstants.GRAND_FILTERED_AGGREGATION)
				.filter(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate))
				.subAggregation(sumAggregation);
		
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.GRAND_CHILDREN)
				.childType(MappedConstants.OPPORTUNITY_INVOICE_MAPPED).subAggregation(Grandfilter);
		TermsBuilder termsAggregation = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.ACCOUNT_NAME_RAW).subAggregation(childrenBuilder).size(0);
		TermsQueryBuilder builder = QueryBuilders.termsQuery(CRMConstants.ACCOUNT_NAME_RAW, topCustomers);
		FilterAggregationBuilder filter = AggregationBuilders.filter(MappedConstants.FILTERED_AGGREGATION)
				.filter(FilterBuilders.queryFilter(builder)).subAggregation(termsAggregation);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.OPPORTUNITY_CAMPAIGN_MAPPED).subAggregation(filter);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(MAPConstants.CAMPAIGN_ID)
				.field(CRMConstants.CAMPAIGN_PARENT_CAMPAIGN_ID_RAW).subAggregation(parentBuilder).size(0);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_campaign")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter)).setSize(0)
				.addAggregation(aggregationBuilders);
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		Collection<Terms.Bucket> termsBuckets = null;
		Collection<Terms.Bucket> childrenTermsBuckets = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(MAPConstants.CAMPAIGN_ID);
			termsBuckets = terms.getBuckets();
		}
		
		double revenue = 0;
		InternalChildren internalChildren = null;
		InternalChildren grandChildren = null;
		Filter terms = null;
		Terms childrenTermsAggregation = null;
		String salesPerson = "";
		CampaignRevenueData campaignRevenueData = null;
		Sum sum = null;
		
		Map<String, List<CampaignRevenueData>> campaignWiseSalesPerson = new HashMap<>();
		List<CampaignRevenueData> campaignRevenueDatas = null;
		String campaign = "";
		for (Terms.Bucket termBucket : termsBuckets) {
			campaign = termBucket.getKey();
			if (StringUtils.isNotBlank(campaign)) {
				if (null != termBucket.getAggregations()) {
					internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
					if (null != internalChildren.getAggregations()) {
						terms = internalChildren.getAggregations().get(MappedConstants.FILTERED_AGGREGATION);
						if (null != terms.getAggregations()) {
							childrenTermsAggregation = terms.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
							childrenTermsBuckets = childrenTermsAggregation.getBuckets();
							for (Terms.Bucket bucket : childrenTermsBuckets) {
								campaignRevenueData = new CampaignRevenueData();
								campaignRevenueData.setCampaignName(termBucket.getKey());
								salesPerson = bucket.getKey();
								if (bucket.getAggregations() != null) {
									grandChildren = bucket.getAggregations().get(MappedConstants.GRAND_CHILDREN);
									if (null != grandChildren.getAggregations()) {
										terms = grandChildren.getAggregations()
												.get(MappedConstants.GRAND_FILTERED_AGGREGATION);
										sum = terms.getAggregations().get(SearchConstants.SUM_AGGREGATION);
										revenue = sum.getValue();
										if (revenue > 0) {
											campaignRevenueData.setRevenueAmount(revenue);
											if (campaignWiseSalesPerson.containsKey(salesPerson)) {
												campaignWiseSalesPerson.get(salesPerson).add(campaignRevenueData);
											} else {
												campaignRevenueDatas = new ArrayList<>();
												campaignRevenueDatas.add(campaignRevenueData);
												campaignWiseSalesPerson.put(salesPerson, campaignRevenueDatas);
											}
										}
									}
								}
								
							}
							
						}
					}
				}
			}
			
		}
		return campaignWiseSalesPerson;
	}
*/
	public Collection<Bucket> getTopCustomersByfield(List<String> topCustomers, String startDate, String endDate, int size, String field, boolean isMarketing) {
		List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_NAME_RAW, topCustomers));
		if (isMarketing) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}else{
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}
		boolFilterBuilder.must(FilterBuilders.hasChildFilter(MappedConstants.CRM_ERP_MAPPED,
				QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));

		SumBuilder sumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(sumBuilder);
		TermsBuilder salesAggre = AggregationBuilders.terms(SearchConstants.SALES_PERSON_AGGREGATION)
				.field(field).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">" + SearchConstants.SUM_AGGREGATION, false)).subAggregation(parentBuilder);

		TermsBuilder accountAggre = AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
				.field(CRMConstants.ACCOUNT_NAME_RAW).size(0).subAggregation(salesAggre);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(accountAggre);
		SearchResponse searchResponse = searchRequestBuilder.get();

		Collection<Terms.Bucket> termsBuckets = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		return termsBuckets;
	}
	
	public Map<String, Object> getTopCustomersByProduct(List<String> topCustomers, String startDate, String endDate, int size, boolean isMarketing) {
		List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_NAME_RAW, topCustomers));
		if (isMarketing) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}else{
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}
		boolFilterBuilder.must(FilterBuilders.hasChildFilter(MappedConstants.CRM_ERP_MAPPED,
				QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		
		SumBuilder sumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(sumBuilder).subAggregation(opportunityAggregation);
		
		TermsBuilder accountAggre = AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
				.field(CRMConstants.ACCOUNT_NAME_RAW).size(0).subAggregation(parentBuilder);
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(accountAggre);
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		Collection<Terms.Bucket> termsBuckets = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		StackedColumnData stackedColumnData = null ;
		List<String> xaxisNames =  new ArrayList<>();
		CampaignRevenueData campaignRevenueData = null;
		List<StackedColumnData> stackedColumnDatas = new ArrayList<>();
		for (Terms.Bucket termBucket : termsBuckets) {
			List<String> fiedOpportunities =  new ArrayList<>();
			   String accountName = termBucket.getKey();
				if (StringUtils.isNotBlank(accountName)) {
					List<CampaignRevenueData> campaignRevenueDatas = new ArrayList<>();
					stackedColumnData =  new StackedColumnData();
					stackedColumnData.setName(accountName);
					xaxisNames.add(accountName);
					InternalChildren internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
					Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
					Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
					for (Bucket opportunityBucket : opportunityBuckets) {
						fiedOpportunities.add(opportunityBucket.getKey());
					}
					List<TopProductData> topProductsByOpportunities = productService.getTopProductsByOpportunities(SearchConstants.SUB_LEVEL_SIZE, startDate, endDate, fiedOpportunities);
					for (TopProductData topProductData : topProductsByOpportunities) {
							campaignRevenueData = new CampaignRevenueData();
							campaignRevenueData.setRevenueAmount(topProductData.getValue());
							campaignRevenueData.setNoOfDeals(topProductData.getDealsClosed());
							campaignRevenueData.setProductName(topProductData.getName());
							campaignRevenueDatas.add(campaignRevenueData);
					}
					
					stackedColumnData.setStackedData(campaignRevenueDatas);
					stackedColumnData.setName(accountName);
					stackedColumnDatas.add(stackedColumnData);
				}
				
			}
		Map<String, Object> metricData = new HashMap<>();
		metricData.put("metricData", stackedColumnDatas);
		metricData.put("xaxisData", xaxisNames);
		return metricData;
	}

	
	
	
//	public List<CampaignRevenueData> getTopParentCampaignsMonthWiseData(String startDate, String endDate, int size){
//		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
//		boolFilterBuilder.must(FilterBuilders
//								.hasChildFilter(MappedConstants.OPPORTUNITY_CAMPAIGN_MAPPED, QueryBuilders.hasChildQuery(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate))));
//		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
//				.field(ERPConstants.INVOICE_SALES_AMOUNT);
//	
//		SumBuilder childSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT);
//		TermsBuilder termsBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(ERPConstants.OPPORTUNITY_ID_RAW).size(0);
//		
//		AbstractAggregationBuilder dateAggregation = AggregationBuilders
//				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(ERPConstants.INVOICE_CREATED_DATE)
//				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate).subAggregation(childSumBuilder).subAggregation(termsBuilder);
//		
//		
//		
//		FilterAggregationBuilder filteredAggregation = AggregationBuilders.filter(MappedConstants.FILTERED_AGGREGATION).filter(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate))
//				.subAggregation(parentSumBuilder).subAggregation(dateAggregation);
//		ChildrenBuilder grandParent = AggregationBuilders.children(MappedConstants.GRAND_CHILDREN).childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(filteredAggregation);
//		
//		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
//				.childType(MappedConstants.OPPORTUNITY_CAMPAIGN_MAPPED).subAggregation(grandParent);
//		TermsBuilder aggregationBuilders = AggregationBuilders.terms(MAPConstants.CAMPAIGN_ID)
//				.field(CRMConstants.CAMPAIGN_PARENT_CAMPAIGN_ID_RAW).subAggregation(parentBuilder).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">" + MappedConstants.GRAND_CHILDREN+">"+MappedConstants.FILTERED_AGGREGATION+">"+SearchConstants.SUM_AGGREGATION, false));
//		SearchRequestBuilder searchRequestBuilder =this.getTransportClient().prepareSearch("crm")
//				.setTypes("crm_campaign")
//				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
//				.addAggregation(aggregationBuilders);
//		SearchResponse searchResponse = searchRequestBuilder.get();
//		Map<Object, CampaignRevenueData> resultsMap = null;
//		Collection<Terms.Bucket> termsBuckets = null;
//		CampaignRevenueData campaignRevenueData = null;
//		List<CampaignRevenueData> revenueByCampaignAndMonth = new ArrayList<>();
//		InternalChildren children = null;
//		InternalChildren grandChildren = null;
//		Sum sum = null;
//		Terms monthlyOpportunities =  null;
//		Filter childTerms = null;
//		if (searchResponse.getAggregations() != null) {
//			Terms terms = searchResponse.getAggregations().get(MAPConstants.CAMPAIGN_ID);
//			termsBuckets = terms.getBuckets();
//		}
//		String campaignName = "";
//		for (Terms.Bucket termBucket : termsBuckets) {
//			campaignName = termBucket.getKey();
//			if(StringUtils.isNotBlank(campaignName)){
//				resultsMap = new HashMap<>();
//				campaignRevenueData = new CampaignRevenueData();
//				campaignRevenueData.setParentCampaignName(campaignName);
//				children =  termBucket.getAggregations().get(MappedConstants.CHILDREN);
//				grandChildren =  children.getAggregations().get(MappedConstants.GRAND_CHILDREN);
//				childTerms = grandChildren.getAggregations().get(MappedConstants.FILTERED_AGGREGATION);
//				InternalHistogram dateHistogram = childTerms.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
//				Collection<InternalHistogram.Bucket> dateBuckets = dateHistogram.getBuckets();
//				int count = 0;
//				for(InternalHistogram.Bucket dateBucket : dateBuckets){
//					monthlyOpportunities = dateBucket.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
//					CampaignRevenueData revenuePojo = new  CampaignRevenueData();
//					sum = dateBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
//					revenuePojo.setRevenueAmount(sum.getValue());
//					revenuePojo.setAverageDealSize(MiriSearchUtils.average(sum.getValue(), monthlyOpportunities.getBuckets().size()));
//					revenuePojo.setAverageSellPrice(MiriSearchUtils.average(sum.getValue(), (int) dateBucket.getDocCount()));
//					revenuePojo.setNoOfDeals((long) monthlyOpportunities.getBuckets().size());
//					revenuePojo.setNoOfProducts(new Long(dateBucket.getDocCount()));
//					resultsMap.put(count, revenuePojo);
//					count++;
//				}
//				campaignRevenueData.setRevenuesByMonth(resultsMap);
//				revenueByCampaignAndMonth.add(campaignRevenueData);
//				
//			}
//		}
//		return revenueByCampaignAndMonth;
//		
//	}
	
//	static Settings settings = ImmutableSettings.settingsBuilder().put("cluster.name", "dev-opt-elasticsearch")
//			.build();
//
//	static Client client = new TransportClient(settings)
//			.addTransportAddress(new InetSocketTransportAddress("10.132.160.129", 9300));
	
	public List<CampaignRevenueData> getTopParentCampaignsMonthWiseData(String startDate, String endDate, int size){
		Calendar startDateCal = MiriDateUtils.parseStrDateToCalendar(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		Calendar endDateCal = MiriDateUtils.parseStrDateToCalendar(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		boolFilterBuilder.must(FilterBuilders
				.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		
		SumBuilder childSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT);
		TermsBuilder termsBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(ERPConstants.OPPORTUNITY_ID_RAW).size(0);
		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(ERPConstants.INVOICE_CREATED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.minDocCount(0).extendedBounds(startDate, endDate).subAggregation(childSumBuilder).subAggregation(termsBuilder);
		
		
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(ElasticSearchEnums.OPPORTUNITY_INVOICE_MAPPED.getText()).subAggregation(dateAggregation);
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(MAPConstants.PARENT_CAMPAIGN_NAME)
				.field(CRMConstants.CRM_PARENT_CAMPAIGN_NAME_RAW).subAggregation(parentBuilder).size(size);
		
		SearchRequestBuilder searchRequestBuilder =this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		CampaignRevenueData campaignRevenueData = null;
		List<CampaignRevenueData> campaignRevenueDatas = new ArrayList<>();
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(MAPConstants.PARENT_CAMPAIGN_NAME);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				Map<Object, CampaignRevenueData> resultsMap = new HashMap<>();
				String parentCampaignName = termBucket.getKey();
				campaignRevenueData = new CampaignRevenueData();
				campaignRevenueData.setParentCampaignName(parentCampaignName);
				InternalChildren children =  termBucket.getAggregations().get(MappedConstants.CHILDREN);
				InternalHistogram dateHistogram = children.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
				Collection<InternalHistogram.Bucket> dateBuckets = dateHistogram.getBuckets();
				int count = 0;
				for(InternalHistogram.Bucket dateBucket : dateBuckets){
					if(MiriDateUtils.isDateBetween(dateBucket.getKey(), startDateCal, endDateCal)){
						Terms monthlyOpportunities = dateBucket.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
						CampaignRevenueData revenuePojo = new  CampaignRevenueData();
						Sum sum = dateBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
						revenuePojo.setRevenueAmount(sum.getValue());
						revenuePojo.setAverageDealSize(MiriSearchUtils.average(sum.getValue(), monthlyOpportunities.getBuckets().size()));
						revenuePojo.setAverageSellPrice(MiriSearchUtils.average(sum.getValue(), (int) dateBucket.getDocCount()));
						revenuePojo.setNoOfDeals((long) monthlyOpportunities.getBuckets().size());
						revenuePojo.setNoOfProducts(new Long(dateBucket.getDocCount()));
						resultsMap.put(count, revenuePojo);
						count++;
					}
				}
				campaignRevenueData.setRevenuesByMonth(resultsMap);
				campaignRevenueDatas.add(campaignRevenueData);
			}
		}
		return campaignRevenueDatas;
		
		
	}
	
	
	public List<CampaignRevenueData> getSubCampaignMonthWiseData(String startDate, String endDate, int size, List<String> parentCampaigns){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
								.hasChildFilter(MappedConstants.OPPORTUNITY_CAMPAIGN_MAPPED, QueryBuilders.hasChildQuery(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate))));
		
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PARENT_CAMPAIGN_ID_RAW, parentCampaigns));
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
	
		SumBuilder childSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT);
		TermsBuilder termsBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(ERPConstants.OPPORTUNITY_ID_RAW).size(0);
		
		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(ERPConstants.INVOICE_CREATED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate).subAggregation(childSumBuilder).subAggregation(termsBuilder);
		
		
		
		FilterAggregationBuilder filteredAggregation = AggregationBuilders.filter(MappedConstants.FILTERED_AGGREGATION).filter(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate))
				.subAggregation(parentSumBuilder).subAggregation(dateAggregation);
		ChildrenBuilder grandParent = AggregationBuilders.children(MappedConstants.GRAND_CHILDREN).childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(filteredAggregation);
		
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.OPPORTUNITY_CAMPAIGN_MAPPED).subAggregation(grandParent);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(MAPConstants.CAMPAIGN_ID)
				.field(CRMConstants.CAMPAIGN_NAME_RAW).subAggregation(parentBuilder).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">" + MappedConstants.GRAND_CHILDREN+">"+MappedConstants.FILTERED_AGGREGATION+">"+SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder =this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_campaign")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		SearchResponse searchResponse = searchRequestBuilder.get();
		Map<Object, CampaignRevenueData> resultsMap = null;
		Collection<Terms.Bucket> termsBuckets = null;
		CampaignRevenueData campaignRevenueData = null;
		List<CampaignRevenueData> revenueByCampaignAndMonth = new ArrayList<>();
		InternalChildren children = null;
		InternalChildren grandChildren = null;
		Sum sum = null;
		Terms monthlyOpportunities =  null;
		Filter childTerms = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(MAPConstants.CAMPAIGN_ID);
			termsBuckets = terms.getBuckets();
		}
		String campaignName = "";
		for (Terms.Bucket termBucket : termsBuckets) {
			campaignName = termBucket.getKey();
			if(StringUtils.isNotBlank(campaignName)){
				resultsMap = new HashMap<>();
				campaignRevenueData = new CampaignRevenueData();
				campaignRevenueData.setParentCampaignName(campaignName);
				children =  termBucket.getAggregations().get(MappedConstants.CHILDREN);
				grandChildren =  children.getAggregations().get(MappedConstants.GRAND_CHILDREN);
				childTerms = grandChildren.getAggregations().get(MappedConstants.FILTERED_AGGREGATION);
				InternalHistogram dateHistogram = childTerms.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
				Collection<InternalHistogram.Bucket> dateBuckets = dateHistogram.getBuckets();
				int count = 0;
				for(InternalHistogram.Bucket dateBucket : dateBuckets){
					monthlyOpportunities = dateBucket.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
					CampaignRevenueData revenuePojo = new  CampaignRevenueData();
					sum = dateBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
					revenuePojo.setRevenueAmount(sum.getValue());
					revenuePojo.setAverageDealSize(MiriSearchUtils.average(sum.getValue(), monthlyOpportunities.getBuckets().size()));
					revenuePojo.setAverageSellPrice(MiriSearchUtils.average(sum.getValue(), (int) dateBucket.getDocCount()));
					revenuePojo.setNoOfDeals((long) monthlyOpportunities.getBuckets().size());
					revenuePojo.setNoOfProducts(new Long(dateBucket.getDocCount()));
					resultsMap.put(count, revenuePojo);
					count++;
				}
				campaignRevenueData.setRevenuesByMonth(resultsMap);
				revenueByCampaignAndMonth.add(campaignRevenueData);
				
			}
		}
		return revenueByCampaignAndMonth;
		
	}
	
	
	public Map<String, Double> getMarketingLeadSourceAndRevenue(String startDate, String endDate, List<String> topLeadSources, int size, List<String> subCampaigns){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
								.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		if(CollectionUtils.isNotEmpty(topLeadSources)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.LEAD_SOURCE_RAW, topLeadSources));
		}
		if(CollectionUtils.isEmpty(subCampaigns)){
			List<String> mapCampaigns =  mapCampaignService.getMarketingSubCampaigns();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
		}else{
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, subCampaigns));

		}
		
		SumBuilder childSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT);
		
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(childSumBuilder).subAggregation(opportunityAggregation);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(CRMConstants.LEAD_SOURCE)
				.field(CRMConstants.LEAD_SOURCE_RAW).subAggregation(parentBuilder).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">"+SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder =this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		List<Bucket> termsBuckets = null;
		SearchResponse searchResponse = searchRequestBuilder.get();
		String leadSource = "";
		double revenue = 0;
		Sum sum = null;
		InternalChildren internalChildren = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(CRMConstants.LEAD_SOURCE);
			termsBuckets = terms.getBuckets();
		}
		Map<String, Double> leadSourceAndRevenue = new LinkedHashMap<>();
		for(Terms.Bucket termBucket : termsBuckets){
			leadSource = termBucket.getKey();
			if(StringUtils.isNotBlank(leadSource)){
				if(null != termBucket.getAggregations()){
					internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
					if(null != internalChildren.getAggregations()){
						List<String> fieldOpportunities = new ArrayList<>();
						sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
						Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
						Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
						for (Bucket opportunityBucket : opportunityBuckets) {
							fieldOpportunities.add(opportunityBucket.getKey());
						}
						revenue= erpInvoiceService.getInvoiceAmountByOpportunityIds(fieldOpportunities, startDate, endDate);
						leadSourceAndRevenue.put(leadSource, revenue);
					}
				}
			}
		}
		return leadSourceAndRevenue;
		
	}
	public Map<String, Double> getMarketingAssetsAndRevenue(String startDate, String endDate, List<String> topAssets, int size, List<String> subCampaigns){
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
				.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		if(CollectionUtils.isNotEmpty(topAssets)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.ASSETS_COMBINED_RAW, topAssets));
		}
		
		if(CollectionUtils.isEmpty(subCampaigns)){
			List<String> mapCampaigns =  mapCampaignService.getMarketingSubCampaigns();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
		}else{
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, subCampaigns));

		}
		
		
		SumBuilder childSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT);
		
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(childSumBuilder);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(CRMConstants.ASSETS_COMBINED)
				.field(CRMConstants.ASSETS_COMBINED_RAW).subAggregation(parentBuilder).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">"+SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder =this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		List<Bucket> termsBuckets = null;
		SearchResponse searchResponse = searchRequestBuilder.get();
		String asset = "";
		double revenue = 0;
		Sum sum = null;
		InternalChildren internalChildren = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(CRMConstants.ASSETS_COMBINED);
			termsBuckets = terms.getBuckets();
		}
		Map<String, Double> assetsAndRevenue = new LinkedHashMap<>();
		for(Terms.Bucket termBucket : termsBuckets){
			asset = termBucket.getKey();
			if(StringUtils.isNotBlank(asset)){
				if(null != termBucket.getAggregations()){
					internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
					if(null != internalChildren.getAggregations()){
						sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
						revenue= sum.getValue();
						assetsAndRevenue.put(asset, revenue);
					}
				}
			}
		}
		return assetsAndRevenue;
		
	}
	
	
	public Map<String, Object> getFieldRevenueByMonth(String startDate, String endDate, int size, String field, List<String> fieldValues, boolean isMarketing){
		Calendar startDateCal = MiriDateUtils.parseStrDateToCalendar(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		Calendar endDateCal = MiriDateUtils.parseStrDateToCalendar(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
				.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		
		if(isMarketing){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}else{
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}
		if(CollectionUtils.isNotEmpty(fieldValues)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(field, fieldValues));
		}
		
		SumBuilder childSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT);
		
		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(ERPConstants.INVOICE_CREATED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate).subAggregation(childSumBuilder);
		
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(dateAggregation).subAggregation(childSumBuilder);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(CRMConstants.OPPORTUNITY_TYPE)
				.field(field).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">"+SearchConstants.SUM_AGGREGATION, false)).subAggregation(childrenBuilder);
		SearchRequestBuilder searchRequestBuilder =this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		List<Bucket> termsBuckets = null;
		String key = "";
		double revenue = 0;
		Sum sum = null;
		List<Double> dollarData = new ArrayList<>();
		double dollarValue = 0d;
		List<SplineIrregularData>  splineIrregularDatas = new ArrayList<>();
		SplineIrregularData splineIrregularData = null;
		InternalChildren internalChildren = null;
		List<MultipleAxesChartData> revenueDatas = null;
		MultipleAxesChartData  revenueData = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(CRMConstants.OPPORTUNITY_TYPE);
			termsBuckets = terms.getBuckets();
		}
		
		for(Terms.Bucket termBucket : termsBuckets){
			dollarValue = 0d;
			key = termBucket.getKey();
			if(StringUtils.isNotBlank(key)){
				if(null != termBucket.getAggregations()){
					splineIrregularData = new SplineIrregularData();
		 			revenueDatas = new ArrayList<>();
		 			splineIrregularData.setName(key);
					internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
					if(null != internalChildren.getAggregations()){
						InternalHistogram dateHistogram = internalChildren.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
						Collection<InternalHistogram.Bucket> dateBuckets = dateHistogram.getBuckets();
						for(InternalHistogram.Bucket dateBucket : dateBuckets){
							if(MiriDateUtils.isDateBetween(dateBucket.getKey(), startDateCal, endDateCal)){
								revenueData = new MultipleAxesChartData();
								sum = dateBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
								revenue= sum.getValue();
								dollarValue += revenue;
								revenueData.setRevenueAmount(revenue);
								revenueData.setRevenueType(key);
								revenueDatas.add(revenueData);
							}
						}
						splineIrregularData.setRevenueData(revenueDatas);
						splineIrregularDatas.add(splineIrregularData);
						dollarData.add(dollarValue);
					}
				}
			}
		}
		Map<String, Object> metricData = new HashMap<>();
 		metricData.put("dollarRangeData", dollarData);
 		metricData.put("metricData", splineIrregularDatas);
 		return metricData;
	}
	
	
	public Map<String, Object> getFieldRevenueByMonthForProduct(String startDate, String endDate, int size, List<String> topProducts, List<String> opportunities){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_ITEM_CREATED_DATE).from(startDate).to(endDate));
		boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));
		if(CollectionUtils.isNotEmpty(topProducts)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, topProducts));
		}
		
		SumBuilder childSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(ERPConstants.INVOICE_ITEM_AMOUNT);
		
		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(ERPConstants.INVOICE_CREATED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate).subAggregation(childSumBuilder);
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(ERPConstants.PRODUCT_LEVEL_THREE_RAW).size(size).subAggregation(dateAggregation);
		SearchRequestBuilder searchRequestBuilder =this.getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOCE_INVOICE_ITEM_MAPPED.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		List<Bucket> termsBuckets = null;
		String key = "";
		double revenue = 0;
		Sum sum = null;
		List<Double> dollarData = new ArrayList<>();
		double dollarValue = 0d;
		List<SplineIrregularData>  splineIrregularDatas = new ArrayList<>();
		SplineIrregularData splineIrregularData = null;
		List<MultipleAxesChartData> revenueDatas = null;
		MultipleAxesChartData  revenueData = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		
		for(Terms.Bucket termBucket : termsBuckets){
			dollarValue = 0d;
			key = termBucket.getKey();
			if(StringUtils.isNotBlank(key)){
				if(null != termBucket.getAggregations()){
					splineIrregularData = new SplineIrregularData();
					revenueDatas = new ArrayList<>();
					splineIrregularData.setName(key);
						InternalHistogram dateHistogram = termBucket.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
						Collection<InternalHistogram.Bucket> dateBuckets = dateHistogram.getBuckets();
						for(InternalHistogram.Bucket dateBucket : dateBuckets){
								revenueData = new MultipleAxesChartData();
								sum = dateBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
								revenue= sum.getValue();
								dollarValue += revenue;
								revenueData.setRevenueAmount(revenue);
								revenueData.setRevenueType(key);
								revenueDatas.add(revenueData);
						}
						splineIrregularData.setRevenueData(revenueDatas);
						splineIrregularDatas.add(splineIrregularData);
						dollarData.add(dollarValue);
				}
			}
		}
		Map<String, Object> metricData = new HashMap<>();
		metricData.put("dollarRangeData", dollarData);
		metricData.put("metricData", splineIrregularDatas);
		return metricData;
	}
	
	public Map<String, Double> getTopFields(String field, String startDate, String endDate, int size, boolean isMarketing){
		List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
				.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		
		if(isMarketing){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}else{
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}
		
		SumBuilder childSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT);
		
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(childSumBuilder);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(CRMConstants.OPPORTUNITY_TYPE)
				.field(field).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">"+SearchConstants.SUM_AGGREGATION, false)).subAggregation(childrenBuilder);
		
		SearchRequestBuilder searchRequestBuilder =this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		List<Bucket> termsBuckets = null;
		String key = "";
		double revenue = 0;
		Sum sum = null;
		InternalChildren internalChildren = null;
		Map<String, Double> topFieldValues = new HashMap<>();
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(CRMConstants.OPPORTUNITY_TYPE);
			termsBuckets = terms.getBuckets();
		}
		
		for(Terms.Bucket termBucket : termsBuckets){
			key = termBucket.getKey();
			if(null != termBucket.getAggregations()){
				internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				if(null != internalChildren.getAggregations()){
					 sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
					 revenue = sum.getValue();
					 topFieldValues.put(key, revenue);
				}
			}
			
		}
		return topFieldValues;
	}
	
	public Map<Integer, Integer> getCusterCountByMonth(String startDate, String endDate){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(startDate).to(endDate));
		TermsBuilder termsBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(CRMConstants.ACCOUNT_NAME_RAW).size(0);
		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(ERPConstants.INVOICE_CREATED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.minDocCount(0).extendedBounds(startDate, endDate).subAggregation(termsBuilder);
		
		
		SearchRequestBuilder searchRequestBuilder =this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(dateAggregation);
		
		
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		InternalHistogram dateHistogram = searchResponse.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
		Collection<InternalHistogram.Bucket> dateBuckets = dateHistogram.getBuckets();
		int count = 0;
		Map<Integer, Integer> monthlyAccountsMap = new HashMap<>(); 
		for(InternalHistogram.Bucket dateBucket : dateBuckets){
				Terms monthlyAccounts = dateBucket.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
				Collection<Terms.Bucket>  termsBuckets = monthlyAccounts.getBuckets();
				monthlyAccountsMap.put(count, termsBuckets.size());
				count++;
		}
		return monthlyAccountsMap;
	}
	
}
