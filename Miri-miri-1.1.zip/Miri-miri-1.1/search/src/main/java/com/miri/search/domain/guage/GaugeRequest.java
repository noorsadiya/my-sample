package com.miri.search.domain.guage;

import java.io.Serializable;
import java.util.List;

import com.miri.search.data.FiscalDatesData;

public class GaugeRequest implements Serializable {

	private String index; //represents the index  in elastic search
	private String documentType; //represents the document to hit the query on
	
	private List<String> tagsFields; //represents the fields to matched in tags of the document
	private String[] relevantFields;  //represents the fields that needs to be returned from the document

	private String termsFilterOnField;
	private List<String> termsFilterOnValues; //represents the values to run a terms query on as  a filter
	
	private int validMetricDataCount;
	private  boolean isLastLevel;
	
	private FiscalDatesData fiscalDates;
	private String createDateField;
	
	private String tagsField;

	public GaugeRequest(String index, String documentType, List<String> tagsFields, String[] relevantFields,
			String termsFilterOnField, List<String> termsFilterOnValues, int validMetricDataCount, 
			boolean isLastLevel,FiscalDatesData fiscalDates,String createdDate) {
		super();
		this.index = index;
		this.documentType = documentType;
		this.tagsFields = tagsFields;
		this.relevantFields = relevantFields;
		this.termsFilterOnField = termsFilterOnField;
		this.termsFilterOnValues = termsFilterOnValues;
		this.validMetricDataCount = validMetricDataCount;
		this.isLastLevel = isLastLevel;
		this.fiscalDates = fiscalDates;
		this.createDateField = createdDate;
	}
	
	public GaugeRequest(String index, String documentType, String tagsField, String[] relevantFields,
			FiscalDatesData fiscalDates,String createdDate) {
		super();
		this.index = index;
		this.documentType = documentType;
		this.tagsField = tagsField;
		this.relevantFields = relevantFields;
		this.fiscalDates = fiscalDates;
		this.createDateField = createdDate;
	}
	
	
	public GaugeRequest(String index, String documentType, List<String> tagfields, String[] relevantFields,
			FiscalDatesData fiscalDates,String createdDate) {
		super();
		this.index = index;
		this.documentType = documentType;
		this.tagsFields = tagfields;
		this.relevantFields = relevantFields;
		this.fiscalDates = fiscalDates;
		this.createDateField = createdDate;
	}

	

	public GaugeRequest(String index, String documentType,
			FiscalDatesData fiscalDates,String createdDate) {
		super();
		this.index = index;
		this.documentType = documentType;
		this.fiscalDates = fiscalDates;
		this.createDateField = createdDate;
	}
	
	public GaugeRequest(){
		
	}
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public List<String> getTagsFields() {
		return tagsFields;
	}
	public void setTagsFields(List<String> tagsFields) {
		this.tagsFields = tagsFields;
	}
	public String[] getRelevantFields() {
		return relevantFields;
	}
	public void setRelevantFields(String[] relevantFields) {
		this.relevantFields = relevantFields;
	}
	public String getTermsFilterOnField() {
		return termsFilterOnField;
	}
	public void setTermsFilterOnField(String termsFilterOnField) {
		this.termsFilterOnField = termsFilterOnField;
	}
	public List<String> getTermsFilterOnValues() {
		return termsFilterOnValues;
	}
	public void setTermsFilterOnValues(List<String> termsFilterOnValues) {
		this.termsFilterOnValues = termsFilterOnValues;
	}
	public int getValidMetricDataCount() {
		return validMetricDataCount;
	}
	public void setValidMetricDataCount(int validMetricDataCount) {
		this.validMetricDataCount = validMetricDataCount;
	}
	public boolean isLastLevel() {
		return isLastLevel;
	}
	public void setLastLevel(boolean isLastLevel) {
		this.isLastLevel = isLastLevel;
	}
	public FiscalDatesData getFiscalDates() {
		return fiscalDates;
	}
	public void setFiscalDates(FiscalDatesData fiscalDates) {
		this.fiscalDates = fiscalDates;
	}
	
	public String getCreateDateField() {
		return createDateField;
	}
	
	public void setCreateDateField(String createDateField) {
		this.createDateField = createDateField;
	}
	
	public String getTagsField() {
		return tagsField;
	}
	
	public void setTagsField(String tagsField) {
		this.tagsField = tagsField;
	}	
	
}
