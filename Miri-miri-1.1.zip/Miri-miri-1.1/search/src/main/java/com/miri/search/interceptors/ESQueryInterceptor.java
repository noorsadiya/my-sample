/**
 * 
 */
package com.miri.search.interceptors;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.client.transport.NoNodeAvailableException;
import org.elasticsearch.common.inject.ConfigurationException;
import org.elasticsearch.common.netty.handler.timeout.TimeoutException;
import org.elasticsearch.common.util.concurrent.ExecutionError;
import org.elasticsearch.transport.TransportException;

import com.miri.search.exception.MiriESException;

/**
 * @author Chandra
 * 
 * ESQueryInterceptor: It is an Aspect that intercepts ES query execute method available in MiriSearchService. It
 * provides before, after and after throwing advise to intercept the execute method.
 *
 */
@Aspect
public class ESQueryInterceptor {

	private static final Logger LOGGER = Logger.getLogger(ESQueryInterceptor.class);

//	@Pointcut("execution(public * com.miri.search.esutils.ESQueryUtils.*(..)) && args(searchRequestBuilder,..)")
	@Pointcut("execution(public * com.miri.search.esutils.ESQueryUtils.*(..))")
	public void miriESQueryInterceptorPointcut() {
	}

	/*@Around("miriESQueryInterceptorPointcut()")
	public Object interceptESQueryInterceptor(ProceedingJoinPoint pjp) throws Throwable {
		String interceptMessage = pjp.getSignature().getName() + " : " + pjp.getSignature().getName();
		LOGGER.info("Executing ES Query : " + interceptMessage);
		long start = System.currentTimeMillis();
		Object returnValue = null;
		try {
			for (Object obj : pjp.getArgs()) {
				if (obj != null) {
					if (obj instanceof SearchRequestBuilder)
						LOGGER.info("ES Query:" + ((SearchRequestBuilder) obj).toString());
					else if (obj instanceof SearchRequestBuilder)
						LOGGER.info("ES Query:" + ((SearchScrollRequestBuilder) obj).toString());

					break;
				}
				else {
					throw new MiriESException("ES Execution Error: Search Request is null.");
				}

			}

			returnValue = pjp.proceed();
			long elapsedTime = System.currentTimeMillis() - start;
			if (null != returnValue && returnValue instanceof SearchResponse) {
				LOGGER.info("Time taken to execute ES Query:" + ((SearchResponse) returnValue).getTookInMillis());
			}
			else {
				throw new MiriESException("ES Execution Error: Search Response is null.");
			}
			LOGGER.info("Method execution time for" + interceptMessage + " : " + elapsedTime + " MilliSec.");
		}
		catch (Throwable ex) {
			throw new MiriESException("ES Execution Error: " + ex.getMessage(), ex.getCause());
		}
		return returnValue;

	}*/
	
	@AfterThrowing(pointcut = "miriESQueryInterceptorPointcut()", throwing = "exception")
	public void handleESQueryExecutionException(Throwable exception) throws MiriESException {
		LOGGER.error("Exception while executin ES Query.");
		if (exception instanceof NoNodeAvailableException) {
			MiriESException esException = new MiriESException("CRITICAL!!! Elasticsearch is down: "+exception.getMessage(), exception.getCause());
			throw esException;
		}
		if (exception instanceof TransportException) {
			throw new MiriESException("ES Transport Client Exception: " + exception.getMessage(), exception.getCause());
		}
		if (exception instanceof ConfigurationException) {
			throw new MiriESException("ES Configuration Exception: " + exception.getMessage(), exception.getCause());
		}
		if (exception instanceof TimeoutException) {
			throw new MiriESException("ES Query timeout Exception: " + exception.getMessage(), exception.getCause());
		}
		if (exception instanceof ExecutionError) {
			throw new MiriESException("ES Execution Exception: " + exception.getMessage(), exception.getCause());
		} 
		
		throw new MiriESException("Unknown ES Execution Error: " + exception.getMessage(), exception.getCause());
	}

	//@AfterReturning(pointcut = "miriESQueryInterceptorPointcut()", returning = "searchResponse")
	public void afterESQueryExecution(SearchResponse searchResponse) throws MiriESException {
		if (null != searchResponse) {
			LOGGER.info("Time taken to execute ES Query:" + searchResponse.getTookInMillis());
		}
		else {
			throw new MiriESException("ES Execution Error: Search Response is null.");
		}
	}

	//@Before("miriESQueryInterceptorPointcut()")
	public void beforeESQueryExecution(JoinPoint joinPoint) throws MiriESException {
		for (Object obj : joinPoint.getArgs()) {
			if (obj != null) {
				if (obj instanceof SearchRequestBuilder)
					LOGGER.info("ES Query:" + ((SearchRequestBuilder) obj).toString());
				else if (obj instanceof SearchRequestBuilder)
					LOGGER.info("ES Query:" + ((SearchScrollRequestBuilder) obj).toString());

				break;
			}
			else {
				throw new MiriESException("ES Execution Error: Search Request is null.");
			}

		}
	}
}
