package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

public class TopCustomerCampaignData implements Serializable{
	String	primaryCampaignSourceId;
	String accountId;
	List<String> opportunities;
	public String getPrimaryCampaignSourceId() {
		return primaryCampaignSourceId;
	}
	public void setPrimaryCampaignSourceId(String primaryCampaignSourceId) {
		this.primaryCampaignSourceId = primaryCampaignSourceId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public List<String> getOpportunities() {
		return opportunities;
	}
	public void setOpportunities(List<String> opportunities) {
		this.opportunities = opportunities;
	}
	
}
