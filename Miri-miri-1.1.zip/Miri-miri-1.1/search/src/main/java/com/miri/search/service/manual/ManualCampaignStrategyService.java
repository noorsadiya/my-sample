package com.miri.search.service.manual;

import java.io.IOException;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.indices.IndexMissingException;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.metrics.sum.InternalSum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.ManualCampaignStrategy;
import com.miri.cis.utilities.DateUtilities;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.FiscalDatesData;
import com.miri.search.data.FiscalDatesStrData;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.utils.TimerUtil;

@Component
public class ManualCampaignStrategyService extends MiriSearchService {
	private static final Logger LOG = LogManager.getLogger(ManualCampaignStrategyService.class);

	private static final String GROUPNAME_TOTALCAMPAIGNCOST = "totalCampaignCost";

	@Autowired
	private ESQueryUtils esQueryUtils;

	@Autowired
	private TimerUtil timeUtil;

	@Autowired
	private ManualAccountStrategyService manualAccountStrategyService;

	private ObjectMapper mapper = new ObjectMapper();

	/**
	 * This method can be used to get the List of all parent campaigns from
	 * manual campaigns
	 *
	 * @return {@link Map} map containing parent campaign Id and its name
	 */
	public Map<String, String> getParentCampaigns() {

		timeUtil.start();
		Map<String, String> campaignMap = new HashMap<String, String>();
		QueryBuilder opportunityQueryBuilder = QueryBuilders.matchQuery("parentCampaignId", "");
		try {
			SearchResponse campaignRespose = getResponse(opportunityQueryBuilder, SearchConstants.MANUAL,
					SearchConstants.CAMPAIGN_STRATEGY,
					new String[] { SearchConstants.CAMPAIGN_ID, SearchConstants.CAMPAIGN_NAME });

			for (SearchHit hit : campaignRespose.getHits()) {
				campaignMap.put(hit.field(SearchConstants.CAMPAIGN_ID).getValue().toString(),
						hit.field(SearchConstants.CAMPAIGN_NAME).getValue().toString());
			}
		}
		catch(IndexMissingException e){
			LOG.error("Index is missing" + SearchConstants.MANUAL + e.getMessage());
		}
		catch (Exception e) {
			LOG.error("Error while Fetching Data from Elastic search"+e.getMessage());
		}

		timeUtil.end();
		LOG.debug("ES time in getParentCampaigns"+timeUtil.timeTakenInMillis());
		return campaignMap;
	}

		/**
	 * This method can be used to get sub campaigns of the provided parent
	 * campaign
	 *
	 * @param parentCampaign
	 *            campaign Id for which sub campaigns need to be fetched
	 * @return {@link List} List containing all the sub campaigns of the
	 *         provided parent campaign
	 *
	 */

	public Map<String, String> getSubCampaigns(String parentCampaign) {
		Map<String, String> campaignIds = new HashMap<>();

		QueryBuilder opportunityQueryBuilder = (QueryBuilders.termQuery(SearchConstants.PARENT_CAMPAIGN_ID_RAW,
				parentCampaign));

		SearchResponse opportunityResponse = getResponse(opportunityQueryBuilder, SearchConstants.MANUAL,
				SearchConstants.CAMPAIGN_STRATEGY,
				new String[] { SearchConstants.CAMPAIGN_ID, SearchConstants.CAMPAIGN_NAME });

		for (SearchHit hit : opportunityResponse.getHits()) {
			campaignIds.put(hit.field(SearchConstants.CAMPAIGN_ID).getValue().toString(),
					hit.field(SearchConstants.CAMPAIGN_NAME).getValue().toString());
		}
		return campaignIds;
	}


	private SearchResponse getResponse(QueryBuilder queryBuilder, String index, String type, String[] fields) {
		Client client = getTransportClient();
		return client.prepareSearch(index).setTypes(type).setQuery(queryBuilder)
				.setSearchType(SearchType.DFS_QUERY_THEN_FETCH).setSize(25).addFields(fields).execute().actionGet();

	}


	/**
	 * Returns manual campaign for the given campaign id.
	 *
	 * @return
	 */
	public ManualCampaignStrategy getManualCampaignById(final String campaignId) {
		return (ManualCampaignStrategy) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(),
				"campaignId.raw", campaignId);

	}

	/**
	 * Returns the sum of total manual campaign costs for campaigns other than given
	 * campaign ids (to be excluded) and the ones created in given review period.
	 *
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @param campaignIdsToExclude campaign ids to be excluded while calculating cost
	 * @return sum of total manual campaign costs for campaigns other than given
	 * campaign ids
	 */
	public double getManualCampaignCost(final String reviewStartDate, final String reviewEndDate, final Set<String> campaignIdsToExclude) {
		Client client = getTransportClient();
		BoolFilterBuilder fiscalConditionClause = FilterBuilders.boolFilter();
		fiscalConditionClause.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE)
													.from(reviewStartDate)
													.to(reviewEndDate));

		BoolFilterBuilder otherCampaignsClause = FilterBuilders.boolFilter()
																.must(fiscalConditionClause)
																.mustNot(FilterBuilders.termsFilter(SearchConstants.CAMPAIGN_ID_RAW, campaignIdsToExclude));

		SumBuilder totalCampaignStrategyCostClause = AggregationBuilders.sum(GROUPNAME_TOTALCAMPAIGNCOST)
									.field(SearchConstants.TOTAL_COST);

		SearchRequestBuilder campaignStrategyCostSearchBuilder = client.prepareSearch(SearchConstants.MANUAL)
									 .setTypes(SearchConstants.CAMPAIGN_STRATEGY)
									 .setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), otherCampaignsClause))
									 .addAggregation(totalCampaignStrategyCostClause)
									 .setSize(0);

		LOG.trace("ManualCampaignCost: Query : "+campaignStrategyCostSearchBuilder);

		SearchResponse campaignStrategyCostSearchResponse = campaignStrategyCostSearchBuilder.execute().actionGet();
		InternalSum totalCampaignStrategyCostAggregation = campaignStrategyCostSearchResponse.getAggregations().get(GROUPNAME_TOTALCAMPAIGNCOST);

		return totalCampaignStrategyCostAggregation.getValue();
	}

	public Map<String, Object> getManualCampaignInputByName(String campaignName) {
		Map<String, Object> source = Collections.emptyMap();
		Client client = getTransportClient();

		FiscalDatesData fiscalDates = manualAccountStrategyService.get1YearDates();
		FiscalDatesStrData fiscalDatesStrData = manualAccountStrategyService.convertFiscalDatetoStr(fiscalDates);
		String reviewStartDate = fiscalDatesStrData.getFiscalStartDateStr();
		String reviewEndDate = fiscalDatesStrData.getFiscalEndDateStr();

		BoolQueryBuilder conditionClause = QueryBuilders.boolQuery();
		conditionClause.must(QueryBuilders.matchQuery(SearchConstants.CAMPAIGN_NAME_RAW, campaignName))
						.must(QueryBuilders.rangeQuery(SearchConstants.CREATED_DATE)
													.from(reviewStartDate)
													.to(reviewEndDate));

		SearchRequestBuilder searchBuilder = client.prepareSearch(getIndex())
													.setTypes(getDocumentType())
													.setQuery(conditionClause)
													.setFrom(0)
													.setSize(1)
													.addSort(SortBuilders.fieldSort(SearchConstants.CREATED_DATE).order(SortOrder.DESC));

		LOG.debug("getManualCampaignInputByName : Query : " + searchBuilder);
		SearchResponse searchResponse = searchBuilder.execute().actionGet();

		SearchHit[] hits = searchResponse.getHits().getHits();
		if (ArrayUtils.isNotEmpty(hits)) {
			source = hits[0].getSource();
		}

		return source;
	}


	/**
	 * Indexes given Campaign Strategy data
	 * @param parentCampaifnId
	 *
	 * @param campaignStrategySetup Campaign Strategy data to index
	 * @throws IOException if saving to ES fails due to json conversion
	 */
	public void indexCampaignStrategy(final String campaignId, final String campaignName, final String parentCampaignId,
			final String parentCampaignName, final String newCampaignName, final Double campaignCost,
			final String startDate, final Date currentDate, final boolean isDraft, final Set<String> editableFields) throws IOException {
		LOG.debug("Enter into save campaignStrategySetup" + campaignId);

		ManualCampaignStrategy manualCampaignStrategy = new ManualCampaignStrategy();
		manualCampaignStrategy.setVendorName(SearchConstants.CAMPAIGN_STRATEGY);
		manualCampaignStrategy.setVendorType(SearchConstants.MANUAL);
		manualCampaignStrategy.setCampaignId(campaignId);
		manualCampaignStrategy.setCampaignName(campaignName);
		manualCampaignStrategy.setParentCampaignId(parentCampaignId);
		manualCampaignStrategy.setParentCampaignName(parentCampaignName);
		manualCampaignStrategy.setNewCampaignName(newCampaignName);
		manualCampaignStrategy.setTotalCost(campaignCost.intValue());
		manualCampaignStrategy.setDraft(isDraft);
		manualCampaignStrategy.setEditableFields(editableFields);
		manualCampaignStrategy.setUpdatedDate(DateUtilities.dateToString(currentDate));
		if(StringUtils.isNotBlank(startDate)) {
			manualCampaignStrategy.setCampaignStart(startDate);
		}

		String identifier = null;
		Map<String, Object> manualCampaignInput = getManualCampaignInputByName(campaignName);

		if (MapUtils.isNotEmpty(manualCampaignInput)) {
			identifier = (String) manualCampaignInput.get("campaignId");
			String createdDate = (String) manualCampaignInput.get(SearchConstants.CREATED_DATE);
			manualCampaignStrategy.setCreatedDate(createdDate);
		} else {
			identifier = campaignId;
			manualCampaignStrategy.setCreatedDate(DateUtilities.dateToString(currentDate));
		}

		Client client = getTransportClient();
		String campaignJson = mapper.writeValueAsString(manualCampaignStrategy);
		IndexResponse response = client.prepareIndex(getIndex(), getDocumentType(), identifier)
										.setSource(campaignJson).execute().actionGet();
		LOG.debug("Response::>>>" + response);
	}

	/**
	 * Returns most recently updated Manual Campaign Detail.
	 *
	 * @return most recently updated Manual Campaign Detail
	 */
	public Map<String, Object> getMostRecentlyUpdated() {
		Map<String, Object> campaignDetails = null;
		LOG.debug("Enter into getRecentlyUpdatedManualCampaignDetails");

		SearchRequestBuilder searchBuilder = getTransportClient().prepareSearch(getIndex())
												.setTypes(getDocumentType())
												.addSort(SearchConstants.UPDATED_DATE, SortOrder.DESC);

		LOG.debug("MostRecentlyUpdated : Query : "+ searchBuilder);

		SearchResponse response = searchBuilder.execute().actionGet();

		SearchHits hits = response.getHits();
		SearchHit[] hitsArr = hits.getHits();

		if (ArrayUtils.isNotEmpty(hitsArr)) {
			campaignDetails = hitsArr[0].getSource();
		}

		return campaignDetails;
	}

	public Map<String, Object> getCampaignByName(String campaignName) {
		Map<String, Object> campaignDetails = null;
		LOG.debug("Enter into getRecentlyUpdatedManualCampaignDetails");

//		FiscalDatesStrData fiscalDatesStrData = manualAccountStrategyService.get1YearDatesStr();
//		String reviewStartDate = fiscalDatesStrData.getFiscalStartDateStr();
//		String reviewEndDate = fiscalDatesStrData.getFiscalEndDateStr();

//		BoolQueryBuilder fiscalConditionClause = QueryBuilders.boolQuery();
//		fiscalConditionClause.must(QueryBuilders.matchQuery(SearchConstants.MANUAL_CAMPAIGN_NAME, campaignName))
//								.must(QueryBuilders.rangeQuery(SearchConstants.CREATED_DATE)
//													.gte(reviewStartDate)
//													.lte(reviewEndDate));

		SearchRequestBuilder searchBuilder = getTransportClient().prepareSearch(getIndex())
												.setTypes(getDocumentType())
												.setQuery(QueryBuilders.matchQuery(SearchConstants.CAMPAIGN_NAME_RAW, campaignName))
												.addSort(SortBuilders.fieldSort(SearchConstants.UPDATED_DATE).order(SortOrder.DESC));

		LOG.debug("MostRecentlyUpdated : Query : "+ searchBuilder);

		SearchResponse response = searchBuilder.execute().actionGet();

		SearchHits hits = response.getHits();
		SearchHit[] hitsArr = hits.getHits();

		if (ArrayUtils.isNotEmpty(hitsArr)) {
			campaignDetails = hitsArr[0].getSource();
		}

		return campaignDetails;
	}


	public ManualCampaignStrategy getManualCampaignStrategy(){
		ManualCampaignStrategy mcs=new ManualCampaignStrategy();
		Client client = getTransportClient();

		SearchResponse getResponse = client.prepareSearch(getIndex())
				.setTypes(getDocumentType()).setSize(1)
				.get();

		SearchHits hits = getResponse.getHits();
		SearchHit[] hitsArr = hits.getHits();
		if (!ArrayUtils.isEmpty(hitsArr)) {
			SearchHit searchHit = hitsArr[0];
			mcs=(ManualCampaignStrategy)ESObjectMapper.getObject(searchHit.getSource(),getDocumentType(), getIndex());
		}
		return mcs;
	}

    @Override
    public String getIndex() {
        return ElasticSearchEnums.MANUAL.getText();
    }

    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.CAMPAIGN_STRATEGY.getText();
    }
}
