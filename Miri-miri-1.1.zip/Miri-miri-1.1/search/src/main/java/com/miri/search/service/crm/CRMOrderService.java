/**
 * 
 */
package com.miri.search.service.crm;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.CrmOrderDetails;
import com.miri.cis.entity.ESEntity;
import com.miri.search.constants.SearchConstants;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;

/**
 * CRMOrderService: Provides service methods to access CRM order document details.
 * 
 * @author Chandra
 *
 */
@Component
public class CRMOrderService extends MiriSearchService {

	@Autowired
	ESQueryUtils esQueryUtils;
	
    /*
     * (non-Javadoc)
     * 
     * @see com.miri.search.service.MiriSearchService#getIndex()
     */
    @Override
    public String getIndex() {
        return ElasticSearchEnums.CRM.getText();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.miri.search.service.MiriSearchService#getDocumentType()
     */
    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.CRM_ORDER.getText();
    }

    /**
     * Returns Sales order for the given opportunity id.
     * 
     * @param opportunityId
     * @return
     */
    public CrmOrderDetails getCRMOrderDetailsByOpportunityId(final String opportunityId) {

        return (CrmOrderDetails) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(),
            SearchConstants.OPPORTUNITY_ID_RAW, opportunityId);

    }
    
    /**
     * Returns Sales order for the given opportunity id.
     * 
     * @param opportunityId
     * @return
     */
    public List<ESEntity> getAllCRMOrderDetailsByOpportunityId(final String opportunityId) {

        return esQueryUtils.getMultipleDocsByFKId(getDocumentType(), getIndex(),
            SearchConstants.OPPORTUNITY_ID_RAW, opportunityId);

    }

	/**
	 * Returns CRM order details based on order id.
	 * 
	 * @param orderId
	 * @return
	 */
	public CrmOrderDetails getCRMOrderDetailsByOrderId(String orderId) {
		   return (CrmOrderDetails) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(),
		            "orderNumber.raw", orderId);
	}

}
