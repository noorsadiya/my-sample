package com.miri.search.data;

import java.io.Serializable;

public class LargestDealOpportunity implements Comparable<LargestDealOpportunity>, Serializable{

	private String opportunityId;
	
	private Long salesAmountSum;
	
	private String accountName;

	public String getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	public Long getSalesAmountSum() {
		return salesAmountSum;
	}

	public void setSalesAmountSum(Long salesAmountSum) {
		this.salesAmountSum = salesAmountSum;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	@Override
	public int compareTo(LargestDealOpportunity o) {
		return this.getSalesAmountSum().compareTo(o.getSalesAmountSum());
	}	

	@Override
	public String toString() {
		return "Opportunity [opportunityId=" + opportunityId + ", salesAmountSum=" + salesAmountSum + ", accountName="
				+ accountName + "]";
	}

}
