package com.miri.search.service.map;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.sum.InternalSum;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.MapCampaign;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.MAPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.FiscalDatesData;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.crm.CRMCampaignService;
import com.miri.search.service.crm.CRMOpportunityService;
import com.miri.search.service.manual.ManualAccountStrategyService;
import com.miri.search.utils.MiriComparators;
import com.miri.search.utils.MiriComparators.CampaignSetComparator;
import com.miri.search.utils.MiriDateUtils;

/**
 * This class can be used to perform various operations on map campaigns
 *
 * @author Prem Kumar
 *
 */
@Component
public class MapCampaignService extends MiriSearchService {
	private static final Logger LOGGER = LogManager.getLogger(MapCampaignService.class);

	private static final String GROUPNAME_TOTALCAMPAIGNCOST = "totalCampaignCost";

	@Autowired
	ManualAccountStrategyService manualAccountStrategyService;

	@Autowired
	ESQueryUtils esQueryUtils;

	@Autowired
	CRMCampaignService crmCampaignService;

	@Autowired
	CRMOpportunityService crmOpportunityService;

	/**
	 * Returns campaign by given campaign id.
	 *
	 * @param campaignId
	 * @return
	 */
	public MapCampaign getMAPCampaignById(final String campaignId) {
		return (MapCampaign) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), "campaignId.raw",
				campaignId);
	}

	@Override
	public String getIndex() {
		return ElasticSearchEnums.MAP.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.MAP_CAMPAIGN.getText();
	}

	/**
	 * This Method can be used to get all the campaigns in the map campaigns
	 *
	 * @return {@link Map} Map containing campaignId and its start date
	 */
	public Map<String, Date> getOverallCampaigns() {
		Map<String, Date> campaignMap = new HashMap<String, Date>();
		FiscalDatesData fiscalDates = manualAccountStrategyService.get1YearDates();
		QueryBuilder builder = QueryBuilders.rangeQuery(SearchConstants.CREATED_DATE)
				.gte(fiscalDates.getFiscalStartDate()).lte(fiscalDates.getFiscalEndDate());
		SearchResponse campaignRespose = getResponse(builder, SearchConstants.MAP, SearchConstants.MAP_CAMPAIGN,
				new String[] { SearchConstants.CAMPAIGN_ID, SearchConstants.CREATED_DATE });

		for (SearchHit hit : campaignRespose.getHits()) {
			campaignMap.put(hit.field(SearchConstants.CAMPAIGN_ID).getValue().toString(),
					MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
							hit.field(SearchConstants.CREATION_DATE).getValue().toString()));
		}
		return campaignMap;

	}

	/**
	 * This Method can be used to get the start date for all the campaign Id's Passed
	 * @param campaignIds campaignId's for which we need start date
	 * @return {@link Map} Containing Campaign Id as key and its start date as value
	 */
	public Map<String, Date> getCampaignDetailsByCampaigns(List<String> campaignIds) {

		Map<String, Date> campaignMap = new HashMap<String, Date>();
		QueryBuilder queryBuilder = QueryBuilders.termsQuery(SearchConstants.CAMPAIGN_ID, campaignIds);
		SearchResponse campaignRespose = getResponse(queryBuilder, SearchConstants.MAP, SearchConstants.MAP_CAMPAIGN,
				new String[] { SearchConstants.CAMPAIGN_ID, SearchConstants.CREATED_AT });
		for (SearchHit hit : campaignRespose.getHits()) {
			campaignMap.put(hit.field(SearchConstants.CAMPAIGN_ID).getValue().toString(),
					MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
							hit.field(SearchConstants.CREATED_AT).getValue().toString()));
		}
		return campaignMap;

	}

	public SearchResponse getResponse(final QueryBuilder queryBuilder, final String index, final String type,
			final String[] fields) {
		return this.getTransportClient().prepareSearch(index).setTypes(type).setSearchType(SearchType.DFS_QUERY_THEN_FETCH).setSize(25)
				.addFields(fields).setQuery(queryBuilder).execute().actionGet();

	}

	/**
	 * To get top 25 the sorted response of the documents
	 * @param queryBuilder
	 * @param index
	 * @param type
	 * @param fields
	 * @return
	 */
	public SearchResponse getSortedResponse(final QueryBuilder queryBuilder, final String index, final String type,
			final String[] fields, final SortBuilder sortBuilder, final int size) {
		return this.getTransportClient().prepareSearch(index).setTypes(type).setSearchType(SearchType.DEFAULT)
				.setSize(size).addSort(sortBuilder).addFields(fields).setQuery(queryBuilder).execute().actionGet();
	}

	/**
	 * Get all Map Campaigns
	 * @return
	 */
	public List<String> getMapCampaigns() {

		List<String> mapCampaigns = new ArrayList<>();

		SearchResponse campaignresponse = getTransportClient().prepareSearch(SearchConstants.MAP).setTypes("campaign")
				.setSearchType(SearchType.QUERY_AND_FETCH).addField("campaignName").execute().actionGet();

		SearchHits searchHits = campaignresponse.getHits();
		for (SearchHit hit : searchHits) {
			mapCampaigns.add(hit.getFields().get("campaignName").getValue().toString());
		}

		return mapCampaigns;
	}

	/**
	 * This Method can be used to get all the campaigns in the map campaigns
	 *
	 * @return {@link Map} Map containing campaignId and its start date
	 */
	public Map<String, Map<String, Object>> getCampaignsWithCost(Calendar startDate, Calendar endDate) {
		Map<String, Map<String, Object>> campaignMap = new HashMap<String, Map<String, Object>>();
		QueryBuilder builder = QueryBuilders.rangeQuery(SearchConstants.CREATED_DATE).gte(startDate).lte(endDate);
		SortBuilder sortBuilder = SortBuilders.fieldSort(SearchConstants.ACTUAL_COST).order(SortOrder.DESC);
		SearchResponse campaignRespose = getSortedResponse(builder, SearchConstants.MAP, SearchConstants.MAP_CAMPAIGN,
				new String[] { SearchConstants.CAMPAIGN_ID, SearchConstants.ACTUAL_COST, SearchConstants.CAMPAIGN_NAME },
				sortBuilder, SearchConstants.NO_OF_ITEMS);
		Map<String, Object> campaignNameAndCost;
		for (SearchHit hit : campaignRespose.getHits()) {
			campaignNameAndCost = new HashMap<>();
			campaignNameAndCost.put(SearchConstants.CAMPAIGN_NAME, hit.field(SearchConstants.CAMPAIGN_NAME).getValue().toString());
			campaignNameAndCost.put(SearchConstants.ACTUAL_COST, Double.parseDouble(hit.field(SearchConstants.ACTUAL_COST).getValue().toString()));
			campaignMap.put(hit.field(SearchConstants.CAMPAIGN_ID).getValue().toString(), campaignNameAndCost);
		}
		return campaignMap;
	}

	/**
	 * This Method can be used to get all the campaigns in the map campaigns
	 *
	 * @return {@link Map} Map containing campaignId and its start date
	 */
	public Map<String, Map<String, Object>> getParentCampaignsWithActualCost(Calendar startDate, Calendar endDate) {
		Map<String, String> parentCampaigns = crmCampaignService.getAllParentCampaigns();
		Map<String, Map<String, Object>> campaignMap = new HashMap<String, Map<String, Object>>();
		Map<String, Object> campaignNameAndCost;
		for (Map.Entry<String, String> parenCampaign : parentCampaigns.entrySet()) {
			campaignNameAndCost = new HashMap<>();
			double actualCost = getParentCampaignsActualCost(parenCampaign.getKey());
			campaignNameAndCost.put(SearchConstants.CAMPAIGN_NAME, parenCampaign.getValue());
			campaignNameAndCost.put(SearchConstants.ACTUAL_COST,actualCost);
			campaignMap.put(parenCampaign.getKey(), campaignNameAndCost);
		}
		return campaignMap;
	}

	public double getParentCampaignsActualCost(String parentCampaignId){

		TermQueryBuilder termQueryBuilder = QueryBuilders
											.termQuery(MAPConstants.CAMPAIGN_PARENTCAMPAIGN_ID_RAW, parentCampaignId);
		AbstractAggregationBuilder aggregationBuilder = AggregationBuilders
														.sum(SearchConstants.SUM_AGGREGATION)
														.field(MAPConstants.CAMPAIGN_ACTUAL_COST);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
													.setTypes(getDocumentType())
													.setSearchType(SearchType.DEFAULT)
													.setQuery(termQueryBuilder)
													.addAggregation(aggregationBuilder);
		SearchResponse searchResponse =  esQueryUtils.execute(searchRequestBuilder);
		Sum sumAggregation  =   searchResponse
								.getAggregations()
								.get(SearchConstants.SUM_AGGREGATION);
		return sumAggregation.getValue();

	}

	public List<String> getMapCampaignsFromCrmCampaigns(List<String> crmSubCampaignIds){
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(MAPConstants.CAMPAIGNID_RAW, crmSubCampaignIds));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
										.prepareSearch(getIndex())
										.setTypes(getDocumentType())
										.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
										.setSearchType(SearchType.SCAN)
										.setScroll(new TimeValue(6000))
										.setSize(1000);

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		List<String> subCampaigns =  new ArrayList<>();

		while(true){
			SearchHits oppSearchHits = searchResponse.getHits();
			for (SearchHit hit : oppSearchHits) {
				subCampaigns.add(hit.getSource().get(MAPConstants.CAMPAIGN_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =   getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(1000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}

		return subCampaigns;
	}


	public List<String> getMarketingSubCampaigns(){
		List<String> crmSubCampaigns =  new ArrayList<>(crmCampaignService.getAllSubCamapigns().keySet());
		return this.getMapCampaignsFromCrmCampaigns(crmSubCampaigns);
	}
	
	/**
	 * Gets the Marketing SubCampigns 
	 * @param crmSubCampaignIds
	 * @return
	 */
	public Map<String, String> getSubMapCampaignsFromCrmCampaigns(List<String> crmSubCampaignIds){
		Map<String, String> subCampaigns =  new HashMap<>();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(MAPConstants.CAMPAIGNID_RAW, crmSubCampaignIds));
		if(CollectionUtils.isNotEmpty(crmSubCampaignIds)){
			SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
											.prepareSearch(getIndex())
											.setTypes(getDocumentType())
											.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
											.setSearchType(SearchType.SCAN)
											.setScroll(new TimeValue(6000))
											.setSize(1000);
	
			SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
	
			
	
			while(true){
				SearchHits oppSearchHits = searchResponse.getHits();
				for (SearchHit hit : oppSearchHits) {
					subCampaigns.put((String)hit.getSource().get(MAPConstants.CAMPAIGN_ID), (String)hit.getSource().get(MAPConstants.CAMPAIGN_NAME));
				}
				SearchScrollRequestBuilder searchScrollRequestBuilder =   getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(1000));
				searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
				if(searchResponse.getHits().getHits().length == 0) {
					break;
				}
			}	
		}

		return subCampaigns;
	}

	/**
	 * Return sum of actual cost for the campaigns created in the given review period.
	 * campaignIdCollector - should have the ids of the campaigns for which the sum was calculated
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @param campaignIdCollector set to add campaigns for which the sum of cost was added
	 * @return sum of actual cost for the campaigns created in the given review period.
	 */
	public double getCampaignCostWithIds(final String reviewStartDate, final String reviewEndDate, final Set<String> campaignIdCollector) {
		Client client = getTransportClient();
		BoolQueryBuilder fiscalConditionClause = QueryBuilders.boolQuery();
		fiscalConditionClause.must(QueryBuilders.rangeQuery(SearchConstants.CREATED_DATE)
													.gte(reviewStartDate)
													.lte(reviewEndDate));

		SumBuilder totalCampaignCostClause = AggregationBuilders.sum(GROUPNAME_TOTALCAMPAIGNCOST).field(SearchConstants.ACTUAL_COST);

		SearchRequestBuilder campaignCostSearchBuilder = client.prepareSearch(getIndex())
															 .setTypes(getDocumentType())
															 .setQuery(fiscalConditionClause)
															 .addAggregation(totalCampaignCostClause);

		LOGGER.trace("CampaignCostWithIds: Query : "+campaignCostSearchBuilder);

		SearchResponse campaignCostSearchResponse = campaignCostSearchBuilder.execute().actionGet();

		InternalSum totalCampaignCostAggregation = campaignCostSearchResponse.getAggregations().get(GROUPNAME_TOTALCAMPAIGNCOST);
		double totalCampaignCost = totalCampaignCostAggregation.getValue();

		SearchHit[] searchHits = campaignCostSearchResponse.getHits().getHits();
		if (ArrayUtils.isNotEmpty(searchHits) && campaignIdCollector != null) {
			for (SearchHit searchHit : searchHits) {
				campaignIdCollector.add((String) searchHit.getSource().get(SearchConstants.CAMPAIGN_ID));
			}
		}

		return totalCampaignCost;
	}
	/**
	 * Gets the actual cost for campaigns
	 * @param subCampaigns
	 * @return
	 */
	public double getActualCostOfCamapigns(List<String> subCampaigns){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.CAMPAIGN_ID_RAW, subCampaigns));
		AbstractAggregationBuilder subaggregation = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(MAPConstants.CAMPAIGN_ACTUAL_COST);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.addAggregation(subaggregation)
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Sum sum =searchResponse.getAggregations().get(SearchConstants.SUM_AGGREGATION);
		return sum.getValue();

	}

	/**
	 * Gets the Campaigns And starttDate
	 * @param subCampaigns
	 * @return
	 */
	public Map<String, String> getCampaignAndStartDate(){

		Map<String, String> campaignsAndStartDate = new HashMap<>();

		AbstractAggregationBuilder subaggregation = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(MAPConstants.CAMPAIGNID_RAW).size(0)
				.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_HITS_AGGREGATION));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
				.prepareSearch(getIndex()).setTypes(getDocumentType())
				.addAggregation(subaggregation);

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		Terms stageTerms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> stageBuckets = stageTerms.getBuckets();
		for(Terms.Bucket bucket: stageBuckets) {
			TopHits topLostHits = bucket.getAggregations().get(SearchConstants.TOP_HITS_AGGREGATION);
			campaignsAndStartDate.put(bucket.getKey(), (String)topLostHits.getHits().getAt(0).getSource().get(MAPConstants.LEAD_CREATED_DATE));
		}
		return campaignsAndStartDate;
	}

	/**
	 * Get campaign start date in milli seconds
	 * @param campaignId
	 * @return
	 */
	public long getCampaignStartDateByCampaignId(String campaignId) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setFetchSource(CRMConstants.CAMPAIGN_START_DATE, null)
				.setQuery(QueryBuilders.termQuery(CRMConstants.CAMPAIGN_ID_RAW, campaignId));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		if(searchResponse.getHits().totalHits() > 0) {
			if(searchResponse.getHits().getAt(0).getSource() != null && searchResponse.getHits().getAt(0).getSource().get(CRMConstants.CAMPAIGN_START_DATE) != null) {
				//LOGGER.info("Campaign response :" + searchResponse.getHits().getAt(0).getSource());
				String campaignStartDate = searchResponse.getHits().getAt(0).getSource().get(CRMConstants.CAMPAIGN_START_DATE).toString();
				Calendar startDate = MiriDateUtils.parseStrDateToCalendar(campaignStartDate.replace("T", " ").replace("Z", ""), MiriDateUtils.DATE_FORMAT_YYYY_MM_DD_HH_MM_SSS);
				return startDate.getTimeInMillis();
			}
			return 0;
		} else {
			return 0;
		}
	}

	/**
	 * Returns the ES source of the MAP Campaign for the given campaign name
	 *
	 * @param campaignName for which the details are needed
	 * @return the source of the MAP Campaign for the given campaign name
	 */
	public Map<String, Object> getCampaignByName(String campaignName) {
		LOGGER.debug("Enter into getCampaignByName" + campaignName);
		Map<String, Object> campaignDetails = Collections.emptyMap();

		SearchRequestBuilder searchBuilder = getTransportClient().prepareSearch(getIndex())
												.setTypes(getDocumentType())
												.setQuery(QueryBuilders.matchQuery(SearchConstants.CAMPAIGN_NAME_RAW, campaignName))
												.addSort(SortBuilders.fieldSort(SearchConstants.CREATED_DATE).order(SortOrder.DESC));

		LOGGER.debug("CampaignByName : Query : " + searchBuilder);

		SearchResponse response = searchBuilder.execute().actionGet();

		SearchHit[] hitsArr = response.getHits().getHits();
		if (ArrayUtils.isNotEmpty(hitsArr)) {
			campaignDetails = hitsArr[0].getSource();
		}

		return campaignDetails;
	}

	/**
	 * A Set of Maps campaign id (as value) and campaign name (as name)
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 */
	public SortedSet<Map<String, String>> getAllCampaignsWithVendorName(final String reviewStartDate, final String reviewEndDate) {
		LOGGER.debug("Enter into getAllCampaignsWithVendorName");
		SortedSet<Map<String, String>> campaignSet = new TreeSet<Map<String, String>>(MiriComparators.CAMPAIGNSET_COMPARATOR);

		BoolFilterBuilder conditionClause = FilterBuilders.boolFilter().should(FilterBuilders.orFilter(FilterBuilders.notFilter(FilterBuilders.existsFilter(SearchConstants.END_DATE)),
																	FilterBuilders.rangeFilter(SearchConstants.END_DATE).gte(reviewStartDate)));
//		ExistsFilterBuilder existsFilter = FilterBuilders.existsFilter(SearchConstants.END_DATE);

		SearchRequestBuilder searchBuilder = getTransportClient().prepareSearch(getIndex())
																	.setTypes(getDocumentType())
																	.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), conditionClause))
																	.addField(SearchConstants.MAP_CAMPAIGN_ID)
																	.addField(SearchConstants.MAP_CAMPAIGN_NAME)
																	.setScroll(new TimeValue(6000))
																	.setSearchType(SearchType.SCAN)
																	.setSize(500);

		//LOGGER.debug("getAllCampaignsWithVendorName : Query : " + searchBuilder);

		SearchResponse response = searchBuilder.execute().actionGet();

		Map<String, String> campaigns = null;
		while(true){
			for (SearchHit hit : response.getHits()) {
				campaigns = new HashMap<String, String>();
				campaigns.put(CampaignSetComparator.VALUE_FIELD, String.valueOf(hit.field(SearchConstants.MAP_CAMPAIGN_ID).getValue()));
				campaigns.put(CampaignSetComparator.NAME_FIELD, String.valueOf(hit.field(SearchConstants.MAP_CAMPAIGN_NAME).getValue()));
				campaignSet.add(campaigns);
			}
			 SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(response.getScrollId())
				      .setScroll(new TimeValue(6000));
			 response = esQueryUtils.execute(searchScrollRequestBuilder);
		    if(response.getHits().getHits().length == 0) {
		    	break;
		    }
		}
		return campaignSet;
	}
}
