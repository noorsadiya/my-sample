package com.miri.search.constants;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.miri.data.jpa.domain.Currency;
import com.miri.data.jpa.repository.accountSetup.AccountSetupRepository;
import com.miri.search.service.common.MiriStaticContextAccessor;

/**
 * Constants for ERP index related fields - prefix the document type to the field
 * @author rammoole
 *
 */
public final class ERPConstants {
	
	private static final Logger LOG = LogManager.getLogger(ERPConstants.class);
	
	private static final String USD = "USD";
	private static final String EUR = "EUR";
	private static final String GBP = "GBP";
	
	//ERP Invoice
	public static final String INVOICE_ID = "invoiceId";
	public static final String INVOICE_ID_RAW = "invoiceId.raw";
	public static final String OPPORTUNITY_ID_RAW = "opportunityId.raw";

	public static final String OPPORTUNITY_COMPETITOR_NAME = "competitorName";
	public static final String OPPORTUNITY_COMPETITOR_NAME_RAW = "competitorName.raw";

	public static final String INVOICE_SALES_PERSON = "salesPerson";
	public static final String INVOICE_SALES_PERSON_RAW = "salesPerson.raw";

	public static final String INVOICE_CREATED_DATE = "createdDate";
	public static final String INVOICE_ITEM_CREATED_DATE = "createdDate";

	public static final String INVOICE_ITEMS = "invoiceItems";
	public static final String INVOICE_ITEMS_RAW = "invoiceItems.raw";

	public static final String INVOICE_ITEM_ID = "invoiceItemId";
	public static final String INVOICE_ITEM_ID_RAW = "invoiceItemId.raw";

	public static final String INVOICE_ITEM_PRODUCT_CODE_RAW = "productCode.raw";
	public static final String INVOICE_ITEM_PRODUCT_CODE = "productCode";

	public static final String PRODUCT_NAME = "productName";
	public static final String PRODUCT_NAME_RAW = "productName.raw";

	public static final String PRODUCT_ID = "productId";
	public static final String PRODUCT_ID_RAW = "productId.raw";

	//ERP Order Items.
	public static final String ORDER_ITEM_DOCID = "itemDocumentId";
	public static final String ORDER_ITEM_ID = "itemId";
	public static final String ORDER_ITEM_ID_RAW = "itemId.raw";

	public static final String ORDER_ITEM_QUANTITY = "quantity";
	public static final String ORDER_ITEM_NAME = "itemName";
	public static final String ORDER_ITEM_NAME_RAW = "itemName.raw";

	public static final String ORDER_ITEM_TYPE = "itemType";
	public static final String ORDER_ITEM_TYPE_RAW = "itemType.raw";

	public static final String ORDER_ITEM_TOTAL_VALUE = "totalValue";

	//Erp Sales Order
	public static final String SALES_ORDER_ITEMS = "items";
	public static final String SALES_ORDER_ITEMS_RAW = "items.raw";

	public static final String OPPORTUNITY_ID= "opportunityId";
	public static final String ACCOUNT_NAME="accountName";
	public static final String LEAD_SOURCE="leadSource";

	public static final String INVOICE_OPPORTUNITY_ID_RAW = "opportunityId.raw";
	public static final String INVOICE_PRODUCT_QUANTITY = "productQuantity";

	public static String INVOICE_SALES_AMOUNT;
	public static final String INVOICE_SALES_AMOUNT_USD = "salesAmountUSD";
	public static final String INVOICE_SALES_AMOUNT_GBP = "salesAmountGBP";
	public static final String INVOICE_SALES_AMOUNT_EUR = "salesAmountEUR";
	
	public static final String INVOICE_ACCOUNT_NAME_RAW = "accountName.raw";
	public static final String SALES_ORDER_CREATED_DATE = "createdDate";

	//public final static String AMOUNT = "amount";
	public static String INVOICE_ITEM_AMOUNT;
	public static final String INVOICE_ITEM_AMOUNT_USD = "amountUSD";
	public static final String INVOICE_ITEM_AMOUNT_GBP = "amountGBP";
	public static final String INVOICE_ITEM_AMOUNT_EUR = "amountEUR";
	public static final String PRODUCT_LEVEL_THREE_RAW = "levelThree.raw";
	public static final String PRODUCT_LEVEL_THREE = "levelThree";
	
	static {
		try {
			// db call
			Currency currency = MiriStaticContextAccessor.getBean(AccountSetupRepository.class).getCurrency();
			String currencyType = currency.getCode();
			//System.out.println("******************* ACCOUNT SETUP: ***********************" + currencyType);
			//LOG.info("ACCOUNT SETUP**********************************: " + currencyType);
			switch(currencyType) {
			case USD:
				INVOICE_SALES_AMOUNT = INVOICE_SALES_AMOUNT_USD;
				INVOICE_ITEM_AMOUNT = INVOICE_ITEM_AMOUNT_USD;
				break;
			case GBP:
				INVOICE_SALES_AMOUNT = INVOICE_SALES_AMOUNT_GBP;
				INVOICE_ITEM_AMOUNT = INVOICE_ITEM_AMOUNT_USD;
				break;
			case EUR:
				INVOICE_SALES_AMOUNT = INVOICE_SALES_AMOUNT_EUR;
				INVOICE_ITEM_AMOUNT = INVOICE_ITEM_AMOUNT_EUR;
				break;
			default:
				// default case
				INVOICE_SALES_AMOUNT = "salesAmount";
				INVOICE_ITEM_AMOUNT = "amount";
			}
		} catch(Exception e) {
			LOG.error("exception :", e);
		}
	}
}
