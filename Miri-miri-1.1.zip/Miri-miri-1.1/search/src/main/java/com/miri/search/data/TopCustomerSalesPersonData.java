package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

public class TopCustomerSalesPersonData  implements Serializable{
	String salesPerson;
	String accountId;
	List<String> opportunities;
	public String getSalesPerson() {
		return salesPerson;
	}
	public void setSalesPerson(String salesPerson) {
		this.salesPerson = salesPerson;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public List<String> getOpportunities() {
		return opportunities;
	}
	public void setOpportunities(List<String> opportunities) {
		this.opportunities = opportunities;
	}
}
