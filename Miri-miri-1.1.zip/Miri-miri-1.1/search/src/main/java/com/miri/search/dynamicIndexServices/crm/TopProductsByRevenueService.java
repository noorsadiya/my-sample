package com.miri.search.dynamicIndexServices.crm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.children.ChildrenBuilder;
import org.elasticsearch.search.aggregations.bucket.children.InternalChildren;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Order;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.TopProductData;
import com.miri.search.dynamicIndexServices.MappedConstants;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;
import com.miri.search.service.map.MapCampaignService;

@Component
public class TopProductsByRevenueService extends MiriSearchService {

	@Autowired
	MapCampaignService mapCampaignsService;

	@Autowired
	ERPInvoiceService erpInvoiceService;

	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.ERP_INVOCE_INVOICE_ITEM_MAPPED.getText();
	}

	private TopProductData constructProductObject(int deals, String name, double revenue, long invoiceCount) {
		TopProductData topProductData = new TopProductData();
		double averageDealSize = deals != 0.0 ? revenue / deals : 0.0;
		double averageSellPrice = invoiceCount != 0.0 ? revenue / invoiceCount : 0.0;
		topProductData.setName(name);
		topProductData.setValue(revenue);
		topProductData.setAvgDealSize(averageDealSize);
		topProductData.setDealsClosed((long) deals);
		topProductData.setAvgSellPrice(averageSellPrice);
		topProductData.setInvoiceCount(invoiceCount);
		return topProductData;
	}

	public Map<String, Double> getTopProducts(int size, String startDate, String endDate) {
		Map<String, Double> topProducts = new HashMap<String, Double>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder
				.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, ""));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, "NULL"));
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_ITEM_AMOUNT);

		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.INDUSTRY_AGGREGATION)
				.field(ERPConstants.PRODUCT_LEVEL_THREE_RAW).subAggregation(parentSumBuilder).size(size)
				.order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);

		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		Sum sum = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.INDUSTRY_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if (StringUtils.isNotBlank(termBucket.getKey())) {
				sum = termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				revenue = sum.getValue();
				if (revenue > 0) {
					topProducts.put(termBucket.getKey(), revenue);
				}
			}
		}
		return topProducts;
	}

	public List<TopProductData> getTopProductsByOpportunities(List<String> opportunities, String startDate,
			String endDate, List<String> topProducts) {
		List<TopProductData> topProuctsList = new ArrayList<TopProductData>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder
				.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_ITEM_CREATED_DATE).gte(startDate).lte(endDate));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, ""));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, "NULL"));
		boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, topProducts));
		if (CollectionUtils.isNotEmpty(opportunities)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));

		}
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_ITEM_AMOUNT);

		TermsBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);

		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.INDUSTRY_AGGREGATION)
				.field(ERPConstants.PRODUCT_LEVEL_THREE_RAW).subAggregation(parentSumBuilder)
				.size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS).subAggregation(opportunityAggregation)
				.order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);

		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		Sum sum = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.INDUSTRY_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if (StringUtils.isNotBlank(termBucket.getKey())) {
				sum = termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				revenue = sum.getValue();
				if (revenue > 0) {
					Terms opportunityTerms = termBucket.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
					Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
					topProuctsList.add(constructProductObject(opportunityBuckets.size(), termBucket.getKey(), revenue,
							termBucket.getDocCount()));
				}
			}
		}
		return topProuctsList;
	}

	public List<TopProductData> getTopProductsByFields(String startDate, String endDate, List<String> topProducts,
			List<String> opportunities, String field) {
		List<TopProductData> topProuctsList = new ArrayList<TopProductData>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder
				.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_ITEM_CREATED_DATE).gte(startDate).lte(endDate));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, ""));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, "NULL"));
		boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, topProducts));
		if (CollectionUtils.isNotEmpty(opportunities)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW,
					opportunities));
		} 
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_ITEM_AMOUNT);

		TermsBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);

		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.INDUSTRY_AGGREGATION)
				.field(ERPConstants.PRODUCT_LEVEL_THREE_RAW).subAggregation(parentSumBuilder)
				.size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS).subAggregation(opportunityAggregation)
				.order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);

		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		Sum sum = null;
		TopProductData topProductData = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.INDUSTRY_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if (StringUtils.isNotBlank(termBucket.getKey())) {
				sum = termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				revenue = sum.getValue();
				if (revenue > 0) {
					List<String> productOpportunities = new ArrayList<>();
					Terms opportunityTerms = termBucket.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
					Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
					for (Bucket opportunityBucket : opportunityBuckets) {
						productOpportunities.add(opportunityBucket.getKey());
					}
					topProductData = constructProductObjectWithOutADSASP(termBucket.getKey(), revenue);
					topProductData.setTopProductInfo(getDataForField(field, productOpportunities, startDate, endDate, SearchConstants.SUB_LEVEL_SIZE));
					topProuctsList.add(topProductData);
				}
			}
		}
		return topProuctsList;
	}

	/**
	 * Construct Product Object without ADS, ASP
	 * 
	 * @param wonOpportunities
	 * @param name
	 * @param revenue
	 * @param startDate
	 * @param endDate
	 * @param productQuantity
	 * @return
	 */
	private TopProductData constructProductObjectWithOutADSASP(String name, double revenue) {
		TopProductData topProductData = new TopProductData();
		topProductData.setName(name);
		topProductData.setValue(revenue);
		return topProductData;
	}

	public List<TopProductData> getDataForField(String field, List<String> opportunities, String startDate, String endDate, int size) {
		List<TopProductData> topProuctsList = new ArrayList<TopProductData>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.hasChildFilter(MappedConstants.CRM_ERP_MAPPED,
				QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));

		SumBuilder childSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		TermsBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(childSumBuilder)
				.subAggregation(opportunityAggregation);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(field)
				.subAggregation(parentBuilder).size(size)
				.order(Order.aggregation(MappedConstants.CHILDREN + ">" + SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		List<Bucket> termsBuckets = null;
		SearchResponse searchResponse = searchRequestBuilder.get();
		String fieldValue = "";
		double revenue = 0;
		Sum sum = null;
		InternalChildren internalChildren = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			fieldValue = termBucket.getKey();
			if (StringUtils.isNotBlank(fieldValue)) {
				List<String> fieldOpportunities = new ArrayList<>();
				internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
				for (Bucket opportunityBucket : opportunityBuckets) {
					fieldOpportunities.add(opportunityBucket.getKey());
				}
				//revenue = erpInvoiceService.getInvoiceAmountByOpportunityIds(fieldOpportunities, startDate, endDate);
				revenue = sum.getValue();
				if(revenue > 0){
					topProuctsList.add(constructProductObject(opportunityBuckets.size(), fieldValue, revenue, internalChildren.getDocCount()));
				}
			}
		}
		return topProuctsList;
	}
	
	public List<TopProductData> getTopProductsByOpportunities(int size, String startDate, String endDate, List<String> opportunities){
		List<TopProductData> topProuctsList = new ArrayList<TopProductData>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder
				.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_ITEM_CREATED_DATE).gte(startDate).lte(endDate));
		}
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, ""));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, "NULL"));
		if (CollectionUtils.isNotEmpty(opportunities)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));

		}
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_ITEM_AMOUNT);

		TermsBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);

		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.INDUSTRY_AGGREGATION)
				.field(ERPConstants.PRODUCT_LEVEL_THREE_RAW).subAggregation(parentSumBuilder)
				.size(size).subAggregation(opportunityAggregation)
				.order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);

		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		Sum sum = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.INDUSTRY_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if (StringUtils.isNotBlank(termBucket.getKey())) {
				sum = termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				revenue = sum.getValue();
				if (revenue > 0) {
					Terms opportunityTerms = termBucket.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
					Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
					topProuctsList.add(constructProductObject(opportunityBuckets.size(), termBucket.getKey(), revenue,
							termBucket.getDocCount()));
				}
			}
		}
		return topProuctsList;
	}
	
	
	public List<TopProductData> getTopProductsByOpportunitiesByMonth(int size, String startDate, String endDate, List<String> opportunities){
		List<TopProductData> topProuctsList = new ArrayList<TopProductData>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder
		.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_ITEM_CREATED_DATE).gte(startDate).lte(endDate));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, ""));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, "NULL"));
		if (CollectionUtils.isNotEmpty(opportunities)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));
			
		}
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_ITEM_AMOUNT);
		
		TermsBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.INDUSTRY_AGGREGATION)
				.field(ERPConstants.PRODUCT_LEVEL_THREE_RAW).subAggregation(parentSumBuilder)
				.size(size).subAggregation(opportunityAggregation)
				.order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		Sum sum = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.INDUSTRY_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if (StringUtils.isNotBlank(termBucket.getKey())) {
				sum = termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				revenue = sum.getValue();
				if (revenue > 0) {
					Terms opportunityTerms = termBucket.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
					Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
					topProuctsList.add(constructProductObject(opportunityBuckets.size(), termBucket.getKey(), revenue,
							termBucket.getDocCount()));
				}
			}
		}
		return topProuctsList;
	}
}
