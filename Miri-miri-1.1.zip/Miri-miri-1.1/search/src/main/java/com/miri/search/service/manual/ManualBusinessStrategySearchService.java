package com.miri.search.service.manual;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.base.ElasticsearchConfig;
import com.miri.cis.entity.ManualBusinessStrategy;
import com.miri.cis.entity.ManualRevenueTarget;
import com.miri.cis.entity.MonthlyTarget;
import com.miri.data.jpa.domain.BusinessStrategyConfigurations;
import com.miri.data.jpa.repository.accountSetup.AccountSetupRepository;
import com.miri.data.jpa.repository.businessStrategy.BusinessStrategyConfigurationRepository;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.BusinessStrategySetup;
import com.miri.search.data.FiscalDatesData;
import com.miri.search.data.MultipleAxesChartData;
import com.miri.search.data.RevenueTarget;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.MiriNumberUtils;
import com.miri.search.utils.TimerUtil;

/**
 * Services pertaining to manual/business_strategy document in elastic search
 * @author noor
 *
 */

@Component
public class ManualBusinessStrategySearchService extends MiriSearchService{

	private static final Logger LOG = LogManager.getLogger(ManualBusinessStrategySearchService.class);

	@Autowired
	private ElasticsearchConfig elasticsearchConfig;

	@Autowired
	ManualAccountStrategyService manualAccountStrategyService;

	@Autowired
	TimerUtil timerUtil;

	@Autowired
	BusinessStrategyConfigurationRepository businessStrategyConfigurationRepository;

	@Autowired
	AccountSetupRepository accountSetupRepository;

	/**
	 * Returns the sum of business revenue target for every month in the fiscal year
	 * index: Manual Document: business_strategy
	 * @param startDate
	 * @param endDate
	 * @return Map<Integer,RevenuePojo>
	 * Integer: Month
	 * RevenuePojo: revenue generated for that month
	 */
	public  Map<Integer,MultipleAxesChartData> getFiscalBusinessRevenueTargetByMonth(Calendar startDate,Calendar endDate){
		return getRevenueByMonth(startDate,endDate,SearchConstants.BUSINESS_REVENUE_TARGET);
	}


	/**
	 * Returns the sum of business revenue target for every month in the fiscal year
	 * index: Manual Document: business_strategy
	 * @param startDate
	 * @param endDate
	 * @return Map<Integer,RevenuePojo>
	 * Integer: Month
	 * RevenuePojo: revenue generated for that month
	 */
	public  Map<Integer,MultipleAxesChartData> getMonthlyBusinessRevenueTargetByMonth(Calendar startDate,Calendar endDate){
		return getRevenueByMonth(startDate,endDate,SearchConstants.MONTHLY_BUSINESS_REVENUE_TARGET);
	}

	/**
	 * Returns the sum of Marketing Influenced revenue target for every month in the fiscal year
	 * index: Manual Document: business_strategy
	 * @param startDate
	 * @param endDate
	 * @return Map<Integer,RevenuePojo>
	 * Integer: Month
	 * RevenuePojo: revenue generated for that month
	 */
	public  Map<Integer,MultipleAxesChartData>  getFiscalMarketingRevenueTargetByMonth(Calendar startDate,Calendar endDate){
		LOG.info("startDate"+startDate+"endDate"+endDate);
		return getRevenueByMonth(startDate,endDate,SearchConstants.MI_REVENUE_TARGET);
	}

	/**
	 * Returns the sum of Marketing Influenced revenue target for every month in the fiscal year
	 * index: Manual Document: business_strategy
	 * @param startDate
	 * @param endDate
	 * @return Map<Integer,RevenuePojo>
	 * Integer: Month
	 * RevenuePojo: revenue generated for that month
	 */
	public  Map<Integer,MultipleAxesChartData>  getMonthlyMarketingRevenueTargetByMonth(Calendar startDate,Calendar endDate){
		return getRevenueByMonth(startDate,endDate,SearchConstants.MONTHLY_MI_REVENUE_TARGET);
	}


	/**
	 * Returns the sum of Marketing Influenced revenue target for every month in the fiscal year
	 * index: Manual Document: business_strategy
	 * @param startDate
	 * @param endDate
	 * @return Map<Integer,RevenuePojo>
	 * Integer: Month
	 * RevenuePojo: revenue generated for that month
	 */
	public  Map<Integer,MultipleAxesChartData>  getRevenueByMonth(Calendar startDate,Calendar endDate,String targetToFetch){
	   
		Map<Integer,String> monthAndYearMap=MiriDateUtils.getMonthsBetweenDates(startDate, endDate);
	    List<String> monthValues=new  LinkedList<>( monthAndYearMap.values());
	    
	    FiscalDatesData fiscalDates=manualAccountStrategyService.get1YearDates();
	    Map<Integer,String> fiscalMonths=MiriDateUtils.getMonthsBetweenDates(fiscalDates.getFiscalStartDate(), fiscalDates.getFiscalEndDate());

		Map<Integer, MultipleAxesChartData> marketingInfluencedRevenueTarget = new LinkedHashMap<>();
		MultipleAxesChartData revenuePojo=null;

		SearchResponse getResponse = this.elasticsearchConfig.getTransportClient()
				.prepareSearch(ElasticSearchEnums.MANUAL.getText())
				.setTypes(ElasticSearchEnums.BUSINESS_STRATEGY.getText())
				.setSize(1)
				.addSort(SearchConstants.LAST_MODIFIED_DATE, SortOrder.DESC).get();

		SearchHits searchHits = getResponse.getHits();

		int monthIndex=0;
		
		for(SearchHit hit: searchHits) {
			List<Object> mirts = (List<Object>) hit.getSource().get(targetToFetch);
			for(int i=0;i<=(monthValues.size())-1;i++){
				String monthValue=monthValues.get(i).substring(0,3);
				for (Iterator iterator = mirts.iterator(); iterator.hasNext();) {
					Map<String, Object> eachMonthObject = (Map<String, Object>) iterator.next();
					String monthVal=(String)eachMonthObject.get("month");
					if(StringUtils.equalsIgnoreCase(monthValue,monthVal)){
						if(!fiscalMonths.containsValue(monthValues.get(i))){
							revenuePojo=new MultipleAxesChartData();
							revenuePojo.setxAxis(monthIndex);
							revenuePojo.setRevenueAmount(0d);
							monthIndex++;
						}else{
								revenuePojo=new MultipleAxesChartData();
								revenuePojo.setxAxis(monthIndex);
								revenuePojo.setRevenueAmount(new  Double(eachMonthObject.get("value").toString()));
								monthIndex++;
						}
					}
				}
				marketingInfluencedRevenueTarget.put(monthIndex,revenuePojo);
			}
		}
		return marketingInfluencedRevenueTarget;
	}


	public  Map<Integer,MultipleAxesChartData>  getSGTargetByMonth(Calendar startDate,Calendar endDate,String targetToFetch){
		Map<Integer,String> monthAndYearMap=MiriDateUtils.getMonthsBetweenDates(startDate, endDate);
	    List<String> monthValues=new  LinkedList<>( monthAndYearMap.values());
	    
	    FiscalDatesData fiscalDates=manualAccountStrategyService.get1YearDates();
	    Map<Integer,String> fiscalMonths=MiriDateUtils.getMonthsBetweenDates(fiscalDates.getFiscalStartDate(), fiscalDates.getFiscalEndDate());
		Map<Integer, MultipleAxesChartData> sgRevenueTarget = new LinkedHashMap<>();
		MultipleAxesChartData revenuePojo=null;
		int monthIndex=0;
		BigDecimal overAllValue=null;
		BigDecimal miValue=null;

		SearchResponse getResponse = this.elasticsearchConfig.getTransportClient()
				.prepareSearch(ElasticSearchEnums.MANUAL.getText())
				.setTypes(ElasticSearchEnums.BUSINESS_STRATEGY.getText())
				.setSize(1)
				.addSort(SearchConstants.LAST_MODIFIED_DATE, SortOrder.DESC).get();

		SearchHits searchHits = getResponse.getHits();

		List<Object>  miTargets=new ArrayList<>();
		List<Object> businessTargets=new  ArrayList<>();
		Map<String, Object> miTarget=new HashMap<>();
		Map<String, Object> businessTarget=new HashMap<>();

		for(SearchHit hit: searchHits) {
			if(StringUtils.equalsIgnoreCase(targetToFetch,"fiscal")){
				 miTargets= (List<Object>) hit.getSource().get(SearchConstants.MI_REVENUE_TARGET);
				businessTargets= (List<Object>) hit.getSource().get(SearchConstants.BUSINESS_REVENUE_TARGET);
			}else{

				 miTargets= (List<Object>) hit.getSource().get(SearchConstants.MONTHLY_MI_REVENUE_TARGET);
				 businessTargets= (List<Object>) hit.getSource().get(SearchConstants.MONTHLY_BUSINESS_REVENUE_TARGET);
			}
			for(int i=0;i<=(monthValues.size())-1;i++){
				String monthValue=monthValues.get(i).substring(0,3);
				for (Iterator iterator = miTargets.iterator(); iterator.hasNext();) {
					miTarget = (Map<String, Object>) iterator.next();
					int month=(int)miTarget.get("id");
					String monthVal=(String)miTarget.get("month");
					businessTarget = (Map<String, Object>)businessTargets.get(month);
					if(StringUtils.equalsIgnoreCase(monthValue,monthVal)){
						if(!fiscalMonths.containsValue(monthValues.get(i))){
							revenuePojo=new MultipleAxesChartData();
							revenuePojo.setxAxis(monthIndex);
							revenuePojo.setRevenueAmount(0d);
							monthIndex++;

						}else{
							miValue=MiriNumberUtils.createBigInteger(miTarget.get("value"));
							overAllValue=MiriNumberUtils.createBigInteger(businessTarget.get("value"));
							revenuePojo=new MultipleAxesChartData();
							revenuePojo.setxAxis(monthIndex);
							revenuePojo.setRevenueAmount(overAllValue.subtract(miValue).doubleValue());
							sgRevenueTarget.put(month,revenuePojo);
							monthIndex++;
						}
					}
				}
			}
		}
		return sgRevenueTarget;
	}


	/**
	 * Get Marketing Influenced Revenue Target for the date range
	 * @param startDate
	 * @param endDate
	 * @author rammoole
	 */
	@SuppressWarnings("unchecked")
	public Map<Integer, Double> getMarketingInfluencedRevenueTargetByMonth() {

		timerUtil.start();

		SearchResponse getResponse = this.elasticsearchConfig.getTransportClient()
				.prepareSearch(ElasticSearchEnums.MANUAL.getText())
				.setTypes(ElasticSearchEnums.BUSINESS_STRATEGY.getText())
				.setSize(1)
				.addSort(SearchConstants.LAST_MODIFIED_DATE, SortOrder.DESC).get();
		SearchHits searchHits = getResponse.getHits();
		Map<Integer, Double> marketingInfluencedRevenueTarget = new LinkedHashMap<>();
		for(SearchHit hit: searchHits) {
			List<Object> mirts = (List<Object>) hit.getSource().get(SearchConstants.MARKETING_INFLUENCED_REVENUE_TARGET);
			Map<String, Object> eachMonthObject;
			for(Object map: mirts) {
				eachMonthObject = (Map<String, Object>) map;
				marketingInfluencedRevenueTarget.put((int) eachMonthObject.get(SearchConstants.MIRT_ID),
						new  Double(eachMonthObject.get("value").toString()));
			}
		}
		timerUtil.end();
		LOG.debug("ES Time getMarketingInfluencedRevenueTargetByMonth ES"+timerUtil.timeTakenInMillis());
		return marketingInfluencedRevenueTarget;
		// This will give all the targets of the Marketing Influenced Revenue target
	}

	/**
	 *
	 * @param businessStrategySetup
	 * @return
	 */
	@Transactional
/*	public boolean saveBusinessStrategyDetails(BusinessStrategySetup businessStrategySetup) {
		LOG.info("enter into the saveBusinessStrategyDetails service" + businessStrategySetup.getBusRevTargets());
		boolean isSuccess = false;
		try {
			// back up
			List<BusinessStrategyConfigurations> allconfigs = businessStrategyConfigurationRepository.findAll();

			Client client = getTransportClient();

			BusinessStrategyConfigurations businessStrategyConfigurations = null;
			List<BusinessStrategyConfigurations> businessRevenueList = new ArrayList<BusinessStrategyConfigurations>();
			List<BusinessStrategyConfigurations> miRevenueList = new ArrayList<BusinessStrategyConfigurations>();
			List<MonthlyTarget> businessRevenueTarget = new ArrayList<MonthlyTarget>();
			List<MonthlyTarget> monthlyBusinessRevenueTarget = new ArrayList<MonthlyTarget>();
			List<MonthlyTarget> quaterlyBusinessRevenuetarget = new ArrayList<MonthlyTarget>();
			List<MarketingInfluencedRevenueTarget> marketingInfluencedRevenueTarget = new ArrayList<MarketingInfluencedRevenueTarget>();
			List<MarketingInfluencedRevenueTarget> monthlymarketingInfluencedRevenueTarget = new ArrayList<MarketingInfluencedRevenueTarget>();
			List<MarketingInfluencedRevenueTarget> quaterlyMarketingInfluencedRevenueTarget = new ArrayList<MarketingInfluencedRevenueTarget>();

			MonthlyTarget quaterlyTarget = null;
			MonthlyTarget yearlyTarget = null;
			for (RevenueTarget revenueTarget : businessStrategySetup.getBusRevTargets()) {
				for (MonthlyTarget monthlyTarget : revenueTarget.getMonthlyTarget()) {
					quaterlyTarget = new MonthlyTarget();
					yearlyTarget = new MonthlyTarget();
					String monthName = monthlyTarget.getMonth().substring(0, 3);
					businessStrategyConfigurations = new BusinessStrategyConfigurations();
					businessStrategyConfigurations.setRevenueName(SearchConstants.BUSINESS_REVENUE_TARGET);
					// businessStrategyConfigurations.setGlobalBusinessStrategy(globalBusinessStrategy);
					businessStrategyConfigurations.setMonthName(monthName);
					businessStrategyConfigurations.setMonthlyTarget(monthlyTarget.getValue().doubleValue());
					businessStrategyConfigurations.setQuaterlyTarget(revenueTarget.getQuarterTarget());
					businessStrategyConfigurations.setYearlyTarget(businessStrategySetup.getBusinessRevenueTarget());
					businessStrategyConfigurations.setDraft(businessStrategySetup.isDraft());
					businessRevenueList.add(businessStrategyConfigurations);
					quaterlyTarget.setMonth(monthName);
					quaterlyTarget.setValue(revenueTarget.getQuarterTarget().doubleValue());
					yearlyTarget.setMonth(monthName);
					yearlyTarget.setValue(businessStrategySetup.getBusinessRevenueTarget());
					// add to list
					int monthId = ArrayUtils.indexOf(MiriDateUtils.MONTH_NAMES, monthName);
					monthlyTarget.setId(monthId);
					monthlyTarget.setMonth(monthName);
					quaterlyTarget.setId(monthId);
					yearlyTarget.setId(monthId);
					monthlyBusinessRevenueTarget.add(monthlyTarget);
					quaterlyBusinessRevenuetarget.add(quaterlyTarget);
					businessRevenueTarget.add(yearlyTarget);
				}
			}

			MarketingInfluencedRevenueTarget monthlyMITarget = null;
			MarketingInfluencedRevenueTarget quaterlyMITarget = null;
			MarketingInfluencedRevenueTarget yearlyMITarget = null;
			for (RevenueTarget revenueTarget : businessStrategySetup.getMirTarget()) {
				for (MonthlyTarget monthlyTarget : revenueTarget.getMonthlyTarget()) {
					monthlyMITarget = new MarketingInfluencedRevenueTarget();
					quaterlyMITarget = new MarketingInfluencedRevenueTarget();
					yearlyMITarget = new MarketingInfluencedRevenueTarget();
					String monthName = monthlyTarget.getMonth().substring(0, 3);
					businessStrategyConfigurations = new BusinessStrategyConfigurations();
					businessStrategyConfigurations.setRevenueName(SearchConstants.MI_REVENUE_TARGET);
					businessStrategyConfigurations.setMonthName(monthName);
					businessStrategyConfigurations.setMonthlyTarget(monthlyTarget.getValue().doubleValue());
					businessStrategyConfigurations.setQuaterlyTarget(revenueTarget.getQuarterTarget());
					businessStrategyConfigurations.setYearlyTarget(businessStrategySetup.getMarketingInflRevTarget());
					businessStrategyConfigurations.setDraft(businessStrategySetup.isDraft());
					miRevenueList.add(businessStrategyConfigurations);
					int monthId = ArrayUtils.indexOf(MiriDateUtils.MONTH_NAMES, monthName);
					monthlyMITarget.setMonth(monthName);
					monthlyMITarget.setId(monthId);
					quaterlyMITarget.setId(monthId);
					monthlyMITarget.setValue(monthlyTarget.getValue().doubleValue());
					quaterlyMITarget.setMonth(monthName);
					quaterlyMITarget.setValue(revenueTarget.getQuarterTarget());
					yearlyMITarget.setId(monthId);
					yearlyMITarget.setMonth(monthName);
					yearlyMITarget.setValue(businessStrategySetup.getMarketingInflRevTarget());
					monthlymarketingInfluencedRevenueTarget.add(monthlyMITarget);
					quaterlyMarketingInfluencedRevenueTarget.add(quaterlyMITarget);
					marketingInfluencedRevenueTarget.add(yearlyMITarget);
				}
			}

			ManualBusinessStrategy mbs = new ManualBusinessStrategy();
			mbs.setBusinessRevenueTarget(businessRevenueTarget);
			mbs.setMonthlyBusinessRevenueTarget(monthlyBusinessRevenueTarget);
			mbs.setQuaterlyBusinessRevenuetarget(quaterlyBusinessRevenuetarget);
			mbs.setMarketingInfluencedRevenueTarget(marketingInfluencedRevenueTarget);
			mbs.setMonthlymarketingInfluencedRevenueTarget(monthlymarketingInfluencedRevenueTarget);
			mbs.setQuaterlyMarketingInfluencedRevenueTarget(quaterlyMarketingInfluencedRevenueTarget);
			mbs.setCreatedDate(DateUtilities.dateToString(new Date()));
			mbs.setLastModifiedDate(DateUtilities.dateToString(new Date()));
			mbs.setVendorName(SearchConstants.BUSINESS_STRATEGY);
			mbs.setVendorType(SearchConstants.MANUAL);
			mbs.setDraft(businessStrategySetup.isDraft());
			mbs.setBusinessStrategyDocumentRefId("1");
			// save to DB
			businessStrategyConfigurationRepository.save(businessRevenueList);
			businessStrategyConfigurationRepository.save(miRevenueList);

			// delete existing data
			businessStrategyConfigurationRepository.delete(allconfigs);

			SearchHit[] hitsArr = getLatestBusinessStrategyDocument();
			String identifier = null;

			if (!ArrayUtils.isEmpty(hitsArr)) {
				SearchHit searchHit = hitsArr[0];
				identifier = searchHit.getId();
				mbs.setCreatedDate((String)searchHit.getSource().get(SearchConstants.CREATED_DATE));
				mbs.setBusinessStrategyDocumentRefId(identifier);
			}

			ObjectMapper mapper = new ObjectMapper();
			String mitJson;
			mitJson = mapper.writeValueAsString(mbs);

			IndexResponse response = client
					.prepareIndex(SearchConstants.MANUAL, SearchConstants.BUSINESS_STRATEGY, identifier)
					.setSource(mitJson).execute().actionGet();

			LOG.debug("response:: " + response);

			isSuccess = true;
			LOG.debug("businessStrategyConfigurationRepository::>>" + businessStrategyConfigurationRepository.count());
		} catch (Exception e) {
			LOG.error("Exception in saveBusinessStrategyDetails" + e.toString());
		}

		return isSuccess;
	}*/


	public ManualBusinessStrategy getLatestBusinessStrategy() {
		ManualBusinessStrategy mbs = new ManualBusinessStrategy();
		Client client = getTransportClient();

		SearchResponse getResponse = client.prepareSearch(SearchConstants.MANUAL)
				.setTypes(SearchConstants.BUSINESS_STRATEGY).setSize(1)
				.addSort(SearchConstants.LAST_MODIFIED_DATE, SortOrder.DESC).get();

		SearchHits hits = getResponse.getHits();
		SearchHit[] hitsArr = hits.getHits();
		if (!ArrayUtils.isEmpty(hitsArr)) {
			SearchHit searchHit = hitsArr[0];
			String identifier = searchHit.getId();
			mbs=(ManualBusinessStrategy)ESObjectMapper.getObject(searchHit.getSource(),getDocumentType(), getIndex());
			mbs.setCreatedDate((String)searchHit.getSource().get(SearchConstants.CREATED_DATE));
			mbs.setBusinessStrategyDocumentRefId(identifier);
		}

		return mbs;
	}


	public void indexBusinessStrategy(ManualBusinessStrategy mbs) throws IOException {
		Client client = getTransportClient();

		ObjectMapper mapper = new ObjectMapper();
		String mitJson;
		mitJson = mapper.writeValueAsString(mbs);

		IndexResponse response = client
				.prepareIndex(SearchConstants.MANUAL, SearchConstants.BUSINESS_STRATEGY, mbs.getDocumentRefId())
				.setSource(mitJson).execute().actionGet();

		LOG.debug("response:: " + response);
	}

	public BusinessStrategySetup getBusinessStrategyDetails() {
		LOG.debug("Enter into getBusinessStrategyDetails");
		Map<String, Object> businessDetails = null;
		BusinessStrategySetup businessStrategySetup = new BusinessStrategySetup();
		try {

			SearchResponse response = getTransportClient().prepareSearch(SearchConstants.MANUAL)
					.setTypes(SearchConstants.BUSINESS_STRATEGY).setSize(1)
					.addSort(SearchConstants.LAST_MODIFIED_DATE, SortOrder.DESC).get();
			SearchHits hits = response.getHits();
			SearchHit[] hitsArr = hits.getHits();

			String fiscalDate = manualAccountStrategyService.getFiscalStartDateStr();

			businessStrategySetup.setFiscalStartDate(fiscalDate);
			Date currentDate = new Date();
			final String currentMonth = MiriDateUtils.getMonthAsString(currentDate);
			if (ArrayUtils.isNotEmpty(hitsArr)) {
				businessDetails = hits.getAt(0).getSource();

				// yearly of revenue
				List<?> businessRevenueTarget = (List<?>) businessDetails.get("businessRevenueTarget");
				Map<String, Object> yearlyTarget = getTargetValueForMonth(currentMonth, businessRevenueTarget);
				if (yearlyTarget != null) {
					businessStrategySetup.setBusinessRevenueTarget(getDouble((Number) yearlyTarget.get("value")));
				}

				// yearly of MI revenue
				List<?> marketingInfluencedRevenueTarget = (List<?>) businessDetails
						.get("marketingInfluencedRevenueTarget");
				Map<String, Object> miYearlyTarget = getTargetValueForMonth(currentMonth, marketingInfluencedRevenueTarget);
				if (miYearlyTarget != null) {
					businessStrategySetup.setMarketingInflRevTarget(getDouble((Number) miYearlyTarget.get("value")));
				}

				List<?> monthlyBusinessRevenueTarget = (List<?>) businessDetails.get("monthlyBusinessRevenueTarget");

				List<?> quaterlyBusinessRevenuetarget = (List<?>) businessDetails.get("quaterlyBusinessRevenuetarget");

				List<RevenueTarget> quaterlytarget = getESTargetList(quaterlyBusinessRevenuetarget,
						monthlyBusinessRevenueTarget);

				LOG.info("values from ES for revenue::>>" + quaterlytarget.size());
				businessStrategySetup.setBusRevTargets(quaterlytarget);

				List<?> monthlymarketingInfluencedRevenueTarget = (List<?>) businessDetails
						.get("monthlymarketingInfluencedRevenueTarget");

				List<?> quaterlyMarketingInfluencedRevenueTarget = (List<?>) businessDetails
						.get("quaterlyMarketingInfluencedRevenueTarget");

				List<RevenueTarget> quaterlyMItarget = getESTargetList(quaterlyMarketingInfluencedRevenueTarget,
						monthlymarketingInfluencedRevenueTarget);
				LOG.info("values from ES for MI revenue::>>" + quaterlyMItarget.size());
				businessStrategySetup.setMirTarget(quaterlyMItarget);

				businessStrategySetup.setDraft(Boolean.valueOf(String.valueOf(businessDetails.get("quaterlyBusinessRevenuetarget"))));

			} else {
				List<BusinessStrategyConfigurations> revenueList = businessStrategyConfigurationRepository
						.findAllByRevenueName(SearchConstants.BUSINESS_REVENUE_TARGET);
				BooleanHolder booleanHolder = new BooleanHolder();
				if (CollectionUtils.isNotEmpty(revenueList)) {
					for(BusinessStrategyConfigurations businessStrategyConfigurations :revenueList){
						if(businessStrategyConfigurations.getMonthName().equals(currentMonth)){
							businessStrategySetup.setBusinessRevenueTarget(businessStrategyConfigurations.getYearlyTarget());
							break;
						}
					}
					List<RevenueTarget> quaterlyTarget = getDBTargetList(revenueList, booleanHolder);
					LOG.info("values from DB forrevenue::>>" + quaterlyTarget.size());
					businessStrategySetup.setBusRevTargets(quaterlyTarget);
				}

				List<BusinessStrategyConfigurations> miRevenueList = businessStrategyConfigurationRepository
						.findAllByRevenueName(SearchConstants.MI_REVENUE_TARGET);
				if (CollectionUtils.isNotEmpty(miRevenueList)) {
					for(BusinessStrategyConfigurations businessStrategyConfigurations:miRevenueList){
						if(businessStrategyConfigurations.getMonthName().equals(currentMonth)){
							businessStrategySetup.setMarketingInflRevTarget(businessStrategyConfigurations.getYearlyTarget());
							break;
						}
					}

					List<RevenueTarget> quaterlyMITarget = getDBTargetList(miRevenueList, booleanHolder);
					LOG.info("values from DB for MI revenue" + quaterlyMITarget.size());
					businessStrategySetup.setMirTarget(quaterlyMITarget);
				}
				businessStrategySetup.setDraft(booleanHolder.getValue());
			}

			LOG.debug("businessStrategySetup:>>" + businessStrategySetup);

		} catch (Exception e) {
			LOG.error("Exception in getBusinessStrategyDetails" + e.toString(), e);
		}
		return businessStrategySetup;
	}


	@SuppressWarnings("unchecked")
	private Map<String, Object> getTargetValueForMonth(String currentMonth, List<?> targetMapList) {
		Map<String, Object> target = null;

		for (Object object : targetMapList) {
			target = (Map<String, Object>) object;
			String targetMonth = (String) target.get("month");
			if (StringUtils.equals(currentMonth, targetMonth)) {
				break;
			}
		}
		return target;
	}

	private Double getDouble(Number number) {
		return number != null ? number.doubleValue() : null;
	}

	private List<RevenueTarget> getDBTargetList(List<BusinessStrategyConfigurations> inputList, BooleanHolder booleanHolder) {
		List<RevenueTarget> outputList = new ArrayList<RevenueTarget>();

		int k = 1;
		for (int i = 0; i < inputList.size(); i += 3) {
			BusinessStrategyConfigurations bs1 = inputList.get(i);
			BusinessStrategyConfigurations bs2 = inputList.get(i + 1);
			BusinessStrategyConfigurations bs3 = inputList.get(i + 2);
			RevenueTarget rt = new RevenueTarget();
			List<MonthlyTarget> mtList = new ArrayList<MonthlyTarget>();
			MonthlyTarget mt1 = new MonthlyTarget();
			mt1.setMonth(bs1.getMonthName());
			mt1.setValue(bs1.getMonthlyTarget());
			booleanHolder.updateValue(bs1.isDraft());
			MonthlyTarget mt2 = new MonthlyTarget();
			mt2.setMonth(bs2.getMonthName());
			mt2.setValue(bs2.getMonthlyTarget());
			booleanHolder.updateValue(bs1.isDraft());
			MonthlyTarget mt3 = new MonthlyTarget();
			mt3.setMonth(bs3.getMonthName());
			mt3.setValue(bs3.getMonthlyTarget());
			booleanHolder.updateValue(bs1.isDraft());
			mtList.add(mt1);
			mtList.add(mt2);
			mtList.add(mt3);
			rt.setLabel("Q" + k);
			rt.setMonthlyTarget(mtList);
			rt.setQuarterTarget(bs1.getQuaterlyTarget());
			outputList.add(rt);
			k++;
		}
		return outputList;
	}

	private List<RevenueTarget> getESTargetList(List quaterlyBusinessRevenuetarget, List monthlyBusinessRevenueTarget) {

		List<RevenueTarget> outputList = new ArrayList<RevenueTarget>();
		int j = 1;
		for (int i = 0; i < monthlyBusinessRevenueTarget.size(); i += 3) {
			List<MonthlyTarget> monthlyTarget = new ArrayList<MonthlyTarget>();
			RevenueTarget rt = new RevenueTarget();
			Map<String, Object> quater = (Map<String, Object>) quaterlyBusinessRevenuetarget.get(i);
			Map<String, Object> tempMonth1 = (Map<String, Object>) monthlyBusinessRevenueTarget.get(i);
			MonthlyTarget m1 = new MonthlyTarget();
			m1.setMonth((String) tempMonth1.get(SearchConstants.MONTH));
			m1.setValue((Number) tempMonth1.get(SearchConstants.VALUE));
			monthlyTarget.add(m1);
			Map<String, Object> tempMonth2 = (Map<String, Object>) monthlyBusinessRevenueTarget.get(i + 1);
			MonthlyTarget m2 = new MonthlyTarget();
			m2.setMonth((String) tempMonth2.get(SearchConstants.MONTH));
			m2.setValue((Number) tempMonth2.get(SearchConstants.VALUE));
			monthlyTarget.add(m2);
			Map<String, Object> tempMonth3 = (Map<String, Object>) monthlyBusinessRevenueTarget.get(i + 2);
			MonthlyTarget m3 = new MonthlyTarget();
			m3.setMonth((String) tempMonth3.get(SearchConstants.MONTH));
			m3.setValue((Number) tempMonth3.get(SearchConstants.VALUE));
			monthlyTarget.add(m3);
			rt.setLabel("Q" + j);
			rt.setQuarterTarget(getDouble((Number) quater.get(SearchConstants.VALUE)));
			rt.setMonthlyTarget(monthlyTarget);
			outputList.add(rt);
			j++;
		}

		return outputList;
	}


	public ManualRevenueTarget getManualFiscalRevenueTargets(){
		ManualBusinessStrategy mbs=new ManualBusinessStrategy();
		ManualRevenueTarget manualRevenueTarget=new ManualRevenueTarget();
		double overallRevenueTarget=0;
		double miRevenueTarget=0;

		SearchResponse getResponse = this.elasticsearchConfig.getTransportClient()
				.prepareSearch(ElasticSearchEnums.MANUAL.getText())
				.setTypes(ElasticSearchEnums.BUSINESS_STRATEGY.getText())
				.setSize(1)
				.addSort(SearchConstants.LAST_MODIFIED_DATE, SortOrder.DESC).get();

		SearchHits searchHits = getResponse.getHits();
		SearchHit[] hitsArr = searchHits.getHits();
		if (!ArrayUtils.isEmpty(hitsArr)) {
			SearchHit hit=searchHits.getAt(0);
			manualRevenueTarget.setCreatedDate((String)hit.getSource().get(SearchConstants.CREATED_DATE));
			mbs=(ManualBusinessStrategy)ESObjectMapper.getObject(hit.getSource(),getDocumentType(), getIndex());
			List<Object> overAllTargets = (List<Object>) hit.getSource().get(SearchConstants.BUSINESS_REVENUE_TARGET);
			List<Object>  miTargets= (List<Object>) hit.getSource().get(SearchConstants.MARKETING_INFLUENCED_REVENUE_TARGET);

			for (Iterator iterator = overAllTargets.iterator(); iterator.hasNext();) {
				Map<String, Object> eachMonthObject = (Map<String, Object>) iterator.next();
				overallRevenueTarget+=new  Double(eachMonthObject.get(SearchConstants.VALUE).toString());
			}

			for (Iterator iterator = miTargets.iterator(); iterator.hasNext();) {
				Map<String, Object> eachMonthObject = (Map<String, Object>) iterator.next();
				miRevenueTarget+= new  Double(eachMonthObject.get(SearchConstants.VALUE).toString());
			}
		}

		manualRevenueTarget.setBusinessRevenueTarget(overallRevenueTarget);
		manualRevenueTarget.setMarketingInfluencedTarget(miRevenueTarget);
		manualRevenueTarget.setInstanceName(mbs.getInstanceName());
		manualRevenueTarget.setVendorName(mbs.getVendorName());
		manualRevenueTarget.setVendorType(mbs.getVendorType());

		return manualRevenueTarget;
	}

    @Override
    public String getIndex() {
        return ElasticSearchEnums.MANUAL.getText();
    }

    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.BUSINESS_STRATEGY.getText();
    }

    private static final class BooleanHolder {
    	private boolean value;

		public boolean getValue() {
			return value;
		}

		public void updateValue(boolean value) {
			this.value = this.value || value;
		}
    }
}