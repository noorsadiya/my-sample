package com.miri.search.data;

import java.io.Serializable;
import java.util.Calendar;

import com.miri.search.utils.MiriDateUtils;

/**
 * Fiscal Dates Calendar Object
 * 
 * @author rammoole
 *
 */
public class FiscalDatesData implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -542520226244614715L;

	private Calendar fiscalStartDate;
	private Calendar fiscalEndDate;

	/**
	 * @return the fiscalStartDate
	 */
	public Calendar getFiscalStartDate() {
		return fiscalStartDate;
	}

	/**
	 * @param fiscalStartDate
	 *            the fiscalStartDate to set
	 */
	public void setFiscalStartDate(Calendar fiscalStartDate) {
		this.fiscalStartDate = fiscalStartDate;
	}

	/**
	 * @return the fiscalEndDate
	 */
	public Calendar getFiscalEndDate() {
		return fiscalEndDate;
	}

	/**
	 * @param fiscalEndDate
	 *            the fiscalEndDate to set
	 */
	public void setFiscalEndDate(Calendar fiscalEndDate) {
		this.fiscalEndDate = fiscalEndDate;
	}

	/**
	 * @return the fiscalStartDate
	 */
	public String getFiscalStartDateStr() {
		return MiriDateUtils.parseDateToString(fiscalStartDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
	}

	/**
	 * @return the fiscalEndDate
	 */
	public String getFiscalEndDateStr() {
		return MiriDateUtils.parseDateToString(fiscalEndDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
	}

}