package com.miri.search.service.manual;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.sort.SortOrder;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.utilities.DateUtilities;
import com.miri.data.jpa.domain.WebServiceVendor;
import com.miri.data.jpa.domain.WebServiceVendorConfiguration;
import com.miri.data.jpa.repository.datasourceSetup.WebServiceVendorConfigurationRepository;
import com.miri.data.jpa.repository.datasourceSetup.WebServiceVendorRepository;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.DatasourceSetup;
import com.miri.search.service.common.MiriSearchService;

/**
 * @author supraja
 *
 */
@Component
public class ManualDatasourceSetupService extends MiriSearchService {

	private static final Logger LOG = Logger.getLogger(ManualDatasourceSetupService.class);

	@Autowired
	WebServiceVendorRepository webServiceVendorRepository;

	@Autowired
	WebServiceVendorConfigurationRepository webServiceVendorConfigurationRepository;

	/**
	 *
	 * @param datasourceMap
	 * @return
	 */
	@Transactional
	public boolean saveDatasourceSetup(Map<String, List<DatasourceSetup>> datasourceMap) {
		LOG.info("Enter into saveDatasourceSetup" + datasourceMap);
		boolean isSuccess = false;
		try {
			WebServiceVendor webServiceVendor = null;
			// Delete all
			webServiceVendorRepository.deleteAllInBatch();
			webServiceVendorConfigurationRepository.deleteAll();

			List<WebServiceVendorConfiguration> webConfigs = null;
			WebServiceVendorConfiguration webServiceVendorConfiguration = null;
			for (Map.Entry<String, List<DatasourceSetup>> entry : datasourceMap.entrySet()) {
				String key = entry.getKey();
				if (entry.getValue() != null && entry.getValue().size() > 0) {

					for (int i = 0; i < entry.getValue().size(); i++) {
						webConfigs = new ArrayList<WebServiceVendorConfiguration>();
						DatasourceSetup datasourceSetup = entry.getValue().get(i);
						webServiceVendor = new WebServiceVendor();
						if (!StringUtils.isEmpty(datasourceSetup.getSystem())) {
							webServiceVendor.setVendorType(key);
							webServiceVendor.setStatus(true);
							webServiceVendor.setVersion("0");
							webServiceVendor.setInstanceName(datasourceSetup.getSystem() + "-" + i);
							webServiceVendor.setVendorName(datasourceSetup.getSystem());
							webServiceVendor = webServiceVendorRepository.saveAndFlush(webServiceVendor);
							LOG.info("Saved Vendor details" + webServiceVendor.getId());

							BeanInfo beanInfo = Introspector.getBeanInfo(DatasourceSetup.class);
							for (PropertyDescriptor propertyDesc : beanInfo.getPropertyDescriptors()) {
								String propertyName = propertyDesc.getName();
								Object value = propertyDesc.getReadMethod().invoke(datasourceSetup);
								if (value != null) {
									webServiceVendorConfiguration = new WebServiceVendorConfiguration();
									webServiceVendorConfiguration.setAttributeName(propertyName);
									webServiceVendorConfiguration.setAttributeValue(value.toString());
									webServiceVendorConfiguration.setWebServiceVendor(webServiceVendor);
									webConfigs.add(webServiceVendorConfiguration);
								}
							}
						}
						if (webConfigs != null && webConfigs.size() > 0) {
							webServiceVendorConfigurationRepository.save(webConfigs);
						}
					}
				}
			}
			LOG.info("datasourceMap::>>>" + datasourceMap);
			Client client = getTransportClient();
			SearchResponse getResponse = client.prepareSearch(SearchConstants.MANUAL)
					.setTypes(SearchConstants.DATASOURCE_SETUP).setSize(1).get();

			SearchHits hits = getResponse.getHits();
			SearchHit[] hitsArr = hits.getHits();
			String identifier = null;

			if (ArrayUtils.isNotEmpty(hitsArr)) {
				SearchHit searchHit = hitsArr[0];
				identifier = searchHit.getId();
			}
			JSONObject dataJson = new JSONObject(datasourceMap);

			IndexResponse response = client
					.prepareIndex(SearchConstants.MANUAL, SearchConstants.DATASOURCE_SETUP, identifier)
					.setId(DateUtilities.dateToString(new Date())).setSource(dataJson.toString()).execute()
					.actionGet();
			LOG.info("After save datasource into elastic search" + response.getId());
			isSuccess = true;

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		LOG.info("success" + isSuccess);
		return isSuccess;
	}

	/**
	 *
	 * @return
	 */
	public Map<String, Object> getDatasourceSetupDetails() {
		Map<String, Object> datasourceDetails = null;
		try {
			SearchResponse response = getTransportClient().prepareSearch(SearchConstants.MANUAL)
					.setTypes(SearchConstants.DATASOURCE_SETUP)
					.addSort("_id", SortOrder.DESC).get();

			SearchHits hits = null;
			if (response != null)
				hits = response.getHits();
			if (hits != null && hits.getTotalHits() > 0) {
				// LOG.info("Hits" + hits.getAt(0));
				datasourceDetails = hits.getAt(0).getSource();
				LOG.info("accountDetails from elastic search:::");
			}
			else {
				List<WebServiceVendor> vendorDetails = webServiceVendorRepository.findAll();// TODO need to put into object
				List<WebServiceVendorConfiguration> configs = webServiceVendorConfigurationRepository.findAll();

			}
		}
		catch (Exception e) {
			LOG.error("Error getting datasources" + e.getMessage());
			e.printStackTrace();
		}
		return datasourceDetails;
	}

	@Override
	public String getIndex() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDocumentType() {
		// TODO Auto-generated method stub
		return null;
	}
}
