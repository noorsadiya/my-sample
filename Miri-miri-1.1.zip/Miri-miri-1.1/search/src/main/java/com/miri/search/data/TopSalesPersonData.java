package com.miri.search.data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class TopSalesPersonData implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8517682621723163471L;

	private String salesPerson;
	
	private double revenueAmount;
	
	private long dealsClosed;
	
	Map<Integer, Double> monthWiseRevenue;
	
	List<String> opportunities;
	
	private double productquantity;
	
	private double opportunityCount;
	
	private double invoiceItemCount;
	
	private double ads;
	
	private double asp;
	
	public double getAsp() {
		return asp;
	}
	
	public void setAsp(double asp) {
		this.asp = asp;
	}
	
	public double getAds() {
		return ads;
	}
	
	public void setAds(double ads) {
		this.ads = ads;
	}
	
	
	public double getInvoiceItemCount() {
		return invoiceItemCount;
	}
	
	public void setInvoiceItemCount(double invoiceItemCount) {
		this.invoiceItemCount = invoiceItemCount;
	}
	
	
	public double getOpportunityCount() {
		return opportunityCount;
	}
	
	public void setOpportunityCount(double opportunityCount) {
		this.opportunityCount = opportunityCount;
	}
	
	public double getProductquantity() {
		return productquantity;
	}
	public void setProductquantity(double productquantity) {
		this.productquantity = productquantity;
	}
	
	public Map<Integer, Double> getMonthWiseRevenue() {
		return monthWiseRevenue;
	}
	
	public void setMonthWiseRevenue(Map<Integer, Double> monthWiseRevenue) {
		this.monthWiseRevenue = monthWiseRevenue;
	}
	
	public String getSalesPerson() {
		return salesPerson;
	}
	public void setSalesPerson(String salesPerson) {
		this.salesPerson = salesPerson;
	}
	
	public double getRevenueAmount() {
		return revenueAmount;
	}
	public void setRevenueAmount(double revenueAmount) {
		this.revenueAmount = revenueAmount;
	}
	
	public long getDealsClosed() {
		return dealsClosed;
	}
	
	public void setDealsClosed(long dealsClosed) {
		this.dealsClosed = dealsClosed;
	}

	public List<String> getOpportunities() {
		return opportunities;
	}

	public void setOpportunities(List<String> opportunities) {
		this.opportunities = opportunities;
	}

	@Override
	public String toString() {
		return "TopSalesPersonData [salesPerson=" + salesPerson + ", revenueAmount=" + revenueAmount
				+ ", opportunities=" + opportunities + "]";
	}
	
}
