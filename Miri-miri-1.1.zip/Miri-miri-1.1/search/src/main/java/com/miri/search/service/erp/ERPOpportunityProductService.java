package com.miri.search.service.erp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.ErpOrderItem;
import com.miri.cis.entity.ErpSalesOrder;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.OpportunityStagesEnum;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.RevenueOpportunitiesData;
import com.miri.search.data.WinLossData;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.crm.CRMOpportunityService;
import com.miri.search.service.manual.ManualAccountStrategyService;
import com.miri.search.utils.MiriDateUtils;

/**
 * ERP Opportunity Product service
 * @author rammoole
 *
 */
@Component
public class ERPOpportunityProductService extends MiriSearchService {
	
	private Logger LOG = LogManager.getLogger(ERPOpportunityProductService.class);

	@Autowired
	private CRMOpportunityService crmOpportunityService;
	
	@Autowired
	private ERPOpportunityCompetitorService erpOpportunityCompetitorService;
	
	@Autowired
	private ManualAccountStrategyService manualAccountStrategyService;
	
	@Autowired
	private ERPOrderItemService erpOrderItemService;
	
	@Autowired
	ERPSalesOrderService erpSalesOrderService;
	
	@Autowired
	ESQueryUtils esQueryUtils;
	
	
	private ConcurrentHashMap<String, Object> allProducts = new ConcurrentHashMap<>();
	
	/**
	 * Get All the products information by revenue
	 */
	public Map<String, Object> getAllProductsByRevenue() {
		String fiscalStartDate = this.manualAccountStrategyService.getFiscalStartDateStr();
		String endDate = MiriDateUtils.parseDateToString(Calendar.getInstance(), MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return this.getAllProductsByRevenueWithInTimeFrame(fiscalStartDate, endDate);
	}
	
	/**
	 * Get all the products with in the time frame
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Object> getAllProductsByRevenueWithInTimeFrame(Calendar startDate, Calendar endDate) {
		String startDateStr = MiriDateUtils.parseDateToString(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		String endDateStr = MiriDateUtils.parseDateToString(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return this.getAllProductsByRevenueWithInTimeFrame(startDateStr, endDateStr);
	}
	
	
	/**
	 * Get All the products with in the time frame
	 * @return
	 */
	public Map<String, Object> getAllProductsByRevenueWithInTimeFrame(String startDate, String endDate) {
		allProducts =  new ConcurrentHashMap<>();
		List<String> opportunityIds = this.crmOpportunityService.getOpportunityIdsByStageAndFiscalYear(
				OpportunityStagesEnum.CLOSED_WON.getText(), startDate, endDate);

		this.processOpportunitiesForProductsInBatches(opportunityIds, allProducts, startDate, endDate);
		
		return MiriSearchUtils.sortMapByObjectValue(allProducts);
	}
	
	/**
	 * Process Opportunities in batches for product information
	 * @param opportunityIds
	 * @param allProducts
	 */
	public void processOpportunitiesForProductsInBatches(List<String> opportunityIds, final Map<String, Object> allProducts, 
			final String startDate, final String endDate) {
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(!CollectionUtils.isEmpty(opportunityIds)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		}
		if(!(StringUtils.isEmpty(startDate) && StringUtils.isEmpty(endDate))) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		}
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_SALESORDER.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION).field(SearchConstants.OPPORTUNITY_ID_RAW));
		
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
						//.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_OPPORTUNITIES_AGGREGATION)
							//	.setSize(100000).setFetchSource(SearchConstants.ITEMS, null))).get();
		
		Aggregations aggregations = searchResponse.getAggregations();
		Terms opportunityTerms = null;
		if(aggregations != null){
			opportunityTerms = aggregations.get(SearchConstants.OPPORTUNITY_AGGREGATION);
		}

		if(opportunityTerms != null){

		Collection<Terms.Bucket> opportunityBuckets = opportunityTerms.getBuckets();
		
		//LOG.info(" processOpportunitiesForProductsInBatches, opportunityBuckets "+opportunityBuckets.size());
	
		ExecutorService executorService =  Executors.newFixedThreadPool(70);
		
		for(final Terms.Bucket opportunityBucket: opportunityBuckets) {
			
			//Instead of TopHits get all Item ids for each sales Order
			//TopHits salesOrderTopHits = opportunityBucket.getAggregations().get(SearchConstants.TOP_OPPORTUNITIES_AGGREGATION);
			List<ErpSalesOrder> erpSalesOrders=erpSalesOrderService.getSalesOrderByOpportunityId(opportunityBucket.getKey());
			
			//LOG.info(" processOpportunitiesForProductsInBatches, erpSalesOrders "+opportunityBucket.getKey()+":-"+erpSalesOrders.size());
		
			for (final Iterator<ErpSalesOrder> iterator = erpSalesOrders.iterator(); iterator.hasNext();) {

						ErpSalesOrder erpSalesOrder = iterator.next();
						List<String> orderItemIds=erpSalesOrder.getItems();
						
						//LOG.info(" processOpportunitiesForProductsInBatches, orderItems "+orderItemIds.size());
						
						List<ErpOrderItem> orderItems = erpOrderItemService.getItemNamesAndRevenueByItemIds(orderItemIds);
						
						for(final ErpOrderItem orderItemId: orderItems) {

							//LOG.info("product count"+orderItemId.getQuantity());
							updateProductMap(orderItemId.getItemName(), orderItemId.getTotalValue(), 
									opportunityBucket.getKey(), allProducts, startDate, endDate, orderItemId.getQuantity());

					}
					
				}
			}
		executorService.shutdown();
		//LOG.info(" executor service end ");
		try {
			if(!executorService.awaitTermination(1, TimeUnit.MINUTES))
				executorService.shutdownNow();
		}
		catch (InterruptedException e) {
			LOG.error("Interruped Exception while updating the campaigns map:" + e.getMessage());
		}
		}

	}
	
	
	
	/**
	 * Get All the products with in the time frame By Opportunities
	 * @return
	 */
	public Map<String, Object> getAllProductsByRevenueWithInTimeFrameByOpportunities(String startDate, String endDate, List<String> opportunityIds) {
		allProducts =  new ConcurrentHashMap<>();
		this.processOpportunitiesForProductsInBatches(opportunityIds, allProducts, startDate, endDate);
		return MiriSearchUtils.sortMapByObjectValue(allProducts);
	}
	
	
	/**
	 * 
	 * @param opportunityIds - List of MI or SG Opportunities
	 * @param timeFrame TODO
	 * @return - Product name as Key and list of Opportunities as value
	 */
	public Map<String, List<String>> getOpportunitiesByProduct(List<String> opportunityIds, String startDate, String endDate){
		
		LOG.info("getAllProductsByOpportunities().....");
		
		Map<String, List<String>> productAndListOfOpportunities = new HashMap<String, List<String>>();
		
		BoolQueryBuilder boolQueryBuilder = MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds, 1000);
		boolQueryBuilder.must(QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		
		TermsBuilder termBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(ERPConstants.SALES_ORDER_ITEMS_RAW).size(0);
		
		termBuilder.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_OPPORTUNITIES_AGGREGATION)
				.setFetchSource(SearchConstants.OPPORTUNITY_ID, null));

		SearchResponse searchResponse = getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
											.setTypes(ElasticSearchEnums.ERP_SALESORDER.getText())
											.setQuery(boolQueryBuilder)
											.addAggregation(termBuilder).execute().actionGet();
		

		Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> termsBuckets = terms.getBuckets();

		for (Terms.Bucket termBucket : termsBuckets) {

			String orderItemId = termBucket.getKey();
			
			if(!StringUtils.isEmpty(orderItemId)){

				String productName = erpOrderItemService.getItemNameByItemId(orderItemId);
				if(!StringUtils.isEmpty(productName)) {
					List<String> opptList = new ArrayList<String>();

					InternalTopHits topHits = termBucket.getAggregations().get(SearchConstants.TOP_OPPORTUNITIES_AGGREGATION);

					SearchHit[] hits = topHits.getHits().getHits();

					for (SearchHit hit : hits) {
						opptList.add(((String)hit.getSource().get(SearchConstants.OPPORTUNITY_ID)));
					}

					productAndListOfOpportunities.put(productName, opptList);
				}
			}
		}

		LOG.info("Opportunities by products..."+productAndListOfOpportunities);
		return productAndListOfOpportunities;
	}
	
	
	/**
	 * Competitive Win Rate Products
	 * @param productsData
	 * @return
	 */
	public List<WinLossData> getCompetitiveWinRateForProducts(List<Object> productsData) {
		return erpOpportunityCompetitorService.getWinRateForCompetitors(productsData, null, null);
	}
	
	/**
	 * Get Competitive Win rate for products
	 * @param otherProductsData
	 * @param timeFrame TODO
	 * @return
	 */
	public WinLossData getCompetitiveWinRateForOtherProducts(List<Object> otherProductsData, String timeFrame) {
		WinLossData winLossData = new WinLossData();
		List<String> opportunityIds;
		RevenueOpportunitiesData revenueOpportunitiesData;
		WinLossData winLossDataLoc;
		for(Object competitorData: otherProductsData) {
			revenueOpportunitiesData = (RevenueOpportunitiesData) competitorData;
			opportunityIds = new ArrayList<>();
			opportunityIds.addAll(revenueOpportunitiesData.getOpportunityIds());
			opportunityIds.addAll(revenueOpportunitiesData.getLostOpportunityIds());
			winLossDataLoc = this.crmOpportunityService.getCompetitiveWinRateForOpportunities(opportunityIds, 
					revenueOpportunitiesData.getLostOpportunityIds().size(), null, null);
			winLossData.setWonCount(winLossData.getWonCount() + winLossDataLoc.getWonCount());
			winLossData.setWonAmount(winLossData.getWonAmount() + winLossDataLoc.getWonAmount());
			winLossData.setLostCount(winLossData.getLostCount() + winLossDataLoc.getLostCount());
			winLossData.setLostAmount(winLossData.getLostAmount() + winLossDataLoc.getLostAmount());
		}
		return winLossData;
	}

	 /**
     * Returns all products associated with given product Id.
     */
    public List<ErpOrderItem> getERPOrderItemsByIds(final List<String> itemIds) { 
        SearchResponse searchresponse = this.getTransportClient().prepareSearch(getIndex())
        		.setTypes(getDocumentType())
        		.setSize(itemIds.size())
        		.setQuery(QueryBuilders.termsQuery("itemId", itemIds))
        		.get();
        List<ErpOrderItem> erpOrderItemList = new ArrayList<>();
        for(SearchHit hit: searchresponse.getHits()) {
        	erpOrderItemList.add((ErpOrderItem) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
        }
        return erpOrderItemList;
    }
    
    /**
     * This processes 500 entries in each batch and gets the result.
     * 
     * @return
     */
    public List<ErpOrderItem> getERPOrderItemsByIdsUsingBatch(List<String> itemIds) {
    	int batchSize = 500;
		int start = 0;
		int end = batchSize;
		int totalItems = itemIds.size() / batchSize; // this is like the number of iterations
		int remainingItems = itemIds.size() % batchSize; // This is for any remaining data after the iterations
		List<ErpOrderItem> totalErpOrderItems = new ArrayList<>();
		for(int i = 0; i < totalItems; i++) {
			totalErpOrderItems.addAll(this.getERPOrderItemsByIds(itemIds.subList(start, end)));
			start = start + batchSize;
			end = end + batchSize;
		}
		if(remainingItems != 0) {
			end = end - batchSize + remainingItems;
			totalErpOrderItems.addAll(this.getERPOrderItemsByIds(itemIds.subList(start, end)));
		}
		return totalErpOrderItems;
    }
    
    
    
    /**
	 * Updating the Product information in Map data structure
	 * @param itemName
	 * @param dealAmount
	 * @param opportunityId
	 * @param allProducts
	 */

	private void updateProductMap(final String itemName, final double dealAmount, final String opportunityId, 
			Map<String, Object> allProducts, final String startDate, final String endDate, int numberOfProduct) {
		// get lost opportunities from CRM Opportunity Product table

		if(allProducts.containsKey(itemName)) {
			RevenueOpportunitiesData revenuOportunitiesData = (RevenueOpportunitiesData) allProducts.get(itemName);
			revenuOportunitiesData.setRevenueAmount(revenuOportunitiesData.getRevenueAmount() + dealAmount);
			revenuOportunitiesData.getOpportunityIds().add(opportunityId);
		} else {
			//List<String> lostOpportunities = crmOpportunityService.findOpportunitiesByStageInBatches(crmOpportunityProductService
					//.getOpportunityIdsByProductName(itemName, startDate, endDate), OpportunityStagesEnum.CLOSED_LOST.getText());
			
			RevenueOpportunitiesData revenueOpportuntiyData = new RevenueOpportunitiesData();
			revenueOpportuntiyData.setRevenueAmount(dealAmount);
			revenueOpportuntiyData.setOpportunityIds(new ArrayList<>(Arrays.asList(opportunityId)));
			//revenueOpportuntiyData.setLostOpportunityIds(lostOpportunities);
			revenueOpportuntiyData.setNumberOfProduct(numberOfProduct);
			allProducts.put(itemName, revenueOpportuntiyData);
		}
		//LOG.info("updateProductMap, allProducts "+allProducts.size());
		
	}

    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getIndex()
     */
    @Override
    public String getIndex() {
    	return ElasticSearchEnums.ERP.getText();
    }

    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getDocumentType()
     */
    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.ERP_ORDER_ITEM.getText();
    }
}
