package com.miri.search.data;

import java.io.Serializable;

import com.miri.search.constants.SearchConstants;

/**
 * Sales Person Revenue Domain class for holding sales person revenue information
 * @author rammoole
 *
 */
public class SalesPersonRevenueData implements Comparable<SalesPersonRevenueData>, Serializable {
	
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 7594598688823720028L;
	private String campaignName;
	private boolean isMarketingInfluenced; // if false then sales generated
	private String salesPersonName;
	private Object xAxisParam;
	private String xAxisLabel;
	private Double revenue;
	private Double winRate;
	private Double lostRate;
	private Double avgDealSize;
	private Double avgSellPrice;
	private Long noOfDealsClosed;
	private Long noOfDealsLost;
	private Double wonAmount;
	private Double lostAmount;
	
	private String industryName;
	
	private String opportunityType;
	
	private String customerName;
	
	private String productName;
	
	private String country;
	
	/**
	 * @return the campaignName
	 */
	public String getCampaignName() {
		return campaignName;
	}

	/**
	 * @param campaignName the campaignName to set
	 */
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	/**
	 * @return the isMarketingInfluenced
	 */
	public boolean isMarketingInfluenced() {
		return isMarketingInfluenced;
	}

	/**
	 * @param isMarketingInfluenced the isMarketingInfluenced to set
	 */
	public void setMarketingInfluenced(boolean isMarketingInfluenced) {
		this.isMarketingInfluenced = isMarketingInfluenced;
	}

	/**
	 * @return the salesPerson
	 */
	public String getSalesPersonName() {
		return salesPersonName;
	}

	/**
	 * @param salesPerson the salesPerson to set
	 */
	public void setSalesPersonName(String salesPersonName) {
		this.salesPersonName = salesPersonName;
	}

	/**
	 * @return the xAxisParam
	 */
	public Object getxAxisParam() {
		return xAxisParam;
	}

	/**
	 * @param xAxisParam the xAxisParam to set
	 */
	public void setxAxisParam(Object xAxisParam) {
		this.xAxisParam = xAxisParam;
	}

	/**
	 * @return the xAxisLabel
	 */
	public String getxAxisLabel() {
		return xAxisLabel;
	}

	/**
	 * @param xAxisLabel the xAxisLabel to set
	 */
	public void setxAxisLabel(String xAxisLabel) {
		this.xAxisLabel = xAxisLabel;
	}

	/**
	 * @return the revenue
	 */
	public Double getRevenue() {
		return revenue;
	}

	/**
	 * @param revenue the revenue to set
	 */
	public void setRevenue(Double revenue) {
		this.revenue = revenue;
	}

	/**
	 * @return the winRate
	 */
	public Double getWinRate() {
		return winRate;
	}

	/**
	 * @param winRate the winRate to set
	 */
	public void setWinRate(Double winRate) {
		this.winRate = winRate;
	}

	/**
	 * @return the lostRate
	 */
	public Double getLostRate() {
		return lostRate;
	}

	/**
	 * @param lostRate the lostRate to set
	 */
	public void setLostRate(Double lostRate) {
		this.lostRate = lostRate;
	}

	/**
	 * @return the avgDealSize
	 */
	public Double getAvgDealSize() {
		return avgDealSize;
	}

	/**
	 * @param avgDealSize the avgDealSize to set
	 */
	public void setAvgDealSize(Double avgDealSize) {
		this.avgDealSize = avgDealSize;
	}

	/**
	 * @return the avgSellPrice
	 */
	public Double getAvgSellPrice() {
		return avgSellPrice;
	}

	/**
	 * @param avgSellPrice the avgSellPrice to set
	 */
	public void setAvgSellPrice(Double avgSellPrice) {
		this.avgSellPrice = avgSellPrice;
	}

	/**
	 * @return the noOfDealsClosed
	 */
	public Long getNoOfDealsClosed() {
		return noOfDealsClosed;
	}

	/**
	 * @param noOfDealsClosed the noOfDealsClosed to set
	 */
	public void setNoOfDealsClosed(Long noOfDealsClosed) {
		this.noOfDealsClosed = noOfDealsClosed;
	}

	/**
	 * @return the noOfDealsLost
	 */
	public Long getNoOfDealsLost() {
		return noOfDealsLost;
	}

	/**
	 * @param noOfDealsLost the noOfDealsLost to set
	 */
	public void setNoOfDealsLost(Long noOfDealsLost) {
		this.noOfDealsLost = noOfDealsLost;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SalesPersonRevenue [campaignName=" + campaignName + ", isMarketingInfluenced=" + isMarketingInfluenced
				+ ", salesPerson=" + salesPersonName + ", revenue=" + revenue + ", xAxisParam=" + xAxisParam + "]";
	}
	
	@Override
	public int compareTo(SalesPersonRevenueData topSalesPerson) {
		if(topSalesPerson != null && Math.abs(this.getRevenue() - topSalesPerson.getRevenue()) < SearchConstants.EPSILON) {
			return 0;
		} else if(topSalesPerson != null) {
			return this.getRevenue() > topSalesPerson.getRevenue() ? -1 : 1;
		} else {
			return 1;
		}
	}

	/**
	 * @return the wonAmount
	 */
	public Double getWonAmount() {
		return wonAmount;
	}

	/**
	 * @param wonAmount the wonAmount to set
	 */
	public void setWonAmount(Double wonAmount) {
		this.wonAmount = wonAmount;
	}

	/**
	 * @return the lostAmount
	 */
	public Double getLostAmount() {
		return lostAmount;
	}

	/**
	 * @param lostAmount the lostAmount to set
	 */
	public void setLostAmount(Double lostAmount) {
		this.lostAmount = lostAmount;
	}

	/**
	 * @return the industryName
	 */
	public String getIndustryName() {
		return industryName;
	}

	/**
	 * @param industryName the industryName to set
	 */
	public void setIndustryName(String industryName) {
		this.industryName = industryName;
	}

	/**
	 * @return the opportunityType
	 */
	public String getOpportunityType() {
		return opportunityType;
	}

	/**
	 * @param opportunityType the opportunityType to set
	 */
	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
}
