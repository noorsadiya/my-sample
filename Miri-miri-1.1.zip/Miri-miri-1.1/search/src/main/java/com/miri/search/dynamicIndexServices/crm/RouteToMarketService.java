package com.miri.search.dynamicIndexServices.crm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.children.ChildrenBuilder;
import org.elasticsearch.search.aggregations.bucket.children.InternalChildren;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Order;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.ColumnDrillDownData;
import com.miri.search.data.MetricPojo;
import com.miri.search.data.TopProductData;
import com.miri.search.domain.guage.GaugePojo;
import com.miri.search.dynamicIndexServices.MappedConstants;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;

@Component
public class RouteToMarketService extends MiriSearchService{
	
	
	@Autowired
	ERPInvoiceService erpInvoiceService;
	
	@Autowired
	TopProductsByRevenueService productService;
	
	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_CAMPAIGN_OPPORTUNITY_MAPPED.getText();
	}
	
	public Map<String, Double> getTopPartnerRoles(String startDate, String endDate, int size){
		Map<String, Double> topPartnerRoles =  new HashMap<String, Double>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
				.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));	
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(CRMConstants.PARTNER_ROLE_RAW, ""));
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(parentSumBuilder);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.PARTNER_ROLE_AGGREGATION)
				.field(CRMConstants.PARTNER_ROLE_RAW).subAggregation(parentBuilder).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">" +SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		InternalChildren internalChildren = null;
		Sum sum = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.PARTNER_ROLE_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				revenue = sum.getValue();
				if(revenue > 0){
					topPartnerRoles.put(termBucket.getKey(), revenue);
				}
			}
		}
		return topPartnerRoles;
	}
	
	public List<ColumnDrillDownData> getPartnerRolesDataByField(int size, String startDate, String endDate, List<String> partnerRoles, String field, List<String> marketingSubCampaigns){

		List<ColumnDrillDownData> rtmData = new ArrayList<>();
		List<Double> dollarDataList = new ArrayList<>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
				.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));	
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(CRMConstants.PARTNER_ROLE_RAW, ""));
		if(CollectionUtils.isNotEmpty(partnerRoles)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.PARTNER_ROLE_RAW, partnerRoles));
		}
		if(CollectionUtils.isNotEmpty(marketingSubCampaigns)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}
		
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
											   .field(CRMConstants.OPPORTUNITY_ID_RAW)
											   .size(0);
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
									  .field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
										.childType(MappedConstants.CRM_ERP_MAPPED)
										.subAggregation(parentSumBuilder)
										.subAggregation(opportunityAggregation);
		
		TermsBuilder fieldAggregator =  AggregationBuilders.terms(SearchConstants.FIELD_AGGREGATION)
										.field(field)
										.size(size)
										.order(Order.aggregation(MappedConstants.CHILDREN + ">" +SearchConstants.SUM_AGGREGATION, false))
										.subAggregation(parentBuilder);
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.PARTNER_ROLE_AGGREGATION)
											.field(CRMConstants.PARTNER_ROLE_RAW)
											.size(size)
											.order(Order.aggregation(MappedConstants.CHILDREN + ">" +SearchConstants.SUM_AGGREGATION, false))
											.subAggregation(fieldAggregator)
											.subAggregation(parentBuilder);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
													.setTypes(getDocumentType())
													.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
													.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		Collection<Terms.Bucket> termsBuckets = null;
		InternalChildren internalChildren = null;
		Sum sum = null;
		ColumnDrillDownData columnDrillDownData = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.PARTNER_ROLE_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				List<String> opportunityIds = new ArrayList<>();
				columnDrillDownData = new ColumnDrillDownData();
				internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
				for(Bucket opportunityBucket : opportunityBuckets){
					opportunityIds.add(opportunityBucket.getKey());
				}
				revenue = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, startDate, endDate);
				if(revenue > 0){
					columnDrillDownData.setName(termBucket.getKey());
					columnDrillDownData.setRevenueAmount(revenue);
					//columnDrillDownData.setAverageDealSize( opportunityBuckets.size() != 0 ? (revenue / (opportunityBuckets.size() )) : 0);
					columnDrillDownData.setOpportunityCount(opportunityBuckets.size());
					//columnDrillDownData.setAverageSellPrice( internalChildren.getDocCount() != 0 ? (revenue / (internalChildren.getDocCount() )) : 0);
					columnDrillDownData.setIndustryDrillDown(getChildData(termBucket,startDate,endDate));
					dollarDataList.add(revenue);
					rtmData.add(columnDrillDownData);
				}
			}
			
		}
		return rtmData;
	}
	
	/**
	 * Extracts child Data From the Bucket
	 * @param termBucket
	 * @return
	 */
	public List<ColumnDrillDownData> getChildData(Bucket termBucket, String startDate, String endDate){
		List<ColumnDrillDownData> fieldData = new ArrayList<>();
		ColumnDrillDownData columnDrillDownData = null;
		InternalChildren internalChildren = null;
		Terms terms = termBucket.getAggregations().get(SearchConstants.FIELD_AGGREGATION);
		List<Bucket> termsBuckets = terms.getBuckets();
		Sum sum = null;
		for (Terms.Bucket bucket : termsBuckets) {
			if(StringUtils.isNotBlank(bucket.getKey())){
				List<String> opportunityIds = new ArrayList<>();
				internalChildren  = bucket.getAggregations().get(MappedConstants.CHILDREN);
				sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				List<Bucket> opportunityTermBuckets = opportunityTerms.getBuckets();
				for(Bucket opportunityTermBucket : opportunityTermBuckets ){
					opportunityIds.add(opportunityTermBucket.getKey());
				}
				columnDrillDownData = new ColumnDrillDownData();
				columnDrillDownData.setName(bucket.getKey());
				columnDrillDownData.setRevenueAmount(erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, startDate, endDate));
				//columnDrillDownData.setAverageDealSize( opportunityTermBuckets.size() != 0 ? (sum.getValue() / (opportunityTermBuckets.size() )) : 0);
				columnDrillDownData.setOpportunityCount(opportunityTermBuckets.size());
				//columnDrillDownData.setAverageSellPrice( internalChildren.getDocCount() != 0 ? (sum.getValue() / (internalChildren.getDocCount() )) : 0);
				fieldData.add(columnDrillDownData);
			}
		}
		return fieldData;
	}
	
	
	/**
	 * Construct Metric Object
	 * @param columnDrillDownData
	 * @param guagePojo
	 * @return
	 */
	public MetricPojo getMetricPojoObject(List<ColumnDrillDownData> columnDrillDownData, GaugePojo guagePojo){
		MetricPojo metricPojo = new MetricPojo();
		metricPojo.setGuagePojo(guagePojo);
		metricPojo.setMetricDataList(columnDrillDownData);
		return metricPojo;
	}
	
	
	public List<ColumnDrillDownData> getTopPartnersByProduct(int size, String startDate, String endDate, List<String> partnerRoles){

		List<ColumnDrillDownData> rtmData = new ArrayList<>();
		List<Double> dollarDataList = new ArrayList<>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
				.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));	
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(CRMConstants.PARTNER_ROLE_RAW, ""));
		if(CollectionUtils.isNotEmpty(partnerRoles)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.PARTNER_ROLE_RAW, partnerRoles));
		}
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
											   .field(CRMConstants.OPPORTUNITY_ID_RAW)
											   .size(0);
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
									  .field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
										.childType(MappedConstants.CRM_ERP_MAPPED)
										.subAggregation(parentSumBuilder)
										.subAggregation(opportunityAggregation);
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.PARTNER_ROLE_AGGREGATION)
											.field(CRMConstants.PARTNER_ROLE_RAW)
											.size(size)
											.order(Order.aggregation(MappedConstants.CHILDREN + ">" +SearchConstants.SUM_AGGREGATION, false))
											.subAggregation(parentBuilder);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
													.setTypes(getDocumentType())
													.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
													.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		Collection<Terms.Bucket> termsBuckets = null;
		InternalChildren internalChildren = null;
		Sum sum = null;
		ColumnDrillDownData columnDrillDownData = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.PARTNER_ROLE_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				List<String> opportunityIds = new ArrayList<>();
				columnDrillDownData = new ColumnDrillDownData();
				internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
				for(Bucket opportunityBucket : opportunityBuckets){
					opportunityIds.add(opportunityBucket.getKey());
				}
				revenue = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, startDate, endDate);
				if(revenue > 0){
					columnDrillDownData.setName(termBucket.getKey());
					columnDrillDownData.setRevenueAmount(revenue);
					//columnDrillDownData.setAverageDealSize( opportunityBuckets.size() != 0 ? (revenue / (opportunityBuckets.size() )) : 0);
					columnDrillDownData.setOpportunityCount(opportunityBuckets.size());
					//columnDrillDownData.setAverageSellPrice( internalChildren.getDocCount() != 0 ? (revenue / (internalChildren.getDocCount() )) : 0);
					columnDrillDownData.setIndustryDrillDown(getProductData(opportunityIds, startDate, endDate, SearchConstants.SUB_LEVEL_SIZE));
					dollarDataList.add(revenue);
					rtmData.add(columnDrillDownData);
				}
			}
			
		}
		return rtmData;
	}
	
	public List<ColumnDrillDownData> getProductData(List<String> opportunities, String startDate, String endDate, int size){
		List<TopProductData> topProductsByOpportunities = productService.getTopProductsByOpportunities(size, startDate, endDate, opportunities);
		List<ColumnDrillDownData> columnDrillDownDatas = new ArrayList<>();
		ColumnDrillDownData columnDrillDownData =  null;
		for(TopProductData topProductData : topProductsByOpportunities){
			columnDrillDownData = new ColumnDrillDownData();
			columnDrillDownData.setName(topProductData.getName());
			columnDrillDownData.setRevenueAmount(topProductData.getValue());
			columnDrillDownData.setOpportunityCount((int)(long)topProductData.getDealsClosed());
			columnDrillDownDatas.add(columnDrillDownData);
		}
		return columnDrillDownDatas;
	}


}
