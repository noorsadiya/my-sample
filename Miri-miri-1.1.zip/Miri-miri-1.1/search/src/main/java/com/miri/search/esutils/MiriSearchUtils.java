package com.miri.search.esutils;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.histogram.InternalHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.entity.CrmOpportunity;
import com.miri.cis.entity.MapLead;
import com.miri.data.jpa.util.AppSalesStageContainer;
import com.miri.search.constants.OpportunityStagesEnum;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.CampaignRevenueData;
import com.miri.search.data.FiscalDatesData;
import com.miri.search.data.FiscalDatesStrData;
import com.miri.search.data.LargeOpenOpportunitiesMetricData;
import com.miri.search.data.MultipleAxesChartData;
import com.miri.search.data.RevenueOpportunitiesData;
import com.miri.search.data.StackedColumnData;
import com.miri.search.data.TopCustomersData;
import com.miri.search.data.TopProductData;
import com.miri.search.data.TopProductsDataPojo;
import com.miri.search.data.WinLossData;
import com.miri.search.esutils.BoolQueryBuilderRequest.BoolType;
import com.miri.search.utils.MiriDateUtils;


/**
 * MiRi Search Utils
 *
 */
@Component
public class MiriSearchUtils {

	private static final Logger LOG = LogManager.getLogger(MiriSearchUtils.class);

	@Autowired
	private  AppSalesStageContainer stageContainer;
	
	private  static AppSalesStageContainer appSalesStageContainer;
	@PostConstruct
	public void init(){
		MiriSearchUtils.appSalesStageContainer=stageContainer;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static HashMap<String, Object> sortByRevenue(Map<String, Object> topIndustriesByRevenue) { 
		List list = new LinkedList(topIndustriesByRevenue.entrySet());
		// Defined Custom Comparator here
		Collections.sort(list, new Comparator() {
			@Override
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o2)).getValue())
						.compareTo(((Map.Entry) (o1)).getValue());
			}
		});

		HashMap<String, Object> sortedHashMap = new LinkedHashMap();
		for (Iterator it = list.iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			sortedHashMap.put((String) entry.getKey(), entry.getValue());
		} 
		return sortedHashMap;
	}

	public static Map<Integer,MultipleAxesChartData> populateRevenuePojoResult(Collection<InternalHistogram.Bucket> buckets,
			Map<Integer,Double> productSumByMonth,List<Integer> fiscalMonths){
		
		Map<Integer,MultipleAxesChartData> resultsMap = new LinkedHashMap<Integer, MultipleAxesChartData>();
		MultipleAxesChartData revenuePojo;
		int noOfProducts = 0;
		Calendar date;
		int month;
		int monthIndex=0;
		long deals = 0;
		
		for (InternalHistogram.Bucket bucket : buckets) {
			revenuePojo = new  MultipleAxesChartData();
			date = MiriDateUtils.parseStrDateToCalendar(bucket.getKeyAsText().toString(), MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			month = date.get(Calendar.MONTH);
	
		Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
		/*if(productSumByMonth.get(monthIndex) != null) {
			noOfProducts = productSumByMonth.get(monthIndex).intValue();
		}*/
		noOfProducts=(int)bucket.getDocCount();
		revenuePojo.setxAxis(monthIndex);
		revenuePojo.setRevenueAmount(sum.getValue());
		revenuePojo.setAverageSellPrice(MiriSearchUtils.average(sum.getValue(), noOfProducts));
		Terms opportunityTerms = bucket.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
		if(opportunityTerms!=null){
			deals = (long) opportunityTerms.getBuckets().size();
		}
		revenuePojo.setNoOfDeals(deals);
		revenuePojo.setAverageDealSize(MiriSearchUtils.average(sum.getValue(),(int)deals));
		revenuePojo.setNoOfProducts((long) noOfProducts);
		resultsMap.put(monthIndex,revenuePojo);
		monthIndex++;
			
		}
	
		return resultsMap;

	}
	
	public static Map<Object,CampaignRevenueData> populateCampaignRevenuePojoResult(Collection<InternalHistogram.Bucket> buckets,
			Map<Integer,Double> productSumByMonth,List<Integer> fiscalMonths, String startDate, String endDate){
		Map<Object,CampaignRevenueData> resultsMap = new LinkedHashMap<Object, CampaignRevenueData>();
		CampaignRevenueData revenuePojo;
		int noOfProducts = 0;
		int monthIndex = 0;
		long deals = 0;
		Map<Integer, String> updatedDates = MiriDateUtils.getUpdatedDates(startDate, endDate);
		for (InternalHistogram.Bucket bucket : buckets) {
			if(updatedDates.containsKey(monthIndex)){
				revenuePojo = new  CampaignRevenueData();
				//date = MiriDateUtils.parseStrDateToCalendar(bucket.getKeyAsText().toString(), MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
				Sum sum = bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
				
				Sum productSum = bucket.getAggregations().get(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION);
				
				// Getting opportunities closed in the deal
				Terms opportunityTerms = bucket.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				noOfProducts = ((Double) productSum.getValue()).intValue();
				//LOG.info("NO of Products :" + noOfProducts);
				deals = (long) opportunityTerms.getBuckets().size();
				revenuePojo.setRevenueAmount(sum.getValue());
				revenuePojo.setAverageDealSize(MiriSearchUtils.average(sum.getValue(), (int) deals));
				revenuePojo.setAverageSellPrice(MiriSearchUtils.average(sum.getValue(), noOfProducts));
				revenuePojo.setNoOfDeals(deals);
				revenuePojo.setNoOfProducts(new Long(noOfProducts));
				resultsMap.put(monthIndex, revenuePojo);
			}else{
				resultsMap.put(monthIndex, null);
			}
			monthIndex++;
		}
		return resultsMap;

	}


	/**
	 * 's 
	 * It is used to get list of the opportunity IDfro mthe ES Search Response
	 * @param searchResponse
	 * ES Search Response which contains Opportunity ID's
	 * @return
	 * 		{@link List}
	 * 		Contains all the ID's from ES search response
	 */
	public static List<String> getOpportunityIds(SearchResponse searchResponse){

		List<String> opportunities = new ArrayList<String>();
		for (SearchHit hit : searchResponse.getHits()) {
			opportunities.add(hit.field(SearchConstants.OPPORTUNITY_ID).getValue().toString());
		}
		return opportunities;
	}


	public static Double sumAll(List<Double> valuesToSum){
		Double sum = new Double(0); 
		for (Double i : valuesToSum) {
			sum = sum + i;
		}
		return sum;
	}

	public static Double average(Double sum,int count) {
		Double avg = new Double(0);
		if(sum!=0 && count!=0){
			avg= sum/count;
		}
		return avg;
	}

	/**
	 * Calculate average sum
	 * @param valuesToSum
	 * @return
	 */
	public static Double calculateAverageSum(Collection<Double> valuesToSum){
		Double sum = new Double(0); 
		for (Double i : valuesToSum) {
			sum = sum + i;
		}
		return sum/valuesToSum.size();
	}

	/**
	 * Sorting top customer wins by revenue map data based on by revenue
	 * @param topCustomerWinsInfo
	 * @return
	 */
	public static Map<String, Object> sortTopCustomerWinsByRevenue(Map<String, Object> topCustomerWinsInfo,int size){

		List<Map.Entry<String, Object>> incomingDate = new LinkedList<>(topCustomerWinsInfo.entrySet());

		Collections.sort(incomingDate,new Comparator<Map.Entry<String, Object>>() {
			@Override
			public int compare(Map.Entry<String, Object> firstObject,Map.Entry<String, Object> nextObject){
				return ((TopCustomersData)(nextObject.getValue())).getyAxisValue()
						.compareTo(((TopCustomersData)(firstObject.getValue())).getyAxisValue());
			}
		});

		Map<String, Object> sortedCustomerInfo = new LinkedHashMap<>();
		Iterator<Map.Entry<String, Object>>  it = incomingDate.iterator();
		int counter=1;
		while(it.hasNext()){
			Map.Entry<String, Object> entry = it.next();
			sortedCustomerInfo.put(entry.getKey(),entry.getValue());

			if(counter++==size){
				break;
			}
			
		}
		return sortedCustomerInfo;
	}
	
	/**
	 * Sorting top customer wins by revenue map data based on by revenue
	 * @param topCustomerWinsInfo
	 * @return
	 */
	public static List<LargeOpenOpportunitiesMetricData> sortForLargeOpenOpportunities(List<LargeOpenOpportunitiesMetricData> metricData){
		
		Collections.sort(metricData, new Comparator<LargeOpenOpportunitiesMetricData>(){
		     public int compare(LargeOpenOpportunitiesMetricData o1, LargeOpenOpportunitiesMetricData o2){
		         return o1.getName().compareTo(o2.getName());
		     }
		});
		return metricData;
	}
	
	/**
	 * Sort the product names in ascending order
	 * @param topProducts
	 * @return
	 */
	public static List<TopProductData> sortProductsByName(List<TopProductData> topProducts) {
		Collections.sort(topProducts, new Comparator<TopProductData>() {
			public int compare(TopProductData topProductData1, TopProductData topProductData2) {
				if(topProductData1 != null && topProductData2 != null) {
					if(topProductData1.getValue() != null && topProductData2.getValue() != null) {
						return topProductData1.getValue().compareTo(topProductData2.getValue());
					} else if(topProductData1.getValue() != null && topProductData1.getValue() == null) {
						return 1;
					} else if(topProductData1.getValue() == null && topProductData1.getValue() != null) {
						return -1;
					} else {
						return 0;
					}
				} else if(topProductData1 == null && topProductData2 != null) {
					return -1;
				} else if(topProductData1 != null && topProductData2 == null) {
					return 1;
				} else {
					return 0;
				}
			}
		});
		return topProducts;
	}

	/**
	 * Returns Top items from the passed Map of data 
	 * @param mapItems
	 * @return
	 */
	public static Map<String, Object> getMapTopItems(Map<String, Object> mapItems, final int number) {
		Map<String, Object> topItems = new LinkedHashMap<>(); 
		if(mapItems.size() > number) {
			int count = 0;
			for(Map.Entry<String, Object> entry: mapItems.entrySet()) {
				topItems.put(entry.getKey(), entry.getValue());
				count++;
				if(count == number) {
					break;
				}
			}
		} else {
			topItems.putAll(mapItems);
		}
		return topItems;
	}

	/**
	 * Returns Top items from the passed Map of data 
	 * @param mapItems
	 * @return
	 */
	public static Map<Object, Double> getTopItems(Map<Object, Double> mapItems, final int size) {
		Map<Object, Double> topItems = new LinkedHashMap<>(); 
		if(mapItems.size() > size) {
			int count = 0;
			for(Map.Entry<Object, Double> entry: mapItems.entrySet()) {
				topItems.put(entry.getKey(), entry.getValue());
				count++;
				if(count == size) {
					break;
				}
			}
		} else {
			topItems.putAll(mapItems);
		}
		return topItems;
	}

	/**
	 * Returns Top items from the passed Map of data 
	 * @param mapItems
	 * @return
	 */
	public static Map<String, Map<String, Object>> getMapTopAndOtherItems(Map<String, Object> mapItems, final int number) {
		Map<String, Object> topItems = new LinkedHashMap<>();
		Map<String, Object> otherItems = null;
		if(mapItems.size() > number) {
			int count = 0;
			otherItems = new HashMap<>();
			for(Map.Entry<String, Object> entry: mapItems.entrySet()) {
				if(count < number) {
					topItems.put(entry.getKey(), entry.getValue());
				}
				if(count > number) {
					otherItems.put(entry.getKey(), entry.getValue());
				}
				count++;
			}
		} else {
			topItems.putAll(mapItems);
		}
		Map<String, Map<String, Object>> topAndOtherItems = new HashMap<>();
		topAndOtherItems.put(SearchConstants.TOP_ITEMS, topItems);
		topAndOtherItems.put(SearchConstants.OTHER_ITEMS, otherItems);
		return topAndOtherItems;
	}


	/**
	 * Sort Map By Value
	 * @param allCampaignsByRevenue
	 * @return
	 */
	public static Map<Object, Double> sortMapByValue(Map<Object, Double> allCampaignsByRevenue) {
		List<Map.Entry<Object, Double>> entries = new ArrayList<>(allCampaignsByRevenue.entrySet());
		Collections.sort(entries, new Comparator<Map.Entry<Object, Double>>() {
			@Override
			public int compare(Map.Entry<Object, Double> arg0, Map.Entry<Object, Double> arg1) {
				return -Double.compare(arg0.getValue(), arg1.getValue());
			}
		});
		Map<Object, Double> campaigns = new LinkedHashMap<>();
		for(Map.Entry<Object, Double> entry: entries) {
			campaigns.put(entry.getKey(), entry.getValue());
		}
		return campaigns;
	}
	
	/**
	 * Sort Map By Value
	 * @param allCampaignsByRevenue
	 * @return
	 */
	public static Map<String, Double> sortMapByValueWithString(Map<String, Double> allCampaignsByRevenue) {
		List<Map.Entry<String, Double>> entries = new ArrayList<>(allCampaignsByRevenue.entrySet());
		
		Collections.sort(entries, new Comparator<Map.Entry<String, Double>>() {
			@Override
			public int compare(Map.Entry<String, Double> arg0, Map.Entry<String, Double> arg1) {
				return -Double.compare(arg0.getValue(), arg1.getValue());
			}
		});
		Map<String, Double> campaigns = new LinkedHashMap<>();
		for(Map.Entry<String, Double> entry: entries) {
			campaigns.put(entry.getKey(), entry.getValue());
		}
		return campaigns;
	}
	
	/**
	 * Win Loss Data to Stacked Column Data
	 * @param winLossData
	 * @return
	 */
	public static List<StackedColumnData> getWinLossData(Map<String, WinLossData> winLossData) {
		List<StackedColumnData> columnData = new ArrayList<>();
		StackedColumnData stackedColumnData;
		WinLossData winLoss;
		double winPercentage;
		double lossPercentage;
		DecimalFormat df = new DecimalFormat("#.00");
		for(Map.Entry<String, WinLossData> campaignData: winLossData.entrySet()) {
			stackedColumnData = new StackedColumnData();
			winLoss = campaignData.getValue();
			if(winLoss != null) {
				winPercentage = ((double) winLoss.getWonCount() / (winLoss.getLostCount() + winLoss.getWonCount()))  * 100;
				lossPercentage = ((double) winLoss.getLostCount() / (winLoss.getLostCount() + winLoss.getWonCount()))  * 100;
				winPercentage = Double.valueOf(df.format(Double.isNaN(winPercentage) ? 0 : winPercentage));
				lossPercentage = Double.valueOf(df.format(Double.isNaN(lossPercentage) ? 0 : lossPercentage));
				stackedColumnData.setTotalAmount(winPercentage);
				stackedColumnData.setQualifiedAmount(lossPercentage);
				stackedColumnData.setWonRevenue(winLoss.getWonAmount());
				stackedColumnData.setLostRevenue(winLoss.getLostAmount());
				stackedColumnData.setWonCount(winLoss.getWonCount());
				stackedColumnData.setLostCount(winLoss.getLostCount());
				stackedColumnData.setxAxis(campaignData.getKey());
				columnData.add(stackedColumnData);
			}
		}
		return columnData;
	}
	
	/**
	 * Sort all the map contents by Object
	 * @param allCampaignsByRevenue
	 * @return
	 */
	public static Map<String, Object> sortMapByObjectValue(Map<String, Object> allItemsByRevenue) {
		List<Map.Entry<String, Object>> entries = new ArrayList<>(allItemsByRevenue.entrySet());

		Collections.sort(entries, new Comparator<Map.Entry<String, Object>>() {
			@Override
			public int compare(Map.Entry<String, Object> arg0, Map.Entry<String, Object> arg1) {
				return -Double.compare(((RevenueOpportunitiesData) arg0.getValue()).getRevenueAmount(), ((RevenueOpportunitiesData) arg1.getValue()).getRevenueAmount());
			}
		});
		Map<String, Object> sortedItems = new LinkedHashMap<>();
		for(Map.Entry<String, Object> entry: entries) {
			sortedItems.put(entry.getKey(), entry.getValue());
		}
		return sortedItems;
	}
	/**
	 * Sort all the map contents by Object
	 * @param allCampaignsByRevenue
	 * @return
	 */
	public static Map<String, Object> sortMapByObjectValueToGetTopRecords(Map<String, Object> allItemsByRevenue, int size) {
		List<Map.Entry<String, Object>> entries = new ArrayList<>(allItemsByRevenue.entrySet());
		
		Collections.sort(entries, new Comparator<Map.Entry<String, Object>>() {
			@Override
			public int compare(Map.Entry<String, Object> arg0, Map.Entry<String, Object> arg1) {
				return -Double.compare(((RevenueOpportunitiesData) arg0.getValue()).getRevenueAmount(), ((RevenueOpportunitiesData) arg1.getValue()).getRevenueAmount());

			}
		});
		int counter = 0;
		Map<String, Object> sortedItems = new LinkedHashMap<>();
		for(Map.Entry<String, Object> entry: entries) {
			if(counter < size){
				sortedItems.put(entry.getKey(), entry.getValue());
				counter++;
			}else
				break;
			
		}
		return sortedItems;
	}

	/**
	 * Get Top 25 and other campaigns if there are more than 25 campaigns. 
	 * If there are less than 25 campaigns, then other campaigns will be null and it returns those campaigns as it is.
	 * @param topCampaigns
	 */

	public static Map<String, Map<Object, Double>> getTopAndOtherCampaigns(Map<Object, Double> campaigns, int number) {
//		Map<Object, Double> otherCampaigns = null;
		Map<Object, Double> topCampaigns = new LinkedHashMap<>();
		if(campaigns.size() > number) {
//			otherCampaigns = new LinkedHashMap<>();
			int count = 0;
			for(Map.Entry<Object, Double> entry: campaigns.entrySet()) {
				if(count < number) {
					topCampaigns.put(entry.getKey(), entry.getValue());
				}
				count++;

/*				if(count > number) {
					otherCampaigns.put(entry.getKey(), entry.getValue());
				}
*/			}
		} else {
			topCampaigns.putAll(campaigns);
		}
		Map<String, Map<Object, Double>> topAndOtherCampaigns = new HashMap<>();
		topAndOtherCampaigns.put(SearchConstants.TOP_ITEMS, topCampaigns);
//		topAndOtherCampaigns.put(SearchConstants.OTHER_ITEMS, otherCampaigns);
		return topAndOtherCampaigns;
	}

	/**
	 * Get Top 25 campaigns if there are more than 25 campaigns. 
	 * If there are less than 25 campaigns, it returns those campaigns as it is.
	 * @param topCampaigns
	 */
	public static Map<Object, Double> getTopCampaigns(Map<Object, Double> campaigns, int number) {
		Map<Object, Double> topCampaigns = new LinkedHashMap<>();
		if(campaigns.size() > number) {
			int count = 0;
			for(Map.Entry<Object, Double> entry: campaigns.entrySet()) {
				if(count < number) {
					topCampaigns.put(entry.getKey(), entry.getValue());
				}
				count++;
				if(count > number) {
					break;
				}
			}
		} else {
			topCampaigns.putAll(campaigns);
		}

		return topCampaigns;
	}

	/**
	 * Calculate Average Opportunity Creation Date
	 * @param crmOpportunities
	 * @return
	 */
	public static long calculateAvgOpportunityCreationDate(List<CrmOpportunity> crmOpportunities) {
		LOG.info("Calculating opportunity creation date");
		long totalOpportunityTime = 0;
		if(crmOpportunities != null) {
			for(CrmOpportunity opportunity: crmOpportunities) {
				totalOpportunityTime += MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD_HH_MM_SSS, 
						opportunity.getCreatedOn().replace("T", " ").replace("Z", "")).getTime(); 
			}
		}
		return totalOpportunityTime / crmOpportunities.size();
	}

	/**
	 * Calculate Average Lead Capture Date 
	 * @param mapLeads
	 * @return
	 */
	public static long calculateAvgLeadCaptureDate( List<MapLead> mapLeads) {
		LOG.info("Calculating average lead capture date");
		long totalLeadCaptureTime = 0;
		if(mapLeads != null) {
			for(MapLead lead: mapLeads) {
				totalLeadCaptureTime += MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD_HH_MM_SSS, 
						lead.getCreatedDate().replace("T", " ").replace("Z", "")).getTime(); 
			}
		}
		return totalLeadCaptureTime / mapLeads.size();
	}

	/**
	 * Calculate Averagae Sales Order creation date
	 * @param mapLeads
	 * @return
	 */
	/*public static long calculateAvgSalesOrderCreationDate( List<ErpSalesOrder> salesOrderList) {
		LOG.info("Calculating average sales order date");
		List<String> opportunityIds = new ArrayList<>();
		if(salesOrderList != null) {
			for(ErpSalesOrder erpSalesOrder: salesOrderList) {
				if(erpSalesOrder != null && erpSalesOrder.getCreatedDate() != null) {
					opportunityIds.add(erpSalesOrder.getOpportunityId());
				}
			}
		}
		return (long) crmOpportunityService.getAvgCreationTimeOfOpportunityIds(opportunityIds);
	}*/

	/**
	 * This method returns the number of days from the milliseconds
	 * @return
	 */
	public static int getDaysfromMillis(long milliseconds) {
		return (int) Math.round(milliseconds / (1000.0 * 60 * 60 * 24));
	}

	/**
	 * Get Ids from opportunity objects
	 * @param crmOpportunities
	 * @return
	 */
	public static List<String> getIdsFromOpportunities(List<CrmOpportunity> crmOpportunities) {
		List<String> opportunityIds = new ArrayList<>();
		for(CrmOpportunity crmOpportunity: crmOpportunities) {
			opportunityIds.add(crmOpportunity.getOpportunityId());
		}
		return opportunityIds;
	}

	/**
	 * Process opportunities for word cloud
	 * @param opportunityNames
	 * @param campaignDemandTriggers
	 * @return
	 */
	public static Map<String, Integer> processOpportunityNamesForWordCloud(List<String> opportunityNames, Map<String, Integer> campaignDemandTriggers) {
		int existingCount;
		for(String opportunityName: opportunityNames) {
			String[] opportunityWords = opportunityName.split(" ");
			for(int i = 0; i < opportunityWords.length; i++) {
				if(campaignDemandTriggers.containsKey(opportunityWords[i])) {
					existingCount = campaignDemandTriggers.get(opportunityWords[i]);
					campaignDemandTriggers.put(opportunityWords[i], existingCount + 1);
				} else {
					campaignDemandTriggers.put(opportunityWords[i], 1); // If there is no opportunity name then inserting for the first time and keeping 1.
				}
			}
		}
		return campaignDemandTriggers;
	}

	/**
	 * Word Cloud Aggregation value from search response
	 * Limiting the numbers and characters less then 2 
	 * @param searchResponse
	 * @author rammoole
	 */
	public static Map<String, Long> getWordCloudAggregation(SearchResponse searchResponse) {
		Terms wordTerms = searchResponse.getAggregations().get(SearchConstants.WORD_CLOUD_OPP_PAIN_POINTS);
		Collection<Terms.Bucket> wordCloudBuckets = wordTerms.getBuckets();
		
		Terms wordOppTerms = searchResponse.getAggregations().get(SearchConstants.WORD_CLOUD_OPP_NAME);
		Collection<Terms.Bucket> wordCloudOppBuckets = wordOppTerms.getBuckets();
		//LOG.info("bucket count :" + wordCloudBuckets.size());
		Map<String, Long> wordCloud = new LinkedHashMap<>();
		for(Terms.Bucket bucket: wordCloudBuckets) {
			if(StringUtils.isNotBlank(bucket.getKey()) && bucket.getKey().length() > 1 && !NumberUtils.isNumber(bucket.getKey())) {
				wordCloud.put(bucket.getKey(), bucket.getDocCount());
			}
			if(wordCloud.size() == SearchConstants.TOP_100_ITEMS) {
				break;
			}
		}
		
		for(Terms.Bucket bucket: wordCloudOppBuckets) {
			if(StringUtils.isNotBlank(bucket.getKey()) && bucket.getKey().length() > 1 && !NumberUtils.isNumber(bucket.getKey())) {
				wordCloud.put(bucket.getKey(), bucket.getDocCount());
			}
			if(wordCloud.size() == SearchConstants.TOP_100_ITEMS) {
				break;
			}
		}
		return wordCloud;
	}
	
	/**
	 * Creates a bool should query  builder for huge set of data
	 * @return
	 * @author rammoole
	 */
	public static BoolQueryBuilder createBoolQueryBuilder(final String fieldName, final List<String> fieldValues,
			final int batchSize) {
		BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
		if (CollectionUtils.isEmpty(fieldValues)) {
			boolQuery.should(QueryBuilders.termQuery(fieldName, fieldValues));
		}
		else {
			int start = 0;
			int end = batchSize;
			int outerForCount = fieldValues.size() / batchSize; // this is like the number of iterations
			int remainingItems = fieldValues.size() % batchSize; // This is for any remaining data after the iterations
			for (int i = 0; i < outerForCount; i++) {
				boolQuery.should(QueryBuilders.termsQuery(fieldName, fieldValues.subList(start, end)));
				start = start + batchSize;
				end = end + batchSize;
			}			
			if (remainingItems != 0) {
				end = end - batchSize + remainingItems;
				boolQuery.should(QueryBuilders.termsQuery(fieldName, fieldValues.subList(start, end)));
			}
		}
		return boolQuery;
	}

	/**
	 * 
	 * 
	 * @param boolQueryRequest
	 * @return
	 */
	public static BoolQueryBuilder createBoolQueryBuilder(List<BoolQueryBuilderRequest>  boolQueryRequests) {
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		return createBoolQueryBuilder(boolQueryBuilder, boolQueryRequests);
	}
	
	/**
	 * 
	 * 
	 * @param boolQueryRequest
	 * @return
	 */
	/*public static BoolQueryBuilder createBoolQueryBuilder(BoolQueryBuilderRequest...    boolQueryRequests) {
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		//TODO- update it.
		return null;
	}*/

	/**
	 * Creating a BoolQuery Builder using BoolQueryBuilderRequest objects
	 * @param boolQueryRequest
	 * @return
	 */
	public static BoolQueryBuilder createBoolQueryBuilder(BoolQueryBuilderRequest  boolQueryRequests) {
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		List<BoolQueryBuilderRequest> boolQueryBuilderRequests = new ArrayList<>();
		boolQueryBuilderRequests.add(boolQueryRequests);
		return createBoolQueryBuilder(boolQueryBuilder, boolQueryBuilderRequests);
	}

	/**
	 * Creating a BoolQuery Builder using BoolQueryBuilderRequest objects
	 * @param boolQueryRequest
	 * @return
	 */
	public static BoolQueryBuilder createBoolQueryBuilder(BoolQueryBuilder boolQueryBuilder, List<BoolQueryBuilderRequest>  boolQueryRequest) {
		if(!CollectionUtils.isEmpty(boolQueryRequest)) {
			for(BoolQueryBuilderRequest boolQueryRequestBuilder: boolQueryRequest) {
				int start = 0;
				int end = boolQueryRequestBuilder.getBatchSize();
				int outerForCount = boolQueryRequestBuilder.getFieldValues().size() / boolQueryRequestBuilder.getBatchSize(); // this is like the number of iterations
				int remainingItems = boolQueryRequestBuilder.getFieldValues().size() % boolQueryRequestBuilder.getBatchSize(); // This is for any remaining data after the iterations
				for(int i = 0; i < outerForCount; i++) {
					if(boolQueryRequestBuilder.getType() == BoolType.SHOULD) {
						boolQueryBuilder.should(QueryBuilders.termsQuery(boolQueryRequestBuilder.getFieldName(), 
								boolQueryRequestBuilder.getFieldValues().subList(start, end)));
					} else if (boolQueryRequestBuilder.getType() == BoolType.MUST_NOT) {
						boolQueryBuilder.mustNot(QueryBuilders.termsQuery(boolQueryRequestBuilder.getFieldName(), 
								boolQueryRequestBuilder.getFieldValues().subList(start, end)));
					} else {
						boolQueryBuilder.must(QueryBuilders.termsQuery(boolQueryRequestBuilder.getFieldName(), 
								boolQueryRequestBuilder.getFieldValues().subList(start, end)));
					}
					start = start + boolQueryRequestBuilder.getBatchSize();
					end = end + boolQueryRequestBuilder.getBatchSize();
				}
				if(remainingItems != 0) {
					end = end - boolQueryRequestBuilder.getBatchSize() + remainingItems;
					if(boolQueryRequestBuilder.getType() == BoolType.SHOULD) {
						boolQueryBuilder.should(QueryBuilders.termsQuery(boolQueryRequestBuilder.getFieldName(), 
								boolQueryRequestBuilder.getFieldValues().subList(start, end)));
					}else if (boolQueryRequestBuilder.getType() == BoolType.MUST_NOT) {
						boolQueryBuilder.mustNot(QueryBuilders.termsQuery(boolQueryRequestBuilder.getFieldName(), 
								boolQueryRequestBuilder.getFieldValues().subList(start, end))); 
					} else {
						boolQueryBuilder.must(QueryBuilders.termsQuery(boolQueryRequestBuilder.getFieldName(), 
								boolQueryRequestBuilder.getFieldValues().subList(start, end)));
					}
				}
			}
		}
		return boolQueryBuilder;
	}
	
	/**
	 * Populating empty months data before filling actual data
	 * @return
	 */
	public static Map<Integer, Double> populateMonthsEmptyDoubleData() {
		Map<Integer, Double> monthsData = new HashMap<>();
		for(int i = 0; i < 12; i++) {
			monthsData.put(i, 0.0);
		}
		return monthsData;
	}
	
	/**
	 * Populating empty months data before filling actual data
	 * @return
	 */
	public static Map<Integer, Long> populateMonthsEmptyLongData() {
		Map<Integer, Long> monthsData = new HashMap<>();
		for(int i = 0; i < 12; i++) {
			monthsData.put(i, 0L);
		}
		return monthsData;
	}
	
	public static List<String> createStages(String[] stages){
		List<String> stagesList=Arrays.asList(stages);
 		return stagesList;
		
	}
	

	public static List<String> stagesToExcludeForTotalAmount(){
		List<String> stagestoExcludeforTotal=new ArrayList<>();
		stagestoExcludeforTotal.add(OpportunityStagesEnum.STAGE_EMPTY.getText());
		stagestoExcludeforTotal.add(OpportunityStagesEnum.CLOSED_WON.getText());
		stagestoExcludeforTotal.add(OpportunityStagesEnum.CLOSED_LOST.getText());
		stagestoExcludeforTotal.add(OpportunityStagesEnum.QUALIFIED.getText());
		return getMappedStages(stagestoExcludeforTotal);
	}

	public static List<String> qualifiedStages(){
		List<String> stagestoExcludeForQualified=new ArrayList<>();
		stagestoExcludeForQualified.add(OpportunityStagesEnum.QUALIFIED.getText());
		return getMappedStages(stagestoExcludeForQualified);
	}
	

	public static List<String> opportunityOpenStages(){
		List<String> openStages=new ArrayList<>();
		openStages.add(OpportunityStagesEnum.OTHERS.getText());
		openStages.add(OpportunityStagesEnum.QUALIFIED.getText());
		return getMappedStages(openStages);
	}
	
	public static List<String> getMappedStages(List<String> stages){
		List<String> mappedStages = new ArrayList<>();
		if(CollectionUtils.isNotEmpty(stages)){
			for(String stage: stages) {
				mappedStages.addAll(appSalesStageContainer.getMappedSaleStage(stage));
			}
		}
		return mappedStages;
	}
	
	
	public static FiscalDatesData getFiscalDatesCalendar(String fiscalStartDate,String fiscalEndDate){
		FiscalDatesData fiscalDates=new FiscalDatesData();
		
		fiscalDates.setFiscalStartDate(MiriDateUtils.parseStrDateToCalendar(fiscalStartDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD));
		fiscalDates.setFiscalEndDate(MiriDateUtils.parseStrDateToCalendar(fiscalEndDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD));
		
		return fiscalDates;
	}
	
	public static FiscalDatesStrData getFiscalDatesStr(Calendar fiscalStartDate,Calendar fiscalEndDate){
		FiscalDatesStrData fiscalDates=new FiscalDatesStrData();
		
		fiscalDates.setFiscalStartDateStr(MiriDateUtils.parseDateToString(fiscalStartDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD));
		fiscalDates.setFiscalEndDateStr(MiriDateUtils.parseDateToString(fiscalEndDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD));
		
		return fiscalDates;
	}
	
	
	public static double removeDecimalPoint(double number) {
		DecimalFormat format = new DecimalFormat("#");
		String str = format.format(number);
		NumberFormat nf = NumberFormat.getInstance();
		double convertedDouble = 0d;
		try {
			convertedDouble =  nf.parse(str).doubleValue();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return convertedDouble;
	}
			
	public static Map<String, Double> sortAndConstructTopMap(Map<String, Double> allCampaignsByRevenue,int size) {
		List<Map.Entry<String, Double>> entries = new ArrayList<>(allCampaignsByRevenue.entrySet());
		
		Collections.sort(entries, new Comparator<Map.Entry<String, Double>>() {
			@Override
			public int compare(Map.Entry<String, Double> arg0, Map.Entry<String, Double> arg1) {
				return -Double.compare(arg0.getValue(), arg1.getValue());
			}
		});
		Map<String, Double> campaigns = new LinkedHashMap<>();
		int index=0;
		for(Map.Entry<String, Double> entry: entries) {
			
			if(index==size){
				break;
			}
			campaigns.put(entry.getKey(), entry.getValue());
			index++;
		}
		return campaigns;
	}
	
	public static Map<Integer,MultipleAxesChartData> populateReturnsPojoResult(Collection<InternalHistogram.Bucket> buckets,
			List<Integer> fiscalMonths){
		
		Map<Integer,MultipleAxesChartData> resultsMap = new LinkedHashMap<Integer, MultipleAxesChartData>();
		MultipleAxesChartData revenuePojo;
		int monthIndex=0;
		
		for (InternalHistogram.Bucket bucket : buckets) {
			revenuePojo = new  MultipleAxesChartData();
			Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			revenuePojo.setxAxis(monthIndex);
			revenuePojo.setRevenueAmount(Math.abs(sum.getValue()));
			revenuePojo.setReturnAmount(Math.abs(sum.getValue()));

			resultsMap.put(monthIndex,revenuePojo);
			monthIndex++;
			
		}
	
		return resultsMap;

	}
	
	
	public static List<String> opportunityWonStages(){
		List<String> wonStages=new ArrayList<>();
		wonStages.add(OpportunityStagesEnum.CLOSED_WON.getText());
		return getMappedStages(wonStages);
	}
	
	public static List<String> opportunityClosedStages(){
		List<String> wonStages=new ArrayList<>();
		wonStages.add(OpportunityStagesEnum.CLOSED_WON.getText());
		wonStages.add(OpportunityStagesEnum.CLOSED_LOST.getText());
		wonStages.add(OpportunityStagesEnum.STAGE_EMPTY.getText());
		return getMappedStages(wonStages);
	}
	
	/**
	 * Get Hits size from the collection. If the collection is empty then default size will be returned
	 * @param collection
	 * @return
	 */
	public static int getHitsSizeFromCollection(final Collection<?> collection) {
		int hitsSize = 10;
		if(CollectionUtils.isNotEmpty(collection)) {
			hitsSize = collection.size();
		}
		return hitsSize;
	}
	
	/**
	 * Get Product Name as List
	 * @param topProductOrLevelItems
	 * @return
	 */
	public static List<String> getProductIdsAsList(final List<TopProductData> topProductOrLevelItems) {
		List<String> productIds = new ArrayList<>();
		for(TopProductData topProductData: topProductOrLevelItems) {
			if(topProductData != null) {
				productIds.add(topProductData.getId());
			}
		}
		return productIds;
	}

	/**
	 * Get Product Name as List
	 * @param topProductOrLevelItems
	 * @return
	 */
	public static List<String> getProductNamesAsList(final List<TopProductData> topProductOrLevelItems) {
		List<String> product = new ArrayList<>();
		for(TopProductData topProductData: topProductOrLevelItems) {
			if(topProductData != null) {
				product.add(topProductData.getName());
			}
		}
		return product;
	}
	
	/**
	 * Get Product Name as List
	 * @param topProductOrLevelItems
	 * @return
	 */
	public static List<String> getProductNamesAsListFrmCollection(final List<TopProductsDataPojo> topProductOrLevelItems) {
		List<String> product = new ArrayList<>();
		for(TopProductsDataPojo topProductData: topProductOrLevelItems) {
			if(topProductData != null) {
				product.add(topProductData.getProductName());
			}
		}
		return product;
	}
	
	/**
	 * Get Top product data sorted based on the revenue amount
	 * @param productData
	 * @return
	 */
	public static List<TopProductData> getTopProductData(List<TopProductData> productData, final int size) {
		List<TopProductData> sortedProductData = sortTopProductData(productData);
		if(sortedProductData.size() > size) {
			return sortedProductData.subList(0, size);
		} else {
			return sortedProductData;
		}
	}
	
	/**
	 * Sort the Top Product data in descending order of revenue
	 * @param topProductData
	 * @return
	 */
	public static List<TopProductData> sortTopProductData(List<TopProductData> topProductData) {
		Collections.sort(topProductData, new Comparator<TopProductData>() {
			@Override
			public int compare(TopProductData topProductData1, TopProductData topProductData2) {
				if((topProductData1 == null) || (topProductData1 != null && topProductData1.getValue() == null)) {
					return -1;
				} else if((topProductData2 == null) || (topProductData2 != null && topProductData2.getValue() == null)) {
					return 1;
				} else {
					return Double.compare(topProductData2.getValue(), topProductData1.getValue());
				}
			}
		});
		return topProductData;
	}
	
	/**
	 * Get Buckets from aggregations
	 * @param aggregations
	 * @param aggregationName
	 * @return
	 */
	public static List<Terms.Bucket> getBuckets(final Aggregations aggregations, final String aggregationName) {
		if(aggregations != null) {
			Terms levelOneTerms = aggregations.get(aggregationName);
			if(levelOneTerms != null) {
				return levelOneTerms.getBuckets();
			}
		} 
		return new ArrayList<>();
	}
}