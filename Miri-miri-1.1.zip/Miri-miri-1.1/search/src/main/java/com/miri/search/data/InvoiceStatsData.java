package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

/**
 * Invoice Statistics like Revenue Amount, Deals Closed, Average Deal Size, Average Sell Price and valid opportunities
 * @author rammoole
 *
 */
public class InvoiceStatsData implements Serializable {
	
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 6809554775808301740L;
	private Double revenueAmount;
	private Long dealsClosed;
	private Double ads;
	private Double asp;
	private Long count;
	private List<String> validOpportunities;
	private Long avgCreationTme;
	private double productQuantity;
	/**
	 * @return the revenueAmount
	 */
	public Double getRevenueAmount() {
		return revenueAmount;
	}
	/**
	 * @param revenueAmount the revenueAmount to set
	 */
	public void setRevenueAmount(Double revenueAmount) {
		this.revenueAmount = revenueAmount;
	}
	/**
	 * @return the dealsClosed
	 */
	public Long getDealsClosed() {
		return dealsClosed;
	}
	/**
	 * @param dealsClosed the dealsClosed to set
	 */
	public void setDealsClosed(Long dealsClosed) {
		this.dealsClosed = dealsClosed;
	}
	/**
	 * @return the ads
	 */
	public Double getAds() {
		return ads;
	}
	/**
	 * @param ads the ads to set
	 */
	public void setAds(Double ads) {
		this.ads = ads;
	}
	/**
	 * @return the asp
	 */
	public Double getAsp() {
		return asp;
	}
	/**
	 * @param asp the asp to set
	 */
	public void setAsp(Double asp) {
		this.asp = asp;
	}
	/**
	 * @return the validOpportunities
	 */
	public List<String> getValidOpportunities() {
		return validOpportunities;
	}
	/**
	 * @param validOpportunities the validOpportunities to set
	 */
	public void setValidOpportunities(List<String> validOpportunities) {
		this.validOpportunities = validOpportunities;
	}
	/**
	 * @return the count
	 */
	public Long getCount() {
		return count;
	}
	/**
	 * @param count the count to set
	 */
	public void setCount(Long count) {
		this.count = count;
	}
	/**
	 * @return the avgCreationTme
	 */
	public Long getAvgCreationTme() {
		return avgCreationTme;
	}
	/**
	 * @param avgCreationTme the avgCreationTme to set
	 */
	public void setAvgCreationTme(Long avgCreationTme) {
		this.avgCreationTme = avgCreationTme;
	}
	/**
	 * @return the productQuantity
	 */
	public double getProductQuantity() {
		return productQuantity;
	}
	/**
	 * @param productQuantity the productQuantity to set
	 */
	public void setProductQuantity(double productQuantity) {
		this.productQuantity = productQuantity;
	}
}
