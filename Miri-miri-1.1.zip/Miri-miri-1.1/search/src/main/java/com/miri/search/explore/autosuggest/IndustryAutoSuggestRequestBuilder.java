/**
 * 
 */
package com.miri.search.explore.autosuggest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.CRMConstants;
import com.miri.search.explore.autosuggest.AutoSuggestRequest.RequestItem;

/**
 * @author Chandra
 *
 */
@Component
public class IndustryAutoSuggestRequestBuilder extends AutoSuggestRequestBuilder {

	private static List<RequestItem> requestItems = new ArrayList<>();

	{
		// Map campaign
		if (requestItems.size() == 0) {
			RequestItem item = new RequestItem();

			List<String> fields = new ArrayList<>();
			fields.add(CRMConstants.OPPORTUNITY_INDUSTRY);
			item.setDocType(ElasticSearchEnums.CRM_OPPORTUNITY.getText());
			item.setFields(fields);
			requestItems.add(item);
		}
	}

	@Override
	public void buildAutoSuggestRequest() {
		autoSuggestRequest.setRequestItems(requestItems);

	}

}
