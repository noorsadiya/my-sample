
package com.miri.search.utils;

import java.math.BigDecimal;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * Miri Number Utils
 * @author Noor
 *
 */
public final class MiriNumberUtils {

	private static final Logger LOG = LogManager.getLogger(MiriNumberUtils.class);

	public static BigDecimal createBigInteger(Object numberValue){
		BigDecimal returnValue=new BigDecimal("0");
		
		if(numberValue!=null){
			String parsedString=numberValue.toString();
			returnValue=new  BigDecimal(parsedString);
		}
		
		return returnValue;
	}
	public static Double createDouble(Object numberValue){
		Double returnValue=new Double("0");
		
		if(numberValue!=null){
			String parsedString=numberValue.toString();
			returnValue=new  Double(parsedString);
		}
		
		return returnValue;
	}
}