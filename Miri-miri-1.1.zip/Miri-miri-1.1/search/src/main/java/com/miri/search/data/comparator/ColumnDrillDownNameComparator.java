package com.miri.search.data.comparator;

import java.util.Comparator;

import com.miri.search.data.ColumnDrillDownData;

public class ColumnDrillDownNameComparator implements Comparator<ColumnDrillDownData> {

	@Override
	public int compare(ColumnDrillDownData o1, ColumnDrillDownData o2) {
		
		if (null == o1.getName() && null == o2.getName())
			return 0;

		if (null != o2.getName() && null == o1.getName())
			return 1;

		if (null == o2.getName() && null != o1.getName())
			return -1;

		return o2.getName().compareTo(o1.getName());
	}

}
