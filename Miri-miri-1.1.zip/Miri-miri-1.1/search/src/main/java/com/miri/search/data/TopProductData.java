package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

/**
 * Top Products Data
 * @author Mohan
 *
 */
public class TopProductData implements Serializable {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -6109557003566545329L;
	
	private String id;
	private String name;
	private Double value;
	private Integer wonCount;
	private Double avgDealSize;
	private Double avgSellPrice;
	private String productName;
	private List<TopProductData> topProductInfo;
	private Long dealsClosed;
	private double invoiceCount;
	private List<String> opportunities;
	
	public List<String> getOpportunities() {
		return opportunities;
	}
	
	public void setOpportunities(List<String> opportunities) {
		this.opportunities = opportunities;
	}
	
	
	public double getInvoiceCount() {
		return invoiceCount;
	}
	
	public void setInvoiceCount(double invoiceCount) {
		this.invoiceCount = invoiceCount;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getDealsClosed() {
		return dealsClosed;
	}

	public void setDealsClosed(Long dealsClosed) {
		this.dealsClosed = dealsClosed;
	}

	public String getProductName() {
		return productName;
	}
	
	public void setProductName(String productName) {
		this.productName = productName;
	}

	private Integer numberOfProducts;

	public Integer getNumberOfProducts() {
		return numberOfProducts;
	}

	public void setNumberOfProducts(Integer numberOfProducts) {
		this.numberOfProducts = numberOfProducts;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	public Integer getWonCount() {
		return wonCount;
	}

	public void setWonCount(Integer wonCount) {
		this.wonCount = wonCount;
	}

	public Double getAvgDealSize() {
		return avgDealSize;
	}

	public void setAvgDealSize(Double avgDealSize) {
		this.avgDealSize = avgDealSize;
	}

	public Double getAvgSellPrice() {
		return avgSellPrice;
	}

	public void setAvgSellPrice(Double avgSellPrice) {
		this.avgSellPrice = avgSellPrice;
	}

	public List<TopProductData> getTopProductInfo() {
		return topProductInfo;
	}

	public void setTopProductInfo(List<TopProductData> topProductInfo) {
		this.topProductInfo = topProductInfo;
	}

}
