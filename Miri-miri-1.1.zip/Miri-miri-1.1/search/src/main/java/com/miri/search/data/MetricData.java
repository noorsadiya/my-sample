package com.miri.search.data;

import java.io.Serializable;

/**
 * 
 * @author Noor
 *
 */
public class MetricData  implements Serializable{
	
	private Object y;
	private Object z;
	private Object x;
	private Object data;

	private String id;
	private String name;
	private String drillDown;
	private String customerName;
	
	//Hover data	
	private double revenueAmount;
	private double averageDealSize;
	private double averageSellPrice;
	private double dealsClosed;
	
	
	public Object getY() {
		return y;
	}
	public void setY(Object y) {
		this.y = y;
	}
	public Object getZ() {
		return z;
	}
	public void setZ(Object z) {
		this.z = z;
	}
	public Object getX() {
		return x;
	}
	public void setX(Object x) {
		this.x = x;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDrillDown() {
		return drillDown;
	}
	public void setDrillDown(String drillDown) {
		this.drillDown = drillDown;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getRevenueAmount() {
		return revenueAmount;
	}
	public void setRevenueAmount(double revenueAmount) {
		this.revenueAmount = revenueAmount;
	}
	public double getAverageDealSize() {
		return averageDealSize;
	}
	public void setAverageDealSize(double averageDealSize) {
		this.averageDealSize = averageDealSize;
	}
	public double getAverageSellPrice() {
		return averageSellPrice;
	}
	public void setAverageSellPrice(double averageSellPrice) {
		this.averageSellPrice = averageSellPrice;
	}
	public double getDealsClosed() {
		return dealsClosed;
	}
	public void setDealsClosed(double dealsClosed) {
		this.dealsClosed = dealsClosed;
	}
	
	@Override
	public String toString() {
		return "MetricDomain [y=" + y + ", z=" + z + ", x=" + x + ", data=" + data + ", id=" + id + ", name=" + name
				+ ", drillDown=" + drillDown + ", customerName=" + customerName + ", revenueAmount=" + revenueAmount
				+ ", averageDealSize=" + averageDealSize + ", averageSellPrice=" + averageSellPrice + ", dealsClosed="
				+ dealsClosed + "]";
	}
	
}
