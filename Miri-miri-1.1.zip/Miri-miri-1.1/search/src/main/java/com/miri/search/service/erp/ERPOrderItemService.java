package com.miri.search.service.erp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.ErpOrderItem;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;


/**
 * Services pertaining to erp/erp_order_item document in elastic search
 * 
 * @author shipenme
 *
 */


@Service
public class ERPOrderItemService extends MiriSearchService {

	private static final Logger LOG = LogManager.getLogger(ERPOrderItemService.class);
	
	@Autowired
	private ESQueryUtils esQueryUtils;
	@Override
	public String getIndex() {

		return ElasticSearchEnums.ERP.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.ERP_ORDER_ITEM.getText();
	}


	/**
	 * 
	 * Gets the ErpOrderItem by provided orderItemId
	 * @param orderItemId 
	 * @return - ErpOrderItem
	 * 
	 */
	public ErpOrderItem getErpOrderItemById(String orderItemId){

		LOG.info("getErpOrderItemById().......");

		GetResponse response = getTransportClient().prepareGet(getIndex(), getDocumentType(), orderItemId).get();

		ErpOrderItem erpOrderItem = (ErpOrderItem) ESObjectMapper.getObject(response.getSource(), getIndex(), getIndex());

		LOG.info("ErpOrderItem "+erpOrderItem+" by "+orderItemId);
		return erpOrderItem;

	}

	/**
	 * 
	 * Gets the ErpOrderItem by provided orderItemId
	 * @param orderItemId 
	 * @return - ErpOrderItem
	 * 
	 */
	public String getItemNameByItemId(String itemId){

		String productName = null;
		
		TermQueryBuilder termQuery = QueryBuilders.termQuery(ERPConstants.ORDER_ITEM_ID_RAW, itemId);

		SearchResponse searchResponse = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setQuery(termQuery).setSize(1).execute().actionGet();
		
		if(searchResponse != null){
			SearchHit[] hits = searchResponse.getHits().getHits();
			for(SearchHit hit: hits){
				productName = (String) hit.getSource().get(ERPConstants.ORDER_ITEM_NAME);
			}
		}
		
		return productName;
	}

	/**
	 * Gets the orderItemName by provided item ids 
	 * 
	 * @param orderItemIds
	 * @return Map of itemIds and itemNames
	 * 
	 */
	public Map<String,String> getItemNamesByItemIds(List<String> orderItemIds){

		Map<String,String> orderItemIdsAndNames = new HashMap<String,String>();

		BoolQueryBuilder boolQueryBuilder = MiriSearchUtils.createBoolQueryBuilder(ERPConstants.ORDER_ITEM_ID_RAW, orderItemIds, 1000);

		SearchResponse searchRespose = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSearchType(SearchType.DEFAULT)
				.setQuery(boolQueryBuilder)
				.setSize(1010).execute().actionGet();


		for(SearchHit searchHit: searchRespose.getHits().getHits()) {

			Map<String,Object> result = searchHit.getSource();

			String key = (String)result.get(ERPConstants.ORDER_ITEM_ID);
			String value = (String)result.get(ERPConstants.ORDER_ITEM_NAME);

			orderItemIdsAndNames.put(key, value);

		}

		return orderItemIdsAndNames;
	}

	/**
	 * Gets the orderItemName and Revenue amount
	 * 
	 * @param orderItemIds
	 * @return List of ItemNames and Revenue amount
	 * 
	 */
	public List<ErpOrderItem> getItemNamesAndRevenueByItemIds(List<String> orderItemIds){


		List<ErpOrderItem> erpOrderItemsList = new ArrayList<ErpOrderItem>();
		ErpOrderItem orderItem=null;


		TermsQueryBuilder boolQueryBuilder = QueryBuilders.termsQuery(ERPConstants.ORDER_ITEM_ID_RAW, orderItemIds);
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.setQuery(boolQueryBuilder)
				.setSize(1010);
		
		SearchResponse searchRespose = esQueryUtils.execute(searchRequestBuilder);

		
		for(SearchHit searchHit: searchRespose.getHits().getHits()) {

			Map<String,Object> result = searchHit.getSource();

			 orderItem = new ErpOrderItem();
			orderItem.setItemId((String)result.get(ERPConstants.ORDER_ITEM_ID));
			orderItem.setItemName((String)result.get(ERPConstants.ORDER_ITEM_NAME));
			orderItem.setQuantity(Integer.parseInt((String)result.get(ERPConstants.ORDER_ITEM_QUANTITY)));
			orderItem.setTotalValue(Double.parseDouble(result.get(ERPConstants.ORDER_ITEM_TOTAL_VALUE).toString()));

			erpOrderItemsList.add(orderItem);
		}

		return erpOrderItemsList;
	}
	
	/**
	 * 
	 * Gets the ErpOrderItem by provided ItemId
	 * @param ItemId 
	 * @return - ErpOrderItem
	 * 
	 */
	public ErpOrderItem getErpOrderItemByItemId(String itemId){

		LOG.info("getErpOrderItemItemId().......");

		ErpOrderItem erpOrderItem = (ErpOrderItem)
	    esQueryUtils.getUniqueDocumentByDocId(getDocumentType(),getIndex(),SearchConstants.ITEM_ID_RAW, itemId);
		return erpOrderItem;

	}
	
	
	

}
