package com.miri.search.dynamicIndexServices.crm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.children.ChildrenBuilder;
import org.elasticsearch.search.aggregations.bucket.children.InternalChildren;
import org.elasticsearch.search.aggregations.bucket.filter.Filter;
import org.elasticsearch.search.aggregations.bucket.filter.FilterAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Order;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.data.jpa.util.AppSalesStageContainer;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.ColumnBasicData;
import com.miri.search.data.SalesPersonRevenueData;
import com.miri.search.data.TopProductData;
import com.miri.search.dynamicIndexServices.MappedConstants;
import com.miri.search.service.common.MiriSearchService;

@Component
public class WinLossTrenAnalysisService extends MiriSearchService{
	
	//public static final String OPPORTUNITY_COMPETITOR_RAW = "competitor.raw";
	
	@Autowired
	AppSalesStageContainer appSalesStageContainer;
	
	@Autowired
	TopProductsByRevenueService productService;

	@Override
	public String getIndex() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDocumentType() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public Map<String, Double> getTopCompetitors(String startDate, String endDate, int size){
		Map<String, Double> topCompetitors =  new HashMap<String, Double>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate));	
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(CRMConstants.COMPETITOR_RAW, ""));
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(parentSumBuilder);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.ERP_OPPORTUNITY_COMPETITOR_AGGREGATION)
				.field(CRMConstants.COMPETITOR_RAW).subAggregation(parentBuilder).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">" +SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		InternalChildren internalChildren = null;
		Sum sum = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.ERP_OPPORTUNITY_COMPETITOR_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				revenue = sum.getValue();
				if(revenue > 0){
					topCompetitors.put(termBucket.getKey(), revenue);
				}
			}
		}
		return topCompetitors;
	}
	
	private SearchRequestBuilder getCompetitorsWinLossData(String startDate, String endDate, List<String> competitors, int size){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.COMPETITOR_RAW, competitors));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate));
		List<String> lostStages = appSalesStageContainer.getClosedLostMappedStages();
	
		SumBuilder lostSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_AMOUNT);
		
		FilterAggregationBuilder lostfilterdAggregation = AggregationBuilders.filter(MappedConstants.FILTERED_AGGREGATION)
				.filter(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, lostStages))
				.subAggregation(lostSumBuilder);
		
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		
		SumBuilder wonSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		
		
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				  .childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(wonSumBuilder).subAggregation(opportunityAggregation);
		
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.ERP_OPPORTUNITY_COMPETITOR_AGGREGATION)
				.field(CRMConstants.COMPETITOR_RAW).subAggregation(lostfilterdAggregation).subAggregation(childrenBuilder).size(size);
		
		return this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
	
	}
	
	public Map<String, Object> getTopCompetitorsWinLossData(String startDate, String endDate, List<String> competitors, int size){
		
		SearchRequestBuilder searchRequestBuilder = getCompetitorsWinLossData(startDate, endDate, competitors, size);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		ColumnBasicData wonColumnBasicData = new ColumnBasicData();
		ColumnBasicData lostColumnBasicData = new ColumnBasicData();
		List<SalesPersonRevenueData> wonData = new ArrayList<>();
		List<SalesPersonRevenueData> lostData = new ArrayList<>();
		List<String> competitorData = new ArrayList<>();
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations()
					.get(SearchConstants.ERP_OPPORTUNITY_COMPETITOR_AGGREGATION);
			Collection<Terms.Bucket> termsBuckets = terms.getBuckets();
			SalesPersonRevenueData wonRevenueData;
			SalesPersonRevenueData lostRevenueData;
			for (Terms.Bucket termBucket : termsBuckets) {
				if (termBucket.getAggregations() != null) {
					wonRevenueData = new SalesPersonRevenueData();
					lostRevenueData = new SalesPersonRevenueData();
					Filter losrTerms = termBucket.getAggregations()
							.get(MappedConstants.FILTERED_AGGREGATION);
					int lostCount = (int) losrTerms.getDocCount();
					Sum lostSum = losrTerms.getAggregations().get(SearchConstants.SUM_AGGREGATION);
					InternalChildren grandChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
					Sum WonSum = grandChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
					Terms opportunityTerms = grandChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
					Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
					int wonCount = opportunityBuckets.size();
					int totalDeals = wonCount + lostCount;
					double lostPercentage;
					double winPercentage;
					if(totalDeals > 0) {
						winPercentage = ((double) wonCount / totalDeals)  * 100;
						lostPercentage = ((double) lostCount / totalDeals)  * 100;
					} else {
						winPercentage = 0;
						lostPercentage = 0;
					}
					wonRevenueData.setxAxisParam(winPercentage);
					wonRevenueData.setNoOfDealsClosed((long) wonCount);
					wonRevenueData.setWonAmount(WonSum.getValue());
					wonRevenueData.setWinRate(winPercentage);
					wonRevenueData.setxAxisLabel(termBucket.getKey());
					wonData.add(wonRevenueData);
					
					lostRevenueData.setxAxisParam(lostPercentage);
					lostRevenueData.setNoOfDealsLost((long) lostCount);
					lostRevenueData.setLostAmount(lostSum.getValue());
					lostRevenueData.setLostRate(lostPercentage);
					lostRevenueData.setxAxisLabel(termBucket.getKey());
					lostData.add(lostRevenueData);
					competitorData.add(termBucket.getKey());
				}
			}
		}
		wonColumnBasicData.setSalesPersonRevenue(wonData);
		wonColumnBasicData.setName(SearchConstants.WON);
		
		lostColumnBasicData.setSalesPersonRevenue(lostData);
		lostColumnBasicData.setName(SearchConstants.LOST);
		
		Map<String, Object> finalResult = new HashMap<>();
		finalResult.put(SearchConstants.DATA, Arrays.asList(wonColumnBasicData, lostColumnBasicData));
		finalResult.put(SearchConstants.X_AXIS_DATA, competitorData);
		return finalResult;
	}
	
	public Map<String, Object> getTopCompetitorsWinLossExcelData(String startDate, String endDate, List<String> competitors, int size){
		
		SearchRequestBuilder searchRequestBuilder = getCompetitorsWinLossData(startDate, endDate, competitors, size);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		Map<String, SalesPersonRevenueData> wonData = new HashMap<>();
		Map<String, SalesPersonRevenueData> lostData = new HashMap<>();
		
		List<String> competitorData = new ArrayList<>();
		
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations()
					.get(SearchConstants.ERP_OPPORTUNITY_COMPETITOR_AGGREGATION);
			Collection<Terms.Bucket> termsBuckets = terms.getBuckets();
			SalesPersonRevenueData wonRevenueData;
			SalesPersonRevenueData lostRevenueData;

			for (Terms.Bucket termBucket : termsBuckets) {
				if (termBucket.getAggregations() != null) {
					wonRevenueData = new SalesPersonRevenueData();
					lostRevenueData = new SalesPersonRevenueData();
			
					Filter losrTerms = termBucket.getAggregations().get(MappedConstants.FILTERED_AGGREGATION);
					
					int lostCount = (int) losrTerms.getDocCount();
					Sum lostSum = losrTerms.getAggregations().get(SearchConstants.SUM_AGGREGATION);
					InternalChildren grandChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
					Sum WonSum = grandChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
					Terms opportunityTerms = grandChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
					Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
					int wonCount = opportunityBuckets.size();
					int totalDeals = wonCount + lostCount;
					double lostPercentage;
					double winPercentage;
					
					if(totalDeals > 0) {
						winPercentage = ((double) wonCount / totalDeals)  * 100;
						lostPercentage = ((double) lostCount / totalDeals)  * 100;
					} else {
						winPercentage = 0;
						lostPercentage = 0;
					}
					wonRevenueData.setxAxisParam(winPercentage);
					wonRevenueData.setNoOfDealsClosed((long) wonCount);
					wonRevenueData.setWonAmount(WonSum.getValue());
					wonRevenueData.setWinRate(winPercentage);
					wonRevenueData.setxAxisLabel(termBucket.getKey());
					wonData.put(termBucket.getKey(), wonRevenueData);
					
					lostRevenueData.setxAxisParam(lostPercentage);
					lostRevenueData.setNoOfDealsLost((long) lostCount);
					lostRevenueData.setLostAmount(lostSum.getValue());
					lostRevenueData.setLostRate(lostPercentage);
					lostRevenueData.setxAxisLabel(termBucket.getKey());
					lostData.put(termBucket.getKey(), lostRevenueData);
					
					competitorData.add(termBucket.getKey());
				}
			}
		}
		
		Map<String, Object> finalResult = new HashMap<>();
		finalResult.put(SearchConstants.WON, wonData);
		finalResult.put(SearchConstants.LOST, lostData);
		finalResult.put(SearchConstants.DATA, competitorData);
		return finalResult;
	}
	
	private SearchRequestBuilder getCompetitorsWinLossDataByFields(String startDate, String endDate, List<String> competitors, int size, String field){
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.COMPETITOR_RAW, competitors));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(field, ""));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(CRMConstants.COMPETITOR_RAW, ""));
		List<String> lostStages = appSalesStageContainer.getClosedLostMappedStages();
		
		SumBuilder lostSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_AMOUNT);
		
		TermsBuilder fieldAggregation = AggregationBuilders.terms(SearchConstants.FIELD_AGGREGATION)
				.field(field).subAggregation(lostSumBuilder).size(size).order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false));
		
		FilterAggregationBuilder lostfilterdAggregation = AggregationBuilders.filter(MappedConstants.FILTERED_AGGREGATION)
				.filter(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, lostStages))
				.subAggregation(fieldAggregation);
		
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		
		SumBuilder wonSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				  .childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(wonSumBuilder).subAggregation(opportunityAggregation);
		
		TermsBuilder wonFieldAggregation = AggregationBuilders.terms(SearchConstants.FIELD_AGGREGATION)
				.field(field).size(size).subAggregation(childrenBuilder).order(Order.aggregation(MappedConstants.CHILDREN + ">" +SearchConstants.SUM_AGGREGATION, false));
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.ERP_OPPORTUNITY_COMPETITOR_AGGREGATION)
				.field(CRMConstants.COMPETITOR_RAW).subAggregation(lostfilterdAggregation).size(size).subAggregation(wonFieldAggregation);
		
		return this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);

	}
	
	public Map<String, Object> getTopCompetitorsWinLossExcelDataByFields(String startDate, String endDate, List<String> competitors, int size, String field){
		
		SearchRequestBuilder searchRequestBuilder = getCompetitorsWinLossDataByFields(startDate, endDate, competitors, size, field);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		Map<String, Object> winLossData = new HashMap<String, Object>();
		
		Map<String, List<SalesPersonRevenueData>> winData = new HashMap<String, List<SalesPersonRevenueData>>();
		Map<String, List<SalesPersonRevenueData>> lostData = new HashMap<String, List<SalesPersonRevenueData>>();
		
		List<String> data = new ArrayList<>();
		List<SalesPersonRevenueData> winDataList = null;
		List<SalesPersonRevenueData> lossDataList = null;
		
		double winPercentage = 0;
		double lostPercentage = 0;
		
		if (searchResponse.getAggregations() != null) {
			
			Terms terms = searchResponse.getAggregations()
					.get(SearchConstants.ERP_OPPORTUNITY_COMPETITOR_AGGREGATION);
		
			Collection<Terms.Bucket> termsBuckets = terms.getBuckets();
			
			SalesPersonRevenueData wonRevenueData;
			SalesPersonRevenueData lostRevenueData;
			
			for (Terms.Bucket termBucket : termsBuckets) {
				
				if (termBucket.getAggregations() != null) {
					int totalDealsPerCompetitor = (int) termBucket.getDocCount();
					Filter fieldTerms = termBucket.getAggregations().get(MappedConstants.FILTERED_AGGREGATION);
					
					Terms lostTerms = fieldTerms.getAggregations().get(SearchConstants.FIELD_AGGREGATION);
					Collection<Terms.Bucket> lostTermBuckets = lostTerms.getBuckets();
					
					lossDataList = new ArrayList<SalesPersonRevenueData>();
					
					for (Terms.Bucket lostTermBucket : lostTermBuckets) {
						lostRevenueData = new SalesPersonRevenueData();
						if(totalDealsPerCompetitor != 0) {
							lostPercentage = ((double) fieldTerms.getDocCount()/ totalDealsPerCompetitor)  * 100;
						} else {
							lostPercentage = 0;
						}
						Sum lostAmount = lostTermBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
						lostRevenueData.setxAxisParam(lostPercentage);
						lostRevenueData.setNoOfDealsLost(fieldTerms.getDocCount());
						lostRevenueData.setLostAmount(lostAmount.getValue());
						lostRevenueData.setLostRate(lostPercentage);
						if(field.equals(CRMConstants.OPPORTUNITY_INDUSTRY_RAW)){
							lostRevenueData.setIndustryName(lostTermBucket.getKey());
						}
						if(field.equals(CRMConstants.OPPORTUNITY_OWNER_RAW)){
							lostRevenueData.setSalesPersonName(lostTermBucket.getKey());
						}
						if(field.equals(CRMConstants.OPPORTUNITY_TYPE_RAW)){
							lostRevenueData.setOpportunityType(lostTermBucket.getKey());
						}
						if(field.equals(CRMConstants.ACCOUNT_NAME_RAW)){
							lostRevenueData.setCustomerName(lostTermBucket.getKey());
						}
						if(field.equals(CRMConstants.OPPORTUNITY_COUNTRY_RAW)){
							lostRevenueData.setCountry(lostTermBucket.getKey());
						}
						if(field.equals(CRMConstants.CAMPAIGN_NAME_RAW)){
							lostRevenueData.setCampaignName(lostTermBucket.getKey());
						}
						
						lossDataList.add(lostRevenueData);
					}
					
					Terms wonTerms = termBucket.getAggregations().get(SearchConstants.FIELD_AGGREGATION);
					Collection<Terms.Bucket> wonTermBuckets = wonTerms.getBuckets();

					winDataList = new ArrayList<SalesPersonRevenueData>();
					
					for (Terms.Bucket wonTermBucket : wonTermBuckets) {
						wonRevenueData = new SalesPersonRevenueData();
						InternalChildren internalChildren = wonTermBucket.getAggregations().get(MappedConstants.CHILDREN);
						Sum wonAmount = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
						Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
						Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
						long wonCount = opportunityBuckets.size();
						if(totalDealsPerCompetitor != 0) {
							winPercentage = ((double) wonCount/ totalDealsPerCompetitor)  * 100;
						} else {
							winPercentage = 0;
						}
						wonRevenueData.setxAxisParam(winPercentage);
						wonRevenueData.setNoOfDealsClosed(wonCount);
						wonRevenueData.setWonAmount(wonAmount.getValue());
						wonRevenueData.setWinRate(winPercentage);
						wonRevenueData.setxAxisLabel(termBucket.getKey());
						if(field.equals(CRMConstants.OPPORTUNITY_INDUSTRY_RAW)){
							wonRevenueData.setIndustryName(wonTermBucket.getKey());
						}
						if(field.equals(CRMConstants.OPPORTUNITY_OWNER_RAW)){
							wonRevenueData.setSalesPersonName(wonTermBucket.getKey());
						}
						if(field.equals(CRMConstants.OPPORTUNITY_TYPE_RAW)){
							wonRevenueData.setOpportunityType(wonTermBucket.getKey());
						}
						if(field.equals(CRMConstants.ACCOUNT_NAME_RAW)){
							wonRevenueData.setCustomerName(wonTermBucket.getKey());
						}
						if(field.equals(CRMConstants.OPPORTUNITY_COUNTRY_RAW)){
							wonRevenueData.setCountry(wonTermBucket.getKey());
						}
						if(field.equals(CRMConstants.CAMPAIGN_NAME_RAW)){
							wonRevenueData.setCampaignName(wonTermBucket.getKey());
						}
						
						winDataList.add(wonRevenueData);						
					}
					
					data.add(termBucket.getKey());
					winData.put(termBucket.getKey(), winDataList);
					lostData.put(termBucket.getKey(), lossDataList);
				}
			}
		}
		
		winLossData.put(SearchConstants.WON, winData);
		winLossData.put(SearchConstants.LOST, lostData);
		winLossData.put(SearchConstants.DATA, data);

		return winLossData;
	}

	
	public Map<String, Object> getTopCompetitorsWinLossDataByFields(String startDate, String endDate, List<String> competitors, int size, String field){
		
		SearchRequestBuilder searchRequestBuilder = getCompetitorsWinLossDataByFields(startDate, endDate, competitors, size, field);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		ColumnBasicData wonColumnBasicData = new ColumnBasicData();
		ColumnBasicData lostColumnBasicData = new ColumnBasicData();
		List<SalesPersonRevenueData> wonData = new ArrayList<>();
		List<SalesPersonRevenueData> lostData = new ArrayList<>();
		List<String> competitorData = new ArrayList<>();
		double winPercentage = 0;
		double lostPercentage = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations()
					.get(SearchConstants.ERP_OPPORTUNITY_COMPETITOR_AGGREGATION);
			Collection<Terms.Bucket> termsBuckets = terms.getBuckets();
			SalesPersonRevenueData wonRevenueData;
			SalesPersonRevenueData lostRevenueData;
			for (Terms.Bucket termBucket : termsBuckets) {
				if (termBucket.getAggregations() != null) {
					int totalDealsPerCompetitor = (int) termBucket.getDocCount();
					Filter fieldTerms = termBucket.getAggregations().get(MappedConstants.FILTERED_AGGREGATION);
					Terms lostTerms = fieldTerms.getAggregations().get(SearchConstants.FIELD_AGGREGATION);
					Collection<Terms.Bucket> lostTermBuckets = lostTerms.getBuckets();
					for (Terms.Bucket lostTermBucket : lostTermBuckets) {
						lostRevenueData = new SalesPersonRevenueData();
						if(totalDealsPerCompetitor != 0) {
							lostPercentage = ((double) fieldTerms.getDocCount()/ totalDealsPerCompetitor)  * 100;
						} else {
							lostPercentage = 0;
						}
						Sum lostAmount = lostTermBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
						lostRevenueData.setxAxisParam(lostPercentage);
						lostRevenueData.setNoOfDealsLost(fieldTerms.getDocCount());
						lostRevenueData.setLostAmount(lostAmount.getValue());
						lostRevenueData.setLostRate(lostPercentage);
						if(field.equals(CRMConstants.OPPORTUNITY_INDUSTRY_RAW)){
							lostRevenueData.setIndustryName(lostTermBucket.getKey());
						}
						if(field.equals(CRMConstants.OPPORTUNITY_OWNER_RAW)){
							lostRevenueData.setSalesPersonName(lostTermBucket.getKey());
						}
						if(field.equals(CRMConstants.OPPORTUNITY_TYPE_RAW)){
							lostRevenueData.setOpportunityType(lostTermBucket.getKey());
						}
						if(field.equals(CRMConstants.ACCOUNT_NAME_RAW)){
							lostRevenueData.setCustomerName(lostTermBucket.getKey());
						}
						if(field.equals(CRMConstants.OPPORTUNITY_COUNTRY_RAW)){
							lostRevenueData.setCountry(lostTermBucket.getKey());
						}
						if(field.equals(CRMConstants.CAMPAIGN_NAME_RAW)){
							lostRevenueData.setCampaignName(lostTermBucket.getKey());
						}
						
						lostRevenueData.setxAxisLabel(termBucket.getKey());
						lostData.add(lostRevenueData);
					}
					Terms wonTerms = termBucket.getAggregations().get(SearchConstants.FIELD_AGGREGATION);
					Collection<Terms.Bucket> wonTermBuckets = wonTerms.getBuckets();
					for (Terms.Bucket wonTermBucket : wonTermBuckets) {
						wonRevenueData = new SalesPersonRevenueData();
						InternalChildren internalChildren = wonTermBucket.getAggregations().get(MappedConstants.CHILDREN);
						Sum wonAmount = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
						Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
						Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
						long wonCount = opportunityBuckets.size();
						if(totalDealsPerCompetitor != 0) {
							winPercentage = ((double) wonCount/ totalDealsPerCompetitor)  * 100;
						} else {
							winPercentage = 0;
						}
						wonRevenueData.setxAxisParam(winPercentage);
						wonRevenueData.setNoOfDealsClosed(wonCount);
						wonRevenueData.setWonAmount(wonAmount.getValue());
						wonRevenueData.setWinRate(winPercentage);
						wonRevenueData.setxAxisLabel(termBucket.getKey());
						if(field.equals(CRMConstants.OPPORTUNITY_INDUSTRY_RAW)){
							wonRevenueData.setIndustryName(wonTermBucket.getKey());
						}
						if(field.equals(CRMConstants.OPPORTUNITY_OWNER_RAW)){
							wonRevenueData.setSalesPersonName(wonTermBucket.getKey());
						}
						if(field.equals(CRMConstants.OPPORTUNITY_TYPE_RAW)){
							wonRevenueData.setOpportunityType(wonTermBucket.getKey());
						}
						if(field.equals(CRMConstants.ACCOUNT_NAME_RAW)){
							wonRevenueData.setCustomerName(wonTermBucket.getKey());
						}
						if(field.equals(CRMConstants.OPPORTUNITY_COUNTRY_RAW)){
							wonRevenueData.setCountry(wonTermBucket.getKey());
						}
						if(field.equals(CRMConstants.CAMPAIGN_NAME_RAW)){
							wonRevenueData.setCampaignName(wonTermBucket.getKey());
						}
						wonData.add(wonRevenueData);
						
					}
					competitorData.add(termBucket.getKey());
				}
			}
		}
		wonColumnBasicData.setSalesPersonRevenue(wonData);
		wonColumnBasicData.setName(SearchConstants.WON);
		
		lostColumnBasicData.setSalesPersonRevenue(lostData);
		lostColumnBasicData.setName(SearchConstants.LOST);
		
		Map<String, Object> finalResult = new HashMap<>();
		finalResult.put(SearchConstants.DATA, Arrays.asList(wonColumnBasicData, lostColumnBasicData));
		finalResult.put(SearchConstants.X_AXIS_DATA, competitorData);
		return finalResult;
	}
	
	private SearchRequestBuilder getCompetitorsWinLossDataForProduct(String startDate, String endDate, List<String> competitors, int size){
	
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.COMPETITOR_RAW, competitors));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(CRMConstants.COMPETITOR_RAW, ""));
		List<String> lostStages = appSalesStageContainer.getClosedLostMappedStages();
		List<String> wonStages =  appSalesStageContainer.getClosedWonMappedStages();
		
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		
		
		FilterAggregationBuilder lostfilterdAggregation = AggregationBuilders.filter(MappedConstants.LOST_AGGREGATION)
				.filter(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, lostStages))
				.subAggregation(opportunityAggregation);
		
		FilterAggregationBuilder wonFieldAggregation = AggregationBuilders.filter(MappedConstants.WON_AGGREGATION)
				.filter(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, wonStages))
				.subAggregation(opportunityAggregation);
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.ERP_OPPORTUNITY_COMPETITOR_AGGREGATION)
				.field(CRMConstants.COMPETITOR_RAW).subAggregation(lostfilterdAggregation).size(size).subAggregation(wonFieldAggregation);
		
		return this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);

	}
	
	public Map<String, Object> getTopCompetitorsWinLossDataForProduct(String startDate, String endDate, List<String> competitors, int size){
		
		SearchRequestBuilder searchRequestBuilder = getCompetitorsWinLossDataForProduct(startDate, endDate, competitors, size);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		ColumnBasicData wonColumnBasicData = new ColumnBasicData();
		ColumnBasicData lostColumnBasicData = new ColumnBasicData();
		List<SalesPersonRevenueData> wonData = new ArrayList<>();
		List<SalesPersonRevenueData> lostData = new ArrayList<>();
		List<String> competitorData = new ArrayList<>();
		double winPercentage = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations()
					.get(SearchConstants.ERP_OPPORTUNITY_COMPETITOR_AGGREGATION);
			Collection<Terms.Bucket> termsBuckets = terms.getBuckets();
			SalesPersonRevenueData wonRevenueData = null;
			for (Terms.Bucket termBucket : termsBuckets) {
				Filter wonOpportunityFilters =termBucket.getAggregations().get(MappedConstants.WON_AGGREGATION);
				Terms wonOpportunityTerms = wonOpportunityFilters.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> wonOpportunityBuckets = wonOpportunityTerms.getBuckets();
				List<String> wonOpportunities = new ArrayList<>();
				List<String> lostOpportunities = new ArrayList<>();
				long wonCount = wonOpportunityBuckets.size();
				for(Bucket wonOpportunity: wonOpportunityBuckets){
					wonOpportunities.add(wonOpportunity.getKey());
				}
				Filter lostOpportunityFilters =termBucket.getAggregations().get(MappedConstants.LOST_AGGREGATION);
				Terms lostOpportunityTerms = lostOpportunityFilters.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> lostOpportunityBuckets = lostOpportunityTerms.getBuckets();
				long lostCount = lostOpportunityBuckets.size();
				for(Bucket lostOpportunity: lostOpportunityBuckets){
					lostOpportunities.add(lostOpportunity.getKey());
				}
				int totalCount = (int) (wonCount+lostCount);
				List<TopProductData> topProductsByOpportunities = productService.getTopProductsByOpportunities(SearchConstants.SUB_LEVEL_SIZE, null, endDate, wonOpportunities);
				List<String> products = new ArrayList<>();
				for(TopProductData productData :  topProductsByOpportunities){
					products.add(productData.getName());
					wonRevenueData = new SalesPersonRevenueData();
					winPercentage = ((double) productData.getValue() / totalCount)  * 100;
					wonRevenueData.setxAxisParam(winPercentage);
					wonRevenueData.setNoOfDealsClosed(productData.getDealsClosed());
					wonRevenueData.setWonAmount(productData.getValue());
					wonRevenueData.setWinRate(winPercentage);
					wonRevenueData.setxAxisLabel(termBucket.getKey());
					wonRevenueData.setProductName(productData.getName());
					wonData.add(wonRevenueData);
				}
				lostData.addAll(this.getLostDataForProducts(products, lostOpportunities, SearchConstants.SUB_LEVEL_SIZE, totalCount, termBucket.getKey()));
				competitorData.add(termBucket.getKey());
			}
		}
		wonColumnBasicData.setSalesPersonRevenue(wonData);
		wonColumnBasicData.setName(SearchConstants.WON);
		
		lostColumnBasicData.setSalesPersonRevenue(lostData);
		lostColumnBasicData.setName(SearchConstants.LOST);
		
		Map<String, Object> finalResult = new HashMap<>();
		finalResult.put(SearchConstants.DATA, Arrays.asList(wonColumnBasicData, lostColumnBasicData));
		finalResult.put(SearchConstants.X_AXIS_DATA, competitorData);
		
		return finalResult;
	}
	
	public Map<String, Object> getTopCompetitorsWinLossExcelDataForProduct(String startDate, String endDate, List<String> competitors, int size){
		
		SearchRequestBuilder searchRequestBuilder = getCompetitorsWinLossDataForProduct(startDate, endDate, competitors, size);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		
		List<SalesPersonRevenueData> wonData = null;
		List<SalesPersonRevenueData> lostData = null;
		
		Map<String, List<SalesPersonRevenueData>> wonDataList = new HashMap<>();
		Map<String, List<SalesPersonRevenueData>> lostDataList = new HashMap<>();

		List<String> competitorData = new ArrayList<>();
		
		double winPercentage = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.ERP_OPPORTUNITY_COMPETITOR_AGGREGATION);
			Collection<Terms.Bucket> termsBuckets = terms.getBuckets();
			SalesPersonRevenueData wonRevenueData = null;
			for (Terms.Bucket termBucket : termsBuckets) {
				
				wonData = new ArrayList<>();
				lostData = new ArrayList<>();
				
				Filter wonOpportunityFilters =termBucket.getAggregations().get(MappedConstants.WON_AGGREGATION);
				Terms wonOpportunityTerms = wonOpportunityFilters.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> wonOpportunityBuckets = wonOpportunityTerms.getBuckets();
				List<String> wonOpportunities = new ArrayList<>();
				List<String> lostOpportunities = new ArrayList<>();
				long wonCount = wonOpportunityBuckets.size();
				
				for(Bucket wonOpportunity: wonOpportunityBuckets){
					wonOpportunities.add(wonOpportunity.getKey());
				}
				
				Filter lostOpportunityFilters =termBucket.getAggregations().get(MappedConstants.LOST_AGGREGATION);
				Terms lostOpportunityTerms = lostOpportunityFilters.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> lostOpportunityBuckets = lostOpportunityTerms.getBuckets();
				long lostCount = lostOpportunityBuckets.size();
			
				for(Bucket lostOpportunity: lostOpportunityBuckets){
					lostOpportunities.add(lostOpportunity.getKey());
				}
				
				int totalCount = (int) (wonCount+lostCount);
				List<TopProductData> topProductsByOpportunities = productService.getTopProductsByOpportunities(SearchConstants.SUB_LEVEL_SIZE, null, endDate, wonOpportunities);
				List<String> products = new ArrayList<>();
				
				for(TopProductData productData :  topProductsByOpportunities){
					products.add(productData.getName());
					wonRevenueData = new SalesPersonRevenueData();
					winPercentage = ((double) productData.getValue() / totalCount)  * 100;
					wonRevenueData.setxAxisParam(winPercentage);
					wonRevenueData.setNoOfDealsClosed(productData.getDealsClosed());
					wonRevenueData.setWonAmount(productData.getValue());
					wonRevenueData.setWinRate(winPercentage);
					wonRevenueData.setxAxisLabel(termBucket.getKey());
					wonRevenueData.setProductName(productData.getName());
					wonData.add(wonRevenueData);
				}
				
				lostData.addAll(this.getLostDataForProducts(products, lostOpportunities, SearchConstants.SUB_LEVEL_SIZE, totalCount, termBucket.getKey()));
				
				wonDataList.put(termBucket.getKey(), wonData);
				lostDataList.put(termBucket.getKey(), lostData);
				competitorData.add(termBucket.getKey());
			}
		}
		
		Map<String, Object> finalResult = new HashMap<>();
		finalResult.put(SearchConstants.WON, wonDataList);
		finalResult.put(SearchConstants.LOST, lostDataList);
		finalResult.put(SearchConstants.DATA, competitorData);

		return finalResult;
	}

	public List<SalesPersonRevenueData> getLostDataForProducts(List<String> products, List<String> opportunnities, int size, int totalCount, String competitor){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.PRODUCT_RAW, products));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunnities));
		SumBuilder wonSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_AMOUNT);
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.PRODUCT_AGGREGATION)
				.field(CRMConstants.PRODUCT_RAW).subAggregation(wonSumBuilder).size(size).order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false));;
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_Opportunity_campaign_mapped")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		SearchResponse  searchResponse = searchRequestBuilder.get();
		Terms terms = searchResponse.getAggregations()
				.get(SearchConstants.PRODUCT_AGGREGATION);
		Collection<Terms.Bucket> termsBuckets = terms.getBuckets();
		SalesPersonRevenueData lostRevenueData = null;
		double lostPercentage = 0;
		List<SalesPersonRevenueData> lostData = new ArrayList<>();
		for (Terms.Bucket termBucket : termsBuckets) {
			lostRevenueData = new SalesPersonRevenueData();
			Sum sum = termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
			lostPercentage = (termBucket.getDocCount() / totalCount)  * 100;
			lostRevenueData.setxAxisParam(lostPercentage);
			lostRevenueData.setNoOfDealsLost(termBucket.getDocCount());
			lostRevenueData.setLostAmount(sum.getValue());
			lostRevenueData.setLostRate(lostPercentage);
			lostRevenueData.setProductName(termBucket.getKey());
			lostRevenueData.setxAxisLabel(competitor);
			lostData.add(lostRevenueData);
		}
		return lostData;
	}
	
}
