package com.miri.search.data;

import java.io.Serializable;
import java.util.Map;

public class RouteToMarketData implements Serializable{
	
	Map<String, Object> partnerData;
	
	int totalPartnerCount;
	
	public void setPartnerData(Map<String, Object> partnerData) {
		this.partnerData = partnerData;
	}
	public Map<String, Object> getPartnerData() {
		return partnerData;
	}
	public void setTotalPartnerCount(int totalPartnerCount) {
		this.totalPartnerCount = totalPartnerCount;
	}
	public int getTotalPartnerCount() {
		return totalPartnerCount;
	}

}
