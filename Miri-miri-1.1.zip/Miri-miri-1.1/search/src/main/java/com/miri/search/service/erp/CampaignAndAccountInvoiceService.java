package com.miri.search.service.erp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.count.CountRequestBuilder;
import org.elasticsearch.action.count.CountResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.data.jpa.util.AppSalesStageContainer;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.crm.CRMCampaignService;
import com.miri.search.service.crm.CRMOpportunityService;
import com.miri.search.service.map.MapCampaignService;
import com.miri.search.service.map.MapOpportunityService;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.TimerUtil;

@Component
public class CampaignAndAccountInvoiceService extends MiriSearchService {

	private static final Logger LOG = LogManager.getLogger(RevenueGeneratedService.class);
	
	@Autowired
	CRMOpportunityService crmOpportunityService;

	@Autowired
	RevenueGeneratedService revenueGeneratedService;
	
	@Autowired
	CRMCampaignService crmCampaignService;
	
	@Autowired
	MapOpportunityService mapOpportunityService;
	
	@Autowired
	TimerUtil timerUtil;

	@Autowired
	ESQueryUtils esQueryUtils;
	
	@Autowired
	MapCampaignService mapCampaignService;
	
	@Autowired
	private AppSalesStageContainer appSalesStageContainer;
	
	/**
	 * Get all opportunities and associated accounts
	 * @param opportunities
	 * @return map of opportunity id and account id
	 */
	public Map<String, String> getOpportunitiesAndAccounts(List<String> opportunities) {
		Map<String, String> opportunitiesAndAccounts = new HashMap<String, String>();

		Client client = getTransportClient();

		TermsQueryBuilder opptTerm = QueryBuilders.termsQuery("opportunityId.raw", opportunities);

		SearchResponse response = client.prepareSearch(SearchConstants.ERP).setTypes(SearchConstants.ERP_INVOICE)
				.setQuery(opptTerm).setSearchType(SearchType.QUERY_AND_FETCH).addField("opportunityId")
				.addField("accountId").execute().actionGet();

		SearchHits searchHits = response.getHits();
		for (SearchHit hit : searchHits) {
			String optyId = hit.getFields().get("opportunityId").getValue().toString();
			String accountId = hit.getFields().get("accountId").getValue().toString();
			opportunitiesAndAccounts.put(optyId, accountId);
		}
		return opportunitiesAndAccounts;
	}

	/**
	 * 
	 * This method gives the number of leads captured between the provided dates
	 * @param startDate Date from which we need to get the lead count
	 * @param endDate Date till which we need to get the lead count
	 * @return {@link Long} number of leads between the provided dates
	 */
	public Double getDealCountByDate(String startDate, String endDate) {
		List<String> subCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(SearchConstants.STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(startDate).to(endDate));
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, subCampaigns));
		
		CountRequestBuilder countRequestBuilder = this.getTransportClient().prepareCount(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
		return (double) countRequestBuilder.get().getCount();

	}

	/**
	 * This method is used to get the Month wise deals response for a campaign
	 * 
	 * @param camapaignId Id of a campaign
	 * @return {@link SearchResponse} Elastic search response
	 */
	public SearchResponse getMonthWiseDealsForCampaignResponse(String campaignId, String startDate, String endDate) {
		
		timerUtil.start();
	
		Client client = getTransportClient();
		Map<String, String> subCampaigns = crmCampaignService.getSubCampaigns(campaignId);
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaigns.keySet()));
		//boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gt(startDate).lt(endDate));
		
		List<String> opportunityIds = new ArrayList<>();
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN).setScroll(new TimeValue(6000));

		SearchResponse opportunityResponse = esQueryUtils.execute(searchRequestBuilder);
/*		SearchResponse opportunityResponse = getResponse(opportunityQueryBuilder, SearchConstants.CRM,
				SearchConstants.CRM_OPPORTUNITY, new String[] { SearchConstants.OPPORTUNITY_ID });
				
*/
		while(true){
			
			for (SearchHit hit : opportunityResponse.getHits()) {
				opportunityIds.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(opportunityResponse.getScrollId()).setScroll(new TimeValue(6000));
			opportunityResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(opportunityResponse.getHits().getHits().length == 0 ){
				break;
			}
		}
		BoolFilterBuilder boolFilterInvoice = FilterBuilders.boolFilter();
		boolFilterInvoice.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		boolFilterInvoice.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).from(startDate).to(endDate));
				AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.CAMPAIGN_AGGREGATION).field(SearchConstants.CREATED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate);
		
				SearchRequestBuilder searchRequest = client.prepareSearch(SearchConstants.ERP).setTypes(SearchConstants.ERP_INVOICE)
						.addAggregation(dateAggregation).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterInvoice))
						.setSize(0)
						.setSearchType(SearchType.DEFAULT);

		SearchResponse response = esQueryUtils.execute(searchRequest);
		
		timerUtil.end();
		LOG.debug(" ES time getMonthWiseDealsForCampaignResponse :- Total Time Taken in sec"+timerUtil.timeTakenInMillis());
		return response;

	}

	/**
	 * Utility method to interact with the Elastic search
	 * 
	 * @param queryBuilder
	 * @param index
	 * @param type
	 * @param fields
	 * @return
	 */
	public CountResponse getCountResponse(QueryBuilder queryBuilder, String index, String type, String[] fields) {
		Client client = getTransportClient();
		return client.prepareCount().setIndices(index).setTypes(type).setQuery(queryBuilder).execute().actionGet();
	}

	/**
	 * 
	 * @param queryBuilder
	 * @param index
	 * @param type
	 * @param fields
	 * @return
	 */
	public SearchResponse getResponse(QueryBuilder queryBuilder, String index, String type, String[] fields) {
		Client client = getTransportClient();
		return client.prepareSearch(index).setTypes(type).setSearchType(SearchType.DFS_QUERY_THEN_FETCH).setSize(25)
				.addFields(fields).setQuery(queryBuilder).execute().actionGet();

	}

	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_OPPORTUNITY.getText();
	}

}
