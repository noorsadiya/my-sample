/**
 * 
 */
package com.miri.search.service.erp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.ErpOpportunity;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;

/**
 * @author Chandra
 *
 */
@Component
public class ERPOpportunityService extends MiriSearchService {

	@Autowired
	ESQueryUtils esQueryUtils;
	
    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getIndex()
     */
    @Override
    public String getIndex() {
        return ElasticSearchEnums.ERP.getText();
    }

    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getDocumentType()
     */
    @Override
    public String getDocumentType() {
         return ElasticSearchEnums.ERP_OPPORTUNITY.getText();
    }
    
    /**
     * Returns ERP opportunity by given opportunity Id.
     * 
     * @param opportunityId
     * @return
     */
    public ErpOpportunity getERPOpportunityById(final String opportunityId) {
        return (ErpOpportunity) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(),
            "opportunityId.raw", opportunityId);
    }
    

}
