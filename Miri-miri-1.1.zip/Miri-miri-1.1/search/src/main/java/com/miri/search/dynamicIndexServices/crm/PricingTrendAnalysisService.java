package com.miri.search.dynamicIndexServices.crm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.children.ChildrenBuilder;
import org.elasticsearch.search.aggregations.bucket.children.InternalChildren;
import org.elasticsearch.search.aggregations.bucket.filter.FilterAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Order;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.ColumnDrillDownData;
import com.miri.search.data.MultipleAxesChartData;
import com.miri.search.dynamicIndexServices.MappedConstants;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;
import com.miri.search.service.map.MapCampaignService;

@Component
public class PricingTrendAnalysisService extends MiriSearchService{
	
	@Autowired
	MapCampaignService mapCampaignService;
	
	@Autowired
	ERPInvoiceService erpInvoiceService;
	
	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_CAMPAIGN_OPPORTUNITY_MAPPED.getText();
	}
	
	public Map<String, Double> getTopFields(int size, String startDate, String endDate, String field){
		Map<String, Double> topFields =  new HashMap<String, Double>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
				.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));	
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(field, ""));
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(parentSumBuilder);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(field).subAggregation(parentBuilder).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">" +SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		InternalChildren internalChildren = null;
		Sum sum = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				revenue = sum.getValue();
				if(revenue > 0){
					topFields.put(termBucket.getKey(), revenue);
				}
			}
		}
		return topFields;
	}
	
	/**
	 * Gets top indistries By Opportunities
	 * @param size
	 * @param startDate
	 * @param endDate
	 * @param industries
	 * @param opportunities
	 * @return
	 */
	public Map<String, Object> getTopFieldValues(int size, String startDate, String endDate, String field, List<String> fieldValues){
		List<Map<Integer, MultipleAxesChartData>> fieldData = new ArrayList<Map<Integer, MultipleAxesChartData>>();
		Map<Integer, MultipleAxesChartData> revenueMapData = new LinkedHashMap<>();
		Map<Integer, MultipleAxesChartData> adsMapData = new LinkedHashMap<>();
		Map<Integer, MultipleAxesChartData> aspMapData = new LinkedHashMap<>();
		List<String> fieldCategories = new ArrayList<>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders
				.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));	
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(field, ""));
		if(CollectionUtils.isNotEmpty(fieldValues)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(field, fieldValues));
		}
		if(field.equals(CRMConstants.CRM_PARENT_CAMPAIGN_NAME_RAW)){
			List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
												.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(opportunityAggregation).subAggregation(parentSumBuilder);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(field).subAggregation(parentBuilder).size(size).order(Order.aggregation(MappedConstants.CHILDREN + ">" +SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		InternalChildren internalChildren = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		int counter = 0;
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				List<String> opportunities = new ArrayList<>();
				Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
				for(Bucket opportunityBucket : opportunityBuckets){
					opportunities.add(opportunityBucket.getKey());
				}
				revenue = erpInvoiceService.getTotalRevenueForOpportunties(startDate, endDate, opportunities);
				if(revenue > 0){
					fieldCategories.add(termBucket.getKey());
					revenueMapData.put(counter, constructRevenueData(revenue, counter, opportunityBuckets.size()));
					adsMapData.put(counter, constructADSData(revenue, counter, opportunityBuckets.size()));
					aspMapData.put(counter, constructASPDta(revenue, counter, internalChildren.getDocCount()));
					counter++;
				}
			}
		}

		fieldData.add(revenueMapData);
		fieldData.add(adsMapData);
		fieldData.add(aspMapData);
		Map<String, Object> metricData = new HashMap<>();
		metricData.put(SearchConstants.DATA, fieldData);
		metricData.put(SearchConstants.X_AXIS_DATA, fieldCategories);
		return metricData;
	}
	
	/**
	 * Calculates the revenue Data 
	 * @param revenue
	 * @param counter
	 * @param dealsClosed
	 * @return
	 */
	public static MultipleAxesChartData constructRevenueData(double revenue, int counter, int dealsClosed){
		MultipleAxesChartData multipleAxesChartData = new MultipleAxesChartData();
		multipleAxesChartData.setAverageRevenue(revenue);
		multipleAxesChartData.setBarHover(revenue);
		multipleAxesChartData.setNoOfDeals((long) dealsClosed);
		multipleAxesChartData.setxAxis(counter);
		return multipleAxesChartData;
	}
	
	/**
	 * Calculates the Average Deal Size
	 * @param revenue
	 * @param counter
	 * @param opportunitiesCount
	 * @return
	 */
	public static MultipleAxesChartData constructADSData(double revenue, int counter, int opportunitiesCount){
		MultipleAxesChartData multipleAxesChartData = new MultipleAxesChartData();
		double ads = revenue/opportunitiesCount;
		multipleAxesChartData.setxAxis(counter);
		multipleAxesChartData.setAverageRevenue(ads);
		multipleAxesChartData.setAverageDealSize(ads);
		return multipleAxesChartData;
	}
	
	/**
	 * Calculates The Average Sell Price
	 * @param revenue
	 * @param counter
	 * @param productQuantity
	 * @return
	 */
	public static MultipleAxesChartData constructASPDta(double revenue, int counter, double productQuantity){
		MultipleAxesChartData multipleAxesChartData = new MultipleAxesChartData();
		double asp = revenue/productQuantity;
		multipleAxesChartData.setAverageRevenue(asp);
		multipleAxesChartData.setxAxis(counter);
		multipleAxesChartData.setAverageSellPrice(asp);
		return multipleAxesChartData;
	}
	/*
	public Map<String, Double> getTopParentCampaignsByMarketingInfluenced(int size, String startDate, String endDate){
		List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();
		Map<String, Double> topParentCampaigns =  new HashMap<>();
		
		BoolFilterBuilder opportunityBoolFilterBuilder = FilterBuilders.boolFilter();
		opportunityBoolFilterBuilder.must(FilterBuilders.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.hasChildFilter(MappedConstants.OPPORTUNITY_CAMPAIGN_MAPPED, opportunityBoolFilterBuilder));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_ID_RAW, marketingSubCampaigns));
		
		SumBuilder sumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
								.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
										  .childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(sumBuilder);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
										.childType(MappedConstants.OPPORTUNITY_CAMPAIGN_MAPPED).subAggregation(childrenBuilder);
		
		TermsBuilder campaignAggreagtion = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
										   .field(CRMConstants.CAMPAIGN_PARENT_CAMPAIGN_ID_RAW)
										   .size(size)
										   .subAggregation(parentBuilder)
										   .order(Order.aggregation(MappedConstants.CHILDREN+ ">" +MappedConstants.CHILDREN+">"+SearchConstants.SUM_AGGREGATION, false));
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_campaign")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(campaignAggreagtion);
		
		SearchResponse searchResponse  = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		InternalChildren opportunityChildren = null;
		InternalChildren invoiceChildren = null;
		Sum sum = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				opportunityChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				invoiceChildren = opportunityChildren.getAggregations().get(MappedConstants.CHILDREN);
				sum = invoiceChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				topParentCampaigns.put(termBucket.getKey(), sum.getValue());
				
			}
		}
		return topParentCampaigns;
	}
	
	public Map<String, Object> getParentCampaignRevenueAdsAndAsp(int size, String startDate, String endDate, List<String> parentCamapigns){
		List<Map<Integer, MultipleAxesChartData>> fieldData = new ArrayList<Map<Integer, MultipleAxesChartData>>();
		Map<Integer, MultipleAxesChartData> revenueMapData = new LinkedHashMap<>();
		Map<Integer, MultipleAxesChartData> adsMapData = new LinkedHashMap<>();
		Map<Integer, MultipleAxesChartData> aspMapData = new LinkedHashMap<>();
		List<String> fieldCategories = new ArrayList<>();
		List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();
		
		BoolFilterBuilder opportunityBoolFilterBuilder = FilterBuilders.boolFilter();
		opportunityBoolFilterBuilder.must(FilterBuilders.hasChildFilter(MappedConstants.CRM_ERP_MAPPED, QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.hasChildFilter(MappedConstants.OPPORTUNITY_CAMPAIGN_MAPPED, opportunityBoolFilterBuilder));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_ID_RAW, marketingSubCampaigns));
		
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		
		SumBuilder sumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
								.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
										  .childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(sumBuilder).subAggregation(opportunityAggregation);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
										.childType(MappedConstants.OPPORTUNITY_CAMPAIGN_MAPPED).subAggregation(childrenBuilder);
		
		TermsBuilder campaignAggreagtion = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
										   .field(CRMConstants.CAMPAIGN_PARENT_CAMPAIGN_ID_RAW)
										   .size(size)
										   .subAggregation(parentBuilder)
										   .order(Order.aggregation(MappedConstants.CHILDREN+ ">" +MappedConstants.CHILDREN+">"+SearchConstants.SUM_AGGREGATION, false));
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch("crm")
				.setTypes("crm_campaign")
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(campaignAggreagtion);
		
		SearchResponse searchResponse  = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		InternalChildren opportunityChildren = null;
		InternalChildren invoiceChildren = null;
		Sum sum = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		int counter = 0;
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				opportunityChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				invoiceChildren = opportunityChildren.getAggregations().get(MappedConstants.CHILDREN);
				sum = invoiceChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				revenue = sum.getValue();
				fieldCategories.add(termBucket.getKey());
				Terms opportunityTerms = invoiceChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
				revenueMapData.put(counter, constructRevenueData(revenue, counter, opportunityBuckets.size()));
				adsMapData.put(counter, constructADSData(revenue, counter, opportunityBuckets.size()));
				aspMapData.put(counter, constructASPDta(revenue, counter, invoiceChildren.getDocCount()));
				counter++;
				
			}
		}
		fieldData.add(revenueMapData);
		fieldData.add(adsMapData);
		fieldData.add(aspMapData);
		Map<String, Object> metricData = new HashMap<>();
		metricData.put(SearchConstants.DATA, fieldData);
		metricData.put(SearchConstants.X_AXIS_DATA, fieldCategories);
		return metricData;
	}*/
	
	/**
	 * Gets top indistries By Opportunities
	 * @param size
	 * @param startDate
	 * @param endDate
	 * @param industries
	 * @param opportunities
	 * @return
	 */
	public Map<String, Object> getTopProductData(int size, String startDate, String endDate, List<String> topProducts){
		List<Map<Integer, MultipleAxesChartData>> fieldData = new ArrayList<Map<Integer, MultipleAxesChartData>>();
		Map<Integer, MultipleAxesChartData> revenueMapData = new LinkedHashMap<>();
		Map<Integer, MultipleAxesChartData> adsMapData = new LinkedHashMap<>();
		Map<Integer, MultipleAxesChartData> aspMapData = new LinkedHashMap<>();
		List<String> fieldCategories = new ArrayList<>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_ITEM_CREATED_DATE).from(startDate).to(endDate));	
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, ""));
		if(CollectionUtils.isNotEmpty(topProducts)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, topProducts));
		}
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_ITEM_AMOUNT);
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
												.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(ERPConstants.PRODUCT_LEVEL_THREE_RAW).subAggregation(parentSumBuilder).subAggregation(opportunityAggregation)
				.size(size)
				.order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(ElasticSearchEnums.ERP_INVOCE_INVOICE_ITEM_MAPPED.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		int counter = 0;
		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				Terms opportunityTerms = termBucket.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
				Sum sum = termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				revenue = sum.getValue();
				if(revenue > 0){
					fieldCategories.add(termBucket.getKey());
					revenueMapData.put(counter, constructRevenueData(revenue, counter, opportunityBuckets.size()));
					adsMapData.put(counter, constructADSData(revenue, counter, opportunityBuckets.size()));
					aspMapData.put(counter, constructASPDta(revenue, counter, termBucket.getDocCount()));
					counter++;
				}
			}
		}

		fieldData.add(revenueMapData);
		fieldData.add(adsMapData);
		fieldData.add(aspMapData);
		Map<String, Object> metricData = new HashMap<>();
		metricData.put(SearchConstants.DATA, fieldData);
		metricData.put(SearchConstants.X_AXIS_DATA, fieldCategories);
		return metricData;
	}
}
