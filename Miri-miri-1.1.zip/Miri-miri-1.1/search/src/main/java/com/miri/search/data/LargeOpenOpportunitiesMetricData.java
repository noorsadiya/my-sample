package com.miri.search.data;

import java.io.Serializable;
import java.util.Date;


public class LargeOpenOpportunitiesMetricData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3653110728142330008L;

	private String campaignName;
	
	private String probability;
	
	private String customerName;
	
	private String stage;
	
	private double amount;
	
	boolean ismarketingInfluenced;
	
	private String name;
	
	private String salesPerson;
	
	private Date closedDate;
	
	private String campaignId;
	
	private double zValue;
	
	private Integer opportunityCount;
	
	public String getCampaignId() {
		return campaignId;
	}
	
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}
	
	public Date getClosedDate() {
		return closedDate;
	}
	
	public void setClosedDate(Date closedDate) {
		this.closedDate = closedDate;
	}
	
	public String getSalesPerson() {
		return salesPerson;
	}

	public void setSalesPerson(String salesPerson) {
		this.salesPerson = salesPerson;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public String getProbability() {
		return probability;
	}

	public void setProbability(String probability) {
		this.probability = probability;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public boolean isIsmarketingInfluenced() {
		return ismarketingInfluenced;
	}

	public void setIsmarketingInfluenced(boolean ismarketingInfluenced) {
		this.ismarketingInfluenced = ismarketingInfluenced;
	}
	
	public double getzValue() {
		return zValue;
	}
	
	public void setzValue(double zValue) {
		this.zValue = zValue;
	}

	public Integer getOpportunityCount() {
		return opportunityCount;
	}

	public void setOpportunityCount(Integer opportunityCount) {
		this.opportunityCount = opportunityCount;
	}
}
