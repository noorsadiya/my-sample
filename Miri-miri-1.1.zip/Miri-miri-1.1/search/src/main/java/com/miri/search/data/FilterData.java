package com.miri.search.data;

import java.io.Serializable;

/**
 * Filter Data for Top Countries graph
 * @author rammoole
 *
 */
public class FilterData implements Serializable, Comparable<FilterData> {
	
	/**
	 * Generated serial version UID
	 */
	private static final long serialVersionUID = -2187834865225746560L;
	private String name;
	private long deals;
	private double revenue;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the deals
	 */
	public long getDeals() {
		return deals;
	}
	/**
	 * @param deals the deals to set
	 */
	public void setDeals(long deals) {
		this.deals = deals;
	}
	/**
	 * @return the revenue
	 */
	public Double getRevenue() {
		return revenue;
	}
	/**
	 * @param revenue the revenue to set
	 */
	public void setRevenue(Double revenue) {
		this.revenue = revenue;
	}
	
	@Override
	public int compareTo(FilterData filterObject) {
		if(filterObject == null) {
			return 1;
		} else {
			return -Double.compare(this.getRevenue(), filterObject.getRevenue());
		}
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FilterData [name=" + name + ", deals=" + deals + ", revenue=" + revenue + "]";
	}
}
