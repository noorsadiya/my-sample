/**
 * 
 */
package com.miri.search.explore.autosuggest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.CRMConstants;
import com.miri.search.explore.autosuggest.AutoSuggestRequest.RequestItem;

/**
 * @author Chandra
 *
 */
@Component
public class ProductAutoSuggestRequestBuilder extends AutoSuggestRequestBuilder {

	private static List<RequestItem> requestItems = new ArrayList<>();

	{
		// Map campaign
		if (requestItems.size() == 0) {
			RequestItem item = new RequestItem();

			List<String> fields = new ArrayList<>();
			fields.add(CRMConstants.CRM_PRODUCT_LEVEL_ONE);
			fields.add(CRMConstants.CRM_PRODUCT_LEVEL_TWO);
			fields.add(CRMConstants.CRM_PRODUCT_LEVEL_THREE);
			fields.add(CRMConstants.CRM_PRODUCT_PRODUCT_NAME);
			fields.add(CRMConstants.CRM_PRODUCT_SOLUTION_FAMILY);

			item.setDocType(ElasticSearchEnums.CRM_PRODUCT.getText());
			item.setFields(fields);
			
			requestItems.add(item);

		}
	}

	@Override
	public void buildAutoSuggestRequest() {
		autoSuggestRequest.setRequestItems(requestItems); 

	}

}
