package com.miri.search.dynamicIndexServices.crm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.children.ChildrenBuilder;
import org.elasticsearch.search.aggregations.bucket.children.InternalChildren;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.CampaignHierarchyData;
import com.miri.search.data.CampaignRevenueData;
import com.miri.search.data.InvoiceDataPojo;
import com.miri.search.dynamicIndexServices.MappedConstants;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.crm.CRMCampaignService;
import com.miri.search.service.erp.ERPInvoiceService;

@Component
public class MarketingSpendService extends MiriSearchService{
	
	@Autowired
	ERPInvoiceService erpInvoiceService;

	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_CAMPAIGN_OPPORTUNITY_MAPPED.getText();
	}
	
	@Autowired
	CRMCampaignService crmCampaignService;
	
	public Map<String, Object> getMarketingSubCampaignsRevneue(String startDate, String endDate, int size, List<String> marketingSubCampaigns, Map<String, Double> campaognCost){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.hasChildFilter(MappedConstants.CRM_ERP_MAPPED,
				QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		SumBuilder sumAggregation = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder childrenAggregation = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(ElasticSearchEnums.OPPORTUNITY_INVOICE_MAPPED.getText()).subAggregation(sumAggregation).subAggregation(opportunityAggregation);
		
		TermsBuilder campaignNameAggregation = AggregationBuilders.terms(SearchConstants.CAMPAIGN_NAME)
				   .field(CRMConstants.CAMPAIGN_NAME_RAW).subAggregation(childrenAggregation)
				   .size(size);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
													.setTypes(getDocumentType())
													.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
													.setSize(0)
													.addAggregation(campaignNameAggregation);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		Terms terms = searchResponse.getAggregations().get(SearchConstants.CAMPAIGN_NAME);
		Collection<Terms.Bucket> campaignBuckets = terms.getBuckets();
		List<CampaignRevenueData> topSubCampaigns = new ArrayList<>();
		CampaignRevenueData campaignRevenueData = null;
		InternalChildren internalChildren = null;
		List<Double> dollarDataList = new ArrayList<>();
		List<String> campaignIds = new ArrayList<>();

		
		for(Terms.Bucket bucket: campaignBuckets) {
			campaignRevenueData = new CampaignRevenueData();
			campaignRevenueData.setCampaignSpend(campaognCost.get(bucket.getKey()));
			List<String> opportunities = new ArrayList<>();
			internalChildren = bucket.getAggregations().get(MappedConstants.CHILDREN);
			Sum sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
			dollarDataList.add(sum.getValue());
			Terms opportunityTerms = internalChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
			Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
			for (Terms.Bucket oppBucket : opportunityBuckets) {
				opportunities.add(oppBucket.getKey());
			}
			InvoiceDataPojo invoiceDataPojo = erpInvoiceService.getInvoiceAmountAndInvoiceByOpportunityIds(opportunities, startDate, endDate);
			double  revenue =  invoiceDataPojo.getRevenue();
			campaignRevenueData.setCampaignName(bucket.getKey());
			campaignRevenueData.setRevenueAmount(revenue);
			campaignRevenueData.setAverageDealSize( opportunityBuckets.size() != 0 ? (revenue / (opportunityBuckets.size() )) : 0);
			campaignRevenueData.setAverageSellPrice(invoiceDataPojo.getProductQuantity() != 0 ? (revenue / (invoiceDataPojo.getProductQuantity() )) : 0);
			campaignRevenueData.setNoOfDeals((long) opportunityBuckets.size() );
			
			topSubCampaigns.add(campaignRevenueData);
		}
		
			
		Collections.sort(topSubCampaigns, new Comparator<CampaignRevenueData>() {
			public int compare(CampaignRevenueData campaignRevenueDataOne, CampaignRevenueData campaignRevenueDataTwo) {
				return campaignRevenueDataTwo.getRevenueAmount().compareTo(campaignRevenueDataOne.getRevenueAmount());
			}
		});
		
		if(topSubCampaigns.size() > size) {
			topSubCampaigns =  topSubCampaigns.subList(0, size);
		}
		
		List<CampaignHierarchyData> campaignHierarchyData = crmCampaignService.getAllCampaignHierarchy(campaignIds);
		Map<String, Object> marketingSpendRoiInfo = new HashMap<>();
		marketingSpendRoiInfo.put(SearchConstants.PARENT_DATA, campaignHierarchyData);
		marketingSpendRoiInfo.put(SearchConstants.X_AXIS_DATA, getCampaignData(topSubCampaigns));
		marketingSpendRoiInfo.put(SearchConstants.DOLLAR_DATA, dollarDataList);
		marketingSpendRoiInfo.put(SearchConstants.DATA, topSubCampaigns);
		return marketingSpendRoiInfo;
	}
	
	private List<String> getCampaignData(List<CampaignRevenueData> topSubCampaigns){
		List<String> campaignData = new ArrayList<>();
		for(CampaignRevenueData topSubCampaign :  topSubCampaigns){
			campaignData.add(topSubCampaign.getCampaignName());
		}
		return campaignData;
	}
}
