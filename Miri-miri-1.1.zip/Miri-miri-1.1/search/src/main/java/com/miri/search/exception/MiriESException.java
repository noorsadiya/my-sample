/**
 * 
 */
package com.miri.search.exception;

/**
 * @author Chandra
 *
 */
public class MiriESException extends RuntimeException  {
	private static final long serialVersionUID = -6781684248361660398L;

	public MiriESException() {
	}

	public MiriESException(String message) {
		super(message);
	}

	public MiriESException(Throwable cause) {
		super(cause);
	}

	public MiriESException(String message, Throwable cause) {
		super(message, cause);
	}

	public MiriESException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
