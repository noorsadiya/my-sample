/**
 * 
 */
package com.miri.search.explore;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.entity.CrmCampaign;
import com.miri.cis.entity.CrmOpportunity;
import com.miri.cis.entity.CrmUser;
import com.miri.cis.entity.ESEntity;
import com.miri.cis.entity.ErpInvoice;
import com.miri.cis.entity.ErpInvoiceItem;
import com.miri.cis.entity.MapCampaign;
import com.miri.search.constants.CRMConstants;
import com.miri.search.service.crm.CRMAccountService;
import com.miri.search.service.crm.CRMCampaignService;
import com.miri.search.service.crm.CRMOpportunityCompetitorService;
import com.miri.search.service.crm.CRMOpportunityProductService;
import com.miri.search.service.crm.CRMOpportunityService;
import com.miri.search.service.crm.CRMOrderService;
import com.miri.search.service.crm.CRMPartnerService;
import com.miri.search.service.crm.CRMProductService;
import com.miri.search.service.crm.CRMSalesPersonService;
import com.miri.search.service.erp.ERPInvoiceItemService;
import com.miri.search.service.erp.ERPInvoiceService;
import com.miri.search.service.erp.ERPSalesOrderService;
import com.miri.search.service.map.MapCampaignService;

/**
 * @author Chandra
 *
 */
@Component
public class ExploreSearchFacade {

	@Autowired
	CRMCampaignService crmCampaignService;

	@Autowired
	MapCampaignService mapCampaignService;

	@Autowired
	CRMOpportunityService crmOpportunityService;
	
	@Autowired
	CRMOrderService orderService;
	
	@Autowired
	ERPSalesOrderService erpSalesOrderService;
	
	@Autowired
	ERPInvoiceService erpInvoiceService;
	
	@Autowired
	ERPInvoiceItemService erpInvoiceItemService;

	@Autowired
	CRMOpportunityCompetitorService crmOpportunityCompetitorService;

	@Autowired
	CRMOpportunityProductService opportunityProductService;

	@Autowired
	CRMProductService crmProductService;

	@Autowired
	CRMSalesPersonService crmSalesPersonService;
	
	@Autowired
	AutoSuggestSearchService autoSuggestSearchService;
	
	@Autowired
	CRMPartnerService crmPartnerService;
	
	@Autowired
	CRMAccountService crmAccountService;

	private String startDate;

	private String endDate;

	public CrmCampaign getCRMCampaign(final String campaignId) {
		return crmCampaignService.getCrmCampaignByCampaignId(campaignId);
	}
	
	public MapCampaign getMapCampaign(final String campaignId) {
		return mapCampaignService.getMAPCampaignById(campaignId);
	}

	public List<String> getCRMOpportunitiesByIndustry(final String industry) {
		return crmOpportunityService.getOpportunitiesByField(CRMConstants.ACCOUNT_INDUSTRY_RAW, industry, getStartDate(), getEndDate());
	}

	public List<String> getCRMOpportunitiesByCountry(final String country) {
		return crmOpportunityService.getOpportunitiesByField(CRMConstants.ACCOUNT_BILLING_ADDRESS_COUNTRY_RAW, country, getStartDate(), getEndDate());
	}

	/**
	 * Returns opportunities by sales person.
	 * 
	 * @param competitorName
	 * @return
	 */
	public List<String> getCRMOpportunitiesBySalesPerson(final String salesPersonId) {
		CrmUser crmUser = crmSalesPersonService.getSalesPersonById(salesPersonId);
		if (null != crmUser) {
			List<String> opportunities = crmOpportunityService.getOpportunityIdsBySalesPerson(crmUser.getUsername(),
					getStartDate(), getEndDate(), StringUtils.EMPTY);
			
			return opportunities;
		}
		return null;
	}

	/**
	 * Returns opportunities by sales person.
	 * 
	 * @param competitorName
	 * @return
	 */
	public List<String> getCRMOpportunitiesByCustomer(final String customerId) {
		return crmOpportunityService.getOpportunitiesByAccountId(customerId, getStartDate(),
				getEndDate());
		
	}

	/**
	 * Returns opportunities by Campaign name.
	 * 
	 * @param competitorName
	 * @return
	 */
	public List<String> getCRMOpportunitiesByCampaign(final String campaignId) {
		return crmOpportunityService.getOpportuniesByCampaignIds(campaignId, getStartDate(),
				getEndDate());
	}
	
	/**
	 * Returns opportunities by Campaign name.
	 * 
	 * @param competitorName
	 * @return
	 */
	public List<CrmOpportunity> getCRMOpportunityEntitiesByCampaign(final String campaignId) {
		return crmOpportunityService.getOpportunitiesByCampaignId(campaignId);
	}

	/**
	 * returns CRM opportunity entities for the given ids.
	 * 
	 * @param opportunities
	 * @return
	 */
	public List<CrmOpportunity> getCrmOpportunityEntitiesByIds(List<String> opportunities) {
		return crmOpportunityService.getOpportunityObjectsByIds(opportunities);
	}

	/**
	 * Returns opportunities by competitor name.
	 * 
	 * @param competitorName
	 * @return
	 */
	public List<String> getCRMOpportunitiesByCompetitor(final String competitorName) {
		return crmOpportunityCompetitorService.getOpportunitiesOfCompetitor(competitorName, getStartDate(), getEndDate());
	}

	/**
	 * Returns opportunities by competitor name.
	 * 
	 * @param competitorName
	 * @return
	 */
	public List<String> getCRMOpportunitiesByProduct(final String productName) {

		return opportunityProductService.getOpportunityIdsByProductName(productName,
				getStartDate(), getEndDate());

	}
	
	/**
	 * Returns all sales orders for the given opportunity.
	 * 
	 * @param opportunityId
	 * @return
	 */
	public List<? extends ESEntity> getSalesOrderDetails(final String opportunityId) {
		return erpSalesOrderService.getSalesOrderByOpportunityId(opportunityId);
	}
	
	
	/**
	 * Returns all products for the given opportunity.
	 * 
	 * @param opportunityId
	 * @return
	 */
	public List<? extends ESEntity> getProducts(final String opportunityId) {
		Set<String> productIds = opportunityProductService.getProductIdsByOppId(opportunityId);
		return crmProductService.getCRMProductEntitiesByProductIds(productIds);
	}

	/**
	 * Returns all sales orders for the given opportunity.
	 * 
	 * @param opportunityId
	 * @return
	 */
	public List<ErpInvoice> getInvoices(final String salesOrderId) {
		return erpInvoiceService.getInvoicesBySOId(salesOrderId);
	}

	
	/**
	 * Returns all sales orders for the given opportunity.
	 * 
	 * @param opportunityId
	 * @return
	 */
	public List<ErpInvoiceItem> getInvoiceItems(final String invoiceId) {
		return erpInvoiceItemService.getInvoiceItemsByInvoiceId(invoiceId);
	}

	/**
	 * Returns opportunities by competitor name.
	 * 
	 * @param competitorName
	 * @return
	 */
	public List<String> getCRMOpportunitiesByProductLevel(final String productLevel,
			final String productLevelValue) {

		// Get product ids mapped to the given product level
		Set<String> productIds = crmProductService.getProductIdsByProductLevel(productLevel+".raw", productLevelValue);

		// Get opportunities associated with resulted product ids.
		Set<String> opportunities = opportunityProductService.getCRMOpportunityProductsByProductIds(productIds);

		return new ArrayList<String>(opportunities);
	}

	/**
	 * Checks whether the given opportunity is Sales generated.
	 * 
	 * @param opportunity
	 * @return
	 */
	public boolean isSGOpportunity(CrmOpportunity opportunity) {

		if (StringUtils.isBlank(opportunity.getPrimaryCampSource()))
			return true;
		else
			return null == mapCampaignService.getMAPCampaignById(opportunity.getPrimaryCampSource());
	}

	public CRMCampaignService getCampaignService() {
		return crmCampaignService;
	}

	public void setCampaignService(CRMCampaignService campaignService) {
		this.crmCampaignService = campaignService;
	}

	public MapCampaignService getMapCampaignService() {
		return mapCampaignService;
	}

	public void setMapCampaignService(MapCampaignService mapCampaignService) {
		this.mapCampaignService = mapCampaignService;
	}

	public CRMOpportunityService getCrmOpportunityService() {
		return crmOpportunityService;
	}

	public void setCrmOpportunityService(CRMOpportunityService crmOpportunityService) {
		this.crmOpportunityService = crmOpportunityService;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public Map<String, String> autoSuggest(String type, String key, boolean startsWith) { 
		return autoSuggestSearchService.autoSuggest(type, key, getStartDate(), getEndDate(), startsWith);
		
	}

	/**
	 * Returns opportunity competitors for the given opportunity id.
	 * 
	 * @param id
	 * @return
	 */
	public List<? extends ESEntity> getCompetitors(String id) { 
		return crmOpportunityCompetitorService.getAllCompetitorsByOpportunityId(id);
	}

	/**
	 * Returns CRM partners Account details for the given opportunity id.
	 *  
	 * @param id
	 * @return
	 */
	public List<? extends ESEntity> getPartners(String id) { 
		return crmPartnerService.getPartnersByOpportunityId(id);
	}

}
