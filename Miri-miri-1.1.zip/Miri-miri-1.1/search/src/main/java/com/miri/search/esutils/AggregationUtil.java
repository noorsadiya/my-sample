/**
 * author : noor
 * description : The util contains all aggregations that can be used across
 * 
 */

package com.miri.search.esutils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.bucket.histogram.InternalHistogram;
import org.elasticsearch.search.aggregations.bucket.range.Range;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.avg.Avg;
import org.elasticsearch.search.aggregations.metrics.max.Max;
import org.elasticsearch.search.aggregations.metrics.min.Min;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.search.constants.SearchConstants;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.TimerUtil;

@Component
public class AggregationUtil {

	@Autowired
	TimerUtil timeUtil;
	/**
	 * 
	 * @param aggregationName
	 * @param fieldName
	 * @return
	 */
	public static AbstractAggregationBuilder sumAggregation(final String aggregationName, final String fieldName) {
		return AggregationBuilders.sum(aggregationName).field(fieldName);
	}

	/**
	 * 
	 * @param subAggregation
	 * @param minBound
	 * @param maxBound
	 * @return
	 */
	public static AbstractAggregationBuilder dateHistogramAggregationForQuarter(AbstractAggregationBuilder subAggregation, String minBound, String maxBound) {
		return AggregationBuilders.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(minBound, maxBound).subAggregation(subAggregation);
	}



	/**
	 * 
	 * @param aggregationName
	 * @param fieldName
	 * @param subAggregation
	 * @param minBound
	 * @param maxBound
	 * @return
	 */
	public static AbstractAggregationBuilder dateHistogramAggregationForFiscalYear(AbstractAggregationBuilder subAggregation,String minBound,String maxBound) {
		return AggregationBuilders.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION)
				.field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH)
				.format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.minDocCount(0)
				.extendedBounds(minBound,maxBound).subAggregation(subAggregation);
	}

	/**
	 * Get Date Histogram Aggregation For Quarter
	 * @param aggregationName
	 * @param fieldName
	 * @param subAggregation
	 * @param minBound
	 * @param maxBound
	 * @return
	 */
	public static AbstractAggregationBuilder dateHistogramAggregationForTimeFrame(AbstractAggregationBuilder subAggregation, String minBound,String maxBound) {
		return AggregationBuilders.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION)
				.field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH)
				.format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(minBound,maxBound).subAggregation(subAggregation);
	}

	/**
	 * Get Date Histogram Aggregation Result	
	 * @param respone
	 * @param dateAggr
	 * @param sumAggr
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public  static Map<Integer, Double> getDateHistogramSumAggrResult(SearchResponse respone,String dateAggr,String sumAggr,
			List<Integer> fiscalMonths){	    
		Map<Integer, Double> resultsMap = new HashMap<Integer, Double>();
		InternalHistogram datehist = respone.getAggregations().get(dateAggr);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		int monthIndex=0;

		for (InternalHistogram.Bucket bucket : buckets) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD, bucket.getKeyAsText().toString()));
			// Commenting the below unused code
			// int month = cal.get(Calendar.MONTH);
			Sum sum = (Sum) bucket.getAggregations().get(sumAggr);
			resultsMap.put(monthIndex, sum.getValue());
			monthIndex++;
		}
		return resultsMap;
	}

	/**
	 * Intrinsic Sort Aggregation
	 * @param termName
	 * @param field
	 * @param size
	 * @param order
	 * @return
	 */
	public static AbstractAggregationBuilder intrinsicSortAggregation(String termName, String field, int size,
			String order) {

		boolean orderTerm = false;

		if ("asc".equals(order))
			orderTerm = true;

		if (size == 0)
			return AggregationBuilders.terms(termName).field(field).order(Terms.Order.term(orderTerm));

		return AggregationBuilders.terms(termName).field(field).size(size).order(Terms.Order.term(orderTerm));
	}

	public static List<String> getWonOppIdsByStageAndFiscalYearAgg(Client client, String indices, String document, String stage, String fiscalStartDate, String fiscalEndDate){

		List<String> opportunityIdsList = new ArrayList<String>();

		SearchResponse response = client.prepareSearch(indices).setTypes(document)
				.addAggregation(AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(SearchConstants.STAGE_RAW).include(stage)
						.subAggregation(AggregationBuilders.dateRange(SearchConstants.DATE_RANGE).field(SearchConstants.CREATED_ON).addRange(fiscalStartDate, fiscalEndDate)
								.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_OPPORTUNITIES_AGGREGATION)
										.setFetchSource(SearchConstants.OPPORTUNITY_ID, null).setSize(1000000))))
				.execute().actionGet();

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> termsBuckets = terms.getBuckets();

		for (Terms.Bucket termBucket : termsBuckets) {

			Range dateRangeagg = termBucket.getAggregations().get(SearchConstants.DATE_RANGE);

			for (Range.Bucket entry : dateRangeagg.getBuckets()) {

				TopHits topHits = entry.getAggregations().get(SearchConstants.TOP_OPPORTUNITIES_AGGREGATION);

				for (SearchHit hit : topHits.getHits().getHits()) {
					String opportunityId = hit.getId();
					opportunityIdsList.add(opportunityId);
				}
			}
		}

		return opportunityIdsList;
	}


	/**
	 * Get Any (Sum, Min, Max and Avg) Aggregation Value
	 * @param searchResponse
	 * @param aggregationName
	 * @param aggregationType
	 * @return
	 */
	public static double getAggregationValue(final SearchResponse searchResponse, final String aggregationName, final String aggregationType) {
		double aggregationValue = 0;
		switch(aggregationType) {
		case SearchConstants.SUM_AGGREGATION_TYPE:
			Sum sumAggregation = searchResponse.getAggregations().get(aggregationName);
			if(sumAggregation != null) {
				aggregationValue = sumAggregation.getValue();
			}
			break;
		case SearchConstants.AVG_AGGREGATION_TYPE:
			Avg avgAggregation = searchResponse.getAggregations().get(aggregationName);
			if(avgAggregation != null) {
				aggregationValue = avgAggregation.getValue();
			}
			break;
		case SearchConstants.MIN_AGGREGATION_TYPE:
			Min minAggregation = searchResponse.getAggregations().get(aggregationName);
			if(minAggregation != null) {
				aggregationValue = minAggregation.getValue();
			}
			break;
		case SearchConstants.MAX_AGGREGATION_TYPE:
			Max maxAggregation = searchResponse.getAggregations().get(aggregationName);
			if(maxAggregation != null) {
				aggregationValue = maxAggregation.getValue();
			}
			break;
		default:
			break;
		}
		return aggregationValue;
	}

	/**
	 * Get Sum Aggregation value from Bucket
	 * @param bucket
	 * @param aggregationName
	 * @return
	 */
	public static double getSumAggregationValueFromBucket(final Terms.Bucket bucket, final String aggregationName) {
		if(bucket.getAggregations() != null) {
			Sum sumAggregation = bucket.getAggregations().get(aggregationName);
			if(sumAggregation != null) {
				return sumAggregation.getValue();
			} else {
				return 0d;
			}
		} else {
			return 0d;
		}
	}
}