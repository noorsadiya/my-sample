package com.miri.search.data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.miri.cis.entity.CrmOpportunity;
import com.miri.cis.entity.MapLead;

public class ParentCamapaignsData implements Serializable{

	String campaignId;
	
	String campaignName;
	
	Map<String, String> subCampaigns;
	
	List<String> opportunityIds;
	
	List<Date> touchPointDates;
	
	Map<Date, Map<String, MapLead>> touchPointLeads;
	
	Map<Date, List<MapLead>> touchPointAndLeads;
	
	Map<Date, List<CrmOpportunity>> touchPointOpportunities;
	
	private Map<Date, Set<String>> uniqueCombinations;
	
	private Map<String, List<MapLead>> leadsForCombinations;
	
	Double leadSourceRevenue;
	
	Double assetRevenue;
	
	Double touchPointRevenue;
	
	public Map<String, List<MapLead>> getLeadsForCombinations() {
		return leadsForCombinations;
	}
	
	public void setLeadsForCombinations(Map<String, List<MapLead>> leadsForCombinations) {
		this.leadsForCombinations = leadsForCombinations;
	}
	
	
	public Map<Date, List<MapLead>> getTouchPointAndLeads() {
		return touchPointAndLeads;
	}
	
	public void setTouchPointAndLeads(Map<Date, List<MapLead>> touchPointAndLeads) {
		this.touchPointAndLeads = touchPointAndLeads;
	}
	
	
	public Map<Date, Set<String>> getUniqueCombinations() {
		return uniqueCombinations;
	}

	public void setUniqueCombinations(Map<Date, Set<String>> uniqueCombinations) {
		this.uniqueCombinations = uniqueCombinations;
	}

	public Double getTouchPointRevenue() {
		return touchPointRevenue;
	}

	public void setTouchPointRevenue(Double touchPointRevenue) {
		this.touchPointRevenue = touchPointRevenue;
	}

	public Double getLeadSourceRevenue() {
		return leadSourceRevenue;
	}

	public void setLeadSourceRevenue(Double leadSourceRevenue) {
		this.leadSourceRevenue = leadSourceRevenue;
	}

	public Double getAssetRevenue() {
		return assetRevenue;
	}

	public void setAssetRevenue(Double assetRevenue) {
		this.assetRevenue = assetRevenue;
	}

	public Map<Date, List<CrmOpportunity>> getTouchPointOpportunities() {
		return touchPointOpportunities;
	}

	public void setTouchPointOpportunities(Map<Date, List<CrmOpportunity>> touchPointOpportunities) {
		this.touchPointOpportunities = touchPointOpportunities;
	}

	public Map<Date, Map<String, MapLead>> getTouchPointLeads() {
		return touchPointLeads;
	}

	public void setTouchPointLeads(Map<Date, Map<String, MapLead>> touchPointLeads) {
		this.touchPointLeads = touchPointLeads;
	}

	public List<Date> getTouchPointDates() {
		return touchPointDates;
	}
	
	public void setTouchPointDates(List<Date> touchPointDates) {
		this.touchPointDates = touchPointDates;
	}

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public Map<String, String> getSubCampaigns() {
		return subCampaigns;
	}

	public void setSubCampaigns(Map<String, String> subCampaigns) {
		this.subCampaigns = subCampaigns;
	}

	public List<String> getOpportunityIds() {
		return opportunityIds;
	}

	public void setOpportunityIds(List<String> opportunityIds) {
		this.opportunityIds = opportunityIds;
	}
	
	
}
