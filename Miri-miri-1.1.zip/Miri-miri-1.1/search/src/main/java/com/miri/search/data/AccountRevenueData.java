package com.miri.search.data;

import java.io.Serializable;

public class AccountRevenueData implements Serializable {
	
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 2928524194765155635L;
	
	private String accountName;
	private Double accountRevenue;
	
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public Double getAccountRevenue() {
		return accountRevenue;
	}
	public void setAccountRevenue(Double accountRevenue) {
		this.accountRevenue = accountRevenue;
	}
	
	

}
