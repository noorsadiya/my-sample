package com.miri.search.service.crm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.ESEntity;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.ColumnDrillDownData;
import com.miri.search.data.RevenueOpportunitiesData;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;

/**
 * This Class is used to query the ES on crmPartner document
 * 
 * @author Prem Kumar
 *
 */
@Component
public class CRMPartnerService extends MiriSearchService {

	@Autowired
	private ERPInvoiceService erpInvoiceService;

	@Autowired
	private CRMAccountService crmAccountService;

	@Autowired
	private ESQueryUtils esQueryUtils;


	/**
	 * Gets the Partner Roles
	 * @param opportunities
	 * @return
	 */
	public  List<String> getAllPartnerRoles(List<String> opportunities){
		List<String>  partnerRoles=new ArrayList<>();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		boolFilter.mustNot(FilterBuilders.termFilter(CRMConstants.PARTNER_ROLE_RAW,""));

		AbstractAggregationBuilder termAggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.PARTNER_ROLE_RAW);

		SearchRequestBuilder request = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.addAggregation(termAggr).setSearchType(SearchType.QUERY_AND_FETCH);

		SearchResponse response=esQueryUtils.execute(request);

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> buckets = terms.getBuckets();

		for (Terms.Bucket bucket : buckets) {
			if(StringUtils.isNotBlank(bucket.getKey())){
				partnerRoles.add(bucket.getKey());
			}
		}
		return partnerRoles;

	}

	/**
	 * Returns all partner ids for the given opportunity.
	 * 
	 * @param opportunityId
	 * @return
	 */
	public List<String> getAllPartnerIdsByOpportunityId(String opportunityId) {
		return esQueryUtils.getMultipleDocsForFieldByFKId(getDocumentType(), getIndex(),
				CRMConstants.OPPORTUNITY_ID_RAW, opportunityId, CRMConstants.ACCOUNT_TO_ID);
	}
	
	/**
	 * Returns crm opportunity partners for the given opportunity id.
	 * 
	 * @param opportunityId
	 * @return
	 */
	public List<ESEntity> getPartnersByOpportunityId(final String opportunityId) {
		return esQueryUtils.getMultipleDocsByFKId(getDocumentType(), getIndex(),
				CRMConstants.OPPORTUNITY_ID_RAW, opportunityId);
	}


	/**
	 * Gets the Opportunities for PartnerRoles
	 * @param partnerRole
	 * @param overallOpportunities
	 * @return
	 */
	public List<String> getOpportunitiesByPartnerRole(String partnerRole, List<String> overallOpportunities){
		List<String> opportunities=new ArrayList<>();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termFilter(CRMConstants.PARTNER_ROLE_RAW,partnerRole));
		if(CollectionUtils.isNotEmpty(overallOpportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, overallOpportunities));
		}

		SearchRequestBuilder request = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN).setScroll(new TimeValue(6000))
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addField(SearchConstants.OPPORTUNITY_ID);

		SearchResponse opportunityRespose=esQueryUtils.execute(request);

		while(true){
			SearchHits oppSearchHits = opportunityRespose.getHits();
			for (SearchHit hit : oppSearchHits) {
				opportunities.add(hit.getFields().get(SearchConstants.OPPORTUNITY_ID).getValue().toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(1000));
			opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return opportunities;
	}

	

	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_PARTNER.getText();
	}
	
	/**
	 * Gets the opportunityIds By partners for a role
	 * @param partnerRole
	 * @param partnerOpportunities 
	 * @return
	 */
	public Map<String, List<String>> getOpportunitiesAndToIdsByPartnerRole(String partnerRole) {
		Map<String, List<String>> opportunities = new HashMap<>();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termFilter(CRMConstants.PARTNER_ROLE_RAW,partnerRole));

		SearchRequestBuilder request = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN).setScroll(new TimeValue(6000))
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
				

		SearchResponse opportunityRespose=esQueryUtils.execute(request);
		String opportunityId = "";
		String toId = "";

		while(true){
			SearchHits oppSearchHits = opportunityRespose.getHits();
			for (SearchHit hit : oppSearchHits) {
				opportunityId = (String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID);
				toId = (String)hit.getSource().get(CRMConstants.ACCOUNT_TO_ID);
				if(StringUtils.isNotBlank(toId) && StringUtils.isNotBlank(opportunityId)){
					if(opportunities.containsKey(toId)){
						opportunities.get(toId).add(opportunityId);
					}
					else{
						opportunities.put(toId, new ArrayList<>(Arrays.asList(opportunityId))); 
						
					}
				}
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(1000));
			opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return opportunities;
	}
	
	
	/**
	 * Get all the Partners by revenue with in time frame by opportunities  
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Object> getTopPartnersFromOpportunities(final String startDate, 
			final String endDate, ColumnDrillDownData columnDrillDownData, int size) {
		Map<String, Object> topPartnersData = new TreeMap<>();
		Map<String, List<String>> toIdsAndOpportunities = columnDrillDownData.getMapForToIdAndOpporId();
		String partnerName = "";
		RevenueOpportunitiesData revenueOpportunitiesData;
		List<String> opportunities;
		for(Entry<String, List<String>> map : toIdsAndOpportunities.entrySet()){
			if(topPartnersData.size() < size){
				partnerName = crmAccountService.getAccountNameByAccountId(map.getKey());
				opportunities =  map.getValue();
				revenueOpportunitiesData = new RevenueOpportunitiesData();
				double revenueAmount = this.erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunities, startDate, endDate);
				revenueOpportunitiesData.setRevenueAmount(revenueAmount);
				revenueOpportunitiesData.setOpportunityIds(opportunities);
				revenueOpportunitiesData.setNoOfDeals((int)erpInvoiceService.getDealsFromOpportunities(opportunities));
				topPartnersData.put(partnerName, revenueOpportunitiesData);
			}else
				break;
		}
		return topPartnersData;
	}

}
