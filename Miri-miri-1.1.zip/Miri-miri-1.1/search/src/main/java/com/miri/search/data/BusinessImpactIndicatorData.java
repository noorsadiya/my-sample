package com.miri.search.data;

import java.io.Serializable;

/**
 * @author supraja
 *
 */
public class BusinessImpactIndicatorData implements Serializable{

	private static final long serialVersionUID = 2090080850750253630L;
	
	private Double targetNoOfTopRevenue;
	private Double targetNoOfNewCust;
	private Double topAcctQualifierAmt;
	private Double targetNoOfDealsClosed;
	private Double targetCustAquisitionCost;
	private Double targetAvgCostPerOpportunity;
	private Double targetTimeToRevenue;
	private Double targetMarketingSpendROI;
	private Double targetAvgDealSize;
	private Double targetAvgSellPrice;
	private Double targetCompetitiveWinRate;
	/**
	 * @return the targetNoOfTopRevenue
	 */
	public Double getTargetNoOfTopRevenue() {
		return targetNoOfTopRevenue;
	}
	/**
	 * @param targetNoOfTopRevenue the targetNoOfTopRevenue to set
	 */
	public void setTargetNoOfTopRevenue(Double targetNoOfTopRevenue) {
		this.targetNoOfTopRevenue = targetNoOfTopRevenue;
	}
	/**
	 * @return the targetNoOfNewCust
	 */
	public Double getTargetNoOfNewCust() {
		return targetNoOfNewCust;
	}
	/**
	 * @param targetNoOfNewCust the targetNoOfNewCust to set
	 */
	public void setTargetNoOfNewCust(Double targetNoOfNewCust) {
		this.targetNoOfNewCust = targetNoOfNewCust;
	}
	/**
	 * @return the topAcctQualifierAmt
	 */
	public Double getTopAcctQualifierAmt() {
		return topAcctQualifierAmt;
	}
	/**
	 * @param topAcctQualifierAmt the topAcctQualifierAmt to set
	 */
	public void setTopAcctQualifierAmt(Double topAcctQualifierAmt) {
		this.topAcctQualifierAmt = topAcctQualifierAmt;
	}
	/**
	 * @return the targetNoOfDealsClosed
	 */
	public Double getTargetNoOfDealsClosed() {
		return targetNoOfDealsClosed;
	}
	/**
	 * @param targetNoOfDealsClosed the targetNoOfDealsClosed to set
	 */
	public void setTargetNoOfDealsClosed(Double targetNoOfDealsClosed) {
		this.targetNoOfDealsClosed = targetNoOfDealsClosed;
	}
	/**
	 * @return the targetCustAquisitionCost
	 */
	public Double getTargetCustAquisitionCost() {
		return targetCustAquisitionCost;
	}
	/**
	 * @param targetCustAquisitionCost the targetCustAquisitionCost to set
	 */
	public void setTargetCustAquisitionCost(Double targetCustAquisitionCost) {
		this.targetCustAquisitionCost = targetCustAquisitionCost;
	}
	/**
	 * @return the targetAvgCostPerOpportunity
	 */
	public Double getTargetAvgCostPerOpportunity() {
		return targetAvgCostPerOpportunity;
	}
	/**
	 * @param targetAvgCostPerOpportunity the targetAvgCostPerOpportunity to set
	 */
	public void setTargetAvgCostPerOpportunity(Double targetAvgCostPerOpportunity) {
		this.targetAvgCostPerOpportunity = targetAvgCostPerOpportunity;
	}
	/**
	 * @return the targetTimeToRevenue
	 */
	public Double getTargetTimeToRevenue() {
		return targetTimeToRevenue;
	}
	/**
	 * @param targetTimeToRevenue the targetTimeToRevenue to set
	 */
	public void setTargetTimeToRevenue(Double targetTimeToRevenue) {
		this.targetTimeToRevenue = targetTimeToRevenue;
	}
	/**
	 * @return the targetMarketingSpendROI
	 */
	public Double getTargetMarketingSpendROI() {
		return targetMarketingSpendROI;
	}
	/**
	 * @param targetMarketingSpendROI the targetMarketingSpendROI to set
	 */
	public void setTargetMarketingSpendROI(Double targetMarketingSpendROI) {
		this.targetMarketingSpendROI = targetMarketingSpendROI;
	}
	/**
	 * @return the targetAvgDealSize
	 */
	public Double getTargetAvgDealSize() {
		return targetAvgDealSize;
	}
	/**
	 * @param targetAvgDealSize the targetAvgDealSize to set
	 */
	public void setTargetAvgDealSize(Double targetAvgDealSize) {
		this.targetAvgDealSize = targetAvgDealSize;
	}
	/**
	 * @return the targetAvgSellPrice
	 */
	public Double getTargetAvgSellPrice() {
		return targetAvgSellPrice;
	}
	/**
	 * @param targetAvgSellPrice the targetAvgSellPrice to set
	 */
	public void setTargetAvgSellPrice(Double targetAvgSellPrice) {
		this.targetAvgSellPrice = targetAvgSellPrice;
	}
	/**
	 * @return the targetCompetitiveWinRate
	 */
	public Double getTargetCompetitiveWinRate() {
		return targetCompetitiveWinRate;
	}
	/**
	 * @param targetCompetitiveWinRate the targetCompetitiveWinRate to set
	 */
	public void setTargetCompetitiveWinRate(Double targetCompetitiveWinRate) {
		this.targetCompetitiveWinRate = targetCompetitiveWinRate;
	}
	
	
}