package com.miri.search.utils;

import java.util.Comparator;
import java.util.Map;


public class MiriComparators {
	public static final CampaignSetComparator CAMPAIGNSET_COMPARATOR = new CampaignSetComparator();

	public static class CampaignSetComparator implements Comparator<Map<String, String>> {
		public static final String NAME_FIELD = "name";
		public static final String VALUE_FIELD = "value";

		@Override
		public int compare(Map<String, String> o1, Map<String, String> o2) {
			String name1 = o1.get(NAME_FIELD);
			String name2 = o2.get(NAME_FIELD);
			if (name1 == null) {
				return -1;
			} else if (name2 == null) {
				return 1;
			}
			return name1.compareTo(name2);
		}
	}
}
