package com.miri.search.data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class ColumnDrillDownData implements Comparable<ColumnDrillDownData> ,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1675144585891182485L;
	private String type;
	private String name;
	private Double revenueAmount;
	private Double averageDealSize;
	private Double averageSellPrice;
	private Long dealsClosed;
	private List<String> opportnutiesList;
	private List<ColumnDrillDownData> industryDrillDown;
	private String industryName;
	private Integer opportunityCount;
	private List<String> opportunities;
	private Map<String, List<String>> oppoToIds;
	private String partnerRole;
	private String partnerName;	
	private Integer numberOfPartners;
	private Map<String, List<String>> mapForFromIdAndOpporId;
	private Map<String, List<String>> mapForToIdAndOpporId;
	private Map<String, List<String>> mappForFromIdAndToIds;

	public Map<String, List<String>> getMappForFromIdAndToIds() {
		return mappForFromIdAndToIds;
	}

	public void setMappForFromIdAndToIds(Map<String, List<String>> mappForFromIdAndToIds) {
		this.mappForFromIdAndToIds = mappForFromIdAndToIds;
	}

	public Map<String, List<String>> getMapForToIdAndOpporId() {
		return mapForToIdAndOpporId;
	}

	public void setMapForToIdAndOpporId(Map<String, List<String>> mapForToIdAndOpporId) {
		this.mapForToIdAndOpporId = mapForToIdAndOpporId;
	}

	public Map<String, List<String>> getMapForFromIdAndOpporId() {
		return mapForFromIdAndOpporId;
	}

	public void setMapForFromIdAndOpporId(Map<String, List<String>> mapForFromIdAndOpporId) {
		this.mapForFromIdAndOpporId = mapForFromIdAndOpporId;
	}


	public void setOppoToIds(Map<String, List<String>> oppoToIds) {
		this.oppoToIds = oppoToIds;
	}

	public Map<String, List<String>> getOppoToIds() {
		return oppoToIds;
	}

	public String getIndustryName() {
		return industryName;
	}

	public void setIndustryName(String industryName) {
		this.industryName = industryName;
	}

	public String getPartnerRole() {
		return partnerRole;
	}

	public void setPartnerRole(String partnerRole) {
		this.partnerRole = partnerRole;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getRevenueAmount() {
		return revenueAmount;
	}

	public void setRevenueAmount(Double revenueAmount) {
		this.revenueAmount = revenueAmount;
	}

	public Double getAverageDealSize() {
		return averageDealSize;
	}

	public void setAverageDealSize(Double averageDealSize) {
		this.averageDealSize = averageDealSize;
	}

	public Double getAverageSellPrice() {
		return averageSellPrice;
	}

	public void setAverageSellPrice(Double averageSellPrice) {
		this.averageSellPrice = averageSellPrice;
	}

	public Long getDealsClosed() {
		return dealsClosed;
	}

	public void setDealsClosed(Long dealsClosed) {
		this.dealsClosed = dealsClosed;
	}

	public List<ColumnDrillDownData> getIndustryDrillDown() {
		return industryDrillDown;
	}

	public void setIndustryDrillDown(List<ColumnDrillDownData> industryDrillDown) {
		this.industryDrillDown = industryDrillDown;
	}

	public Integer getNumberOfPartners() {
		return numberOfPartners;
	}

	public void setNumberOfPartners(Integer numberOfPartners) {
		this.numberOfPartners = numberOfPartners;
	}

	public void setOpportunityCount(Integer opportunityCount) {
		this.opportunityCount = opportunityCount;
	}

	public Integer getOpportunityCount() {
		return opportunityCount;
	}



	public List<String> getOpportunities() {
		return opportunities;
	}

	public void setOpportunities(List<String> opportunities) {
		this.opportunities = opportunities;
	}

	public List<String> getOpportnutiesList() {
		return opportnutiesList;
	}

	public void setOpportnutiesList(List<String> opportnutiesList) {
		this.opportnutiesList = opportnutiesList;
	}

	@Override
	public String toString() {
		return "ColumnDrillDownData [type=" + type + ", name=" + name + ", partnerName=" + partnerName
				+ ", revenueAmount=" + revenueAmount + ", averageDealSize=" + averageDealSize + ", averageSellPrice="
				+ averageSellPrice + ", dealsClosed=" + dealsClosed + ", numberOfPartners=" + numberOfPartners
				+ ", partnerRole=" + partnerRole + ", industryName="
				+ industryName + "]";
	}

	@Override
	public int compareTo(ColumnDrillDownData industryData) {
		if(null != industryData){
			return this.getRevenueAmount().compareTo(industryData.getRevenueAmount());
		} else{
			return -1;
		}
	}

}
