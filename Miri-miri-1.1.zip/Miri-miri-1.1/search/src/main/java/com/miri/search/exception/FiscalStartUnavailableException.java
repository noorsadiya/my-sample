package com.miri.search.exception;

/**
 * This exception is used to throw if the Fiscal start date or manual/account_strategy document is not available in ES
 * @author rammoole
 *
 */
public class FiscalStartUnavailableException extends RuntimeException {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 4486752988643583027L;

	public FiscalStartUnavailableException() {
		
	}

	public FiscalStartUnavailableException(String message) {
		super(message);
	}

	public FiscalStartUnavailableException(Throwable cause) {
		super(cause);
	}

	public FiscalStartUnavailableException(String message, Throwable cause) {
		super(message, cause);
	}

	public FiscalStartUnavailableException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
