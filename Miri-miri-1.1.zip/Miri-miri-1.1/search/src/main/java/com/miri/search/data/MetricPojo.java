package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

import com.miri.search.domain.guage.GaugePojo;

public class MetricPojo implements Serializable{

	private GaugePojo guagePojo;
	
	private Object metricDataList;
	
	private List<Double> dollarRanges;
	
	private List<String> xAxisData;
	
	private int dataCount;
	
	private double revenueAchieved;

	public Object getMetricDataList() {
		return metricDataList;
	}
	
	public void setMetricDataList(Object metricDataList) {
		this.metricDataList = metricDataList;
	}
	
	public GaugePojo getGuagePojo() {
		return guagePojo;
	}
	
	public void setGuagePojo(GaugePojo guagePojo) {
		this.guagePojo = guagePojo;
	}
	
	
	public void setDollarRanges(List<Double> dollarRanges) {
		this.dollarRanges = dollarRanges;
	}
	
	public List<Double> getDollarRanges() {
		return dollarRanges;
	}
	
	public List<String> getxAxisData() {
		return xAxisData;
	}
	
	public void setxAxisData(List<String> xAxisData) {
		this.xAxisData = xAxisData;
	}

	public int getDataCount() {
		return dataCount;
	}

	public void setDataCount(int dataCount) {
		this.dataCount = dataCount;
	}

	public double getRevenueAchieved() {
		return revenueAchieved;
	}

	public void setRevenueAchieved(double revenueAchieved) {
		this.revenueAchieved = revenueAchieved;
	}
	
	
	
}
