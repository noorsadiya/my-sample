package com.miri.search.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * For holding parameter Revenue and won, closed Opportunity Ids
 * @author rammoole
 *
 */
public class RevenueOpportunitiesData implements Serializable {
	private Double revenueAmount;

	private List<String> opportunityIds = new ArrayList<>();
	private List<String> lostOpportunityIds = new ArrayList<>();
	private Integer numberOfProduct;
	private String id;
	private Double avgDealSize;
	private Double avgSellPrice;
	private long noOfDeals;
	private List<String> validOpportunityIds = new ArrayList<>();

	private Map<String, Object> countriesData = new HashMap<>();
	
	private String partnerRole;
	
	public String getPartnerRole() {
		return partnerRole;
	}
	public void setPartnerRole(String partnerRole) {
		this.partnerRole = partnerRole;
	}
	public Integer getNumberOfProduct() {
		return numberOfProduct;
	}
	public void setNumberOfProduct(Integer numberOfProduct) {
		this.numberOfProduct = numberOfProduct;
	}
	/**
	 * @return the revenueAmount
	 */
	public Double getRevenueAmount() {
		return revenueAmount;
	}
	/**
	 * @param revenueAmount the revenueAmount to set
	 */
	public void setRevenueAmount(Double revenueAmount) {
		this.revenueAmount = revenueAmount;
	}
	/**
	 * @return the opportunityIds
	 */
	public List<String> getOpportunityIds() {

		return opportunityIds;
	}
	/**
	 * @param opportunityIds the opportunityIds to set
	 */
	public void setOpportunityIds(List<String> opportunityIds) {
		this.opportunityIds = opportunityIds;
	}
	
	/**
	 * @return the lostOpportunityIds
	 */
	public List<String> getLostOpportunityIds() {
		return lostOpportunityIds;
	}
	/**
	 * @param lostOpportunityIds the lostOpportunityIds to set
	 */
	public void setLostOpportunityIds(List<String> lostOpportunityIds) {
		this.lostOpportunityIds = lostOpportunityIds;
	}
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * @return the avgDealSize
	 */
	public Double getAvgDealSize() {
		return avgDealSize;
	}
	/**
	 * @param avgDealSize the avgDealSize to set
	 */
	public void setAvgDealSize(Double avgDealSize) {
		this.avgDealSize = avgDealSize;
	}
	/**
	 * @return the avgSellPrice
	 */
	public double getAvgSellPrice() {
		return avgSellPrice;
	}
	/**
	 * @param avgSellPrice the avgSellPrice to set
	 */
	public void setAvgSellPrice(Double avgSellPrice) {
		this.avgSellPrice = avgSellPrice;
	}
	/**
	 * @return the noOfDeals
	 */
	public long getNoOfDeals() {
		return noOfDeals;
	}
	/**
	 * @param noOfDeals the noOfDeals to set
	 */
	public void setNoOfDeals(long noOfDeals) {
		this.noOfDeals = noOfDeals;
	}
	/**
	 * @return the validOpportunityIds
	 */
	public List<String> getValidOpportunityIds() {
		return validOpportunityIds;
	}
	/**
	 * @param validOpportunityIds the validOpportunityIds to set
	 */
	public void setValidOpportunityIds(List<String> validOpportunityIds) {
		this.validOpportunityIds = validOpportunityIds;
	}
	/**
	 * @return the countriesData
	 */
	public Map<String, Object> getCountriesData() {
		return countriesData;
	}
	/**
	 * @param countriesData the countriesData to set
	 */
	public void setCountriesData(Map<String, Object> countriesData) {
		this.countriesData = countriesData;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RevenueOpportunitiesData [revenueAmount=" + revenueAmount + "]";
	}

}
