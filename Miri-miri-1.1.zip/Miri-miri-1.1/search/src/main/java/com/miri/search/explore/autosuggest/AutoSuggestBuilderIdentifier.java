/**
 * 
 */
package com.miri.search.explore.autosuggest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Chandra
 *
 */
@Component
public class AutoSuggestBuilderIdentifier {

	public static final String PRODUCT = "product";
	public static final String SALES_PERSON = "sales-person";
	public static final String INDUSTRY = "industry";
	public static final String COUNTRY = "country";
	public static final String CAMPAIGN = "campaign";
	public static final String COMPETITOR = "competitor";
	public static final String CUSTOMER = "customer";

	@Autowired
	ProductAutoSuggestRequestBuilder productAutoSuggestRequestBuilder;

	@Autowired
	SalesPersonAutoSuggestRequestBuilder salesPersonAutoSuggestRequestBuilder;

	@Autowired
	AccountAutoSuggestRequestBuilder accountAutoSuggestRequestBuilder;

	@Autowired
	CompetitorAutoSuggestRequestBuilder competitorAutoSuggestRequestBuilder;

	@Autowired
	CountryAutoSuggestRequestBuilder countryAutoSuggestRequestBuilder;

	@Autowired
	IndustryAutoSuggestRequestBuilder industryAutoSuggestRequestBuilder;

	@Autowired
	CampaignAutoSuggestRequestBuilder campaignAutoSuggestRequestBuilder;

	public AutoSuggestRequestBuilder getBuilder(final String field) {
		switch (field) {
		case PRODUCT:
			return productAutoSuggestRequestBuilder;

		case SALES_PERSON:

			return salesPersonAutoSuggestRequestBuilder;

		case INDUSTRY:

			return industryAutoSuggestRequestBuilder;

		case CAMPAIGN:

			return campaignAutoSuggestRequestBuilder;

		case COMPETITOR:

			return competitorAutoSuggestRequestBuilder;

		case CUSTOMER:

			return accountAutoSuggestRequestBuilder;

		case COUNTRY:

			return countryAutoSuggestRequestBuilder;

		default:
			break;
		}

		return null;

	}
}
