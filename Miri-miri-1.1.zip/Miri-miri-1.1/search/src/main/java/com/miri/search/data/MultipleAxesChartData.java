package com.miri.search.data;

import java.io.Serializable;

public class MultipleAxesChartData implements Comparable<MultipleAxesChartData>,Serializable {
	
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -1211800923759853443L;

	//represents X-axis used by any builder
	private Object xAxis;
	private Double barHover; 
	private Double revenueAmount;
	private Double averageDealSize;
    private Double averageSellPrice;
    private Long noOfDeals;
    private Long noOfProducts;
    
    //Added for Average Time To Revenue Metric
    private Long averageTimeToRevenue;
    private String productName;
    
    //Added for Product Adoption Trend Analyasis Metric
    private String customerName;
    private String revenueType;
    private String industry;
    private String country;
    private String competitor;
    
    private String salesPerson;
    
    //Added these fields for MISG Pipeline Graph consumed by the MultipleAxesChartBuilder
    private Double totalAmount;
    private Double pipelineAmount;
    private Integer opportunityCount;
    private Double hoverAmount;
    private Double projectedRevenue;
    private String campaignName;
    
    private Integer customersCount;
    private Double averageRevenue;
    
	private Integer timeToOpportunity;
	private Integer timeToSalesOrder;
	private Integer timeToInvoice;
	private Integer salesOrderCount;
	private Integer invoiceCount;

    private Double monthRevenue;
    private Double previousRevenue;
    private Double returnAmount;
    
    private String name;
    
    private Double previousFyAvgRevenue;
    
    private String bucketKeyAsString;
    
    
	public Object getxAxis() {
		return xAxis;
	}




	public void setxAxis(Object xAxis) {
		this.xAxis = xAxis;
	}




	public Double getRevenueAmount() {
		return revenueAmount;
	}




	public void setRevenueAmount(Double revenueAmount) {
		this.revenueAmount = revenueAmount;
	}




	public Double getAverageDealSize() {
		return averageDealSize;
	}




	public void setAverageDealSize(Double averageDealSize) {
		this.averageDealSize = averageDealSize;
	}




	public Double getAverageSellPrice() {
		return averageSellPrice;
	}




	public void setAverageSellPrice(Double averageSellPrice) {
		this.averageSellPrice = averageSellPrice;
	}




	public Long getNoOfDeals() {
		return noOfDeals;
	}




	public void setNoOfDeals(Long noOfDeals) {
		this.noOfDeals = noOfDeals;
	}




	public Long getNoOfProducts() {
		return noOfProducts;
	}




	public void setNoOfProducts(Long noOfProducts) {
		this.noOfProducts = noOfProducts;
	}




	public Long getAverageTimeToRevenue() {
		return averageTimeToRevenue;
	}




	public void setAverageTimeToRevenue(Long averageTimeToRevenue) {
		this.averageTimeToRevenue = averageTimeToRevenue;
	}




	public String getProductName() {
		return productName;
	}




	public void setProductName(String productName) {
		this.productName = productName;
	}




	public String getCustomerName() {
		return customerName;
	}




	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}




	public String getRevenueType() {
		return revenueType;
	}




	public void setRevenueType(String customerType) {
		this.revenueType = customerType;
	}




	public String getIndustry() {
		return industry;
	}




	public void setIndustry(String industry) {
		this.industry = industry;
	}




	public String getCountry() {
		return country;
	}




	public void setCountry(String country) {
		this.country = country;
	}




	public String getCompetitor() {
		return competitor;
	}




	public void setCompetitor(String competitor) {
		this.competitor = competitor;
	}




	public String getSalesPerson() {
		return salesPerson;
	}




	public void setSalesPerson(String salesPerson) {
		this.salesPerson = salesPerson;
	}




	public Double getTotalAmount() {
		return totalAmount;
	}




	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}




	public Double getPipelineAmount() {
		return pipelineAmount;
	}




	public void setPipelineAmount(Double pipelineAmount) {
		this.pipelineAmount = pipelineAmount;
	}




	public Integer getOpportunityCount() {
		return opportunityCount;
	}




	public void setOpportunityCount(Integer opportunityCount) {
		this.opportunityCount = opportunityCount;
	}

	


	public Double getHoverAmount() {
		return hoverAmount;
	}




	public void setHoverAmount(Double hoverAmount) {
		this.hoverAmount = hoverAmount;
	}




	public Double getProjectedRevenue() {
		return projectedRevenue;
	}




	public void setProjectedRevenue(Double projectedRevenue) {
		this.projectedRevenue = projectedRevenue;
	}


	

	public String getCampaignName() {
		return campaignName;
	}




	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}




	/**
	 * @return the customersCount
	 */
	public Integer getCustomersCount() {
		return customersCount;
	}




	/**
	 * @param customersCount the customersCount to set
	 */
	public void setCustomersCount(Integer customersCount) {
		this.customersCount = customersCount;
	}




	/**
	 * @return the averageRevenue
	 */
	public Double getAverageRevenue() {
		return averageRevenue;
	}




	/**
	 * @param averageRevenue the averageRevenue to set
	 */
	public void setAverageRevenue(Double averageRevenue) {
		this.averageRevenue = averageRevenue;
	}

	


	public Double getMonthRevenue() {
		return monthRevenue;
	}



	public void setMonthRevenue(Double monthRevenue) {
		this.monthRevenue = monthRevenue;
	}




	public Double getPreviousRevenue() {
		return previousRevenue;
	}




	public void setPreviousRevenue(Double previousRevenue) {
		this.previousRevenue = previousRevenue;
	}



	public Double getBarHover() {
		return barHover;
	}
	
	public void setBarHover(Double barHover) {
		this.barHover = barHover;
	}

	@Override
	public String toString() {
		return String.format(
				"MultipleAxesChartData [xAxis=%s, revenueAmount=%s, averageDealSize=%s, averageSellPrice=%s, noOfDeals=%s, averageTimeToRevenue=%s, projectedRevenue=%s]",
				xAxis, revenueAmount, averageDealSize, averageSellPrice, noOfDeals, averageTimeToRevenue,projectedRevenue);
	}
	
	@Override
	public int compareTo(MultipleAxesChartData multiAxesData) {
		if(null != multiAxesData){
			return Double.compare( multiAxesData.getTotalAmount(),this.getTotalAmount());
		}
		else{
			return -1;
		}
	}


	/**
	 * @return the timeToOpportunity
	 */
	public Integer getTimeToOpportunity() {
		return timeToOpportunity;
	}




	/**
	 * @param timeToOpportunity the timeToOpportunity to set
	 */
	public void setTimeToOpportunity(Integer timeToOpportunity) {
		this.timeToOpportunity = timeToOpportunity;
	}




	/**
	 * @return the timeToSalesOrder
	 */
	public Integer getTimeToSalesOrder() {
		return timeToSalesOrder;
	}




	/**
	 * @param timeToSalesOrder the timeToSalesOrder to set
	 */
	public void setTimeToSalesOrder(Integer timeToSalesOrder) {
		this.timeToSalesOrder = timeToSalesOrder;
	}




	/**
	 * @return the timeToInvoice
	 */
	public Integer getTimeToInvoice() {
		return timeToInvoice;
	}




	/**
	 * @param timeToInvoice the timeToInvoice to set
	 */
	public void setTimeToInvoice(Integer timeToInvoice) {
		this.timeToInvoice = timeToInvoice;
	}




	/**
	 * @return the salesOrderCount
	 */
	public Integer getSalesOrderCount() {
		return salesOrderCount;
	}




	/**
	 * @param salesOrderCount the salesOrderCount to set
	 */
	public void setSalesOrderCount(Integer salesOrderCount) {
		this.salesOrderCount = salesOrderCount;
	}




	/**
	 * @return the invoiceCount
	 */
	public Integer getInvoiceCount() {
		return invoiceCount;
	}




	/**
	 * @param invoiceCount the invoiceCount to set
	 */
	public void setInvoiceCount(Integer invoiceCount) {
		this.invoiceCount = invoiceCount;
	}




	public Double getReturnAmount() {
		return returnAmount;
	}




	public void setReturnAmount(Double returnAmount) {
		this.returnAmount = returnAmount;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the previousFyAvgRevenue
	 */
	public Double getPreviousFyAvgRevenue() {
		return previousFyAvgRevenue;
	}

	/**
	 * @param previousFyAvgRevenue the previousFyAvgRevenue to set
	 */
	public void setPreviousFyAvgRevenue(Double previousFyAvgRevenue) {
		this.previousFyAvgRevenue = previousFyAvgRevenue;
	}




	public String getBucketKeyAsString() {
		return bucketKeyAsString;
	}




	public void setBucketKeyAsString(String bucketKeyAsString) {
		this.bucketKeyAsString = bucketKeyAsString;
	}
	
	
}
