package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

/**
 * @author supraja
 *
 */
public class BusinessStrategySetup implements Serializable{
	private static final long serialVersionUID = -7350649826373112277L;

	private String geoName;
	private String fiscalStartDate;
	private Double businessRevenueTarget;
	private Double marketingInflRevTarget;
	private List<RevenueTarget> busRevTargets;
	private List<RevenueTarget> mirTarget;
	private boolean draft;

	public String getGeoName() {
		return geoName;
	}

	public void setGeoName(String geoName) {
		this.geoName = geoName;
	}

	public String getFiscalStartDate() {
		return fiscalStartDate;
	}

	public void setFiscalStartDate(String fiscalStartDate) {
		this.fiscalStartDate = fiscalStartDate;
	}

	public Double getBusinessRevenueTarget() {
		return businessRevenueTarget;
	}

	public void setBusinessRevenueTarget(Double businessRevenueTarget) {
		this.businessRevenueTarget = businessRevenueTarget;
	}

	public Double getMarketingInflRevTarget() {
		return marketingInflRevTarget;
	}

	public void setMarketingInflRevTarget(Double marketingInflRevTarget) {
		this.marketingInflRevTarget = marketingInflRevTarget;
	}

	public List<RevenueTarget> getBusRevTargets() {
		return busRevTargets;
	}

	public void setBusRevTargets(List<RevenueTarget> busRevTargets) {
		this.busRevTargets = busRevTargets;
	}

	public List<RevenueTarget> getMirTarget() {
		return mirTarget;
	}

	public void setMirTarget(List<RevenueTarget> mirTarget) {
		this.mirTarget = mirTarget;
	}

	public boolean isDraft() {
		return draft;
	}

	public void setDraft(boolean draft) {
		this.draft = draft;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BusinessStrategySetup [geoName=").append(geoName );
		builder.append(", fiscalStartDate=").append(fiscalStartDate);
		builder.append(", businessRevenueTarget=").append(businessRevenueTarget);
		builder.append(", marketingInflRevTarget=").append(marketingInflRevTarget);
		builder.append(", busRevTargets=").append(busRevTargets);
		builder.append(", mirTarget=").append(mirTarget).append("]");
		return builder.toString();
	}
}
