package com.miri.search.service.map;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.MapCampaign;
import com.miri.cis.entity.MapLead;
import com.miri.cis.entity.MapOpportunity;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.MAPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.crm.CRMOpportunityService;

/**
 * Services pertaining to map/map_opportunity document in elastic search
 * 
 * @author noor
 *
 */

@Component
public class MapOpportunityService extends MiriSearchService {

	private static final Logger LOG = LogManager.getLogger(MapOpportunityService.class);

	@Autowired
	CRMOpportunityService crmOpportunityService;
	
	@Autowired
	ESQueryUtils esQueryUtils;

	/**
	 * Get all Map opportunities for the given campaign and lead details.
	 * 
	 * @return List<OppotunityIds>
	 */
	public List<MapOpportunity> getMapOpportunitiesByCampaignAndLeadDetails(final MapCampaign campaign,
			final MapLead mapLead) {
		List<MapOpportunity> mapOpportunities = new ArrayList<>();

		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery()
				.must(QueryBuilders.termQuery("campaignId.raw", campaign.getCampaignId()));

		if (null != mapLead) {
			boolQueryBuilder.must(QueryBuilders.termQuery("campaignId.raw", mapLead.getCampaignId()))
					.must(QueryBuilders.termQuery("leadSource.raw", mapLead.getLeadSource()))
					.must(QueryBuilders.termQuery("opportunityOwner.raw", mapLead.getLeadOwner()))
					.must(QueryBuilders.termQuery("companyName.raw", mapLead.getCompanyName()));

			boolQueryBuilder.must(
					QueryBuilders.rangeQuery(MAPConstants.OPPORTUNITY_CREATED_DATE).gte(mapLead.getCreatedDate()));
			boolQueryBuilder.must(
					QueryBuilders.rangeQuery(MAPConstants.OPPORTUNITY_CREATED_DATE).gte(campaign.getCreatedDate()));
		}

		SearchResponse opportunityRespose = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(boolQueryBuilder).execute().actionGet();

		if (opportunityRespose == null || opportunityRespose.getHits().getTotalHits() == 0) {
			if (null != mapLead) {
				boolQueryBuilder = QueryBuilders.boolQuery()
						.must(QueryBuilders.termQuery("campaignId.raw", campaign.getCampaignId()));
				boolQueryBuilder.must(QueryBuilders.termQuery("campaignId.raw", mapLead.getCampaignId()))
						.must(QueryBuilders.termQuery("companyName.raw", mapLead.getCompanyName()))
						.should(QueryBuilders.termQuery("leadSource.raw", mapLead.getLeadSource()))
						.should(QueryBuilders.termQuery("opportunityOwner.raw", mapLead.getLeadOwner()));

				boolQueryBuilder.must(
						QueryBuilders.rangeQuery(MAPConstants.OPPORTUNITY_CREATED_DATE).gte(mapLead.getCreatedDate()));
				boolQueryBuilder.must(
						QueryBuilders.rangeQuery(MAPConstants.OPPORTUNITY_CREATED_DATE).gte(campaign.getCreatedDate()));
			}

			opportunityRespose = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
					.setQuery(boolQueryBuilder).execute().actionGet();

		}
		SearchHits oppSearchHits = opportunityRespose.getHits();

		for (SearchHit hit : oppSearchHits) {
			mapOpportunities
					.add((MapOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
		}
		return mapOpportunities;
	}

	@Override
	public String getIndex() {
		return ElasticSearchEnums.MAP.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.MAP_OPPORTUNITY.getText();
	}

	/**
	 * Get Map Opportunity for opportunity id parameterized
	 * @param opportunityId
	 * @return
	 */
	public MapOpportunity getMapOpportunity(String opportunityId) {
		SearchResponse mapOpportunityResponse = this.getTransportClient().prepareSearch(getIndex()) 
				.setQuery(QueryBuilders.termQuery("opportunityId.raw", opportunityId))
				.setSearchType(SearchType.QUERY_AND_FETCH).setTypes(getDocumentType()).get();
		MapOpportunity mapOpportunity = null;
		for (SearchHit hit : mapOpportunityResponse.getHits()) {
			mapOpportunity = (MapOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex());
			break;
		}
		return mapOpportunity;
	}

	/**
	 * Get all Map opportunties
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return List<OppotunityIds>
	 */
	public List<String> getMapOpportunities(String startDate, String endDate) {
		List<String> mapOpportunities = new ArrayList<>();
		
		RangeQueryBuilder rangeQuery= QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate);

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(SearchConstants.MAP)
				.setTypes(SearchConstants.MAP_OPPORTUNITY).setSearchType(SearchType.SCAN)
				.addField(SearchConstants.OPPORTUNITY_ID).setQuery(rangeQuery).setScroll(new TimeValue(6000));
		
		SearchResponse opportunityRespose = searchRequestBuilder.execute().actionGet();
		
		while(true) {
			SearchHits oppSearchHits = opportunityRespose.getHits();
			for (SearchHit hit : oppSearchHits) {
				mapOpportunities.add(hit.getFields().get(SearchConstants.OPPORTUNITY_ID).getValue().toString());
			}
			opportunityRespose = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000)).get();
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return mapOpportunities;
	}
	
	/**
	 * Get all Map opportunties
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return List<OppotunityIds>
	 */
	public List<String> getMapOpportunities() {
		List<String> mapOpportunities = new ArrayList<>();
		
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(SearchConstants.MAP)
				.setTypes(SearchConstants.MAP_OPPORTUNITY).setSearchType(SearchType.SCAN)
				.addField(SearchConstants.OPPORTUNITY_ID).setScroll(new TimeValue(6000));
		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		
		while(true) {
			SearchHits oppSearchHits = opportunityRespose.getHits();
			for (SearchHit hit : oppSearchHits) {
				mapOpportunities.add(hit.getFields().get(SearchConstants.OPPORTUNITY_ID).getValue().toString());
			}
			SearchScrollRequestBuilder searchScrollRequest = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000));
			opportunityRespose = esQueryUtils.execute(searchScrollRequest);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return mapOpportunities;
	}

	/**
	 * Get all Map Opportunities with in the time frame
	 * @return List<OppotunityIds>
	 * @author rammoole
	 */
	@Cacheable
	public List<String> getMapOpportunitiesByDateRange(String startDate, String endDate) {
		List<String> mapOpportunities = new ArrayList<>();
		Client client = this.getTransportClient();
		SearchResponse opportunityRespose = client.prepareSearch(SearchConstants.MAP)
				.setTypes(SearchConstants.MAP_OPPORTUNITY)
				.setScroll(new TimeValue(6000))
				.setSize(300)
				.setPostFilter(FilterBuilders.rangeFilter(MAPConstants.OPPORTUNITY_CREATED_DATE).gte(startDate).lte(endDate))
				.setSearchType(SearchType.SCAN).addField(SearchConstants.OPPORTUNITY_ID).execute()
				.actionGet();
		while(true) {
			for (SearchHit hit : opportunityRespose.getHits().getHits()) {
				mapOpportunities.add(hit.getFields().get(SearchConstants.OPPORTUNITY_ID).getValue().toString());
			}
			opportunityRespose = client.prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000)).get();
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return mapOpportunities;
	}
}