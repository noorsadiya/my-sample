package com.miri.search.service.manual;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.get.GetRequestBuilder;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.ManualAccountStrategy;
import com.miri.cis.utilities.DateUtilities;
import com.miri.cis.utilities.JacksonUtils;
import com.miri.data.jpa.domain.Account;
import com.miri.data.jpa.domain.Country;
import com.miri.data.jpa.domain.Currency;
import com.miri.data.jpa.domain.Industry;
import com.miri.data.jpa.repository.accountSetup.AccountSetupRepository;
import com.miri.data.jpa.repository.accountSetup.CountryRepository;
import com.miri.data.jpa.repository.accountSetup.CurrencyRepository;
import com.miri.data.jpa.repository.accountSetup.IndustryRepository;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.AccountSetup;
import com.miri.search.data.FiscalDatesData;
import com.miri.search.data.FiscalDatesStrData;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.exception.FiscalStartUnavailableException;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.TimerUtil;

/**
 * Services pertaining to manual/account_strategy document in elastic search
 * @author noor
 *
 */

@Component
public class ManualAccountStrategyService extends MiriSearchService {
	private static final Logger LOG = LogManager.getLogger(ManualAccountStrategyService.class);

	@Autowired
	ESQueryUtils esQueryUtils;

	@Autowired
	TimerUtil timeUtil;

	@Autowired
	CurrencyRepository currencyRepository;

	@Autowired
	CountryRepository countryRepository;

	@Autowired
	IndustryRepository industryRepository;

	@Autowired
	AccountSetupRepository accountSetupRepository;


	private ObjectMapper mapper = new ObjectMapper();

	public int getFiscalMonth() {


		//Create the query to fetch fiscal year
		SearchResponse response = getTransportClient()
				.prepareSearch(SearchConstants.MANUAL)
				.setTypes(SearchConstants.ACCOUNT_STRATEGY).addField(SearchConstants.FISCAL_YEAR)
				.setSearchType(SearchType.QUERY_AND_FETCH).execute()
				.actionGet();

		SearchHit hit = response.getHits().getAt(0);
		int fiscalYearstr = hit.getFields().get(SearchConstants.FISCAL_YEAR).getValue();

		return  fiscalYearstr;
	}

	/**
	 * Returns the fiscal start date as String object (yyyy-MM-dd)
	 * @return Calendar
	 * @author rammoole
	 */
	public String getFiscalStartDateStr()  {
		String fiscalStart = null;
		try {
			SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(ElasticSearchEnums.MANUAL.getText())
					.setTypes(ElasticSearchEnums.ACCOUNT_STRATEGY.getText())
					.setSize(1)
					.addSort(SearchConstants.LAST_MODIFIED_DATE, SortOrder.DESC);
			SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);


			SearchHits searchHits = searchResponse.getHits();
			for(SearchHit hit: searchHits) {
				fiscalStart = hit.getSource().get(SearchConstants.FISCAL_START).toString();
			}
			// Since the date from elasticsearch will always be in 2015-10-05T10:38:48.056Z format. only date is required.
			fiscalStart = fiscalStart.split("T")[0];
		} catch(Exception e) {
			LOG.error("Manual Account Strategy document is not available in Elasticsearch :" + e.getMessage());
			throw new FiscalStartUnavailableException("Fiscal Start Date or manual/account_strategy document is not available in Elasticsearch");
		}
		return fiscalStart;
	}

	/* Returns the fiscal start date as String object (yyyy-MM-dd)
	 * @return Calendar
	 * @author rammoole
	 */
	public String getFiscalStartDateStrTemp()  {

		timeUtil.start();

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(ElasticSearchEnums.MANUAL.getText())
				.setTypes(ElasticSearchEnums.ACCOUNT_STRATEGY.getText())
				.setSize(1)
				.addSort(SearchConstants.LAST_MODIFIED_DATE, SortOrder.DESC);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		timeUtil.end();
		LOG.debug("getFiscalStartDateStr ES time"+timeUtil.timeTakenInMillis());

		SearchHits searchHits = searchResponse.getHits();
		String fiscalStart = null;
		for(SearchHit hit: searchHits) {
			fiscalStart = hit.getSource().get(SearchConstants.FISCAL_START).toString();
		}
		// Since the date from elasticsearch will always be in 2015-10-05T10:38:48.056Z format. only date is required.
		fiscalStart = fiscalStart.split("T")[0];
		return fiscalStart;
	}


    @Override
    public String getIndex() {
        return ElasticSearchEnums.MANUAL.getText();
    }

    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.ACCOUNT_STRATEGY.getText();
    }


	/**
	 * Returns the fiscal start date as Calendar Object
	 * @return Calendar
	 * @author rammoole
	 */
    public Calendar getFiscalStartDate()  {
    	String fiscalStart = this.getFiscalStartDateStr();
    	Calendar fiscalStartCalObj = null;
    	if(StringUtils.isNotBlank(fiscalStart)) {
    		// Since the date from elasticsearch will always be in 2015-10-05T10:38:48.056Z format. only date is required.
    		Date fiscalStartDate = MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD, fiscalStart.split("T")[0]);
    		fiscalStartCalObj = Calendar.getInstance();
    		fiscalStartCalObj.setTime(fiscalStartDate);
    	}
    	return fiscalStartCalObj;
    }

	/**
	 * Get Calendar Objects for first quarter
	 * Fiscal start date -> fiscal start date + 3 months
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesData get1stQuarterDates()  {
		Calendar fiscalStartDate = this.getFiscalStartDate();
		// adding 3 months to end date
		Calendar endDate = Calendar.getInstance();
		endDate.setTime(fiscalStartDate.getTime());
		endDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) + 3);
		endDate.set(Calendar.DATE, endDate.get(Calendar.DATE) - 1); // substracting one day from the end date

		FiscalDatesData fiscalDates = new FiscalDatesData();
		fiscalDates.setFiscalStartDate(fiscalStartDate);
		fiscalDates.setFiscalEndDate(endDate);

		return fiscalDates;
	}

	/**
	 * Get Calendar Objects for second quarter
	 * In a Fiscal year -> 3rd month to 6th month = 2nd Quarter
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesData get2ndQuarterDates()  {
		Calendar fiscalStartDate = this.getFiscalStartDate();
		// adding 9 months to end date
		Calendar endDate = Calendar.getInstance();
		endDate.setTime(fiscalStartDate.getTime());
		endDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) + 6);
		endDate.set(Calendar.DATE, endDate.get(Calendar.DATE) - 1); // substracting one day from the end date

		Calendar fiscalStDate = Calendar.getInstance();
		fiscalStDate.setTime(fiscalStartDate.getTime());
		fiscalStDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) + 3);

		FiscalDatesData fiscalDates = new FiscalDatesData();
		fiscalDates.setFiscalStartDate(fiscalStDate);
		fiscalDates.setFiscalEndDate(endDate);
		return fiscalDates;
	}

	/**
	 * Get Calendar objects for third quarter
	 * In a fiscal year -> 6th month to 9th month = 3rd quarter
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesData get3rdQuarterDates()  {
		Calendar fiscalStartDate = this.getFiscalStartDate();
		// adding 9 months to end date
		Calendar endDate = Calendar.getInstance();
		endDate.setTime(fiscalStartDate.getTime());
		endDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) + 9);
		endDate.set(Calendar.DATE, endDate.get(Calendar.DATE) - 1); // substracting one day from the end date

		Calendar fiscalStDate = Calendar.getInstance();
		fiscalStDate.setTime(fiscalStartDate.getTime());
		fiscalStDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) + 6);

		// adding 6 months to get the range for 1+ years
		// fiscalStartDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) + 6);

		FiscalDatesData fiscalDates = new FiscalDatesData();
		fiscalDates.setFiscalStartDate(fiscalStDate);
		fiscalDates.setFiscalEndDate(endDate);
		return fiscalDates;
	}

	/**
	 * Get Calendar Objects for fourth quarter
	 * In Fiscal Year -> 9th Month to 12 month end = 4th Quarter
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesData get4thQuarterDates()  {
		Calendar fiscalStartDate = this.getFiscalStartDate();
		// adding 12 months to end date
		Calendar endDate = Calendar.getInstance();
		endDate.setTime(fiscalStartDate.getTime());
		endDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) + 12);
		endDate.set(Calendar.DATE, endDate.get(Calendar.DATE) - 1); // substracting one day from the end date

		Calendar fiscalStDate = Calendar.getInstance();
		fiscalStDate.setTime(fiscalStartDate.getTime());
		fiscalStDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) + 9);
		// Substracting 6 months to get the range for 1+ years
		//fiscalStartDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) + 9);
		FiscalDatesData fiscalDates = new FiscalDatesData();
		fiscalDates.setFiscalStartDate(fiscalStDate);
		fiscalDates.setFiscalEndDate(endDate);
		return fiscalDates;
	}

	/**
	 * Get Calendar Objects for 1 year duration
	 * Fiscal start date to fiscal start date + 12 months = 1 year
	 * @return
	 * @author rammoole
	 */

	public FiscalDatesData get1YearDates()  {
		Calendar fiscalStartDate = this.getFiscalStartDate();
		Calendar endDate = Calendar.getInstance();
		endDate.setTime(fiscalStartDate.getTime());
		endDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) + 12);
		endDate.set(Calendar.DATE, endDate.get(Calendar.DATE) - 1); // substracting one day from the end date

		FiscalDatesData fiscalDates = new FiscalDatesData();
		fiscalDates.setFiscalStartDate(fiscalStartDate);
		fiscalDates.setFiscalEndDate(endDate);
		return fiscalDates;
	}

	/**
	 * Get Calendar Objects for 1 plus year duration
	 * Fiscal start date - 6 months to  fiscal start date + 12 months = 1 plus year
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesData get1plusYearDates()  {
		Calendar fiscalStartDate = this.getFiscalStartDate();
		// adding 12 months to end date
		Calendar endDate = Calendar.getInstance();
		endDate.setTime(fiscalStartDate.getTime());
		endDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) + 12);
		endDate.set(Calendar.DATE, endDate.get(Calendar.DATE) - 1); // substracting one day from the end date

		Calendar fiscalStDate = Calendar.getInstance();
		fiscalStDate.setTime(fiscalStartDate.getTime());
		fiscalStDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) - 6);
		// Substracting 6 months to get the range for 1+ years
		//fiscalStartDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) - 6);

		FiscalDatesData fiscalDates = new FiscalDatesData();
		fiscalDates.setFiscalStartDate(fiscalStDate);
		fiscalDates.setFiscalEndDate(endDate);

		return fiscalDates;
	}


	/**
	 * Get Calendar Objects for first quarter
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesStrData get1stQuarterDatesStr()  {
		FiscalDatesData dates = get1stQuarterDates();
		return this.convertFiscalDatetoStr(dates);
	}

	/**
	 * Get Calendar Objects for second quarter
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesStrData get2ndQuarterDatesStr()  {
		FiscalDatesData dates = get2ndQuarterDates();
		return this.convertFiscalDatetoStr(dates);
	}

	/**
	 * Get Calendar objects for third quarter
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesStrData get3rdQuarterDatesStr()  {
		FiscalDatesData dates = get3rdQuarterDates();
		return this.convertFiscalDatetoStr(dates);
	}

	/**
	 * Get Calendar Objects for fourth quarter
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesStrData get4thQuarterDatesStr()  {
		FiscalDatesData dates = get4thQuarterDates();
		return this.convertFiscalDatetoStr(dates);
	}

	/**
	 * Get Calendar Objects for 1 plus year duration
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesStrData get1plusYearDatesStr()  {
		FiscalDatesData dates = get1plusYearDates();
		return this.convertFiscalDatetoStr(dates);
	}

	/**
	 * Get Calendar Objects for 1 year duration
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesStrData get1YearDatesStr()  {
		timeUtil.start();
		FiscalDatesData dates = get1YearDates();
		FiscalDatesStrData strData=this.convertFiscalDatetoStr(dates);
		timeUtil.end();
		//LOG.debug("Java Processing Time Taken in sec :- "+timeUtil.timeTakenInMillis());
		return  strData;
	}

	/**
	 * Get Calendar Objects for Previous Year
	 * Fiscal start date - 6 months to  fiscal start date + 12 months = 1 plus year
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesData getPreviousYearDates()  {
		Calendar fiscalStartDate = this.getFiscalStartDate();
		// adding 12 months to end date
		Calendar endDate = Calendar.getInstance();
		endDate.setTime(fiscalStartDate.getTime());
		//endDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) - 1);
		endDate.set(Calendar.DATE, endDate.get(Calendar.DATE) - 1); // substracting one day from the end date

		Calendar fiscalStDate = Calendar.getInstance();
		fiscalStDate.setTime(fiscalStartDate.getTime());
		fiscalStDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) - 12);
		// Substracting 6 months to get the range for 1+ years
		//fiscalStartDate.set(Calendar.MONTH, fiscalStartDate.get(Calendar.MONTH) - 6);

		FiscalDatesData fiscalDates = new FiscalDatesData();
		fiscalDates.setFiscalStartDate(fiscalStDate);
		fiscalDates.setFiscalEndDate(endDate);

		return fiscalDates;
	}

	/**
	 * Get Calendar Objects for 1 year duration
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesStrData getPreviousYearDatesStr()  {
		timeUtil.start();
		FiscalDatesData dates = this.getPreviousYearDates();
		FiscalDatesStrData strData=this.convertFiscalDatetoStr(dates);
		timeUtil.end();
		//LOG.debug("Java Processing Time Taken in sec :- "+timeUtil.timeTakenInMillis());
		return  strData;
	}
	/**
	 * This method converts the FiscalDates Object to FiscalDatesStr object
	 * @param dates
	 * @return
	 * @author rammoole
	 */
	public FiscalDatesStrData convertFiscalDatetoStr(FiscalDatesData dates) {
		return convertCalendarToString(dates.getFiscalStartDate(), dates.getFiscalEndDate());
	}

	/**
	 * Converts the given date range into required String format
	 *
	 * @param startDate Calendar object for start of the date range
	 * @param endDate Calendar object for end of the date range
	 * @return FiscalDatesStrData holding string representation of the date range
	 */
	public FiscalDatesStrData convertCalendarToString(Calendar startDate, Calendar endDate) {
		String startDateStr = MiriDateUtils.parseDateToString(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		String endDateStr = MiriDateUtils.parseDateToString(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		FiscalDatesStrData fiscalStartDates = new FiscalDatesStrData();
		fiscalStartDates.setFiscalStartDateStr(startDateStr);
		fiscalStartDates.setFiscalEndDateStr(endDateStr);
		return fiscalStartDates;
	}

	/**
	 * Method returns the fiscal dates depending on timeFrame
	 * @param timeFrame
	 * @return
	 */
	public FiscalDatesData getTimeFrameDates(String timeFrame)  {
		FiscalDatesData fiscalDatesData;

		if(StringUtils.isEmpty(timeFrame))
			timeFrame = SearchConstants.ONE_YEAR;

		switch (timeFrame) {
			case SearchConstants.FIRST_QUARTER:
				fiscalDatesData = this.get1stQuarterDates();
				break;
			case SearchConstants.SECOND_QUARTER:
				fiscalDatesData = this.get2ndQuarterDates();
				break;
			case SearchConstants.THIRD_QUARTER:
				fiscalDatesData = this.get3rdQuarterDates();
				break;
			case SearchConstants.FOURTH_QUARTER:
				fiscalDatesData = this.get4thQuarterDates();
				break;
			case SearchConstants.ONE_YEAR:
				fiscalDatesData = this.get1YearDates();
				break;
			case SearchConstants.ONE_PLUS_YEAR:
				fiscalDatesData = this.get1plusYearDates();
				break;
			case SearchConstants.PREVIOUS_YEAR:
				fiscalDatesData = this.getPreviousYearDates();
				break;

			default:
				fiscalDatesData = this.get1YearDates();
				break;
		}
		return fiscalDatesData;
	}

	/**
	 * Method returns the String fiscal dates depending on timeFrame
	 * @param timeFrame
	 * @return
	 */
	public FiscalDatesStrData getTimeFrameStringDates(String timeFrame)  {
		FiscalDatesStrData fiscalDatesData;

		if(StringUtils.isEmpty(timeFrame))
			timeFrame = SearchConstants.ONE_YEAR;

		switch (timeFrame) {
			case SearchConstants.FIRST_QUARTER:
				fiscalDatesData = this.get1stQuarterDatesStr();
				break;
			case SearchConstants.SECOND_QUARTER:
				fiscalDatesData = this.get2ndQuarterDatesStr();
				break;
			case SearchConstants.THIRD_QUARTER:
				fiscalDatesData = this.get3rdQuarterDatesStr();
				break;
			case SearchConstants.FOURTH_QUARTER:
				fiscalDatesData = this.get4thQuarterDatesStr();
				break;
			case SearchConstants.ONE_YEAR:
				fiscalDatesData = this.get1YearDatesStr();
				break;
			case SearchConstants.ONE_PLUS_YEAR:
				fiscalDatesData = this.get1plusYearDatesStr();
				break;
			case SearchConstants.PREVIOUS_YEAR:
				fiscalDatesData = this.getPreviousYearDatesStr();
				break;
			default:
				fiscalDatesData = this.get1YearDatesStr();
				break;
		}
		return fiscalDatesData;
	}


	/**
	 *
	 * @return
	 */
	public Map<String, Object> populateAccountSetupData() {
		LOG.debug("Enter into populateAccountSetupData");
		// get all the data
		List<Currency> currencies = getCurrencies("USD", "GBP", "EUR");
		List<?> countries = getCountries();
		List<?> industries = getIndusties();

		Map<String, Object> accountDetails = new HashMap<>();
		if (currencies != null)
			accountDetails.put(SearchConstants.CURRENCY, currencies);
		if (countries != null)
			accountDetails.put(SearchConstants.COUNTRY, countries);
		if (industries != null)
			accountDetails.put(SearchConstants.INDUSTRY, industries);
		return accountDetails;
	}

	@Transactional
	public void saveAccountSetupDetails(AccountSetup accountSetup) throws IOException {
		LOG.debug("Enter into saveAccountSetupDetails" + accountSetup.getAccountId());
		ManualAccountStrategy manualAccountStrategy = new ManualAccountStrategy();
		LOG.debug("connect to the DB to save details");
		Account account = accountSetupRepository.findOne(SearchConstants.ACCOUNT_DB_ID);

		Date currentDate = new Date();
		if (account == null) {
			account = new Account();
			account.setId(SearchConstants.ACCOUNT_DB_ID);
			account.setCreatedAt(currentDate);
			manualAccountStrategy.setCreatedDate(DateUtilities.dateToString(currentDate));
		}

		String companyName = StringUtils.defaultString(accountSetup.getCompanyName());
		String businessUnit = StringUtils.defaultString(accountSetup.getBusinessUnit());
		String address1 = StringUtils.defaultString(accountSetup.getAddress1());
		String address2 = StringUtils.defaultString(accountSetup.getAddress2());
		String address3 = StringUtils.defaultString(accountSetup.getAddress3());
		String city = StringUtils.defaultString(accountSetup.getCity());
		String state = StringUtils.defaultString(accountSetup.getState());
		String zipCode = StringUtils.defaultString(accountSetup.getZipCode());
		String website = StringUtils.defaultString(accountSetup.getWebsite());

		account.setCompanyName(companyName);
		account.setBusinessUnit(businessUnit);
		account.setAddress1(address1);
		account.setAddress2(address2);
		account.setAddress3(address3);
		account.setCity(city);
		account.setState(state);
		account.setZipCode(zipCode);
		account.setWebsite(website);
		account.setDraft(accountSetup.isDraft());
		account.setNumOfEmployee(accountSetup.getNumOfEmployee());
		account.setAnnualRevenue(accountSetup.getAnnualRevenue());

		long countryid = accountSetup.getCountryId();
		Country country = countryRepository.findOne(countryid);
		account.setCountry(country);
		long currencyid = accountSetup.getCurrencyId();
		Currency currency = currencyRepository.findOne(currencyid);
		account.setCurrency(currency);

		long industryId = accountSetup.getIndustryId();
		Industry industry = industryRepository.findOne(industryId);
		account.setIndustry(industry);
		account.setUpdatedAt(currentDate);
		byte[] logoByte = null;
		if (accountSetup.getLogo() != null) {
			logoByte = accountSetup.getLogo().getBytes(StandardCharsets.UTF_8);
			account.setLogo(logoByte);
		}

		account.setFiscalStart(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
				accountSetup.getFiscalStart()));

		LOG.debug("after copy the properties " + account);

		account = accountSetupRepository.saveAndFlush(account);
		// save into elastic search
		manualAccountStrategy.setVendorName(SearchConstants.MANUAL);
		manualAccountStrategy.setVendorType(SearchConstants.MANUAL);
		manualAccountStrategy.setInstanceName(SearchConstants.MANUAL_INSTANCE);
		manualAccountStrategy.setName(companyName);
		manualAccountStrategy.setAddressLine1(address1);
		manualAccountStrategy.setAddressLine2(address2);
		manualAccountStrategy.setAddressLine3(address3);
		manualAccountStrategy.setCity(city);
		manualAccountStrategy.setState(state);
		manualAccountStrategy.setCountryName(country.getCountryName());
		manualAccountStrategy.setCurrencyName(currency.getName());
		manualAccountStrategy.setBusinessUnit(businessUnit);
		manualAccountStrategy.setAnnualRevenue(accountSetup.getAnnualRevenue());
		manualAccountStrategy.setNoOfEmployees(accountSetup.getNumOfEmployee());
		manualAccountStrategy.setIndustry(industry.getIndustryName());
		manualAccountStrategy.setWebsite(website);
		manualAccountStrategy.setFiscalStart(accountSetup.getFiscalStart());
		manualAccountStrategy.setLogo(accountSetup.getLogo());
		manualAccountStrategy.setDraft(accountSetup.isDraft());
		manualAccountStrategy.setCreatedDate(DateUtilities.dateToString(account.getCreatedAt()));
		manualAccountStrategy.setLastModifiedDate(DateUtilities.dateToString(currentDate));
		manualAccountStrategy.setZipCode(zipCode);
		manualAccountStrategy
				.setAccountStrategyDocumentRefId(Integer.toString(Calendar.getInstance().get(Calendar.YEAR)));

		String accountJson = mapper.writeValueAsString(manualAccountStrategy);

		Client client = getTransportClient();
		IndexResponse response = client.prepareIndex(getIndex(), getDocumentType(), String.valueOf(SearchConstants.ACCOUNT_DB_ID))
										.setSource(accountJson).execute().actionGet();

		LOG.debug("saveAccountSetupDetails : index response : " + response);
	}

	/**
	 *
	 * @return
	 */
	private List<Currency> getCurrencies(String...currencyCodes) {
		List<String> currencyCodesList = Arrays.asList(currencyCodes);

		List<Currency> currencyList = null;

		SearchRequestBuilder requestBuilder = getTransportClient().prepareSearch(SearchConstants.MANUAL)
				.setTypes(SearchConstants.CURRENCY);

//		LOG.debug("getCurrencies : Query :: " + requestBuilder);

		SearchResponse response = requestBuilder.execute().actionGet();

		SearchHits hits = response.getHits();

		SearchHit[] hitsArr = hits.getHits();
		if (ArrayUtils.isNotEmpty(hitsArr)) {
			Map<String, Object> currencies = hitsArr[0].getSource();
			List<Map<String, Object>> allCurrencyList = (ArrayList<Map<String, Object>>) currencies.get(SearchConstants.CURRENCY);
			currencyList = new ArrayList<>();
			for (Map<String, Object> currencyObj : allCurrencyList) {
				String currencyCode = (String) currencyObj.get("code");
				if (currencyCodesList.contains(currencyCode)) {
					Currency currency = new Currency();
					currency.setValue(((Number) currencyObj.get("value")).longValue());
					currency.setName((String) currencyObj.get("name"));
					currency.setCode(currencyCode);
					currencyList.add(currency);
				}
			}
		} else {
			currencyList = currencyRepository.findByCodeIn(currencyCodesList);
		}

		return currencyList;
	}

	/**
	 *
	 * @return
	 */
	private List<?> getCountries() {
		LOG.debug("Enter into getCountries");

		List<?> countryList = null;

		SearchResponse response = getTransportClient().prepareSearch(SearchConstants.MANUAL)
				.setTypes(SearchConstants.COUNTRY).execute().actionGet();

		SearchHits hits = null;
		if (response != null)
			hits = response.getHits();
		SearchHit[] hitsArr = hits.getHits();
		if (ArrayUtils.isNotEmpty(hitsArr)) {
			Map<String, Object> countries = null;
			countries = hitsArr[0].getSource();
			countryList = (List<?>) countries.get(SearchConstants.COUNTRY);
		} else {
			countryList = countryRepository.findAll();
			LOG.debug("countries from DB:::" + countryList.size());
		}

		return countryList;
	}

	/**
	 *
	 * @return
	 */
	private List<?> getIndusties() {
		LOG.debug("Enter into getIndusties");
		List<?> industryList = null;
		SearchResponse response = getTransportClient().prepareSearch(SearchConstants.MANUAL)
				.setTypes(SearchConstants.INDUSTRY).execute().actionGet();

		SearchHits hits = null;
		if (response != null)
			hits = response.getHits();

		SearchHit[] hitsArr = hits.getHits();
		if (ArrayUtils.isNotEmpty(hitsArr)) {
			Map<String, Object> industries = null;
			industries = hitsArr[0].getSource();
			industryList = (List<?>) industries.get(SearchConstants.INDUSTRY);
		} else {
			industryList = industryRepository.findAll();
		}

		return industryList;
	}

	public AccountSetup getAccountDetails() {
		LOG.info("Enter into getAccountDetails");
		Map<String, Object> accountDetails = null;
		AccountSetup accountSetup = new AccountSetup();
		Account account = new Account();
		try {
			String companyName = null;
			String businessUnit = null;
			String address1 = null;
			String address2 = null;
			String address3 = null;
			String city = null;
			String state = null;
			String zipCode = null;
			int countryId = 0;
			int industryId = 0;
			Integer numOfEmployee = 0;
			int currencyId = 0;
			Double annualRevenue = null;
			String website = null;
			String logo = null;
			boolean isDraft = false;
			String fiscalStart = null;

			GetRequestBuilder getRequestBuilder = getTransportClient().prepareGet(getIndex(), getDocumentType(),
					String.valueOf(SearchConstants.ACCOUNT_DB_ID));
			GetResponse response = esQueryUtils.execute(getRequestBuilder);

			accountDetails = response.getSource();
			if (MapUtils.isNotEmpty(accountDetails)) {
				accountDetails = response.getSource();

				ManualAccountStrategy manualAccountStrategy = JacksonUtils.convertValue(accountDetails,
						ManualAccountStrategy.class);
				companyName = StringUtils.defaultString(manualAccountStrategy.getName());
				businessUnit = StringUtils.defaultString(manualAccountStrategy.getBusinessUnit());
				address1 = StringUtils.defaultString(manualAccountStrategy.getAddressLine1());
				address2 = StringUtils.defaultString(manualAccountStrategy.getAddressLine2());
				address3 = StringUtils.defaultString(manualAccountStrategy.getAddressLine3());
				city = StringUtils.defaultString(manualAccountStrategy.getCity());
				state = StringUtils.defaultString(manualAccountStrategy.getState());
				zipCode = StringUtils.defaultString(manualAccountStrategy.getZipCode());
				countryId = countryRepository.findOneByCountryName(manualAccountStrategy.getCountryName().toLowerCase()).getValue().intValue();
				industryId = industryRepository.findOneByIndustryName(manualAccountStrategy.getIndustry().toLowerCase()).getValue().intValue();
				currencyId = currencyRepository.findOneByName(manualAccountStrategy.getCurrencyName().toLowerCase()).getValue().intValue();
				numOfEmployee = manualAccountStrategy.getNoOfEmployees();
				annualRevenue = manualAccountStrategy.getAnnualRevenue();
				website = manualAccountStrategy.getWebsite();
				logo = StringUtils.defaultString(manualAccountStrategy.getLogo());
				isDraft = manualAccountStrategy.isDraft();
				fiscalStart = StringUtils.defaultString(manualAccountStrategy.getFiscalStart());
			} else {
				accountDetails = new HashMap<String, Object>();
				account = accountSetupRepository.findOne(SearchConstants.ACCOUNT_DB_ID);
				companyName = StringUtils.defaultString(account.getCompanyName());
				businessUnit = StringUtils.defaultString(account.getBusinessUnit());
				address1 = StringUtils.defaultString(account.getAddress1());
				address2 = StringUtils.defaultString(account.getAddress2());
				address3 = StringUtils.defaultString(account.getAddress3());
				city = StringUtils.defaultString(account.getCity());
				state = StringUtils.defaultString(account.getState());
				zipCode = StringUtils.defaultString(account.getZipCode());
				countryId = account.getCountry().getValue().intValue();
				industryId = account.getIndustry().getValue().intValue();
				currencyId = account.getCurrency().getValue().intValue();
				numOfEmployee = account.getNumOfEmployee();
				annualRevenue = account.getAnnualRevenue();
				website = account.getWebsite();
				if (account.getLogo() != null) {
					logo = new String(account.getLogo(), StandardCharsets.UTF_8);
				}
				isDraft = account.isDraft();
				fiscalStart = DateUtilities.dateToString(account.getFiscalStart());
			}
			accountSetup.setCompanyName(companyName);
			accountSetup.setBusinessUnit(businessUnit);
			accountSetup.setAddress1(address1);
			accountSetup.setAddress2(address2);
			accountSetup.setAddress3(address3);
			accountSetup.setCity(city);
			accountSetup.setState(state);
			accountSetup.setZipCode(zipCode);
			accountSetup.setCountryId(countryId);
			accountSetup.setIndustryId(industryId);
			accountSetup.setCurrencyId(currencyId);
			accountSetup.setNumOfEmployee(numOfEmployee);
			accountSetup.setAnnualRevenue(annualRevenue);
			accountSetup.setWebsite(website);
			accountSetup.setLogo(logo);
			accountSetup.setDraft(isDraft);
			accountSetup.setFiscalStart(fiscalStart);

		} catch (Exception e) {
			LOG.error("Error in get account details service" + e.getMessage(), e);
		}

		return accountSetup;
	}

}
