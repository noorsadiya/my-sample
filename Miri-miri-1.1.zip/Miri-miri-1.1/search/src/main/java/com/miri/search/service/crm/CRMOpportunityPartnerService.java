/**
 * 
 */
package com.miri.search.service.crm;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.CrmOpportunityPartner;
import com.miri.search.service.common.MiriSearchService;

/**
 * @author chavanka
 *
 */
@Component
public class CRMOpportunityPartnerService extends MiriSearchService {

    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getIndex()
     */
    @Override
    public String getIndex() {
        return ElasticSearchEnums.CRM.getText();
    }

    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getDocumentType()
     */
    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.CRM_PARTNER.getText();
    }
    
    /**
     * Returns partners for the given opportunity.
     * 
     * @param opportunityId
     * @return
     */
    public List<CrmOpportunityPartner> getPartnersByOpportunityId(final String opportunityId) {

        SearchResponse searchResponse = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
                .setQuery(QueryBuilders.termsQuery("opportunityId.raw", opportunityId)).execute().actionGet();
        SearchHits searchHits = searchResponse.getHits();

        List<CrmOpportunityPartner> entities = new ArrayList<>();
        Iterator<SearchHit> searcHitsItr = searchHits.iterator();
        while (searcHitsItr.hasNext()) {
            SearchHit searchHit = searcHitsItr.next();
            entities.add(
                (CrmOpportunityPartner) ESObjectMapper.getObject(searchHit.getSource(), getDocumentType(), getIndex()));

        }
        return entities;
    }

}
