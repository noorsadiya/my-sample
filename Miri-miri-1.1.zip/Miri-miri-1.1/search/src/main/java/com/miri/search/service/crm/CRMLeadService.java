/**
 * 
 */
package com.miri.search.service.crm;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.CrmCampaign;
import com.miri.cis.entity.CrmLead;
import com.miri.cis.entity.CrmOpportunity;
import com.miri.search.constants.CRMConstants;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;

/**
 * @author Chandra
 *
 */
@Component
public class CRMLeadService extends MiriSearchService {

	private static final Logger LOGGER = Logger.getLogger(CRMLeadService.class);
	
	@Autowired
	ESQueryUtils esQueryUtils;
	
	/**
	 * Gets all campaigns from Lead Document by given campaignId and optional
	 * attributes.
	 * 
	 * @param campaignId
	 * @param mustParams
	 * @return
	 */
	public List<CrmLead> getAllLeadsByCampaignIdAndOppAttributes(final CrmCampaign crmCampaign,
			final CrmOpportunity crmOpportunity) {

		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery()
				.must(QueryBuilders.termQuery(CRMConstants.CAMPAIGN_ID_RAW, crmCampaign.getCampaignId()));

		if (null != crmOpportunity) {
			boolQueryBuilder.must(QueryBuilders.termQuery("campaignId.raw", crmOpportunity.getPrimaryCampSource()))
					.must(QueryBuilders.termQuery("accountName.raw", crmOpportunity.getCompanyName()))
					.must(QueryBuilders.termQuery("accountId.raw", crmOpportunity.getAccountId()))
					.must(QueryBuilders.termQuery("leadSource.raw", crmOpportunity.getLeadSource()))
					.must(QueryBuilders.termQuery("leadOwner.raw", crmOpportunity.getOwner()));
		}
		boolQueryBuilder
				.must(QueryBuilders.rangeQuery(CRMConstants.LEAD_CREATED_DATE).lte(crmOpportunity.getCreatedOn()));
		boolQueryBuilder
		.must(QueryBuilders.rangeQuery(CRMConstants.LEAD_CREATED_DATE).gte(crmCampaign.getCreatedDate()));

		SearchRequestBuilder srb = getTransportClient().prepareSearch(getIndex());
		SearchResponse response = srb.setTypes(getDocumentType()).setQuery(boolQueryBuilder).execute().actionGet();
		SearchHits searchHits = response.getHits();

		if (searchHits == null || searchHits.getTotalHits() == 0) {
			//
			boolQueryBuilder = QueryBuilders.boolQuery()
					.must(QueryBuilders.termQuery(CRMConstants.CAMPAIGN_ID_RAW, crmCampaign.getCampaignId()));

			if (null != crmOpportunity) {
				boolQueryBuilder.must(QueryBuilders.termQuery("campaignId.raw", crmOpportunity.getPrimaryCampSource()))
						.must(QueryBuilders.termQuery("accountName.raw", crmOpportunity.getCompanyName()))
						.must(QueryBuilders.termQuery("accountId.raw", crmOpportunity.getAccountId()))
						.should(QueryBuilders.termQuery("leadSource.raw", crmOpportunity.getLeadSource()))
						.should(QueryBuilders.termQuery("leadOwner.raw", crmOpportunity.getOwner()));
			}
			boolQueryBuilder
					.must(QueryBuilders.rangeQuery(CRMConstants.LEAD_CREATED_DATE).lte(crmOpportunity.getCreatedOn()));
			boolQueryBuilder
			.must(QueryBuilders.rangeQuery(CRMConstants.LEAD_CREATED_DATE).gte(crmCampaign.getCreatedDate()));
			
			srb = getTransportClient().prepareSearch(getIndex());
			response = srb.setTypes(getDocumentType()).setQuery(boolQueryBuilder).execute().actionGet();
			searchHits = response.getHits();
		}
		List<CrmLead> crmLeads = new ArrayList<>();
		CrmLead crmLead = null;
		for (SearchHit searchHit : searchHits) {
			Map<String, Object> map = searchHit.getSource();
			crmLead = (CrmLead) ESObjectMapper.getObject(map, getDocumentType(), getIndex());
			if (null != crmLead) {
				crmLeads.add(crmLead);
			}
		}
		LOGGER.info("Number of Leads matched for the given campaign & opportunity: " + crmLeads.size());
		return crmLeads;
	}

	/**
	 * Returns CRM Leads for the given CRM campaign Id.
	 * 
	 * @param campaignId
	 * @return
	 */
    public List<CrmLead> getCRMLeadsByCRMCampaignId(final String campaignId) {
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery()
				.must(QueryBuilders.termQuery("campaignId.raw", campaignId));
		
		SearchRequestBuilder srb = getTransportClient().prepareSearch(getIndex());
		SearchResponse response = srb.setTypes(getDocumentType()).setQuery(boolQueryBuilder).execute().actionGet();
		SearchHits searchHits = response.getHits();

		List<CrmLead> crmLeads = new ArrayList<>();
		CrmLead crmLead = null;
		for (SearchHit searchHit : searchHits) {
			Map<String, Object> map = searchHit.getSource();
			crmLead = (CrmLead) ESObjectMapper.getObject(map, getDocumentType(), getIndex());
			if (null != crmLead) {
				crmLeads.add(crmLead);
			}
		}
		return crmLeads;
	
    }

	/**
	 * Returns CRM Lead for the given CRM Lead Id.
	 * 
	 * @param campaignId
	 * @return
	 */
	public CrmLead getCRMLeadByLeadId(final String leadId) {
		return (CrmLead) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), CRMConstants.LEAD_ID_RAW,
				leadId);

	}
    
    @Override
    public String getIndex() {
        return ElasticSearchEnums.CRM.getText();
    }

    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.CRM_LEAD.getText();
    }
}
