package com.miri.search.constants;

/**
 * MAP index related field Constants - Prefix the document type to the field
 * @author rammoole
 *
 */
public final class MAPConstants {
	// Lead
	public static final String LEAD_COMPANY_NAME_RAW = "companyName.raw";
	public static final String LEAD_OWNER_RAW = "leadOwner.raw";
	public static final String LEAD_SOURCE_RAW = "leadSource.raw";
	public static final String LEAD_ID_RAW = "leadId.raw";
	public static final String CAMPAIGNID_RAW = "campaignId.raw";
	public static final String MAP_LEAD_CREATED_DATE = "createdDate";
	public static final String LEAD_ID = "leadId";
	public static final String LEAD_COMPANY_ID_RAW = "companyId.raw";
	public static final String LEAD_INDUSTRY_RAW = "industry.raw";
	
	// Opportunity
	public static final String OPPORTUNITY_CREATED_ON = "createdOn";
	public static final String OPPORTUNITY_CREATED_DATE = "createdDate";
	public static final String OPPORTUNITY_STAGE = "stage";
	public static final String OPPORTUNITY_STAGE_RAW = "stage.raw";
	
	//campaign
	public static final String CAMPAIGN_PARENTCAMPAIGN_ID_RAW = "parentCampaignId.raw";
	public static final String CAMPAIGN_ACTUAL_COST = "actualCost";
	public static final String CAMPAIGN_ID = "campaignId";
	public static final String LEAD_CREATED_DATE = "createdDate";
	public static final String CAMPAIGN_ID_RAW = "campaignId.raw";
	
	public static final String CAMPAIGN_NAME = "campaignName";
	public static final String CAMPAIGN_START_DATE = "startDate";
	public static final String PARENT_CAMPAIGN_NAME = "parentCampaignName";

}
