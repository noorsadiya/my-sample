package com.miri.search.service.erp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.ErpSalesOrder;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.esutils.AggregationUtil;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;

/**
 * Services pertaining to erp/erp_sales_order document in elastic search
 * @author noor
 *
 */
@Component
public class ERPSalesOrderService extends MiriSearchService {
	
	private static final Logger LOG = LogManager.getLogger(ERPSalesOrderService.class);
	
	@Autowired
	ESQueryUtils esQueryUtils;

	/**
	 * get the Sales Order by opportunityId
	 * @param opportunityId
	 * @return
	 */
	public List<ErpSalesOrder> getSalesOrderByOpportunityId(String opportunityId) {
		Client client = this.getTransportClient();
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_SALESORDER.getText())
				.setSize(300)
				.setQuery(QueryBuilders.termQuery(SearchConstants.OPPORTUNITY_ID_RAW, opportunityId));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<ErpSalesOrder> erpSalesOrders = new ArrayList<>();
			for (SearchHit searchHit : searchResponse.getHits()) {
				erpSalesOrders.add((ErpSalesOrder) ESObjectMapper.getObject(searchHit.getSource(), getDocumentType(), getIndex()));
			}
		return erpSalesOrders;
	}

	/**
	 * Get Sales Order by sales person and opportunity Id
	 * @param opportunityId
	 * @param owner
	 * @return
	 */
	public List<ErpSalesOrder> getSalesOrderBySalesPersonAndOpportunityId(String opportunityId, String owner) {
		Client client = this.getTransportClient();
		SearchResponse searchResponse = client.prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_SALESORDER.getText())
				.setQuery(QueryBuilders.boolQuery().must(QueryBuilders.termQuery(SearchConstants.ACCOUNT_OWNER_RAW, owner)).must(QueryBuilders.termQuery(SearchConstants.OPPORTUNITY_ID_RAW, opportunityId)))
				.setSearchType(SearchType.SCAN)
				.setSize(300)
				.setScroll(new TimeValue(6000))
				.get();
		
		List<ErpSalesOrder> erpSalesOrders = new ArrayList<>();
		while (true) {
			for (SearchHit searchHit : searchResponse.getHits()) {
				erpSalesOrders.add((ErpSalesOrder) ESObjectMapper.getObject(searchHit.getSource(), getDocumentType(), getIndex()));
			}
			searchResponse = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000))
					.get();
			if (searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return erpSalesOrders;
	}

	/**
	 * Get ERP Sales Order by opportunity Ids
	 * @param opportunityIds
	 * @return
	 * @author rammoole
	 */
	public List<ErpSalesOrder> getSalesOrderByOpportunityIds(List<String> opportunityIds) {
		// Sales Order dates for opportunityIds
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_SALESORDER.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)); 
		SearchResponse searchResponse = searchRequestBuilder.get();
		List<ErpSalesOrder> erpSalesOrders = null;
		if(searchResponse != null) {
			SearchHits searchHits = searchResponse.getHits();
			erpSalesOrders = new ArrayList<>();
			for(SearchHit searchHit: searchHits) {
				erpSalesOrders.add((ErpSalesOrder) ESObjectMapper.getObject(searchHit.getSource(), ElasticSearchEnums.ERP_SALESORDER.getText(), ElasticSearchEnums.ERP.getText()));
			}
		}
		return erpSalesOrders;
	}

	/**
	 * Get all the ERP Sales order by sales person name with in the time frame
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public List<ErpSalesOrder> getSalesOrderBySalesPerson(String salesPersonName, String startDate, String endDate) {
		Client client = this.getTransportClient();
		SearchResponse scrollResponse = client.prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_SALESORDER.getText())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(60000))
				.setSize(500)
				.setQuery(QueryBuilders.termQuery(SearchConstants.ACCOUNT_OWNER_RAW, salesPersonName))
				.setPostFilter(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).gte(startDate).lte(endDate))
				.get();
		List<ErpSalesOrder> erpSalesOrderList = new ArrayList<>();
		while(true) {
			for (SearchHit hit : scrollResponse.getHits().getHits()) {
				erpSalesOrderList.add((ErpSalesOrder) ESObjectMapper.getObject(hit.getSource(), ElasticSearchEnums.ERP_SALESORDER.getText(), ElasticSearchEnums.ERP.getText()));
			}
			scrollResponse = client.prepareSearchScroll(scrollResponse.getScrollId()).setScroll(new TimeValue(60000)).execute().actionGet();
			//Break condition: No hits are returned
			if (scrollResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return erpSalesOrderList;
	}

	/**
	 * Get Sales Order Average creation date by opportunity Ids
	 * @param opportunityIds
	 * @return
	 */
	public Map<String, Long> getAvgSalesOrderCreatedDateAndCountByOpportunityIds(List<String> opportunityIds) {
		//LOG.info("Average Sales Order Creation Date ");
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_SALESORDER.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.avg(SearchConstants.AVG_AGGREGATION).field(ERPConstants.SALES_ORDER_CREATED_DATE));
		//LOG.info("Average Sales Order Creation :" + searchRequestBuilder);
		SearchResponse searchResponse = searchRequestBuilder.get();
		Map<String, Long> countAndAvgCreationDate = new HashMap<>();
		countAndAvgCreationDate.put(SearchConstants.COUNT, searchResponse.getHits().getTotalHits());
		countAndAvgCreationDate.put(SearchConstants.AVG_CREATION_DATE, ((Double) AggregationUtil.getAggregationValue(searchResponse, SearchConstants.AVG_AGGREGATION, SearchConstants.AVG_AGGREGATION_TYPE)).longValue());
		return countAndAvgCreationDate;
	}
	

	/**
	 * Get sales
	 * @param opportunityIds
	 * @return
	 */
	public double getSumSalesOrderTimeByOpportunityIds(List<String> erpSalesOrderIds) {
		SearchResponse searchResponse = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_SALESORDER.getText())
				.setSize(0)
				.setQuery(QueryBuilders.termsQuery(SearchConstants.ORDER_ID_RAW, erpSalesOrderIds))
				.addAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field("activatedDate"))
				.get();
		return AggregationUtil.getAggregationValue(searchResponse, SearchConstants.SUM_AGGREGATION, SearchConstants.SUM_AGGREGATION_TYPE);
	}

	/**
	 * Process Opportunities in batches for average creation time
	 * @param salesOrderIds
	 * @return
	 */
	public double processSalesOrdersInBatchesForAvgCreationDate(List<String> salesOrderIds) {
		double creationTimeSum = 0;
		int batchSize = 1000;
		int start = 0;
		int end = batchSize;
		int outerForCount = salesOrderIds.size() / batchSize; // this is like the number of iterations
		int remainingItems = salesOrderIds.size() % batchSize; // This is for any remaining data after the iterations
		for(int i = 0; i < outerForCount; i++) {
			creationTimeSum += this.getSumSalesOrderTimeByOpportunityIds(salesOrderIds.subList(start, end));
			start = start + batchSize;
			end = end + batchSize;
		}
		if(remainingItems != 0) {
			end = end - batchSize + remainingItems;
			creationTimeSum += this.getSumSalesOrderTimeByOpportunityIds(salesOrderIds.subList(start, end));
		}
		return creationTimeSum / salesOrderIds.size();
	}

	@Override
	public String getIndex() {
		return ElasticSearchEnums.ERP.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.ERP_SALESORDER.getText();
	}
}
