package com.miri.search.service.erp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.FilteredQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeFilterBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.bucket.histogram.InternalHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.CampaignRevenueData;
import com.miri.search.data.FiscalDatesData;
import com.miri.search.data.FiscalDatesStrData;
import com.miri.search.data.MultipleAxesChartData;
import com.miri.search.esutils.AggregationUtil;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.manual.ManualAccountStrategyService;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.TimerUtil;

@Component
public class RevenueGeneratedService extends MiriSearchService {

	private static final Logger LOG = LogManager.getLogger(RevenueGeneratedService.class);

	@Autowired
	ProductInvoiceService productInvoiceService;

	@Autowired
	ManualAccountStrategyService manualAccountStrategyService;

	@Autowired
	TimerUtil timeUtil;

	@Autowired
	ESQueryUtils esQueryUtils;
	
	public Map<String, Double> getInvoicAmountByOpportunity() {
		Map<String, Double> invoiceByOpportunityMap = new HashMap<String, Double>();

		Client client = getTransportClient();

		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder termAggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field("opportunityId.raw").subAggregation(sumInvoiceAmountByMonth);

		SearchResponse response = client.prepareSearch(ElasticSearchEnums.ERP.getText()).setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.addAggregation(termAggr).setSearchType(SearchType.QUERY_AND_FETCH).execute().actionGet();

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> buckets = terms.getBuckets();

		for (Terms.Bucket bucket : buckets) {
			Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			invoiceByOpportunityMap.put(bucket.getKeyAsText().toString(), sum.getValue());
		}
		return invoiceByOpportunityMap;
	}

	/**
	 * This method is used to get the sum of all the opportunities invoice
	 * 
	 * @param opportunities
	 * @param startDate
	 *            TODO
	 * @param endDate
	 *            TODO
	 * @return
	 */
	public Double getInvoiceSumForOpportunites(List<String> opportunities, String startDate, String endDate) {
		timeUtil.start();
		Client client = getTransportClient();
		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunities));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).gte(startDate).lte(endDate));

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(sumInvoiceAmountByMonth).setSize(0);
		
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		Sum sum = (Sum) response.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
		timeUtil.end();
		return sum.getValue();
	}

	/**
	 * This method is used to get the average time to revenue for a campaign
	 * month wise
	 * 
	 * @param overallCampaignIds
	 *            Map containing campaign Id's and there start date
	 * @return Map containing campaign and its month wise average time to
	 *         revenue
	 */
	public SearchResponse getInvoiceAmountOfOpportunitiesResponse(List<String> opportunityIds) {
		Client client = getTransportClient();
		FiscalDatesData fiscaldates = manualAccountStrategyService.get1YearDates();

		String minBound = MiriDateUtils.getElasticSearchFormattedDate(fiscaldates.getFiscalStartDate());
		String maxBound = MiriDateUtils.getElasticSearchFormattedDate(fiscaldates.getFiscalEndDate());

		BoolQueryBuilder termsQuery = MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW,
				opportunityIds, 1000);

		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder invoiceDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(SearchConstants.CREATED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(minBound, maxBound).minDocCount(0).subAggregation(sumInvoiceAmountByMonth);

		RangeFilterBuilder rangeFilter = FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.from(minBound).to(maxBound).includeLower(false).includeUpper(false);

		FilteredQueryBuilder rangeFilterQuery = QueryBuilders.filteredQuery(termsQuery, rangeFilter);

		SearchResponse invoiceResponse = client.prepareSearch(ElasticSearchEnums.ERP.getText()).setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
						FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE).from(minBound)
								.to(maxBound).includeLower(false).includeUpper(false)))
				.addField(SearchConstants.CREATED_DATE).addAggregation(invoiceDateAggregation)
				.setQuery(rangeFilterQuery).execute().actionGet();

		return invoiceResponse;

	}

	/**
	 * It will be used to get the response from ES by giving dynamic values for
	 * query builder, index and document type
	 * 
	 * @param queryBuilder
	 *            Query to be Executed
	 * @param index
	 *            Index on which query shoukd be executed
	 * 
	 * @param type
	 *            Document type on for query execution
	 * @param fields
	 * 
	 * @return {@link SearchResponse}
	 */
	public SearchResponse getResponse(QueryBuilder queryBuilder, String index, String type, String[] fields) {
		Client client = getTransportClient();
		return client.prepareSearch(index).setTypes(type).setSearchType(SearchType.DFS_QUERY_THEN_FETCH).setSize(20)
				.addFields(fields).setQuery(queryBuilder).execute().actionGet();

	}

	/**
	 * 
	 * It is used to get list of the opportunity ID's from the ES Search
	 * Response
	 * 
	 * @param searchResponse
	 *            ES Search Response which contains Opportunity ID's
	 * @return {@link List} Contains all the ID's from ES search response
	 */
	public List<String> getOpportunityIds(SearchResponse searchResponse) {

		List<String> opportunities = new ArrayList<String>();
		for (SearchHit hit : searchResponse.getHits()) {
			opportunities.add(hit.field(SearchConstants.OPPORTUNITY_ID).getValue().toString());
		}
		return opportunities;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<Object, CampaignRevenueData> getCampaignRevenueByMonthAndOpportunities(Calendar startDate,
			Calendar endDate, List<String> opportunties) {
		
		String startDateStr = MiriDateUtils.getElasticSearchFormattedDate(startDate);
		String endDateStr = MiriDateUtils.getElasticSearchFormattedDate(endDate);

		Map<Integer, Double> productSumByMonth = productInvoiceService.getProductQuantiesByMonth(opportunties,startDate, endDate);

		Map<Integer, String> monthAndYearMap = MiriDateUtils.getMonthsBetweenDates(startDate, endDate);
		List<Integer> months = new LinkedList<>(monthAndYearMap.keySet());

		SearchResponse searchResponse = getRevenueGeneratedByMonthAndOpportunitiesResponse(startDate, endDate,
				opportunties);
		InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		Map<Object, CampaignRevenueData> resultsMap = MiriSearchUtils.populateCampaignRevenuePojoResult(buckets,
				productSumByMonth, months, startDateStr, endDateStr);
		return resultsMap;
	}

	/**
	 * Returns the sum of revenue amount for every month in the fiscal year
	 * index: Manual Document: business_strategy
	 * 
	 * @param startDate
	 * @param endDate
	 * @return Map<Integer,RevenuePojo> Integer: Month RevenuePojo: revenue
	 *         generated for that month
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, MultipleAxesChartData> getRevenueByMonthAndOpportunities(Calendar startDate, Calendar endDate,
			List<String> opportunities) {
		// Return the sum of product quantities for every month in the fiscal
		//Map<Integer, Double> productSumByMonth = productInvoiceService.getProductQuantiesByMonth(opportunities,startDate, endDate);

		Map<Integer, String> monthAndYearMap = MiriDateUtils.getMonthsBetweenDates(startDate, endDate);
		List<Integer> months = new LinkedList<>(monthAndYearMap.keySet());

		SearchResponse searchResponse = getRevenueGeneratedByMonthAndOpportunitiesResponse(startDate, endDate,
				opportunities);

		timeUtil.start();
		InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		Map<Integer, MultipleAxesChartData> resultsMap = MiriSearchUtils.populateRevenuePojoResult(buckets, null,
				months);
		timeUtil.end();
		LOG.debug("getTotalInvoicesByMonthOpportunities :- Java Processing Time" + timeUtil.timeTakenInMillis());

		return resultsMap;
	}
	
	public List<MultipleAxesChartData> populateRevenuePojoResultForInvoices(Collection<InternalHistogram.Bucket> buckets, String productName, Collection<InternalHistogram.Bucket> previousFYBuckets, String startDate, String endDate) {
		int monthIndex = 0;
		MultipleAxesChartData revenueData;
		List<MultipleAxesChartData> revenueDataList = new ArrayList<>();
		List<InternalHistogram.Bucket> curretFiscalBuckets = new ArrayList<>(buckets);
		List<InternalHistogram.Bucket> previousFiscalBuckets = new ArrayList<>(previousFYBuckets);
		Map<Integer, String> updatedDates = MiriDateUtils.getUpdatedDates(startDate, endDate);
		final boolean isCurrentFiscal = true;
		for(int index = 0; (CollectionUtils.isNotEmpty(curretFiscalBuckets) && index < curretFiscalBuckets.size()); index++) {
			if(updatedDates.get(monthIndex)!=null){
				revenueData = new MultipleAxesChartData();
				// Passing true to specify current fiscal buckets data
				getRevenueDataObject(revenueData, curretFiscalBuckets, index, isCurrentFiscal);
				
				// Passing last parameter false to specify previous fiscal buckets and sets the previousFyAvgRevenue only.
				getRevenueDataObject(revenueData, previousFiscalBuckets, index, !isCurrentFiscal);
				
				revenueData.setxAxis(monthIndex);
				revenueData.setProductName(productName);
				revenueDataList.add(revenueData);
			} else {
				revenueDataList.add(null);
			}
			monthIndex++;
		}
		return revenueDataList;
	}

	/**
	 * @param revenueData
	 * @param curretFiscalBuckets
	 * @param index
	 * @return
	 */
	private void getRevenueDataObject(MultipleAxesChartData revenueData,
			List<InternalHistogram.Bucket> curretFiscalBuckets, int index, boolean isCurrentFiscal) {
		long customers;
		double averageRevenue;
		Sum sum = (Sum) curretFiscalBuckets.get(index).getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
		Terms opportunityTerms = curretFiscalBuckets.get(index).getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
		customers = (long) opportunityTerms.getBuckets().size();
		if(customers > 0) {
			averageRevenue = sum.getValue() / customers;
		} else {
			averageRevenue = 0;
		}
		averageRevenue = Double.isNaN(averageRevenue) ? 0 : averageRevenue;
		if(isCurrentFiscal) {
			revenueData.setCustomersCount((int) customers);
			revenueData.setRevenueAmount(sum.getValue());
			revenueData.setAverageRevenue(averageRevenue);
		} else {
			revenueData.setPreviousFyAvgRevenue(averageRevenue);
		}
	}
	
	
	public SearchResponse getRevenueGeneratedByMonthAndOpportunitiesResponse(Calendar startDate, Calendar endDate,
			List<String> opportunities) {
		timeUtil.start();

		String minBound = MiriDateUtils.getElasticSearchFormattedDate(startDate);
		String maxBound = MiriDateUtils.getElasticSearchFormattedDate(endDate);

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();

		if (CollectionUtils.isNotEmpty(opportunities)) {
			boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunities));
			// rangeFilterQuery = QueryBuilders.filteredQuery(termsQuery,
			// rangeFilter);
		}

		if (StringUtils.isNotEmpty(minBound) && StringUtils.isNotEmpty(maxBound)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE).from(minBound)
					.to(maxBound).includeLower(true).includeUpper(true));
		}
		
		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder sumProductQuantityByMonth = AggregationUtil
				.sumAggregation(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION, ERPConstants.INVOICE_PRODUCT_QUANTITY);
		
		AbstractAggregationBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION).field(ERPConstants.OPPORTUNITY_ID_RAW).size(0);
		// Create a aggregation to sort the invoices by month
		AbstractAggregationBuilder invoiceDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(minBound, maxBound).minDocCount(0).subAggregation(sumInvoiceAmountByMonth).subAggregation(opportunityAggregation)
				.subAggregation(sumProductQuantityByMonth);

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(invoiceDateAggregation).setSize(0);

		timeUtil.end();
		LOG.debug("getRevenueGeneratedByMonthAndOpportunitiesResponse ES Time Taken" + timeUtil.timeTakenInMillis());
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		return response;
	} 
	
	/**
	 * Gets the Month Wise revenue for Invoices 
	 * @param startDate
	 * @param endDate
	 * @param opportunities
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<MultipleAxesChartData> getRevenueGeneratedByMonthAndInvoiceResponse(String startDate, String endDate,
			List<String> invoiceItems, String productName) {
		timeUtil.start();
		
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		BoolFilterBuilder previousFiscalBoolFilter = FilterBuilders.boolFilter();
		
		if (CollectionUtils.isNotEmpty(invoiceItems)) {
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.INVOICE_ITEMS_RAW, invoiceItems));
			previousFiscalBoolFilter.must(FilterBuilders.termsFilter(ERPConstants.INVOICE_ITEMS_RAW, invoiceItems));
			// rangeFilterQuery = QueryBuilders.filteredQuery(termsQuery,
			// rangeFilter);
		}
		
		if (StringUtils.isNotEmpty(startDate) && StringUtils.isNotEmpty(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE).from(startDate)
					.to(endDate).includeLower(true).includeUpper(true));
			
			// Getting previous fiscal dates for hover values
			FiscalDatesStrData previousFiscalDates = manualAccountStrategyService.getPreviousYearDatesStr();
			previousFiscalBoolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE).gte(previousFiscalDates.getFiscalStartDateStr())
					.lte(previousFiscalDates.getFiscalEndDateStr()));
		}
		
		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);
		
		
		
		AbstractAggregationBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION).field(ERPConstants.INVOICE_ACCOUNT_NAME_RAW).size(0);
		// Create a aggregation to sort the invoices by month
		AbstractAggregationBuilder invoiceDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(startDate, endDate).minDocCount(0).subAggregation(sumInvoiceAmountByMonth).subAggregation(opportunityAggregation);
				
		
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(invoiceDateAggregation).setSize(0);
		
		timeUtil.end();
		LOG.debug("getRevenueGeneratedByMonthAndOpportunitiesResponse ES Time Taken" + timeUtil.timeTakenInMillis());
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		
		SearchRequestBuilder previousFiscalSearchRequestBuilder = getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), previousFiscalBoolFilter))
				.addAggregation(invoiceDateAggregation).setSize(0);
		
		SearchResponse previousFiscalResponse = esQueryUtils.execute(previousFiscalSearchRequestBuilder);
		
		InternalHistogram datehist = response.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		
		InternalHistogram previousFicalDatehist = previousFiscalResponse.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> previousFiscalBuckets = previousFicalDatehist.getBuckets();
		return this.populateRevenuePojoResultForInvoices(buckets, productName, previousFiscalBuckets, startDate, endDate);
	} 
	/**
	 * Returns the sum of revenue amount for every month in the fiscal year index: Manual Document: business_strategy
	 * @param startDate
	 * @param endDate
	 * @return Map<Integer,RevenuePojo> Integer: Month RevenuePojo: revenue generated for that month
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, Double> getRevenueByMonthAndOpportunitiesOfCustomer(String startDate, String endDate,
			List<String> opportunities, String customerName) {
		
		SearchResponse searchResponse=getRevenueGeneratedByMonthAndOpportunitiesOfCustomerResponse(startDate, endDate, opportunities, customerName);
		
		InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		Map<Integer, Double> resultsMap = new LinkedHashMap<>();
		int count = 0;
		for (InternalHistogram.Bucket bucket : buckets) {
			Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			resultsMap.put(count,sum.getValue());
			count++;
		}
		
		return resultsMap; 
	}
	
	public SearchResponse getRevenueGeneratedByMonthAndOpportunitiesOfCustomerResponse(String startDate, String endDate,
			List<String> opportunities, String customerName){
		timeUtil.start();
		
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		
		if (StringUtils.isNotEmpty(startDate) && StringUtils.isNotEmpty(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(startDate).to(endDate).includeLower(true).includeUpper(true));
		}
		
		boolFilter.must(FilterBuilders.termFilter(ERPConstants.INVOICE_ACCOUNT_NAME_RAW, customerName));
		
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);
		
		AbstractAggregationBuilder invoiceDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(startDate, endDate).minDocCount(0).subAggregation(sumInvoiceAmountByMonth);
		
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(invoiceDateAggregation)
				.setSize(0);
		
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		return response;
	} 
	
	/**
	 * Returns the sum of revenue amount for every month in the fiscal year
	 * index: Manual Document: business_strategy
	 * 
	 * @param startDate
	 * @param endDate
	 * @return Map<Integer,RevenuePojo> Integer: Month RevenuePojo: revenue
	 *         generated for that month
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, MultipleAxesChartData> getReturnsByMonthAndOpportunities(Calendar startDate, Calendar endDate,
			List<String> opportunities) {
		Map<Integer, String> monthAndYearMap = MiriDateUtils.getMonthsBetweenDates(startDate, endDate);
		List<Integer> months = new LinkedList<>(monthAndYearMap.keySet());

		String minBound = MiriDateUtils.getElasticSearchFormattedDate(startDate);
		String maxBound = MiriDateUtils.getElasticSearchFormattedDate(endDate);

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();

		if (CollectionUtils.isNotEmpty(opportunities)) {
			boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunities));
			// rangeFilterQuery = QueryBuilders.filteredQuery(termsQuery,
			// rangeFilter);
		}

		if (StringUtils.isNotEmpty(minBound) && StringUtils.isNotEmpty(maxBound)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE).from(minBound)
					.to(maxBound).includeLower(true).includeUpper(true));
		}
		
		boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_SALES_AMOUNT).lte(0));
		
		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder sumProductQuantityByMonth = AggregationUtil
				.sumAggregation(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION, ERPConstants.INVOICE_PRODUCT_QUANTITY);
		
		AbstractAggregationBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION).field(ERPConstants.OPPORTUNITY_ID_RAW).size(0);
		// Create a aggregation to sort the invoices by month
		AbstractAggregationBuilder invoiceDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(minBound, maxBound).minDocCount(0).subAggregation(sumInvoiceAmountByMonth).subAggregation(opportunityAggregation)
				.subAggregation(sumProductQuantityByMonth);

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(invoiceDateAggregation).setSize(0);
		
		timeUtil.end();
		LOG.debug("getRevenueGeneratedByMonthAndOpportunitiesResponse ES Time Taken" + timeUtil.timeTakenInMillis());
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		timeUtil.start();
		InternalHistogram datehist = response.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		Map<Integer, MultipleAxesChartData> resultsMap = MiriSearchUtils.populateReturnsPojoResult(buckets,
				months);
		timeUtil.end();
		LOG.debug("getTotalInvoicesByMonthOpportunities :- Java Processing Time" + timeUtil.timeTakenInMillis());
		return resultsMap;
	}
	
	/**
	 * Returns the sum of revenue amount for every month in the fiscal year
	 * index: Manual Document: business_strategy
	 * 
	 * @param startDate
	 * @param endDate
	 * @return Map<Integer,RevenuePojo> Integer: Month RevenuePojo: revenue
	 *         generated for that month
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, Double> getRevenueByMonth(Calendar startDate, Calendar endDate,
			List<String> opportunities) {
		SearchResponse searchResponse = getRevenueGeneratedByMonthAndOpportunitiesResponse(startDate, endDate,
				opportunities);
		InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		return  this.populateRevenueByMonth(buckets);
	}
	
	/**
	 * Gets the Revenue for each Month
	 * @param buckets
	 * @return
	 */
	public Map<Integer, Double> populateRevenueByMonth(Collection<InternalHistogram.Bucket> buckets){
		int counter =0;
		Map<Integer, Double> revenueMap = new LinkedHashMap<>();
		Sum sum = null;
		for (InternalHistogram.Bucket bucket : buckets) {
			sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			revenueMap.put(counter, sum.getValue());
		}
		return revenueMap;
		
	}
	
	
	@Override
	public String getIndex() {
		return ElasticSearchEnums.ERP.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_OPPORTUNITY.getText();
	}
	
}