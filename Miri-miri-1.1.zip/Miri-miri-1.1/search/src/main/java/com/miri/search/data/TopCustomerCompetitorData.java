package com.miri.search.data;

import java.io.Serializable;

public class TopCustomerCompetitorData  implements Serializable{
	String CompititorName;
	String accountName;
	Double totalRevenue;
	Double customerHighestRevenue;
	Long dealsCount;
	public String getCompititorName() {
		return CompititorName;
	}
	public void setCompititorName(String compititorName) {
		CompititorName = compititorName;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public Double getTotalRevenue() {
		return totalRevenue;
	}
	public void setTotalRevenue(Double totalRevenue) {
		this.totalRevenue = totalRevenue;
	}
	public Double getCustomerHighestRevenue() {
		return customerHighestRevenue;
	}
	public void setCustomerHighestRevenue(Double customerHighestRevenue) {
		this.customerHighestRevenue = customerHighestRevenue;
	}
	public Long getDealsCount() {
		return dealsCount;
	}
	public void setDealsCount(Long dealsCount) {
		this.dealsCount = dealsCount;
	}
	
		
}
