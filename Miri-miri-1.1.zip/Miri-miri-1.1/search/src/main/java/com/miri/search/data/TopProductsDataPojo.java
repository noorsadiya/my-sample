package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

public class TopProductsDataPojo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3677322262206427469L;

	private String productName;
	
	private String productId;
	
	private double revenueAmount;
	
	private long noOfdeals;
	
	private List<String> productIds;

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public double getRevenueAmount() {
		return revenueAmount;
	}

	public void setRevenueAmount(double revenueAmount) {
		this.revenueAmount = revenueAmount;
	}

	public long getNoOfdeals() {
		return noOfdeals;
	}

	public void setNoOfdeals(long noOfdeals) {
		this.noOfdeals = noOfdeals;
	}

	/**
	 * @return the productIds
	 */
	public List<String> getProductIds() {
		return productIds;
	}

	/**
	 * @param productIds the productIds to set
	 */
	public void setProductIds(List<String> productIds) {
		this.productIds = productIds;
	}
	
	
	
}
