package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

/**
 * Customer Value Data object for Customer Value Trend Analysis 
 * @author rammoole
 *
 */
public class CustomerValueData implements Serializable {
	
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 4898311499983399014L;

	private int customersCount;
	
	private double revenue;
	
	private List<String> opportunityIds;
	
	/**
	 * @return the customersCount
	 */
	public int getCustomersCount() {
		return customersCount;
	}
	/**
	 * @param customersCount the customersCount to set
	 */
	public void setCustomersCount(int customersCount) {
		this.customersCount = customersCount;
	}
	/**
	 * @return the revenue
	 */
	public double getRevenue() {
		return revenue;
	}
	/**
	 * @param revenue the revenue to set
	 */
	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}
	/**
	 * @return the opportunityIds
	 */
	public List<String> getOpportunityIds() {
		return opportunityIds;
	}
	/**
	 * @param opportunityIds the opportunityIds to set
	 */
	public void setOpportunityIds(List<String> opportunityIds) {
		this.opportunityIds = opportunityIds;
	}
}
