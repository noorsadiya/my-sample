package com.miri.search.service.erp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.bucket.histogram.InternalHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Order;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.ModifiableObject;
import com.miri.search.data.ScatterChartData;
import com.miri.search.data.TopCustomersData;
import com.miri.search.data.TopHighestCustomerData;
import com.miri.search.esutils.AggregationUtil;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.crm.CRMOpportunityService;
import com.miri.search.service.manual.ManualAccountStrategyService;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.TimerUtil;

/**
 * Services pertaining to erp/erp_invoice by account document in elastic search
 * @author noor
 *
 */

@Component
public class OpportunityAccountInvoiceService extends MiriSearchService {

	private static final Logger LOG = LogManager.getLogger(OpportunityAccountInvoiceService.class); 

	@Autowired
	ManualAccountStrategyService manualAccountStrategyService;

	@Autowired
	TimerUtil timerUtil;

	@Autowired
	ESQueryUtils esQueryUtils;

	@Autowired
	CRMOpportunityService crmOpportunityService;
	
	
	/**
	 * computes all opportunities and account from invoice from the list of opportunities parameterized
	 * @param opportunities
	 * @return Map<OpportuntiyId,AccounIid>
	 */

	public Map<String,String> getOpportunitiesAndAccounts(List<String> opportunities){
		Map<String,String> opportunitiesAndAccounts=new  HashMap<String,String>();


		TermsQueryBuilder opptTerm=QueryBuilders.termsQuery(SearchConstants.OPPORTUNITY_ID_RAW, opportunities);

		SearchResponse response = getTransportClient()
				.prepareSearch(SearchConstants.ERP).setTypes(SearchConstants.ERP_INVOICE)
				.setQuery(opptTerm)
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.addField(SearchConstants.OPPORTUNITY_ID).addField(SearchConstants.ACCOUNT_ID)
				.execute().actionGet();

		SearchHits searchHits=response.getHits();

		for(SearchHit hit: searchHits){
			String optyId=hit.getFields().get(SearchConstants.OPPORTUNITY_ID).getValue().toString();
			String accountId=hit.getFields().get(SearchConstants.ACCOUNT_ID).getValue().toString();
			opportunitiesAndAccounts.put(optyId, accountId);
		}
		return opportunitiesAndAccounts;
	}


	/**
	 * computes sum of invoices by account for the list of opportunities parameterized
	 * @param opportunities
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return Map<OpportuntiyId,AccounIid>
	 */
	public Map<String,Double> getInvoicesAndAccounts(List<String> opportunities, String startDate, String endDate){

		timerUtil.start();

		Map<String,Double> accountsInvocieSum=new  HashMap<String,Double>();

		Client client =getTransportClient();

		AbstractAggregationBuilder sumInvoiceAmountByOpt=AggregationUtil.
				sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder termAggr=AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).
				field(SearchConstants.ACCOUNT_ID_RAW).subAggregation(sumInvoiceAmountByOpt);	

		BoolQueryBuilder termsQuery = MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW, 
				opportunities, SearchConstants.BATCH_SIZE_1000);


		SearchResponse response = client
				.prepareSearch(SearchConstants.ERP).setTypes(SearchConstants.ERP_INVOICE)
				.setQuery(termsQuery)
				.addAggregation(termAggr)
				.execute().actionGet();

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> buckets = terms.getBuckets();

		for (Terms.Bucket bucket : buckets) {
			Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			accountsInvocieSum.put(bucket.getKeyAsText().toString(),sum.getValue());
		}
		//LOG.info("getInvoicesAndAccounts:-"+accountsInvocieSum);
		timerUtil.end();
		LOG.debug("getInvoicesAndAccounts ES"+timerUtil.timeTakenInMillis());
		return accountsInvocieSum;
	}


	/**
	 * computes sum of invoices by salesperson for the list of opportunities parameterized
	 * @param opportunities
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return Map<salesperson,invoiceamount>
	 */
	public  Map<String,Object> getInvoicAmountBySalesPerson(List<String> opportunities, String startDate, String endDate){

		timerUtil.start();

		Map<String,Object> invoiceBySalesPerson=new  HashMap<String,Object>();

		//Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth=AggregationUtil.
				sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder termAggr=AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).
				field(SearchConstants.ERP_SALES_PERSON_RAW).size(0).subAggregation(sumInvoiceAmountByMonth);

		BoolQueryBuilder termsQuery=MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW, opportunities, 1000);
		termsQuery.must(QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));

		SearchResponse response = getTransportClient()
				.prepareSearch(SearchConstants.ERP).setTypes(SearchConstants.ERP_INVOICE)
				.setQuery(termsQuery)
				.addAggregation(termAggr)
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.execute().actionGet();

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> buckets = terms.getBuckets();

		for (Terms.Bucket bucket : buckets) {
			Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			invoiceBySalesPerson.put(bucket.getKeyAsText().toString(),sum.getValue());
		}				 
		timerUtil.end();
		LOG.debug("getInvoicAmountBySalesPerson ES"+timerUtil.timeTakenInMillis());
		return	invoiceBySalesPerson;
	}


	/**
	 * computes sum of invoices by salesperson for the list of opportunities parameterized
	 * @param opportunities
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return Map<OpportuntiyId,AccounId>
	 */
	public Map<String,Double> getInvoiceSumAndAccountsForSalesPerson(List<String> opportunities,String salesPerson, String startDate, String endDate){

		timerUtil.start();
		Map<String,Double> accountsInvocieSum=new  HashMap<String,Double>();
		Client client =getTransportClient();

		TermsQueryBuilder salesPersonTerm=QueryBuilders.termsQuery(SearchConstants.ERP_SALES_PERSON_RAW,salesPerson);

		BoolQueryBuilder termsQuery=MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW, 
				opportunities, 1000);
		termsQuery.must(salesPersonTerm);
		termsQuery.must(QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));


		AbstractAggregationBuilder sumInvoiceAmountByOpt=AggregationUtil.
				sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder termAggr=AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).
				field("accountId")
				.subAggregation(sumInvoiceAmountByOpt);	

		SearchResponse response = client
				.prepareSearch(SearchConstants.ERP).setTypes(SearchConstants.ERP_INVOICE)
				.setQuery(termsQuery)
				.addAggregation(termAggr)
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.addField("opportunityId").addField("accountId")
				.execute().actionGet();

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		
		Collection<Terms.Bucket> buckets = terms.getBuckets();
		
		for (Terms.Bucket bucket : buckets) {
			Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			accountsInvocieSum.put(bucket.getKeyAsText().toString(),sum.getValue());
		}				 
		timerUtil.end();

		//LOG.info("accountsInvocieSum:-"+accountsInvocieSum);
		return accountsInvocieSum;
	}


	/**
	 * computes sum of invoices by account for the list of opportunities parameterized
	 * @param opportunities
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return Map<AccountName,Invoice>
	 */
	public Map<String,Object> getAccountsWithInvoice(List<String> opportunities, String startDate, String endDate){
		Map<String,Object> accountsInvocieSum=new LinkedHashMap<String, Object>();
		TopCustomersData topCustomersData=new TopCustomersData();
		TopHighestCustomerData customerData=new TopHighestCustomerData();
		Client client =getTransportClient();

		AbstractAggregationBuilder sumInvoiceAmountByOpt=AggregationUtil.
				sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder termAggr=AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).
				field(SearchConstants.ACCOUNT_NAME_RAW).size(0).order(Order.aggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, false))
				.subAggregation(sumInvoiceAmountByOpt);	


		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.from(startDate)
				.to(endDate));

		// Commenting the below code as this is not used.
		//BoolQueryBuilder termsQuery = MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW, 
		//		opportunities, SearchConstants.BATCH_SIZE_1000);

		//RangeFilterBuilder rangeFilter = FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
		//		.from(startDate).to(endDate).includeLower(false).includeUpper(false);

		//FilteredQueryBuilder rangeFilterQuery = QueryBuilders.filteredQuery(termsQuery, rangeFilter);

		SearchResponse response = client
				.prepareSearch(SearchConstants.ERP).setTypes(SearchConstants.ERP_INVOICE)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(termAggr)
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.execute().actionGet();

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> buckets = terms.getBuckets();

		double totalInvoiceAmount=0;
		for (Terms.Bucket bucket : buckets) {
			Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);

			topCustomersData=new TopCustomersData();

			topCustomersData.setxAxisName(bucket.getKeyAsText().toString());
			topCustomersData.setyAxisValue(sum.getValue());
			topCustomersData.setTotalRevenue(totalInvoiceAmount);
			topCustomersData.setHoverDealsClosed(new Long(bucket.getDocCount()));

			customerData=new TopHighestCustomerData();
			customerData.setCustomerName(bucket.getKeyAsText().toString());
			customerData.setTotalSalesAmount(sum.getValue());
			topCustomersData.setTopHighestcustomer(customerData);

			accountsInvocieSum.put(bucket.getKeyAsText().toString(), topCustomersData);
		}
		//LOG.info("getAccounts and Invoice Sum :-"+accountsInvocieSum);
		return accountsInvocieSum;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<ScatterChartData>  calculateAllNewBusinessRevenueByMonth(List<String> opportunities,String startDate,String endDate,
			Map<Integer,String> monthAndYearMap,List<Double> revenueList,ModifiableObject modifiableObject){
		
		List<ScatterChartData> newBusinessClosedlist=new  ArrayList<>();
		ScatterChartData nbcData=null;
		double overallRevenueAchieved=0;
		
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		
		if (StringUtils.isNotEmpty(startDate) && StringUtils.isNotEmpty(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.from(startDate).to(endDate).includeLower(true).includeUpper(true));
		}

		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);
		
		AbstractAggregationBuilder acctNameAggr=AggregationBuilders.terms("accountNamAggr").
				field(SearchConstants.ACCOUNT_NAME_RAW).subAggregation(sumInvoiceAmountByMonth).size(0);	

		/*AbstractAggregationBuilder opptyAggr=AggregationBuilders.terms("opptyAggr").
				field(SearchConstants.OPPORTUNITY_ID_RAW).subAggregation(acctNameAggr);	*/
		
		// Create a aggregation to sort the invoices by month
		AbstractAggregationBuilder invoiceDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(startDate, endDate).minDocCount(0).subAggregation(acctNameAggr);
		
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(SearchConstants.ERP)
				.setTypes(SearchConstants.ERP_INVOICE)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(invoiceDateAggregation)
				.setSize(0);
		
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		
		InternalHistogram datehist = response.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		
		int monthIndex=0;
		for (InternalHistogram.Bucket bucket : buckets) {
			
			/*Terms opptyTerms = bucket.getAggregations().get("opptyAggr");
			Collection<Terms.Bucket> opptyBuckets = opptyTerms.getBuckets();
			
			for (Terms.Bucket termBucket : opptyBuckets) {*/
				
				Terms acctTerms = bucket.getAggregations().get("accountNamAggr");
				Collection<Terms.Bucket> acctBuckets = acctTerms.getBuckets();
				
				for (Terms.Bucket acctBucket : acctBuckets) {

					Sum sum = (Sum) acctBucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
					if(sum.getValue()!=0){
						nbcData=new ScatterChartData();
						nbcData.setHoverName(acctBucket.getKey());
						nbcData.setxAxisPointer(monthAndYearMap.get(monthIndex));
						nbcData.setHoverAmount(sum.getValue());
						newBusinessClosedlist.add(nbcData);
						revenueList.add(sum.getValue());
						overallRevenueAchieved+=sum.getValue();
					}
					
					
				}
				
			//}	
			monthIndex++;
		}
		modifiableObject.setDoubleValue(overallRevenueAchieved);
		return newBusinessClosedlist;
	}
	
	public List<ScatterChartData>  calculateAllNewBusinessRevenue(List<String> opportunities,String startDate,
			String endDate,String name,List<Double> revenueList,ModifiableObject modifiableObject){
		List<ScatterChartData> newBusinessClosedlist=new  ArrayList<>();
		ScatterChartData nbcData=null;
		double overallRevenueAchieved=0;
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		
		if (StringUtils.isNotEmpty(startDate) && StringUtils.isNotEmpty(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.from(startDate).to(endDate).includeLower(true).includeUpper(true));
		}

		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);
		
		AbstractAggregationBuilder acctNameAggr=AggregationBuilders.terms("accountNamAggr").
				field(SearchConstants.ACCOUNT_NAME_RAW).subAggregation(sumInvoiceAmountByMonth).size(0);	

		/*AbstractAggregationBuilder opptyAggr=AggregationBuilders.terms("opptyAggr").
				field(SearchConstants.OPPORTUNITY_ID_RAW).subAggregation(acctNameAggr);	*/
		
	
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(SearchConstants.ERP)
				.setTypes(SearchConstants.ERP_INVOICE)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(acctNameAggr)
				.setSize(0);
			
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		
		/*	Terms opptyTerms = response.getAggregations().get("opptyAggr");
			Collection<Terms.Bucket> opptyBuckets = opptyTerms.getBuckets();
			
			for (Terms.Bucket termBucket : opptyBuckets) {*/
				
				Terms acctTerms = response.getAggregations().get("accountNamAggr");
				Collection<Terms.Bucket> acctBuckets = acctTerms.getBuckets();
				
				for (Terms.Bucket acctBucket : acctBuckets) {

					Sum sum = (Sum) acctBucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
					nbcData=new ScatterChartData();
					nbcData.setxAxisPointer(name);
					nbcData.setHoverName(acctBucket.getKey());
					nbcData.setHoverAmount(sum.getValue());
					nbcData.setDrillDownXaxisPointer(name);
					newBusinessClosedlist.add(nbcData);
					revenueList.add(sum.getValue());
					overallRevenueAchieved+=sum.getValue();
					
				}
				
			//}	
		modifiableObject.setDoubleValue(overallRevenueAchieved);
		return newBusinessClosedlist;
	}
	
	public List<ScatterChartData>  calculateAllNewBusinessRevenueBySalesPerson(List<String> opportunities,String startDate,
			String endDate,List<Double> revenueList,String salesPerson,ModifiableObject modifiableObject){
		List<ScatterChartData> newBusinessClosedlist=new  ArrayList<>();
		ScatterChartData nbcData=null;
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		double overallRevenueAchieved=0;
		
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		
		if (StringUtils.isNotEmpty(startDate) && StringUtils.isNotEmpty(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.from(startDate).to(endDate).includeLower(true).includeUpper(true));
		}
		boolFilter.must(FilterBuilders.termFilter(ERPConstants.INVOICE_SALES_PERSON_RAW, salesPerson));

		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);
		
		AbstractAggregationBuilder acctNameAggr=AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION).
				field(SearchConstants.ACCOUNT_NAME_RAW).subAggregation(sumInvoiceAmountByMonth).size(0);	
		
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(SearchConstants.ERP)
				.setTypes(SearchConstants.ERP_INVOICE)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(acctNameAggr)
				.setSize(0);
			
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		Terms acctTerms = response.getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
		Collection<Terms.Bucket> acctBuckets = acctTerms.getBuckets();
		
		for (Terms.Bucket acctBucket : acctBuckets) {
			Sum sum = (Sum) acctBucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			nbcData=new ScatterChartData();
			nbcData.setxAxisPointer(salesPerson);
			nbcData.setHoverName(acctBucket.getKey());
			nbcData.setHoverAmount(sum.getValue());
			nbcData.setDrillDownXaxisPointer(salesPerson);
			newBusinessClosedlist.add(nbcData);
			revenueList.add(sum.getValue());
			overallRevenueAchieved+=sum.getValue();
		}
		modifiableObject.setDoubleValue(overallRevenueAchieved);
		return newBusinessClosedlist;
	}
	
	
		
	/**
	 * computes sum of invoices by account for the list of opportunities parameterized
	 * @param opportunities
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return Map<AccountName,Invoice>
	 */
	public Map<String,Object> getAccountsWithInvoiceWithInTimeFrame(List<String> opportunities, String startDate, String endDate, int size){

		Map<String,Object> accountsInvocieSum=new LinkedHashMap<String, Object>();
		TopCustomersData topCustomersData=new TopCustomersData();
		TopHighestCustomerData customerData=new TopHighestCustomerData();

		AbstractAggregationBuilder sumInvoiceAmountByOpt=AggregationUtil.
				sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder termAggr=AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).
				field(SearchConstants.ACCOUNT_NAME_RAW).size(0).order(Order.aggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, false))
				.subAggregation(sumInvoiceAmountByOpt);	


		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(startDate)
					.to(endDate));
		}

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
				.prepareSearch(SearchConstants.ERP)
				.setTypes(SearchConstants.ERP_INVOICE)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(termAggr);

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		Collection<Terms.Bucket> buckets = null;
		if(response.getAggregations() != null){
			Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			buckets = terms.getBuckets();
		}

		for (Terms.Bucket bucket : buckets) {
			if(accountsInvocieSum.size() < size){
				
				String customerName = bucket.getKey();
				if(StringUtils.isNotEmpty(customerName)){
	
					Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
	
					topCustomersData=new TopCustomersData();
					topCustomersData.setxAxisName(customerName);
					topCustomersData.setyAxisValue(sum.getValue());
					//miri-1833 : set revenue to z pointer as well to convert to a bubble chart
					topCustomersData.setzAxisValue(sum.getValue()); 
					topCustomersData.setHoverDealsClosed(crmOpportunityService.getDealsClosedForCustomerInDateRange(customerName, startDate, endDate));
	
					customerData=new TopHighestCustomerData();
					customerData.setCustomerName(customerName);
					customerData.setTotalSalesAmount(sum.getValue());
	
					topCustomersData.setTopHighestcustomer(customerData);
					accountsInvocieSum.put(customerName, topCustomersData);
				}
			}else
				break;
		}
		return accountsInvocieSum;
	}
	
	
	/**
	 * computes sum of invoices by account for the list of opportunities parameterized
	 * @param opportunities
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return Map<AccountName,Invoice>
	 */
	public Map<String,Object> getAccountsWithInvoiceWithInTimeFrame(String startDate, String endDate, int size){
		return this.getAccountsWithInvoiceWithInTimeFrame(null, startDate, endDate, size);
	}

	@Override
	public String getIndex() {
		return ElasticSearchEnums.ERP.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_OPPORTUNITY.getText();
	}
}
