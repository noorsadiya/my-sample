package com.miri.search.service.crm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.base.VendorTypeEnum;
import com.miri.cis.entity.CrmOpportunityProduct;
import com.miri.cis.entity.ESEntity;
import com.miri.data.constants.OpportunityStagesEnum;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.FilterData;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;

/**
 * CRM Opportunity Product Service
 *
 */
@Component
public class CRMOpportunityProductService extends MiriSearchService {
	
	private static final Logger LOG = LogManager.getLogger(CRMOpportunityProductService.class);
	
	@Autowired
	private ESQueryUtils esQueryUtils;
	
	@Autowired
	private CRMOpportunityService crmOpportunityService;
	
	@Autowired
	private CRMProductService crmProductService;

	@Autowired
	private ERPInvoiceService erpInvoiceService;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.miri.search.service.MiriSearchService#getIndex()
	 */
	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.miri.search.service.MiriSearchService#getDocumentType()
	 */
	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_OPP_PRODUCT.getText();
	}


	/**
	 * Returns opportunity products by given opportunity id.
	 * 
	 * @param opportunityId
	 * @return
	 */
	public List<ESEntity> getCRMOpportunityProductsByOpportunityId(final String opportunityId) {
		return esQueryUtils.getMultipleDocsByFKId(getDocumentType(), getIndex(), "opportunityId.raw", opportunityId);
	}

	/**
	 * Returns opportunity products by given product id.
	 * 
	 * @param opportunityId
	 * @return
	 */
	public List<ESEntity> getCRMOpportunityProductsByProductId(final String productId) {
		return esQueryUtils.getMultipleDocsByFKId(getDocumentType(), getIndex(), CRMConstants.PRODUCT_RAW, productId);
	}
	
	/**
	 * Get Opportunity Ids. associated with given products.
	 * 
	 * @param productIds
	 * @return
	 */
	public Set<String> getCRMOpportunityProductsByProductIds(Set<String> productIds) {
		SearchRequestBuilder srb = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).addField(CRMConstants.OPPORTUNITY_ID)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
						FilterBuilders.boolFilter().must(FilterBuilders.termsFilter(CRMConstants.PRODUCT_RAW,
								productIds))));
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms("prodAggr").field(CRMConstants.PRODUCT_RAW).size(0)
				.subAggregation(AggregationBuilders.terms("oppAggr").field(CRMConstants.OPPORTUNITY_ID_RAW).size(0));
		
		srb.addAggregation(aggregationBuilders);
		
		SearchResponse searchResponse = srb.get();
		Terms terms = searchResponse.getAggregations().get("prodAggr");
		List<Terms.Bucket> termsBuckets = terms.getBuckets();

		Set<String> ids = new HashSet<>();
		for (Terms.Bucket termBucket : termsBuckets) {
			String prodName = termBucket.getKey();
			if(StringUtils.isNotBlank(prodName)){
				Terms oppKeyTerms = termBucket.getAggregations().get("oppAggr");
				List<Terms.Bucket> oppTermsBuckets = oppKeyTerms.getBuckets();
				for (Terms.Bucket oppTermBucket : oppTermsBuckets) {
					String oppName = oppTermBucket.getKey();
					if(StringUtils.isNotBlank(oppName)){
						ids.add(oppName);
					}
				}
			}
		}
		return ids;
	}
	
	/**
	 * Gets the opportunities Of a product With In timeFrame
	 * @param productId
	 * @param startDate
	 * @param endDate
	 * @param opportunities
	 * @return
	 */
	public List<String> getOpportunitiesByProductId(final String productId, String startDate, String endDate, List<String> opportunities) {
		return getOpportunitiesByProductIds(Arrays.asList(productId), startDate, endDate, opportunities);
	}
	
	/**
	 * Gets the opportunities of a products with in time frame
	 * @param productIds
	 * @param startDate
	 * @param endDate
	 * @param opportunities
	 * @return
	 */
	public List<String> getOpportunitiesByProductIds(final List<String> productIds, String startDate, String endDate, List<String> opportunities) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.PRODUCT_RAW, productIds));
		
		if(opportunities != null){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		
		List<String> opportunityIds = new ArrayList<>();
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
													.setTypes(getDocumentType())
													.setSize(1000)
													.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
													.setSearchType(SearchType.SCAN)
													.setScroll(new TimeValue(6000));
		//LOG.info(searchRequestBuilder);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		
		while(true) {
			for(SearchHit hit: searchResponse.getHits()) {
				opportunityIds.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		//LOG.info("product Id opportunities :" + productId + "|" + opportunityIds.size());
		return opportunityIds;
	}
	
	/**
	 * gets the won Opportunity count for Product 
	 * @param opportunities
	 * @param productId
	 * @param startDate
	 * @param endDate
	 * @param isMarketing
	 * @return
	 */
	public long getWonOpportunityCountForProductIdByCustomerOpportunities(List<String> opportunities, String productId, String startDate, String endDate, boolean isMarketing){
		//LOG.info("won opportunity count :" + isMarketing);
		return crmOpportunityService.getWonOpportunityCountFromOpportunities(getOpportunitiesByProductId(productId, startDate, endDate, opportunities), startDate, endDate, isMarketing);
	}
	
	/**
	 * Get Lost Opportunities by product Id
	 * @param productId
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getOtherStageOpportunitiesByProductIds(List<String> productIds, String startDate, String endDate) {
		List<String> allOpportunities = this.getOpportunitiesByProductIds(productIds, null, null, null);
		//LOG.info("product Id:" + productId + "|" + startDate + "|" + endDate);
		return crmOpportunityService.getOpportunitiesByDateAndExceptStage(allOpportunities, OpportunityStagesEnum.CLOSED_WON.getText(), startDate, endDate);
	}
	
	/**
	 * gets the won Opportunities for a Product 
	 * @param opportunities
	 * @param productId
	 * @param startDate
	 * @param endDate
	 * @param isMarketing
	 * @return
	 */
	public List<String> getWonOpportunitiesForProductIdByOpportunities(List<String> opportunities, String productId, String startDate, String endDate, Boolean isMarketing){
		List<String> allOpportunities = getOpportunitiesByProductId(productId, startDate, endDate, opportunities);
		return crmOpportunityService.getWonOpportunitiesFromOpportunities(allOpportunities, startDate, endDate, isMarketing);
	}

	/**
	 * Get CRM Opportunity Product by opportunity Id
	 * @param oppId
	 * @return
	 */
	public CrmOpportunityProduct getCRMOpportunityProductByOppId(String oppId) {
		CrmOpportunityProduct crmOpportunityProduct = null;
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
				.prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY_PRODUCT)
				.setQuery(QueryBuilders.boolQuery().must(QueryBuilders.termQuery(SearchConstants.OPPORTUNITY_ID_RAW, oppId))); 
		SearchResponse oppSearch = esQueryUtils.execute(searchRequestBuilder);
		if(oppSearch.getHits().getHits().length > 0) {
			SearchHit searchHit = oppSearch.getHits().getAt(0);
			crmOpportunityProduct =  (CrmOpportunityProduct) ESObjectMapper.getObject(searchHit.getSource(), ElasticSearchEnums.CRM_OPP_PRODUCT.getText(), VendorTypeEnum.CRM.getText());
		}
		return crmOpportunityProduct;
	}
	
	/**
	 * Get CRM Opportunity Product by opportunity Id
	 * @param oppId
	 * @return
	 */
	public Set<String> getProductIdsByOppId(String oppId) {
		Set<String> productIds = new HashSet<>();
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY_PRODUCT).addField(CRMConstants.PRODUCT).setQuery(QueryBuilders
						.boolQuery().must(QueryBuilders.termQuery(SearchConstants.OPPORTUNITY_ID_RAW, oppId)));
		SearchResponse oppSearch = esQueryUtils.execute(searchRequestBuilder);
		if (oppSearch.getHits().getHits().length > 0) {
			for (SearchHit hit : oppSearch.getHits()) {
				productIds.add(hit.getFields().get(CRMConstants.PRODUCT).getValue().toString());
			}
		}
		return productIds;
	}
	
	
	/**
	 * Get product names as a comma separated string by opportunity Id
	 * @param opportunityId
	 * @return
	 */
	public String getCRMOpportunityProductByOpportunityId(String opportunityId) {
		List<ESEntity> crmOpportunityProducts = this.getCRMOpportunityProductsByOpportunityId(opportunityId);
		StringBuffer sb = new StringBuffer();
		String productName;
		for(ESEntity esEntity: crmOpportunityProducts) {
			if(sb.length() > 0) {
				sb.append(",");
			}
			String productId = ((CrmOpportunityProduct) esEntity).getProduct(); 
			productName = crmProductService.getProductByProductId(productId);
			if(StringUtils.isNotBlank(productName)) {
				sb.append(productName);
			}
		}
		return sb.toString();
	}
	
	/**
	 * Get all the opportunities by Product Name
	 * @param productName
	 * @return
	 */
	public List<String> getOpportunityIdsByProductName(final String productName, final String startDate, final String endDate) {
		Client client = this.getTransportClient();
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(200);
		String productId = crmProductService.getCRMProductByName(productName);
		if(StringUtils.isNotBlank(productName)) {
			searchRequestBuilder.setQuery(QueryBuilders.termQuery(CRMConstants.PRODUCT_RAW, productId));
		}
		
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			searchRequestBuilder.setPostFilter(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).gte(startDate).lte(endDate));
		}
		
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunityIds = new ArrayList<>();
		if(searchResponse != null) {
			while(true) {
				for(SearchHit hit: searchResponse.getHits()) {
					opportunityIds.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
				}
				SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
				searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
				if(searchResponse.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		return opportunityIds;
	}
	
	
	/**
	 * Get number of deals of each product
	 * @param opportunityIds
	 * @return
	 */
	public List<FilterData> getDealsByProductForOpportunities(List<String> opportunityIds, int size) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.PRODUCT_AGGREGATION).field(CRMConstants.PRODUCT_RAW).size(0).minDocCount(1));
		long maxHits = 0;
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Terms productTerms = searchResponse.getAggregations().get(SearchConstants.PRODUCT_AGGREGATION);
		Collection<Terms.Bucket> productBuckets = productTerms.getBuckets();
		for(Terms.Bucket productBucket: productBuckets) {
			maxHits = productBucket.getDocCount();
			break;
		}
		
		searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.PRODUCT_AGGREGATION).field(CRMConstants.PRODUCT_RAW).size(0).minDocCount(1)
						.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITY_HITS).setSize((int) maxHits)));
		searchResponse = esQueryUtils.execute(searchRequestBuilder);
		productTerms = searchResponse.getAggregations().get(SearchConstants.PRODUCT_AGGREGATION);
		productBuckets = productTerms.getBuckets();
		List<FilterData> productDeals = new ArrayList<>();
		FilterData filterData;
		List<String> opportunityids;
		for(Terms.Bucket bucket: productBuckets) {
			filterData = new FilterData();
			filterData.setName(crmProductService.getProductByProductId(bucket.getKey()));
			filterData.setDeals(bucket.getDocCount());
			TopHits topHits = bucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITY_HITS);
			opportunityids = new ArrayList<>();
			for(SearchHit hit: topHits.getHits()) {
				opportunityids.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			double revenueAmont = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityids, null, null);
			filterData.setRevenue(revenueAmont);
			productDeals.add(filterData);
		}
		Collections.sort(productDeals);
		if(productDeals.size() > size) {
			return productDeals.subList(0, size);
		} else {
			return productDeals;
		}
	}
}
