package com.miri.search.domain.guage;

import java.io.Serializable;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class GaugeRow implements Serializable{

	private List<String> guageDataList;

	public List<String> getGuageDataList() {
		return guageDataList;
	}
	
	public void setGuageDataList(List<String> guageDataList) {
		this.guageDataList = guageDataList;
	}
	
	
}
