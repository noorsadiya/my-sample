package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

public class InvoiceDataPojo implements Serializable{

	private static final long serialVersionUID = 1L;

	 List<String> invoiceItems;
	 
	 List<String> opportunities;
	 
	 double revenue;
	 
	 double productQuantity;
	 
	 
	 public double getProductQuantity() {
		return productQuantity;
	}
	 
	public void setProductQuantity(double productQuantity) {
		this.productQuantity = productQuantity;
	}
	 
	 public List<String> getInvoiceItems() {
	  return invoiceItems;
	 }

	 public void setInvoiceItems(List<String> invoiceItems) {
	  this.invoiceItems = invoiceItems;
	 }

	 public List<String> getOpportunities() {
	  return opportunities;
	 }

	 public void setOpportunities(List<String> opportunities) {
	  this.opportunities = opportunities;
	 }

	 public double getRevenue() {
	  return revenue;
	 }

	 public void setRevenue(double revenue) {
	  this.revenue = revenue;
	 }
	 
}
