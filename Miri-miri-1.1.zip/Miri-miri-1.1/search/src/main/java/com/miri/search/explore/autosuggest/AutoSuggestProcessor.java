/**
 * 
 */
package com.miri.search.explore.autosuggest;

/**
 * AutoSuggestProcessor: Calls auto suggest request creation on the given
 * builder.
 * 
 * @author Chandra
 *
 */
public class AutoSuggestProcessor {

	private AutoSuggestRequestBuilder autoSuggestRequestBuilder;

	public void setAutoSuggestRequestBuilder(AutoSuggestRequestBuilder autoSuggestRequestBuilder) {
		this.autoSuggestRequestBuilder = autoSuggestRequestBuilder;
	}

	public void constructAutoSuggestRequest() {
		autoSuggestRequestBuilder.buildAutoSuggestRequest();
	}

	public AutoSuggestRequest getAutoSuggestRequest() {
		return autoSuggestRequestBuilder.getAutoSuggestRequest();
	}
}
