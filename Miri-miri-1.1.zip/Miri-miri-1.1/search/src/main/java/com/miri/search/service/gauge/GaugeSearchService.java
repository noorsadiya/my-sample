package com.miri.search.service.gauge;

import java.util.Iterator;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.crsh.console.jline.internal.Log;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.OrFilterBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeFilterBuilder;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.index.query.TermsFilterBuilder;
import org.elasticsearch.search.SearchHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticsearchConfig;
import com.miri.search.constants.SearchConstants;
import com.miri.search.domain.guage.GaugeRequest;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.utils.TimerUtil;

/**
 * Service that gets all the records form the documents requesting the guage for
 * 
 * @author noor
 *
 */
@Component
public class GaugeSearchService {
	
	private static final Logger LOG = LogManager.getLogger(GaugeSearchService.class);
	
	@Autowired
	ESQueryUtils esqueryUtils;
	
	@Autowired
	TimerUtil timerUtil;

	@Autowired
	ElasticsearchConfig elasticSearchConfig;
	

	/**
	 * getTaggedSearchHits : returns the search hits from ES for field availibity in 'tags' column of the document 
	 * @param guageRequest
	 * @return
	 */
	public SearchHits  getTaggedSearchHits(GaugeRequest guageRequest) {
		SearchHits searchHits=null;
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
	
		if( null != guageRequest){
		if(null != guageRequest.getCreateDateField() && null !=guageRequest.getFiscalDates()){
			RangeFilterBuilder fiscalRange = FilterBuilders.rangeFilter(guageRequest.getCreateDateField())
				 .from(guageRequest.getFiscalDates().getFiscalStartDate())
				.to(guageRequest.getFiscalDates().getFiscalEndDate());
			boolFilter.must(fiscalRange);
		}
		
		if(null != guageRequest.getTagsField()){
			boolFilter.must(FilterBuilders.termFilter(SearchConstants.TAGS_RAW,guageRequest.getTagsField()));	
		}
		
		SearchRequestBuilder searchRequestBuilder = elasticSearchConfig.getTransportClient().prepareSearch(guageRequest.getIndex())
				.setTypes(guageRequest.getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
		searchHits=getSearchHits(searchRequestBuilder);
		}
		
		return searchHits;
	}
	
	
	/**
	 * getTotalDocumentSearchHits : returns the total number of documents in the fiscal
	 * @param guageRequest
	 * @return
	 */
	public SearchHits getTotalDocumentSearchHits(GaugeRequest guageRequest){
		SearchHits searchHits=null;	
		
		SearchRequestBuilder searchRequestBuilder = elasticSearchConfig.getTransportClient().prepareSearch(guageRequest.getIndex())
				.setTypes(guageRequest.getDocumentType());
				
		if(StringUtils.isNotBlank(guageRequest.getCreateDateField()) && null !=guageRequest.getFiscalDates()){
			
			RangeQueryBuilder rangeQuery=QueryBuilders.rangeQuery(guageRequest.getCreateDateField())
					.gte(guageRequest.getFiscalDates().getFiscalStartDate())
					.lte(guageRequest.getFiscalDates().getFiscalEndDate());
			
			searchRequestBuilder.setQuery(rangeQuery);
		}
			
			LOG.debug("Total documents count :-"+guageRequest.getIndex()+guageRequest.getDocumentType()+" :- "+searchRequestBuilder);
			
			searchHits=getSearchHits(searchRequestBuilder);
		
	
		return searchHits;
	}
	
	/**
	 * getSearchHits : executes the ES query and return search hits form the response
	 * @param searchRequestBuilder
	 * @return
	 */
	private SearchHits getSearchHits(SearchRequestBuilder searchRequestBuilder){
		
		SearchResponse searchResponse = esqueryUtils.execute(searchRequestBuilder);
		SearchHits searchHits = searchResponse.getHits();
		
		return searchHits;
	}
	
	/**
	 * getGuageSearchHitsForDocument : returns the search hits matching wither of the fields in tags of the document 
	 * @param guageRequest
	 * @return
	 */
	public SearchHits  getGuageSearchHitsForDocument(GaugeRequest guageRequest) {
		
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
	
		if(guageRequest.getCreateDateField()!=null){
		RangeFilterBuilder fiscalRange = FilterBuilders.rangeFilter(guageRequest.getCreateDateField())
				 .from(guageRequest.getFiscalDates().getFiscalStartDate())
				.to(guageRequest.getFiscalDates().getFiscalEndDate());
		boolFilter.must(fiscalRange);
		}
			
		OrFilterBuilder orFilterBuilder = new OrFilterBuilder();
		TermsFilterBuilder tagOrfilter = null;
		for (Iterator iterator = guageRequest.getTagsFields().iterator(); iterator.hasNext();) {
			String tagValue = (String) iterator.next();
			tagOrfilter = FilterBuilders.termsFilter(SearchConstants.TAGS_RAW, tagValue);
			orFilterBuilder.add(tagOrfilter);
		}
		boolFilter.must(orFilterBuilder);
		
		SearchRequestBuilder searchRequestBuilder = elasticSearchConfig.getTransportClient().prepareSearch(guageRequest.getIndex())
				.setTypes(guageRequest.getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter)).setSize(1000000000)
				.addFields(guageRequest.getRelevantFields());
		
		return getSearchHits(searchRequestBuilder);
	}
	

	
}
