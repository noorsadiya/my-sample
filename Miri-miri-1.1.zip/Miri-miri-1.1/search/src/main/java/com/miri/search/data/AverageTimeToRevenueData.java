package com.miri.search.data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class AverageTimeToRevenueData implements Serializable {
	
	/**
	 * Default serial version UID
	 */
	private static final long serialVersionUID = 1L;

	private String campaignId;
	
	private String campaignName;
	
	private Map<String, String> subCampaigns;
	
	private List<String> opportunityIds;
	
	private double actualCost;
	
	private List<MultipleAxesChartData> revenueData;
	
	private String name;
	
	public double getActualCost() {
		return actualCost;
	}

	public void setActualCost(double actualCost) {
		this.actualCost = actualCost;
	}

	public List<String> getOpportunityIds() {
		return opportunityIds;
	}

	public void setOpportunityIds(List<String> opportunityIds) {
		this.opportunityIds = opportunityIds;
	}

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public Map<String, String> getSubCampaigns() {
		return subCampaigns;
	}

	public void setSubCampaigns(Map<String, String> subCampaigns) {
		this.subCampaigns = subCampaigns;
	}
	
	/**
	 * @return the revenueData
	 */
	public List<MultipleAxesChartData> getRevenueData() {
		return revenueData;
	}

	/**
	 * @param revenueData the revenueData to set
	 */
	public void setRevenueData(List<MultipleAxesChartData> revenueData) {
		this.revenueData = revenueData;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

}
