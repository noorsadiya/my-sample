
package com.miri.search.service.crm;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.count.CountRequestBuilder;
import org.elasticsearch.action.count.CountResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.FilteredQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeFilterBuilder;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.index.query.TermsFilterBuilder;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.bucket.histogram.InternalHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Order;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.metrics.avg.InternalAvg;
import org.elasticsearch.search.aggregations.metrics.cardinality.CardinalityBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.InternalCardinality;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.tophits.InternalTopHits;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHitsBuilder;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.CrmCampaign;
import com.miri.cis.entity.CrmLead;
import com.miri.cis.entity.CrmOpportunity;
import com.miri.cis.entity.ESEntity;
import com.miri.cis.entity.MapCampaign;
import com.miri.cis.entity.MapLead;
import com.miri.data.jpa.domain.MiriHistoryData;
import com.miri.data.jpa.util.AppSalesStageContainer;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.OpportunityStagesEnum;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.CampaignRevenueData;
import com.miri.search.data.ColumnDrillDownData;
import com.miri.search.data.FilterData;
import com.miri.search.data.FiscalDatesStrData;
import com.miri.search.data.InvoiceDataPojo;
import com.miri.search.data.InvoiceStatsData;
import com.miri.search.data.LargeOpenOpportunitiesMetricData;
import com.miri.search.data.MarketingCampaignTrendData;
import com.miri.search.data.MultipleAxesChartData;
import com.miri.search.data.RevenueOpportunitiesData;
import com.miri.search.data.SalesPersonRevenueData;
import com.miri.search.data.TopHighestCustomerData;
import com.miri.search.data.WinLossData;
import com.miri.search.esutils.AggregationUtil;
import com.miri.search.esutils.BoolQueryBuilderRequest;
import com.miri.search.esutils.BoolQueryBuilderRequest.BoolType;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;
import com.miri.search.service.erp.ERPOpportunityCompetitorService;
import com.miri.search.service.erp.RevenueGeneratedService;
import com.miri.search.service.manual.ManualAccountStrategyService;
import com.miri.search.service.map.MapCampaignService;
import com.miri.search.service.map.MapOpportunityService;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.TimerUtil;

/**
 * Common Opportunity Service to get opportunities
 * @author rammoole
 *
 */
@Component
public class CRMOpportunityService extends MiriSearchService {

	private static final Logger LOG = LogManager.getLogger(CRMOpportunityService.class);

	// Constants
	private static final String LEAD_SOURCE = "lead-source";

	private static final String CAMPAIGN = "campaign";

	private static final String SALES_PERSON = "sales-person";

	private static final String GROUPNAME_NUMCUSTOMER = "numCustomers";

	@Autowired
	private ESQueryUtils esQueryUtils;

	@Autowired
	private MapOpportunityService mapOpportunityService;

	@Autowired
	private ERPInvoiceService erpInvoiceService;

	@Autowired
	private ManualAccountStrategyService accountStrategyService;

	@Autowired
	private CRMAccountService crmAccountService;

	@Autowired
	private CRMCampaignService crmCampaignService;

	@Autowired
	private ERPOpportunityCompetitorService erpOpportunityCompetitorService;

	@Autowired
	private ManualAccountStrategyService manualAccountStrategyService;

	@Autowired
	private TimerUtil timeUtil;

	@Autowired
	private MapCampaignService mapCampaignService;

	@Autowired
	private CRMProductService crmProductService;

	@Autowired
	private AppSalesStageContainer appSalesStageContainer;

	@Autowired
	private CRMOpportunityProductService crmOpportunityProductService;
	
	@Autowired
	RevenueGeneratedService revenueGeneratedService;

	/**
	 * Get Opportunities by stage and fiscal dates
	 * @param stage
	 * @param fiscalStartDate
	 * @param fiscalEndDate
	 * @return
	 */
	public List<CrmOpportunity> getOpportunitiesByStageAndFiscalYear(final String stage, final String fiscalStartDate,
			final String fiscalEndDate) {
		Client client = getTransportClient();

		SearchResponse opportunityRespose = getCrmOpportunitiesSearchResponse(stage, fiscalStartDate, fiscalEndDate, client);

		List<CrmOpportunity> crmOpportunities = extractOpportunityObjects(client, opportunityRespose);

		LOG.debug("getCrmOpportunities :" + crmOpportunities.size());
		return crmOpportunities;
	}

	/**
	 * Get CRM opportunity by given opportunity id.
	 *
	 * @param opportunityId
	 * @return
	 */
	public CrmOpportunity getCRMOpportunityById(final String opportunityId) {
		CrmOpportunity crmOpportunity = (CrmOpportunity) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(),
				getIndex(), SearchConstants.OPPORTUNITY_ID_RAW, opportunityId);
		return crmOpportunity;
	}

	/**
	 * Get all won Marketing Influenced Opportunities
	 * @param startDate TODO
	 * @param endDate TODO
	 *
	 * @return
	 */
	public List<String> getWonMarketingInfluenceddOpportunites(String startDate, String endDate) {

		timeUtil.start();
		List<String> marketingInfluencedOptys = new ArrayList<>();
		List<String> subCamapigns =  mapCampaignService.getMarketingSubCampaigns();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapigns));
		if(!StringUtils.isEmpty(startDate) && !StringUtils.isEmpty(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).from(startDate).to(endDate));
		}

		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));

		SearchRequestBuilder srb = getTransportClient().prepareSearch(SearchConstants.CRM)
				.setSearchType(SearchType.SCAN).setScroll(new TimeValue(6000))
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addField(SearchConstants.OPPORTUNITY_ID)
				.setSize(1000);

		SearchResponse opportunityRespose = esQueryUtils.execute(srb);

		timeUtil.end();
		LOG.debug("getWonMarketingInfluenceddOpportunites ES time "+timeUtil.timeTakenInMillis());
		timeUtil.start();

		while(true){
			SearchHits oppSearchHits = opportunityRespose.getHits();
			for (SearchHit hit : oppSearchHits) {
				marketingInfluencedOptys.add(hit.getFields().get(SearchConstants.OPPORTUNITY_ID).getValue().toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(1000));
			opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		timeUtil.end();
		LOG.debug("getWonMarketingInfluenceddOpportunites Java Time "+timeUtil.timeTakenInMillis());
		return marketingInfluencedOptys;
	}
	/**
	 * Get all Won Marketing Influenced Opportunities
	 * @param startDate TODO
	 * @param endDate TODO
	 *
	 * @return
	 */
	public List<String> getWonMarketingInfluenceddOpportunites() {
		return getWonMarketingInfluenceddOpportunites(null, null);
	}

	/**
	 * Won marketing Influenced Opportunities Count
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return
	 */
	public long getWonMarketingInfluencedOpportunitiesCount(String startDate, String endDate) {

		List<String> mapCampaigns = mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
		boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).from(startDate).to(endDate));
		boolFilter.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));

		CountRequestBuilder countRequestBuilder = this.getTransportClient().prepareCount(getIndex())
				.setTypes(getDocumentType()).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
		return countRequestBuilder.get().getCount();
	}

	/**
	 * This method is used to get details of Large opportunities which are open in both marketing and sales campaign
	 * @param startDate TODO
	 * @param endDate TODO
	 *
	 * @return {@link Map} Returns the map containing the opportunity ID's as key and the opportunity details as the
	 * values in string array
	 *
	 */
	public List<LargeOpenOpportunitiesMetricData> getOverallLargeOpenopportunities(int size, String startDate, String endDate) {

		List<String> mapCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		List<String> stageToExclude = new ArrayList<>();
		stageToExclude.addAll(appSalesStageContainer.getClosedWonMappedStages());
		stageToExclude.addAll(appSalesStageContainer.getClosedLostMappedStages());

		stageToExclude.add(OpportunityStagesEnum.STAGE_EMPTY.getText());

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		//MIRI-1828 - requested date should fall in closed date rather than created date
		boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(startDate).to(endDate));
		boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stageToExclude));

		SortBuilder sortBuilder = SortBuilders.fieldSort(CRMConstants.OPPORTUNITY_AMOUNT).order(SortOrder.DESC);

		SearchRequestBuilder searchRequestBuilder = getTransportClient()
				.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(size)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addSort(sortBuilder);

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		List<LargeOpenOpportunitiesMetricData> metricData =  new ArrayList<>();
		LargeOpenOpportunitiesMetricData  data;
		String customerName = "";
		SearchHits oppSearchHits = searchResponse.getHits();
		for (SearchHit hit : oppSearchHits) {
			data =  new LargeOpenOpportunitiesMetricData();
			CrmOpportunity crmOpportunity = (CrmOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex());
			data.setProbability(Integer.toString(crmOpportunity.getProbabilityPerc()));
			data.setAmount(crmOpportunity.getAmount());
			//miri-1832 : Set the amount in z placeholder as well.
			data.setzValue(crmOpportunity.getAmount());
			data.setStage(crmOpportunity.getStage());
			customerName = crmOpportunity.getCompanyName();
			if(StringUtils.isBlank(customerName)){
				customerName = crmAccountService.getAccountNameByAccountId(crmOpportunity.getAccountId());
			}
			data.setCustomerName(customerName);
			data.setName(data.getCustomerName());
			data.setSalesPerson(crmOpportunity.getOwner());
			//MIRI-1828 - requested date should fall in closed date rather than created date
			data.setClosedDate(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD, crmOpportunity.getClosedDate()));
			if(StringUtils.isNotBlank(crmOpportunity.getPrimaryCampSource()) && mapCampaigns.contains(crmOpportunity.getPrimaryCampSource())){
				data.setIsmarketingInfluenced(true);
				data.setCampaignName(crmCampaignService.getCampaignNamebyPrimaryCampaignSource(crmOpportunity.getPrimaryCampSource()));
				data.setCampaignId(crmOpportunity.getPrimaryCampSource());
			}
			else{
				data.setIsmarketingInfluenced(false);
			}

			metricData.add(data);
		}
		return metricData;
	}

	/**
	 * This method is used to get details of Large opportunities which are open in both marketing and drilldown
	 * @param startDate TODO
	 * @param endDate TODO
	 *
	 * @return {@link Map} Returns the map containing the opportunity ID's as key and the opportunity details as the
	 * values in string array
	 *
	 */
	public List<LargeOpenOpportunitiesMetricData> getMarketingInfluencedLargeOpenopportunitiesByFilter(int size, String startDate, String endDate, String filter) {

		List<String> mapCampaigns =  mapCampaignService.getMarketingSubCampaigns();

		List<String> stageToExclude = new ArrayList<>();
		stageToExclude.addAll(appSalesStageContainer.getClosedWonMappedStages());
		stageToExclude.addAll(appSalesStageContainer.getClosedLostMappedStages());
		stageToExclude.add(OpportunityStagesEnum.STAGE_EMPTY.getText());

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).from(startDate).to(endDate));
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
		boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stageToExclude));

		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(filter).size(25).order(Order.aggregation("sumAggregation", false))
				.subAggregation(AggregationBuilders.sum("sumAggregation").field(SearchConstants.AMOUNT));

		SearchRequestBuilder searchRequestBuilder = getTransportClient()
				.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.QUERY_THEN_FETCH)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(aggregationBuilders);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		List<LargeOpenOpportunitiesMetricData> metricData =  new ArrayList<>();
		LargeOpenOpportunitiesMetricData  data;

		Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> termsBuckets = terms.getBuckets();

		for (Terms.Bucket termBucket : termsBuckets) {
			data =  new LargeOpenOpportunitiesMetricData();
			String filterName = termBucket.getKey();
			if(StringUtils.isNotBlank(filterName)){
				data.setName(filterName);
				Sum sum = termBucket.getAggregations().get("sumAggregation");
				data.setAmount(sum.getValue());
			}
			metricData.add(data);
		}

		return metricData;
	}

	/**
	 * Get opportunities for list of campaign ids
	 * @param campaignIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getOpportuniesByCampaignIds(List<String> campaignIds, String startDate, String endDate) {
		if(CollectionUtils.isEmpty(campaignIds)){
			return new ArrayList<String>();
		}
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, campaignIds));

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));
		}
		List<String> campaignOptys = new ArrayList<>();

		SearchRequestBuilder srb = getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(1000)
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN).addField(SearchConstants.OPPORTUNITY_ID);
		SearchResponse opportunityRespose = esQueryUtils.execute(srb);

		while(true) {
			SearchHits oppSearchHits = opportunityRespose.getHits();
			for(SearchHit hit: oppSearchHits) {
				campaignOptys.add(hit.getFields().get(SearchConstants.OPPORTUNITY_ID).getValue().toString());
			}
			opportunityRespose = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000)).get();
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return campaignOptys;
	}

	/**
	 * Returns opportunities for the given campaign id. If parent campaign is
	 * passed then all opportunities of it's sub campaigns will be returned.
	 * 
	 * @param campaignId
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getOpportuniesByCampaignIds(String campaignId, String startDate, String endDate) {
		List<String> campaignIds = crmCampaignService.getSubCampaignIds(campaignId);
		if (null != campaignIds && campaignIds.size() > 0) {
			return getOpportuniesByCampaignIds(campaignIds, startDate, endDate);
		} else {
			campaignIds = new ArrayList<>();
			campaignIds.add(campaignId);
			return getOpportuniesByCampaignIds(campaignIds, startDate, endDate);
		}
	}

	/**
	 * Get Opportunities by parent campaign id and date range
	 * @return
	 */
	public List<String> getOpportunitiesByParentCampaignId(final String parentCampaignId, final String startDate, final String endDate) {
		List<String> subCampaigns = crmCampaignService.getSubCampaignIds(parentCampaignId);
		List<String> crmOpportunities = getOpportuniesByCampaignIds(subCampaigns, startDate, endDate);
		return crmOpportunities;
	}

	/**
	 * Get the list of opportunities by campaign ID
	 * @param campaignId
	 * @return
	 * @author rammoole
	 */
	public List<CrmOpportunity> getOpportunitiesByCampaignId(String campaignId) {
		// if the passed campaign Id is parent campaign then get all the sub campaigns of that campaign and
		// get the opportunities of that campaign
		Map<String, String> subCampaigns = this.crmCampaignService.getSubCampaigns(campaignId);
		List<String> campaignIds = new ArrayList<>(subCampaigns.keySet());
		campaignIds.add(campaignId);
		List<CrmOpportunity> crmOpportunities = null;
		Client client = this.getTransportClient();
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(SearchConstants.PRIMARY_CAMPAIGN_SOURCE_RAW, campaignIds)));
		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		if (opportunityRespose != null) {
			long totalHits = opportunityRespose.getHits().getTotalHits();
			searchRequestBuilder = client.prepareSearch(SearchConstants.CRM).setTypes(SearchConstants.CRM_OPPORTUNITY)
					.setSize((int) totalHits)
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
							FilterBuilders.termsFilter(SearchConstants.PRIMARY_CAMPAIGN_SOURCE_RAW, campaignIds)))
					.setFetchSource(true);
			opportunityRespose = esQueryUtils.execute(searchRequestBuilder);

			crmOpportunities = new ArrayList<>();
			for (SearchHit hit : opportunityRespose.getHits()) {
				crmOpportunities
						.add((CrmOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
			}

		}
		return crmOpportunities;
	}

	/**
	 * Get Opportunity Ids by campaign Id
	 * @param campaignId
	 * @return
	 */
	public List<String> getOpportunityIdsByCampaignId(String campaignId) {
		List<CrmOpportunity> crmOpportunities = this.getOpportunitiesByCampaignId(campaignId);
		List<String> opportunityIds = new ArrayList<>();
		for(CrmOpportunity crmOpportunity: crmOpportunities) {
			opportunityIds.add(crmOpportunity.getOpportunityId());
		}
		return opportunityIds;
	}

	/**
	 * Get All the Opportunity Names of a campaign
	 * @param campaignId
	 * @return
	 * @author rammoole
	 */
	public List<String> getOpportunityNamesByCampaignId(String campaignId) {
		// if the passed campaign Id is parent campaign then get all the sub campaigns of that campaign and
		// get the opportunities of that campaign
		List<CrmOpportunity> crmOpportunities = this.getOpportunitiesByCampaignId(campaignId);
		List<String> opportunityNames = new ArrayList<>();
		for(CrmOpportunity crmOpportunity: crmOpportunities) {
			opportunityNames.add(crmOpportunity.getOpportunityName());
		}
		return opportunityNames;
	}

	/**
	 * get Won opportunity ids
	 * @param opportunityIds
	 * @return
	 */
	public List<String> getWonOpportunitiesByOpportunityIds(List<String> opportunityIds) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(opportunityIds.size())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.termsQuery(CRMConstants.OPPORTUNITY_STAGE_RAW,
						appSalesStageContainer.getClosedWonMappedStages()), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds)));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> wonOpportunityIds = new ArrayList<>();
		for(SearchHit hit: searchResponse.getHits()) {
			wonOpportunityIds.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
		}
		return wonOpportunityIds;
	}

	/**
	 * Get Won Marketing Influenced Opportunities
	 * @return
	 * @author rammoole
	 */
	public List<String> getMarketingInfluencedOpportunites(String startDate, String endDate) {
		return getMarketingInfluencedOpportunities(startDate, endDate, null);
	}

	/**
	 * Get Marketing Influenced Opportunities from passed list of opportunities
	 * @param startDate
	 * @param endDate
	 * @param opportunities
	 * @return
	 */
	public List<String> getMarketingInfluencedOpportunities(String startDate, String endDate, List<String> opportunities) {
		timeUtil.start();
		Client client = getTransportClient();

		List<String> marketingInfluencedOptys = new ArrayList<>();
		List<String> subCamapigns =  mapCampaignService.getMarketingSubCampaigns();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapigns));

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).from(startDate).to(endDate));
		}

		if(CollectionUtils.isNotEmpty(opportunities)) {
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}

		SearchRequestBuilder srb = client.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setFetchSource(CRMConstants.OPPORTUNITY_ID, null)
				.setSize(500)
				.setScroll(new TimeValue(60000))
				.setSearchType(SearchType.SCAN);

		SearchResponse opportunityRespose = esQueryUtils.execute(srb);

		while(true) {
			SearchHits oppSearchHits = opportunityRespose.getHits();
			for (SearchHit hit : oppSearchHits) {
				marketingInfluencedOptys.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder scrollRequestBuilder=client.prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(60000));
			opportunityRespose=esQueryUtils.execute(scrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		timeUtil.end();
		//LOG.debug("getMarketingInfluencedOpportunites time taken :" + timeUtil.timeTakenInMillis());
		return marketingInfluencedOptys;
	}
	/**
	 * Get Marketing Influenced Opportunities from passed list of opportunities
	 * @param startDate
	 * @param endDate
	 * @param opportunities
	 * @return
	 */
	public List<String> getSalesGeneratespportunities(String startDate, String endDate, List<String> opportunities) {
		timeUtil.start();
		Client client = getTransportClient();

		List<String> marketingInfluencedOptys = new ArrayList<>();
		List<String> subCamapigns =  mapCampaignService.getMarketingSubCampaigns();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapigns));

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).from(startDate).to(endDate));
		}

		if(CollectionUtils.isNotEmpty(opportunities)) {
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}

		SearchRequestBuilder srb = client.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setFetchSource(CRMConstants.OPPORTUNITY_ID, null)
				.setSize(500)
				.setScroll(new TimeValue(60000))
				.setSearchType(SearchType.SCAN);

		SearchResponse opportunityRespose = esQueryUtils.execute(srb);

		while(true) {
			SearchHits oppSearchHits = opportunityRespose.getHits();
			for (SearchHit hit : oppSearchHits) {
				marketingInfluencedOptys.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder scrollRequestBuilder=client.prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(60000));
			opportunityRespose=esQueryUtils.execute(scrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		timeUtil.end();
		//LOG.debug("getMarketingInfluencedOpportunites time taken :" + timeUtil.timeTakenInMillis());
		return marketingInfluencedOptys;
	}

	public List<String> getMarketingInfluencedOpportunites() {
		return getMarketingInfluencedOpportunites(null,null);
	}

	/**
	 * This method gives the number of leads captured between the provided dates
	 * @param startDate Date from which we need to get the lead count
	 * @param endDate Date till which we need to get the lead count
	 * @return {@link Long} number of leads between the provided dates
	 */
	public Double getMarketingOpportunityCountByDate(String startDate, String endDate) {
		List<String> subCampaigns = mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaigns));
		boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).from(startDate).to(endDate));
		CountResponse res = this.getTransportClient().prepareCount()
				.setIndices(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter)).execute().actionGet();
		return (double) res.getCount();
	}
	/**
	 *
	 * This method gives the number of leads captured between the provided dates
	 * @param startDate Date from which we need to get the lead count
	 * @param endDate Date till which we need to get the lead count
	 * @return {@link Long} number of leads between the provided dates
	 */
	public Double getMarketingOpportunityLostByDate(String startDate, String endDate) {
		List<String> subCampaigns = mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaigns));
		boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(startDate).to(endDate));
		boolFilter.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedLostMappedStages()));
		CountResponse res = this.getTransportClient().prepareCount()
				.setIndices(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter)).execute().actionGet();
		return (double) res.getCount();
	}

	/**
	 *
	 * This method gives the number of opportunities captured for List of campaigns
	 * @param campaignIds
	 * 			Campaign Id's for which we need opportunity Id's
	 * @return
	 * 		{@link Double} number of opportunities
	 */
	public Double getOpportunityCountByCampaignIds(List<String> campaignIds, String startDate, String endDate){
		QueryBuilder queryBuilder = QueryBuilders.termsQuery(SearchConstants.PRIMARY_CAMP_SOURCE, campaignIds);
		RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CREATED_ON).gt(startDate).lt(endDate);
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		boolQueryBuilder.must(queryBuilder);
		boolQueryBuilder.must(rangeQueryBuilder);
		CountResponse res = getResponse(boolQueryBuilder, getIndex(), getDocumentType());
		return (double) res.getCount();
	}

	/**
	 *
	 * This method gives the number of opportunities captured for Parent campaign
	 * @param campaignIds
	 * 			Campaign Id's for which we need opportunity Id's
	 * @return
	 * 		{@link Double} number of opportunities
	 */
	public Double getOpportunityCountByParentCampaignId(String parentCampaignId, String startDate, String endDate){
		Map<String, String> subCampaigns = crmCampaignService.getSubCampaigns(parentCampaignId);
		return this.getOpportunityCountByCampaignIds(new ArrayList<>(subCampaigns.keySet()), startDate, endDate);
	}

	/**
	 * This method is used to get the Month wise opportunities response for a campaign
	 *
	 * @param camapaignId Id of a campaign
	 * @return {@link SearchResponse} Elastic search response
	 */
	public SearchResponse getMonthWiseOpportunitiesForCampaignResponseInDateRange(final String campaignId, final String startDate, final String endDate) {

		Client client = getTransportClient();
		Map<String, String> subCampaigns = crmCampaignService.getSubCampaigns(campaignId);

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		FilterBuilder opportunityQueryBuilder = FilterBuilders.termsFilter(SearchConstants.PRIMARY_CAMP_SOURCE,
				subCampaigns.keySet());

		FilterBuilder rangeQueryBuilder = FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate);
		boolFilter.must(opportunityQueryBuilder);
		boolFilter.must(rangeQueryBuilder);
		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.CAMPAIGN_AGGREGATION).field(SearchConstants.CREATED_ON)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate);

		SearchRequestBuilder srb = client.prepareSearch(SearchConstants.CRM).setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(dateAggregation);
		SearchResponse response = esQueryUtils.execute(srb);
		return response;
	}

	/**
	 * Get month wise opportunities for the campaign with in the fiscal date
	 * @param parentCampaignId
	 * @return
	 * @author rammoole
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, List<String>> getMonthWiseOpportunitiesForCampaignResponse(final String parentCampaignId, final String startDate, final String endDate) {
		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(CRMConstants.OPPORTUNITY_CLOSED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate);
		Client client = this.getTransportClient();
		List<String> subCampaigns = crmCampaignService.getSubCampaignIds(parentCampaignId);
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType()).addAggregation(dateAggregation)
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
						FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaigns)));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		InternalHistogram dateHistogram = searchResponse.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
		Collection<InternalHistogram.Bucket> termsBuckets = dateHistogram.getBuckets();
		Calendar monthStart = Calendar.getInstance();
		Calendar monthEnd = Calendar.getInstance();
		Map<Integer, List<String>> opportunitiesByMonth = new LinkedHashMap<>();
		String monthStartStr;
		String monthEndStr;
		int count = 0;
		List<String> opportunities;
		for (InternalHistogram.Bucket dateBucket : termsBuckets) {
			monthStart.setTime(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD, dateBucket.getKeyAsText().toString()));
			//int month = monthStart.get(Calendar.MONTH);
			monthEnd.setTime(monthStart.getTime());
			monthEnd.set(Calendar.DAY_OF_MONTH, monthStart.getActualMaximum(Calendar.DAY_OF_MONTH));
			monthStartStr = MiriDateUtils.parseDateToString(monthStart, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			monthEndStr = MiriDateUtils.parseDateToString(monthEnd, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType()).setSize((int) dateBucket.getDocCount())
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(monthStartStr).lte(monthEndStr),
							FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaigns)));
			searchResponse = esQueryUtils.execute(searchRequestBuilder);
			opportunities = new ArrayList<>();
			for(SearchHit hit: searchResponse.getHits()) {
				opportunities.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			opportunitiesByMonth.put(count++, opportunities);
		}
		return opportunitiesByMonth;
	}

	/**
	 * Get month wise opportunities for the campaign with in the fiscal date
	 * @param campaignId
	 * @return
	 * @author rammoole
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, List<String>> getMonthWiseOpportunitiesForDateRange(final String startDate, final String endDate) {
		QueryBuilder opportunityQueryBuilder = QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate);

		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.MONTH_WISE_AGGREGATION).field(CRMConstants.OPPORTUNITY_CREATED_ON)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate);

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setQuery(opportunityQueryBuilder)
				.addAggregation(dateAggregation).addFields(CRMConstants.OPPORTUNITY_CREATED_ON, SearchConstants.OPPORTUNITY_ID_RAW);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		InternalHistogram datehistogram = searchResponse.getAggregations().get(SearchConstants.MONTH_WISE_AGGREGATION);
		Collection<InternalHistogram.Bucket> buckets = datehistogram.getBuckets();
		Map<Integer, List<String>> opportunityByMonth = new LinkedHashMap<>();
		int count = 0;
		Calendar monthStart = Calendar.getInstance();
		Calendar monthEnd = Calendar.getInstance();
		String monthStartStr;
		String monthEndStr;
		for (InternalHistogram.Bucket dateBucket : buckets) {
			monthStart.setTime(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					dateBucket.getKeyAsText().toString()));
			// int month = monthStart.get(Calendar.MONTH);
			monthEnd.setTime(monthStart.getTime());
			monthEnd.set(Calendar.DAY_OF_MONTH, monthStart.getActualMaximum(Calendar.DAY_OF_MONTH));
			monthStartStr = MiriDateUtils.parseDateToString(monthStart, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			monthEndStr = MiriDateUtils.parseDateToString(monthEnd, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
					.setSize((int) dateBucket.getDocCount())
					.setTypes(getDocumentType()).setQuery(QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CREATED_ON).gte(monthStartStr).lte(monthEndStr));
			//TopHits topHits = bucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITY_HITS);
			
			searchResponse = esQueryUtils.execute(searchRequestBuilder);
			List<String> opportunities = new ArrayList<>();
			for(SearchHit searchHit: searchResponse.getHits()) {
				//LOG.info(searchHit.getSource());
				opportunities.add(searchHit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			opportunityByMonth.put(count++, opportunities);
		}
		return opportunityByMonth;
	}

	/**
	 * Get month wise opportunities for the campaign with in the fiscal date
	 * @param campaignId
	 * @return
	 * @author rammoole
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, List<String>> getMonthWiseOpportunitiesClosedForDateRange(final String startDate, final String endDate) {
		QueryBuilder opportunityQueryBuilder = QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate);

		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.MONTH_WISE_AGGREGATION).field(CRMConstants.OPPORTUNITY_CLOSED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate);

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setQuery(opportunityQueryBuilder)
				.addAggregation(dateAggregation).addFields(CRMConstants.OPPORTUNITY_CLOSED_DATE, SearchConstants.OPPORTUNITY_ID_RAW);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		InternalHistogram datehistogram = searchResponse.getAggregations().get(SearchConstants.MONTH_WISE_AGGREGATION);
		Collection<InternalHistogram.Bucket> buckets = datehistogram.getBuckets();
		Map<Integer, List<String>> opportunityByMonth = new LinkedHashMap<>();
		int count = 0;
		Calendar monthStart = Calendar.getInstance();
		Calendar monthEnd = Calendar.getInstance();
		String monthStartStr;
		String monthEndStr;
		for (InternalHistogram.Bucket dateBucket : buckets) {
			monthStart.setTime(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					dateBucket.getKeyAsText().toString()));
			// int month = monthStart.get(Calendar.MONTH);
			monthEnd.setTime(monthStart.getTime());
			monthEnd.set(Calendar.DAY_OF_MONTH, monthStart.getActualMaximum(Calendar.DAY_OF_MONTH));
			monthStartStr = MiriDateUtils.parseDateToString(monthStart, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			monthEndStr = MiriDateUtils.parseDateToString(monthEnd, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
					.setSize((int) dateBucket.getDocCount())
					.setTypes(getDocumentType()).setQuery(QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(monthStartStr).lte(monthEndStr));
			//TopHits topHits = bucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITY_HITS);
			
			searchResponse = esQueryUtils.execute(searchRequestBuilder);
			List<String> opportunities = new ArrayList<>();
			for(SearchHit searchHit: searchResponse.getHits()) {
				//LOG.info(searchHit.getSource());
				opportunities.add(searchHit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			opportunityByMonth.put(count++, opportunities);
		}
		return opportunityByMonth;
	}

	/**
	 * Utility method to interact with the Elastic search
	 *
	 * @param queryBuilder
	 * @param index
	 * @param type
	 * @param fields
	 * @return
	 */
	public CountResponse getResponse(QueryBuilder queryBuilder, String index, String type) {
		Client client = getTransportClient();
		return client.prepareCount().setIndices(index).setTypes(type).setQuery(queryBuilder).execute().actionGet();
	}

	/**
	 * Get Win Loss Opportunity Aggregation between the fiscal year
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public WinLossData getWinLossOpportunityAggregation(final String startDate, final String endDate) {
		String[] stages = (String[]) appSalesStageContainer.getClosedLostMappedStages().toArray();
		WinLossData winLossObject = new WinLossData();
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setQuery(QueryBuilders.rangeQuery(SearchConstants.CREATED_ON)
						.gte(startDate).lte(endDate)) // Have to pass the
				//				.addAggregation(AggregationBuilders.terms(SearchConstants.WON_AGGREGATION)
				//						.field(CRMConstants.OPPORTUNITY_STAGE_RAW).include(SearchConstants.OPPORTUNITY_STAGE_WON_DEPLOY_EXPAND)
				//						.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITY_HITS)
				//								.setSize(10000).setFetchSource(SearchConstants.OPPORTUNITY_ID, null)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.LOST_AGGREGATION)
						.field(CRMConstants.OPPORTUNITY_STAGE_RAW).include(stages)
						.subAggregation(AggregationBuilders.sum(SearchConstants.LOST_OPPORTUNITIES_AMOUNT)
								.field(SearchConstants.AMOUNT)));
		SearchResponse searchResponse = searchRequestBuilder.execute().actionGet();
		List<String> wonOpportunities = this.getOpportunityIdsByStageAndFiscalYear(OpportunityStagesEnum.CLOSED_WON.getText(), startDate, endDate);
		double wonSum = erpInvoiceService.getInvoiceAmountByOpportunityIds(wonOpportunities, startDate, endDate);
		// Getting Aggregations from Search Response Object
		Aggregations aggregations = searchResponse.getAggregations();

		// Process aggregation to get win loss debugrmation
		Object[] winLossData = this.getWinLossDataFromAggregation(aggregations);
		winLossObject.setWonCount((long) wonOpportunities.size());
		winLossObject.setWonAmount((double) wonSum);
		winLossObject.setLostCount((long) winLossData[2]);
		winLossObject.setLostAmount((double) winLossData[3]);
		return winLossObject;
	}

	/**
	 * Using Core Elasctisearch API for differentiating marketing influenced opportunities
	 * @param crmOpportunityIds
	 * @return List<String>
	 */
	public List<String> getMiOpportunityIds(List<String> crmOpportunityIds) {
		timeUtil.start();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, crmOpportunityIds));

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(ElasticSearchEnums.MAP.getText())
				.setTypes(ElasticSearchEnums.MAP_OPPORTUNITY.getText())
				.setPostFilter(boolFilter)
				.setSize(crmOpportunityIds.size());
		SearchResponse searchResponse = searchRequestBuilder.execute().actionGet();
		List<String> mapOpportunityIds = new ArrayList<>();
		for (SearchHit hit : searchResponse.getHits()) {
			// Whatever the records that we get are the map opportunities
			mapOpportunityIds.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
		}
		timeUtil.end();
		LOG.debug("ES time getMiOpportunityIds ES"+timeUtil.timeTakenInMillis());
		return mapOpportunityIds;
	}

	/**
	 * Using Core Elasctisearch API for getting sales generated
	 * @param crmOpportunityIds
	 * @return List<Object> gives Sales Generated Opportunity Ids
	 */
	public List<String> getSgOpportunityIds(List<String> crmOpportunityIds) {

		BoolQueryBuilder termsQuery=MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW,
				crmOpportunityIds, 1000);

		SearchResponse searchResponse = getTransportClient().prepareSearch(ElasticSearchEnums.MAP.getText())
				.setTypes(ElasticSearchEnums.MAP_OPPORTUNITY.getText()).setSize(crmOpportunityIds.size())
				.setQuery(termsQuery).execute()
				.actionGet();

		for (SearchHit hit : searchResponse.getHits()) {
			// Whatever the records that we get are the map opportunities
			if (crmOpportunityIds.contains(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString())) {
				crmOpportunityIds.remove(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
		}
		return crmOpportunityIds;
	}

	/**
	 * Process Search Response for Win Loss Data
	 * @param aggregations
	 * @return
	 */
	public Object[] getWinLossDataFromAggregation(Aggregations aggregations) {
		long wonOpportunities = 0;
		long lostOpportunities = 0;
		double wonOpportunitiesAmount = 0;
		double lostOpportunitiesAmount = 0;
		Collection<Terms.Bucket> buckets;
		// Extracting Won aggregation
		/*if(null != aggregations){
			Terms wonTerms = aggregations.get(SearchConstants.WON_AGGREGATION);

			if(wonTerms != null) {
				buckets = wonTerms.getBuckets();

				List<String> opportunityIds = new ArrayList<String>();
				TopHits topHits;
				for (Terms.Bucket bucket : buckets) {
					wonOpportunities = bucket.getDocCount();
					topHits = bucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITY_HITS);
					for (SearchHit hit : topHits.getHits()) {
						opportunityIds.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
					}
				}
				// This object returns array of both invoice amount and the number of invoices
				wonOpportunitiesAmount = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds);
			}
		}
		 */

		// Lost Aggregation extraction
		if(null != aggregations){
			Terms lostTerms = aggregations.get(SearchConstants.LOST_AGGREGATION);
			buckets = lostTerms.getBuckets();
			Sum sumAggr;
			for (Terms.Bucket bucket : buckets) {
				lostOpportunities += bucket.getDocCount();
				sumAggr = bucket.getAggregations().get(SearchConstants.LOST_OPPORTUNITIES_AMOUNT);
				lostOpportunitiesAmount += sumAggr.getValue();
			}
		}
		return new Object[] { wonOpportunities, wonOpportunitiesAmount, lostOpportunities, lostOpportunitiesAmount };
	}

	/**
	 * Using Core Elasctisearch API for differentiating sales generated and marketing influenced opportunities
	 * @param crmOpportunityIds
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return List<Object>
	 */

	public Map<String, Object> getMiSgOpportunityIds(List<String> crmOpportunityIds, String startDate, String endDate) {

		timeUtil.start();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(!CollectionUtils.isEmpty(crmOpportunityIds)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, crmOpportunityIds));
		}

		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_DATE).from(startDate).to(endDate));

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(ElasticSearchEnums.MAP.getText())
				.setTypes(ElasticSearchEnums.MAP_OPPORTUNITY.getText())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(1000)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		List<String> mapOpportunityIds = new ArrayList<>();
		while(true){
			for (SearchHit hit : searchResponse.getHits()) {
				// Whatever the records that we get are the map opportunities
				mapOpportunityIds.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				if (crmOpportunityIds.contains(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString())) {
					crmOpportunityIds.remove(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				}
			}
			searchResponse = getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)).get();

			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		Map<String, Object> miSgOpportunities = new HashMap<>();
		miSgOpportunities.put(SearchConstants.MARKETING_INFLUENCED, mapOpportunityIds);
		miSgOpportunities.put(SearchConstants.SALES_GENERATED, crmOpportunityIds);
		return miSgOpportunities;
	}

	/**
	 * Get all Sales generated Opportunities for fiscal year
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return
	 * @author rammoole
	 */
	public List<String> getWonSalesGeneratedOpportunityIds(String startDate, String endDate) {
		timeUtil.start();

		List<String> subCampaigns =  mapCampaignService.getMarketingSubCampaigns();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaigns));
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).from(startDate).to(endDate));
		}
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));

		SearchRequestBuilder searchRequestBuilder =  getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setSearchType(SearchType.SCAN).setScroll(new TimeValue(60000))
				.setSize(1000)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addField(CRMConstants.OPPORTUNITY_ID);

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		timeUtil.end();
		LOG.debug("getWonSalesGeneratedOpportunityIds ES time "+timeUtil.timeTakenInMillis());
		timeUtil.start();

		List<String> sgOpportunities = new ArrayList<>();
		if(searchResponse != null) {
			while(true) {
				for (SearchHit hit : searchResponse.getHits()) {
					sgOpportunities.add(hit.field(CRMConstants.OPPORTUNITY_ID).getValue().toString());
				}
				SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(searchResponse.getScrollId())
						.setScroll(new TimeValue(1000));
				searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
				if(searchResponse.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		timeUtil.end();
		LOG.debug("getWonSalesGeneratedOpportunityIds Java Time :- " + timeUtil.timeTakenInMillis());
		return sgOpportunities;
	}
	/**
	 * Get all Sales generated Opportunities
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return
	 * @author rammoole
	 */
	public List<String> getWonSalesGeneratedOpportunityIds() {
		return this.getWonSalesGeneratedOpportunityIds(null, null);
	}

	/**
	 * Using core elasticsearch API for getting opportunities based on stage and fiscal year. If Stage is null then only
	 * results between the fiscal dates are returned
	 * @param stage
	 * @param ficalStartDate
	 * @param fiscalEndDate
	 * @return
	 */
	public List<String> getOpportunityIdsByStageAndFiscalYear(final String stage, final String fiscalStartDate,
			final String fiscalEndDate) {
		timeUtil.start();

		List<String> opportunityIds = this.getCrmOpportunities(stage, fiscalStartDate, fiscalEndDate);

		timeUtil.end();
		LOG.debug(" ES time opportunityIds size:-ES"+timeUtil.timeTakenInMillis());

		return opportunityIds;
	}

	/**
	 * Gets the CRM Opportunities the based on the stage and fiscal year provided
	 * Added scroll to get huge data based on stage and date range
	 *
	 */
	public List<String> getCrmOpportunities(String stage, String startDate, String endDate) {
		Client client = getTransportClient();

		SearchResponse opportunityRespose = getCrmOpportunitiesSearchResponse(stage, startDate, endDate, client);

		List<String> crmOpportunities = extractOpportunityIds(client, opportunityRespose);

		LOG.debug("getCrmOpportunities  :" + crmOpportunities.size());
		return crmOpportunities;
	}

	/**
	 * Client object can be null. If null object is passed, it will create a new client object inside the method
	 * @param stage
	 * @param startDate
	 * @param endDate
	 * @param client
	 * @return
	 */
	public SearchResponse getCrmOpportunitiesSearchResponse(final String stage, final String startDate, final String endDate, Client client) {
		timeUtil.start();
		if(client == null) {
			client = getTransportClient();
		}

		BoolFilterBuilder boolFilter = null;
		if(StringUtils.isNotBlank(stage)) {
			if(boolFilter == null) {
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			if(boolFilter == null) {
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).from(startDate).to(endDate));
		}
		
		// Commeting the below unused code
		/*QueryBuilder query;
		if(boolFilter != null) {
			query = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter);
		} else {
			query = QueryBuilders.matchAllQuery();
		}*/
		
		SearchRequestBuilder searchRequestBuilder = client
				.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(60000))
				.setSize(300)
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));

		SearchResponse opportunityRespose= esQueryUtils.execute(searchRequestBuilder);

		timeUtil.end();
		LOG.debug("getCrmOpportunities ES time Taken"+timeUtil.timeTakenInMillis());
		return opportunityRespose;
	}

	/**
	 * Extract OpportunityIds from search response
	 * @param client
	 * @param opportunityRespose
	 * @return
	 */
	private List<String> extractOpportunityIds(Client client,
			SearchResponse opportunityRespose) {
		timeUtil.start();
		List<String> crmOpportunities = new ArrayList<>();
		while(true) {
			for(SearchHit hit:opportunityRespose.getHits().getHits()){
				crmOpportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			opportunityRespose = client.prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(60000)).get();
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		timeUtil.end();
		LOG.debug("getCrmOpportunities Java time Taken"+timeUtil.timeTakenInMillis());
		return crmOpportunities;
	}

	/**
	 * Extract Opportunity Objects from search response
	 * @param client
	 * @param opportunityRespose
	 * @return
	 */
	private List<CrmOpportunity> extractOpportunityObjects(Client client, SearchResponse opportunityRespose) {
		List<CrmOpportunity> crmOpportunities = new ArrayList<>();
		while(true) {
			for(SearchHit hit:opportunityRespose.getHits().getHits()){
				crmOpportunities.add((CrmOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
			}
			opportunityRespose = client.prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(60000)).get();
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return crmOpportunities;
	}

	/**
	 * Gets CRM Opportunities By Campaign
	 * @param timeFrame
	 *
	 */
	public Map<String, List<String>> getCrmOpportunitiesByCampaign(List<String> opportunityIds, String startDate, String endDate) {

		Map<String, List<String>> crmMap = new HashMap<String, List<String>>();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds));

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}

		TermsBuilder campSourceTermBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW).size(0);

		TermsBuilder opptTermBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);

		SearchRequestBuilder builder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter)).addAggregation(
						campSourceTermBuilder.subAggregation(opptTermBuilder));

		SearchResponse searchResponse = esQueryUtils.execute(builder);

		Terms aggTerms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);

		for (Bucket bucket : aggTerms.getBuckets()) {
			MapCampaign mapCampaign = mapCampaignService.getMAPCampaignById(bucket.getKey());
			String campaignName = null;
			if(mapCampaign != null) {
				 campaignName = mapCampaign.getCampaignName();
			}

			List<String> opportunityList = null;
			if(StringUtils.isNotBlank(campaignName)){

				opportunityList = new ArrayList<String>();

				Terms opptTermAgg = bucket.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
				for(Bucket childBucket : opptTermAgg.getBuckets()){
					opportunityList.add(childBucket.getKey());
				}
				crmMap.put(campaignName, opportunityList);
			}
		}

		return crmMap;
	}

	/**
	 * Gets CRM Opportunities by Lead source
	 * @param timeFrame
	 *
	 */
	public Map<String, List<String>> getCrmOpportunitiesByLeadSource(List<String> oppIds, String startDate, String endDate) {
		return getCrmOpportunitiesByFilter(LEAD_SOURCE, oppIds, startDate, endDate);
	}

	/**
	 * Gets CRM Opportunities by Sales Person
	 * @param timeFrame
	 */
	public Map<String, List<String>> getCrmOpportunitiesBySalesPerson(List<String> oppIds, String startDate, String endDate) {
		return getCrmOpportunitiesByFilter(SALES_PERSON, oppIds, startDate, endDate);
	}

	/**
	 * Gets CRM Opportunities based on provided the filter
	 * @param startDate
	 * @param endDate
	 *
	 */
	private Map<String, List<String>> getCrmOpportunitiesByFilter(String filter, List<String> oppIds, String startDate, String endDate) {

		Map<String, List<String>> crmMap = new HashMap<String, List<String>>();

		TermsBuilder termBuilder = null;

		switch (filter) {

		case CAMPAIGN:
			termBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
			.field(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW).size(0);
			break;

		case LEAD_SOURCE:
			termBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
			.field(CRMConstants.LEAD_SOURCE_RAW).size(0);
			break;

		case SALES_PERSON:
			termBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
			.field(CRMConstants.SALES_PERSON_RAW).size(0);
			break;

		default:
			break;
		}

		termBuilder.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_OPPORTUNITIES_AGGREGATION)
				.setFetchSource(CRMConstants.OPPORTUNITY_ID, null));

		BoolQueryBuilder boolQueryBuilder = MiriSearchUtils.createBoolQueryBuilder(CRMConstants.OPPORTUNITY_ID_RAW, oppIds, 1000);

		if(startDate != null && endDate !=null)
			boolQueryBuilder.must(QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));

		SearchResponse response = getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText()).setQuery(boolQueryBuilder)
				.addAggregation(termBuilder).execute().actionGet();

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> termsBuckets = terms.getBuckets();

		for (Terms.Bucket termBucket : termsBuckets) {

			String filterName = termBucket.getKey();

			if(StringUtils.isNotBlank(filterName)){

				if(CAMPAIGN.equals(filter)){
					CrmCampaign crmCampaign = crmCampaignService.getParentCrmCampaignByOpportunityPrimaryCampaignSource(filterName);
					if(crmCampaign!=null){
						filterName = crmCampaign.getCampaignName();
					}else
						continue;
				}

				List<String> list = new ArrayList<String>();

				InternalTopHits topHits = termBucket.getAggregations().get(SearchConstants.TOP_OPPORTUNITIES_AGGREGATION);

				SearchHit[] hits = topHits.getHits().getHits();

				for (SearchHit hit : hits) {
					list.add(hit.getId());
				}

				crmMap.put(filterName, list);
			}
		}

		return crmMap;
	}

	/**
	 * Process Opportunities to calculate Competitive Win Rate
	 * @param opportunityIds
	 * @param startDate TODO
	 * @param endDate TODO
	 * @param winLossData
	 * @author rammoole
	 */
	public WinLossData getCompetitiveWinRateForOpportunities(List<String> opportunityIds, long wonCount, String startDate, String endDate) {
		String[] lostStages = (String[]) appSalesStageContainer.getClosedLostMappedStages().toArray();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.LOST_AGGREGATION)
						.field(CRMConstants.OPPORTUNITY_STAGE_RAW).include(lostStages)
						.subAggregation(AggregationBuilders.sum(SearchConstants.LOST_OPPORTUNITIES_AMOUNT)
								.field(SearchConstants.AMOUNT)));
		//LOG.debug(searchRequestBuilder);
		SearchResponse searchResponse = searchRequestBuilder.execute().actionGet();
		double invoiceAmount = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, startDate, endDate);
		Object[] winLossObject = this.getWinLossDataFromAggregation(searchResponse.getAggregations());

		WinLossData winLossData = new WinLossData();
		winLossData.setWonCount(wonCount);
		winLossData.setWonAmount(invoiceAmount);
		winLossData.setLostCount((long) winLossObject[2]);
		winLossData.setLostAmount((double) winLossObject[3]);
		return winLossData;
	}

	/**
	 * Get Competitive WinRate for Overall
	 * @param opportunityIds
	 * @param startDate TODO
	 * @param endDate TODO
	 * @param winLossData
	 * @author rammoole
	 */
	public WinLossData getOverallCompetitiveWinRate(String startDate, String endDate) {
		Object[] wonData = getWonOpportunityCountAndRevenueClosedInDateRange(startDate, endDate);
		Object[] lostData = getLostOpportunityCountAndRevenueClosedInDateRange(startDate, endDate);

		WinLossData winLossData = new WinLossData();
		winLossData.setWonCount((long) wonData[0]);
		winLossData.setWonAmount((double) wonData[1]);
		winLossData.setLostCount((long) lostData[0]);
		winLossData.setLostAmount((double) lostData[1]);
		return winLossData;
	}

	/**
	 * Competitive Win rate for Marketing opportunities
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public WinLossData getMarketingCompetitiveWinRate(String startDate, String endDate){
		Object[] wonData = getWonpportunityCountAndRevenueClosedInDateRangeByType(startDate, endDate, true);
		Object[] lostData = getLostOpportunityCountAndRevenueClosedInDateRangeByType(startDate, endDate, true);

		WinLossData winLossData = new WinLossData();
		winLossData.setWonCount((long) wonData[0]);
		winLossData.setWonAmount((double) wonData[1]);
		winLossData.setLostCount((long) lostData[0]);
		winLossData.setLostAmount((double) lostData[1]);
		return winLossData;
	}

	/**
	 * Competitive winrate for Sales Opportunities
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public WinLossData getSalesCompetitiveWinRate(String startDate, String endDate){
		Object[] wonData = getWonpportunityCountAndRevenueClosedInDateRangeByType(startDate, endDate, false);
		Object[] lostData = getLostOpportunityCountAndRevenueClosedInDateRangeByType(startDate, endDate, false);

		WinLossData winLossData = new WinLossData();
		winLossData.setWonCount((long) wonData[0]);
		winLossData.setWonAmount((double) wonData[1]);
		winLossData.setLostCount((long) lostData[0]);
		winLossData.setLostAmount((double) lostData[1]);
		return winLossData;
	}

	/**
	 * Gets the Count and revenue of the Won Opprtunities closed in the date range
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Object[] getWonOpportunityCountAndRevenueClosedInDateRange(String startDate, String endDate){
		List<String> opportunityIds = new ArrayList<>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(startDate).to(endDate));
		}

		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));

		SearchRequestBuilder searchRequestBuilder = getTransportClient()
				.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(1000);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		while(true) {

			for (SearchHit hit : searchResponse.getHits().getHits()) {
				opportunityIds.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		double invoiceAmount = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, null, null);
		return new Object[] { (long)opportunityIds.size(), invoiceAmount};
	}

	/**
	 * Gets the Won Opportunities Count and revenue which are closed in date range
	 * @param startDate
	 * @param endDate
	 * @param isMarketing
	 * 		true if want marketing opportunities count and revenue
	 * @return
	 */
	public Object[] getWonpportunityCountAndRevenueClosedInDateRangeByType(String startDate, String endDate, boolean isMarketing){
		List<String> opportunityIds = new ArrayList<>();
		List<String> marketingCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(startDate).to(endDate));
		}
		if(isMarketing){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
		} else {
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
		}

		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));

		SearchRequestBuilder searchRequestBuilder = getTransportClient()
				.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(1000);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		while(true) {

			for (SearchHit hit : searchResponse.getHits().getHits()) {
				opportunityIds.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		double invoiceAmount = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, null, null);
		return new Object[] { (long)opportunityIds.size(), invoiceAmount};
	}

	/**Get Lost Opportunity count and amount which are closed in the date range
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Object[] getLostOpportunityCountAndRevenueClosedInDateRange(String startDate, String endDate) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(startDate).to(endDate));
		}
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedLostMappedStages()));

		SearchRequestBuilder searchRequestBuilder = getTransportClient()
				.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.sum(SearchConstants.LOST_OPPORTUNITIES_AMOUNT).field(SearchConstants.AMOUNT));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		Sum sum = searchResponse.getAggregations().get(SearchConstants.LOST_OPPORTUNITIES_AMOUNT);
		return new Object[] { searchResponse.getHits().getTotalHits(), sum.getValue()};
	}

	/**
	 * Get Lost Opportunities closed on the date range
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getLostOpportunitiesClosedInDateRange(final String startDate, final String endDate) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(startDate).to(endDate));
		}
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedLostMappedStages()));
		Client client = this.getTransportClient();
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(600)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> lostOpportunities = new ArrayList<>();
		do {
			for(SearchHit hit: searchResponse.getHits()) {
				lostOpportunities.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
		} while(searchResponse.getHits().getHits().length != 0);
		return lostOpportunities;
	}

	/**
	 * Gets the Lost Opportunities Count and amount closed in the date range
	 * @param startDate
	 * @param endDate
	 * @param isMarketing
	 * 		true if want marketing opportunities
	 * @return
	 */
	public Object[] getLostOpportunityCountAndRevenueClosedInDateRangeByType(String startDate, String endDate, boolean isMarketing){
		List<String> marketingCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(startDate).to(endDate));
		}
		if(isMarketing){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
		} else {
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
		}

		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedLostMappedStages()));

		SearchRequestBuilder searchRequestBuilder = getTransportClient()
				.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.DEFAULT)
				.addAggregation(AggregationBuilders.sum(SearchConstants.LOST_OPPORTUNITIES_AMOUNT).field(SearchConstants.AMOUNT));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		Sum sum = searchResponse.getAggregations().get(SearchConstants.LOST_OPPORTUNITIES_AMOUNT);
		return new Object[] { searchResponse.getHits().getTotalHits(), sum.getValue()};
	}

	/**
	 * Get All the Industries By Revenue with in the fiscal year
	 * @return
	 */
	public Map<String, Object> getAllIndustriesByRevenue() {
		String fiscalStartDate = this.accountStrategyService.getFiscalStartDateStr();
		String endDate = MiriDateUtils.parseDateToString(Calendar.getInstance(), MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return this.getAllIndustriesByRevenueWithInTimeFrame(fiscalStartDate, endDate);
	}

	/**
	 * Get All the Industries by Revenue with the Time Frame
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Object> getAllIndustriesByRevenueWithInTimeFrame(Calendar startDate, Calendar endDate) {
		String startDateStr = MiriDateUtils.parseDateToString(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		String endDateStr = MiriDateUtils.parseDateToString(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return getAllIndustriesByRevenueWithInTimeFrame(startDateStr, endDateStr);
	}

	/**
	 * Get All the Industries by Revenue with the Time Frame By OpportunityIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Object> getAllIndustriesByRevenueWithInTimeFrameByOpportunities(final String startDate,
			final String endDate, final List<String> opportunityIds) {
		TimerUtil timerUtil = new TimerUtil();

		Map<String, Object> topIndustriesMap = new HashMap<>();
		timerUtil.start();
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.addAggregation(AggregationBuilders.terms(SearchConstants.INDUSTRY_AGGREGATION).field(CRMConstants.ACCOUNT_INDUSTRY_RAW).size(0));

		if(CollectionUtils.isNotEmpty(opportunityIds)) {
			BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds));
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		}
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		Aggregations aggregations = searchResponse.getAggregations();
		Collection<Terms.Bucket> industryBuckets = null;
		if(aggregations != null){
			Terms  industryTerms = aggregations.get(SearchConstants.INDUSTRY_AGGREGATION);
			industryBuckets = industryTerms.getBuckets();
		}
		//ExecutorService executorService =  Executors.newFixedThreadPool(70);

		for(final Terms.Bucket industryBucket: industryBuckets) {
			
			if(StringUtils.isNotBlank(industryBucket.getKey())){

				// get accounts based on industry
				//List<String> accountIds = crmAccountService.getAccountIdsByIndustry(industryBucket.getKey());
	
				//LOG.info(accountIds.size());
				List<String> wonOpportunityIds = this.getMarketingInfluencedOpportunitiesForIndustry(opportunityIds, industryBucket.getKey(), null, null);
				//List<String> lostOpportunityIds = this.getOpportunitiesByAccountIdsAndStage(accountIds, OpportunityStagesEnum.CLOSED_LOST.getText(), null, null, opportunityIds);
				//LOG.info("Opportunity Ids :" + wonOpportunityIds.size());
				double revenueAmount = this.erpInvoiceService.getInvoiceAmountByOpportunityIds(wonOpportunityIds, startDate, endDate);
				//LOG.info("revenue Amount :" + revenueAmount);
				RevenueOpportunitiesData revenueOpportunitiesData = new RevenueOpportunitiesData();
				revenueOpportunitiesData.setOpportunityIds(wonOpportunityIds);
				revenueOpportunitiesData.setRevenueAmount(revenueAmount);
				//revenueOpportunitiesData.setLostOpportunityIds(lostOpportunityIds);
				topIndustriesMap.put(industryBucket.getKey(), revenueOpportunitiesData);
			}
		}

		return MiriSearchUtils.sortMapByObjectValue(topIndustriesMap);
	}

	/**
	 * Gets the Opportunities and revenue for Industry
	 * @param industry
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public InvoiceDataPojo getOpportunitiesAndRevenueForIndustry(String industry, String startDate, String endDate){
		List<String> wonOpportunityIds = this.getMarketingInfluencedOpportunitiesForIndustry(null, industry, null, null);
		return erpInvoiceService.getRevenueAndUniqueOpportunities(wonOpportunityIds, startDate, endDate);
	}

	/**
	 * Get All the Industries by Revenue with the Time Frame
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Object> getAllIndustriesByRevenueWithInTimeFrame(final String startDate, final String endDate) {
		return this.getAllIndustriesByRevenueWithInTimeFrameByOpportunities(startDate, endDate, null);
	}

	/**
	 * Get All accounts by opportunity
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public SearchRequestBuilder getAccountsByOpportunityQuery(final String startDate, final String endDate, final String stage) {
		return getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setSize(0)
				.setQuery(QueryBuilders.termsQuery(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)))
				/*FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate)))*/
				.addAggregation(AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
						.field(SearchConstants.ACCOUNT_ID_RAW).size(0)); // passing zero here to get all the terms
		//.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITY_HITS)
		//	.setSize(100000).setFetchSource(SearchConstants.OPPORTUNITY_ID, null))
	}

	/**
	 * Get Account opportunities query for specific opportunities
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public SearchRequestBuilder getAccountsByOpportunityQueryByOpportunities(String startDate, String endDate,
			List<String> opportunityIds) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate));
		return getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
						.field(SearchConstants.ACCOUNT_ID_RAW).size(0)); // passing zero here to get all the terms
		//.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITY_HITS)
		//	.setSize(100000).setFetchSource(SearchConstants.OPPORTUNITY_ID, null))
	}

	/**
	 * Get Opportunities By accounts with in time frame
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public SearchRequestBuilder getAccountsByOpportunityQuery(String startDate, String endDate) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate));
		return getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
						.field(SearchConstants.ACCOUNT_ID_RAW));
	}

	/**
	 * Get Competitive Win Rate for Industries
	 * @param industriesData
	 * @return
	 * @author rammoole
	 */
	public List<WinLossData> getWinLossDataForIndustry(List<Object> industriesData) {
		return this.erpOpportunityCompetitorService.getWinRateForCompetitors(industriesData, null, null);
	}

	/**
	 * Win Loss Data for other industries. here other industries mean by is there are more than 25 industries. rest of
	 * the industries other than top 25
	 * @param otherIndustriesData
	 * @return
	 * @author rammoole
	 */
	public WinLossData getWinLossDataForOtherIndustry(List<Object> otherIndustriesData) {
		return this.erpOpportunityCompetitorService.getWinRateForOtherCompetitors(otherIndustriesData, null, null);
	}

	/**
	 *
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, WinLossData> getWinRateForNewOrExistingDeals(Calendar startDate, Calendar endDate) {
		String startDateStr = MiriDateUtils.parseDateToString(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		String endDateStr = MiriDateUtils.parseDateToString(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return this.getWinRateForNewOrExistingDeals(startDateStr, endDateStr);
	}

	/**
	 * To get Win Rate for new or existing deals
	 * @param startDate
	 * @param endDate
	 * @author rammoole
	 */
	public Map<String, WinLossData> getWinRateForNewOrExistingDeals(String startDate, String endDate) {
		String[] wonStages = (String[]) appSalesStageContainer.getClosedWonMappedStages().toArray();
		String[] lostStages = (String[]) appSalesStageContainer.getClosedLostMappedStages().toArray();
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders
						.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_TYPE_AGGREGATION)
						.field(CRMConstants.OPPORTUNITY_TYPE_RAW)
						.subAggregation(AggregationBuilders.terms(SearchConstants.WON_AGGREGATION)
								.field(CRMConstants.OPPORTUNITY_STAGE_RAW)
								.include(wonStages))
						/*.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITY_HITS)
										.setSize(100000).setFetchSource(SearchConstants.OPPORTUNITY_ID, null)))*/
						.subAggregation(AggregationBuilders.terms(SearchConstants.LOST_AGGREGATION)
								.field(CRMConstants.OPPORTUNITY_STAGE_RAW)
								.include(lostStages).subAggregation(AggregationBuilders
										.sum(SearchConstants.LOST_OPPORTUNITIES_AMOUNT).field(SearchConstants.AMOUNT))));
		SearchResponse searchResponse = searchRequestBuilder.execute().actionGet();
		Terms newOrExsitingTerms = searchResponse.getAggregations().get(SearchConstants.OPPORTUNITY_TYPE_AGGREGATION);
		Collection<Terms.Bucket> opportunityTypeTerms = newOrExsitingTerms.getBuckets();

		Map<String, WinLossData> newOrExistingWinLossData = new LinkedHashMap<>();
		WinLossData winLossData;
		for (Terms.Bucket opportunityTypeTerm : opportunityTypeTerms) {
			Object[] winLossObject = this.getWinLossDataFromAggregation(opportunityTypeTerm.getAggregations());
			// write code to get term based opportunities
			winLossData = new WinLossData();
			winLossData.setWonCount((long) winLossObject[0]);
			winLossData.setWonAmount((double) winLossObject[1]);
			winLossData.setLostCount((long) winLossObject[2]);
			winLossData.setLostAmount((double) winLossObject[3]);
			newOrExistingWinLossData.put(opportunityTypeTerm.getKey(), winLossData);
		}
		return newOrExistingWinLossData;
	}

	/**
	 * Gets the opportunities by the industry. To get all Opportunities, Query for Win Stage Opportunities with
	 * in the provided time frame and aggregate by the industry
	 *
	 * @param startDate
	 * @param endDate
	 *
	 * @return Opportunities by the Industry.
	 */
	public Map<String, List<String>> getWonOpportunitesByIndustry(String startDate, String endDate){

		Map<String, List<String>> opportunitiesAndIndustries =  new HashMap<String, List<String>>();

		TermsFilterBuilder termsFilter =  FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW , appSalesStageContainer.getClosedWonMappedStages());

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter().must(termsFilter);

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.should(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}

		TermsBuilder parentAggregationBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_INDUSTRY_RAW).size(0);

		TermsBuilder childAggregationBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);

		SearchResponse opportunityRespose = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(parentAggregationBuilder.subAggregation(childAggregationBuilder)).execute().actionGet();

		Terms aggTerms = opportunityRespose.getAggregations().get(SearchConstants.TERMS_AGGREGATION);

		for (Bucket bucket : aggTerms.getBuckets()) {
			
			if(StringUtils.isNotBlank(bucket.getKey())){
				String industryName = bucket.getKey();

				List<String> opportunityList = new ArrayList<String>();

				Terms childAggTerms = bucket.getAggregations().get(SearchConstants.TERMS_AGGREGATION);

				for(Bucket childBucket : childAggTerms.getBuckets()){
					opportunityList.add(childBucket.getKey());
				}
			
				opportunitiesAndIndustries.put(industryName,opportunityList);
			}
		}

		return opportunitiesAndIndustries;
	}

	/**
	 * Get Marketing Influenced Opportunities for industry
	 * @param marketingOpportunities
	 * @param industryName
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getMarketingInfluencedOpportunitiesForIndustry(List<String> marketingOpportunities, String industryName, String startDate, String endDate){
		List<String> opportunityIds = new ArrayList<>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).to(endDate));
		}
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.ACCOUNT_INDUSTRY_RAW, industryName));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		if(CollectionUtils.isNotEmpty(marketingOpportunities)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, marketingOpportunities));
		}

		SearchResponse opportunityRespose = getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText()).setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000))
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.execute().actionGet();

		while(true) {
			for(SearchHit hit: opportunityRespose.getHits().getHits()) {
				opportunityIds.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			opportunityRespose = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(60000)).get();
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return opportunityIds;

	}

	/**
	 * Get Sales Generated Opportunities for industry
	 * @param marketingOpportunities
	 * @param industryName
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getSalesGeneratedOpportunitiesForIndustry(List<String> marketingOpportunities, String industryName, String startDate, String endDate){
		List<String> opportunityIds = new ArrayList<>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).to(endDate));
		}
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.ACCOUNT_INDUSTRY_RAW,industryName));
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_STAGE_RAW,OpportunityStagesEnum.CLOSED_WON.getText()));
		boolFilterBuilder.mustNot(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, marketingOpportunities));

		SearchResponse opportunityRespose = getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText()).setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000)).setSize(1000)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.execute().actionGet();

		while(true) {
			for(SearchHit hit: opportunityRespose.getHits().getHits()) {
				opportunityIds.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			opportunityRespose = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(60000)).get();
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return opportunityIds;
	}

	/**
	 * Returns a Map of Campaigns and the list of opportunities for each campaign
	 * @param startDate TODO
	 * @param endDate TODO
	 * @param overallCampaignIds
	 * @return
	 */

	public Map<String, List<String>> getOpportunitiesByCampaignAndOpportunities(List<String> opportunitiesList, String startDate, String endDate) {

		Map<String, List<String>> campOpportunityMap = new HashMap<String, List<String>>();

		BoolQueryBuilder termsQuery=MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW,
				opportunitiesList, 1000);
		termsQuery.must(QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));

		TopHitsBuilder tophits = AggregationBuilders.topHits(SearchConstants.TOTAL_HITS_AGGR).setSize(1000)
				.setFetchSource(SearchConstants.OPPORTUNITY_ID, null);

		TermsBuilder aggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field("primaryCampSource.raw").size(0).subAggregation(tophits);

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY).setQuery(termsQuery).addAggregation(aggr);
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		Terms aggTerms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);

		for (Bucket bucket : aggTerms.getBuckets()) {
			bucket.getKeyAsText();
			List<String> opportunitesListFoCampaign = new ArrayList<>();
			TopHits topHitsAggr = bucket.getAggregations().get(SearchConstants.TOTAL_HITS_AGGR);
			SearchHit[] opportunityHits = topHitsAggr.getHits().getHits();
			for (SearchHit searchhit : opportunityHits) {
				opportunitesListFoCampaign.add(searchhit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			campOpportunityMap.put(bucket.getKeyAsText().string(), opportunitesListFoCampaign);

		}

		return campOpportunityMap;

	}

	/**
	 *
	 * It is used to get list of the opportunity ID's from the ES Search Response
	 * @param searchResponse ES Search Response which contains Opportunity ID's
	 * @return {@link List} Contains all the ID's from ES search response
	 */
	public List<String> getOpportunityIds(SearchResponse searchResponse) {

		List<String> opportunities = new ArrayList<String>();
		for (SearchHit hit : searchResponse.getHits()) {
			opportunities.add(hit.field(SearchConstants.OPPORTUNITY_ID).getValue().toString());
		}
		return opportunities;
	}

	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_OPPORTUNITY.getText();
	}

	/**
	 * @param list
	 * @return
	 */
	public List<String> getCrmOpportunitiesByType(List<String> list,List<String> opprotunityTypes, String stage) {
		timeUtil.start();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(list)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, list));
		}

		if(CollectionUtils.isNotEmpty(opprotunityTypes)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_TYPE_RAW, opprotunityTypes));
		}

		if(StringUtils.isNotBlank(stage)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}

		List<String> newOpportunitiesList = new ArrayList<String>();
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
				.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN).setScroll(new TimeValue(6000)).setSize(1000)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));

		SearchResponse oppSearch = esQueryUtils.execute(searchRequestBuilder);

		do {
			for (SearchHit hit : oppSearch.getHits().getHits()) {
				newOpportunitiesList.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			oppSearch = this.getTransportClient().prepareSearchScroll(oppSearch.getScrollId()).setScroll(new TimeValue(60000)).execute().actionGet();
		} while(oppSearch.getHits().getHits().length != 0);

		timeUtil.end();
		LOG.debug("getCrmOpportunitiesByType ES"+timeUtil.timeTakenInMillis());
		return newOpportunitiesList;

	}

	/**
	 * Get Opportunities by Stage
	 * @param opportunityIds
	 * @param stage
	 * @return
	 */
	public List<String> getOpportunitiesByDateAndExceptStage(final List<String> opportunityIds, final String stage, final String startDate, final String endDate) {
		Client client = this.getTransportClient();
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType()).setSearchType(SearchType.SCAN).setScroll(new TimeValue(6000)).setSize(500);
		BoolFilterBuilder boolFilterBuilder = null;
		if (CollectionUtils.isNotEmpty(opportunityIds)) {
			boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));
		}

		if (StringUtils.isNotBlank(stage)) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}
		//LOG.info(opportunityIds);
		if(boolFilterBuilder == null) {
			searchRequestBuilder.setQuery(QueryBuilders.matchAllQuery());
		} else {
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		}
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunities = new ArrayList<>();
		if (searchResponse != null) {
			do {
				for (SearchHit hit : searchResponse.getHits()) {
					opportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				}
				searchResponse = esQueryUtils.execute(client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)));
			} while(searchResponse.getHits().getHits().length != 0);
		}
		//LOG.info("Opportunity Ids:" + opportunityIds.size());
		return opportunities;
	}

	/**
	 * Get Opportunities by Date, sales person and except the specified stage
	 * @param salesPersonName
	 * @param stage
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getOpportunitiesByDateAndSalesPersonNameAndExceptStage(final String salesPersonName, final String stage, final String startDate, final String endDate) {
		Client client = this.getTransportClient();
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType()).setSearchType(SearchType.SCAN).setScroll(new TimeValue(6000)).setSize(500);
		BoolFilterBuilder boolFilterBuilder = null;
		if (StringUtils.isNotBlank(salesPersonName)) {
			boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.SALES_PERSON_RAW, salesPersonName));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));
		}

		if (StringUtils.isNotBlank(stage)) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}
		//LOG.info(opportunityIds);
		if(boolFilterBuilder == null) {
			searchRequestBuilder.setQuery(QueryBuilders.matchAllQuery());
		} else {
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		}
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunities = new ArrayList<>();
		if (searchResponse != null) {
			do {
				for (SearchHit hit : searchResponse.getHits()) {
					opportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				}
				searchResponse = esQueryUtils.execute(client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)));
			} while(searchResponse.getHits().getHits().length != 0);
		}
		return opportunities;
	}
	
	/**
	 * @param crmCampaign
	 * @param crmLead
	 * @return
	 */
	public List<CrmOpportunity> getCRMOpportunitiesByCampaignAndLead(CrmCampaign crmCampaign, CrmLead crmLead) {

		List<CrmOpportunity> crmOpportunities = new ArrayList<>();

		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery()
				.must(QueryBuilders.termQuery("primaryCampSource.raw", crmCampaign.getCampaignId()));

		if (null != crmLead) {
			boolQueryBuilder.must(QueryBuilders.termQuery("primaryCampSource.raw", crmLead.getCampaignId()))
					.must(QueryBuilders.termQuery("leadSource.raw", crmLead.getLeadSource()))
					.must(QueryBuilders.termQuery("owner.raw", crmLead.getLeadOwner()))
					.must(QueryBuilders.termQuery("accountId.raw", crmLead.getAccountId()));

			boolQueryBuilder.must(
					QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CREATED_DATE).gte(crmLead.getCreatedDate()));
			boolQueryBuilder.must(
					QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CREATED_DATE).gte(crmLead.getCreatedDate()));
		}

		SearchResponse opportunityRespose = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(boolQueryBuilder).execute().actionGet();

		if (opportunityRespose == null || opportunityRespose.getHits().getTotalHits() == 0) {
			if (null != crmLead) {
				boolQueryBuilder = QueryBuilders.boolQuery()
						.must(QueryBuilders.termQuery("primaryCampSource.raw", crmCampaign.getCampaignId()));
				boolQueryBuilder.must(QueryBuilders.termQuery("primaryCampSource.raw", crmLead.getCampaignId()))
						.must(QueryBuilders.termQuery("accountId.raw", crmLead.getAccountId()))
						.should(QueryBuilders.termQuery("leadSource.raw", crmLead.getLeadSource()))
						.should(QueryBuilders.termQuery("owner.raw", crmLead.getLeadOwner()));

				boolQueryBuilder.must(
						QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CREATED_DATE).gte(crmLead.getCreatedDate()));
				boolQueryBuilder.must(
						QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CREATED_DATE).gte(crmLead.getCreatedDate()));
			}

			opportunityRespose = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
					.setQuery(boolQueryBuilder).execute().actionGet();
		}
		SearchHits oppSearchHits = opportunityRespose.getHits();
		for (SearchHit hit : oppSearchHits) {
			crmOpportunities
					.add((CrmOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
		}
		return crmOpportunities;
	}

	/**
	 * Get CRM Opportunities by lead data such as company name and primary campaign source
	 * @param mapLead
	 * @return
	 */
	public List<String> getCrmOpporutnityByLeads(final List<String> campaignIds, final List<String> companyNames) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		Set<String> uniqueCompanyName = new HashSet<>(companyNames);
		Set<String> uniqueCampaignId = new HashSet<>(campaignIds);
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_COMPANY_NAME_RAW, uniqueCompanyName));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, uniqueCampaignId));
		//boolQueryBuilder.should(QueryBuilders.termQuery(CRMConstants.OPPORTUNITY_OWNER_RAW, mapLead.getLeadOwner()));
		//boolQueryBuilder.should(QueryBuilders.termQuery(CRMConstants.LEAD_SOURCE_RAW, mapLead.getLeadSource()));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSize(700)
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunityIds = new ArrayList<>();
		do {
			for (SearchHit hit : searchResponse.getHits().getHits()) {
				opportunityIds.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(60000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
		} while(searchResponse.getHits().getHits().length != 0);
		LOG.info("valid Opportunities:" + opportunityIds.size());
		return opportunityIds;
	}

	/**
	 * get CRM opportunity by leads
	 * @param mapLeadCompanyName
	 * @param mapLeadCampaignId
	 * @param industry
	 * @param companyId
	 * @param salesPerson
	 * @return
	 */
	public List<String> getValidLeadsData(final List<String> mapLeadCampaignId, final List<String> mapLeadCompanyName, final List<String> leadSource, final List<MapLead> mapLeads,
			List<String> companyId, List<String> industry, List<String> salesPerson) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		Set<String> uniqueCompanyName = new HashSet<>(mapLeadCompanyName);
		Set<String> uniqueCampaignId = new HashSet<>(mapLeadCampaignId);
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_COMPANY_NAME_RAW, uniqueCompanyName));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, uniqueCampaignId));
		boolFilterBuilder.must((FilterBuilders.termsFilter(CRMConstants.LEAD_SOURCE_RAW, leadSource)));
		boolFilterBuilder.must((FilterBuilders.termsFilter(CRMConstants.ACCOUNT_INDUSTRY_RAW, industry)));
		boolFilterBuilder.must((FilterBuilders.termsFilter(CRMConstants.ACCOUNT_ID_RAW, companyId)));
		boolFilterBuilder.must((FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_OWNER_RAW, salesPerson)));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION).field(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW).size(0)
						.subAggregation(AggregationBuilders.terms("companyNameAggregation").field(CRMConstants.OPPORTUNITY_COMPANY_NAME_RAW).size(0)
						.subAggregation(AggregationBuilders.terms("leeadSourceAggregation").field(CRMConstants.LEAD_SOURCE_RAW).size(0))));

		//LOG.info(searchRequestBuilder);
		long maxHits = 0l;
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Terms campaignTerms = searchResponse.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
		Collection<Terms.Bucket> campaignBuckets = campaignTerms.getBuckets();
		for(Terms.Bucket campaignBucket: campaignBuckets) {
			Terms accountNameTerms = campaignBucket.getAggregations().get("companyNameAggregation");
			if(accountNameTerms != null) {
				Collection<Terms.Bucket> accountNameBuckets = accountNameTerms.getBuckets();
				for(Terms.Bucket accountNameBucket: accountNameBuckets) {
					Terms leadSourceTerms = accountNameBucket.getAggregations().get("leeadSourceAggregation");
					if(leadSourceTerms != null) {
						Collection<Terms.Bucket> leadSourceBuckets = leadSourceTerms.getBuckets();
						for(Terms.Bucket leadSourceBucket: leadSourceBuckets) {
							maxHits = leadSourceBucket.getDocCount();
							break;
						}
					}
					break;
				}
			}
			break;
		}
		List<String> opportunityids = new ArrayList<>();
		searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION).field(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW).size(0)
						.subAggregation(AggregationBuilders.terms("companyNameAggregation").field(CRMConstants.OPPORTUNITY_COMPANY_NAME_RAW).size(0)
						.subAggregation(AggregationBuilders.terms("leeadSourceAggregation").field(CRMConstants.LEAD_SOURCE_RAW).size(0)
						.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_HITS_AGGREGATION).setSize((int) maxHits)))));
		//LOG.info("campaignIdAndAccountName :" + campaignIdAndAccountName.size());
		//LOG.info("total Valid Leads :" + mapLeads.size());

		//LOG.info("Query : "+ searchRequestBuilder);
		searchResponse = esQueryUtils.execute(searchRequestBuilder);
		campaignTerms = searchResponse.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
		campaignBuckets = campaignTerms.getBuckets();
		opportunityids = new ArrayList<>();
		for(Terms.Bucket campaignBucket: campaignBuckets) {
			Terms accountNameTerms = campaignBucket.getAggregations().get("companyNameAggregation");
			if(accountNameTerms != null) {
				Collection<Terms.Bucket> accountNameBuckets = accountNameTerms.getBuckets();
				for(Terms.Bucket accountNameBucket: accountNameBuckets) {
					Terms leadSourceTerms = accountNameBucket.getAggregations().get("leeadSourceAggregation");
					if(leadSourceTerms != null) {
						Collection<Terms.Bucket> leadSourceBuckets = leadSourceTerms.getBuckets();
						for(Terms.Bucket leadSourceBucket: leadSourceBuckets) {
							TopHits topHits = leadSourceBucket.getAggregations().get(SearchConstants.TOP_HITS_AGGREGATION);
							for(SearchHit hit: topHits.getHits()) {
								opportunityids.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
							}
						}
					}

				}
			}
		}
		return opportunityids;
	}

	/**
	 * This method is used to construct large open opportunities map data
	 * @param response ES {@link SearchResponse}
	 *
	 * @return
	 */
	public Map<String, Object> getOpenOpprtunitiesDataMapFromAggregation(Terms terms, String field) {
		Map<String, Object> largeOpenOpportunities = new HashMap<>();
		Collection<Terms.Bucket> buckets = terms.getBuckets();

		for (Terms.Bucket bucket : buckets) {
			TopHits topHits = bucket.getAggregations().get(SearchConstants.TOP_HITS_AGGREGATION);
			for (SearchHit hit : topHits.getHits()) {
				Map<String, String> opportunityValues = new HashMap<String, String>();
				opportunityValues.put(SearchConstants.NAME,
						hit.getSource().get(field).toString());
				opportunityValues.put(CRMConstants.OPPORTUNITY_AMOUNT,
						hit.getSource().get(CRMConstants.OPPORTUNITY_AMOUNT).toString());
				opportunityValues.put(CRMConstants.PROBABILITY_PERC,
						hit.getSource().get(CRMConstants.PROBABILITY_PERC).toString());
				//				opportunityValues.put(CRMConstants.OPPORTUNITY_COMPANY_NAME,
				//						hit.getSource().get(CRMConstants.OPPORTUNITY_COMPANY_NAME).toString());
				//opportunityValues.put(SearchConstants.STAGE, hit.getSource().get(CRMConstants.OPPORTUNITY_STAGE).toString());
				if (null != hit.getSource().get(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE)) {
					String campaignName = crmCampaignService.getCampaignNamebyPrimaryCampaignSource(hit.getSource().get(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE).toString());
					opportunityValues.put(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE,campaignName);
					if(StringUtils.equals(field, CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE)){
						opportunityValues.put(SearchConstants.NAME, campaignName);
					}
				} else {
					opportunityValues.put(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE, SearchConstants.NOT_APPLICABLE);
				}
				largeOpenOpportunities.put(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString(),
						opportunityValues);
			}
		}
		return largeOpenOpportunities;
	}

	/**
	 * This method is used get range query for probability
	 * @param greaterThan greater than value for probability
	 * @return {@link RangeQueryBuilder}
	 */
	public RangeQueryBuilder getProbabilityRangeQuery(int greaterThan) {
		return QueryBuilders.rangeQuery(SearchConstants.PROBABILITY_PERC).gte(greaterThan);
	}

	/**
	 * This method is used to get the Large open Opportunities By Parent Campaign
	 *
	 * @param subCampaigns {@link Set} specify the sub campaigns in market or sales campaign
	 * @param startDate TODO
	 * @param endDate TODO
	 *
	 * @return {@link Map} Returns the map containing the opportunity ID's as key and the opportunity details as the
	 * values in string array
	 *
	 */
	public Map<String, Object> getMarketingInfluencedLargeOpenOpportunitiesForSubCampaigns(Set<String> subCampaigns, String startDate, String endDate) {
		QueryBuilder range = QueryBuilders.rangeQuery(SearchConstants.CREATED_ON).gte(startDate).lte(endDate);

		List<String> stageToExclude = new ArrayList<>();
		stageToExclude.addAll(appSalesStageContainer.getClosedWonMappedStages());
		stageToExclude.addAll(appSalesStageContainer.getClosedLostMappedStages());
		stageToExclude.add(OpportunityStagesEnum.STAGE_EMPTY.getText());

		TermsQueryBuilder stageTerms = QueryBuilders.termsQuery(CRMConstants.OPPORTUNITY_STAGE_RAW, stageToExclude);
		BoolQueryBuilderRequest queryBuilderRequest = new BoolQueryBuilderRequest()
				.fieldName(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW)
				.fieldValues(new ArrayList<String>(subCampaigns))
				.type(BoolType.MUST);
		BoolQueryBuilder boolQueryBuilder = MiriSearchUtils.createBoolQueryBuilder(queryBuilderRequest);
		boolQueryBuilder.must(range);
		boolQueryBuilder.mustNot(stageTerms);
		SortBuilder sortBuilder = SortBuilders.fieldSort(CRMConstants.OPPORTUNITY_AMOUNT).order(SortOrder.DESC);

		AbstractAggregationBuilder subaggregation = AggregationBuilders.topHits(SearchConstants.TOP_HITS_AGGREGATION)
				.setSize(1).addSort(sortBuilder);

		AbstractAggregationBuilder aggragation = AggregationBuilders.terms(SearchConstants.SALES_PERSON_AGGREGATION)
				.field(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW)
				.subAggregation(subaggregation);

		SearchRequestBuilder builder =  getTransportClient()
				.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(boolQueryBuilder)
				.addAggregation(aggragation)
				.setSize(0);

		SearchResponse searchResponse = esQueryUtils.execute(builder);
		Terms terms = searchResponse.getAggregations().get(SearchConstants.SALES_PERSON_AGGREGATION);
		return getOpenOpprtunitiesDataMapFromAggregation(terms, CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE);
	}

	/**
	 * Return All CRM opportunities for the given account id.
	 *
	 * @param accountId
	 */
	public List<ESEntity> getCRMOpportunitiesByCRMAccountId(final String accountId) {
		return esQueryUtils.getMultipleDocsByFKId(getDocumentType(), getIndex(), "accountId.raw", accountId);
	}

	/**
	 * Gets CRM Opportunities by Sales Person Id.
	 */
	public List<ESEntity> getCrmOpportunitiesBySalesPersonId(final String salesPersonId) {
		return esQueryUtils.getMultipleDocsByFKId(getDocumentType(), getIndex(),"owner.raw", salesPersonId);
	}

	/**
	 * Returns CRM opportunity associated with the given order number.
	 *
	 * @param orderNumber
	 */
	public CrmOpportunity getCrmOpportunityByOrderNumber(String orderNumber) {
		return (CrmOpportunity) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), "orderNumber.raw", orderNumber);
	}

	/**
	 * Get Opportunities by Stage
	 * @param opportunityIds
	 * @param stage
	 * @return List<CrmOpportunity>
	 */
	public List<CrmOpportunity> getOpportunityObjectsByStage(final List<String> opportunityIds, final String stage) {
		Client client = this.getTransportClient();
		SearchRequestBuilder searchRequest = client.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setSize(opportunityIds.size());
		if(opportunityIds != null) {
			searchRequest.setQuery(QueryBuilders.termsQuery(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		}
		if(StringUtils.isNotBlank(stage)) {
			searchRequest.setPostFilter(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}
		SearchResponse scrollResponse = searchRequest.execute().actionGet();
		List<CrmOpportunity> opportunities = new ArrayList<>();
		for(SearchHit hit: scrollResponse.getHits()) {
			//LOG.debug("Each Opportunity" + hit.getSource());
			opportunities.add((CrmOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
		}
		return opportunities;
	}

	/**
	 * Get Opportunities by sales person
	 * @param salesPersonName
	 * @return
	 */
	public List<String> getOpportunityIdsBySalesPerson(String salesPersonName, String startDate, String endDate, String stage) {
		Client client = this.getTransportClient();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termFilter(SearchConstants.OWNER_RAW, salesPersonName));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate));
		if(StringUtils.isNotBlank(stage)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(60000))
				.setSize(500)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse scrollResponse = esQueryUtils.execute(searchRequestBuilder);

		List<String> crmOpportunityList = new ArrayList<>();
		//Scroll until no hits are returned
		while (true) {
			for (SearchHit hit : scrollResponse.getHits().getHits()) {
				if(hit.getSource().get(SearchConstants.OPPORTUNITY_ID) != null && StringUtils.isNotBlank(String.valueOf(hit.getSource().get(SearchConstants.OPPORTUNITY_ID)))) {
					crmOpportunityList.add(String.valueOf(hit.getSource().get(SearchConstants.OPPORTUNITY_ID)));
				}
			}
			scrollResponse = client.prepareSearchScroll(scrollResponse.getScrollId()).setScroll(new TimeValue(60000)).execute().actionGet();
			//Break condition: No hits are returned
			if (scrollResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return crmOpportunityList;
	}
	
	/**
	 * Get MI  Opportunities by sales person
	 * @param salesPersonName
	 * @return
	 */
	public List<String> getMarketingInfluencedOpportunitiesBySalesPerson(String salesPersonName, String startDate, String endDate, String stage) {
		Client client = this.getTransportClient();
		
		BoolFilterBuilder boolFilterBuilder=FilterBuilders.boolFilter();
	
		List<String> subCamapigns =  mapCampaignService.getMarketingSubCampaigns();
		if(CollectionUtils.isNotEmpty(subCamapigns)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapigns));
		}
		if(StringUtils.isNotBlank(salesPersonName)) {
			boolFilterBuilder.must(FilterBuilders.termFilter(SearchConstants.OWNER_RAW, salesPersonName));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate));
		}
		if(StringUtils.isNotBlank(stage)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(60000))
				.setSize(500);
		
		List<String> crmOpportunityList = new ArrayList<>();

		if (boolFilterBuilder.toString().contains("must")) {
			searchRequestBuilder
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		}

			SearchResponse scrollResponse = esQueryUtils.execute(searchRequestBuilder);

			// Scroll until no hits are returned
			while (true) {
				for (SearchHit hit : scrollResponse.getHits().getHits()) {
					if (hit.getSource().get(SearchConstants.OPPORTUNITY_ID) != null && StringUtils
							.isNotBlank(String.valueOf(hit.getSource().get(SearchConstants.OPPORTUNITY_ID)))) {
						crmOpportunityList.add(String.valueOf(hit.getSource().get(SearchConstants.OPPORTUNITY_ID)));
					}
				}
				scrollResponse = client.prepareSearchScroll(scrollResponse.getScrollId())
						.setScroll(new TimeValue(60000)).execute().actionGet();
				// Break condition: No hits are returned
				if (scrollResponse.getHits().getHits().length == 0) {
					break;
				}
			}
		return crmOpportunityList;
	}

	
	

	@Deprecated
	/**
	 * Get Opportunities by sales person
	 * @param salesPersonName
	 * @return
	 */
	public List<String> getMarketingOrSalesOpportunitiesBySalesPersonByopportunities(String salesPersonName, String startDate, String endDate, List<String> opportunities) {
		Client client = this.getTransportClient();

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(!CollectionUtils.isEmpty(opportunities)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));
		boolFilterBuilder.must(FilterBuilders.termFilter(SearchConstants.OWNER_RAW, salesPersonName));
		SearchResponse scrollResponse = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(60000))
				.setSize(500)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.get();

		List<String> crmOpportunityList = new ArrayList<>();
		//Scroll until no hits are returned
		while (true) {
			for (SearchHit hit : scrollResponse.getHits().getHits()) {
				crmOpportunityList.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			scrollResponse = client.prepareSearchScroll(scrollResponse.getScrollId()).setScroll(new TimeValue(60000)).execute().actionGet();
			//Break condition: No hits are returned
			if (scrollResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return crmOpportunityList;
	}

	/**
	 * Get Opportunities by competitor name. This method handles the competitors with comma separated case as well.
	 * @param competitorName
	 * @return
	 */
	public List<CrmOpportunity> getOpportunitiesByCompetitorName(final String competitorName, final String startDate, final String endDate, final String stage) {
		List<CrmOpportunity> opportunities = new ArrayList<>();
		if(!StringUtils.isEmpty(competitorName) && competitorName.contains(",")) {
			String[] competitorNames = competitorName.split(",");
			for(String competitor: competitorNames) {
				opportunities.addAll(this.erpOpportunityCompetitorService.getOpportunityObjectsByCompetitorAndStage(competitor, startDate, endDate, stage));
			}
		} else {
			opportunities.addAll(this.erpOpportunityCompetitorService.getOpportunityObjectsByCompetitorAndStage(competitorName, startDate, endDate, stage));
		}
		return opportunities;
	}

	/**
	 * Get Opportunities by competitor name. This method handles the competitors with comma separated case as well.
	 * @param competitorName
	 * @return
	 */
	public List<String> getOpportunitiesByCompetitor(final String competitorName, final String startDate, final String endDate, final String stage) {
		List<String> opportunities = new ArrayList<>();
		if(!StringUtils.isEmpty(competitorName) && competitorName.contains(",")) {
			String[] competitorNames = competitorName.split(",");
			for(String competitor: competitorNames) {
				opportunities.addAll(this.erpOpportunityCompetitorService.getOpportunityObjectsByCompetitorAndStageAndDate(competitor, startDate, endDate, stage));
			}
		} else {
			opportunities.addAll(this.erpOpportunityCompetitorService.getOpportunityObjectsByCompetitorAndStageAndDate(competitorName, startDate, endDate, stage));
		}
		return opportunities;
	}

	/**
	 * Get Opportunity Ids by Competitor
	 * @param competitorName
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getOpportunityIdsByCompetitorName(final String competitorName, final String startDate, final String endDate) {
		List<CrmOpportunity> opportunityObjects = this.getOpportunitiesByCompetitorName(competitorName, startDate, endDate, null);
		List<String> opportunityIds = new ArrayList<>();
		for(CrmOpportunity crmOpportunity: opportunityObjects) {
			opportunityIds.add(crmOpportunity.getOpportunityId());
		}
		return opportunityIds;
	}

	/**
	 * Get Opportunities by competitor name and Opportunity created date with in specified dates
	 * @param competitorName
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getOpportunityIdsByCompetitor(final String competitorName, final String startDate, final String endDate) {
		List<String> opportunityIds = this.getOpportunitiesByCompetitor(competitorName, startDate, endDate, null);
		return opportunityIds;
	}

	/**
	 * Get average time of opportunities
	 * @param crmOpportunities
	 * @return
	 */
	public double getAvgTimeOfOpportunities(List<CrmOpportunity> crmOpportunities) {
		List<String> opportunityIds = new ArrayList<>();
		if(CollectionUtils.isNotEmpty(crmOpportunities)) {
			// Calculate average opportunity creation date
			for(CrmOpportunity crmOpportunity: crmOpportunities) {
				opportunityIds.add(crmOpportunity.getOpportunityId());
			}
		}
		return this.getAvgCreationTimeOfOpportunityIds(opportunityIds);
	}

	/**
	 * Average Time of opportunities
	 * @param crmOpportunityIds
	 * @return
	 */
	public double getAvgCreationTimeOfOpportunityIds(List<String> crmOpportunityIds) {
		if(CollectionUtils.isNotEmpty(crmOpportunityIds)) {
			BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, crmOpportunityIds));
			SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
					.setTypes(getDocumentType())
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
					.setSize(0)
					.addAggregation(AggregationBuilders.avg(SearchConstants.AVG_AGGREGATION).field(SearchConstants.CREATED_ON));
			SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
			return (long) AggregationUtil.getAggregationValue(searchResponse, SearchConstants.AVG_AGGREGATION, SearchConstants.AVG_AGGREGATION_TYPE);
		} else {
			return 0;
		}
	}

	/**
	 * Average Time of opportunities
	 * @param crmOpportunityIds
	 * @return
	 */
	public double getAvgClosedDateOfOpportunityIds(List<String> crmOpportunityIds) {
		if(CollectionUtils.isNotEmpty(crmOpportunityIds)) {
			BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, crmOpportunityIds));
			SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
					.setTypes(getDocumentType())
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
					.setSize(0)
					.addAggregation(AggregationBuilders.avg(SearchConstants.AVG_AGGREGATION).field(CRMConstants.OPPORTUNITY_CLOSED_DATE));
			SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
			return (long) AggregationUtil.getAggregationValue(searchResponse, SearchConstants.AVG_AGGREGATION, SearchConstants.AVG_AGGREGATION_TYPE);
		} else {
			return 0;
		}
	}

	/**
	 * @param opportunityIds
	 * @return
	 */
	public List<String> getOpportunityNamesByIds(List<String> opportunityIds) {
		SearchResponse searchResponse = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.termsQuery(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds))
				.setFetchSource(SearchConstants.OPPORTUNITY_NAME, null)
				.get();
		List<String> opportunityNames = new ArrayList<>();
		for(SearchHit hit: searchResponse.getHits()) {
			opportunityNames.add(hit.getSource().get(SearchConstants.OPPORTUNITY_NAME).toString());
		}
		return opportunityNames;
	}

	/**
	 * Get Opportunity Objects by Ids
	 * @param opportunityIds
	 * @return
	 */
	public List<CrmOpportunity> getOpportunityObjectsByIds(Collection<String> opportunityIds) {
		SearchRequestBuilder srb = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
						FilterBuilders.boolFilter().must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW,
								opportunityIds))));
		if(!CollectionUtils.isEmpty(opportunityIds)) {
			srb.setSize(opportunityIds.size());
		}
		SearchResponse searchResponse = srb.get();
		List<CrmOpportunity> opportunityObjects = new ArrayList<>();
		for(SearchHit hit: searchResponse.getHits()) {
			opportunityObjects.add((CrmOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
		}
		return opportunityObjects;
	}


	/**
	 * Get all the opportunity Names by Customer name / Account Name
	 * @param customerName
	 * @return
	 */
	public Map<String, Long> getOpportunityNamesByAccountId(List<String> accountIds, final String startDate, final String endDate) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(!CollectionUtils.isEmpty(accountIds)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_ID_RAW, accountIds));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.WORD_CLOUD_OPP_PAIN_POINTS).field(CRMConstants.OPPORTUNITY_PAIN_POINTS/*SearchConstants.OPPORTUNITY_NAME*/).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS))
				.addAggregation(AggregationBuilders.terms(SearchConstants.WORD_CLOUD_OPP_NAME).field(CRMConstants.OPPORTUNITY_NAME/*SearchConstants.OPPORTUNITY_NAME*/).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		return MiriSearchUtils.getWordCloudAggregation(searchResponse);
	}

	/**
	 * Get All the opportunity Names by Industry
	 * @param key
	 * @return
	 */
	public Map<String, Long> getOpportunityNamesByIndustry(final Set<String> industryName, final String startDate, final String endDate) {

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(!CollectionUtils.isEmpty(industryName)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_INDUSTRY_RAW, industryName));
		}
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.WORD_CLOUD_OPP_PAIN_POINTS).field(CRMConstants.OPPORTUNITY_PAIN_POINTS/*SearchConstants.OPPORTUNITY_NAME*/).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS))
				.addAggregation(AggregationBuilders.terms(SearchConstants.WORD_CLOUD_OPP_NAME).field(CRMConstants.OPPORTUNITY_NAME/*SearchConstants.OPPORTUNITY_NAME*/).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		return MiriSearchUtils.getWordCloudAggregation(searchResponse);
	}

	/**
	 * Get Opportunity Names by Sales person with in time frame
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Long> getOpprtunityNamesAggregationBySalesPerson(Set<String> salesPersonNames, String startDate, String endDate) {
		Client client = this.getTransportClient();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OWNER_RAW, salesPersonNames));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate));
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.WORD_CLOUD_OPP_PAIN_POINTS).field(CRMConstants.OPPORTUNITY_PAIN_POINTS).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS))
				.addAggregation(AggregationBuilders.terms(SearchConstants.WORD_CLOUD_OPP_NAME).field(CRMConstants.OPPORTUNITY_NAME).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS));
		SearchResponse scrollResponse = esQueryUtils.execute(searchRequestBuilder);
		return MiriSearchUtils.getWordCloudAggregation(scrollResponse);
	}

	/**
	 * Get Won Marketing Influenced Opportunities
	 * @return
	 */
	/*public Map<String, List<String>> getTaggedIndustryAndSalesGeneratedOpportunities() {

		List<String> mapOpportunities = mapOpportunityService.getMapOpportunities();

		MatchQueryBuilder matchQueryBuilder = QueryBuilders.matchQuery(SearchConstants.TAGS,
				SearchConstants.STAGE);

		TermsQueryBuilder campaignIdTerm = QueryBuilders.termsQuery(SearchConstants.OPPORTUNITY_ID_RAW,
				mapOpportunities);

		QueryBuilder queryBuilder = QueryBuilders.boolQuery().must(matchQueryBuilder).mustNot(campaignIdTerm);

		Map<String, List<String>> salesGeneratedOptys = getOpportunitesAndIndustry(queryBuilder);

		LOG.info("getWonSalesGeneratedOpportunitesAndIndustry" + salesGeneratedOptys);
		return salesGeneratedOptys;
	}*/

	/**
	 * Get Won Marketing Influenced Opportunities
	 * @return
	 */
	/*public Map<String, List<String>> getTaggedIndustryAndMarketingInfluencedOpportunities() {

		List<String> mapOpportunities = mapOpportunityService.getMapOpportunities();

		MatchQueryBuilder matchQueryBuilder = QueryBuilders.matchQuery(SearchConstants.TAGS,
				SearchConstants.STAGE);

		TermsQueryBuilder campaignIdTerm = QueryBuilders.termsQuery(SearchConstants.OPPORTUNITY_ID_RAW,
				mapOpportunities);

		QueryBuilder queryBuilder = QueryBuilders.boolQuery().must(matchQueryBuilder).must(campaignIdTerm);

		Map<String, List<String>> marketingInfluencedOptys = getOpportunitesAndIndustry(queryBuilder);

		return marketingInfluencedOptys;
	}*/



	/**
	 * Get Lost Opportunities By Account ID
	 * @param accountId
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public List<String> getLostOpportunitiesByAccountId(String accountId, String startDate, String endDate) {
		return this.getOpportunitiesByAccountIdsAndStage(Arrays.asList(accountId), OpportunityStagesEnum.CLOSED_LOST.getText(),
				startDate, endDate, null);
	}

	/**
	 * Get Lost Opportunities By Account ID
	 * @param accountId
	 * @return
	 * @author rammoole
	 */
	public List<String> getLostOpportunitiesByAccountIds(List<String> accountIds, final String startDate, final String endDate) {
		return this.getOpportunitiesByAccountIdsAndStage(accountIds, OpportunityStagesEnum.CLOSED_LOST.getText(),
				startDate, endDate, null);
	}

	/**
	 * Get Won Opportunities By Account ID
	 * @param accountId
	 * @return
	 */
	public List<String> getWonOpportunitiesByAccountId(final String accountId, final String startDate, final String endDate) {
		return this.getOpportunitiesByAccountIdsAndStage(Arrays.asList(accountId),
				OpportunityStagesEnum.CLOSED_WON.getText(), startDate, endDate, null);
	}

	/**
	 * Get all the lost opportunities by account ids
	 * @param accountIds
	 * @param opportunities
	 * @return
	 * @author rammoole
	 */
	public List<String> getOpportunitiesByAccountIdsAndStage(List<String> accountIds, final String stage,
			final String startDate, final String endDate, List<String> opportunities) {
		Client client = this.getTransportClient();
		// Get all the lost opportunities
		BoolFilterBuilder boolFilterBuilder = null;
		if(CollectionUtils.isNotEmpty(accountIds)) {
			boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ACCOUNT_ID_RAW, accountIds));
		}
		if(CollectionUtils.isNotEmpty(opportunities)) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		if(StringUtils.isNotBlank(stage)) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));
		}

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(1000)
				.setFetchSource(CRMConstants.OPPORTUNITY_ID, null);
		
		if(boolFilterBuilder != null) {
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		} else {
			searchRequestBuilder.setQuery(QueryBuilders.matchAllQuery());
		}

		//LOG.debug("Search Request Builder :" + searchRequestBuilder);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunityIds = null;
		if(searchResponse != null) {
			opportunityIds = new ArrayList<>();
			while(true) {
				for(SearchHit searchHit: searchResponse.getHits().getHits()) {
					opportunityIds.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				}
				SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(searchResponse.getScrollId())
						.setScroll(new TimeValue(6000));
				searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
				if(searchResponse.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		return opportunityIds;
	}

	/**
	 * Get all the lost opportunities by industry
	 * @param industryName
	 * @return
	 */
	public List<String> getLostOpportunitiesByIndustry(String industryName, final String startDate, final String endDate) {
		Client client = this.getTransportClient();
		List<String> opportunityIds = new ArrayList<>();
		try {
			SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(ElasticSearchEnums.CRM_ACCOUNT.getText())
					.setQuery(QueryBuilders.termQuery(CRMConstants.ACCOUNT_INDUSTRY_RAW, industryName))
					.setFetchSource(CRMConstants.ACCOUNT_ID, null).setSearchType(SearchType.SCAN)
					.setSize(1000).setScroll(new TimeValue(6000));
			SearchResponse searchResponse = searchRequestBuilder.get();
			List<String> accountIds = new ArrayList<>();
			if(searchResponse != null) {
				while(true) {
					for(SearchHit searchHit: searchResponse.getHits().getHits()) {
						accountIds.add(searchHit.getSource().get(CRMConstants.ACCOUNT_ID).toString());
					}
					searchResponse = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)).get();
					if(searchResponse.getHits().getHits().length == 0) {
						break;
					}
				}
			}
			searchRequestBuilder = client.prepareSearch(getIndex())
					.setTypes(getDocumentType()).setScroll(new TimeValue(6000)).setSize(1000).setSearchType(SearchType.SCAN)
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.termsQuery(CRMConstants.OPPORTUNITY_ACCOUNT_ID_RAW,
							accountIds), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedLostMappedStages())))
					.setPostFilter(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));

			searchResponse = esQueryUtils.execute(searchRequestBuilder);

			if(searchResponse != null) {
				opportunityIds = new ArrayList<>();
				while(true) {
					for(SearchHit searchHit: searchResponse.getHits().getHits()) {
						opportunityIds.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
					}
					searchResponse = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)).get();
					if(searchResponse.getHits().getHits().length == 0) {
						break;
					}
				}
			}
		} catch(Exception e) {
			LOG.error("Exception while getting lost opportunities for industry:", e);
		}
		return opportunityIds;
	}
	
	/**
	 * Get all the lost opportunities by industry
	 * @param fieldValue
	 * @return
	 */
	public List<String> getOpportunitiesByField(final String field, String fieldValue, final String startDate, final String endDate) {
		Client client = this.getTransportClient();
		List<String> opportunityIds = new ArrayList<>();
		try {
			SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(ElasticSearchEnums.CRM_ACCOUNT.getText())
					.setQuery(QueryBuilders.termQuery(field, fieldValue))
					.setFetchSource(CRMConstants.ACCOUNT_ID, null).setSearchType(SearchType.SCAN)
					.setSize(1000).setScroll(new TimeValue(6000));
			SearchResponse searchResponse = searchRequestBuilder.get();
			List<String> accountIds = new ArrayList<>();
			if(searchResponse != null) {
				while(true) {
					for(SearchHit searchHit: searchResponse.getHits().getHits()) {
						accountIds.add(searchHit.getSource().get(CRMConstants.ACCOUNT_ID).toString());
					}
					searchResponse = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)).get();
					if(searchResponse.getHits().getHits().length == 0) {
						break;
					}
				}
			}
			BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ACCOUNT_ID_RAW,
							accountIds));
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));
			
			searchRequestBuilder = client.prepareSearch(getIndex())
					.setTypes(getDocumentType()).setScroll(new TimeValue(6000)).setSize(1000).setSearchType(SearchType.SCAN)
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),boolFilterBuilder));

			searchResponse = esQueryUtils.execute(searchRequestBuilder);

			if(searchResponse != null) {
				opportunityIds = new ArrayList<>();
				while(true) {
					for(SearchHit searchHit: searchResponse.getHits().getHits()) {
						opportunityIds.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
					}
					searchResponse = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)).get();
					if(searchResponse.getHits().getHits().length == 0) {
						break;
					}
				}
			}
		} catch(Exception e) {
			LOG.error("Exception while getting lost opportunities for industry:", e);
		}
		return opportunityIds;
	}


	/**
	 * Get Number of accounts by opportunities
	 * @param opportunities
	 * @return
	 * @author rammoole
	 */
	public int getNoOfAccountsByOpportunities(List<String> opportunities) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0);

		TermsFilterBuilder filter = FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunities);

		SearchResponse searchResponse = searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), filter))
				.addAggregation(AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
						.field(SearchConstants.ACCOUNT_ID_RAW).size(0)).get();

		Terms accountTerms = searchResponse.getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
		return accountTerms.getBuckets().size();
	}

	/**
	 * This method is used to get Won New and existing opportunities Between dates
	 * @return
	 * 		{@link Map}
	 */
	public Map<String, List<String>> getWonNewAndExistingOpportunities(String startDate, String endDate){
		Map<String, List<String>> mapOfNewAndExistingOpportunities = new HashMap<>();
		mapOfNewAndExistingOpportunities.put(SearchConstants.OPPORTUNITY_TYPE_NEW, getWonNewOpportunities(startDate, endDate));
		mapOfNewAndExistingOpportunities.put(SearchConstants.OPPORTUNITY_TYPE_EXISTING, getWonExistingOpportunities(startDate, endDate));
		return mapOfNewAndExistingOpportunities;
	}

	/**
	 * Get product Name word cloud aggregation by opportunityIds
	 * @param opportunityIds
	 * @return
	 */
	public Map<String, Long> getOpportunityNameAggregationByOpportunities(List<String> opportunityIds, String startDate, String endDate) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.WORD_CLOUD_OPP_PAIN_POINTS).field(CRMConstants.OPPORTUNITY_PAIN_POINTS/*SearchConstants.OPPORTUNITY_NAME*/).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS))
				.addAggregation(AggregationBuilders.terms(SearchConstants.WORD_CLOUD_OPP_NAME).field(CRMConstants.OPPORTUNITY_NAME/*SearchConstants.OPPORTUNITY_NAME*/).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		return MiriSearchUtils.getWordCloudAggregation(searchResponse);
	}

	/**
	 * This method is used to get Won New and existing opportunities Between dates
	 * @return
	 * 		{@link Map}
	 */
	public Map<String, List<String>> getSalesOrMarketingGeneratedWonNewAndExistingOpportunities(String startDate, String endDate, boolean isMarketing) {
		List<String> mapCampaigns = mapCampaignService.getMarketingSubCampaigns();
	
		//Get all opportunity Types
		Map<String, List<String>> mapOfNewAndExistingOpportunities = this.getOpportunityIdsByType(startDate, endDate, mapCampaigns, isMarketing, null, OpportunityStagesEnum.CLOSED_WON.getText(), null);
			
		return mapOfNewAndExistingOpportunities;
	}

	/**
	 * Get New Sales generated customers
	 * @param startDate
	 * @param endDate
	 * @param mapCampaigns
	 * @param isMarketing
	 * @return
	 */
	public List<String> getNewSalesGeneratedCustomers(String startDate, String endDate, List<String> mapCampaigns, boolean isMarketing){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(mapCampaigns)) {
			if(isMarketing){
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
			}else
				boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}

		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, OpportunityStagesEnum.CLOSED_WON.getText()));
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW, SearchConstants.OPPORTUNITY_TYPE_NEW));


		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000));

		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		List<String> newCustomers = new ArrayList<>();
		while(true){
			for(SearchHit searchHit: opportunityRespose.getHits().getHits()) {
				newCustomers.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000));
			opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return newCustomers;
	}

	/**
	 * Get Existing Sales generated customers
	 * @param startDate
	 * @param endDate
	 * @param mapCampaigns
	 * @param isMarketing
	 * @return
	 */
	public List<String> getExistingSalesGeneratedCustomers(String startDate, String endDate, List<String> mapCampaigns, boolean isMarketing){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(mapCampaigns)) {
			if(isMarketing){
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
			}else
				boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}

		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW, SearchConstants.OPPORTUNITY_TYPE_EXISTING));


		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000));

		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		List<String> existingCustomers = new ArrayList<>();
		while(true){
			for(SearchHit searchHit: opportunityRespose.getHits().getHits()) {
				existingCustomers.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000));
			opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return existingCustomers;

	}
	
	/**
	 * Get New Sales generated customers
	 * @param startDate
	 * @param endDate
	 * @param mapCampaigns
	 * @param isMarketing
	 * @return
	 */
	public List<String> getOpportunitiesByType(String startDate, String endDate, List<String> mapCampaigns,
			boolean isMarketing, String opportunityType){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(mapCampaigns)) {
			if(isMarketing){
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
			}else
				boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}

		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW,opportunityType));


		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000));

		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		List<String> newCustomers = new ArrayList<>();
		while(true){
			for(SearchHit searchHit: opportunityRespose.getHits().getHits()) {
				newCustomers.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000));
			opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return newCustomers;
	}
	
	/**
	 * Get the Won opportunities of opportunity types
	 * @param startDate
	 * @param endDate
	 * @param mapCampaigns
	 * @param isMarketing
	 * @param opportunityType
	 * @param stage
	 * @return
	 */
	public Map<String, List<String>> getOpportunityIdsByType(String startDate, String endDate, List<String> mapCampaigns,
			boolean isMarketing, String opportunityType, String stage, List<String> allOpportunityIds) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();;
		if(CollectionUtils.isNotEmpty(mapCampaigns)) {
			if(isMarketing){
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
			} else {
				boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
			}
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}

		if(StringUtils.isNotBlank(stage)) {
			boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}
		
		if(StringUtils.isNotBlank(opportunityType)) {
			boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW, opportunityType));
		}
		
		if(allOpportunityIds != null) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, allOpportunityIds));
		}
		
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_TYPE_AGGREGATION).field(CRMConstants.OPPORTUNITY_TYPE_RAW).size(0));

		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		Terms typeTerms = opportunityRespose.getAggregations().get(SearchConstants.OPPORTUNITY_TYPE_AGGREGATION);
		Collection<Terms.Bucket> typeBuckets = typeTerms.getBuckets();
		long maxHitsSize = 0;
		for(Terms.Bucket typeBucket: typeBuckets) {
			maxHitsSize = typeBucket.getDocCount();
			break;
		}
		searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_TYPE_AGGREGATION).field(CRMConstants.OPPORTUNITY_TYPE_RAW).size(0)
						.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_HITS_AGGREGATION).setSize((int) maxHitsSize).setFetchSource(CRMConstants.OPPORTUNITY_ID, null)));
		opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		Map<String, List<String>> opportunityIdsByTypeMap = new HashMap<>();
		List<String> opportunityIds = null;
		typeTerms = opportunityRespose.getAggregations().get(SearchConstants.OPPORTUNITY_TYPE_AGGREGATION);
		typeBuckets = typeTerms.getBuckets();
		for(Terms.Bucket typeBucket: typeBuckets) {
			TopHits topHits = typeBucket.getAggregations().get(SearchConstants.TOP_HITS_AGGREGATION);
			opportunityIds = new ArrayList<>();
			for(SearchHit hit: topHits.getHits()) {
				opportunityIds.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			//LOG.info("Type :" + typeBucket.getKey() + " count:" + opportunityIds.size());
			opportunityIdsByTypeMap.put(typeBucket.getKey(), opportunityIds);
		}
		return opportunityIdsByTypeMap;
	}
	
	/**
	 * This method is used to get Won New and existing opportunities Between dates
	 * @return
	 * 		{@link Map}
	 */
	public Map<String, List<String>> getSalesGeneratedWonNewAndExistingOpportunities() {
		List<String> mapOpportunities = mapOpportunityService.getMapOpportunities();
		Map<String, List<String>> mapOfNewAndExistingOpportunities = new HashMap<>();
		mapOfNewAndExistingOpportunities.put(SearchConstants.OPPORTUNITY_TYPE_NEW, getNewSalesGeneratedCustomers(mapOpportunities));
		mapOfNewAndExistingOpportunities.put(SearchConstants.OPPORTUNITY_TYPE_EXISTING, getExistingSalesGeneratedCustomers(mapOpportunities));
		return mapOfNewAndExistingOpportunities;
	}

	/**
	 * Get New Sales Generated Opportunities for customers
	 * @param mapOpportunities
	 * @return
	 */
	public List<String> getNewSalesGeneratedCustomers(List<String> mapOpportunities){
		List<String> stageToInclude = new ArrayList<>();
		stageToInclude.addAll(appSalesStageContainer.getClosedWonMappedStages());

		BoolFilterBuilder boolFilter=FilterBuilders.boolFilter();
		boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, mapOpportunities));
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stageToInclude));
		boolFilter.must(FilterBuilders.termFilter(SearchConstants.OPPORTUNITY_TYPE_RAW, SearchConstants.OPPORTUNITY_TYPE_NEW));

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000));

		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		List<String> newCustomers = new ArrayList<>();
		while(true){
			for(SearchHit searchHit: opportunityRespose.getHits().getHits()) {
				newCustomers.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000));
			opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return newCustomers;
	}

	/**
	 * Get Existing Sales Genrated opportunities customers
	 * @param mapOpportunities
	 * @return
	 */
	public List<String> getExistingSalesGeneratedCustomers(List<String> mapOpportunities){
		List<String> stageToInclude = new ArrayList<>();
		stageToInclude.addAll(appSalesStageContainer.getClosedWonMappedStages());

		BoolFilterBuilder boolFilter=FilterBuilders.boolFilter();
		boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, mapOpportunities));
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stageToInclude));
		boolFilter.must(FilterBuilders.termFilter(SearchConstants.OPPORTUNITY_TYPE_RAW, SearchConstants.OPPORTUNITY_TYPE_EXISTING));

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000));

		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		List<String> existingCustomers = new ArrayList<>();
		while(true){
			for(SearchHit searchHit: opportunityRespose.getHits().getHits()) {
				existingCustomers.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000));
			opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return existingCustomers;

	}


	/**
	 * Get campaign name based on the opportunity Id.
	 *
	 * @param opportunityId
	 * @return CrmOpportunity
	 */
	public CrmOpportunity getCrmCampaignByOpportunityId(final String opportunityId) {
		return (CrmOpportunity) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), CRMConstants.OPPORTUNITY_ID_RAW,
				opportunityId);
	}

	/**
	 * get the month wise average days for opportunities in index and document
	 * @param index
	 * @param document
	 * @param field
	 * @param opportunityIds
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<Integer, Long> getAverageDaysForOpportunities(String index, String document, String field, List<String> opportunityIds, String termsField){
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(termsField, opportunityIds));

		AbstractAggregationBuilder invoiceDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(field)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.subAggregation(AggregationBuilders.avg(SearchConstants.AVG_AGGREGATION).field(field));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(index)
				.setTypes(document).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(invoiceDateAggregation);
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		InternalHistogram datehist = response.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		Map<Integer, Long> mapForListofDateForMon = new HashMap<>();
		for (InternalHistogram.Bucket bucket : buckets) {
			InternalAvg sum = (InternalAvg) bucket.getAggregations().get(SearchConstants.AVG_AGGREGATION);
			long days = MiriSearchUtils.getDaysfromMillis((long) sum.getValue());
			Date createddate = MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					bucket.getKey());
			int month= MiriDateUtils.getMonth(createddate);
			mapForListofDateForMon.put(month, days);
		}
		return mapForListofDateForMon;
	}

	/**
	 * Won Sales Generated Opportunities Count
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public long getWonSalesGeneratedOpportunitiesCount(String startDate, String endDate) {
		List<String> mapOpportunities = mapOpportunityService.getMapOpportunities(startDate, endDate);

		//		BoolQueryBuilderRequest boolQueryBuilderRequest = new BoolQueryBuilderRequest(SearchConstants.OPPORTUNITY_ID_RAW, mapOpportunities, SearchConstants.BATCH_SIZE_1000, BoolType.MUST_NOT);
		//
		//		BoolQueryBuilder termsQuery = MiriSearchUtils.createBoolQueryBuilder(Arrays.asList(boolQueryBuilderRequest));
		//
		//		termsQuery.must(QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));

		FilterBuilder rangeFilter = FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON)
				.from(startDate).to(endDate).includeLower(true).includeUpper(true);

		//RangeFilterBuilder probFilter= FilterBuilders.rangeFilter("probabilityPerc").from(80).to(100).includeLower(true).includeUpper(true);
		TermsFilterBuilder opportunityTerms=FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, mapOpportunities);
		TermsFilterBuilder stage = FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages());

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter()
				.must(rangeFilter);
		boolFilter.mustNot(opportunityTerms);
		boolFilter.must(stage);

		CountResponse countResponse = getTransportClient().prepareCount(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.get();

		return countResponse.getCount();
	}

	/**
	 * Get the opportunities count and sum of opportinity amount matching the stages
	 * @param opportunities
	 * @param stageToExclude
	 * @param startDate
	 * @param endDate
	 * @return
	 */

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<String, MultipleAxesChartData> getOpportunityAmountByStageAndMonth(List<String> opportunities,List<String> stageToExclude,
			Calendar startDate,Calendar endDate,boolean isProbabilityFilter,int probStartRange,int probabilityEndRange){
		Map<String,MultipleAxesChartData> opportunityAmountByStages=new LinkedHashMap<>();
		MultipleAxesChartData pipelineData = null;
		timeUtil.start();

		String minBound = MiriDateUtils.getElasticSearchFormattedDate(startDate);
		String maxBound = MiriDateUtils.getElasticSearchFormattedDate(endDate);

		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumAmounttByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, SearchConstants.OPPORTUNITY_AMOUNT);


		// Create a aggregation to sort the invoices by month
		AbstractAggregationBuilder opportunityDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(CRMConstants.OPPORTUNITY_CLOSED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(minBound,maxBound).minDocCount(0).subAggregation(sumAmounttByMonth);

		TermsFilterBuilder stageTerms=FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stageToExclude);

		//MIRI-1828 - Change the filter on closed date
		RangeFilterBuilder rangeFilter = FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE)
				.from(minBound).to(maxBound).includeLower(false).includeUpper(false);

		BoolFilterBuilder boolFilter=FilterBuilders.boolFilter().must(rangeFilter).must(stageTerms);

		if(isProbabilityFilter){
			RangeFilterBuilder probFilter= FilterBuilders.rangeFilter(CRMConstants.PROBABILITY_PERC)
					.from(probStartRange).to(probabilityEndRange).includeLower(true).includeUpper(true);
			boolFilter.must(probFilter);
		}

		if(CollectionUtils.isNotEmpty(opportunities)){
			TermsFilterBuilder opportunityTerms=FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW,opportunities);
			boolFilter.must(opportunityTerms);
		}

		SearchRequestBuilder requestQuery = getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(opportunityDateAggregation).setSize(0);
		

		SearchResponse response=esQueryUtils.execute(requestQuery);

		InternalHistogram datehist = response.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		int monthIndex=0;
		for (InternalHistogram.Bucket bucket : buckets) {
			pipelineData = new  MultipleAxesChartData();
			Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			pipelineData.setRevenueAmount(sum.getValue());
			pipelineData.setxAxis(monthIndex);
			pipelineData.setOpportunityCount(new Integer((int)bucket.getDocCount()));
			pipelineData.setBucketKeyAsString(bucket.getKeyAsText().string());
			opportunityAmountByStages.put(String.valueOf(monthIndex), pipelineData);
			monthIndex++;
		}

		timeUtil.end();
		LOG.debug("opportunityAmountByStages:- Time Taken in seconds"+timeUtil.timeTakenInMillis());
		return opportunityAmountByStages;

	}


	/**
	 * Get the opportunities count and sum of opportinity amount matching the stages
	 *
	 */
	public double getOpportunityAmountSumByStage(List<String> opportunities,List<String> stageToExclude,
			boolean isProbabilityFilter,int probStartRange,int probabilityEndRange,FiscalDatesStrData fiscalDates){
		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumAmounttByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, SearchConstants.OPPORTUNITY_AMOUNT);


		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(stageToExclude)) {
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stageToExclude));
		}

		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}

		if(isProbabilityFilter){
			RangeFilterBuilder probFilter= FilterBuilders.rangeFilter(CRMConstants.PROBABILITY_PERC).from(probStartRange).
					to(probabilityEndRange).includeLower(true).includeUpper(true);
			boolFilter.must(probFilter);
		}
		
		if(StringUtils.isNotBlank(fiscalDates.getFiscalStartDateStr()) && StringUtils.isNotBlank(fiscalDates.getFiscalEndDateStr())){
			boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(fiscalDates.getFiscalStartDateStr())
					.to(fiscalDates.getFiscalEndDateStr()));
		}

		FilteredQueryBuilder query= QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter);

		SearchResponse response = getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setQuery(query)
				.addAggregation(sumAmounttByMonth).setSize(0)
				.execute().actionGet();

		Sum sum = (Sum) response.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);

		return sum.getValue();

	}

	public Map<String, MultipleAxesChartData> getOpportunityAmountSumByCriteria(List<String> opportunities,
			List<String> stageToExclude,String aggregationCriteria,boolean isProbabilityFilter
			,int probStartRange,int probabilityEndRange,FiscalDatesStrData fiscalDates ){

		Map<String,MultipleAxesChartData> stagesAndAmoutSumMap=new LinkedHashMap<String,MultipleAxesChartData>();
		MultipleAxesChartData pipelineData=null;

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(stageToExclude)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stageToExclude));
		}

		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		
		if(StringUtils.isNotBlank(fiscalDates.getFiscalStartDateStr()) && StringUtils.isNotBlank(fiscalDates.getFiscalEndDateStr())){
			boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(fiscalDates.getFiscalStartDateStr())
					.to(fiscalDates.getFiscalEndDateStr()));
		}
		
		if(isProbabilityFilter){
			RangeFilterBuilder probFilter= FilterBuilders.rangeFilter(CRMConstants.PROBABILITY_PERC).from(probStartRange).
					to(probabilityEndRange)
					.includeLower(true).includeUpper(true);
			boolFilter.must(probFilter);
		}

		FilteredQueryBuilder query= QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter);

		AbstractAggregationBuilder sumAmounttByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, SearchConstants.OPPORTUNITY_AMOUNT);

		AbstractAggregationBuilder termAggr=AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).
				field(aggregationCriteria)
				.order(Order.term(false))
				.size(probabilityEndRange-probStartRange)
				.subAggregation(sumAmounttByMonth);


		SearchRequestBuilder request=getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setQuery(query)
				.addAggregation(termAggr)
				.setSize(0);


		SearchResponse response = esQueryUtils.execute(request);

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> buckets = terms.getBuckets();

		int monthIndex = 0;
		for (Terms.Bucket bucket : buckets) {
			pipelineData=new MultipleAxesChartData();
			Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			pipelineData.setxAxis(monthIndex);
			pipelineData.setRevenueAmount(sum.getValue());
			pipelineData.setOpportunityCount(new Integer((int)bucket.getDocCount()));
			pipelineData.setHoverAmount(sum.getValue());
			stagesAndAmoutSumMap.put(bucket.getKey(),pipelineData);
			monthIndex++;
		}

		return stagesAndAmoutSumMap;

	}

	public long getOpportunityCountByStage(List<String> opportunities,List<String> stageToExclude,boolean isProbabilityFilter
			,int probStartRange,int probabilityEndRange,FiscalDatesStrData fiscalDates){
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(stageToExclude)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stageToExclude));
		}

		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}

		if(isProbabilityFilter) {
			RangeFilterBuilder probFilter= FilterBuilders.rangeFilter(CRMConstants.PROBABILITY_PERC).from(probStartRange).to(probabilityEndRange)
					.includeLower(true).includeUpper(true);
			boolFilter.must(probFilter);
		}
		
		if(StringUtils.isNotBlank(fiscalDates.getFiscalStartDateStr()) && StringUtils.isNotBlank(fiscalDates.getFiscalEndDateStr())){
			boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(fiscalDates.getFiscalStartDateStr())
					.to(fiscalDates.getFiscalEndDateStr()));
		}

		FilteredQueryBuilder query= QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter);
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setQuery(query);
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		SearchHits oppSearchHits = response.getHits();

		return oppSearchHits.totalHits();

	}

	/**
	 * Get Won Sales Generated Opportunities
	 * @return
	 * @author Noor
	 */
	public List<String> getSalesGeneratedOpportunites(String startDate, String endDate) {

		timeUtil.start();
		Client client = getTransportClient();

		List<String> salesGeneratedOpportunities = new ArrayList<>();
		List<String> subCampaigns = mapCampaignService.getMarketingSubCampaigns();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaigns));

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}

		SearchResponse opportunityRespose = client.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setFetchSource(CRMConstants.OPPORTUNITY_ID, null)
				.setSize(500)
				.setScroll(new TimeValue(60000))
				.setSearchType(SearchType.SCAN).get();

		while(true) {
			SearchHits oppSearchHits = opportunityRespose.getHits();
			for (SearchHit hit : oppSearchHits) {
				salesGeneratedOpportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			opportunityRespose = client.prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(60000)).get();
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		timeUtil.end();
		LOG.debug("ES Time getSalesGeneratedOpportunites"+timeUtil.timeTakenInMillis());
		return salesGeneratedOpportunities;
	}
	/**
	 * Get Won Sales Generated Opportunities
	 * @return
	 * @author Prem
	 */
	public List<String> getSalesGeneratedOpportunites() {
		return getSalesGeneratedOpportunites(null, null);
	}

	/**
	 * Get Won Sales Generated Opportunities
	 * @return
	 * @author Ramana
	 */
	public List<String> getSalesGeneratedOpportunitesByStageAndDateRange(String startDate, String endDate, String stage) {
		timeUtil.start();
		Client client = getTransportClient();
		List<String> salesGeneratedOpportunities = new ArrayList<>();

		List<String> marketingCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}

		if(CollectionUtils.isNotEmpty(marketingCampaigns)) {
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
		}

		if(StringUtils.isNotBlank(stage)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN)
				.setSize(600)
				.setScroll(new TimeValue(6000));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		do {
			for (SearchHit hit : searchResponse.getHits().getHits()) {
				salesGeneratedOpportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
		} while(searchResponse.getHits().getHits().length != 0);

		/*
		List<String> mapOpportunities = mapOpportunityService.getMapOpportunitiesByDateRange(startDate, endDate);

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, mapOpportunities));

		SearchResponse opportunityRespose = client.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setFetchSource(CRMConstants.OPPORTUNITY_ID, null)
				.setSize(500)
				.setScroll(new TimeValue(60000))
				.setSearchType(SearchType.SCAN).get();

		while(true) {
			SearchHits oppSearchHits = opportunityRespose.getHits();
			for (SearchHit hit : oppSearchHits) {
				salesGeneratedOpportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			opportunityRespose = client.prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(60000)).get();
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}*/
		timeUtil.end();
		LOG.debug("ES Time getSalesGeneratedOpportunites"+timeUtil.timeTakenInMillis());
		return salesGeneratedOpportunities;
	}


	/**
	 * Get Sales generated opportunities with in date range
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getSalesGeneratedOpportunitesByStage(String startDate, String endDate) {
		return getSalesGeneratedOpportunitesByStageAndDateRange(startDate, endDate, OpportunityStagesEnum.CLOSED_WON.getText());
	}

	/**
	 * Get Month Wise Sales Generated Opportunities
	 * used for Average Time To Revenue.
	 * @param startDate
	 * @param endDate
	 * @param stage
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, List<String>> getMonthWiseSalesGeneratedOpportunitiesByStage(final String startDate, final String endDate, final String stage) {
		timeUtil.start();
		Client client = getTransportClient();
		List<String> marketingCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate));
		}

		if(CollectionUtils.isNotEmpty(marketingCampaigns)) {
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
		}

		if(StringUtils.isNotBlank(stage)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.dateHistogram(SearchConstants.MONTH_WISE_AGGREGATION).field(CRMConstants.OPPORTUNITY_CLOSED_DATE)
						.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		InternalHistogram dateHistogram = searchResponse.getAggregations().get(SearchConstants.MONTH_WISE_AGGREGATION);
		Collection<InternalHistogram.Bucket> monthBuckets = dateHistogram.getBuckets();

		Calendar monthStart = Calendar.getInstance();
		Calendar monthEnd = Calendar.getInstance();
		Map<Integer, List<String>> sgOpportunitiesByMonth = new LinkedHashMap<>();
		String monthStartStr;
		String monthEndStr;
		int count = 0;
		for (InternalHistogram.Bucket dateBucket : monthBuckets) {
			monthStart.setTime(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					dateBucket.getKeyAsText().toString()));

			int month = monthStart.get(Calendar.MONTH);
			monthEnd.setTime(monthStart.getTime());
			monthEnd.set(Calendar.DAY_OF_MONTH, monthStart.getActualMaximum(Calendar.DAY_OF_MONTH));
			monthStartStr = MiriDateUtils.parseDateToString(monthStart, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			monthEndStr = MiriDateUtils.parseDateToString(monthEnd, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);

			boolFilterBuilder = FilterBuilders.boolFilter();
			if(CollectionUtils.isNotEmpty(marketingCampaigns)) {
				boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
			}

			if(StringUtils.isNotBlank(stage)) {
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
			}

			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(monthStartStr).lte(monthEndStr));

			searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
					.setSize((int) dateBucket.getDocCount())
					.setFetchSource(CRMConstants.OPPORTUNITY_ID, null);
			searchResponse = esQueryUtils.execute(searchRequestBuilder);
			List<String> opportunities = new ArrayList<>();
			for(SearchHit hit: searchResponse.getHits()) {
				opportunities.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			sgOpportunitiesByMonth.put(count, opportunities);
			count++;
		}
		return sgOpportunitiesByMonth;
	}


	/**
	 * receives opportunity list and returns TopHighestCustomerData
	 * @param opps
	 * @return
	 */
	public  TopHighestCustomerData getTopAccount(List<String> opps) {
		Client client = this.getTransportClient();
		TopHighestCustomerData topHighestCustomer = null;
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(!CollectionUtils.isEmpty(opps)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opps));
		}

		AbstractAggregationBuilder dateAggregation = AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ACCOUNT_ID_RAW);
		SearchResponse response = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(dateAggregation).get();
		Terms aggs = response.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
		Collection<Bucket> buckets = aggs.getBuckets();
		Map<Object, Double> accountIdToInvoiceSumMap = null;
		if (buckets.size() > 0) {
			accountIdToInvoiceSumMap = new java.util.HashMap<>();
			for (Terms.Bucket bucket : buckets) {
				getAccountIdToInvoiceSumMap(accountIdToInvoiceSumMap,
						bucket.getKey().toString(), opps);
			}
			topHighestCustomer=new TopHighestCustomerData();
			accountIdToInvoiceSumMap = MiriSearchUtils.sortMapByValue(accountIdToInvoiceSumMap);
			List<Object> accountIdList = new ArrayList<Object>(accountIdToInvoiceSumMap.keySet());
			topHighestCustomer.setTotalSalesAmount(accountIdToInvoiceSumMap.get(accountIdList.get(0)));
			topHighestCustomer.setCustomerName(crmAccountService.getAccountNameByAccountId((String) accountIdList.get(0)));
		}
		return topHighestCustomer;

	}

	private void getAccountIdToInvoiceSumMap(
			Map<Object, Double> accountIdToInvoiceSumMap, String accountId, List<String> opps) {
		Client client = this.getTransportClient();

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(!CollectionUtils.isEmpty(opps)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opps));
		}

		if(!StringUtils.isEmpty(accountId)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_ID_RAW, accountId));
		}
		//BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery().must(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).must(queryBuilderAcc);
		SearchResponse response = client.prepareSearch(getIndex()).setTypes(getDocumentType()).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.get();
		List<String> opportunityIdLIst = new ArrayList<>();
		for (SearchHit hit : response.getHits()) {
			opportunityIdLIst.add((String) hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
		}
		Double invoiceSum = erpInvoiceService.getInvoiceSumForOpportunites(opportunityIdLIst);
		accountIdToInvoiceSumMap.put(accountId, invoiceSum);
	}


	/**
	 * receives opportunity list and returns list of industry
	 * @param opps
	 * @return
	 */
	public  List<ColumnDrillDownData> getIdustryList(List<String> opps) {
		Client client = this.getTransportClient();

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(!CollectionUtils.isEmpty(opps)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opps));
		}
		AbstractAggregationBuilder dateAggregation = AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION)
				.field(CRMConstants.ACCOUNT_INDUSTRY_RAW);
		SearchResponse response = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(dateAggregation).get();
		Terms aggs = response.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
		Collection<Bucket> buckets = aggs.getBuckets();
		Map<Object, Double> industryToInvoiceSumMap = null;
		List<ColumnDrillDownData> industryList = null;
		if (buckets.size() > 0) {
			industryToInvoiceSumMap = new java.util.HashMap<>();
			for (Terms.Bucket bucket : buckets) {
				getIndustryToInvoiceSumMap(industryToInvoiceSumMap,
						bucket.getKey().toString(), opps);
			}

			industryList = new ArrayList<>();
			industryToInvoiceSumMap = MiriSearchUtils.sortMapByValue(industryToInvoiceSumMap);
			for(Object industry : industryToInvoiceSumMap.keySet()){
				ColumnDrillDownData columnDrillDownData = new ColumnDrillDownData();
				columnDrillDownData.setIndustryName((String)industry);
				columnDrillDownData.setRevenueAmount(industryToInvoiceSumMap.get(industry));
				industryList.add(columnDrillDownData);
			}
		}
		return industryList;
	}

	private  void getIndustryToInvoiceSumMap(
			Map<Object, Double> industryToInvoiceSumMap, String industry, List<String> opps) {
		Client client = this.getTransportClient();

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(!CollectionUtils.isEmpty(opps)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opps));
		}

		if(!StringUtils.isEmpty(industry)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_INDUSTRY_RAW, industry));
		}



		//BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery().must(queryBuilderOpp).must(queryBuilderAcc);
		SearchResponse response = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),boolFilterBuilder))
				.get();
		List<String> opportunityIdLIst = new ArrayList<>();
		for (SearchHit hit : response.getHits()) {
			opportunityIdLIst.add((String) hit.getSource().get("opportunityId"));
		}
		Double invoiceSum = erpInvoiceService.getInvoiceSumForOpportunites(opportunityIdLIst);
		industryToInvoiceSumMap.put(industry, invoiceSum);
	}

	/**
	 * Gets all the opportunities of a parent Campaign
	 * @param parentCampaignId
	 * @return
	 */
	public List<String> getWonOpportunitiesByParentCampaignId(String parentCampaignId, String startDate, String endDate) {

		Map<String, String> subCampaigns = this.crmCampaignService.getSubCampaigns(parentCampaignId);
		List<String> campaignIds = new ArrayList<>(subCampaigns.keySet());

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(campaignIds)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, campaignIds));
		}

		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(300)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setPostFilter(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate))
				.setFetchSource(CRMConstants.OPPORTUNITY_ID, null);

		List<String> crmOpportunities = null;
		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		if(opportunityRespose != null) {
			crmOpportunities = new ArrayList<>();
			while(true) {
				for (SearchHit hit : opportunityRespose.getHits()) {
					crmOpportunities.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
				}
				SearchScrollRequestBuilder  searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000));
				opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
				if(opportunityRespose.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		return crmOpportunities;
	}
	/**
	 * Gets all the opportunities of a parent Campaign
	 * @param parentCampaignId
	 * @return
	 */
	public Object[] getLostOpportunitiesAndAmountByParentCampaignId(String parentCampaignId, String startDate, String endDate) {
		Map<String, String> subCampaigns = this.crmCampaignService.getSubCampaigns(parentCampaignId);
		List<String> campaignIds = new ArrayList<>(subCampaigns.keySet());
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(!CollectionUtils.isEmpty(campaignIds)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, campaignIds));
		}

		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedLostMappedStages()));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));

		AbstractAggregationBuilder aggregation = AggregationBuilders
				.sum(SearchConstants.AMOUNT_AGGREGATION).field(SearchConstants.AMOUNT);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.DEFAULT)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(aggregation);
		SearchResponse response = searchRequestBuilder.execute().actionGet();

		Sum sum = (Sum) response.getAggregations().get(SearchConstants.AMOUNT_AGGREGATION);
		long opportunityCount = response.getHits().getTotalHits();
		return new Object[]{opportunityCount, sum.getValue()};
	}

	/**
	 * Get New customers Won opportunities
	 * @param startDate
	 * @param endDate
	 */
	public List<String> getWonNewOpportunities(String startDate, String endDate){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));
		}
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW, SearchConstants.OPPORTUNITY_TYPE_NEW));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunityIds = new ArrayList<>();
		while (true) {
			for (SearchHit hit : searchResponse.getHits()) {
				opportunityIds.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}

		}
		return opportunityIds;
	}

	/**
	 * Get Existing customers Won opportunities
	 * @param startDate
	 * @param endDate
	 */
	public List<String> getWonExistingOpportunities(String startDate, String endDate) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));
		}
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW, SearchConstants.OPPORTUNITY_TYPE_EXISTING));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunityIds = new ArrayList<>();
		while (true) {
			for (SearchHit hit : searchResponse.getHits()) {
				opportunityIds.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}

		}
		return opportunityIds;
	}
	/**
	 * Get New customers Won opportunities
	 * @param startDate
	 * @param endDate
	 */
	public List<String> getWonNewMarketingOpportunitiesForParentCampaign(String parentCampaignId, String startDate, String endDate){
		List<String> mapOpportunities = mapOpportunityService.getMapOpportunities(startDate, endDate);
		Map<String, String> subCampaigns =  crmCampaignService.getSubCampaigns(parentCampaignId);
		List<String> subCampaignIds = new ArrayList<>(subCampaigns.keySet());
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, mapOpportunities));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaignIds));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW, SearchConstants.OPPORTUNITY_TYPE_NEW));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000));
		SearchResponse searchResponse = searchRequestBuilder.get();
		List<String> opportunityIds = new ArrayList<>();
		while (true) {
			for (SearchHit hit : searchResponse.getHits()) {
				opportunityIds.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
			}
			searchResponse = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)).get();
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}

		}
		return opportunityIds;
	}
	/**
	 * Get New customers Won opportunities
	 * @param startDate
	 * @param endDate
	 */
	public List<String> getWonNewMarketingOpportunitiesForParentCampaign(String parentCampaignId){
		List<String> mapOpportunities = mapOpportunityService.getMapOpportunities();
		Map<String, String> subCampaigns =  crmCampaignService.getSubCampaigns(parentCampaignId);
		List<String> subCampaignIds = new ArrayList<>(subCampaigns.keySet());
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, mapOpportunities));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaignIds));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW, SearchConstants.OPPORTUNITY_TYPE_NEW));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000)).setSize(1000);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunityIds = new ArrayList<>();
		while (true) {
			for (SearchHit hit : searchResponse.getHits()) {
				opportunityIds.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}

		}
		return opportunityIds;
	}

	/**
	 * Get Existing customers Won opportunities
	 * @param startDate
	 * @param endDate
	 */
	public List<String> getWonExistingOpportunitiesForParentCampaign(String parentCampaign, String startDate, String endDate){
		List<String> mapOpportunities = mapOpportunityService.getMapOpportunities(startDate, endDate);
		Map<String, String> subCampaigns =  crmCampaignService.getSubCampaigns(parentCampaign);
		List<String> subCampaignIds = new ArrayList<>(subCampaigns.keySet());
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, mapOpportunities));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaignIds));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW, SearchConstants.OPPORTUNITY_TYPE_EXISTING));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000)).setSize(1000);
		SearchResponse searchResponse = searchRequestBuilder.get();
		List<String> opportunityIds = new ArrayList<>();
		while (true) {
			for (SearchHit hit : searchResponse.getHits()) {
				opportunityIds.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
			}
			searchResponse = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)).get();
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}

		}
		return opportunityIds;
	}
	/**
	 * Get Existing customers Won opportunities
	 * @param startDate
	 * @param endDate
	 */
	public List<String> getWonExistingOpportunitiesForParentCampaign(String parentCampaign){
		List<String> mapOpportunities = mapOpportunityService.getMapOpportunities();
		Map<String, String> subCampaigns =  crmCampaignService.getSubCampaigns(parentCampaign);
		List<String> subCampaignIds = new ArrayList<>(subCampaigns.keySet());
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, mapOpportunities));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaignIds));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW, SearchConstants.OPPORTUNITY_TYPE_EXISTING));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000)).setSize(1000);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunityIds = new ArrayList<>();
		while (true) {
			for (SearchHit hit : searchResponse.getHits()) {
				opportunityIds.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}

		}
		return opportunityIds;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<Integer, Double> getMonthWiseADSForCampaign(String startDate, String endDate, double campaignRevenue, List<String> campaignIds){
		timeUtil.start();
		AbstractAggregationBuilder aggregation = AggregationBuilders
				.dateHistogram(SearchConstants.LEAD_AGGREGATION).field(CRMConstants.OPPORTUNITY_CREATED_ON)
				.extendedBounds(startDate, endDate)
				.minDocCount(0)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		BoolFilterBuilder boolFilter=FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, campaignIds));
		boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gt(startDate).lt(endDate));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(aggregation)
				.setSize(0);
		SearchResponse searchResponse = searchRequestBuilder.get();
		InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.LEAD_AGGREGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		Map<Integer, Double> mapForListofDateForMon = MiriSearchUtils.populateMonthsEmptyDoubleData();
		for (InternalHistogram.Bucket bucket : buckets) {
			Date createddate = MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					bucket.getKey());
			int month= MiriDateUtils.getMonth(createddate);
			mapForListofDateForMon.put(month, (double) (campaignRevenue/bucket.getDocCount()));
		}
		timeUtil.end();
		LOG.debug(" ES time getMonthWiseADSForCampaign :- Total Time Taken in sec"+timeUtil.timeTakenInMillis());
		return mapForListofDateForMon;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, Double> getAverageOpprtunityCreationTimeForOpportunities(List<String> opportunities, String startDate, String endDate){
		timeUtil.start();

		AbstractAggregationBuilder aggregation = AggregationBuilders
				.dateHistogram(SearchConstants.OPPORTUNITY_AGGREGATION).field(CRMConstants.OPPORTUNITY_CREATED_ON)
				.extendedBounds(startDate, endDate)
				.minDocCount(0)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.subAggregation(AggregationBuilders.avg(SearchConstants.AVG_AGGREGATION).field(CRMConstants.OPPORTUNITY_CREATED_ON));
		BoolFilterBuilder boolFilter=FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gt(startDate).lt(endDate));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(aggregation)
				.setSize(0);
		SearchResponse searchResponse = searchRequestBuilder.get();
		InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		Map<Integer, Double> mapForListofDateForMon = MiriSearchUtils.populateMonthsEmptyDoubleData();
		for (InternalHistogram.Bucket bucket : buckets) {
			InternalAvg sum = (InternalAvg) bucket.getAggregations().get(SearchConstants.AVG_AGGREGATION);
			double millis = sum.getValue();
			Date createddate = MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					bucket.getKey());
			int month= MiriDateUtils.getMonth(createddate);
			mapForListofDateForMon.put(month, millis);
		}
		timeUtil.end();
		LOG.debug("ES time getAverageOpprtunityCreationTimeForOpportunities"+timeUtil.timeTakenInMillis());
		return mapForListofDateForMon;

	}

	public SearchResponse getMonthWiseDealsResponse(List<String> opportunities, String startDate, String endDate) {
		timeUtil.start();
		Client client = getTransportClient();
		BoolFilterBuilder boolFilterInvoice = FilterBuilders.boolFilter();
		boolFilterInvoice.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunities));
		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.CAMPAIGN_AGGREGATION).field(SearchConstants.CREATED_ON)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0);
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.addAggregation(dateAggregation).setSize(0).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterInvoice));
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		timeUtil.end();

		LOG.debug("ES time getMonthWiseDealsResponse"+timeUtil.timeTakenInMillis());
		return response;
	}


	//Refactor Purpose , Methods to get Opportunities by Stages,Date,Opportunities

	/**
	 * Returns the opportunities in the mentioned stages, dates, type and opportunities
	 * @param stages
	 * @param fiscalStartDate
	 * @param fiscalEndDate
	 * @param opportunities
	 * @param opportunityType
	 * @return
	 */
	public List<String> getCRMMarketingInfluencedOpportunities(List<String> stages,
			String fiscalStartDate,String fiscalEndDate,List<String> opportunities,String opportunityType){

		List<String> subCamapigns =  mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapigns));

		return getOpportunities(stages, fiscalStartDate, fiscalEndDate, opportunities, opportunityType, boolFilter);
	}

	/**
	 * Returns the opportunities in the mentioned stages, dates, type and opportunities
	 * @param stages
	 * @param fiscalStartDate
	 * @param fiscalEndDate
	 * @param opportunities
	 * @param opportunityType
	 * @return
	 */
	public List<String> getCRMSalesGeneratedOpportunities(List<String> stages,
			String fiscalStartDate,String fiscalEndDate,List<String> opportunities,String opportunityType){

		List<String> subCamapigns =  mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapigns));

		return getOpportunities(stages, fiscalStartDate, fiscalEndDate, opportunities, opportunityType, boolFilter);
	}

	//Refactor Purpose , Methods to get Opportunities by Stages,Date,Opportunities
	public List<String> getCRMOpportunitiesByStageDateAndOpportunities(List<String> stages,
			String fiscalStartDate, String fiscalEndDate, List<String> opportunities, String opportunityType) {

		return getOpportunities(stages, fiscalStartDate, fiscalEndDate, opportunities, opportunityType, null);
	}
	/**
	 * Returns the opportunities in the mentioned stages, dates, type and opportunities
	 * @param stages
	 * @param fiscalStartDate
	 * @param fiscalEndDate
	 * @param opportunities
	 * @param opportunityType
	 * @return
	 */
	public List<String> getOpportunities(List<String> stages, String fiscalStartDate,
			String fiscalEndDate, List<String> opportunities, String opportunityType, BoolFilterBuilder boolFilter) {
		List<String> crmOpportunities = new ArrayList<>();
		Client client = getTransportClient();

		if(StringUtils.isNotBlank(fiscalStartDate) && StringUtils.isNotBlank(fiscalEndDate)) {
			if(boolFilter == null) {
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(fiscalStartDate).lte(fiscalEndDate));
		}

		if(CollectionUtils.isNotEmpty(stages)) {
			if(boolFilter == null) {
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stages));
		}

		if(CollectionUtils.isNotEmpty(opportunities)){
			if(boolFilter == null) {
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}

		if(StringUtils.isNotBlank(opportunityType)){
			if(boolFilter == null) {
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW, opportunityType));
		}

		QueryBuilder query;
		if(boolFilter != null) {
			query = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter);
		} else {
			query = QueryBuilders.matchAllQuery();
		}

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(60000))
				.setSize(500).setTypes(getDocumentType())
				.setQuery(query);
		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		while(true) {
			for(SearchHit hit:opportunityRespose.getHits().getHits()){
				crmOpportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			opportunityRespose = client.prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(60000)).get();
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		//LOG.debug("getCRMOpportunitiesByStageDateAndOpportunities :" + crmOpportunities.size());
		return crmOpportunities;
	}



	/**
	 * Account Name by opportunity Id
	 * @param oppId
	 * @return
	 */
	public String getAccountNameByOpportunityId(String oppId) {
		String accountName = null;
		QueryBuilder queryBuilder  = QueryBuilders.termQuery(SearchConstants.OPPORTUNITY_ID_RAW, oppId);
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(queryBuilder).setFetchSource(SearchConstants.ACCOUNT_ID, null);
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		SearchHits oppSearchHits = response.getHits();

		for (SearchHit hit : oppSearchHits) {
			String accountId = hit.getSource().get(SearchConstants.ACCOUNT_ID).toString();
			if(accountId != null){
				accountName = crmAccountService.getAccountNameByAccountId(accountId);
				if(accountName!=null)
					break;
			}
		}
		return accountName;
	}

	public List<String> getMarketingInfluencedOpprtunitiesForSubCampaigns(List<String> subCampaigns){

		List<String> crmOpportunities = new ArrayList<>();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, subCampaigns));
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));

		SearchResponse response = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000))
				.get();
		while(true) {
			for(SearchHit hit:response.getHits().getHits()){
				crmOpportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			response = getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(60000)).get();
			if(response.getHits().getHits().length == 0) {
				break;
			}
		}
		return crmOpportunities;
	}

	/**
	 * Get the list of opportunities for the given sub camapaign
	 * @param campaignId
	 * @return
	 */
	public List<String> getOpportunitiesByPrimaryCampSource(String campaignId, String opportunityType) {
		List<String> crmOpportunities = null;
		Client client = this.getTransportClient();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(opportunityType)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_TYPE_RAW, opportunityType));
		}

		boolFilter.must(FilterBuilders.termFilter(SearchConstants.PRIMARY_CAMPAIGN_SOURCE_RAW, campaignId));

		SearchResponse opportunityRespose = client.prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN)
				.setSize(500)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addField(SearchConstants.OPPORTUNITY_ID)
				.execute().actionGet();

		if(opportunityRespose != null) {
			crmOpportunities = new ArrayList<>();
			while(true) {
				for (SearchHit hit : opportunityRespose.getHits()) {
					crmOpportunities.add(hit.getFields().get(SearchConstants.OPPORTUNITY_ID).getValue().toString());
				}
				opportunityRespose = client.prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000)).get();
				if(opportunityRespose.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		return crmOpportunities;
	}

	/**
	 * Gets Won Opportunities within the Dates
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getWonOpportunitiesClosedInDaterange(String startDate, String endDate){
		List<String> opportunities =  new ArrayList<>();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(startDate).to(endDate));
		}

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);

		if(opportunityRespose != null) {
			opportunities = new ArrayList<>();
			while(true) {
				for (SearchHit hit : opportunityRespose.getHits()) {
					opportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				}
				opportunityRespose = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000)).get();
				if(opportunityRespose.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		return opportunities;
	}

	/**
	 * Get Marketing Influenced opportunities by stage and closed date range
	 * @param startDate
	 * @param endDate
	 * @param stage
	 * @return
	 */
	public List<String> getMarketingInfluencedOpportunitesByStageAndDateRange(String startDate,
			String endDate, String stage) {
		timeUtil.start();
		Client client = getTransportClient();
		List<String> marketingInfluencedOpportunities = new ArrayList<>();

		List<String> marketingCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}

		if(CollectionUtils.isNotEmpty(marketingCampaigns)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
		}

		if(StringUtils.isNotBlank(stage)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN)
				.setSize(600)
				.setScroll(new TimeValue(6000));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		do {
			for (SearchHit hit : searchResponse.getHits().getHits()) {
				marketingInfluencedOpportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
		} while(searchResponse.getHits().getHits().length != 0);

		timeUtil.end();
		//LOG.debug("ES Time getMarketingInfluencedOpportunites" + timeUtil.timeTakenInMillis());
		return marketingInfluencedOpportunities;
	}

	/**
	 * Gets the Number of Deals closed for a With In date Range
	 * @param companyName
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public long getDealsClosedForCustomerInDateRange(String companyName, String startDate, String endDate){
		return getDealsClosedByCustomerAndOpportunities(companyName, null, startDate, endDate);

	}

	/**
	 * Gets the Number of deals Closed By Customer from the opportunities with in dates
	 * @param accountName
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public long getDealsClosedByCustomerAndOpportunities(String accountName, List<String> opportunities, String startDate, String endDate){

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}

		boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON)
				.from(startDate)
				.to(endDate));
		boolFilter.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_COMPANY_NAME_RAW, accountName));
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));

		CountRequestBuilder searchRequestBuilder = this.getTransportClient().prepareCount(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));

		CountResponse searchResponse = searchRequestBuilder.get();
		return searchResponse.getCount();
	}


	/**
	 * Gets the Won Opportunities of a customer By Marketing Or sales
	 * @param customerName
	 * @return
	 */
	public List<String> getWonOpportunitiesOfCustomerByMarketingOrSales(String customerName, List<String> opportunityIds){

		//List<String> subCamapignIds = mapCampaignService.getMarketingSubCampaigns();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();

		boolFilter.must(FilterBuilders.termFilter(ERPConstants.INVOICE_ACCOUNT_NAME_RAW, customerName));

//		if(isMarketing){
//			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapignIds));
//		} else {
//			boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapignIds));
//		}
//		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		
		if(CollectionUtils.isNotEmpty(opportunityIds)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		}

		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText()).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		List<String> opportunities =  new ArrayList<>();

		while(true) {
			for (SearchHit hit : searchResponse.getHits()) {
				opportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return opportunities;
	}
	
	/**
	 * Gets the Won Opportunities of a customer By Marketing Or sales
	 * @param customerName
	 * @param isMarketing
	 * @return
	 */
	public List<String> getAllOpportunitiesOfCustomer(String customerName){
		
		List<String> accountId = crmAccountService.getAccountIdsByAccountNames(new ArrayList<>(Arrays.asList(customerName)));


		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_ID_RAW, accountId));

		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(1000);

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		List<String> opportunities =  new ArrayList<>();

		while(true) {
			for (SearchHit hit : searchResponse.getHits()) {
				opportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return opportunities;
	}

	/**
	 * Gets the Won Opportunities of a customer By Marketing Or sales
	 * @param customerName
	 * @param isMarketing
	 * @return
	 */
	public List<String> getOpportunitiesByAccountId(String accountId, final String startDate, final String endDate){
		
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termFilter(CRMConstants.ACCOUNT_ID_RAW, accountId));
		boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate));
		
		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(1000);

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		List<String> opportunities =  new ArrayList<>();

		while(true) {
			for (SearchHit hit : searchResponse.getHits()) {
				opportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return opportunities;
	}
	
	/**
	 * Gets the Won Opportunity Count From the list bof opportunities
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @param isMarketing
	 * @return
	 */
	public long getWonOpportunityCountFromOpportunities(List<String> opportunities, String startDate, String endDate, boolean isMarketing) {

		List<String> subCamapignIds = mapCampaignService.getMarketingSubCampaigns();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();

		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}

		if(isMarketing) {
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapignIds));
		} else {
			boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapignIds));
		}

		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));

		CountRequestBuilder countRequestBuilder = this.getTransportClient().prepareCount(getIndex())
				.setTypes(getDocumentType()).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
		return countRequestBuilder.get().getCount();
	}

	/**
	 * Gets the Won Opportunities From the list of opportunities
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @param isMarketing
	 * @return
	 */
	public List<String> getWonOpportunitiesFromOpportunities(List<String> opportunities, String startDate, String endDate, Boolean isMarketing) {

		List<String> subCamapignIds = mapCampaignService.getMarketingSubCampaigns();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();

		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}

		if(null != isMarketing){
			if(isMarketing) {
				boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapignIds));
			} else {
				boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapignIds));
			}
		}
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(1000);


		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> wonOpportunities = new ArrayList<>();

		while(true) {
			for (SearchHit hit : searchResponse.getHits()) {
				wonOpportunities.add((String)hit.getSource().get(SearchConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}

		return wonOpportunities;
	}

	public  List<String> getAllLeadSources(List<String> opportunities){
		List<String>  leadSources=new ArrayList<>();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		boolFilter.mustNot(FilterBuilders.termFilter(CRMConstants.LEAD_SOURCE_RAW,""));

		AbstractAggregationBuilder termAggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.LEAD_SOURCE_RAW).size(0);

		SearchRequestBuilder request = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(termAggr).setSearchType(SearchType.QUERY_AND_FETCH);

		SearchResponse response = esQueryUtils.execute(request);

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> buckets = terms.getBuckets();

		for (Terms.Bucket bucket : buckets) {
			if(StringUtils.isNotBlank(bucket.getKey())){
				leadSources.add(bucket.getKey());
			}
		}

		return leadSources;

	}

	/**
	 * Gets the lead sources for the campaigns
	 * @param campaigns
	 * @return
	 */
	public  List<String> getAllLeadSourcesByCampaigns(List<String> campaigns){
		List<String>  leadSources=new ArrayList<>();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(campaigns)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, campaigns));
		}
		boolFilter.mustNot(FilterBuilders.termFilter(CRMConstants.LEAD_SOURCE_RAW,""));

		AbstractAggregationBuilder termAggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.LEAD_SOURCE_RAW).size(0);

		SearchRequestBuilder request = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(termAggr).setSearchType(SearchType.QUERY_AND_FETCH);

		SearchResponse response = esQueryUtils.execute(request);

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> buckets = terms.getBuckets();

		for (Terms.Bucket bucket : buckets) {
			if(StringUtils.isNotBlank(bucket.getKey())){
				leadSources.add(bucket.getKey());
			}
		}

		return leadSources;

	}


	public  List<String> getAllOpportunityTypes(List<String> opportunities){
		List<String>  opportunityTypes=new ArrayList<>();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		
		boolFilter.mustNot(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW,"NULL"));
		boolFilter.mustNot(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW,""));

		AbstractAggregationBuilder termAggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_TYPE_RAW);

		SearchRequestBuilder request = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(termAggr);

		SearchResponse response=esQueryUtils.execute(request);

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> buckets = terms.getBuckets();

		for (Terms.Bucket bucket : buckets) {
				opportunityTypes.add(bucket.getKey());
		}

		return opportunityTypes;

	}


	public List<String> getOpportunitiesByLeadSource(List<String> opportunities,String startDate,String endDate,String leadSource){
		List<String> leadSourceOpportunities=new ArrayList<>();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotEmpty(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).to(endDate));
		}
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		if(StringUtils.isNotBlank(leadSource)){
			boolFilter.must(FilterBuilders.termFilter(CRMConstants.LEAD_SOURCE_RAW,leadSource));
		}

		SearchResponse opportunityRespose = getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.execute().actionGet();

		if(opportunityRespose != null) {
			leadSourceOpportunities = new ArrayList<>();
			while(true) {
				for (SearchHit hit : opportunityRespose.getHits()) {
					leadSourceOpportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				}
				opportunityRespose = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000)).get();
				if(opportunityRespose.getHits().getHits().length == 0) {
					break;
				}
			}
		}

		return leadSourceOpportunities;

	}

	/**
	 * Gets the revenue for Leadsource
	 * @param startDate
	 * @param endDate
	 * @param leadSource
	 * @return
	 */
	public double getMarketinInfluencedRevenueForLeadSource(String startDate, String endDate, String leadSource, List<String> campaigns){
		List<String> leadSourceOpportunities=new ArrayList<>();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(campaigns)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, campaigns));
		}else{
			List<String> mapCampaigns =  mapCampaignService.getMarketingSubCampaigns();
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
		}

		if(StringUtils.isNotBlank(leadSource)){
			boolFilter.must(FilterBuilders.termFilter(CRMConstants.LEAD_SOURCE_RAW,leadSource));
		}

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));


		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);

		if(opportunityRespose != null) {
			leadSourceOpportunities = new ArrayList<>();
			while(true) {
				for (SearchHit hit : opportunityRespose.getHits()) {
					leadSourceOpportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				}
				opportunityRespose = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000)).get();
				if(opportunityRespose.getHits().getHits().length == 0) {
					break;
				}
			}
		}

		return erpInvoiceService.getInvoiceAmountByOpportunityIds(leadSourceOpportunities, startDate, endDate);

	}

	/**
	 * Gets Assets and Corresponding Opportunities
	 * @param startDate
	 * @param endDate
	 * @param campaigns
	 * @return
	 */
	public Map<String, List<String>> getAssetsAndOpprtunities(List<String> campaigns){

		Map<String, List<String>> assetsAndOpportunities = new HashMap<>();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();

		if(CollectionUtils.isNotEmpty(campaigns)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, campaigns));
		}else{
			List<String> mapCampaigns =  mapCampaignService.getMarketingSubCampaigns();
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
		}

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setScroll(new TimeValue(6000)).setSize(1000)
				.setSearchType(SearchType.SCAN)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));


		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);

		if(opportunityRespose != null) {
			while(true) {
				for (SearchHit hit : opportunityRespose.getHits()) {
					CrmOpportunity crmOpportunity = (CrmOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex());
					String asset = crmOpportunity.getAssetsCombined().trim().toLowerCase();
					if(assetsAndOpportunities.containsKey(asset)){
						assetsAndOpportunities.get(asset).add(crmOpportunity.getOpportunityId());
					}else{
						assetsAndOpportunities.put(asset, new ArrayList<>(Arrays.asList(crmOpportunity.getOpportunityId())));
					}
				}
				opportunityRespose = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000)).get();
				if(opportunityRespose.getHits().getHits().length == 0) {
					break;
				}
			}
		}

		return assetsAndOpportunities;
	}


	/**
	 * Get Won Top CRM Opportunities by revenue
	 * @param startDate
	 * @param endDate
	 * @param size
	 * @return
	 */
	public Map<String, Double> getTopWonCRMOpportunities(final int size, List<String> opportunities) {
		BoolFilterBuilder boolFilterBuilder = null;

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setSize(0)
				//.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION).field(CRMConstants.OPPORTUNITY_ID_RAW).size(0)
						.order(Terms.Order.aggregation(SearchConstants.INVOICE_AMOUNT_AGGREGATION, false))
						.subAggregation(AggregationBuilders.sum(SearchConstants.INVOICE_AMOUNT_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT)));

		if(CollectionUtils.isNotEmpty(opportunities)) {
			boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		} else {
			searchRequestBuilder.setQuery(QueryBuilders.matchAllQuery());
		}

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Terms opportunityTerms = searchResponse.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
		Collection<Terms.Bucket> opportunityBuckets = opportunityTerms.getBuckets();
		int index = 0;
		Map<String, Double> topOpportunitiesByRevenue = new LinkedHashMap<>();
		for(Terms.Bucket opportunityBucket: opportunityBuckets) {
			String opporutnityId = opportunityBucket.getKey();
			Sum salesAmountAggregation = opportunityBucket.getAggregations().get(SearchConstants.INVOICE_AMOUNT_AGGREGATION);
			double salesAmount = salesAmountAggregation.getValue();
			topOpportunitiesByRevenue.put(opporutnityId, salesAmount);
			if(index == size-1) {
				break; // breaking the loop if the number of opportunities are greater than size
			}
			index++;
		}
		return topOpportunitiesByRevenue;
	}

	/**
	 * This is to find the top won opportunities by revenue with in the fiscal date for other than 1 plus year.
	 * for 1 plus year the date should be passed explicitly
	 * @param startDate
	 * @param endDate
	 * @param size
	 * @return
	 */
	public Map<String, Double> getTopWonCRMOpportunitiesWithInFiscal(String startDate, String endDate, final int size) {
		if(StringUtils.isBlank(startDate) && StringUtils.isBlank(endDate)) { // To this method if the filter is 1 plus year then dates are passed otherwise fiscal date will be considered
			FiscalDatesStrData fiscalDatesStrData = manualAccountStrategyService.get1YearDatesStr();
			startDate = fiscalDatesStrData.getFiscalStartDateStr();
			endDate = fiscalDatesStrData.getFiscalEndDateStr();
		}

		List<String> opportunities = this.getWonOpportunitiesClosedInDaterange(startDate, endDate);
		return getTopWonCRMOpportunities(size, opportunities);
	}
	/**
	 * Find Marketing Influenced Opportunities from the list of opportunities
	 * @param opportunities
	 * @return
	 */
	public List<CrmOpportunity> findMarketingInfluencedOpportunities(Collection<String> opportunities) {
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		List<String> marketingCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(opportunities.size())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<CrmOpportunity> miOpportunities = new ArrayList<>();
		for(SearchHit hit: searchResponse.getHits()) {
			miOpportunities.add((CrmOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
		}
		
		return miOpportunities;
	}
	
	/**
	 * Find Marketing Influenced Opportunities from the list of opportunities
	 * @param opportunities
	 * @return
	 */
	public List<String> findMarketingInfluencedOpportunityId(Collection<String> opportunities) {
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		List<String> marketingCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(opportunities.size())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> miOpportunities = new ArrayList<>();
		for(SearchHit hit: searchResponse.getHits()) {
			CrmOpportunity oppt =(CrmOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex());
			if(oppt != null) {
				miOpportunities.add(oppt.getOpportunityId());
			}
		}
		
		return miOpportunities;
	}
	
	/**
	 * Get Sales generated Opportunities for the list of opportunities
	 * @param opportunities
	 * @return
	 */
	public List<String> findSalesGeneratedOpportunityId(Collection<String> opportunities) {
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		List<String> marketingCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(opportunities.size())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> sgOpportunities = new ArrayList<>();
		for(SearchHit hit: searchResponse.getHits()) {
			CrmOpportunity oppt =(CrmOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()); 
			sgOpportunities.add(oppt.getOpportunityId());
		}
		
		return sgOpportunities;
	}

	/**
	 * Get Sales generated Opportunities for the list of opportunities
	 * @param opportunities
	 * @return
	 */
	public List<CrmOpportunity> findSalesGeneratedOpportunities(Collection<String> opportunities) {
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		List<String> marketingCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(opportunities.size())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<CrmOpportunity> sgOpportunities = new ArrayList<>();
		for(SearchHit hit: searchResponse.getHits()) {
			sgOpportunities.add((CrmOpportunity) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
		}
		
		return sgOpportunities;
	}

	/**
	 * Get Month wise Opportunities  information with in date range.
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<Integer, List<String>> getMonthWiseOpportunities(final String startDate, final String endDate, boolean isMarketing) {
		Client client = getTransportClient();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).gt(startDate).lt(endDate));
		}

		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(SearchConstants.CREATED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate);
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.addAggregation(dateAggregation)
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.QUERY_AND_FETCH);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		//LOGGER.info("SearchRequestBuilder :" + searchRequestBuilder);

		InternalHistogram dateHistogram = searchResponse.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
		Collection<InternalHistogram.Bucket> termsBuckets = dateHistogram.getBuckets();
		Calendar monthStart = Calendar.getInstance();
		Calendar monthEnd = Calendar.getInstance();
		Map<Integer, List<String>> opportunitiesByMonth = new LinkedHashMap<>();
		String monthStartStr;
		String monthEndStr;
		int count = 0;
		for (InternalHistogram.Bucket dateBucket : termsBuckets) {
			monthStart.setTime(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					dateBucket.getKeyAsText().toString()));
			//int month = monthStart.get(Calendar.MONTH);
			monthEnd.setTime(monthStart.getTime());
			monthEnd.set(Calendar.DAY_OF_MONTH, monthStart.getActualMaximum(Calendar.DAY_OF_MONTH));
			monthStartStr = MiriDateUtils.parseDateToString(monthStart, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			monthEndStr = MiriDateUtils.parseDateToString(monthEnd, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			boolFilterBuilder = FilterBuilders.boolFilter();

			List<String> opportunities;
			if(isMarketing){
				opportunities = this.getMarketingInfluencedOpportunites(monthStartStr, monthEndStr);
			}else
				opportunities = this.getSalesGeneratedOpportunites(monthStartStr, monthEndStr);
			opportunitiesByMonth.put(count, opportunities);
			count++;
		}
		return opportunitiesByMonth;
	}

	/**
	 * Get Deals by sales for opportunities
	 * @param opportunityIds
	 * @return
	 */
	public List<FilterData> getDealsBySalesPersonForOpportunities(List<String> opportunityIds, int size) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds)))
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.SALES_PERSON_AGGREGATION).field(CRMConstants.OPPORTUNITY_OWNER_RAW).size(0).minDocCount(1));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Terms salesPersonTerms = searchResponse.getAggregations().get(SearchConstants.SALES_PERSON_AGGREGATION);
		Collection<Terms.Bucket> salesPersonBuckets = salesPersonTerms.getBuckets();
		long maxHits = 0;
		for(Terms.Bucket bucket: salesPersonBuckets) {
			maxHits = bucket.getDocCount();
			break;
		}
		searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds)))
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.SALES_PERSON_AGGREGATION).field(CRMConstants.OPPORTUNITY_OWNER_RAW).size(0).minDocCount(1)
						.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITY_HITS).setSize((int) maxHits)));
		searchResponse = esQueryUtils.execute(searchRequestBuilder);
		salesPersonTerms = searchResponse.getAggregations().get(SearchConstants.SALES_PERSON_AGGREGATION);
		salesPersonBuckets = salesPersonTerms.getBuckets();
		List<FilterData> salesPersonDeals = new ArrayList<>();
		FilterData filterData;
		List<String> opportunityids;
		for(Terms.Bucket bucket: salesPersonBuckets) {
			filterData = new FilterData();
			filterData.setName(bucket.getKey());
			TopHits topHits = bucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITY_HITS);
			opportunityids = new ArrayList<>();
			for(SearchHit hit: topHits.getHits()) {
				opportunityids.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			double revenueAmont = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityids, null, null);
			filterData.setDeals(bucket.getDocCount());
			filterData.setRevenue(revenueAmont);
			salesPersonDeals.add(filterData);
		}
		Collections.sort(salesPersonDeals);
		if(salesPersonDeals.size() > size) {
			return salesPersonDeals.subList(0, size);
		} else {
			return salesPersonDeals;
		}
	}

	/**
	 * Get Campaign deals
	 * @param opportunityIds
	 * @return
	 */
	public List<FilterData> getDealsByCampaignForOpportunities(List<String> opportunityIds, int size) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds)))
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION).field(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW).size(0).minDocCount(1));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Terms campaignTerms = searchResponse.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
		Collection<Terms.Bucket> campaignBuckets = campaignTerms.getBuckets();
		long maxHits = 0;
		for(Terms.Bucket bucket: campaignBuckets) {
			maxHits = bucket.getDocCount();
			break;
		}

		searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds)))
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION)
						.field(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW).size(0).minDocCount(1)
						.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITY_HITS).setSize((int) maxHits)));
		searchResponse = esQueryUtils.execute(searchRequestBuilder);
		campaignTerms = searchResponse.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
		campaignBuckets = campaignTerms.getBuckets();
		List<FilterData> campaignDeals = new ArrayList<>();
		List<String> opportunityids;
		FilterData filterData;
		for(Terms.Bucket bucket: campaignBuckets) {
			String campaignname = crmCampaignService.getCampaignNamebyPrimaryCampaignSource(bucket.getKey());
			filterData = new FilterData();
			filterData.setName(campaignname);
			filterData.setDeals(bucket.getDocCount());

			TopHits topHits = bucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITY_HITS);
			opportunityids = new ArrayList<>();
			for(SearchHit hit: topHits.getHits()) {
				opportunityids.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			double revenueAmont = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityids, null, null);
			filterData.setRevenue(revenueAmont);
			campaignDeals.add(filterData);
		}
		Collections.sort(campaignDeals);
		if(campaignDeals.size() > size) {
			return campaignDeals.subList(0, size);
		} else {
			return campaignDeals;
		}
	}

	/**
	 * Returns the count of unique accounts associated with "Won and Closed"
	 * Opportunities with opportunity type as 'new' in the review period
	 * mentioned.
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @return count of new customers
	 */
	public Number getNewCustomers(final String reviewStartDate, final String reviewEndDate) {
		Client client = getTransportClient();

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termFilter(SearchConstants.OPPORTUNITY_TYPE_RAW, SearchConstants.CUSTOMER_TYPE_NEW))
		.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()))
		.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(reviewStartDate).lte(reviewEndDate));

		CardinalityBuilder countClause = AggregationBuilders.cardinality(GROUPNAME_NUMCUSTOMER).field(SearchConstants.ACCOUNT_ID_RAW);


		SearchRequestBuilder searchBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(countClause);
		//LOG.info("Net New Customers :" + searchBuilder);
		SearchResponse searchResponse = esQueryUtils.execute(searchBuilder);

		InternalCardinality count = searchResponse.getAggregations().get(GROUPNAME_NUMCUSTOMER);

		return Long.valueOf(count.getValue());
	}

	/**
	 * Returns the count of "Won and Closed" Opportunities in the review period
	 * mentioned.
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @return count of "Won and Closed" opportunities
	 */
	public Number getNumDealsClosed(final String reviewStartDate, final String reviewEndDate) {
		Client client = getTransportClient();

		BoolQueryBuilder conditionClause = QueryBuilders.boolQuery();
		conditionClause.must(QueryBuilders.termsQuery(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()))
		.must(QueryBuilders.rangeQuery(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(reviewStartDate).lte(reviewEndDate));

		CountRequestBuilder countBuilder = client.prepareCount(getIndex())
				.setTypes(getDocumentType())
				.setQuery(conditionClause);


		CountResponse countResponse = countBuilder.execute().actionGet();
		long count = countResponse.getCount();

		return Long.valueOf(count);
	}


	/**
	 * Returns the unique account ids from the "Won and Closed" Opportunities
	 * in the review period mentioned.
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @return count of unique accounts for "Won and Closed" opportunities
	 */
	public Map<String, Set<String>> getUniqueAccountsInOpportunities(final String reviewStartDate, final String reviewEndDate) {
		Set<String> uniqueAccounts = Collections.emptySet();
		Set<String> uniqueCampaigns = Collections.emptySet();
		// Handled the sales stages mapping in the called method
		SearchRequestBuilder searchRequestBuilder = getAccountsByOpportunityQueryForAssess(reviewStartDate, reviewEndDate, OpportunityStagesEnum.CLOSED_WON.getText());
		//LOG.trace("UniqueAccountsInOpportunities : Query : " + searchRequestBuilder);
		Aggregations aggregations = searchRequestBuilder.get().getAggregations();

		Terms accountTerms = aggregations.get(SearchConstants.ACCOUNT_AGGREGATION);
		Collection<Terms.Bucket> accountBuckets = accountTerms.getBuckets();

		Terms campaignTerms = aggregations.get(SearchConstants.CAMPAIGN_AGGREGATION);
		Collection<Terms.Bucket> campaignBuckets = campaignTerms.getBuckets();

		if (CollectionUtils.isNotEmpty(accountBuckets)) {
			uniqueAccounts = new HashSet<>();
			for (Terms.Bucket bucket : accountBuckets) {
				String accountId = bucket.getKey();
				if (StringUtils.isNotBlank(accountId)) {
					uniqueAccounts.add(accountId);
				}
			}
		}

		if (CollectionUtils.isNotEmpty(campaignBuckets)) {
			uniqueCampaigns = new HashSet<>();
			for (Terms.Bucket bucket : campaignBuckets) {
				String campaignId = bucket.getKey();
				if (StringUtils.isNotBlank(campaignId)) {
					uniqueCampaigns.add(campaignId);
				}
			}
		}

		Map<String, Set<String>> accountsAndCampaigns = new HashMap<>();
		accountsAndCampaigns.put(SearchConstants.CAMPAIGNS, uniqueCampaigns);
		accountsAndCampaigns.put(SearchConstants.ACCOUNTS, uniqueAccounts);

		return accountsAndCampaigns;
	}
	
	
	/**
	 * Returns the unique account ids from the "Won and Closed" Opportunities
	 * in the review period mentioned.
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @return count of unique accounts for "Won and Closed" opportunities
	 */
	public Map<String, Set<String>> getUniqueAccountsInOpportunitiesForAvgCost(final String reviewStartDate, final String reviewEndDate) {
		Set<String> uniqueAccounts = Collections.emptySet();
		Set<String> uniqueCampaigns = Collections.emptySet();
		// Handled the sales stages mapping in the called method
		SearchRequestBuilder searchRequestBuilder = getAccountsByOpportunityForAssess(reviewStartDate, reviewEndDate, OpportunityStagesEnum.CLOSED_WON.getText());
		//LOG.trace("UniqueAccountsInOpportunities : Query : " + searchRequestBuilder);
		Aggregations aggregations = searchRequestBuilder.get().getAggregations();
		
		Terms accountTerms = aggregations.get(SearchConstants.ACCOUNT_AGGREGATION);
		Collection<Terms.Bucket> accountBuckets = accountTerms.getBuckets();
		
		Terms campaignTerms = aggregations.get(SearchConstants.CAMPAIGN_AGGREGATION);
		Collection<Terms.Bucket> campaignBuckets = campaignTerms.getBuckets();
		
		if (CollectionUtils.isNotEmpty(accountBuckets)) {
			uniqueAccounts = new HashSet<>();
			for (Terms.Bucket bucket : accountBuckets) {
				String accountId = bucket.getKey();
				if (StringUtils.isNotBlank(accountId)) {
					uniqueAccounts.add(accountId);
				}
			}
		}
		
		if (CollectionUtils.isNotEmpty(campaignBuckets)) {
			uniqueCampaigns = new HashSet<>();
			for (Terms.Bucket bucket : campaignBuckets) {
				String campaignId = bucket.getKey();
				if (StringUtils.isNotBlank(campaignId)) {
					uniqueCampaigns.add(campaignId);
				}
			}
		}
		
		Map<String, Set<String>> accountsAndCampaigns = new HashMap<>();
		accountsAndCampaigns.put(SearchConstants.CAMPAIGNS, uniqueCampaigns);
		accountsAndCampaigns.put(SearchConstants.ACCOUNTS, uniqueAccounts);
		
		return accountsAndCampaigns;
	}

	/**
	 * Returns the count of all Opportunities created in the review period
	 * mentioned.
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @return count of all opportunities in given period
	 */
	public Long getNumOpportunitiesCreated(final String reviewStartDate, final String reviewEndDate) {
		Client client = getTransportClient();

		BoolQueryBuilder conditionClause = QueryBuilders.boolQuery();
		conditionClause.must(QueryBuilders.rangeQuery(SearchConstants.CREATED_ON)
				.gte(reviewStartDate)
				.lte(reviewEndDate));

		CountRequestBuilder countBuilder = client.prepareCount(getIndex())
				.setTypes(getDocumentType())
				.setQuery(conditionClause);


		CountResponse countResponse = countBuilder.execute().actionGet();
		long count = countResponse.getCount();

		return Long.valueOf(count);
	}


	//	/**
	//	 * Get All the Industries by Revenue with the Time Frame
	//	 * @param startDate
	//	 * @param endDate
	//	 * @return
	//	 */
	//	public Map<String, Object> getAllIndustriesByRevenueWithInTimeFrame(final String startDate, final String endDate) {
	//		TimerUtil timerUtil = new TimerUtil();
	//		LOG.info("Top Industries :" );
	//
	//		Map<String, Object> topIndustriesMap = new HashMap<>();
	//		timerUtil.start();
	//		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
	//				.setTypes(getDocumentType())
	//				/*.setQuery(QueryBuilders.termsQuery(CRMConstants.ACCOUNT_ID_RAW, accountIds))*/
	//				.addAggregation(AggregationBuilders.terms(SearchConstants.INDUSTRY_AGGREGATION).field(CRMConstants.ACCOUNT_INDUSTRY_RAW).size(0));
	//
	//		Aggregations aggregations = searchRequestBuilder.get().getAggregations();
	//		//ExecutorService executorService =  Executors.newFixedThreadPool(70);
	//		Terms  industryTerms = aggregations.get(SearchConstants.INDUSTRY_AGGREGATION);
	//
	//		Collection<Terms.Bucket> industryBuckets = industryTerms.getBuckets();
	//		LOG.info("Industtry Terms :");
	//		for(final Terms.Bucket industryBucket: industryBuckets) {
	//			LOG.info(industryBucket.getKey());
	//			// get accounts based on industry
	//			List<String> accountIds = crmAccountService.getAccountIdsByIndustry(industryBucket.getKey());
	//
	//			LOG.info(accountIds.size());
	//			List<String> wonOpportunityIds = this.getOpportunitiesByAccountIdsAndStage(accountIds, OpportunityStagesEnum.CLOSED_WON.getText(), null, null, null);
	//			List<String> lostOpportunityIds = this.getOpportunitiesByAccountIdsAndStage(accountIds, OpportunityStagesEnum.CLOSED_LOST.getText(), null, null, null);
	//			LOG.info("Opportunity Ids :" + wonOpportunityIds.size());
	//			double revenueAmount = this.erpInvoiceService.getInvoiceAmountByOpportunityIds(wonOpportunityIds, startDate, endDate);
	//			LOG.info("revenue Amount :" + revenueAmount);
	//			RevenueOpportunitiesData revenueOpportunitiesData = new RevenueOpportunitiesData();
	//			revenueOpportunitiesData.setOpportunityIds(wonOpportunityIds);
	//			revenueOpportunitiesData.setRevenueAmount(revenueAmount);
	//			revenueOpportunitiesData.setLostOpportunityIds(lostOpportunityIds);
	//			topIndustriesMap.put(industryBucket.getKey(), revenueOpportunitiesData);
	//		}
	//
	//		LOG.debug("Processed accounts data :" + timerUtil.timeTakenInMillis());
	//		return MiriSearchUtils.sortMapByObjectValue(topIndustriesMap);
	//		/*
	//
	//		topIndustriesMap = new ConcurrentHashMap<>();
	//		SearchRequestBuilder searchRequestBuilder = this.getAccountsByOpportunityQuery(startDate, endDate,
	//				OpportunityStagesEnum.CLOSED_WON.getText());
	//		ExecutorService executorService =  Executors.newFixedThreadPool(70);
	//		Aggregations aggregations = searchRequestBuilder.get().getAggregations();
	//		Terms accoountTerms = aggregations.get(SearchConstants.ACCOUNT_AGGREGATION);
	//		Collection<Terms.Bucket> accountBuckets = accoountTerms.getBuckets();
	//
	//		for (final Terms.Bucket accountBucket : accountBuckets) {
	//
	//			executorService.submit(new Runnable() {
	//				@Override
	//				public void run() {// passing null opportunityIids to get complete industries information
	//					updateTopIndustriesMap(startDate, endDate, accountBucket.getKey(),
	//							OpportunityStagesEnum.CLOSED_WON.getText(), null);
	//				}
	//			});
	//
	//		}
	//
	//		executorService.shutdown();
	//		try {
	//			if(!executorService.awaitTermination(1, TimeUnit.MINUTES))
	//				executorService.shutdownNow();
	//		}
	//		catch (InterruptedException e) {
	//			LOG.error("Interruped Exception while updating the campaigns map:" + e.getMessage());
	//		}
	//		return MiriSearchUtils.sortMapByObjectValue(topIndustriesMap);*/
	//	}

	/**
	 * Gets all the opportunities of a parent Campaign
	 * @param parentCampaignId
	 * @return
	 */
	public List<String> getAllOpportunitiesByParentCampaignId(String parentCampaignId, List<String> opportunities, List<String> stages) {

		Map<String, String> subCampaigns = this.crmCampaignService.getSubCampaigns(parentCampaignId);
		List<String> campaignIds = new ArrayList<>(subCampaigns.keySet());
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();

		if(CollectionUtils.isNotEmpty(campaignIds)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, campaignIds));
		} else {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, CollectionUtils.EMPTY_COLLECTION));
		}
		if(CollectionUtils.isNotEmpty(stages)) {
			List<String> mappedStages = new ArrayList<>();
			for(String stage: stages) {
				mappedStages.addAll(appSalesStageContainer.getMappedSaleStage(stage));
			}
			if(CollectionUtils.isNotEmpty(mappedStages)) {
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, mappedStages));
			}
		}

		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSize(1000);

		List<String> crmOpportunities = new ArrayList<>();
		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		if(opportunityRespose != null) {
			while(true) {
				for (SearchHit hit : opportunityRespose.getHits()) {
					crmOpportunities.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
				}
				SearchScrollRequestBuilder  searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000));
				opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
				if(opportunityRespose.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		return crmOpportunities;
	}


	/**
	 * Gets all the opportunities of a parent Campaign
	 * @param parentCampaignId
	 * @return
	 */
	public List<String> getAllOpportunitiesByParentCampaignIdFromOpportunities(String parentCampaignId, List<String> overAllOpportunities) {
		return this.getAllWonOpportunitiesByParentCampaignIdFromOpportunitiesByStage(parentCampaignId, overAllOpportunities, null, null, null);

	}
	/**
	 * Gets all the opportunities of a parent Campaign
	 * @param parentCampaignId
	 * @return
	 */
	public List<String> getAllWonOpportunitiesByParentCampaignIdFromOpportunitiesByStage(String parentCampaignId,
			List<String> overAllOpportunities, String stage,
			String startDate, String endDate) {
		Map<String, String> subCampaigns = this.crmCampaignService.getSubCampaigns(parentCampaignId);
		List<String> campaignIds = new ArrayList<>(subCampaigns.keySet());
		BoolFilterBuilder boolFilterBuilder = null;
		if(CollectionUtils.isNotEmpty(campaignIds)) {
			boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, campaignIds));
		}
		if(CollectionUtils.isNotEmpty(overAllOpportunities)){
			if(null == boolFilterBuilder){
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, overAllOpportunities));
		}
		if(StringUtils.isNotBlank(stage)){
			if(null == boolFilterBuilder){
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			if(null == boolFilterBuilder){
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).from(startDate).to(endDate));
		}


		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000));
		if(null != boolFilterBuilder){
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		}

		List<String> crmOpportunities = new ArrayList<>();
		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);
		if(opportunityRespose != null) {
			while(true) {
				for (SearchHit hit : opportunityRespose.getHits()) {
					crmOpportunities.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
				}
				SearchScrollRequestBuilder  searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000));
				opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
				if(opportunityRespose.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		return crmOpportunities;
	}

	/**
	 * Get New customers Won opportunities
	 * @param startDate
	 * @param endDate
	 */
	public List<String> getOpportunititesByopportunityType(String opportunityType,List<String> opportunities){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_TYPE_RAW, opportunityType));
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunityIds = new ArrayList<>();
		while (true) {
			for (SearchHit hit : searchResponse.getHits()) {
				opportunityIds.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}

		}
		return opportunityIds;
	}

	/**
	 * This method is used to get Won New and existing opportunities Between dates
	 * @return
	 * 		{@link Map}
	 */
	public Map<String, List<String>> getNewAndExistingOpportunities(){
		Map<String, List<String>> mapOfNewAndExistingOpportunities = new HashMap<>();
		mapOfNewAndExistingOpportunities.put(SearchConstants.OPPORTUNITY_TYPE_NEW,
				getOpportunititesByopportunityType(SearchConstants.OPPORTUNITY_TYPE_NEW,null));
		mapOfNewAndExistingOpportunities.put(SearchConstants.OPPORTUNITY_TYPE_EXISTING,
				getOpportunititesByopportunityType(SearchConstants.OPPORTUNITY_TYPE_EXISTING,null));
		return mapOfNewAndExistingOpportunities;
	}

	/**
	 * Get Month wise opportunities in closed date range
	 * @param startDate
	 * @param endDate
	 * @param stage
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, List<String>> getMonthWiseMiOpportunitesByCloseDateRange(final String startDate, final String endDate, String stage) {
		Client client = getTransportClient();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate));
		}

		List<String> subCamapigns =  mapCampaignService.getMarketingSubCampaigns();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapigns));

		if(StringUtils.isNotBlank(stage)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}

		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(CRMConstants.OPPORTUNITY_CLOSED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate);
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.addAggregation(dateAggregation)
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		InternalHistogram dateHistogram = searchResponse.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
		Collection<InternalHistogram.Bucket> termsBuckets = dateHistogram.getBuckets();
		Calendar monthStart = Calendar.getInstance();
		Calendar monthEnd = Calendar.getInstance();
		Map<Integer, List<String>> opportunitiesByMonth = new LinkedHashMap<>();
		String monthStartStr;
		String monthEndStr;
		int count = 0;
		List<String> opportunities;
		for (InternalHistogram.Bucket dateBucket : termsBuckets) {
			monthStart.setTime(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					dateBucket.getKeyAsText().toString()));
			//int month = monthStart.get(Calendar.MONTH);
			monthEnd.setTime(monthStart.getTime());
			monthEnd.set(Calendar.DAY_OF_MONTH, monthStart.getActualMaximum(Calendar.DAY_OF_MONTH));
			monthStartStr = MiriDateUtils.parseDateToString(monthStart, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			monthEndStr = MiriDateUtils.parseDateToString(monthEnd, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(monthStartStr).lte(monthEndStr));
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapigns));
			searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
					.setSize((int) dateBucket.getDocCount())
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
			searchResponse = esQueryUtils.execute(searchRequestBuilder);
			opportunities = new ArrayList<>();
			for(SearchHit hit: searchResponse.getHits()) {
				opportunities.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			opportunitiesByMonth.put(count, opportunities);
			count++;
		}
		return opportunitiesByMonth;
	}

	/**
	 * Calculate the weighted average of campaign
	 * @param opportunityIds
	 * @return
	 */
	public double calculateCampaignWeightedAverageTime(List<String> opportunityIds) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION).field(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW).size(0));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Terms campaignTerms = searchResponse.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
		Collection<Terms.Bucket> campaignBuckets = campaignTerms.getBuckets();
		long weightedSum = 0;
		long weightedCount = 0;

		for(Terms.Bucket campaignBucket: campaignBuckets) {
			long campaignStartDate = mapCampaignService.getCampaignStartDateByCampaignId(campaignBucket.getKey());
			weightedSum += campaignStartDate * campaignBucket.getDocCount();
			weightedCount += campaignBucket.getDocCount();
		}
		if(weightedCount != 0) {
			return weightedSum / weightedCount;
		} else {
			return 0;
		}
	}

	/**
	 * Calculate the campaign average time
	 * @param opportunityIds
	 * @return
	 */
	public double calculateCampaignAverageTime(List<String> opportunityIds) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION).field(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW).size(0));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Terms campaignTerms = searchResponse.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
		Collection<Terms.Bucket> campaignBuckets = campaignTerms.getBuckets();
		//LOG.info("campaignBuckets :" + campaignBuckets.size());
		List<String> campaignIds = new ArrayList<>();
		for(Terms.Bucket campaignBucket: campaignBuckets) {
			campaignIds.add(campaignBucket.getKey());
		}
		//LOG.info(campaignIds);
		searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.MAP.getText())
				.setTypes(ElasticSearchEnums.MAP_CAMPAIGN.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_ID_RAW, campaignIds)))
				.addAggregation(AggregationBuilders.avg(SearchConstants.AVG_AGGREGATION).field(CRMConstants.CAMPAIGN_START_DATE));
		searchResponse = esQueryUtils.execute(searchRequestBuilder);
		return AggregationUtil.getAggregationValue(searchResponse, SearchConstants.AVG_AGGREGATION, SearchConstants.AVG_AGGREGATION_TYPE);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, List<String>> getMonthWiseOpportunityForCampaignWithInDateRange(List<String> campaignId,
			String startDate, String endDate) {
		Client client = getTransportClient();
		//Map<String, String> subCampaigns = crmCampaignService.getSubCampaigns(campaignId);
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		FilterBuilder opportunityQueryBuilder = FilterBuilders.termsFilter(SearchConstants.PRIMARY_CAMP_SOURCE, campaignId);

		FilterBuilder rangeQueryBuilder = FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate);
		boolFilter.must(opportunityQueryBuilder);
		boolFilter.must(rangeQueryBuilder);
		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(CRMConstants.OPPORTUNITY_CLOSED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate);

		SearchRequestBuilder srb = client.prepareSearch(SearchConstants.CRM).setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(dateAggregation);
		SearchResponse searchResponse = esQueryUtils.execute(srb);
		InternalHistogram dateHistogram = searchResponse.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
		Collection<InternalHistogram.Bucket> termsBuckets = dateHistogram.getBuckets();
		Calendar monthStart = Calendar.getInstance();
		Calendar monthEnd = Calendar.getInstance();
		Map<Integer, List<String>> opportunitiesByMonth = new LinkedHashMap<>();
		String monthStartStr;
		String monthEndStr;
		int count = 0;
		List<String> opportunities;
		for (InternalHistogram.Bucket dateBucket : termsBuckets) {
			monthStart.setTime(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					dateBucket.getKeyAsText().toString()));
			//int month = monthStart.get(Calendar.MONTH);
			monthEnd.setTime(monthStart.getTime());
			monthEnd.set(Calendar.DAY_OF_MONTH, monthStart.getActualMaximum(Calendar.DAY_OF_MONTH));
			monthStartStr = MiriDateUtils.parseDateToString(monthStart, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			monthEndStr = MiriDateUtils.parseDateToString(monthEnd, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
			boolFilter = FilterBuilders.boolFilter();
			boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(monthStartStr).lte(monthEndStr));
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, campaignId));
			srb = client.prepareSearch(getIndex()).setTypes(getDocumentType())
					.setSize((int) dateBucket.getDocCount())
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
			searchResponse = esQueryUtils.execute(srb);
			opportunities = new ArrayList<>();
			for(SearchHit hit: searchResponse.getHits()) {
				opportunities.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			opportunitiesByMonth.put(count, opportunities);
			count++;
		}
		return opportunitiesByMonth;
	}
	/**
	 * Gets the Campaigns and Opprtunities By month leads
	 * @param campaignId
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public SearchResponse getCamapignsAndOpportunitiesByMonth(String campaignId, String startDate, String endDate){
		Map<String, String> subCampaigns = crmCampaignService.getSubCampaigns(campaignId);
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, subCampaigns.keySet()));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(startDate).to(endDate));

		AbstractAggregationBuilder subaggregation = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW).size(0);

		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.CAMPAIGN_AGGREGATION).field(CRMConstants.OPPORTUNITY_CLOSED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate).subAggregation(subaggregation);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.addAggregation(dateAggregation)
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		return searchResponse;

	}

	/**
	 * Gets the Average customer cost
	 * @param startDate
	 * @param endDate
	 * @param parenCampaign
	 * @param totalCountMap
	 * @param totalCostMap
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public MarketingCampaignTrendData getCustomersByMonthForCampaigns(String startDate, String endDate, String parenCampaign){
		Map<String, String> subCampaignsMap = crmCampaignService.getSubCampaigns(parenCampaign);
		Map<Integer, Long> CustomersByMonth =  new HashMap<>();
		Map<Integer, TreeSet<String>> campaignsByMonth =  new HashMap<>();
		MarketingCampaignTrendData marketingCampaignTrendData =  null;
		Map<Integer, String> updatedDates = MiriDateUtils.getUpdatedDates(startDate, endDate);
		for(Entry<String, String> subCampaign :  subCampaignsMap.entrySet()){
			marketingCampaignTrendData =  new MarketingCampaignTrendData();
			List<String> opportunities = getOpportunitiesBySubCampaignId(subCampaign.getKey());
			SearchResponse searchResponse = erpInvoiceService.getNumberOfCustomersByMonth(opportunities, startDate, endDate);
			InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
			Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
			int count = 0;
			for (InternalHistogram.Bucket bucket : buckets) {
				if(updatedDates.containsKey(count)){
					Terms campaigns = bucket.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
					int numberOfCustomers = campaigns.getBuckets().size();
					if(numberOfCustomers > 0){
						if(campaignsByMonth.containsKey(count)){
							campaignsByMonth.get(count).add(subCampaign.getKey());
						}else
							campaignsByMonth.put(count, new TreeSet<>(Arrays.asList(subCampaign.getKey())));
					}
					if(CustomersByMonth.containsKey(count)){
						CustomersByMonth.put(count, CustomersByMonth.get(count)+numberOfCustomers);
					}else
						CustomersByMonth.put(count, (long) numberOfCustomers);
				}else{
					CustomersByMonth.put(count, null);
					campaignsByMonth.put(count, null);
					
				}
				count++;
			}
		}
		marketingCampaignTrendData.setCount(CustomersByMonth);
		Map<Integer, Double> averageCost = getAverageCostFromNumberOfCustomers(campaignsByMonth, CustomersByMonth, parenCampaign, updatedDates);
		marketingCampaignTrendData.setAverageCost(averageCost);
		return marketingCampaignTrendData;
	}


	/**
	 * Calculates the average cost of a customer
	 * @param campaignsByMonth
	 * @param CustomersByMonth
	 * @param parenCampaign
	 * @return
	 */
	public Map<Integer, Double> getAverageCostFromNumberOfCustomers(Map<Integer, TreeSet<String>> campaignsByMonth, Map<Integer, Long> CustomersByMonth, String parenCampaign, Map<Integer, String> updatedDates){

		Map<Integer, Double> averageCostMap =  new HashMap<>();
		double parenerCampaignActualCost = mapCampaignService.getParentCampaignsActualCost(parenCampaign);
		for(Entry<Integer, Long> customers : CustomersByMonth.entrySet()){
			if(updatedDates.containsKey(customers.getKey())){
				double campaignCost=0d;
				if(campaignsByMonth.containsKey(customers.getKey())){
					campaignCost = mapCampaignService.getActualCostOfCamapigns(new ArrayList<String> (campaignsByMonth.get(customers.getKey())));
				}else
					campaignCost = parenerCampaignActualCost;
				double averagecost = 0d;
				if(customers.getValue() > 0){
					averagecost = campaignCost /customers.getValue();
				}else
					averagecost = campaignCost;
				averageCostMap.put(customers.getKey(), averagecost);
			}else
			{
				averageCostMap.put(customers.getKey(), null);
			}
		}
		return averageCostMap;
	}


	/**
	 * Get the list of opportunities by campaign ID
	 * @param campaignId
	 * @return
	 * @author rammoole
	 */
	public List<String> getOpportunitiesBySubCampaignId(String campaignId) {
		// if the passed campaign Id is parent campaign then get all the sub campaigns of that campaign and
		// get the opportunities of that campaign
		List<String> crmOpportunities = null;
		Client client = this.getTransportClient();

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, campaignId));

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);

		if(opportunityRespose != null) {
			crmOpportunities = new ArrayList<>();
			while(true) {
				for (SearchHit hit : opportunityRespose.getHits()) {
					crmOpportunities.add((String) hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
				}
				SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000));
				opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
				if(opportunityRespose.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		return crmOpportunities;
	}

	/**
	 * Get Marketing Influenced / Sales Generated opportunities of the sales person based on the isMarketingInfluenced flag
	 * if the isMarketingInfluenced - true then returns the marketing influenced opportunities of the sales person, otherwise sales generated opportunities.
	 * @param salesPerson
	 * @param startDate
	 * @param endDate
	 * @param isMarketingInfluenced
	 * @return
	 */
	public List<String> getSalesPersonMIOrSGOpportunities(String salesPerson, final String startDate, final String endDate, final boolean isMarketingInfluenced) {
		Client client = getTransportClient();
		List<String> opportunities = new ArrayList<>();

		List<String> marketingCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = null;

		if(CollectionUtils.isNotEmpty(marketingCampaigns)) {
			boolFilterBuilder = FilterBuilders.boolFilter();
			if(isMarketingInfluenced) {
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
			} else {
				boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
			}
		}

		if(StringUtils.isNotBlank(salesPerson)) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_OWNER_RAW, salesPerson));
		}

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN)
				.setSize(600)
				.setScroll(new TimeValue(6000));

		if(boolFilterBuilder == null) {
			searchRequestBuilder.setQuery(QueryBuilders.matchAllQuery());
		} else {
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		}

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		do {
			for (SearchHit hit : searchResponse.getHits().getHits()) {
				opportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
		} while(searchResponse.getHits().getHits().length != 0);

		timeUtil.end();
		//LOG.debug("ES Time getMarketingInfluencedOpportunites" + timeUtil.timeTakenInMillis());
		return opportunities;
	}

	/**
	 * Get Marketing Influenced Revenue of the sales person
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public SalesPersonRevenueData getSalesPersonMIRevenue(String salesPersonName, String startDate, String endDate, List<String> opportunityIds) {
		//List<String> opportunityIds = getSalesPersonMIOrSGOpportunities(salesPersonName, startDate, endDate, SearchConstants.MARKETING_INFLUENCED_FLAG);
		return getSalesPersonData(salesPersonName, startDate, endDate, opportunityIds);
	}

	/**
	 * Get Sales Generated Revenue of the sales person
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public SalesPersonRevenueData getSalesPersonSGRevenue(String salesPersonName, String startDate, String endDate, List<String> opportunityIds) {
		//List<String> opportunityIds = getSalesPersonMIOrSGOpportunities(salesPersonName, startDate, endDate, SearchConstants.SALES_GENERATED_FLAG);
		return getSalesPersonData(salesPersonName, startDate, endDate, opportunityIds);
	}

	/**
	 * Get Overall Sales person Data Object
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @param opportunityIds
	 * @return
	 * @author rammoole
	 */
	private SalesPersonRevenueData getSalesPersonData(String salesPersonName, String startDate, String endDate,
			List<String> opportunityIds) {
		SalesPersonRevenueData salesPersonRevenueData = new SalesPersonRevenueData();
		salesPersonRevenueData.setSalesPersonName(salesPersonName);
		salesPersonRevenueData.setxAxisLabel(salesPersonName);
		if(CollectionUtils.isNotEmpty(opportunityIds)) {
			Double revenueAmount = erpInvoiceService.getInvoiceAmountByOpportunityIdsAndSalesPerson(opportunityIds, startDate, endDate, salesPersonName);
			salesPersonRevenueData.setxAxisParam(revenueAmount);
			salesPersonRevenueData.setRevenue(revenueAmount);
		}
		return salesPersonRevenueData;
	}

	/**
	 *
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public SalesPersonRevenueData getSalesPersonMIAverageDealSize(String salesPersonName, String startDate, String endDate, List<String> opportunityIds) {
		//List<String> opportunityIds = getSalesPersonMIOrSGOpportunities(salesPersonName, startDate, endDate, SearchConstants.MARKETING_INFLUENCED_FLAG);
		return getSalesPersonDataADS(salesPersonName, startDate, endDate, opportunityIds);
	}

	/**
	 * Get Sales Generated Sales Person Average Deals Size
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public SalesPersonRevenueData getSalesPersonSGAverageDealSize(String salesPersonName, String startDate, String endDate, List<String> opportunityIds) {
		//List<String> opportunityIds = getSalesPersonMIOrSGOpportunities(salesPersonName, startDate, endDate, SearchConstants.SALES_GENERATED_FLAG);
		return getSalesPersonDataADS(salesPersonName, startDate, endDate, opportunityIds);
	}

	/**
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @param opportunityIds
	 * @return
	 * @author rammoole
	 */
	private SalesPersonRevenueData getSalesPersonDataADS(String salesPersonName, String startDate, String endDate,
			List<String> opportunityIds) {
		InvoiceStatsData adsAsp = erpInvoiceService.getAdsAspDealsRevenueByOpportunitiesAndSalesPerson(opportunityIds, startDate, endDate, salesPersonName);
		SalesPersonRevenueData salesPersonRevenueData = new SalesPersonRevenueData();
		salesPersonRevenueData.setSalesPersonName(salesPersonName);
		salesPersonRevenueData.setxAxisLabel(salesPersonName);
		//LOG.info("SG - "+ opportunityIds.size());
		if(CollectionUtils.isNotEmpty(opportunityIds)) {
			salesPersonRevenueData.setxAxisParam(adsAsp.getAds());
			salesPersonRevenueData.setRevenue(adsAsp.getRevenueAmount());
			salesPersonRevenueData.setAvgDealSize(adsAsp.getAds());
		}
		return salesPersonRevenueData;
	}

	/**
	 * Deals Closed for Marketing Influenced Sales person
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public SalesPersonRevenueData getSalesPersonMIDealsClosed(final String salesPersonName, final String startDate, final String endDate, final List<String> opportunityIds) {
		//List<String> opportunityIds = getSalesPersonMIOrSGOpportunities(salesPersonName, startDate, endDate, SearchConstants.MARKETING_INFLUENCED_FLAG);
		return getSalesPersonDataDealsClosed(salesPersonName, startDate, endDate, opportunityIds);
	}

	/**
	 * Deals CLosed for Sales Generated Sales person
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public SalesPersonRevenueData getSalesPersonSGDealsClosed(final String salesPersonName, final String startDate, final String endDate, final List<String> opportunityIds) {
		//List<String> opportunityIds = getSalesPersonMIOrSGOpportunities(salesPersonName, startDate, endDate, SearchConstants.SALES_GENERATED_FLAG);
		return getSalesPersonDataDealsClosed(salesPersonName, startDate, endDate, opportunityIds);
	}

	/**
	 * Get Sales Person Data Object for Deals Closed
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @param opportunityIds
	 * @return
	 * @author rammoole
	 */
	private SalesPersonRevenueData getSalesPersonDataDealsClosed(final String salesPersonName, final String startDate, final String endDate,
			final List<String> opportunityIds) {
		InvoiceStatsData adsAsp = erpInvoiceService.getAdsAspDealsRevenueByOpportunitiesAndSalesPerson(opportunityIds, startDate, endDate, salesPersonName);
		SalesPersonRevenueData salesPersonRevenueData = new SalesPersonRevenueData();
		salesPersonRevenueData.setSalesPersonName(salesPersonName);
		salesPersonRevenueData.setxAxisLabel(salesPersonName);
		if(CollectionUtils.isNotEmpty(opportunityIds)) {
			salesPersonRevenueData.setxAxisParam((double)adsAsp.getDealsClosed());
			salesPersonRevenueData.setRevenue(adsAsp.getRevenueAmount());
			salesPersonRevenueData.setNoOfDealsClosed(adsAsp.getDealsClosed());
		}
		return salesPersonRevenueData;
	}

	/**
	 * Get Marketing Influenced Sales person Average Sell price
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public SalesPersonRevenueData getSalesPersonMIAvgSellPrice(final String salesPersonName, final String startDate, final String endDate, final List<String> opportunityIds) {
		//List<String> opportunityIds = getSalesPersonMIOrSGOpportunities(salesPersonName, startDate, endDate, SearchConstants.MARKETING_INFLUENCED_FLAG);
		return getSalesPersonDataASP(salesPersonName, startDate, endDate, opportunityIds);
	}

	/**
	 * Get Sales Person Sales Generated Average Sell Price
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public SalesPersonRevenueData getSalesPersonSGAvgSellPrice(final String salesPersonName, final String startDate, final String endDate, final List<String> opportunityIds) {
		//List<String> opportunityIds = getSalesPersonMIOrSGOpportunities(salesPersonName, startDate, endDate, SearchConstants.SALES_GENERATED_FLAG);
		return getSalesPersonDataASP(salesPersonName, startDate, endDate, opportunityIds);
	}

	/**
	 * Get Sales Person Data Object for Deals Closed
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @param opportunityIds
	 * @return
	 * @author rammoole
	 */
	private SalesPersonRevenueData getSalesPersonDataASP(final String salesPersonName, final String startDate, final String endDate,
			final List<String> opportunityIds) {
		InvoiceStatsData adsAsp = erpInvoiceService.getAdsAspDealsRevenueByOpportunitiesAndSalesPerson(opportunityIds, startDate, endDate, salesPersonName);
		SalesPersonRevenueData salesPersonRevenueData = new SalesPersonRevenueData();
		salesPersonRevenueData.setSalesPersonName(salesPersonName);
		salesPersonRevenueData.setxAxisLabel(salesPersonName);
		if(CollectionUtils.isNotEmpty(opportunityIds)) {
			//LOG.info("SG Revenue :" + revenueAmount);
			salesPersonRevenueData.setxAxisParam(adsAsp.getAsp());
			salesPersonRevenueData.setRevenue(adsAsp.getRevenueAmount());
			salesPersonRevenueData.setAvgSellPrice(adsAsp.getAsp());
		}
		return salesPersonRevenueData;
	}

	/**
	 * Get Marketing Influenced Sales Person's Win Rate
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public SalesPersonRevenueData getSalesPersonMIWinRate(final String salesPersonName, final String startDate, final String endDate, final List<String> opportunityIds) {
		//List<String> opportunityIds = getSalesPersonMIOrSGOpportunities(salesPersonName, startDate, endDate, SearchConstants.MARKETING_INFLUENCED_FLAG);
		return getSalesPersonDataWinRate(salesPersonName, startDate, endDate, opportunityIds, SearchConstants.MARKETING_INFLUENCED_FLAG);
	}

	/**
	 * Get Sales Generated Sales person's Win Rate
	 * @param salesPerson
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public SalesPersonRevenueData getSalesPersonSGWinRate(final String salesPersonName, final String startDate, final String endDate, final List<String> opportunityIds) {
		//List<String> opportunityIds = getSalesPersonMIOrSGOpportunities(salesPersonName, startDate, endDate, SearchConstants.SALES_GENERATED_FLAG);
		return getSalesPersonDataWinRate(salesPersonName, startDate, endDate, opportunityIds, SearchConstants.SALES_GENERATED_FLAG);
	}

	/**
	 * Get Sales Person Win Rate
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @param opportunityIds
	 * @return
	 */
	private SalesPersonRevenueData getSalesPersonDataWinRate(final String salesPersonName, final String startDate, final String endDate,
			final List<String> opportunityIds, final boolean MiOrSgFlag) {
		SalesPersonRevenueData salesPersonRevenueData = getSalesPersonDataDealsClosed(salesPersonName, startDate, endDate, opportunityIds);
		DecimalFormat df = new DecimalFormat("#.00");
		if(salesPersonRevenueData != null) {
			Map<String, Long> countAndAmount = this.getLostOpportunitiesCountAndAmountBySalesPerson(salesPersonName, startDate, endDate, MiOrSgFlag);
			salesPersonRevenueData.setNoOfDealsLost(countAndAmount.get(SearchConstants.COUNT));
			double winPercentage;
			if((salesPersonRevenueData.getNoOfDealsClosed() == null || salesPersonRevenueData.getNoOfDealsClosed() == 0) && (salesPersonRevenueData.getNoOfDealsLost() == null || salesPersonRevenueData.getNoOfDealsLost() == 0)) {
				winPercentage = 0;
			} else {
				winPercentage = ((double) salesPersonRevenueData.getNoOfDealsClosed() / (salesPersonRevenueData.getNoOfDealsLost() + salesPersonRevenueData.getNoOfDealsClosed()))  * 100;
			}
			winPercentage = Double.valueOf(df.format(Double.isNaN(winPercentage) ? 0 : winPercentage));
			salesPersonRevenueData.setxAxisParam(winPercentage);
			salesPersonRevenueData.setWinRate(winPercentage);
		}

		return salesPersonRevenueData;
	}

	/**
	 * Get Lost Opportunities count and Amount by sales person
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Long> getLostOpportunitiesCountAndAmountBySalesPerson(final String salesPersonName, final String startDate, final String endDate, final boolean isMarketingInfluenced) {
		BoolFilterBuilder boolFilterBuilder = null;
		List<String> marketingCampaigns =  mapCampaignService.getMarketingSubCampaigns();

		if(StringUtils.isNotBlank(salesPersonName)) {
			boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_OWNER_RAW, salesPersonName));
		}

		if(CollectionUtils.isNotEmpty(marketingCampaigns)) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			if(isMarketingInfluenced) {
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
			} else {
				boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, marketingCampaigns));
			}
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lt(endDate));
		}
		if(CollectionUtils.isNotEmpty(appSalesStageContainer.getClosedLostMappedStages())) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedLostMappedStages()));
		}

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setSize(0)
				.addAggregation(AggregationBuilders.sum(SearchConstants.AMOUNT_AGGREGATION).field(CRMConstants.OPPORTUNITY_AMOUNT));
		if(boolFilterBuilder != null) {
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		} else {
			searchRequestBuilder.setQuery(QueryBuilders.matchAllQuery());
		}

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		SearchHits searchHits = searchResponse.getHits();
		Sum amountAggr = searchResponse.getAggregations().get(SearchConstants.AMOUNT_AGGREGATION);

		Map<String, Long> countAnAmount = new HashMap<>();
		countAnAmount.put(SearchConstants.COUNT, searchHits.getTotalHits());
		if(amountAggr != null) {
			countAnAmount.put(SearchConstants.AMOUNT, (long) amountAggr.getValue());
		}
		return countAnAmount;
	}

	/**
	 * Get Campaign wise revenue of a sales person
	 * @param salesPerson
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<CampaignRevenueData> getCampaignWiseRevenueBySalesPerson(final String salesPerson, final String startDate,
			final String endDate, final Map<String, String> parentCampaigns) {
		CampaignRevenueData campaignRevenueData;
		List<CampaignRevenueData> campaignRevenueDataList = new ArrayList<>();
		for(Map.Entry<String, String> parentCampaignEntry: parentCampaigns.entrySet()) {
			List<String> opportunities = this.getOpportunityIdsByParentCampaignId(parentCampaignEntry.getKey());
			if(CollectionUtils.isNotEmpty(opportunities)) {
				campaignRevenueData = new CampaignRevenueData();
				campaignRevenueData.setCampaignName(parentCampaignEntry.getValue());
				double revenueAmount = erpInvoiceService.getRevenueForSalesPerson(startDate, endDate, salesPerson, opportunities);
				campaignRevenueData.setRevenueAmount(revenueAmount);
				campaignRevenueDataList.add(campaignRevenueData);
			}
		}
		return campaignRevenueDataList;
	}

	/**
	 * Get Campaign wise win data by opportunities
	 * @param opportunityIds
	 * @param wonOrLost
	 * @return
	 */
	public List<WinLossData> getCampaignWiseWinDataByOpportunities(final List<String> opportunityIds, List<String> lostOpportunities, int size) {
		List<String> totalOpportunities = new ArrayList<>(opportunityIds);
		totalOpportunities.addAll(lostOpportunities);
		int hitsSize = getHitsSize(opportunityIds);
		String[] wonStages = appSalesStageContainer.getClosedWonMappedStages().toArray(new String[appSalesStageContainer.getClosedWonMappedStages().size()]);
		String[] lostStages = appSalesStageContainer.getClosedLostMappedStages().toArray(new String[appSalesStageContainer.getClosedLostMappedStages().size()]);
		appSalesStageContainer.getClosedLostMappedStages().toArray(lostStages);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, totalOpportunities)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION).field(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
						.subAggregation(AggregationBuilders.terms(SearchConstants.WON_AGGREGATION).field(CRMConstants.OPPORTUNITY_STAGE_RAW)
								.include(wonStages)
								.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITIES_AGGREGATION).setSize(hitsSize).setFetchSource(CRMConstants.OPPORTUNITY_ID, null)))
						.subAggregation(AggregationBuilders.terms(SearchConstants.LOST_AGGREGATION).field(CRMConstants.OPPORTUNITY_STAGE_RAW)
								.include(lostStages)
								.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_LOST_OPPORTUNITIES_AGGREGATION).setSize(hitsSize).setFetchSource(CRMConstants.OPPORTUNITY_ID, null))));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		Terms campaignTerms = searchResponse.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
		Collection<Terms.Bucket> campaignBuckets = campaignTerms.getBuckets();
		List<WinLossData> campaignWinLossData = new ArrayList<>();
		WinLossData campaignRevenueData;
		List<String> campaignWonOportunityIds;
		List<String> campaignLostOportunityIds;
		Terms stageTerms;
		double revenueAmount;
		for(Terms.Bucket campaignBucket: campaignBuckets) {
			if(StringUtils.isNotBlank(campaignBucket.getKey())) {
				campaignRevenueData = new WinLossData();
				campaignWonOportunityIds = new ArrayList<>();
				campaignLostOportunityIds = new ArrayList<>();
				stageTerms = campaignBucket.getAggregations().get(SearchConstants.WON_AGGREGATION);
				Collection<Terms.Bucket> stageBuckets = stageTerms.getBuckets();
				for(Terms.Bucket wonBucket: stageBuckets) {
					TopHits topWonHits = wonBucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITIES_AGGREGATION);
					for(SearchHit topHit: topWonHits.getHits()) {
						campaignWonOportunityIds.add(topHit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
					}
				}
				stageTerms = campaignBucket.getAggregations().get(SearchConstants.LOST_AGGREGATION);
				stageBuckets = stageTerms.getBuckets();
				for(Terms.Bucket wonBucket: stageBuckets) {
					TopHits topLostHits = wonBucket.getAggregations().get(SearchConstants.TOP_LOST_OPPORTUNITIES_AGGREGATION);
					for(SearchHit topHit: topLostHits.getHits()) {
						campaignLostOportunityIds.add(topHit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
					}
				}
				revenueAmount= erpInvoiceService.getInvoiceSumForOpportunites(campaignWonOportunityIds);
				campaignRevenueData.setWonAmount(revenueAmount);
				campaignRevenueData.setWonCount((long)campaignWonOportunityIds.size());
				campaignRevenueData.setLostCount((long)campaignLostOportunityIds.size());
				campaignRevenueData.setLostAmount(this.getOpportunityAmountByOpportunities(campaignLostOportunityIds));
				campaignRevenueData.setStackedParamName(crmCampaignService.getCampaignNamebyPrimaryCampaignSource(campaignBucket.getKey()));
				campaignWinLossData.add(campaignRevenueData);
			}
		}
		sortWinLosstByWonAmount(campaignWinLossData);
		if(campaignWinLossData.size() > size) {
			campaignWinLossData = campaignWinLossData.subList(0, size);
		}
		return campaignWinLossData;
	}

	/**
	 * @param opportunityIds
	 * @return
	 */
	private int getHitsSize(final List<String> opportunityIds) {
		int hitsSize = 10;
		if(CollectionUtils.isNotEmpty(opportunityIds)) {
			hitsSize = opportunityIds.size();
		}
		return hitsSize;
	}

	/**
	 * @param campaignWinLossData
	 */
	private void sortWinLosstByWonAmount(List<WinLossData> campaignWinLossData) {
		Collections.sort(campaignWinLossData, new Comparator<WinLossData>() {
			@Override
			public int compare(WinLossData o1, WinLossData o2) {
				if(o1 != null && o2 != null) {
					return Double.compare(o2.getWonAmount(), o1.getWonAmount());
				} else if (o2 == null) {
					return -1;
				} else {
					return 1;
				}
			}
		});
	}

	/**
	 * Get Opportunities by campaign and Sales Person
	 * @param campaignId
	 * @param salesPersonName
	 * @return
	 */
	public List<String> getOpportunityIdsByParentCampaignId(final String campaignId) {
		Map<String, String> subCampaigns = this.crmCampaignService.getSubCampaigns(campaignId);
		List<String> campaignIds = new ArrayList<>(subCampaigns.keySet());
		campaignIds.add(campaignId);
		List<String> crmOpportunities = null;
		Client client = this.getTransportClient();

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, campaignIds));

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN)
				.setSize(500)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse opportunityResponse = esQueryUtils.execute(searchRequestBuilder);
		if(opportunityResponse != null) {
			crmOpportunities = new ArrayList<>();
			while(true) {
				for (SearchHit hit : opportunityResponse.getHits()) {
					crmOpportunities.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
				}
				SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(opportunityResponse.getScrollId()).setScroll(new TimeValue(6000));
				opportunityResponse = esQueryUtils.execute(searchScrollRequestBuilder);
				if(opportunityResponse.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		return crmOpportunities;
	}

	/**
	 * Gets the Opportunities for the List of leads
	 * @param touchpointleads
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getOpportunitiesForLeads(List<MapLead> mapLeads) {
		List<String> accountName = new ArrayList<>();
		List<String> campaignId = new ArrayList<>();
		List<String> leadSource = new ArrayList<>();
		List<String> companyId = new ArrayList<>();
		List<String>  industry = new ArrayList<>();
		List<String> salesPerson = new ArrayList<>();
		for(MapLead lead : mapLeads){
			accountName.add(lead.getCompanyName());
			campaignId.add(lead.getCampaignId());
			leadSource.add(lead.getLeadSource());
			companyId.add(lead.getCompanyId());
			industry.add(lead.getIndustry());
			salesPerson.add(lead.getLeadOwner());
		}
		return this.getValidLeadsData(campaignId, accountName, leadSource, mapLeads, companyId, industry, salesPerson);
	}

	/**
	 * Gets the revenue for Opportunities with in the priovided campaigns
	 * @param subCampaigns
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 */
	public double getRevenueForOpportunitieswithCampaigns(List<String> subCampaigns, List<String> opportunities, String startDate, String endDate){

		if(CollectionUtils.isNotEmpty(subCampaigns)){
			List<String> campaignOpportunities = new ArrayList<>();
			BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaigns));
			SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
					.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
					.setSearchType(SearchType.SCAN).setSize(1000)
					.setScroll(new TimeValue(6000))
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));

			SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
			while(true) {
				for (SearchHit hit : searchResponse.getHits()) {
					campaignOpportunities.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
				}
				searchResponse = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)).get();
				if(searchResponse.getHits().getHits().length == 0) {
					break;
				}
			}
			return erpInvoiceService.getInvoiceAmountByOpportunityIds(campaignOpportunities, startDate, endDate);
		}else
			return erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunities, startDate, endDate);

	}

	/**
	 * Get Opportunity amount for the lost opportunities
	 * @param opportunityIds
	 * @return
	 */
	public Double getOpportunityAmountByOpportunities(List<String> opportunityIds) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds)))
				.addAggregation(AggregationBuilders.sum(SearchConstants.AMOUNT_AGGREGATION).field(CRMConstants.OPPORTUNITY_AMOUNT));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		return AggregationUtil.getAggregationValue(searchResponse, SearchConstants.AMOUNT_AGGREGATION, SearchConstants.SUM_AGGREGATION_TYPE);
	}

	/**
	 * Get New or Existing Win / Loss Rate by opportunities
	 * @param wonOpportunities
	 * @param lostOpportunities
	 * @return
	 */
	public List<WinLossData> getNewOrExistingWinDataByOpportunities(List<String> wonOpportunities,
			List<String> lostOpportunities) {
		List<String> allOpportunities = new ArrayList<>(wonOpportunities);
		allOpportunities.addAll(lostOpportunities);
		int hitsSize = getHitsSize(allOpportunities);
		String[] wonStages = appSalesStageContainer.getClosedWonMappedStages().toArray(new String[appSalesStageContainer.getClosedWonMappedStages().size()]);
		String[] lostStages = appSalesStageContainer.getClosedLostMappedStages().toArray(new String[appSalesStageContainer.getClosedLostMappedStages().size()]);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, allOpportunities)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_TYPE_AGGREGATION).field(CRMConstants.OPPORTUNITY_TYPE_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
						.subAggregation(AggregationBuilders.terms(SearchConstants.WON_AGGREGATION).field(CRMConstants.OPPORTUNITY_STAGE_RAW)
								.include(wonStages)
								.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITIES_AGGREGATION).setSize(hitsSize).setFetchSource(CRMConstants.OPPORTUNITY_ID, null)))
						.subAggregation(AggregationBuilders.terms(SearchConstants.LOST_AGGREGATION).field(CRMConstants.OPPORTUNITY_STAGE_RAW)
								.include(lostStages)
								.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_LOST_OPPORTUNITIES_AGGREGATION).setSize(hitsSize).setFetchSource(CRMConstants.OPPORTUNITY_ID, null))));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Terms newOrExistingTerms = searchResponse.getAggregations().get(SearchConstants.OPPORTUNITY_TYPE_AGGREGATION);
		Collection<Terms.Bucket> newOrExistingBuckets = newOrExistingTerms.getBuckets();
		List<WinLossData> newOrExistingData = new ArrayList<>();
		WinLossData newOrExistingDataObject;
		List<String> campaignWonOportunityIds;
		List<String> campaignLostOportunityIds;
		Terms stageTerms;
		for(Terms.Bucket newOrExistingBucket: newOrExistingBuckets) {
			if(StringUtils.isNotBlank(newOrExistingBucket.getKey())) {
				newOrExistingDataObject = new WinLossData();
				campaignWonOportunityIds = new ArrayList<>();
				campaignLostOportunityIds = new ArrayList<>();
				stageTerms = newOrExistingBucket.getAggregations().get(SearchConstants.WON_AGGREGATION);
				Collection<Terms.Bucket> stageBuckets = stageTerms.getBuckets();
				for(Terms.Bucket wonBucket: stageBuckets) {
					TopHits topWonHits = wonBucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITIES_AGGREGATION);
					for(SearchHit topHit: topWonHits.getHits()) {
						campaignWonOportunityIds.add(topHit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
					}
				}
				stageTerms = newOrExistingBucket.getAggregations().get(SearchConstants.LOST_AGGREGATION);
				stageBuckets = stageTerms.getBuckets();
				for(Terms.Bucket lostBucket: stageBuckets) {
					TopHits topLostHits = lostBucket.getAggregations().get(SearchConstants.TOP_LOST_OPPORTUNITIES_AGGREGATION);
					for(SearchHit topHit: topLostHits.getHits()) {
						campaignLostOportunityIds.add(topHit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
					}
				}
				double revenueAmount = erpInvoiceService.getInvoiceSumForOpportunites(campaignWonOportunityIds);
				newOrExistingDataObject.setWonAmount(revenueAmount);
				newOrExistingDataObject.setWonCount((long)campaignWonOportunityIds.size());
				newOrExistingDataObject.setLostCount((long)campaignLostOportunityIds.size());
				newOrExistingDataObject.setLostAmount(this.getOpportunityAmountByOpportunities(campaignLostOportunityIds));
				newOrExistingDataObject.setStackedParamName(newOrExistingBucket.getKey());
				newOrExistingData.add(newOrExistingDataObject);
			}
		}
		return newOrExistingData;
	}

	/**
	 * Get Account Wise Win Loss Data for opportunities
	 * @param wonOpportunities
	 * @param lostOpportunities
	 * @return
	 */
	public List<WinLossData> getAccountWiseWinLossDataByOpportunities(List<String> wonOpportunities,
			List<String> lostOpportunities, int size) {
		List<String> allOpportunities = new ArrayList<>(wonOpportunities);
		allOpportunities.addAll(lostOpportunities);
		int hitsSize = getHitsSize(allOpportunities);
		String[] wonStages = appSalesStageContainer.getClosedWonMappedStages().toArray(new String[appSalesStageContainer.getClosedWonMappedStages().size()]);
		String[] lostStages = appSalesStageContainer.getClosedLostMappedStages().toArray(new String[appSalesStageContainer.getClosedLostMappedStages().size()]);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, allOpportunities)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION).field(CRMConstants.OPPORTUNITY_ACCOUNT_ID_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
						.subAggregation(AggregationBuilders.terms(SearchConstants.WON_AGGREGATION).field(CRMConstants.OPPORTUNITY_STAGE_RAW)
								.include(wonStages)
								.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITIES_AGGREGATION).setSize(hitsSize).setFetchSource(CRMConstants.OPPORTUNITY_ID, null)))
						.subAggregation(AggregationBuilders.terms(SearchConstants.LOST_AGGREGATION).field(CRMConstants.OPPORTUNITY_STAGE_RAW)
								.include(lostStages)
								.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_LOST_OPPORTUNITIES_AGGREGATION).setSize(hitsSize).setFetchSource(CRMConstants.OPPORTUNITY_ID, null))));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Terms accountTerms = searchResponse.getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
		Collection<Terms.Bucket> accountBuckets = accountTerms.getBuckets();
		List<WinLossData> acocuntsWinLossDataData = new ArrayList<>();
		WinLossData accountDataObject;
		List<String> accountWonOportunityIds;
		List<String> accountLostOportunityIds;
		Terms stageTerms;
		for(Terms.Bucket accountBucket: accountBuckets) {
			if(StringUtils.isNotBlank(accountBucket.getKey())) {
				accountDataObject = new WinLossData();
				accountWonOportunityIds = new ArrayList<>();
				accountLostOportunityIds = new ArrayList<>();
				stageTerms = accountBucket.getAggregations().get(SearchConstants.WON_AGGREGATION);
				Collection<Terms.Bucket> stageBuckets = stageTerms.getBuckets();
				for(Terms.Bucket wonBucket: stageBuckets) {
					TopHits topWonHits = wonBucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITIES_AGGREGATION);
					for(SearchHit topHit: topWonHits.getHits()) {
						accountWonOportunityIds.add(topHit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
					}
				}
				stageTerms = accountBucket.getAggregations().get(SearchConstants.LOST_AGGREGATION);
				stageBuckets = stageTerms.getBuckets();
				for(Terms.Bucket lostBucket: stageBuckets) {
					TopHits topLostHits = lostBucket.getAggregations().get(SearchConstants.TOP_LOST_OPPORTUNITIES_AGGREGATION);
					for(SearchHit topHit: topLostHits.getHits()) {
						accountLostOportunityIds.add(topHit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
					}
				}
				double revenueAmount = erpInvoiceService.getInvoiceSumForOpportunites(accountWonOportunityIds);
				accountDataObject.setWonAmount(revenueAmount);
				accountDataObject.setWonCount((long)accountWonOportunityIds.size());
				accountDataObject.setLostCount((long)accountLostOportunityIds.size());
				accountDataObject.setLostAmount(this.getOpportunityAmountByOpportunities(accountLostOportunityIds));
				accountDataObject.setStackedParamName(crmAccountService.getAccountNameByAccountId(accountBucket.getKey()));
				acocuntsWinLossDataData.add(accountDataObject);
			}
		}
		sortWinLosstByWonAmount(acocuntsWinLossDataData);
		if(acocuntsWinLossDataData.size() > size) {
			acocuntsWinLossDataData = acocuntsWinLossDataData.subList(0, size);
		}
		return acocuntsWinLossDataData;
	}

	/**
	 * Get Industry wise Win Loss Data by opportunities
	 * @param wonOpportunities
	 * @param lostOpportunities
	 * @return
	 */
	public List<WinLossData> getIndustryWiseWinLossDataByOpportunities(List<String> wonOpportunities,
			List<String> lostOpportunities, int size) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(ElasticSearchEnums.CRM_ACCOUNT.getText())
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.INDUSTRY_AGGREGATION).field(CRMConstants.ACCOUNT_INDUSTRY_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		Terms industryTerms = searchResponse.getAggregations().get(SearchConstants.INDUSTRY_AGGREGATION);
		Collection<Terms.Bucket> industryBuckets = industryTerms.getBuckets();
		WinLossData industryDataObject;
		List<WinLossData> industryWinLossData = new ArrayList<>();
		for(Terms.Bucket bucket: industryBuckets) {
			industryDataObject = new WinLossData();
			String industryName = bucket.getKey();
			Object[] won = this.getWonOpportunityAndRevenueForIndustry(industryName, wonOpportunities);
			Object[] lost = this.getLostOpportunityAndRevenueForIndustry(industryName, lostOpportunities);
 			industryDataObject.setWonAmount((double) won[0]);
			industryDataObject.setWonCount((long) won[1]);
			industryDataObject.setLostCount((long) lost[1]);
			industryDataObject.setLostAmount((double) lost[0]);
			industryDataObject.setStackedParamName(bucket.getKey());
			industryWinLossData.add(industryDataObject);
		}
		sortWinLosstByWonAmount(industryWinLossData);
		if(industryWinLossData.size() > size) {
			industryWinLossData = industryWinLossData.subList(0, size);
		}
		return industryWinLossData;
	}

	/**
	 * Get Won Opportunity Won Count and revenue for Industry
	 * @param industry
	 * @param opportunities
	 * @return
	 */
	public Object[] getWonOpportunityAndRevenueForIndustry(String industry, List<String> opportunities){
		BoolFilterBuilder boolFilterBuilder =FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.ACCOUNT_INDUSTRY_RAW,	 industry));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
												.setTypes(getDocumentType())
												.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
												.setSearchType(SearchType.SCAN).setSize(1000)
												.setScroll(new TimeValue(6000));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Set<String> opportunityIds = new TreeSet<>();
		 while (true) {
				for (SearchHit hit : searchResponse.getHits()) {
					opportunityIds.add((String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
				}
				SearchScrollRequestBuilder searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
				searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
				if(searchResponse.getHits().getHits().length == 0) {
					break;
				}
			}

		 double revenue = erpInvoiceService.getInvoiceSumForOpportunites(new ArrayList<>(opportunityIds));
		 return new Object[]{revenue, (long)opportunityIds.size()};
	}

	/**
	 * Get Lost count and revenue for Industry
	 * @param industry
	 * @param opportunities
	 * @return
	 */
	public Object[] getLostOpportunityAndRevenueForIndustry(String industry, List<String> opportunities){
		String[] lostStages = appSalesStageContainer.getClosedLostMappedStages().toArray(new String[appSalesStageContainer.getClosedLostMappedStages().size()]);
		BoolFilterBuilder boolFilterBuilder =FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.ACCOUNT_INDUSTRY_RAW,	 industry));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, lostStages));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(CRMConstants.OPPORTUNITY_AMOUNT));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		Sum sum = searchResponse.getAggregations().get(SearchConstants.SUM_AGGREGATION);
		double revenue = sum.getValue();
		return new Object[]{revenue, (long)searchResponse.getHits().getTotalHits()};
	}


	/**
	 * Get Win Loss Data of sales person by opportunities
	 * @param wonOpportunities
	 * @param lostOpportunities
	 * @return
	 */
	public List<WinLossData> getSalesPersonWiseWinLossDataByOpportunities(List<String> wonOpportunities,
			List<String> lostOpportunities, int size) {
		List<String> allOpportunities = new ArrayList<>(wonOpportunities);
		allOpportunities.addAll(lostOpportunities);
		int hitsSize = getHitsSize(allOpportunities);
		String[] wonStages = appSalesStageContainer.getClosedWonMappedStages().toArray(new String[appSalesStageContainer.getClosedWonMappedStages().size()]);
		String[] lostStages = appSalesStageContainer.getClosedLostMappedStages().toArray(new String[appSalesStageContainer.getClosedLostMappedStages().size()]);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, allOpportunities)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.SALES_PERSON_AGGREGATION).field(CRMConstants.OPPORTUNITY_OWNER_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
						.subAggregation(AggregationBuilders.terms(SearchConstants.WON_AGGREGATION).field(CRMConstants.OPPORTUNITY_STAGE_RAW)
								.include(wonStages)
								.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITIES_AGGREGATION).setSize(hitsSize).setFetchSource(CRMConstants.OPPORTUNITY_ID, null)))
						.subAggregation(AggregationBuilders.terms(SearchConstants.LOST_AGGREGATION).field(CRMConstants.OPPORTUNITY_STAGE_RAW)
								.include(lostStages)
								.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_LOST_OPPORTUNITIES_AGGREGATION).setSize(hitsSize).setFetchSource(CRMConstants.OPPORTUNITY_ID, null))
								.subAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(CRMConstants.OPPORTUNITY_AMOUNT))));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Terms salesPersonTerms = searchResponse.getAggregations().get(SearchConstants.SALES_PERSON_AGGREGATION);
		Collection<Terms.Bucket> salesPersonBuckets = salesPersonTerms.getBuckets();
		//LOG.info("Competitor - salesPersonCount :" + salesPersonBuckets.size());
		List<WinLossData> salesPersonsData = new ArrayList<>();
		WinLossData salesPersonData;
		List<String> salesPersonWonOportunityIds;
		List<String> salesPersonLostOportunityIds;
		Terms stageTerms;
		double opportunityLostAmount = 0;
		for(Terms.Bucket salesPersonBucket: salesPersonBuckets) {
			if(StringUtils.isNotBlank(salesPersonBucket.getKey())) {
				salesPersonData = new WinLossData();
				salesPersonWonOportunityIds = new ArrayList<>();
				salesPersonLostOportunityIds = new ArrayList<>();
				stageTerms = salesPersonBucket.getAggregations().get(SearchConstants.WON_AGGREGATION);
				Collection<Terms.Bucket> stageBuckets = stageTerms.getBuckets();
				for(Terms.Bucket wonBucket: stageBuckets) {
					TopHits topWonHits = wonBucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITIES_AGGREGATION);
					for(SearchHit topHit: topWonHits.getHits()) {
						salesPersonWonOportunityIds.add(topHit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
					}
				}
				stageTerms = salesPersonBucket.getAggregations().get(SearchConstants.LOST_AGGREGATION);
				stageBuckets = stageTerms.getBuckets();
				for(Terms.Bucket lostBucket: stageBuckets) {
					TopHits topLostHits = lostBucket.getAggregations().get(SearchConstants.TOP_LOST_OPPORTUNITIES_AGGREGATION);
					for(SearchHit topHit: topLostHits.getHits()) {
						salesPersonLostOportunityIds.add(topHit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
					}
					Sum lostAmountSum = lostBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
					opportunityLostAmount = lostAmountSum.getValue();
				}

				//Object[] lost = this.getLostOpportunityAndRevenueForSalesPerson(salesPersonBucket.getKey(), lostOpportunities);
				double revenueAmount = erpInvoiceService.getInvoiceSumForOpportunites(salesPersonWonOportunityIds);
				salesPersonData.setWonAmount(revenueAmount);
				salesPersonData.setWonCount((long)salesPersonWonOportunityIds.size());
				salesPersonData.setLostCount(salesPersonLostOportunityIds.size());
				salesPersonData.setLostAmount(opportunityLostAmount);
				salesPersonData.setStackedParamName(salesPersonBucket.getKey());
				salesPersonsData.add(salesPersonData);
			}
		}
		sortWinLosstByWonAmount(salesPersonsData);
		if(salesPersonsData.size() > size) {
			salesPersonsData = salesPersonsData.subList(0, size);
		}
		return salesPersonsData;
	}

	/**
	 * Get Lost count and revenue for Industry
	 * @param industry
	 * @param opportunities
	 * @return
	 */
	public Object[] getLostOpportunityAndRevenueForSalesPerson(String salesPerson, List<String> opportunities){
		String[] lostStages = appSalesStageContainer.getClosedLostMappedStages().toArray(new String[appSalesStageContainer.getClosedLostMappedStages().size()]);
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_OWNER_RAW, salesPerson));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, lostStages));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(CRMConstants.OPPORTUNITY_AMOUNT));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		Sum sum = searchResponse.getAggregations().get(SearchConstants.SUM_AGGREGATION);
		double revenue = sum.getValue();
		return new Object[]{revenue, (long)searchResponse.getHits().getTotalHits()};
	}


	/**
	 * Get Country Wise Win Loss Data by opportunities
	 * @param wonOpportunities
	 * @param lostOpportunities
	 * @return
	 */
	public List<WinLossData> getCountryWiseWinLossDataByOpportunities(List<String> wonOpportunities,
			List<String> lostOpportunities, int size) {
		int hitsSize = getHitsSize(wonOpportunities);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(ElasticSearchEnums.CRM_ACCOUNT.getText())
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.COUNTRY_AGGREGATION).field(CRMConstants.ACCOUNT_BILLING_ADDRESS_COUNTRY_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
						.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_HITS_AGGREGATION).setSize(hitsSize).setFetchSource(CRMConstants.ACCOUNT_ID, null)));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		Terms countryTerms = searchResponse.getAggregations().get(SearchConstants.COUNTRY_AGGREGATION);
		Collection<Terms.Bucket> countryBuckets = countryTerms.getBuckets();
		List<String> accountIds;
		List<String> allOpportunities = new ArrayList<>(wonOpportunities);
		allOpportunities.addAll(lostOpportunities);
		BoolFilterBuilder boolFilterBuilder;
		WinLossData countryDataObject;
		//LOG.info("country buckets: "+ countryBuckets.size());
		String[] wonStages = appSalesStageContainer.getClosedWonMappedStages().toArray(new String[appSalesStageContainer.getClosedWonMappedStages().size()]);
		String[] lostStages = appSalesStageContainer.getClosedLostMappedStages().toArray(new String[appSalesStageContainer.getClosedLostMappedStages().size()]);
		List<WinLossData> countryWinLossData = new ArrayList<>();
		for(Terms.Bucket bucket: countryBuckets) {
			countryDataObject = new WinLossData();
			boolFilterBuilder = FilterBuilders.boolFilter();
			TopHits topAccountHits = bucket.getAggregations().get(SearchConstants.TOP_HITS_AGGREGATION);
			accountIds = new ArrayList<>();
			for(SearchHit hit: topAccountHits.getHits()) {
				accountIds.add(hit.getSource().get(CRMConstants.ACCOUNT_ID).toString());
			}
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_ID_RAW, accountIds));
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, allOpportunities));
			if(CollectionUtils.isNotEmpty(allOpportunities)) {
				hitsSize = allOpportunities.size();
			}
			searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
					.setTypes(getDocumentType())
					.setSize(0)
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
					.addAggregation(AggregationBuilders.terms(SearchConstants.WON_AGGREGATION).field(CRMConstants.OPPORTUNITY_STAGE_RAW)
							.include(wonStages)
							.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITIES_AGGREGATION).setSize(hitsSize).setFetchSource(CRMConstants.OPPORTUNITY_ID, null)))
					.addAggregation(AggregationBuilders.terms(SearchConstants.LOST_AGGREGATION).field(CRMConstants.OPPORTUNITY_STAGE_RAW)
							.include(lostStages)
							.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_LOST_OPPORTUNITIES_AGGREGATION).setSize(hitsSize).setFetchSource(CRMConstants.OPPORTUNITY_ID, null)));
			searchResponse = esQueryUtils.execute(searchRequestBuilder);
			List<String> countryWonOportunityIds;
			List<String> countryLostOportunityIds;
			countryWonOportunityIds = new ArrayList<>();
			countryLostOportunityIds = new ArrayList<>();
			Terms stageTerms = searchResponse.getAggregations().get(SearchConstants.WON_AGGREGATION);
			Collection<Terms.Bucket> stageBuckets = stageTerms.getBuckets();
			for(Terms.Bucket wonBucket: stageBuckets) {
				TopHits topWonHits = wonBucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITIES_AGGREGATION);
				for(SearchHit topHit: topWonHits.getHits()) {
					countryWonOportunityIds.add(topHit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
				}
			}
			stageTerms = searchResponse.getAggregations().get(SearchConstants.LOST_AGGREGATION);
			stageBuckets = stageTerms.getBuckets();
			for(Terms.Bucket lostBucket: stageBuckets) {
				TopHits topLostHits = lostBucket.getAggregations().get(SearchConstants.TOP_LOST_OPPORTUNITIES_AGGREGATION);
				for(SearchHit topHit: topLostHits.getHits()) {
					countryLostOportunityIds.add(topHit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
				}
			}
			//LOG.info(bucket.getKey() + " won :" + countryWonOportunityIds.size() + " lost :" + countryLostOportunityIds.size());
			double revenueAmount = erpInvoiceService.getInvoiceSumForOpportunites(countryWonOportunityIds);
			countryDataObject.setWonAmount(revenueAmount);
			countryDataObject.setWonCount((long)countryWonOportunityIds.size());
			countryDataObject.setLostCount((long)countryLostOportunityIds.size());
			countryDataObject.setLostAmount(this.getOpportunityAmountByOpportunities(countryLostOportunityIds));
			countryDataObject.setStackedParamName(bucket.getKey());
			countryWinLossData.add(countryDataObject);
		}
		sortWinLosstByWonAmount(countryWinLossData);
		if(countryWinLossData.size() > size) {
			countryWinLossData = countryWinLossData.subList(0, size);
		}
		return countryWinLossData;
	}

	/**
	 * Get Product wise Win Loss Data for opportunities
	 * @param wonOpportunities
	 * @param lostOpportunities
	 * @return
	 */
	public List<WinLossData> getProductWiseWinLossDataByOpportunities(List<String> wonOpportunities,
			List<String> lostOpportunities, String startDate, String endDate, int size) {
		List<String> allOpportunities = new ArrayList<>();
		allOpportunities.addAll(wonOpportunities);
		allOpportunities.addAll(lostOpportunities);
		//LOG.info("all Opportunity size :" + allOpportunities.size());
		Map<String, WinLossData> productWinLossData = new HashMap<>();
		List<WinLossData> winLossDataList = new ArrayList<>();
		if(CollectionUtils.isNotEmpty(allOpportunities)) {
			SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
					.setTypes(ElasticSearchEnums.CRM_OPP_PRODUCT.getText())
					.setSize(0)
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, allOpportunities)))
					.addAggregation(AggregationBuilders.terms(SearchConstants.PRODUCT_AGGREGATION).field(CRMConstants.PRODUCT_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS));

			SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

			Terms countryTerms = searchResponse.getAggregations().get(SearchConstants.PRODUCT_AGGREGATION);
			Collection<Terms.Bucket> productBuckets = countryTerms.getBuckets();
			WinLossData productDataObject;
			//String productCode;
			String levelThreeName;
			for(Terms.Bucket bucket: productBuckets) {
				String productId = bucket.getKey();
				List<String> opportunitiesLost = crmOpportunityProductService.getOpportunitiesByProductId(productId, null, null, lostOpportunities);
				//List<String> opportunitiesWon = crmOpportunityProductService.getOpportunitiesByProductId(productId, null, null, wonOpportunities);
				Object[] lost = this.getLostOpportunityAndRevenueForProduct(opportunitiesLost);
				productDataObject = new WinLossData();
				//productCode = crmProductService.getProductCodeByProductId(bucket.getKey());
				InvoiceDataPojo invoiceDataPojo = erpInvoiceService.getWonUniqueOpportinitiesOfProduct(bucket.getKey(), null, null, wonOpportunities);
				//LOG.info(bucket.getKey() + " won :" + countryWonOportunityIds.size() + " lost :" + countryLostOportunityIds.size());
				productDataObject.setWonAmount(invoiceDataPojo.getRevenue());
				productDataObject.setWonCount(invoiceDataPojo.getOpportunities().size());
				productDataObject.setLostCount((long) lost[1]);
				productDataObject.setLostAmount((double) lost[0]);
				levelThreeName = crmProductService.getLevelThreeNameByProductId(bucket.getKey());
				productDataObject.setStackedParamName(levelThreeName);
				if(productWinLossData.containsKey(levelThreeName)) {
					WinLossData existingWinLossData = productWinLossData.get(levelThreeName);
					productDataObject.setLostAmount(productDataObject.getLostAmount() + existingWinLossData.getLostAmount());
					productDataObject.setLostCount(productDataObject.getLostCount() + existingWinLossData.getLostCount());
					productDataObject.setWonAmount(productDataObject.getWonAmount() + existingWinLossData.getWonAmount());
					productDataObject.setWonCount(productDataObject.getWonCount() + existingWinLossData.getWonCount());
				} else {
					productWinLossData.put(crmProductService.getLevelThreeNameByProductId(bucket.getKey()), productDataObject);
				}
				// productWinLossData.add(productDataObject);
			}
			winLossDataList = new ArrayList<>(productWinLossData.values());  
			sortWinLosstByWonAmount(winLossDataList);
			if(winLossDataList.size() > size) {
				winLossDataList = winLossDataList.subList(0, size);
			}
		}
		return winLossDataList;
	}




	/**
	 * Get Lost count and revenue for Industry
	 * @param industry
	 * @param opportunities
	 * @return
	 */
	public Object[] getLostOpportunityAndRevenueForProduct(List<String> opportunities){
		String[] lostStages = appSalesStageContainer.getClosedLostMappedStages().toArray(new String[appSalesStageContainer.getClosedLostMappedStages().size()]);
		BoolFilterBuilder boolFilterBuilder =FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, lostStages));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(CRMConstants.OPPORTUNITY_AMOUNT));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		Sum sum = searchResponse.getAggregations().get(SearchConstants.SUM_AGGREGATION);
		double revenue = sum.getValue();
		return new Object[]{revenue, (long)searchResponse.getHits().getTotalHits()};
	}

	/**
	 * Gets the Opportunities By Campaigns
	 * @param opportunities
	 * @return
	 */
	public Map<String, List<CrmOpportunity>> getCampaignWiseOpportunities(List<String> opportunities){

		Map<String, List<CrmOpportunity>> campaignWithOpportunities = new HashMap<>();
		AbstractAggregationBuilder aggregation = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW).
				size(0);
		 SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.addAggregation(aggregation);

		 if(CollectionUtils.isNotEmpty(opportunities)){
			BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		 }
		 SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> termsBuckets = terms.getBuckets();

		for (Terms.Bucket termBucket : termsBuckets) {
			if(StringUtils.isNotBlank(termBucket.getKey())){
				campaignWithOpportunities.put(termBucket.getKey(), getOpportunitiesOfaCampaignFromOpp(opportunities, termBucket.getKey()));
			}
		}
		return campaignWithOpportunities;
	}

	/**
	 * Gets the CrmOpportunity Ids from the opportunities
	 * @param opportunities
	 * @param campaignId
	 * @return
	 */
	public List<CrmOpportunity> getOpportunitiesOfaCampaignFromOpp(List<String> opportunities, String campaignId){
		 BoolFilterBuilder boolFilterBuilder = null;
		 if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		 }
		 if(StringUtils.isNotBlank(campaignId)){
			if(boolFilterBuilder == null){
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, campaignId));
		 }
		 SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
					.setTypes(getDocumentType()).setScroll(new TimeValue(6000)).setSearchType(SearchType.SCAN).setSize(1000);
		 if(boolFilterBuilder != null){
			 searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		 }
		 SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		 List<CrmOpportunity> opportunityIds = new ArrayList<>();
		 while (true) {
			for (SearchHit hit : searchResponse.getHits()) {
				opportunityIds.add((CrmOpportunity)ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		 return opportunityIds;
	}

	//	/**
	//	 * Get All the Industries by Revenue with the Time Frame
	//	 * @param startDate
	//	 * @param endDate
	//	 * @return
	//	 */
	//	public Map<String, Object> getAllIndustriesByRevenueWithInTimeFrame(final String startDate, final String endDate) {
	//		TimerUtil timerUtil = new TimerUtil();
	//		LOG.info("Top Industries :" );
	//
	//		Map<String, Object> topIndustriesMap = new HashMap<>();
	//		timerUtil.start();
	//		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
	//				.setTypes(getDocumentType())
	//				/*.setQuery(QueryBuilders.termsQuery(CRMConstants.ACCOUNT_ID_RAW, accountIds))*/
	//				.addAggregation(AggregationBuilders.terms(SearchConstants.INDUSTRY_AGGREGATION).field(CRMConstants.ACCOUNT_INDUSTRY_RAW).size(0));
	//
	//		Aggregations aggregations = searchRequestBuilder.get().getAggregations();
	//		//ExecutorService executorService =  Executors.newFixedThreadPool(70);
	//		Terms  industryTerms = aggregations.get(SearchConstants.INDUSTRY_AGGREGATION);
	//
	//		Collection<Terms.Bucket> industryBuckets = industryTerms.getBuckets();
	//		LOG.info("Industtry Terms :");
	//		for(final Terms.Bucket industryBucket: industryBuckets) {
	//			LOG.info(industryBucket.getKey());
	//			// get accounts based on industry
	//			List<String> accountIds = crmAccountService.getAccountIdsByIndustry(industryBucket.getKey());
	//
	//			LOG.info(accountIds.size());
	//			List<String> wonOpportunityIds = this.getOpportunitiesByAccountIdsAndStage(accountIds, OpportunityStagesEnum.CLOSED_WON.getText(), null, null, null);
	//			List<String> lostOpportunityIds = this.getOpportunitiesByAccountIdsAndStage(accountIds, OpportunityStagesEnum.CLOSED_LOST.getText(), null, null, null);
	//			LOG.info("Opportunity Ids :" + wonOpportunityIds.size());
	//			double revenueAmount = this.erpInvoiceService.getInvoiceAmountByOpportunityIds(wonOpportunityIds, startDate, endDate);
	//			LOG.info("revenue Amount :" + revenueAmount);
	//			RevenueOpportunitiesData revenueOpportunitiesData = new RevenueOpportunitiesData();
	//			revenueOpportunitiesData.setOpportunityIds(wonOpportunityIds);
	//			revenueOpportunitiesData.setRevenueAmount(revenueAmount);
	//			revenueOpportunitiesData.setLostOpportunityIds(lostOpportunityIds);
	//			topIndustriesMap.put(industryBucket.getKey(), revenueOpportunitiesData);
	//		}
	//
	//		LOG.debug("Processed accounts data :" + timerUtil.timeTakenInMillis());
	//		return MiriSearchUtils.sortMapByObjectValue(topIndustriesMap);
	//		/*
	//
	//		topIndustriesMap = new ConcurrentHashMap<>();
	//		SearchRequestBuilder searchRequestBuilder = this.getAccountsByOpportunityQuery(startDate, endDate,
	//				OpportunityStagesEnum.CLOSED_WON.getText());
	//		ExecutorService executorService =  Executors.newFixedThreadPool(70);
	//		Aggregations aggregations = searchRequestBuilder.get().getAggregations();
	//		Terms accoountTerms = aggregations.get(SearchConstants.ACCOUNT_AGGREGATION);
	//		Collection<Terms.Bucket> accountBuckets = accoountTerms.getBuckets();
	//
	//		for (final Terms.Bucket accountBucket : accountBuckets) {
	//
	//			executorService.submit(new Runnable() {
	//				@Override
	//				public void run() {// passing null opportunityIids to get complete industries information
	//					updateTopIndustriesMap(startDate, endDate, accountBucket.getKey(),
	//							OpportunityStagesEnum.CLOSED_WON.getText(), null);
	//				}
	//			});
	//
	//		}
	//
	//		executorService.shutdown();
	//		try {
	//			if(!executorService.awaitTermination(1, TimeUnit.MINUTES))
	//				executorService.shutdownNow();
	//		}
	//		catch (InterruptedException e) {
	//			LOG.error("Interruped Exception while updating the campaigns map:" + e.getMessage());
	//		}
	//		return MiriSearchUtils.sortMapByObjectValue(topIndustriesMap);*/
	//	}
	
	
	public SearchRequestBuilder getAccountsByOpportunityQueryForAssess(final String startDate, final String endDate,
			final String stage) {
		List<String> subCamapigns = mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW,
				appSalesStageContainer.getMappedSaleStage(stage)));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapigns));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CLOSED_ON).gte(startDate).lte(endDate));
		return getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
						.field(SearchConstants.ACCOUNT_ID_RAW).size(0))
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION)
						.field(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW).size(0));
	}
	
	public SearchRequestBuilder getAccountsByOpportunityForAssess(final String startDate, final String endDate,
			final String stage) {
		List<String> subCamapigns = mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW,
				appSalesStageContainer.getMappedSaleStage(stage)));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapigns));
		return getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
						.field(SearchConstants.ACCOUNT_ID_RAW).size(0))
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION)
						.field(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW).size(0));
	}

	/**
	 * Gets the account Ids within the time Frame
	 * @param startDate
	 * @param endDate
	 * @return 
	 */
	public List<String> getAccountIdsWithInDates(String startDate, String endDate){
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate));
		
		Set<String> uniqueAccountIds = new TreeSet<>();
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(this.getIndex())
													.setTypes(this.getDocumentType())
													.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
													.setSearchType(SearchType.SCAN)
													.setScroll(new TimeValue(6000))
													.setSize(1000);
		
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder); 
		String accountId = "";
		while(true){
			for (SearchHit hit : searchResponse.getHits()) {
				accountId = (String)hit.getSource().get(CRMConstants.ACCOUNT_ID);
				if(StringUtils.isNotBlank(accountId)){
					uniqueAccountIds.add(accountId);
				}
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient()
																	 .prepareSearchScroll(searchResponse.getScrollId())
																	 .setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
	    return new ArrayList<String>(uniqueAccountIds);				
	}
	
	/**
	 * Gets the Opportunities Not belonging to the accountIds
	 * @param accountIds
	 * 			accountIds which are created in previous Fiscal
	 * @return 
	 */
	public List<String> getWonNewOpportunitiesByAccountIds(List<String> accountIds, Boolean isMarketing){
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(null != accountIds){
			boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_ID_RAW, accountIds));
		}
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(CRMConstants.ACCOUNT_ID_RAW, ""));
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		
		if(null != isMarketing){
			List<String> subCamapignIds = mapCampaignService.getMarketingSubCampaigns();
			if(isMarketing){
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapignIds));
			}else{
				boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCamapignIds));
			}
		}
		List<String> newOpportunities = new ArrayList<String>();
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(this.getIndex())
													.setTypes(this.getDocumentType())
													.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
													.setSearchType(SearchType.SCAN)
													.setScroll(new TimeValue(6000))
													.setSize(1000);

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder); 
		
		String opportunityId = "";
		
		while(true){
			for (SearchHit hit : searchResponse.getHits()) {
				opportunityId = (String)hit.getSource().get(CRMConstants.OPPORTUNITY_ID);
				if(StringUtils.isNotBlank(opportunityId)){
					newOpportunities.add(opportunityId);
				}
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient()
																	 .prepareSearchScroll(searchResponse.getScrollId())
																	 .setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
	    return newOpportunities;	
	}
	
	/**
	 * Gets the Top SubCamapaigns
	 * @param opportunities
	 * @param size
	 * @param statDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Object> getTopMarketingSubCamapigns(List<String> opportunities, int size, String statDate, String endDate, Map<String, String> marketingSubCampaigns){
		Map<String, Object> topSubCamapigns = new HashMap<>();
		RevenueOpportunitiesData revenueOpportunitiesData = null;
		List<String> campaignOpportunities = null;
		double revenue = 0;
		for(Entry<String, String> subCamapign : marketingSubCampaigns.entrySet()){
			revenueOpportunitiesData = new RevenueOpportunitiesData();
			campaignOpportunities = this.getOpportunitiesBySubCampaignId(subCamapign.getKey(), opportunities);
			revenue = erpInvoiceService.getInvoiceAmountByOpportunityIds(campaignOpportunities, statDate, endDate);
			revenueOpportunitiesData.setOpportunityIds(campaignOpportunities);
			revenueOpportunitiesData.setRevenueAmount(revenue);
			topSubCamapigns.put(subCamapign.getValue(), revenueOpportunitiesData);
		}
		return MiriSearchUtils.sortMapByObjectValueToGetTopRecords(topSubCamapigns, size);
	}
	
	/**
	 * Get the list of opportunities by campaign ID
	 * @param campaignId
	 * @return
	 * @author rammoole
	 */
	public List<String> getOpportunitiesBySubCampaignId(String campaignId, List<String> opportunityIds) {
		List<String> crmOpportunities = null;
		Client client = this.getTransportClient();

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, campaignId));
		if(null != opportunityIds){
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		}

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setScroll(new TimeValue(6000)).setSearchType(SearchType.SCAN).setSize(1000)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);

		if (opportunityRespose != null) {
			crmOpportunities = new ArrayList<>();
			while (true) {
				for (SearchHit hit : opportunityRespose.getHits()) {
					crmOpportunities.add((String) hit.getSource().get(CRMConstants.OPPORTUNITY_ID));
				}
				SearchScrollRequestBuilder searchScrollRequestBuilder = client
						.prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000));
				opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
				if (opportunityRespose.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		return crmOpportunities;
	}
	
	/**
	 * Gets the Top Lead Source From the Opportunities 
	 * @param opportunities
	 * @param size
	 * @param isMarketing
	 * @param statDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Object> getTopLeadSource(List<String> opportunities, int size, boolean isMarketing, String statDate, String endDate){
 		Map<String, Object> topLeadSourceRevenue = new HashMap<>();
 		List<String> leadSourceOpportunities = null;
		List<String> allLeadSources = this.getAllLeadSources(opportunities);
		RevenueOpportunitiesData revenueOpportunitiesData = null;
 		double revenue = 0;
		for(String leadSource : allLeadSources){
			revenueOpportunitiesData = new RevenueOpportunitiesData();
			leadSourceOpportunities = this.getOpportunitiesForLeadSource(leadSource, opportunities, isMarketing);
			revenue = erpInvoiceService.getInvoiceAmountByOpportunityIds(leadSourceOpportunities, statDate, endDate);
			revenueOpportunitiesData.setOpportunityIds(leadSourceOpportunities);
			revenueOpportunitiesData.setRevenueAmount(revenue);
	 		topLeadSourceRevenue.put(leadSource, revenueOpportunitiesData);
		}
		return MiriSearchUtils.sortMapByObjectValueToGetTopRecords(topLeadSourceRevenue, size);
	}
	
	/**
	 * Gets the revenue for Leadsource
	 * @param startDate
	 * @param endDate
	 * @param leadSource
	 * @return
	 */
	public List<String> getOpportunitiesForLeadSource(String leadSource, List<String> opportunities, boolean isMarketing){
		List<String> leadSourceOpportunities=new ArrayList<>();
		List<String> mapCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(null != opportunities){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		if(isMarketing){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));
		}else{
			boolFilter.mustNot(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, mapCampaigns));

		}

		if(StringUtils.isNotBlank(leadSource)){
			boolFilter.must(FilterBuilders.termFilter(CRMConstants.LEAD_SOURCE_RAW,leadSource));
		}

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN).setSize(1000)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));


		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);

		if(opportunityRespose != null) {
			leadSourceOpportunities = new ArrayList<>();
			while(true) {
				for (SearchHit hit : opportunityRespose.getHits()) {
					leadSourceOpportunities.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				}
				opportunityRespose = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000)).get();
				if(opportunityRespose.getHits().getHits().length == 0) {
					break;
				}
			}
		}

		return leadSourceOpportunities;
	}
	
	/**
	 * MarketingSpendRoiMetric
	 *
	 * @param opportunityIds
	 * @param startDate
	 *            TODO
	 * @param endDate
	 *            TODO
	 * @return
	 */
	public Object[] getInvoiceAmountByOpportunityIdsAndCount(final List<String> opportunityIds, final String startDate, final String endDate) {

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate));
		}
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION).field(CRMConstants.OPPORTUNITY_ID_RAW)
															.size(opportunityIds.size()));

		SearchResponse searchResponse = searchRequestBuilder.get();
		double revenue = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, startDate, endDate);
		double count = 0;
		if(searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
			count = terms.getBuckets().size();
		}
		return new Object[] { count, revenue};
	}
	
	/**
	 * Gets the MonthWise Opportunity Count and Revenue
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @return 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<String, Map<Integer, Double>> getMonthWiseRevenueAndOpportunityCount(List<String> opportunities, String startDate, String endDate){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate));
		}
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		AbstractAggregationBuilder invoiceDateAggregation = AggregationBuilders
										.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION)
										.field(CRMConstants.OPPORTUNITY_CLOSED_DATE)
										.interval(DateHistogram.Interval.MONTH)
										.format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
										.extendedBounds(startDate, endDate)
										.minDocCount(0)
										.subAggregation(AggregationBuilders
															.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
															.field(CRMConstants.OPPORTUNITY_ID_RAW)
															.size(opportunities.size()));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
													.setTypes(getDocumentType())
													.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
													.setSize(0)
													.addAggregation(invoiceDateAggregation);

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		
		Map<Integer, Double> revenueMap = new LinkedHashMap<Integer, Double>();
		Map<Integer, Double> countMap = new LinkedHashMap<Integer, Double>();
		Set<String> monthlyOpportunities =  null;

		Collection<InternalHistogram.Bucket> buckets = null;
		if(null != searchResponse.getAggregations()){
			InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
			buckets = datehist.getBuckets();
		}
		
		Terms terms = null;
		Collection<Terms.Bucket> termsBuckets = null;
		
		Set<String> overAllOpportunities =  new HashSet<>();
		
		int count = 0;
		Map<Integer, String> updatedDates = MiriDateUtils.getUpdatedDates(startDate, endDate);
		for (InternalHistogram.Bucket bucket : buckets) {
			if(updatedDates.containsKey(count)){
				monthlyOpportunities = new TreeSet<>();
				if(null != bucket.getAggregations()){
					terms = bucket.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
					termsBuckets = terms.getBuckets();
					for (Terms.Bucket termBucket : termsBuckets) {
						if(StringUtils.isNotBlank(termBucket.getKey())){
						if(overAllOpportunities.add(termBucket.getKey())){
							monthlyOpportunities.add(termBucket.getKey());
						}
					}
				}
				revenueMap.put(count, erpInvoiceService.getInvoiceSumForOpportunites(new ArrayList<>(monthlyOpportunities)));
				countMap.put(count, (double) terms.getBuckets().size());
				count++;
				}
			}else{
				revenueMap.put(count, null);
				countMap.put(count, null);
				count++;
			}
		}
		Map<String, Map<Integer, Double>> data = new HashMap<>();
		data.put(SearchConstants.NBC_REVENUE, revenueMap);
		data.put(SearchConstants.NBC_COUNT, countMap);
		return data;
	}
	
	
	/**
	 * Gets the Opportunities By Campaigns
	 * @param opportunities
	 * @return
	 */
	public List<String> getSubCamapignsFromOpportunities(List<String> opportunities){

		List<String> subCamapigns = new ArrayList<String>();
		AbstractAggregationBuilder aggregation = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW).
				size(0);
		 SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.addAggregation(aggregation);

		 if(CollectionUtils.isNotEmpty(opportunities)){
			BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		 }
		 SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		if(null != searchResponse.getAggregations()){
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			Collection<Terms.Bucket> termsBuckets = terms.getBuckets();
			for (Terms.Bucket termBucket : termsBuckets) {
				if(StringUtils.isNotBlank(termBucket.getKey())){
					subCamapigns.add(termBucket.getKey());
				}
			}
		}
		return subCamapigns;
	}
	
	/**
	 * Get opportunities for list of campaign ids
	 * @param campaignIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getOpportuniesByCampaignIdsFromTheOpportunities(List<String> campaignIds, List<String> opportunities) {
		
		if(CollectionUtils.isEmpty(campaignIds)){
			return opportunities;
		}
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, campaignIds));
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));

		List<String> campaignOptys = new ArrayList<>();

		SearchRequestBuilder srb = getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(1000)
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN).addField(SearchConstants.OPPORTUNITY_ID);
		SearchResponse opportunityRespose = esQueryUtils.execute(srb);

		while(true) {
			SearchHits oppSearchHits = opportunityRespose.getHits();
			for(SearchHit hit: oppSearchHits) {
				campaignOptys.add(hit.getFields().get(SearchConstants.OPPORTUNITY_ID).getValue().toString());
			}
			opportunityRespose = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(6000)).get();
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return campaignOptys;
	}
	
	/**
	 * Get All the won Opportunities
	 * @return
	 */
	public List<String> getAllWonOpportunities() {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN)
				.setSize(1000)
				.setScroll(new TimeValue(6000))
				.setQuery(QueryBuilders.termsQuery(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunities = new ArrayList<>();
		SearchScrollRequestBuilder searchScrollRequestBuilder;
		do {
			for(SearchHit hit: searchResponse.getHits()) {
				opportunities.add(hit.getFields().get(SearchConstants.OPPORTUNITY_ID).getValue().toString());
			}
			searchScrollRequestBuilder = this.getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
		} while(searchResponse.getHits().getHits().length == 0);
		return opportunities;
	}
	
	/**
	 * getExpiredPipelineForMonth : returns the expired pipeline amount of a month from the fiscal
	 * @param opportunities
	 * @param stagesToExclude
	 * @param minBound
	 * @param maxBound
	 * @param miriHistoryData
	 * @param fetchNewOpportunities
	 * @return
	 */
	public MiriHistoryData getExpiredPipelineForMonth(List<String> opportunities,List<String> stagesToExclude,
			String minBound,String maxBound,MiriHistoryData miriHistoryData,boolean fetchNewOpportunities,String drillDown){
		SearchRequestBuilder requestQuery = constructExpiredPipelineRequest(opportunities, stagesToExclude, minBound,
				maxBound, fetchNewOpportunities);
		SearchResponse response=esQueryUtils.execute(requestQuery);
		miriHistoryData = buildExpiredPipelineResponse(response,drillDown);
		return miriHistoryData;
	}

	/**
	 * constructExpiredPipelineRequest : constructs a request for expired pipeline
	 * @param opportunities
	 * @param stagesToExclude
	 * @param minBound
	 * @param maxBound
	 * @param fetchNewOpportunities
	 * @return
	 */
	private SearchRequestBuilder constructExpiredPipelineRequest(List<String> opportunities,
			List<String> stagesToExclude, String minBound, String maxBound, boolean fetchNewOpportunities) {
		AbstractAggregationBuilder sumAmounttByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, SearchConstants.OPPORTUNITY_AMOUNT);
		
		TermsBuilder aggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(SearchConstants.OPPORTUNITY_ID_RAW).size(0);

		BoolFilterBuilder boolFilter=FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(stagesToExclude)){
			TermsFilterBuilder stageTerms=FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stagesToExclude);
			boolFilter.must(stageTerms);
		}

		if(StringUtils.isNotEmpty(minBound) && StringUtils.isNotEmpty(maxBound) ){
			RangeFilterBuilder rangeFilter = FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE)
				.from(minBound).to(maxBound).includeLower(false).includeUpper(false);
			boolFilter.must(rangeFilter);
		}

		if(CollectionUtils.isNotEmpty(opportunities)){
			TermsFilterBuilder opportunityTerms=FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW,opportunities);
			if(fetchNewOpportunities){
				boolFilter.mustNot(opportunityTerms);
			}else{
				boolFilter.must(opportunityTerms);
			}
			
		}
		
		SearchRequestBuilder requestQuery = getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(sumAmounttByMonth).addAggregation(aggr).setSize(0);
		return requestQuery;
	}
	
	
	/**
	 * buildExpiredPipelineResponse : creates MiriHistoryData with month, amount, count and opportunities
	 * @param response
	 * @return
	 */
	private MiriHistoryData buildExpiredPipelineResponse(SearchResponse response,String drillDown) {
		MiriHistoryData miriHistoryData;
		Terms opportunityTerms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Sum sum = (Sum) response.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
		Collection<Terms.Bucket> buckets = opportunityTerms.getBuckets();
		List<String> opportunityIds= new ArrayList<>();
		for (Terms.Bucket bucket : buckets) {
			opportunityIds.add(bucket.getKey());
		}
		
		miriHistoryData=new MiriHistoryData();
		miriHistoryData.setType(SearchConstants.EXPIRED_PIPELINE_LITERAL);
		miriHistoryData.setCriteriaType(drillDown);
		miriHistoryData.setCreatedDate(new Date());
		miriHistoryData.setAmount(sum.getValue());
		if(CollectionUtils.isNotEmpty(opportunityIds)){
			miriHistoryData.setCount(opportunityIds.size());
			miriHistoryData.setOpportunities(StringUtils.join(opportunityIds, ","));
		}
		miriHistoryData.setLastUpdatedDate(new Date());
		return miriHistoryData;
	}


	/**
	 * getClosedPipelineFromPreviousPipeline : returns the closed opportunities along with amount, count and dates closed
	 * @param opportunities
	 * @param stages
	 * @return
	 */
	public List<MiriHistoryData> getClosedPipelineFromPreviousPipeline(List<String> opportunities, List<String> stages){
		SearchRequestBuilder requestQuery = constructClosedPipelineRequest(opportunities, stages);
		SearchResponse response=esQueryUtils.execute(requestQuery);
		List<MiriHistoryData> closedMiriHistoryData = buildClosedPipelineResponse(response);
		return closedMiriHistoryData;
	}

	/**
	 * buildClosedPipelineResponse : return a List<MiriHistoryData> with closed pipline in the months they were closed
	 * @param response
	 * @return
	 */
	private List<MiriHistoryData> buildClosedPipelineResponse(SearchResponse response) {
		List<MiriHistoryData> closedMiriHistoryData=new ArrayList<>();
		MiriHistoryData miriHistoryData;
		InternalHistogram datehist = response.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();

		for (InternalHistogram.Bucket bucket : buckets) {
			miriHistoryData = new  MiriHistoryData();
			Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			Terms opportunityTerms = bucket.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
			if(opportunityTerms!=null){
				Collection<Terms.Bucket> oppBuckets = opportunityTerms.getBuckets();
				List<String> opportunityIds= new ArrayList<>();
				for (Terms.Bucket oppBucket : oppBuckets) {
					opportunityIds.add(oppBucket.getKey());
				}
				miriHistoryData.setCount(opportunityIds.size());
				miriHistoryData.setOpportunities(StringUtils.join(opportunityIds, ","));
				miriHistoryData.setCriteriaValue(bucket.getKey());
			}
			miriHistoryData.setAmount(sum.getValue());
			closedMiriHistoryData.add(miriHistoryData);
		}
		return closedMiriHistoryData;
	}

	/**
	 * constructClosedPipelineRequest : Creates a request to fetch the closed pipeline in the opportunities passed.
	 * @param opportunities
	 * @param stages
	 * @return
	 */
	private SearchRequestBuilder constructClosedPipelineRequest(List<String> opportunities, List<String> stages) {
		BoolFilterBuilder boolFilter=FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(stages)){
			TermsFilterBuilder stageTerms=FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stages);
			boolFilter.must(stageTerms);
		}
		if(CollectionUtils.isNotEmpty(opportunities)){
			TermsFilterBuilder opportunityTerms=FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW,opportunities);
				boolFilter.must(opportunityTerms);
		}
		
		//Query Aggregations
		AbstractAggregationBuilder sumAmounttByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, SearchConstants.OPPORTUNITY_AMOUNT);
		
		TermsBuilder aggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(SearchConstants.OPPORTUNITY_ID_RAW).size(0);
		
		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(CRMConstants.OPPORTUNITY_CREATED_ON)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.subAggregation(sumAmounttByMonth).subAggregation(aggr);

		SearchRequestBuilder requestQuery = getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(dateAggregation).setSize(0);
		return requestQuery;
	}
	
}
