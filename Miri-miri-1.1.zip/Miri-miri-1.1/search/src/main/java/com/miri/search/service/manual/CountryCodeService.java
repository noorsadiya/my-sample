package com.miri.search.service.manual;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.get.GetResponse;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.SearchConstants;
import com.miri.search.service.common.MiriSearchService;

/**
 * Country Code Service for Top Countries By Revenue Achieved Graph
 * @author rammoole
 *
 */
@Component
public class CountryCodeService extends MiriSearchService { 
	
	/**
	 * To get the country code of a country 
	 * @param countryName
	 * @return
	 */
	public String getCountryCode(String countryName) {
		GetResponse getResponse = this.getTransportClient().prepareGet(ElasticSearchEnums
				.MANUAL.getText(), ElasticSearchEnums.COUNTRY.getText(), ElasticSearchEnums.CODE.getText()).get();
		return getResponse.getSource().get(countryName.toLowerCase()).toString();
	}

	/**
	 * To get all the country codes for elasticsearch
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getAllCountryCodes() { 
		GetResponse getResponse = this.getTransportClient().prepareGet(ElasticSearchEnums
				.MANUAL.getText(), ElasticSearchEnums.COUNTRY.getText(), SearchConstants.COUNTRY_DOCUMENT_ID).get();
		Map<String, Object> coutnryCodes = new HashMap<>();
		List<Object> countryList = (List<Object>) getResponse.getSource().get(SearchConstants.COUNTRY);
		String countryName = "";
		
		for(Object countryObject: countryList) {
			Map<String, Object> countryObjectMap = (Map<String, Object>) countryObject;
			countryName = (String) countryObjectMap.get(SearchConstants.COUNTRY_CODE_NAME);
			coutnryCodes.put(countryName.toLowerCase(), countryObjectMap.get(SearchConstants.COUNTRY_CODE));
		}
		
		return coutnryCodes;
	}
	
    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getIndex()
     */
    @Override
    public String getIndex() {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getDocumentType()
     */
    @Override
    public String getDocumentType() {
        // TODO Auto-generated method stub
        return null;
    }
}
