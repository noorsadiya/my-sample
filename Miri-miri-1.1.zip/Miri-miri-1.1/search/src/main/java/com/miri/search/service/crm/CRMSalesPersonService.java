package com.miri.search.service.crm;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.CrmUser;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.OpportunityStagesEnum;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.RevenueOpportunitiesData;
import com.miri.search.data.TopCustomerSalesPersonData;
import com.miri.search.data.WinLossData;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;
import com.miri.search.service.erp.ERPOpportunityCompetitorService;
import com.miri.search.service.manual.ManualAccountStrategyService;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.TimerUtil;

/**
 * CRM Sales Person Service
 * @author rammoole
 *
 */
@Component
public class CRMSalesPersonService extends MiriSearchService {

	private static final Logger LOG = LogManager.getLogger(CRMSalesPersonService.class);

	@Autowired
	private ESQueryUtils esQueryUtils;

	@Autowired
	private ManualAccountStrategyService manaulAccountStrategyService;

	@Autowired
	private ERPOpportunityCompetitorService erpOpportunityCompetitorService;

	@Autowired
	private ERPInvoiceService erpInvoiceService;

	@Autowired
	private TimerUtil timerUtil;
	
	private ConcurrentHashMap<String, Object> topSalesPersonMap = new ConcurrentHashMap<>();

	/**
	 * Get all the sales persons with in the fiscal year and by revenue
	 * @return
	 * @author rammoole
	 */
	public Map<String, Object> getAllSalesPerson() {
		String fiscalStartDate = this.manaulAccountStrategyService.getFiscalStartDateStr();
		String endDate = MiriDateUtils.parseDateToString(Calendar.getInstance(), MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return this.getAllSalesPersonsWithInTimeFrame(fiscalStartDate, endDate);
	}

	/**
	 * Get All Sales Person's revenue with in the time frame
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public Map<String, Object> getAllSalesPersonsWithInTimeFrame(Calendar startDate, Calendar endDate) {
		String startDateStr = MiriDateUtils.parseDateToString(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		String endDateStr = MiriDateUtils.parseDateToString(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return getAllSalesPersonsWithInTimeFrame(startDateStr, endDateStr);
	}

	/**
	 * Get top 25 sales person with in the fiscal year
	 * @return
	 */
	public Map<String, Object> getTop25SalesPersons() {
		Map<String, Object> allSalesPersons = getAllSalesPerson();
		Map<String, Object> top25SalesPersons = new LinkedHashMap<>();
		if(allSalesPersons.size() > 25) {
			int count = 1;
			for(Map.Entry<String, Object> entry: allSalesPersons.entrySet()) {
				top25SalesPersons.put(entry.getKey(), entry.getValue());
				count++;
				if(count == 25) {
					break;
				}
			}
		}
		return top25SalesPersons;
	}

	/**
	 * Returns sales person details by given name.
	 * 
	 * @param owner
	 * @return
	 */
	public CrmUser getSalesPersonById(final String ownerId) {
		return (CrmUser)esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), "userId.raw", ownerId);
	}
	/**
	 * Get all the sales person revenu with in the time frame
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	@Cacheable
	public Map<String, Object> getAllSalesPersonsWithInTimeFrame(final String startDate, final String endDate) {
		topSalesPersonMap = new ConcurrentHashMap<>();
		timerUtil.start();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).to(endDate));
		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient()
				.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),boolFilter))
				.addAggregation(AggregationBuilders.terms(SearchConstants.SALES_PERSON_AGGREGATION)
						.field(SearchConstants.SALES_PERSON_RAW).size(0));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		LOG.debug("after first query result : " + timerUtil.timeTakenInMillis());
		Terms salesPersonTerms = searchResponse.getAggregations().get(SearchConstants.SALES_PERSON_AGGREGATION);
		Collection<Terms.Bucket> salesPersonBuckets = salesPersonTerms.getBuckets();
		ExecutorService executorService =  Executors.newFixedThreadPool(70);
		for(final Terms.Bucket salesPersonBucket: salesPersonBuckets) {
			executorService.submit(new Runnable() {
				@Override
				public void run() {
					// passing opportunity ids as null as we need to get all the opportunities
					updateTopSalesPersonMap(salesPersonBucket.getKey(), startDate, endDate, 
							OpportunityStagesEnum.CLOSED_WON.getText(), null); 
				}
			});
		}
		executorService.shutdown();
		
		try {
			if(!executorService.awaitTermination(1, TimeUnit.MINUTES))
				executorService.shutdownNow();
		}
		catch (InterruptedException e) {
			LOG.error("Interruped Exception while updating the salesperson map:" + e.getMessage());
		}
		
		try {
			if(!executorService.awaitTermination(1, TimeUnit.MINUTES))
				executorService.shutdownNow();
		}
		catch (InterruptedException e) {
			LOG.error("Interruped Exception while updating the salesperson map:" + e.getMessage());
		}
		LOG.debug("after processing sales persons result : " + timerUtil.timeTakenInMillis());
		return MiriSearchUtils.sortMapByObjectValue(topSalesPersonMap);
	}

	/**
	 * this method is used by executor service threads to update MAP
	 * @param salesPerson
	 * @param startDate
	 * @param endDate
	 * @param stage
	 */
	public void updateTopSalesPersonMap(final String salesPerson, final String startDate, final String endDate, 
			final String stage, final List<String> crmOpportunityIds) {
		Client client = this.getTransportClient();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(salesPerson)) {
			boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_OWNER_RAW, salesPerson));
		}

		if(StringUtils.isNotBlank(stage)) {
			boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stage));
		}

		if(CollectionUtils.isNotEmpty(crmOpportunityIds)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, crmOpportunityIds));
		}
		
		SearchRequestBuilder searchRequestBuilder =  client.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				//.setPostFilter(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate))
				.setScroll(new TimeValue(6000))
				.setSize(1000)
				.setSearchType(SearchType.SCAN);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunityIds = new ArrayList<>();
		while(true) {
			for (SearchHit hit : searchResponse.getHits().getHits()) {
				opportunityIds.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}

		double invoiceAmount = this.erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, startDate, endDate);
		RevenueOpportunitiesData revenuOpportunityData = new RevenueOpportunitiesData();
		revenuOpportunityData.setRevenueAmount(invoiceAmount);
		revenuOpportunityData.setOpportunityIds(opportunityIds);
		revenuOpportunityData.setLostOpportunityIds(this.getLostOpportunitiesBySalesPerson(salesPerson, startDate, endDate));
		topSalesPersonMap.put(salesPerson, revenuOpportunityData);
	}

	/**
	 * Get all the sales person revenu with in the time frame
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	@Cacheable
	public Map<String, Object> getAllSalesPersonsWithInTimeFrameByOpportunities(final String startDate, final String endDate, final List<String> opportunityIds) {
		topSalesPersonMap = new ConcurrentHashMap<>();
		ExecutorService executorService =  Executors.newFixedThreadPool(70);
		// Creating a bool query builder request 
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(opportunityIds)) {
			boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		}
		
		if(StringUtils.isNotEmpty(startDate) && StringUtils.isNotEmpty(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).to(endDate));
		}
		
		SearchRequestBuilder srb = this.getTransportClient()
				.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(AggregationBuilders.terms(SearchConstants.SALES_PERSON_AGGREGATION)
						.field(SearchConstants.SALES_PERSON_RAW).size(0));
		SearchResponse searchResponse = esQueryUtils.execute(srb);
		
		Terms salesPersonTerms = searchResponse.getAggregations().get(SearchConstants.SALES_PERSON_AGGREGATION);
		Collection<Terms.Bucket> salesPersonBuckets = salesPersonTerms.getBuckets();

		for(final Terms.Bucket salesPersonBucket: salesPersonBuckets) {
			executorService.submit(new Runnable() {
							@Override
							public void run() {
					updateTopSalesPersonMap(salesPersonBucket.getKey(), startDate, endDate, 
							OpportunityStagesEnum.CLOSED_WON.getText(), opportunityIds);
					}
			});
		}
		
		executorService.shutdown();
		
		try {
			if(!executorService.awaitTermination(1, TimeUnit.MINUTES))
				executorService.shutdownNow();
		}
		catch (InterruptedException e) {
			LOG.error("Interruped Exception while updating the salesperson map:" + e.getMessage());
		}
		return MiriSearchUtils.sortMapByObjectValue(topSalesPersonMap);
	}

	/**
	 * Get Lost the opportunities for sales person
	 * @param salesPerson
	 * @return
	 */
	public List<String> getLostOpportunitiesBySalesPerson(String salesPerson, String startDate, String endDate) {
		SearchResponse searchResponse = this.getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setSize(100000)
				.setQuery(QueryBuilders.boolQuery()
						.must(QueryBuilders.termsQuery(SearchConstants.OWNER_RAW, salesPerson))
						.must(QueryBuilders.rangeQuery(SearchConstants.CREATED_ON).gte(startDate).lt(endDate)))
				.setPostFilter(FilterBuilders.termFilter(SearchConstants.STAGE_RAW, SearchConstants.OPPORTUNITY_CLOSED_LOST))
				.get();
		SearchHits searchHits = searchResponse.getHits();
		List<String> opportunityIds = new ArrayList<>();
		for(SearchHit searchHit: searchHits) {
			opportunityIds.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
		}
		return opportunityIds;
	}

	/**
	 * Get Competitive Win Rate for Sales Person
	 * @param salesPersonData
	 * @return\
	 * @author rammoole
	 */
	public List<WinLossData> getCompetitiveWinRateForSalesPerson(List<Object> salesPersonData) {
		return erpOpportunityCompetitorService.getWinRateForCompetitors(salesPersonData, null, null);
	}

	/**
	 * Win Loss Data for other sales persons. here other sales persons mean by is there are more than 25 competitors.
	 * rest of the sales persons other than top 25
	 * @param otherSalesPersonsData
	 * @return
	 * @author rammoole
	 */
	public WinLossData getWinRateForOtherSalesPerson(List<Object> otherSalesPersonsData) {
		return this.erpOpportunityCompetitorService.getWinRateForOtherCompetitors(otherSalesPersonsData, null, null);
	}

	/**
	 * Getting list of sales persons for both map opprotunitites and Sales
	 * Campaign opporutnities
	 * 
	 * @param mapOpportunities
	 * @return
	 */

	public List<TopCustomerSalesPersonData> getSalesPersonList(List<String> mapOpportunities) {
		LOG.info("sales person list..");
		List<TopCustomerSalesPersonData> primaryCampignSouceList = new ArrayList<>();
		SearchResponse searchResponse = this.getTransportClient().prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_OPPORTUNITY)
				.setQuery(QueryBuilders.termsQuery(SearchConstants.OPPORTUNITY_ID_RAW, mapOpportunities))
				.addAggregation(
						AggregationBuilders.terms(SearchConstants.SALES_PERSON_AGGREGATION)
						.field(SearchConstants.OWNER_RAW)
						.subAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_ACCOUNT_ID)
								.field(SearchConstants.ACCOUNT_ID)
								.subAggregation(AggregationBuilders
										.topHits(SearchConstants.TOP_OPPORTUNITIES_AGGREGATION).setSize(100000)
										.setFetchSource(SearchConstants.OPPORTUNITY_ID, null))))
				.setSearchType(SearchType.QUERY_AND_FETCH).get();

		Aggregations aggregations = searchResponse.getAggregations();

		Terms terms = aggregations.get(SearchConstants.SALES_PERSON_AGGREGATION);
		Collection<Terms.Bucket> salesPersonBuckets = terms.getBuckets();
		// looping through parent campaign buckets
		for (Terms.Bucket bucket : salesPersonBuckets) {
			LOG.info("Sales Persion Name:" + bucket.getKey());

			Terms accountTerms = bucket.getAggregations().get(SearchConstants.CAMPAIGN_ACCOUNT_ID);
			Collection<Terms.Bucket> accountBuckets = accountTerms.getBuckets();
			// looping thorough account buckets
			for (Terms.Bucket accountBucket : accountBuckets) {
				TopCustomerSalesPersonData topCustomerCampaignPojo = new TopCustomerSalesPersonData();
				topCustomerCampaignPojo.setSalesPerson(bucket.getKey());
				LOG.info("Account id:" + accountBucket.getKey());
				topCustomerCampaignPojo.setAccountId(accountBucket.getKey());
				TopHits oppHits = accountBucket.getAggregations().get(SearchConstants.TOP_OPPORTUNITIES_AGGREGATION);
				List<String> campaignOpportunity = new ArrayList<>();
				// get all hits for opporutnity ids
				for (SearchHit topHit : oppHits.getHits()) {
					LOG.info("Opportunity for Account id :"
							+ topHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
					campaignOpportunity.add(topHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				}
				topCustomerCampaignPojo.setOpportunities(campaignOpportunity);
				primaryCampignSouceList.add(topCustomerCampaignPojo);
			}
		}

		return primaryCampignSouceList;
	}

	/* (non-Javadoc)
	 * @see com.miri.search.service.MiriSearchService#getIndex()
	 */
	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	/* (non-Javadoc)
	 * @see com.miri.search.service.MiriSearchService#getDocumentType()
	 */
	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_USER.getText();
	}
}
