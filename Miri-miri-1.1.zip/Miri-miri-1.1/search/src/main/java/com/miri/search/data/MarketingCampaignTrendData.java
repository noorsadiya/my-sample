package com.miri.search.data;

import java.io.Serializable;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class MarketingCampaignTrendData implements Comparator<MarketingCampaignTrendData>,Serializable{
	
	private String campaignId;
	
	private String campaignName;
	
	private Map<Integer, Long> count;
	
	private Map<Integer, Double> averageCost;
	
	private Long totalCount;
	
	private String name;
	
	private List<MarketingCampaignTrendData> metricData;
	
	public void setMetricData(List<MarketingCampaignTrendData> metricData) {
		this.metricData = metricData;
	}
	
	public List<MarketingCampaignTrendData> getMetricData() {
		return metricData;
	}

	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the campaignId
	 */
	public String getCampaignId() {
		return campaignId;
	}


	/**
	 * @param campaignId the campaignId to set
	 */
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}


	/**
	 * @return the campaignName
	 */
	public String getCampaignName() {
		return campaignName;
	}


	/**
	 * @param campaignName the campaignName to set
	 */
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}


	/**
	 * @return the count
	 */
	public Map<Integer, Long> getCount() {
		return count;
	}


	/**
	 * @param count the count to set
	 */
	public void setCount(Map<Integer, Long> count) {
		this.count = count;
	}


	/**
	 * @return the averageCost
	 */
	public Map<Integer, Double> getAverageCost() {
		return averageCost;
	}


	/**
	 * @param averageCost the averageCost to set
	 */
	public void setAverageCost(Map<Integer, Double> averageCost) {
		this.averageCost = averageCost;
	}


	/**
	 * @return the totalCount
	 */
	public Long getTotalCount() {
		return totalCount;
	}


	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}


	@Override
	public int compare(MarketingCampaignTrendData arg0, MarketingCampaignTrendData arg1) {
		 return arg0.getTotalCount().compareTo(arg1.getTotalCount());
	}
}
