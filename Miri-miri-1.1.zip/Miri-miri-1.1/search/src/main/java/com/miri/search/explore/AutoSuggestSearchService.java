/**
 * 
 */
package com.miri.search.explore;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.MultiSearchRequestBuilder;
import org.elasticsearch.action.search.MultiSearchResponse;
import org.elasticsearch.action.search.MultiSearchResponse.Item;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.MatchQueryBuilder.Operator;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticsearchConfig;
import com.miri.search.explore.autosuggest.AutoSuggestBuilderIdentifier;
import com.miri.search.explore.autosuggest.AutoSuggestRequest;
import com.miri.search.explore.autosuggest.AutoSuggestRequest.RequestItem;
import com.miri.search.explore.autosuggest.AutoSuggestRequestBuilder;

/**
 * AutoSuggestSearchService: Contains methods to make ES call and retrieve auto
 * suggestion terms.
 * 
 * @author Chandra
 *
 */
@Component
public class AutoSuggestSearchService {

	private static final Logger LOGGER = Logger.getLogger(AutoSuggestSearchService.class);

	@Autowired
	ElasticsearchConfig elasticsearchConfig;

	@Autowired
	AutoSuggestBuilderIdentifier autoSuggestBuilderIdentifier;

	/**
	 * Auto suggest.
	 * 
	 * @param searchKey
	 * @return
	 */
	public Map<String, String> autoSuggest(final String type, final String key, final String startDate,
			final String endDate, boolean startsWith) {

		Map<String, String> suggestions = new LinkedHashMap<>();
		try {
			AutoSuggestRequestBuilder autoSuggestRequestBuilder = autoSuggestBuilderIdentifier.getBuilder(type);
			autoSuggestRequestBuilder.buildAutoSuggestRequest();
			AutoSuggestRequest autoSuggestRequest = autoSuggestRequestBuilder.getAutoSuggestRequest();

			// Use auto suggest request to make ES call and get list of
			// suggestions.
			List<RequestItem> requestItems = autoSuggestRequest.getRequestItems();

			for (RequestItem item : requestItems) {
				suggestions.putAll(retrieveSuggestions(item, key, startDate, endDate, startsWith));
			}
		} catch (Exception ex) {
			LOGGER.error("Error occurred while executing auto suggest:" + key, ex);
		}
		return suggestions;

	}

	/**
	 * Retrieves buckets with suggestions.
	 * 
	 * @param entry
	 * @param key
	 */
	private Map<String, String> retrieveSuggestions(RequestItem requestItem, final String key, final String startDate,
			final String endDate, boolean startsWith) {
		Map<String, String> suggestionsMap = new LinkedHashMap<>();
		final String AGG_NAME = "auto_suggest_aggs";
		final String TOP_HITS_AGG_NAME = "auto_suggest_aggs_top_hits";
		try {
			String documentType = requestItem.getDocType();
			List<String> fields = requestItem.getFields();

			String index = documentType.substring(0, documentType.indexOf("_"));
			MultiSearchRequestBuilder multiSearchRequestBuilder = new MultiSearchRequestBuilder(
					elasticsearchConfig.getTransportClient());

			for (String field : fields) {
				multiSearchRequestBuilder.add(constructSearchRequestBuilder(requestItem, key, documentType, AGG_NAME,
						TOP_HITS_AGG_NAME, index, field, startDate, endDate, startsWith));
			}
			MultiSearchResponse multiSearchResponse = multiSearchRequestBuilder.get();

			Item[] responseItems = multiSearchResponse.getResponses();
			for (int i = 0; i < responseItems.length; i++) {
				populateSuggestionsToMap(requestItem, suggestionsMap, AGG_NAME, TOP_HITS_AGG_NAME, responseItems, i,
						index, documentType);
			}
		} catch (Exception ex) {
			LOGGER.error("Error occurred while retrieving Suggestions:" + key, ex);
		}

		return suggestionsMap;
	}

	/**
	 * Constructs searchrequestbuilder that will be fed to multisearchrequest
	 * builder.
	 * 
	 * @param requestItem
	 * @param key
	 * @param documentType
	 * @param AGG_NAME
	 * @param TOP_HITS_AGG_NAME
	 * @param index
	 * @param field
	 * @return
	 */
	private SearchRequestBuilder constructSearchRequestBuilder(RequestItem requestItem, String key, String documentType,
			final String AGG_NAME, final String TOP_HITS_AGG_NAME, String index, String field, final String startDate,
			final String endDate, boolean startsWith) {
		final String RAW = ".raw";

		int fuzziness = calculateFuzziness(key);
		Operator operator = IdentifyOperator(key);
		key = cleanKey(key);

		String identifier = StringUtils.isNotBlank(requestItem.getIdentifier()) ? requestItem.getIdentifier() : field;

		String aggregationOnField = field + RAW;
		if (fuzziness == 0)
			field = field + RAW;

		QueryBuilder queryBuilder = null;
		if(startsWith) {
			queryBuilder =  QueryBuilders.matchPhrasePrefixQuery(field, key);
		} else {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
//		boolFilterBuilder.must(FilterBuilders.rangeFilter("createdDate").gte(startDate).lte(endDate));
		boolFilterBuilder.must(FilterBuilders.termFilter(field, key));
		boolFilterBuilder.must(FilterBuilders
				.queryFilter((QueryBuilders.matchQuery(field, key).operator(operator).fuzziness(fuzziness))));

		queryBuilder = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder);
		}
		SearchRequestBuilder searchRequestBuilder = elasticsearchConfig.getTransportClient().prepareSearch(index)
				.setTypes(documentType)
				.setQuery(queryBuilder);

		searchRequestBuilder.addAggregation(AggregationBuilders.terms(AGG_NAME).field(aggregationOnField).size(0)
				.subAggregation(AggregationBuilders.topHits(TOP_HITS_AGG_NAME).setFetchSource(identifier, null)));
		return searchRequestBuilder;
	}

	/**
	 * Constructs searchrequestbuilder that will be fed to multisearchrequest
	 * builder. This method results in fuzzy match.
	 * 
	 * @param requestItem
	 * @param key
	 * @param documentType
	 * @param AGG_NAME
	 * @param TOP_HITS_AGG_NAME
	 * @param index
	 * @param field
	 * @return
	 */
	private SearchRequestBuilder constructSearchRequestBuilder(RequestItem requestItem, String key,
			String documentType, final String AGG_NAME, final String TOP_HITS_AGG_NAME, String index, String field) {
		final String RAW = ".raw";

		int fuzziness = calculateFuzziness(key);
		Operator operator = IdentifyOperator(key);
		key = cleanKey(key);

		String identifier = StringUtils.isNotBlank(requestItem.getIdentifier()) ? requestItem.getIdentifier() : field;
		
		String aggregationOnField = field + RAW;
		if(fuzziness == 0)
			field = field+ RAW;
		
		SearchRequestBuilder searchRequestBuilder = elasticsearchConfig.getTransportClient().prepareSearch(index)
				.setTypes(documentType).setQuery(QueryBuilders.matchQuery(field, key).operator(operator)
						.fuzziness(fuzziness));

		searchRequestBuilder.addAggregation(AggregationBuilders.terms(AGG_NAME).field(aggregationOnField).size(0)
				.subAggregation(AggregationBuilders.topHits(TOP_HITS_AGG_NAME).setFetchSource(identifier, null)));
		return searchRequestBuilder;
	}
	
	/**
	 * Removes wrapped double quotes if exists.
	 * 
	 * @param key
	 * @return
	 */
	private static String cleanKey(String key) {
		if (StringUtils.isNotBlank(key) && key.contains("\""))
			return key.replace("\"", StringUtils.EMPTY);

		return key;
	}

	/**
	 * Populates a linked hash map that contains key as identifier provided and
	 * value as auto suggest term.
	 * 
	 * @param requestItem
	 * @param bucketMap
	 * @param AGG_NAME
	 * @param TOP_HITS_AGG_NAME
	 * @param responseItems
	 * @param i
	 */
	private void populateSuggestionsToMap(RequestItem requestItem, Map<String, String> suggestions,
			final String AGG_NAME, final String TOP_HITS_AGG_NAME, Item[] responseItems, int i, String index,
			String docType) {
		Terms suggestionTerms = responseItems[i].getResponse().getAggregations().get(AGG_NAME);

		if (null != suggestionTerms) {
			for (Bucket bucket : suggestionTerms.getBuckets()) {
				TopHits hits = bucket.getAggregations().get(TOP_HITS_AGG_NAME);

				if (null != hits && hits.getHits().getTotalHits() > 0)
					if (hits.getHits().getAt(0).getSource() != null) {
						String id = null;
						if (StringUtils.isNotBlank(requestItem.getIdentifier()))
							id = requestItem.getIdentifier() + "|"
									+ (String) hits.getHits().getAt(0).getSource().get(requestItem.getIdentifier());
						else if (hits.getHits().getAt(0).getSource().keySet().size() > 0)
							id = (String) hits.getHits().getAt(0).getSource().keySet().iterator().next() + "|"
									+ bucket.getKey();

						if (StringUtils.isNotBlank(id))
							// id is constructed as docRefUniqueId|Value to be searched for|index|document Type
							suggestions.put(bucket.getKey(), id + "|" + index + "|" + docType);
					}
			}
		}
	}

	/**
	 * Returns AND if looking for exact match", else returns OR.
	 * 
	 * @param key
	 * @return
	 */
	private Operator IdentifyOperator(String key) {

		if (key.startsWith("\""))
			return Operator.AND;

		return Operator.OR;
	}

	/**
	 * Returns zero fuzziness if search key starts with double quotes.
	 * 
	 * @param key
	 * @return
	 */
	private int calculateFuzziness(final String key) {

		if (key.startsWith("\""))
			return 0;

		return 2;
	}

}
