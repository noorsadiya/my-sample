/**
 * 
 */
package com.miri.search.esutils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.elasticsearch.action.count.CountRequestBuilder;
import org.elasticsearch.action.count.CountResponse;
import org.elasticsearch.action.get.GetRequestBuilder;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticsearchConfig;
import com.miri.cis.entity.ESEntity;

/**
 * ESQueryUtils: Provides utility methods that are frequently used to construct
 * query and fetch response.
 * 
 * @author Chandra
 *
 */
@Component
public class ESQueryUtils {

	@Autowired
	private ElasticsearchConfig elasticsearchConfig;

	/**
	 * Returns unique document based on given document ID.
	 * 
	 * @param value
	 * @return
	 */
	public ESEntity getUniqueDocumentByDocId(final String doc, final String index, final String field,
			final String value) {
		SearchResponse searchResponse = elasticsearchConfig.getTransportClient().prepareSearch(index).setTypes(doc)
				.setQuery(QueryBuilders.termsQuery(field, value)).execute().actionGet();
		SearchHits searchHits = searchResponse.getHits();
		ESEntity esEntity = null;
		if (searchHits.getTotalHits() > 0)
			esEntity = ESObjectMapper.getObject(searchHits.getAt(0).getSource(), doc, index);
		return esEntity;
	}

	/**
	 * Returns unique document based on given document ID's.
	 * 
	 * @param value
	 * @return
	 */
	public ESEntity getUniqueDocumentByDocIdMap(final String doc, final String index,
			TreeMap<String, Object> fieldAndValueMap) {

		BoolQueryBuilder boolQueryBuilder = new BoolQueryBuilder();
		if (MapUtils.isNotEmpty(fieldAndValueMap)) {
			Iterator<String> fieldItr = fieldAndValueMap.keySet().iterator();
			while (fieldItr.hasNext()) {
				String field = fieldItr.next();
				boolQueryBuilder.must(QueryBuilders.termQuery(field, fieldAndValueMap.get(field)));
			}
		}

		SearchResponse searchResponse = elasticsearchConfig.getTransportClient().prepareSearch(index).setTypes(doc)
				.setQuery(boolQueryBuilder).execute().actionGet();
		SearchHits searchHits = searchResponse.getHits();
		ESEntity esEntity = null;
		if (searchHits.getTotalHits() > 0)
			esEntity = ESObjectMapper.getObject(searchHits.getAt(0).getSource(), doc, index);
		return esEntity;
	}

	/**
	 * Returns all matched documents based on given foreign key ID.
	 * 
	 * @param value
	 * @return
	 */
	public List<ESEntity> getMultipleDocsByFKId(final String doc, final String index, final String field,
			final String value) {
		SearchResponse searchResponse = elasticsearchConfig.getTransportClient().prepareSearch(index).setTypes(doc)
				.setQuery(QueryBuilders.termsQuery(field, value)).execute().actionGet();
		SearchHits searchHits = searchResponse.getHits();

		List<ESEntity> entities = new ArrayList<>();
		Iterator<SearchHit> searcHitsItr = searchHits.iterator();
		while (searcHitsItr.hasNext()) {
			SearchHit searchHit = searcHitsItr.next();
			entities.add(ESObjectMapper.getObject(searchHit.getSource(), doc, index));

		}
		return entities;
	}
	
	/**
	 * Returns all matched document fields based on given foreign key ID and field.
	 * 
	 * @param value
	 * @return
	 */
	public List<String> getMultipleDocsForFieldByFKId(final String doc, final String index, final String field,
			final String value, final String whichField) {
		SearchResponse searchResponse = elasticsearchConfig.getTransportClient().prepareSearch(index).setTypes(doc)
				.setQuery(QueryBuilders.termsQuery(field, value)).addField(whichField).execute().actionGet(); 
		SearchHits searchHits = searchResponse.getHits();

		List<String> fields = new ArrayList<>();
		Iterator<SearchHit> searcHitsItr = searchHits.iterator();
		while (searcHitsItr.hasNext()) {
			SearchHit searchHit = searcHitsItr.next();
			fields.add(String.valueOf(searchHit.getFields().get(whichField)));

		}
		return fields;
	}

	/**
	 * Get ESEntity Objects by Ids
	 * 
	 * @param ids
	 * @return
	 */
	public List<ESEntity> getEntitiesByIds(final String doc, final String index, final String field,
			Collection<String> ids) {
		SearchRequestBuilder srb = elasticsearchConfig.getTransportClient().prepareSearch(index).setTypes(doc)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
						FilterBuilders.boolFilter().must(FilterBuilders.termsFilter(field, ids))));
		if (!CollectionUtils.isEmpty(ids)) {
			srb.setSize(ids.size());
		}
		SearchResponse searchResponse = srb.get();
		List<ESEntity> esEntities = new ArrayList<>();
		for (SearchHit hit : searchResponse.getHits()) {
			esEntities.add(ESObjectMapper.getObject(hit.getSource(), doc, index));
		}
		return esEntities;
	}

	public SearchResponse execute(final SearchRequestBuilder searchRequestBuilder) {
		return searchRequestBuilder.get();

	}

	public SearchResponse execute(final SearchScrollRequestBuilder searchScrollRequestBuilder) {
		return searchScrollRequestBuilder.get();
	}
	
	public GetResponse execute(final GetRequestBuilder getRequestBuilder) {
		return getRequestBuilder.get();
	}
	
	public CountResponse execute(final CountRequestBuilder countRequestBuilder) {
		return countRequestBuilder.get();
	}
}
