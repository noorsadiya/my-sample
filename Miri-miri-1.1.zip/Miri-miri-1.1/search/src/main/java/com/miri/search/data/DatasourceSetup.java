package com.miri.search.data;

import java.io.Serializable;

/**
 * @author supraja
 *
 */
public class DatasourceSetup implements Serializable {

	private static final long serialVersionUID = 163301503567370425L;

	private String system;

	private String url;

	private String username;

	private String password;

	private String clientId;

	private String clientSecret;

	private String companyName;

	private String email;

	private String apiUserKey;

	private Boolean showUrl;

	private Boolean showUsername;

	private Boolean showPassword;

	private Boolean showClientId;

	private Boolean showClientSecret;

	private Boolean showCompanyName;

	private Boolean showEmail;

	private Boolean showApiUserKey;

	private Boolean isConnected;

	private String securityToken;

	private int datasourceId;

	private String instanceName;

	/**
	 * @return the system
	 */
	public String getSystem() {
		return system;
	}

	/**
	 * @param system the system to set
	 */
	public void setSystem(String system) {
		this.system = system;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the clientSecret
	 */
	public String getClientSecret() {
		return clientSecret;
	}

	/**
	 * @param clientSecret the clientSecret to set
	 */
	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the apiUserKey
	 */
	public String getApiUserKey() {
		return apiUserKey;
	}

	/**
	 * @param apiUserKey the apiUserKey to set
	 */
	public void setApiUserKey(String apiUserKey) {
		this.apiUserKey = apiUserKey;
	}

	/**
	 * @return the showUrl
	 */
	public Boolean getShowUrl() {
		return showUrl;
	}

	/**
	 * @param showUrl the showUrl to set
	 */
	public void setShowUrl(Boolean showUrl) {
		this.showUrl = showUrl;
	}

	/**
	 * @return the showUsername
	 */
	public Boolean getShowUsername() {
		return showUsername;
	}

	/**
	 * @param showUsername the showUsername to set
	 */
	public void setShowUsername(Boolean showUsername) {
		this.showUsername = showUsername;
	}

	/**
	 * @return the showPassword
	 */
	public Boolean getShowPassword() {
		return showPassword;
	}

	/**
	 * @param showPassword the showPassword to set
	 */
	public void setShowPassword(Boolean showPassword) {
		this.showPassword = showPassword;
	}

	/**
	 * @return the showClientId
	 */
	public Boolean getShowClientId() {
		return showClientId;
	}

	/**
	 * @param showClientId the showClientId to set
	 */
	public void setShowClientId(Boolean showClientId) {
		this.showClientId = showClientId;
	}

	/**
	 * @return the showClientSecret
	 */
	public Boolean getShowClientSecret() {
		return showClientSecret;
	}

	/**
	 * @param showClientSecret the showClientSecret to set
	 */
	public void setShowClientSecret(Boolean showClientSecret) {
		this.showClientSecret = showClientSecret;
	}

	/**
	 * @return the showCompanyName
	 */
	public Boolean getShowCompanyName() {
		return showCompanyName;
	}

	/**
	 * @param showCompanyName the showCompanyName to set
	 */
	public void setShowCompanyName(Boolean showCompanyName) {
		this.showCompanyName = showCompanyName;
	}

	/**
	 * @return the showEmail
	 */
	public Boolean getShowEmail() {
		return showEmail;
	}

	/**
	 * @param showEmail the showEmail to set
	 */
	public void setShowEmail(Boolean showEmail) {
		this.showEmail = showEmail;
	}

	/**
	 * @return the showApiUserKey
	 */
	public Boolean getShowApiUserKey() {
		return showApiUserKey;
	}

	/**
	 * @param showApiUserKey the showApiUserKey to set
	 */
	public void setShowApiUserKey(Boolean showApiUserKey) {
		this.showApiUserKey = showApiUserKey;
	}

	/**
	 * @return the isConnected
	 */
	public Boolean getIsConnected() {
		return isConnected;
	}

	/**
	 * @param isConnected the isConnected to set
	 */
	public void setIsConnected(Boolean isConnected) {
		this.isConnected = isConnected;
	}

	/**
	 * @return the securityToken
	 */
	public String getSecurityToken() {
		return securityToken;
	}

	/**
	 * @param securityToken the securityToken to set
	 */
	public void setSecurityToken(String securityToken) {
		this.securityToken = securityToken;
	}

	/**
	 * @return the datasourceId
	 */
	public int getDatasourceId() {
		return datasourceId;
	}

	/**
	 * @param datasourceId the datasourceId to set
	 */
	public void setDatasourceId(int datasourceId) {
		this.datasourceId = datasourceId;
	}

	/**
	 * @return the instanceName
	 */
	public String getInstanceName() {
		return instanceName;
	}

	/**
	 * @param instanceName the instanceName to set
	 */
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("[system=");
		builder.append(system);
		builder.append(", url=");
		builder.append(url);
		builder.append(", username=");
		builder.append(username);
		builder.append(", password=");
		builder.append(password);
		builder.append("]");
		return builder.toString();
	}

}
