package com.miri.search.dynamicIndexServices.crm;

import java.util.Collection;
import java.util.List;

import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.children.ChildrenBuilder;
import org.elasticsearch.search.aggregations.bucket.children.InternalChildren;
import org.elasticsearch.search.aggregations.bucket.filter.Filter;
import org.elasticsearch.search.aggregations.bucket.filter.FilterAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.data.jpa.util.AppSalesStageContainer;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.WinLossData;
import com.miri.search.dynamicIndexServices.MappedConstants;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.map.MapCampaignService;

@Component
public class CompetitiveWinRateService extends MiriSearchService{
	
	@Autowired
	MapCampaignService mapCampaignService;
	
	@Autowired
	private AppSalesStageContainer appSalesStageContainer;

	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_CAMPAIGN_OPPORTUNITY_MAPPED.getText();
	}
	
	public WinLossData competitiveWinRateData(String startDate, String endDate, Boolean isMarketing){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate));
		List<String> wonStages = appSalesStageContainer.getClosedWonMappedStages();
		List<String> lostStages = appSalesStageContainer.getClosedLostMappedStages();
		if(null != isMarketing){
			List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();	
			if(isMarketing){
				boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
			}else
				boolFilterBuilder.mustNot(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}
		SumBuilder lostSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_AMOUNT);
		
		SumBuilder wonSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		
		FilterAggregationBuilder lostfilterdAggregation = AggregationBuilders.filter(MappedConstants.FILTERED_AGGREGATION)
				.filter(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, lostStages))
				.subAggregation(lostSumBuilder);
		
		
		TermsBuilder opportunityAggregation  = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		
		
		ChildrenBuilder childrenBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				  .childType(ElasticSearchEnums.OPPORTUNITY_INVOICE_MAPPED.getText()).subAggregation(wonSumBuilder).subAggregation(opportunityAggregation);
		
		FilterAggregationBuilder wonfilterdAggregation = AggregationBuilders.filter(MappedConstants.GRAND_FILTERED_AGGREGATION)
				.filter(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, wonStages))
				.subAggregation(childrenBuilder);
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(wonfilterdAggregation).addAggregation(lostfilterdAggregation);
		
		SearchResponse searchResponse = searchRequestBuilder.get();
		WinLossData winLossData = new WinLossData();
		if (searchResponse.getAggregations() != null) {
			Filter losrTerms = searchResponse.getAggregations()
					.get(MappedConstants.FILTERED_AGGREGATION);
			Sum lostSum = losrTerms.getAggregations().get(SearchConstants.SUM_AGGREGATION);
			winLossData.setLostAmount(lostSum.getValue());
			winLossData.setLostCount(losrTerms.getDocCount());
			Filter wonTerms = searchResponse.getAggregations()
					.get(MappedConstants.GRAND_FILTERED_AGGREGATION);
			InternalChildren invoiceChildren =  wonTerms.getAggregations().get(MappedConstants.CHILDREN);
			Sum wonSum = invoiceChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
			Terms opportunityTerms = invoiceChildren.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
			Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
			winLossData.setWonAmount(wonSum.getValue());
			winLossData.setWonCount(opportunityBuckets.size());
		}
		
		return winLossData;
	}

}
