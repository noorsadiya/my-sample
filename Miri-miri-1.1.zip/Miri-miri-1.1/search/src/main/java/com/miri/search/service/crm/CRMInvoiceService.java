/**
 * 
 */
package com.miri.search.service.crm;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.CrmInvoice;
import com.miri.cis.entity.ESEntity;
import com.miri.cis.entity.ErpInvoice;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;

/**
 * CRMInvoiceService: Provides service methods for CRM invoice document.
 * 
 * @author Chandra
 *
 */
@Component
public class CRMInvoiceService extends MiriSearchService {
	
	@Autowired
	ESQueryUtils esQueryUtils;

    @Autowired
    ERPInvoiceService erpInvoiceService;

    public List<CrmInvoice> getCRMInvoicesByOpportunityId(final String opportunityId) {
        // Get ERP Invoice
        Map<String, ErpInvoice> erpInvoiceMap = erpInvoiceService.getInvoicesAsMapByOpportunityId(opportunityId);
       
        return getCRMInvoicesByListOfInvoiceIds(erpInvoiceMap.keySet());
    }
    
    /**
     * Get CRM Invoices from given order Id.
     * 
     * @param OrderId
     * @return
     */
    public List<ESEntity> getCRMInvoicesByOrderId(final String OrderId) {
        List<ESEntity> esEntities = esQueryUtils.getMultipleDocsByFKId(getDocumentType(), getIndex(), "orderId.raw", OrderId);
        return esEntities;
    }

    /**
     * Fetches CRM invoice for the given invoice ID.
     * 
     * @param invoiceId
     * @return
     */
    public CrmInvoice getCRMInvoiceByInvoiceId(final String invoiceId) {
        CrmInvoice crmInvoice = (CrmInvoice)esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), "invoiceId.raw", invoiceId);
        
        return crmInvoice;
    }
    
    
    /**
     * Get All CRM Invoices for the given list of invoice Id's.
     * 
     * @param invoiceIds
     * @return
     */
    public List<CrmInvoice> getCRMInvoicesByListOfInvoiceIds(Set<String> invoiceIds) {
        
        return null;
    }

    @Override
    public String getIndex() {
        return ElasticSearchEnums.CRM.getText();
    }

    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.CRM_INVOICE.getText();
    }
}
