/**
 * 
 */
package com.miri.search.exception;

/**
 * @author Chandra
 *
 */
public class MiriSearchException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MiriSearchException() {
	}

	public MiriSearchException(String message) {
		super(message);
	}

	public MiriSearchException(Throwable cause) {
		super(cause);
	}

	public MiriSearchException(String message, Throwable cause) {
		super(message, cause);
	}

	public MiriSearchException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
