package com.miri.search.domain.guage;

import java.io.Serializable;

import org.elasticsearch.search.SearchHits;

public class GaugeLevel implements Serializable{
	
	private int guageLevel;
	private boolean islastLevel;
	private SearchHits searchHits;
	private int validMetricDataCount;
	private String documentType;
	private GaugeRequest guageRequest;
	
	public GaugeLevel(int guageLevel, boolean islastLevel, SearchHits searchHits, int validMetricDataCount,String documentType,
			GaugeRequest guageRequest) {
		super();
		this.guageLevel = guageLevel;
		this.islastLevel = islastLevel;
		this.searchHits = searchHits;
		this.validMetricDataCount = validMetricDataCount;
		this.documentType=documentType;
		this.guageRequest=guageRequest;
	}
	
	public int getGuageLevel() {
		return guageLevel;
	}
	public void setGuageLevel(int guageLevel) {
		this.guageLevel = guageLevel;
	}
	public boolean isIslastLevel() {
		return islastLevel;
	}
	public void setIslastLevel(boolean islastLevel) {
		this.islastLevel = islastLevel;
	}
	public SearchHits getSearchHits() {
		return searchHits;
	}
	public void setSearchHits(SearchHits searchHits) {
		this.searchHits = searchHits;
	}
	public int getValidMetricDataCount() {
		return validMetricDataCount;
	}
	public void setValidMetricDataCount(int validMetricDataCount) {
		this.validMetricDataCount = validMetricDataCount;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public GaugeRequest getGuageRequest() {
		return guageRequest;
	}

	public void setGuageRequest(GaugeRequest guageRequest) {
		this.guageRequest = guageRequest;
	}
	
	
	

}
