/**
 * 
 */
package com.miri.search.service.map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.MapSalesPerson;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;

/**
 * @author Chandra
 *
 */
@Component
public class MapSalesPersonService extends MiriSearchService {

	@Autowired
	ESQueryUtils esQueryUtils;
	
	
    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getIndex()
     */
    @Override
    public String getIndex() {
        return ElasticSearchEnums.MAP.getText();
    }

    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getDocumentType()
     */
    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.MAP_SALESPERSON.getText();
    }

    /**
     * Returns lead details for the given lead id.
     * 
     * @param leadOwnerUsername
     * @return
     */
    public MapSalesPerson getLeadOwnerByName(final String leadOwnerUsername) {
        return (MapSalesPerson)esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), "userName.raw", leadOwnerUsername);
    }


    
}
