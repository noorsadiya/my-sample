package com.miri.search.data;

public class ModifiableObject {
	
	private Double doubleValue;
	
	public Double getDoubleValue() {
		return doubleValue;
	}
	
	public void setDoubleValue(Double doubleValue) {
		this.doubleValue = doubleValue;
	}
	
	

}
