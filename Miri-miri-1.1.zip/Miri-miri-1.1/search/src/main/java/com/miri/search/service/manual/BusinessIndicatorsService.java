package com.miri.search.service.manual;

import static com.miri.search.utils.MiriDateUtils.MONTH_NAMES;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.crsh.console.jline.internal.Log;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.ManualBusinessStrategy;
import com.miri.cis.entity.ManualIndicatorTarget;
import com.miri.cis.entity.ManualIndicatorTarget.IndicatorValue;
import com.miri.cis.entity.MarketingInfluencedRevenueTarget;
import com.miri.cis.entity.MonthlyTarget;
import com.miri.cis.utilities.DateUtilities;
import com.miri.data.jpa.domain.ImpactIndicatorName;
import com.miri.data.jpa.service.ImpactIndicatorService;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.FiscalDatesData;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.utils.MiriDateUtils;

@Service
public class BusinessIndicatorsService extends MiriSearchService {
	private static final Logger LOGGER = Logger.getLogger(BusinessIndicatorsService.class);

	public static final String PERIOD_FISCAL = "fiscal";

	@Autowired
	private ManualAccountStrategyService manualAccountStrategyService;

	@Autowired
	private ImpactIndicatorService impactIndicatorService;

	@Autowired
	ManualBusinessStrategySearchService businessStrategyService;

	public ManualIndicatorTarget getIndicatorTarget(String indicatorType) {
		ManualIndicatorTarget manualIndicatorTarget = null;

		Client client = getTransportClient();

		SearchRequestBuilder searchBuilder = client.prepareSearch(SearchConstants.MANUAL)
												 .setTypes(SearchConstants.MANUAL_INDICATOR_TYPE)
												 .setSearchType(SearchType.QUERY_AND_FETCH)
												 .setQuery(QueryBuilders.matchQuery(ManualIndicatorTarget.FIELDNAME_INDICATORTYPE, indicatorType))
												 .addSort(ManualIndicatorTarget.FIELDNAME_LASTMODIFIEDDATE, SortOrder.DESC)
												 .setFrom(0)
												 .setSize(1);
		//LOGGER.debug("BusinessIndicatorsService.getIndicatorTarget(): search:: "+searchBuilder.internalBuilder());

		SearchResponse searchResponse = searchBuilder.execute().actionGet();

		SearchHits hits = searchResponse.getHits();
		SearchHit[] hitsArr = hits.getHits();
		if (ArrayUtils.isNotEmpty(hitsArr)) {
			SearchHit searchHit = hitsArr[0];
			Map<String, Object> source = searchHit.getSource();
			manualIndicatorTarget = new ManualIndicatorTarget();
			manualIndicatorTarget.update(source);
		}

		return manualIndicatorTarget;
	}

	public void updateIndicatorTarget(Double targetValue, String period, String indicatorType,
			ImpactIndicatorName dbIndicatorName) {
		ImpactIndicatorService.ValidityPeriod validityPeriod = ImpactIndicatorService.ValidityPeriod.FISCAL;
		Client client = getTransportClient();

		SearchRequestBuilder searchBuilder = client.prepareSearch(SearchConstants.MANUAL)
											 .setTypes(SearchConstants.MANUAL_INDICATOR_TYPE)
											 .setSearchType(SearchType.QUERY_AND_FETCH)
											 .setQuery(QueryBuilders.matchQuery(ManualIndicatorTarget.FIELDNAME_INDICATORTYPE, indicatorType))
											 .setFrom(0)
											 .setSize(1);
		//LOGGER.debug("BusinessIndicatorsService.updateIndicatorTarget(): search:: "+searchBuilder.internalBuilder());
		SearchResponse searchResponse = searchBuilder.execute().actionGet();

		SearchHits hits = searchResponse.getHits();
		SearchHit[] hitsArr = hits.getHits();
		List<String> monthsToAdd = Collections.emptyList();
		String identifier = null;

		ManualIndicatorTarget mit = new ManualIndicatorTarget();

		final Calendar fiscalStartDate = getFiscalStartDate();
		final Calendar currentDate = Calendar.getInstance();

		if (ArrayUtils.isEmpty(hitsArr)) {
			int fiscalStartMonth = fiscalStartDate.get(Calendar.MONTH);
			int currentMonth = currentDate.get(Calendar.MONTH);
			mit.setIndicatorId(String.valueOf(dbIndicatorName.ordinal()));
			mit.setIndicatorType(indicatorType);
			List<String> tags = Collections.emptyList();
			mit.setTags(tags);
			mit.setCreatedDate(DateUtilities.dateToString(currentDate.getTime()));
			List<IndicatorValue> indicatorValueList = new ArrayList<>();;
			mit.setIndicatorValue(indicatorValueList);

			if (fiscalStartMonth > currentMonth) {
				monthsToAdd = new ArrayList<>();
				for (int i = fiscalStartMonth; i <= currentMonth; i++) {
					indicatorValueList.add(new IndicatorValue(String.valueOf(i), MONTH_NAMES[i], targetValue));
					monthsToAdd.add(MONTH_NAMES[i]);
				}
			}
		} else {
			SearchHit searchHit = hitsArr[0];
			identifier = searchHit.getId();
			mit.update(searchHit.getSource());
		}
		mit.setLastModifiedDate(DateUtilities.dateToString(currentDate.getTime()));
		switch (period) {
		case PERIOD_FISCAL: {
			List<IndicatorValue> indicatorValueList = mit.getIndicatorValue();
			for (IndicatorValue indicatorValue : indicatorValueList) {
				indicatorValue.setValue(targetValue);
			}

			break;
		}
		default:
			int currentMonth = currentDate.get(Calendar.MONTH);
			boolean matchingValueFound = false;
			List<IndicatorValue> indicatorValueList = mit.getIndicatorValue();
			for (IndicatorValue indicatorValue : indicatorValueList) {
				if (MONTH_NAMES[currentMonth].equals(indicatorValue.getMonth())) {
					indicatorValue.setValue(targetValue);
					matchingValueFound = true;
					break;
				}
			}
			if (!matchingValueFound) {
				indicatorValueList.add(new IndicatorValue(String.valueOf(currentMonth), MONTH_NAMES[currentMonth], targetValue));
			}
			validityPeriod = ImpactIndicatorService.ValidityPeriod.valueOf(MONTH_NAMES[currentMonth]);
			break;
		}

		updateImpactIndicatorTarget(identifier, mit);

		impactIndicatorService.updateImpactIndicatorTarget(dbIndicatorName, targetValue, validityPeriod, fiscalStartDate.getTime());
	}

	public void updateImpactIndicatorTarget(String identifier, ManualIndicatorTarget mit) {
		Client client = getTransportClient();
		try {
			ObjectMapper mapper = new ObjectMapper();
			String mitJson = mapper.writeValueAsString(mit);

			IndexResponse response = client.prepareIndex(SearchConstants.MANUAL, SearchConstants.MANUAL_INDICATOR_TYPE, identifier)
			        						.setSource(mitJson)
			        						.execute()
			        						.actionGet();

			LOGGER.debug("BusinessIndicatorsService.updateIndicatorTarget(): mitJson:: "+mitJson);
			LOGGER.info("response:: "+response);
		} catch (Exception e) {
			LOGGER.warn("Error while building json", e);
		}
	}

	public void updateOverallRevenueAchieved(final Double targetValue, final String period) {
		ImpactIndicatorService.ValidityPeriod validityPeriod = ImpactIndicatorService.ValidityPeriod.FISCAL;
		Client client = getTransportClient();

		SearchResponse getResponse = getTransportClient()
										.prepareSearch(ElasticSearchEnums.MANUAL.getText())
										.setTypes(ElasticSearchEnums.BUSINESS_STRATEGY.getText())
										.setSize(1)
										.addSort(SearchConstants.LAST_MODIFIED_DATE, SortOrder.DESC).get();

		SearchHits hits = getResponse.getHits();
		//LOGGER.debug("BusinessIndicatorsService.updateOverallRevenueAchieved(): search:: "+getResponse);

		SearchHit[] hitsArr = hits.getHits();
		List<String> monthsToAdd = Collections.emptyList();
		String identifier = null;

		ManualBusinessStrategy mbs = new ManualBusinessStrategy();

		//final Calendar fiscalStartDate = getFiscalStartDate();
		FiscalDatesData fiscalDates = manualAccountStrategyService.get1YearDates();
		final Calendar currentDate = Calendar.getInstance();

		if (ArrayUtils.isEmpty(hitsArr)) {
			int fiscalStartMonth = fiscalDates.getFiscalStartDate().get(Calendar.MONTH);
			int currentMonth = currentDate.get(Calendar.MONTH);
			mbs.setMarketingBudgetSpend(0);
			List<String> tags = Collections.emptyList();
			mbs.setTags(tags);
			mbs.setCreatedDate(DateUtilities.dateToString(currentDate.getTime()));
			List<MonthlyTarget> businessRevenueTarget = new ArrayList<>();
			mbs.setBusinessRevenueTarget(businessRevenueTarget);
			List<MarketingInfluencedRevenueTarget> marketingInfluencedRevenueTarget = new ArrayList<>();
			mbs.setMarketingInfluencedRevenueTarget(marketingInfluencedRevenueTarget);

			if (fiscalStartMonth > currentMonth) {
				monthsToAdd = new ArrayList<>();
				for (int i = fiscalStartMonth; i <= currentMonth; i++) {
					businessRevenueTarget.add(new MonthlyTarget(i, MONTH_NAMES[i], targetValue.intValue()));
					monthsToAdd.add(MONTH_NAMES[i]);
				}
			}
		} else {
			SearchHit searchHit = hitsArr[0];
			identifier = searchHit.getId();
			mbs.update(searchHit.getSource());
		}
		mbs.setLastModifiedDate(DateUtilities.dateToString(currentDate.getTime()));
		Log.info("period: " + period);
		switch (period) {
		case PERIOD_FISCAL: {
			List<MonthlyTarget> indicatorValueList = mbs.getBusinessRevenueTarget();
			for (MonthlyTarget indicatorValue : indicatorValueList) {
				indicatorValue.setValue(targetValue.longValue());
			}
			break;
		}
		default:
			int currentMonth = currentDate.get(Calendar.MONTH);
			boolean matchingValueFound = false;
			List<String> monthsBetweenDates = MiriDateUtils.getMonthsBetweenDatesInMMM(currentDate, fiscalDates.getFiscalEndDate());
			
			List<MonthlyTarget> indicatorValueList = mbs.getBusinessRevenueTarget();
			for(String month: monthsBetweenDates) {
				for(MonthlyTarget indicatorValue : indicatorValueList) {
					if(StringUtils.equals(month, indicatorValue.getMonth())) {
						indicatorValue.setValue(targetValue.longValue());
						matchingValueFound = true;
					}
				}
				if(!matchingValueFound) {
					indicatorValueList.add(new MonthlyTarget(currentMonth, MONTH_NAMES[currentMonth], targetValue.intValue()));
					matchingValueFound = false;
				}
			}
			
			/*for (MonthlyTarget indicatorValue : indicatorValueList) {
				if(monthsBetweenDates.contains(indicatorValue.getMonth())) {
					indicatorValue.setValue(targetValue.longValue());
					//matchingValueFound = true;
				} else {
					indicatorValueList.add(new MonthlyTarget(currentMonth, MONTH_NAMES[currentMonth], targetValue.intValue()));
					//matchingValueFound = false;
				}
				if (MONTH_NAMES[currentMonth].equalsIgnoreCase(indicatorValue.getMonth())) {
					indicatorValue.setValue(targetValue.longValue());
					matchingValueFound = true;
					break;
				}
			}*/
			validityPeriod = ImpactIndicatorService.ValidityPeriod.valueOf(MONTH_NAMES[currentMonth]);
			break;
		}

		ObjectMapper mapper = new ObjectMapper();
		String mitJson;
		try {
			mitJson = mapper.writeValueAsString(mbs);
			IndexResponse response = client.prepareIndex(SearchConstants.MANUAL, SearchConstants.BUSINESS_STRATEGY, identifier)
			        						.setSource(mitJson)
			        						.execute()
			        						.actionGet();

			//LOGGER.debug("BusinessIndicatorsService.updateOverallRevenueAchieved(): mitJson:: "+mitJson);
			LOGGER.info("response:: "+response);
		} catch (JsonProcessingException e) {
			LOGGER.warn("Error while building json", e);
		}

		impactIndicatorService.updateImpactIndicatorTarget(ImpactIndicatorName.OVERALLREVENUEACHIEVED,
								targetValue, validityPeriod, fiscalDates.getFiscalStartDate().getTime());
	}

	public Calendar getFiscalStartDate() {
		return manualAccountStrategyService.getFiscalStartDate();
	}

	@Override
	public String getIndex() {
		return ElasticSearchEnums.MANUAL.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.IMPACT_INDICATORS.getText();
	}
}
