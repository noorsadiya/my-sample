/**
 * 
 */
package com.miri.search.service.crm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.base.VendorTypeEnum;
import com.miri.cis.entity.CrmProduct;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.TopProductData;
import com.miri.search.data.TopProductsDataPojo;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceItemService;

/**
 * CRM Product Service
 * @author rammoole
 *
 */
@Component
public class CRMProductService extends MiriSearchService {

	private static final Logger LOGGER = LogManager.getLogger(CRMProductService.class);

	@Autowired
	private ESQueryUtils esQueryUtils;

	@Autowired
	private ERPInvoiceItemService erpInvoiceItemService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.miri.search.service.MiriSearchService#getIndex()
	 */
	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.miri.search.service.MiriSearchService#getDocumentType()
	 */
	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_PRODUCT.getText();
	}

	/**
	 * Get crm product details by given product id.
	 * 
	 * @param productId
	 * @return
	 */
	public CrmProduct getCRMproductById(final String productId) {
		return (CrmProduct) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), CRMConstants.PRODUCT_ID_RAW,
				productId);
	}

	public CrmProduct getCRMProductByProductId(String productId) {
		CrmProduct crmProduct = null;
		SearchRequestBuilder searchRequestBuilder = getTransportClient()
				.prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_PRODUCT)
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.setQuery(QueryBuilders.boolQuery()
						.must(QueryBuilders.termQuery(SearchConstants.PRODUCT_ID_RAW, productId))); 
		SearchResponse oppSearch = esQueryUtils.execute(searchRequestBuilder);

		if(oppSearch.getHits().getHits().length > 0) {
			SearchHit searchHit = oppSearch.getHits().getAt(0);
			crmProduct = (CrmProduct) ESObjectMapper.getObject(searchHit.getSource(), ElasticSearchEnums.CRM_PRODUCT.getText(), VendorTypeEnum.CRM.getText());
		}
		return crmProduct;
	}

	public String getProductByProductId(String productId) {
		String crmProduct = null;
		SearchResponse oppSearch = getTransportClient()
				.prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_PRODUCT).addField(SearchConstants.PRODUCT_NAME)
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.setQuery(QueryBuilders.boolQuery()
						.must(QueryBuilders.termQuery(SearchConstants.PRODUCT_ID_RAW, productId)))
				.execute().actionGet();

		if(oppSearch.getHits().getHits().length > 0) {
			SearchHit searchHit = oppSearch.getHits().getAt(0);
			crmProduct = searchHit.field(SearchConstants.PRODUCT_NAME).getValue().toString();
		}
		return crmProduct;
	}

	/**
	 * 
	 * @param productId
	 * @return
	 */
	public String getProductIdsByProductId(String productId) {
		String crmProduct = null;
		SearchResponse oppSearch = getTransportClient()
				.prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_PRODUCT).addField(SearchConstants.PRODUCT_NAME)
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.setQuery(QueryBuilders.boolQuery()
						.must(QueryBuilders.termQuery(SearchConstants.PRODUCT_ID_RAW, productId)))
				.execute().actionGet();

		if(oppSearch.getHits().getHits().length > 0) {
			SearchHit searchHit = oppSearch.getHits().getAt(0);
			crmProduct = searchHit.field(SearchConstants.PRODUCT_NAME).getValue().toString();
		}
		return crmProduct;
	}

	/**
	 * Get Level Three Name by Product Id
	 * @param productId
	 * @return
	 */
	public String getLevelThreeNameByProductId(String productId) {
		String crmProductLevelThreeName = null;
		SearchRequestBuilder searchRequestBuilder = getTransportClient()
				.prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_PRODUCT).addField(CRMConstants.CRM_PRODUCT_LEVEL_THREE)
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.setQuery(QueryBuilders.boolQuery()
						.must(QueryBuilders.termQuery(CRMConstants.CRM_PRODUCT_ID_RAW, productId)));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		if(searchResponse.getHits().getHits().length > 0) {
			SearchHit searchHit = searchResponse.getHits().getAt(0);
			crmProductLevelThreeName = searchHit.field(CRMConstants.CRM_PRODUCT_LEVEL_THREE).getValue().toString();
		}
		return crmProductLevelThreeName;
	}

	/**
	 * Returns products based on product level.
	 * 
	 * @param productLevelField
	 * @param productLevelvalue
	 * @return
	 */
	public Set<String> getProductIdsByProductLevel(String productLevelField, String productLevelvalue) {
		Set<String> productIds = new LinkedHashSet<>();
		SearchResponse crmProdSearch = this.getProductDataByProductLevelQuery(productLevelField, productLevelvalue);

		if(crmProdSearch.getHits().getHits().length > 0) {
			for(SearchHit hit: crmProdSearch.getHits()) {
				productIds.add((String)hit.field(SearchConstants.PRODUCT_ID).getValue());
			}

		}
		return productIds;
	}

	/**
	 * Get Product Ids from product Names
	 * @param productNames
	 * @return
	 */
	public Set<String> getProductIdsByProductNames(List<String> productNames) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(SearchConstants.TOP_1000_ITEMS)
				.addField(CRMConstants.PRODUCT_ID)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), 
						FilterBuilders.boolFilter().must(FilterBuilders.termsFilter(CRMConstants.PRODUCT_NAME_RAW, productNames))));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Set<String> productIds = new HashSet<>();
		if(searchResponse.getHits().getHits().length > 0) {
			for(SearchHit hit: searchResponse.getHits()) {
				productIds.add((String)hit.field(CRMConstants.PRODUCT_ID).getValue());
			}
		}

		return productIds;
	}
	/**
	 * Get Product Codes by product level data
	 * @param productLevelField
	 * @param productLevelvalue
	 * @return
	 */
	public Set<String> getProductCodesByProductLevel(String productLevelField, String productLevelvalue) {
		Set<String> productCodes = new LinkedHashSet<>();
		SearchResponse crmProdSearch = this.getProductDataByProductLevelQuery(productLevelField, productLevelvalue);

		if(crmProdSearch.getHits().getHits().length > 0) {
			for(SearchHit hit: crmProdSearch.getHits()) {
				productCodes.add((String) hit.field(CRMConstants.CRM_PRODUCT_CODE).getValue());
			}

		}
		return productCodes;
	}

	/**
	 * @param productLevelField
	 * @param productLevelvalue
	 * @return
	 */
	private SearchResponse getProductDataByProductLevelQuery(String productLevelField, String productLevelvalue) {
		SearchRequestBuilder searchRequestBuilder = getTransportClient()
				.prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_PRODUCT)
				.setSize(1000)
				.addField(CRMConstants.PRODUCT_ID).addField(CRMConstants.CRM_PRODUCT_CODE)
				.setQuery(QueryBuilders.boolQuery()
						.must(QueryBuilders.termQuery(productLevelField, productLevelvalue))); 
		SearchResponse crmProdSearch = esQueryUtils.execute(searchRequestBuilder);
		return crmProdSearch;
	}

	/**
	 * Returns product  code for product Id
	 * @param productId
	 * @return
	 */
	public String getProductCodeByProductId(String productId) {
		String crmProductCode = null;
		SearchResponse oppSearch = getTransportClient()
				.prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_PRODUCT).addField(CRMConstants.CRM_PRODUCT_CODE)
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.setQuery(QueryBuilders.boolQuery()
						.must(QueryBuilders.termQuery(SearchConstants.PRODUCT_ID_RAW, productId)))
				.execute().actionGet();

		if(oppSearch.getHits().getHits().length > 0) {
			SearchHit searchHit = oppSearch.getHits().getAt(0);
			crmProductCode = searchHit.field(CRMConstants.CRM_PRODUCT_CODE).getValue().toString();
		}
		return crmProductCode;
	}
	/**
	 * Get Product Id by Name
	 * @param productName
	 * @return
	 */
	public String getCRMProductByName(String productName) {
		SearchRequestBuilder searchRequestBuilder = getTransportClient()
				.prepareSearch(SearchConstants.CRM)
				.setTypes(SearchConstants.CRM_PRODUCT)
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.setQuery(QueryBuilders.boolQuery()
						.must(QueryBuilders.termQuery(CRMConstants.PRODUCT_NAME_RAW, productName))); 
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		String productId = "";
		for(SearchHit hit: searchResponse.getHits()) {
			productId = hit.getSource().get(CRMConstants.PRODUCT_ID).toString();
		}
		return productId;
	}

	/**
	 * Get Product level based segregated products.
	 * Segregation is based on the segregationFieldName passed as a parameter to the method.
	 * @param segregationFieldName
	 * @param productOrLevelNames
	 */
	public List<TopProductData> getLevelBasedSegregatedProducts(final List<TopProductData> topProductOrLevelItems, final int size) {
		List<String> products = MiriSearchUtils.getProductNamesAsList(topProductOrLevelItems);

		return getLevelBasedSegregatedProducts (products, topProductOrLevelItems, size);
	}

	private List<TopProductData> getLevelBasedSegregatedProducts(final List<String> products, final List<TopProductData> topProductOrLevelItems, final int size){

		LOGGER.info("fetching level based segregated products"/* + product*/);
		BoolFilterBuilder boolFilterBuilder = this.getBoolFilterBuilder(products, CRMConstants.CRM_PRODUCT_ID_RAW);

		// LOGGER.info("Product Name :" + product);
		List<TopProductData> solLevelProductDataList = new ArrayList<>();

		SearchRequestBuilder searchRequestBuilder = getLevelBasedAggregationQuery(boolFilterBuilder);

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		List<Terms.Bucket> solutionLevelBuckets = MiriSearchUtils.getBuckets(searchResponse.getAggregations(), SearchConstants.SOLUTION_LEVEL_AGGREGATION);
		//LOGGER.info("Segregation :" + segregationFieldName + "|" + productLevelBuckets.size());

		processSolutionLevelData(topProductOrLevelItems, products, solLevelProductDataList, solutionLevelBuckets);

		// This method is to update the inner top product list of the hierarchy
		updateListWithTop25ProductData(solLevelProductDataList, size);

		// This method will sort the solution level top products
		return MiriSearchUtils.getTopProductData(solLevelProductDataList, size);

	}

	public List<TopProductData> getLevelBasedSegregatedProductsByProductIds(final List<TopProductData> topProductOrLevelItems, final int size){
		List<String> productIds = MiriSearchUtils.getProductNamesAsList(topProductOrLevelItems);

		return getLevelBasedSegregatedProducts(productIds, topProductOrLevelItems, size);
	}

	/**
	 * Get Product level based segregated products.
	 * Segregation is based on the segregationFieldName passed as a parameter to the method.
	 * @param segregationFieldName
	 * @param productOrLevelNames
	 */
	public List<TopProductData> getLevelBasedSegregatedProductsForTopProducts(final List<TopProductData> topProductOrLevelItems, final int size) {
		List<String> product = MiriSearchUtils.getProductNamesAsList(topProductOrLevelItems);
		LOGGER.info("fetching level based segregated products"/* + product*/);
		BoolFilterBuilder boolFilterBuilder = this.getBoolFilterBuilder(product, CRMConstants.CRM_PRODUCT_LEVEL_THREE_RAW);

		// LOGGER.info("Product Name :" + product);
		List<TopProductData> solLevelProductDataList = new ArrayList<>();

		SearchRequestBuilder searchRequestBuilder = getLevelBasedAggregationQueryForTopProducts(boolFilterBuilder);

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		List<Terms.Bucket> solutionLevelBuckets = MiriSearchUtils.getBuckets(searchResponse.getAggregations(), SearchConstants.SOLUTION_LEVEL_AGGREGATION);
		//LOGGER.info("Segregation :" + segregationFieldName + "|" + productLevelBuckets.size());

		processSolutionLevelDataForTopProducts(topProductOrLevelItems, product, solLevelProductDataList, solutionLevelBuckets);

		// This method is to update the inner top product list of the hierarchy
		updateListWithTop25ProductData(solLevelProductDataList, size);

		// This method will sort the solution level top products
		return MiriSearchUtils.getTopProductData(solLevelProductDataList, size);
	}

	/**
	 * Get Level Based Aggregation Query for Top Products metric
	 * @param boolFilterBuilder
	 * @return
	 */
	private SearchRequestBuilder getLevelBasedAggregationQueryForTopProducts(BoolFilterBuilder boolFilterBuilder) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.SOLUTION_LEVEL_AGGREGATION).field(CRMConstants.CRM_PRODUCT_SOLUTION_FAMILY_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
						.subAggregation(AggregationBuilders.terms(SearchConstants.LEVEL_1_AGGREGATION).field(CRMConstants.CRM_PRODUCT_LEVEL_ONE_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
								.subAggregation(AggregationBuilders.terms(SearchConstants.LEVEL_2_AGGREGATION).field(CRMConstants.CRM_PRODUCT_LEVEL_TWO_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
										.subAggregation(AggregationBuilders.terms(SearchConstants.LEVEL_3_AGGREGATION).field(CRMConstants.CRM_PRODUCT_LEVEL_THREE_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)))));
		return searchRequestBuilder;
	}

	/**
	 * Get Combo Level Based Segregated Product
	 * @param invoiceItemIds
	 * @param productNames
	 * @return
	 */
	public List<TopProductData> getLevelComboBasedSegregatedProducts(final List<String> invoiceItemIds, final int size) {
		List<TopProductData> productWiseRevenue = erpInvoiceItemService.getProductWiseRevenueForInvoiceItemIds(invoiceItemIds);
		return getLevelBasedSegregatedProducts(productWiseRevenue, size);
	}

	/**
	 * Sort the products by revenue and take only top size elements
	 * @param productData
	 * @param size
	 */
	public void updateListWithTop25ProductData(List<TopProductData> productData, final int size) {
		for (TopProductData topProduct: productData) {
			//LOGGER.info("Product Name :" + topProduct.getName());
			List<TopProductData> productInfoList = topProduct.getTopProductInfo();
			List<TopProductData> sortedTopProductData;
			if(productInfoList != null) {
				//LOGGER.info("Top Product size :" + productInfoList.size());
				sortedTopProductData = MiriSearchUtils.getTopProductData(productInfoList, size);
				topProduct.setTopProductInfo(sortedTopProductData);
				this.updateListWithTop25ProductData(productInfoList, size);
			}
		}
	}

	/**
	 * Get Bool Filter Builder for products
	 * @param product
	 * @return
	 */
	private BoolFilterBuilder getBoolFilterBuilder(List<String> product, final String fieldName) {
		BoolFilterBuilder boolFilterBuilder = null;
		if(product != null) {
			boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(fieldName, product));
		}
		return boolFilterBuilder;
	}

	/**
	 * Get Level Based Aggregation Query
	 * @param boolFilterBuilder
	 * @return
	 */
	private SearchRequestBuilder getLevelBasedAggregationQuery(BoolFilterBuilder boolFilterBuilder) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.SOLUTION_LEVEL_AGGREGATION).field(CRMConstants.CRM_PRODUCT_SOLUTION_FAMILY_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
						.subAggregation(AggregationBuilders.terms(SearchConstants.LEVEL_1_AGGREGATION).field(CRMConstants.CRM_PRODUCT_LEVEL_ONE_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
								.subAggregation(AggregationBuilders.terms(SearchConstants.LEVEL_2_AGGREGATION).field(CRMConstants.CRM_PRODUCT_LEVEL_TWO_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
										.subAggregation(AggregationBuilders.terms(SearchConstants.LEVEL_3_AGGREGATION).field(CRMConstants.CRM_PRODUCT_LEVEL_THREE_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
												.subAggregation(AggregationBuilders.terms(SearchConstants.PRODUCT_CODE_AGGREGATION).field(CRMConstants.CRM_PRODUCT_ID_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS))))));
		return searchRequestBuilder;
	}

	/**
	 * Process Solution Level Data for Level 1
	 * @param topProductCodeItems
	 * @param product
	 * @param solLevelProductDataList
	 * @param solutionLevelBucket
	 */
	private void processSolutionLevelData(final List<TopProductData> topProductCodeItems, List<String> product,
			List<TopProductData> solLevelProductDataList, List<Terms.Bucket> solutionLevelBuckets) {
		for(Terms.Bucket solutionLevelBucket: solutionLevelBuckets) {
			List<Terms.Bucket> levelOneBuckets = MiriSearchUtils.getBuckets(solutionLevelBucket.getAggregations(), SearchConstants.LEVEL_1_AGGREGATION);

			TopProductData topProductSolLevel = new TopProductData();
			topProductSolLevel.setName(solutionLevelBucket.getKey());
			List<TopProductData> productLevelOneDataList = new ArrayList<>();
			for(Terms.Bucket levelOneBucket: levelOneBuckets) {
				getSolutionLevelBasedData(topProductCodeItems, product, topProductSolLevel, productLevelOneDataList, levelOneBucket);
			}
			// MiriSearchUtils.getTopProductData(productLevelOneDataList, size);
			topProductSolLevel.setTopProductInfo(productLevelOneDataList);
			solLevelProductDataList.add(topProductSolLevel);
		}
	}

	/**
	 * Process Solution Level Data for Level 1
	 * @param topProductCodeItems
	 * @param product
	 * @param solLevelProductDataList
	 * @param solutionLevelBucket
	 */
	private void processSolutionLevelDataForTopProducts(final List<TopProductData> topProductCodeItems, List<String> product,
			List<TopProductData> solLevelProductDataList, List<Terms.Bucket> solutionLevelBuckets) {
		for(Terms.Bucket solutionLevelBucket: solutionLevelBuckets) {
			List<Terms.Bucket> levelOneBuckets = MiriSearchUtils.getBuckets(solutionLevelBucket.getAggregations(), SearchConstants.LEVEL_1_AGGREGATION);

			TopProductData topProductSolLevel = new TopProductData();
			topProductSolLevel.setName(solutionLevelBucket.getKey());
			List<TopProductData> productLevelOneDataList = new ArrayList<>();
			for(Terms.Bucket levelOneBucket: levelOneBuckets) {
				getSolutionLevelBasedDataTopProducts(topProductCodeItems, product, topProductSolLevel, productLevelOneDataList, levelOneBucket);
			}
			// MiriSearchUtils.getTopProductData(productLevelOneDataList, size);
			topProductSolLevel.setTopProductInfo(productLevelOneDataList);
			solLevelProductDataList.add(topProductSolLevel);
		}
	}

	/**
	 * Get Solution Level Based Data
	 * @param topProductCodeItems
	 * @param product
	 * @param topProductSolLevel
	 * @param productLevelOneDataList
	 * @param levelOneBucket
	 */
	private void getSolutionLevelBasedDataTopProducts(final List<TopProductData> topProductCodeItems, List<String> product,
			TopProductData topProductSolLevel, List<TopProductData> productLevelOneDataList,
			Terms.Bucket levelOneBucket) {
		List<Terms.Bucket> levelTwoBuckets = MiriSearchUtils.getBuckets(levelOneBucket.getAggregations(), SearchConstants.LEVEL_2_AGGREGATION);

		TopProductData topProductLevel1 = new TopProductData();
		topProductLevel1.setName(levelOneBucket.getKey());
		List<TopProductData> productLevelTwoDataList = new ArrayList<>();
		for(Terms.Bucket levelTwoBucket: levelTwoBuckets) {
			getLevelTwoBasedDataForTopProducts(topProductCodeItems, product, topProductLevel1, productLevelTwoDataList, levelTwoBucket);
		}
		setProductData(topProductSolLevel, productLevelOneDataList, topProductLevel1, productLevelTwoDataList);
	}

	/**
	 * Get Solution Level Based Data
	 * @param topProductCodeItems
	 * @param product
	 * @param topProductSolLevel
	 * @param productLevelOneDataList
	 * @param levelOneBucket
	 */
	private void getSolutionLevelBasedData(final List<TopProductData> topProductCodeItems, List<String> product,
			TopProductData topProductSolLevel, List<TopProductData> productLevelOneDataList,
			Terms.Bucket levelOneBucket) {
		List<Terms.Bucket> levelTwoBuckets = MiriSearchUtils.getBuckets(levelOneBucket.getAggregations(), SearchConstants.LEVEL_2_AGGREGATION);

		TopProductData topProductLevel1 = new TopProductData();
		topProductLevel1.setName(levelOneBucket.getKey());
		List<TopProductData> productLevelTwoDataList = new ArrayList<>();
		for(Terms.Bucket levelTwoBucket: levelTwoBuckets) {
			getLevelTwoBasedData(topProductCodeItems, product, topProductLevel1, productLevelTwoDataList, levelTwoBucket);
		}
		setProductData(topProductSolLevel, productLevelOneDataList, topProductLevel1, productLevelTwoDataList);
	}

	/**
	 * @param topProductOrLevelItems
	 * @param product
	 * @param topProductLevel1
	 * @param productLevelTwoDataList
	 * @param levelTwoBucket
	 */
	private void getLevelTwoBasedData(final List<TopProductData> topProductOrLevelItems, List<String> product,
			TopProductData topProductLevel1, List<TopProductData> productLevelTwoDataList,
			Terms.Bucket levelTwoBucket) {
		List<Terms.Bucket> levelThreeBuckets = MiriSearchUtils.getBuckets(levelTwoBucket.getAggregations(), SearchConstants.LEVEL_3_AGGREGATION);

		TopProductData topProductLevel2 = new TopProductData();
		topProductLevel2.setName(levelTwoBucket.getKey());
		//LOGGER.info("Level 2:" + levelTwoBucket.getKey());
		List<TopProductData> productLevelThreeDataList = new ArrayList<>();
		for(Terms.Bucket levelThreeBucket: levelThreeBuckets) {
			processLevelThreeBasedData(topProductOrLevelItems, product, topProductLevel2, productLevelThreeDataList, levelThreeBucket);
		}
		setProductData(topProductLevel1, productLevelTwoDataList, topProductLevel2, productLevelThreeDataList);
	}

	/**
	 * @param topProductOrLevelItems
	 * @param product
	 * @param topProductLevel1
	 * @param productLevelTwoDataList
	 * @param levelTwoBucket
	 */
	private void getLevelTwoBasedDataForTopProducts(final List<TopProductData> topProductOrLevelItems, List<String> product,
			TopProductData topProductLevel1, List<TopProductData> productLevelTwoDataList,
			Terms.Bucket levelTwoBucket) {
		List<Terms.Bucket> levelThreeBuckets = MiriSearchUtils.getBuckets(levelTwoBucket.getAggregations(), SearchConstants.LEVEL_3_AGGREGATION);

		TopProductData topProductLevel2 = new TopProductData();
		topProductLevel2.setName(levelTwoBucket.getKey());
		//LOGGER.info("Level 2:" + levelTwoBucket.getKey());
		List<TopProductData> productLevelThreeDataList = new ArrayList<>();
		for(Terms.Bucket levelThreeBucket: levelThreeBuckets) {
			TopProductData topProductDataObject = topProductOrLevelItems.get(product.indexOf(levelThreeBucket.getKey()));
			setTopProductValue(topProductLevel2, topProductDataObject);
			// topProductLevel2.setAvgDealSize(topProductDataObject.getAvgDealSize());
			// topProductLevel2.setAvgSellPrice(topProductDataObject.getAvgSellPrice());
			// topProductLevel2.setDealsClosed(topProductDataObject.getDealsClosed());
			productLevelThreeDataList.add(topProductDataObject);
			//processLevelThreeBasedData(topProductOrLevelItems, product, topProductLevel2, productLevelThreeDataList, levelThreeBucket);
		}
		setProductData(topProductLevel1, productLevelTwoDataList, topProductLevel2, productLevelThreeDataList);
	}

	/**
	 * Process Level Three Based Data
	 * @param topProductOrLevelItems
	 * @param product
	 * @param topProductLevel2
	 * @param productLevelThreeDataList
	 * @param levelThreeBucket
	 */
	private void processLevelThreeBasedData(final List<TopProductData> topProductOrLevelItems, final List<String> product,
			TopProductData topProductLevel2, List<TopProductData> productLevelThreeDataList,
			final Terms.Bucket levelThreeBucket) {
		List<Terms.Bucket> productCodeBuckets = MiriSearchUtils.getBuckets(levelThreeBucket.getAggregations(), SearchConstants.PRODUCT_CODE_AGGREGATION);
		TopProductData topProductLevel3 = new TopProductData();
		topProductLevel3.setName(levelThreeBucket.getKey());
		// LOGGER.info("Level3:" + levelThreeBucket.getKey());
		for(Terms.Bucket productCodeBucket: productCodeBuckets) {
			processProductCodeLevelData(topProductOrLevelItems, product, topProductLevel3, productCodeBucket);
		}
		productLevelThreeDataList.add(topProductLevel3);
		for(TopProductData topData: productLevelThreeDataList) {
			setTopProductValue(topProductLevel2, topData);
		}
	}

	/**
	 * @param topProductOrLevelItems
	 * @param product
	 * @param topProductLevel3
	 * @param productCodeBucket
	 */
	private void processProductCodeLevelData(final List<TopProductData> topProductOrLevelItems, List<String> product,
			TopProductData topProductLevel3, final Terms.Bucket productCodeBucket) {
		//LOGGER.info("Product Code:" + productCodeBucket.getKey());
		TopProductData topProductDataObject = topProductOrLevelItems.get(product.indexOf(productCodeBucket.getKey()));
		setTopProductValue(topProductLevel3, topProductDataObject);
	}

	/**
	 * Get Product Data
	 * @param topProductLevel1
	 * @param productLevelTwoDataList
	 * @param topProductLevel2
	 * @param productLevelThreeDataList
	 */
	private void setProductData(TopProductData topProductLevel1, List<TopProductData> productLevelTwoDataList,
			TopProductData topProductLevel2, List<TopProductData> productLevelThreeDataList) {
		topProductLevel2.setTopProductInfo(productLevelThreeDataList);
		productLevelTwoDataList.add(topProductLevel2);
		setTopProductValue(topProductLevel1, topProductLevel2);
	}

	/**
	 * Get Top Product Value
	 * @param topProductLevel1
	 * @param topProductLevel2
	 */
	private void setTopProductValue(TopProductData topProductLevel1, TopProductData topProductLevel2) {
		if(topProductLevel2.getValue() != null && topProductLevel1.getValue() != null) {
			topProductLevel1.setValue(topProductLevel2.getValue() + topProductLevel1.getValue());
		} else {
			topProductLevel1.setValue(topProductLevel2.getValue());
		}
	}

	/**
	 * Returns list of crm products for the given product ids.
	 * 
	 * @param productIds
	 * @return
	 */
	public List<CrmProduct> getCRMProductEntitiesByProductIds(Set<String> productIds) {
		SearchRequestBuilder srb = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.boolFilter()
						.must(FilterBuilders.termsFilter(CRMConstants.PRODUCT_ID_RAW, productIds))));
		if (!CollectionUtils.isEmpty(productIds)) {
			srb.setSize(productIds.size());
		}
		SearchResponse searchResponse = srb.get();
		List<CrmProduct> crmProductObjects = new ArrayList<>();
		for (SearchHit hit : searchResponse.getHits()) {
			crmProductObjects
			.add((CrmProduct) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
		}
		return crmProductObjects;
	}

	/**
	 * Get Solution level combo from Product Names
	 * @param productCodes
	 * @return
	 */
	public String getSolutionLevelCombo(Collection<String> productCodes) {
		SearchRequestBuilder searchRequestBuilder = this.getSolutionLevelAggregationQuery(productCodes);

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		Aggregations solAggregations = searchResponse.getAggregations();

		List<Terms.Bucket> solBuckets = MiriSearchUtils.getBuckets(solAggregations, SearchConstants.SOLUTION_LEVEL_AGGREGATION);
		StringBuffer sb = getComboStringFromBuckets(solBuckets);
		return sb.toString();
	}

	/**
	 * @param solBuckets
	 * @return
	 */
	private StringBuffer getComboStringFromBuckets(List<Terms.Bucket> solBuckets) {
		StringBuffer sb = new StringBuffer();
		for(Terms.Bucket solBucket: solBuckets) {
			if(sb.length() > 0) {
				sb.append(SearchConstants.PRODUCT_COMBO_SEPARATOR);
			}
			sb.append(solBucket.getKey());
		}
		return sb;
	}

	/**
	 * @param productCodes
	 * @return
	 */
	private SearchRequestBuilder getSolutionLevelAggregationQuery(Collection<String> productCodes) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.CRM_PRODUCT_ID_RAW, productCodes)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.SOLUTION_LEVEL_AGGREGATION).field(CRMConstants.CRM_PRODUCT_SOLUTION_FAMILY_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS).order(Order.term(true)));
		return searchRequestBuilder;
	}

	/**
	 * Get Level Three Segregated products from top product Id based products
	 * @param topProducts
	 * @return
	 */
	public List<TopProductsDataPojo> getLevelThreeSegregatedProducts(List<TopProductsDataPojo> topProducts, final String fieldName) {
		List<String> topProductCodes = MiriSearchUtils.getProductNamesAsListFrmCollection(topProducts);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), 
						FilterBuilders.termsFilter(fieldName, topProductCodes)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.LEVEL_3_AGGREGATION)
						.field(CRMConstants.CRM_PRODUCT_LEVEL_THREE_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
						.subAggregation(AggregationBuilders.terms(SearchConstants.PRODUCT_CODE_AGGREGATION).field(fieldName)
								.size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<Terms.Bucket> levelThreeBuckets = MiriSearchUtils.getBuckets(searchResponse.getAggregations(), SearchConstants.LEVEL_3_AGGREGATION);
		List<TopProductsDataPojo> levelThreeProductDataList = new ArrayList<>();
		TopProductsDataPojo topProductsDataPojo;
		List<Terms.Bucket> topProductCodeBuckets;
		TopProductsDataPojo topProduct;
		List<String> productIds;
		for(Terms.Bucket levelThreeBucket: levelThreeBuckets) {
			topProductsDataPojo = new TopProductsDataPojo();
			topProductsDataPojo.setProductName(levelThreeBucket.getKey());
			topProductsDataPojo.setProductId(levelThreeBucket.getKey());
			topProductCodeBuckets = MiriSearchUtils.getBuckets(levelThreeBucket.getAggregations(), SearchConstants.PRODUCT_CODE_AGGREGATION);
			productIds = new ArrayList<>();
			for(Terms.Bucket codeBucket: topProductCodeBuckets) {
				topProduct = topProducts.get(topProductCodes.indexOf(codeBucket.getKey()));
				productIds.add(codeBucket.getKey());
				topProductsDataPojo.setRevenueAmount(topProductsDataPojo.getRevenueAmount() + topProduct.getRevenueAmount());
			}
			if(CRMConstants.CRM_PRODUCT_PRODUCT_NAME_RAW.equals(fieldName)) {
				topProductsDataPojo.setProductIds(new ArrayList<>(this.getProductIdsByProductNames(productIds)));
			} else {
				topProductsDataPojo.setProductIds(productIds);
			}

			levelThreeProductDataList.add(topProductsDataPojo);
		}
		return levelThreeProductDataList;
	}
}