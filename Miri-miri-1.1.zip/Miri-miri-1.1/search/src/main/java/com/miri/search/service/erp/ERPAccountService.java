package com.miri.search.service.erp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.ErpAccount;
import com.miri.search.constants.SearchConstants;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;

/**
 * Services pertaining to erp/erp_account document in elastic search
 * @author noor
 *
 */
@Component
public class ERPAccountService extends MiriSearchService {
	
	@Autowired
	ESQueryUtils esQueryUtils;
	
	/**
	 * Get the country name for the acconntid
	 * @param accountId
	 * @return country name
	 */
	public String getAccountCountryNameByAccountId(String accountId) {
		//ErpAccount erpAccount = this.erpAccountRepository.findByAccountId(accountId);
		 ErpAccount erpAccount =(ErpAccount)
				    esQueryUtils.getUniqueDocumentByDocId(getDocumentType(),getIndex(),SearchConstants.ACCOUNT_ID_RAW, accountId);
		
		if(erpAccount != null) {
			return erpAccount.getBillingAddress().getCountryName();
		} else {
			return null;
		}
	}
	
	/**
	 * Returns ERP account details by given account id.
	 * 
	 * @param accountId
	 * @return
	 */
	public ErpAccount getERPAccountById(final String accountId) {
	    return (ErpAccount)esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), "accountId.raw", accountId);
	}

    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getIndex()
     */
    @Override
    public String getIndex() {
        return ElasticSearchEnums.ERP.getText();
    }

    /* (non-Javadoc)
     * @see com.miri.search.service.MiriSearchService#getDocumentType()
     */
    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.ERP_ACCOUNT.getText();
    }
}
