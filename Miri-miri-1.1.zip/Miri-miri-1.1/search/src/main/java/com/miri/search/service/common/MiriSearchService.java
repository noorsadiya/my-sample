package com.miri.search.service.common;

import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticsearchConfig;
import com.miri.search.exception.MiriESException;

/**
 * Miri Search Service
 * @author Noor
 *
 */
@Component
public abstract class MiriSearchService {

	@Autowired
	ElasticsearchConfig elasticSearchConfig;

	/**
	 * Get the elasticsearch transport client from elasticsearchconfig
	 * @return
	 */
	public  Client getTransportClient() {
		return elasticSearchConfig.getTransportClient();
	}

	/**
	 * It will be used to get the response from ES by giving dynamic values for
	 * query builder, index and document type
	 *
	 * @param queryBuilder Query to be Executed
	 * @param index Index on which query should be execute
	 * @param type Document type on for query execution
	 * @param fields
	 *
	 * @return {@link SearchResponse}
	 */
	public SearchResponse executeQuery(QueryBuilder queryBuilder, String index, String type, String[] fields) {
		Client client =getTransportClient();
		return client.prepareSearch(index).setTypes(type).setSearchType(SearchType.DFS_QUERY_THEN_FETCH).setSize(20)
				.addFields(fields).setQuery(queryBuilder).execute().actionGet();

	}

	public abstract String getIndex();

	public abstract String getDocumentType();
	
	/**
	 * All ES Requests are handled through this common method. Elastic search Exceptions are handled here and this
	 * method is intercepted by AOP to process post throwing of the error or post execution.
	 * 
	 * @param searchRequestBuilder
	 * @return
	 * @throws MiriESException
	 */
	public SearchResponse execute(final SearchRequestBuilder searchRequestBuilder)  {
		return searchRequestBuilder.get();

	}

	/*public SearchResponse execute(final SearchScrollRequestBuilder searchScrollRequestBuilder)  {
		return searchScrollRequestBuilder.get();
	}*/
	
}

