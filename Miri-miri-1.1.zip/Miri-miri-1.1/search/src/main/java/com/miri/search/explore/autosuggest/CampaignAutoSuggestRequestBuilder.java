/**
 * 
 */
package com.miri.search.explore.autosuggest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.MAPConstants;
import com.miri.search.explore.autosuggest.AutoSuggestRequest.RequestItem;

/**
 * @author Chandra
 *
 */
@Component
public class CampaignAutoSuggestRequestBuilder extends AutoSuggestRequestBuilder {

	private static List<RequestItem> requestItems = new ArrayList<>();

	{
		if (requestItems.size() == 0) {
			// Map campaign
			RequestItem item = new RequestItem();
			List<String> mapCampaignFields = new ArrayList<>();
			mapCampaignFields.add(MAPConstants.CAMPAIGN_NAME);

			item.setDocType(ElasticSearchEnums.MAP_CAMPAIGN.getText());
			item.setFields(mapCampaignFields);
			item.setIdentifier(MAPConstants.CAMPAIGN_ID);
			requestItems.add(item);

			// CRM Campaign
			List<String> crmCampaignFields = new ArrayList<>();
			crmCampaignFields.add(CRMConstants.CAMPAIGN_NAME);

			RequestItem crmCampaignItems = new RequestItem();
			crmCampaignItems.setDocType(ElasticSearchEnums.CRM_CAMPAIGN.getText());
			crmCampaignItems.setFields(crmCampaignFields);
			crmCampaignItems.setIdentifier(CRMConstants.CAMPAIGN_ID);
			requestItems.add(crmCampaignItems);
		}
	}

	@Override
	public void buildAutoSuggestRequest() {

		autoSuggestRequest.setRequestItems(requestItems);

	}

}
