package com.miri.search.data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.miri.search.constants.SearchConstants;

/**
 * Stacked Column Data for Win Loss Trend Analysis and Marketing Influenced and Sales Generated Pipeline graphs
 * @author rammoole
 *
 */
public class StackedColumnData  implements Comparable<StackedColumnData>,Serializable{
	
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -257034103522245040L;
	private double totalAmount;
	private double qualifiedAmount;
	private Object xAxis;
	private double wonRevenue;
	private long wonCount;
	private double lostRevenue;
	private long lostCount;
	private double hoverAmount;
	private Map<String, StackedColumnData> coutriesWinLossData = new HashMap<>();
	
	List<CampaignRevenueData> stackedData;
	
	String name;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public List<CampaignRevenueData> getStackedData() {
		return stackedData;
	}
	
	public void setStackedData(List<CampaignRevenueData> stackedData) {
		this.stackedData = stackedData;
	}

	private Integer opportunityCount;
	
	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public double getQualifiedAmount() {
		return qualifiedAmount;
	}

	public void setQualifiedAmount(double qualifiedAmount) {
		this.qualifiedAmount = qualifiedAmount;
	}

	public Object getxAxis() {
		return xAxis;
	}

	public void setxAxis(Object xAxis) {
		this.xAxis = xAxis;
	}

	/**
	 * @return the wonRevenue
	 */
	public double getWonRevenue() {
		return wonRevenue;
	}

	/**
	 * @param wonRevenue the wonRevenue to set
	 */
	public void setWonRevenue(double wonRevenue) {
		this.wonRevenue = wonRevenue;
	}

	/**
	 * @return the wonCount
	 */
	public long getWonCount() {
		return wonCount;
	}

	/**
	 * @param wonCount the wonCount to set
	 */
	public void setWonCount(long wonCount) {
		this.wonCount = wonCount;
	}

	/**
	 * @return the lostRevenue
	 */
	public double getLostRevenue() {
		return lostRevenue;
	}

	/**
	 * @param lostRevenue the lostRevenue to set
	 */
	public void setLostRevenue(double lostRevenue) {
		this.lostRevenue = lostRevenue;
	}

	/**
	 * @return the lostCOunt
	 */
	public long getLostCount() {
		return lostCount;
	}

	/**
	 * @param lostCOunt the lostCOunt to set
	 */
	public void setLostCount(long lostCount) {
		this.lostCount = lostCount;
	}

	public double getHoverAmount() {
		return hoverAmount;
	}

	public void setHoverAmount(double hoverAmount) {
		this.hoverAmount = hoverAmount;
	}

	/**
	 * @return the coutriesWinLossData
	 */
	public Map<String, StackedColumnData> getCoutriesWinLossData() {
		return coutriesWinLossData;
	}

	/**
	 * @param coutriesWinLossData the coutriesWinLossData to set
	 */
	public void setCountriesWinLossData(Map<String, StackedColumnData> coutriesWinLossData) {
		this.coutriesWinLossData = coutriesWinLossData;
	}
	
	

	public Integer getOpportunityCount() {
		return opportunityCount;
	}

	public void setOpportunityCount(Integer opportunityCount) {
		this.opportunityCount = opportunityCount;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "StackedColumnData [totalAmount=" + totalAmount + ", qualifiedAmount=" + qualifiedAmount + ", xAxis="
				+ xAxis + ", wonRevenue=" + wonRevenue + ", wonCount=" + wonCount + ", lostRevenue=" + lostRevenue
				+ ", lostCount=" + lostCount + ", hoverAmount=" + hoverAmount + ", coutriesWinLossData="
				+ coutriesWinLossData + "]";
	}

	@Override
	public int compareTo(StackedColumnData sColumnData) {
		if(Math.abs(this.getTotalAmount() - sColumnData.getTotalAmount()) < SearchConstants.EPSILON) {
			return 0;
		} else {
			return this.getTotalAmount() > sColumnData.getTotalAmount() ? -1 : 1;
		}
	}
	
}
