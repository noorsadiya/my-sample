package com.miri.search.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Campaign Hierarchy Data for the front end
 * @author rammoole
 *
 */
public class CampaignHierarchyData implements Serializable {
	
	/**
	 * Default serial version UID
	 */
	private static final long serialVersionUID = 1L;

	private String id;
	
	private String name;
	
	private Boolean value = false;
	
	List<CampaignHierarchyData> subCampaigns = new ArrayList<>();
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Boolean getValue() {
		return value;
	}

	public void setValue(Boolean value) {
		this.value = value;
	}
	
	public List<CampaignHierarchyData> getSubCampaigns() {
		return subCampaigns;
	}
	
	public void setSubCampaigns(List<CampaignHierarchyData> subCampaigns) {
		this.subCampaigns = subCampaigns;
	}

	@Override
	public String toString() {
		return "CampaignHierarchyData [id=" + id + ", name=" + name + ", value=" + value + ", subCampaigns="
				+ subCampaigns + "]";
	}
}
