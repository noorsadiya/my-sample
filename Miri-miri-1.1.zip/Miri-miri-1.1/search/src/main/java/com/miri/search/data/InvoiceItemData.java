package com.miri.search.data;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

/**
 * To hold the invoice item ids per opportunity
 * @author rammoole
 *
 */
public class InvoiceItemData implements Serializable {
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 4211286713567311606L;
	private double salesAmount;
	private List<String> itemIds;
	private Collection<String> productNames;
	
	/**
	 * @return the salesAmount
	 */
	public double getSalesAmount() {
		return salesAmount;
	}
	/**
	 * @param salesAmount the salesAmount to set
	 */
	public void setSalesAmount(double salesAmount) {
		this.salesAmount = salesAmount;
	}
	/**
	 * @return the itemIds
	 */
	public List<String> getItemIds() {
		return itemIds;
	}
	/**
	 * @param itemIds the itemIds to set
	 */
	public void setItemIds(List<String> itemIds) {
		this.itemIds = itemIds;
	}
	/**
	 * @return the productNames
	 */
	public Collection<String> getProductNames() {
		return productNames;
	}
	/**
	 * @param productNames the productNames to set
	 */
	public void setProductNames(Collection<String> productNames) {
		this.productNames = productNames;
	}
}
