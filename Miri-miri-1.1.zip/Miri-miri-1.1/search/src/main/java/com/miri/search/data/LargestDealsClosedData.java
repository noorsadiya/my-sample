package com.miri.search.data;

import java.io.Serializable;

public class LargestDealsClosedData extends MetricData implements Serializable {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -3690764656640286337L;

	private int xAxisIndex;
	
	private String formatedClosedDate;
	
	private String campaignName;
	
	private String leadSource;
	
	private String salesPerson;
	
	private String competitorName;
	
	private String productName;
	
	private String customerName;
	
	public int getxAxisIndex() {
		return xAxisIndex;
	}

	public void setxAxisIndex(int xAxisIndex) {
		this.xAxisIndex = xAxisIndex;
	}

	public String getFormatedClosedDate() {
		return formatedClosedDate;
	}

	public void setFormatedClosedDate(String formatedClosedDate) {
		this.formatedClosedDate = formatedClosedDate;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the campaignName
	 */
	public String getCampaignName() {
		return campaignName;
	}

	/**
	 * @param campaignName the campaignName to set
	 */
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	/**
	 * @return the leadSource
	 */
	public String getLeadSource() {
		return leadSource;
	}

	/**
	 * @param leadSource the leadSource to set
	 */
	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}

	/**
	 * @return the salesPerson
	 */
	public String getSalesPerson() {
		return salesPerson;
	}

	/**
	 * @param salesPerson the salesPerson to set
	 */
	public void setSalesPerson(String salesPerson) {
		this.salesPerson = salesPerson;
	}

	/**
	 * @return the competitorName
	 */
	public String getCompetitorName() {
		return competitorName;
	}

	/**
	 * @param competitorName the competitorName to set
	 */
	public void setCompetitorName(String competitorName) {
		this.competitorName = competitorName;
	}

	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	@Override
	public String toString() {
		return "LargestDealsClosedData [xAxisIndex=" + xAxisIndex + ", campaignName=" + campaignName + ", leadSource="
				+ leadSource + ", salesPerson=" + salesPerson + ", competitorName=" + competitorName + ", productName="
				+ productName + ", customerName=" + customerName + "]";
	}
}
