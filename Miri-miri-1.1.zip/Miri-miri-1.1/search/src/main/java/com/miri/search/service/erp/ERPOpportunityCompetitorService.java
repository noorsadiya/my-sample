package com.miri.search.service.erp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.CrmOpportunity;
import com.miri.cis.entity.ESEntity;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.OpportunityStagesEnum;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.RevenueOpportunitiesData;
import com.miri.search.data.WinLossData;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.crm.CRMOpportunityService;
import com.miri.search.service.manual.ManualAccountStrategyService;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.TimerUtil;

/**
 * Services pertaining to erp/erp_opportunity_competitor document in elastic search
 * @author noor
 *
 */

@Component
public class ERPOpportunityCompetitorService extends MiriSearchService {

	private static final Logger LOG = LogManager.getLogger(ERPOpportunityCompetitorService.class);

	@Autowired
	private CRMOpportunityService crmOpportunityService;

	@Autowired
	ManualAccountStrategyService manualAccountStrategyService;

	@Autowired
	private ERPInvoiceService erpInvoiceService;

	@Autowired
	ESQueryUtils esQueryUtils;

	@Autowired
	private TimerUtil timerUtil;


	/**
	 * Get ERP Competitors for the opportunity ID.
	 * @param opportunityId
	 * @return
	 */
	public List<ESEntity> getCompetitorsByOpportunityId(final String opportunityId) {
		return esQueryUtils.getMultipleDocsByFKId(getDocumentType(), getIndex(), "opportunityId.raw", opportunityId);
	}

	/**
	 * If there are multiple competitors for one opportunity then they are combined shown as separate one competitor.
	 * @param opportunityId
	 * @author rammoole
	 * @return
	 */
	public String getErpOpportunityCompetitors(String opportunityId) {
		timerUtil.start();
		StringBuilder competitor = new StringBuilder();
		SearchRequestBuilder srb = this.getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY_COMPETITOR.getText())
				.setQuery(QueryBuilders.termQuery(SearchConstants.OPPORTUNITY_ID_RAW, opportunityId))
				.setSearchType(SearchType.QUERY_AND_FETCH);
		SearchResponse searchRespose = esQueryUtils.execute(srb);
		SearchHits searchHits = searchRespose.getHits();
		for (SearchHit erpCompetitorHit : searchHits) {
			if (competitor.length() > 0) {
				competitor.append(",");
			}
			if (erpCompetitorHit.getSource().get(SearchConstants.COMPETITOR_NAME) != null)
				competitor.append(erpCompetitorHit.getSource().get(SearchConstants.COMPETITOR_NAME));
		}
		timerUtil.end();
		return competitor.toString();
	}

	/**
	 * Get all the competitors with in the fiscal year. This method returns the Map<String, Double> competitor name and
	 * won amount against competitor
	 * @return
	 * @author rammoole
	 */
	public Map<String, Object> getAllCompetitors() {
		String fiscalStartDate = this.manualAccountStrategyService.getFiscalStartDateStr();
		String endDate = MiriDateUtils.parseDateToString(Calendar.getInstance(), MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return this.getAllCompetitorsWithInTimeFrame(fiscalStartDate, endDate);
	}

	/**
	 * Get Top 25 campaigns with in the fiscal year
	 * @return
	 * @author rammoole
	 */
	public Map<String, Object> getTop25Competitors() {
		Map<String, Object> competitors = this.getAllCompetitors();
		Map<String, Object> top25Competitors = new LinkedHashMap<>();
		if (competitors.size() > 25) {
			int count = 1;
			for (Map.Entry<String, Object> entry : competitors.entrySet()) {
				top25Competitors.put(entry.getKey(), entry.getValue());
				count++;
				if (count == 25) {
					break;
				}
			}
		}
		return top25Competitors;
	}

	/**
	 * Get Top 25 campaigns with in the the time frame
	 * @return
	 * @author rammoole
	 */
	public Map<String, Object> getTop25CompetitorsWithInTimeFrame(String startDate, String endDate) {
		Map<String, Object> competitors = this.getAllCompetitorsWithInTimeFrame(startDate, endDate);
		Map<String, Object> top25Competitors = new LinkedHashMap<>();
		if (competitors.size() > 25) {
			int count = 1;
			for (Map.Entry<String, Object> entry : competitors.entrySet()) {
				top25Competitors.put(entry.getKey(), entry.getValue());
				count++;
				if (count == 25) {
					break;
				}
			}
		}
		else {
			top25Competitors.putAll(competitors);
		}
		return top25Competitors;
	}

	/**
	 * Get all the competitors with in the time frame
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	@Cacheable
	public Map<String, Object> getAllCompetitorsWithInTimeFrame(String startDate, String endDate) {
		timerUtil.start();
		List<String> crmOpportunities = this.crmOpportunityService.getOpportunityIdsByStageAndFiscalYear(
				OpportunityStagesEnum.CLOSED_WON.getText(), startDate, endDate);
		Map<String, Object> allCompetitors = new HashMap<>();
		for (String opportunityId : crmOpportunities) {
			String competitorName = this.getErpOpportunityCompetitors(opportunityId);
			if (!StringUtils.isEmpty(competitorName)) {
				//LOG.info("Competitor Name:" + competitorName);
				double revenue = this.erpInvoiceService.getInvoiceAmountByOpportunityId(opportunityId);
				if (!allCompetitors.containsKey(competitorName)) {
					List<String> opportunityIds = new ArrayList<>();
					RevenueOpportunitiesData competitorData = new RevenueOpportunitiesData();
					opportunityIds.add(opportunityId);
					competitorData.setRevenueAmount(revenue);
					competitorData.setOpportunityIds(opportunityIds);
					//competitorData.setLostOpportunityIds(this.getOpportunitiesByCompetitorNameAndStage(competitorName, startDate, endDate, OpportunityStagesEnum.CLOSED_LOST.getText()));
					allCompetitors.put(competitorName, competitorData);
				} else {
					RevenueOpportunitiesData competitorData = (RevenueOpportunitiesData) allCompetitors
							.get(competitorName);
					competitorData.setRevenueAmount(competitorData.getRevenueAmount() + revenue);
					competitorData.getOpportunityIds().add(opportunityId);
					allCompetitors.put(competitorName, competitorData);
				}
			}
		}
		LOG.debug("timer taken after processing competitor information :ES" + timerUtil.timeTakenInMillis());
		return MiriSearchUtils.sortMapByObjectValue(allCompetitors);
	}

	/**
	 * Get all the competitors with in the time frame
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	@Cacheable
	public Map<String, Object> getAllCompetitorsWithInTimeFrameByOpportunities(String startDate, String endDate,
			List<String> opportunityIds) {

	RevenueOpportunitiesData competitorData=null;

		Map<String, Object> allCompetitors = new HashMap<>();
		for (String opportunityId : opportunityIds) {
			String competitorName = this.getErpOpportunityCompetitors(opportunityId);
			double revenue = this.erpInvoiceService.getInvoiceAmountByOpportunityId(opportunityId);
			if (!allCompetitors.containsKey(competitorName)) {
				List<String> opportunityIdList = new ArrayList<>();
				competitorData = new RevenueOpportunitiesData();
				opportunityIdList.add(opportunityId);
				competitorData.setRevenueAmount(revenue);
				competitorData.setOpportunityIds(opportunityIdList);	
			}
			else {
				competitorData = (RevenueOpportunitiesData) allCompetitors.get(competitorName);
				competitorData.setRevenueAmount(competitorData.getRevenueAmount() + revenue);
				competitorData.getOpportunityIds().add(opportunityId);
				
			}
			allCompetitors.put(competitorName, competitorData);
		}
		LOG.info("getAllCompetitorsWithInTimeFrameByOpportunities ES"+timerUtil.timeTakenInMillis());
		return MiriSearchUtils.sortMapByObjectValue(allCompetitors);
	}

	/**
	 * Get all the competitors with in the time frame
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public Map<String, Object> getAllCompetitorsWithInTimeFrame(Calendar startDate, Calendar endDate) {
		String startDateStr = MiriDateUtils.parseDateToString(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		String endDateStr = MiriDateUtils.parseDateToString(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return this.getAllCompetitorsWithInTimeFrame(startDateStr, endDateStr);
	}

	/**
	 * Get Opportunities by competitor name
	 * @param competitorName
	 * @param opportunities
	 * @return
	 * @author rammoole
	 */
	public List<String> getOpportunitiesByCompetitor(String competitorName, List<String> opportunities) {
		Client client = this.getTransportClient();
		SearchRequestBuilder srb = client.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY_COMPETITOR.getText()).setScroll(new TimeValue(60000))
				.setSearchType(SearchType.SCAN).setSize(500)
				.setFetchSource(SearchConstants.OPPORTUNITY_ID, null)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.termsQuery(SearchConstants.COMPETITOR_NAME_RAW, competitorName), 
						FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities)));
		
		SearchResponse searchResponse = esQueryUtils.execute(srb);
		List<String> opportunityIds = null;
		if (searchResponse != null) {
			opportunityIds = new ArrayList<>();
			while (true) {
				for (SearchHit searchHit : searchResponse.getHits()) {
					opportunityIds.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				}
				searchResponse = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(60000))
						.get();
				if (searchResponse.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		return opportunityIds;
	}

	/**
	 * Opportunity Objects by competitor and stage
	 * @param competitorName
	 * @return
	 * @author rammoole
	 */
	public List<CrmOpportunity> getOpportunityObjectsByCompetitorAndStage(final String competitorName, final String startDate, 
			final String endDate, final String stage) {
		Client client = getTransportClient();
		BoolFilterBuilder boolFilterBuilder = null;
		
		if(StringUtils.isNotBlank(competitorName)) {
			boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_COMPETITOR_NAME_RAW, competitorName));
		}
		
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).gte(startDate).lte(endDate));
		}
 		SearchRequestBuilder srb = client.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY_COMPETITOR.getText())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(60000))
				.setSize(300)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		
		SearchResponse searchResponse = esQueryUtils.execute(srb);
		List<CrmOpportunity> opportunities = null;
		if (searchResponse != null) {
			opportunities = new ArrayList<>();
			List<String> opportunityIds = new ArrayList<>();
			while(true) {
				for (SearchHit searchHit : searchResponse.getHits()) {
					opportunityIds.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				}
				searchResponse = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(60000)).get();
				if(searchResponse.getHits().getHits().length == 0) {
					break;
				}
			}
			if(!StringUtils.isEmpty(stage)) {
				// mapped sale stages are already handled by called method
				opportunities.addAll(crmOpportunityService.getOpportunityObjectsByStage(opportunityIds,
						OpportunityStagesEnum.CLOSED_WON.getText()));
			} else { // if the stage is empty get all the opportunities by stage
				opportunities.addAll(crmOpportunityService.getOpportunityObjectsByIds(opportunityIds));
			}
		}
		//LOG.info("COmpetitorName :" + opportunities.size());
		return opportunities;
	}
	
	/**
	 * Opportunity Objects by competitor and stage
	 * @param competitorName
	 * @return
	 * @author rammoole
	 */
	public List<String> getOpportunityObjectsByCompetitorAndStageAndDate(final String competitorName, final String startDate, 
			final String endDate, final String stage) {
		Client client = getTransportClient();
		BoolFilterBuilder boolFilterBuilder = null;
		
		if(StringUtils.isNotBlank(competitorName)) {
			boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_COMPETITOR_NAME_RAW, competitorName));
		}
		
		/*if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			if(boolFilterBuilder == null) {
				boolFilterBuilder = FilterBuilders.boolFilter();
			}
			boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).gte(startDate).lte(endDate));
		}*/
 		SearchRequestBuilder srb = client.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY_COMPETITOR.getText())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(60000))
				.setSize(500)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		
		SearchResponse searchResponse = esQueryUtils.execute(srb);
		List<String> opportunityIds = new ArrayList<>();
		if (searchResponse != null) {
			while(true) {
				for (SearchHit searchHit : searchResponse.getHits()) {
					opportunityIds.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
				}
				searchResponse = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(60000)).get();
				if(searchResponse.getHits().getHits().length == 0) {
					break;
				}
			}
		}
		// To get the opportunities with in time frame only irrespective of stages
		//LOG.info("COmpetitorName :" + competitorName + "|" + opportunityIds.size());
		return crmOpportunityService.getCRMOpportunitiesByStageDateAndOpportunities(null, startDate, endDate, opportunityIds, null);
	}

	/**
	 * Win Loss Data for Competitors
	 * @param competitorsData
	 * @param startDate TODO
	 * @param endDate TODO
	 * @author rammoole
	 */
	public List<WinLossData> getWinRateForCompetitors(List<Object> competitorsData, String startDate, String endDate) {
		List<WinLossData> winLossDataForCompetitors = new ArrayList<>();
		List<String> opportunityIds;
		for (Object competitorData : competitorsData) {
			opportunityIds = new ArrayList<>();
			//LOG.info("Won Opportunity Count:" + ((RevenueOpportunitiesData) competitorData).getOpportunityIds().size());
			//LOG.info("Lost Opportunity Count:" + ((RevenueOpportunitiesData) competitorData).getLostOpportunityIds().size());
			opportunityIds.addAll(((RevenueOpportunitiesData) competitorData).getOpportunityIds());
			opportunityIds.addAll(((RevenueOpportunitiesData) competitorData).getLostOpportunityIds());
			winLossDataForCompetitors.add(this.crmOpportunityService.getCompetitiveWinRateForOpportunities(opportunityIds, 
					((RevenueOpportunitiesData) competitorData).getOpportunityIds().size(), startDate, endDate));
		}
		return winLossDataForCompetitors;
	}

	/**
	 * Win Loss Data for other competitors. here other competitors mean by is there are more than 25 competitors
	 * @param otherCompetitorsData
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return
	 * @author rammoole
	 */
	public WinLossData getWinRateForOtherCompetitors(List<Object> otherCompetitorsData, String startDate, String endDate) {
		WinLossData winLossData = new WinLossData();
		List<String> opportunityIds;
		for (Object competitorData : otherCompetitorsData) {
			opportunityIds = new ArrayList<>();
			opportunityIds.addAll(((RevenueOpportunitiesData) competitorData).getOpportunityIds());
			opportunityIds.addAll(((RevenueOpportunitiesData) competitorData).getLostOpportunityIds());
			WinLossData winLossDataLoc = this.crmOpportunityService
					.getCompetitiveWinRateForOpportunities(opportunityIds, ((RevenueOpportunitiesData) competitorData).getOpportunityIds().size(), startDate, endDate);
			winLossData.setWonCount(winLossDataLoc.getWonCount());
			winLossData.setWonAmount(winLossDataLoc.getWonAmount());
			winLossData.setLostCount(winLossDataLoc.getLostCount());
			winLossData.setLostAmount(winLossDataLoc.getLostAmount());
		}
		return winLossData;
	}

	@Override
	public String getIndex() {
		return ElasticSearchEnums.ERP.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.ERP_OPPORTUNITY_COMPETITOR.getText();
	}

	/**
	 * Get all the lost opportunities by competitor in this case competitor can be multiple with comma separated
	 * @param competitorName
	 * @return
	 */
	public List<String> getOpportunitiesByCompetitorNameAndStage(String competitorName, List<String> opportunities) {
		List<String> competitorOpportunities = new ArrayList<>();
		if (competitorName.contains(",")) {
			String[] competitorNames = competitorName.split(",");
			for (String competitor : competitorNames) {
				competitorOpportunities.addAll(this.getOpportunitiesByCompetitor(competitor, opportunities));
			}
		} else {
			competitorOpportunities.addAll(this.getOpportunitiesByCompetitor(competitorName, opportunities));
		}
		//LOG.info("Lost Opportunities by competitor:" + lostOpportunities);
		return competitorOpportunities;
	}
	
	/**
	 * @return
	 */
	public Map<String, Object> getTopCompetitorsByRevenue(String startDate, String endDate, int size) {
		Map<String, Object> allCompetitors = this.erpInvoiceService.getTopCompetitorsWithInTimeFrame(startDate, endDate);
		allCompetitors = MiriSearchUtils.getMapTopItems(allCompetitors, size);
		return new TreeMap<String, Object> (allCompetitors);
	}
}