package com.miri.search.data;

import java.io.Serializable;

public class TopCustomerProductsData implements Serializable {
	
	String productName;
	Double totalRevenue;
	String customerName;
	Double highestRevenueOfCustomer;
	Long dealsCount;
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getTotalRevenue() {
		return totalRevenue;
	}
	public void setTotalRevenue(Double totalRevenue) {
		this.totalRevenue = totalRevenue;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Double getHighestRevenueOfCustomer() {
		return highestRevenueOfCustomer;
	}
	public void setHighestRevenueOfCustomer(Double highestRevenueOfCustomer) {
		this.highestRevenueOfCustomer = highestRevenueOfCustomer;
	}
	public Long getDealsCount() {
		return dealsCount;
	}
	public void setDealsCount(Long dealsCount) {
		this.dealsCount = dealsCount;
	}
}
