package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

/**
 * Column Basic Graph Data Object 
 * @author rammoole
 *
 */
public class ColumnBasicData implements Serializable {
	
	/**
	 * Generated Serial Version UID 
	 */
	private static final long serialVersionUID = -170923897265471673L;
	
	private String name;
	
	private List<SalesPersonRevenueData> salesPersonRevenue;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the salesPersonRevenue
	 */
	public List<SalesPersonRevenueData> getSalesPersonRevenue() {
		return salesPersonRevenue;
	}
	/**
	 * @param salesPersonRevenue the salesPersonRevenue to set
	 */
	public void setSalesPersonRevenue(List<SalesPersonRevenueData> salesPersonRevenue) {
		this.salesPersonRevenue = salesPersonRevenue;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ColumnBasicData [name=" + name + ", salesPersonRevenue=" + salesPersonRevenue + "]";
	}
}
