/**
 * 
 */
package com.miri.search.explore.autosuggest;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * AutosuggestRequestBuilder: Abstract class provides methods to create auto
 * suggest request for various incoming field and search key combinations.
 * 
 * @author Chandra
 *
 */
public abstract class AutoSuggestRequestBuilder {

	@Autowired
	protected AutoSuggestRequest autoSuggestRequest;
	
	public abstract void buildAutoSuggestRequest();

	public AutoSuggestRequest getAutoSuggestRequest() {
		return autoSuggestRequest;
	}

	
}
