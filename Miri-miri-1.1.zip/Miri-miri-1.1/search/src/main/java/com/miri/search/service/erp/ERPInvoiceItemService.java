package com.miri.search.service.erp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.ErpInvoiceItem;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.TopProductData;
import com.miri.search.esutils.AggregationUtil;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;

/**
 * Services pertaining to erp/erp_invoice document in elastic search
 *
 * @author noor
 *
 */
@Component
public class ERPInvoiceItemService extends MiriSearchService {

	private final static Logger LOG = LogManager.getLogger(ERPInvoiceItemService.class);

	private static final String GROUPNAME_TOTALSALESAMOUNT = "totalSalesAmount";
	private static final String GROUPNAME_TOTALPRODUCTS = "totalProducts";
	private static final String GROUPNAME_GROUPEDACCOUNTS = "groupedAccounts";

	@Autowired
	private ESQueryUtils esQueryUtils;

	@Override
	public String getIndex() {
		return ElasticSearchEnums.ERP.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.ERP_INVOICE_ITEM.getText();
	}


	@SuppressWarnings("unchecked")
	public List<String> getInvoiceItemsByProductId(String productId,List<String> opportunities,String startDate,String endDate){

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(startDate)
					.to(endDate));
		}
		boolFilter.must(FilterBuilders.termFilter(ERPConstants.PRODUCT_ID_RAW, productId));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000));

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		List<String> invoiceItemIds = new ArrayList<>();

		while (true) {
			for (SearchHit hit : response.getHits()) {
				invoiceItemIds.addAll((List<String>)hit.getSource().get(ERPConstants.INVOICE_ITEMS));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(60000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}
		return invoiceItemIds;
	}
	
	/**
	 * Returns invoice items for the given invoice id.
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<ErpInvoiceItem> getInvoiceItemsByInvoiceId(final String id) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setSize(1000)
				.setQuery(QueryBuilders.termQuery(ERPConstants.INVOICE_ID_RAW, id));
		
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> invoiceItems = new ArrayList<>();
		for(SearchHit hit: searchResponse.getHits()) {
			if(hit.getSource().get("invoiceItems") != null) {
				invoiceItems.addAll((List<String>) hit.getSource().get("invoiceItems"));
			}
		}
		return getInvoiceItemByIds(invoiceItems);
	}


	
	/**
	 * Get Invoice Items By Ids
	 * @param invoiceItemIds
	 * @return
	 */
	public List<ErpInvoiceItem> getInvoiceItemByIds(List<String> invoiceItemIds) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(invoiceItemIds.size())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(ERPConstants.INVOICE_ITEM_ID_RAW, invoiceItemIds)));
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		List<ErpInvoiceItem> invoiceItemObjects = new ArrayList<>();
		for(SearchHit hit: response.getHits()) {
			invoiceItemObjects.add((ErpInvoiceItem) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
		}
		return invoiceItemObjects;
	}
	
	/**
	 * Get Product Names from invoice Item Ids
	 * @param invoiceItemIds
	 * @return
	 */
	public Collection<String> getProductCodesByInvoiceItemIds(List<String> invoiceItemIds) {
		//LOG.info("Get Unique Product Names from invoice Items Ids");
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(MiriSearchUtils.getHitsSizeFromCollection(invoiceItemIds))
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(ERPConstants.INVOICE_ITEM_ID_RAW, invoiceItemIds)));
		
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Set<String> productCodeList = new HashSet<>();
		
		for(SearchHit hit: searchResponse.getHits()) {
			if(hit.getSource() != null && hit.getSource().get(ERPConstants.PRODUCT_ID) != null) {
				productCodeList.add(String.valueOf(hit.getSource().get(CRMConstants.PRODUCT_ID)));
			}
		}
		return productCodeList;
	}
	
	/**
	 * Get Product Wise Revenue for invoice item Ids
	 * @param invoiceItemIds
	 */
	public List<TopProductData> getProductWiseRevenueForInvoiceItemIds(final List<String> invoiceItemIds) {
		SearchRequestBuilder searchRequestBuilder = getProductWiseRevenueFromInvoiceItemIdsQuery(invoiceItemIds);
		SearchResponse searchResponse = this.esQueryUtils.execute(searchRequestBuilder);
		Aggregations productAggregations = searchResponse.getAggregations();
		List<Terms.Bucket> productBuckets = MiriSearchUtils.getBuckets(productAggregations, SearchConstants.PRODUCT_AGGREGATION);
		TopProductData topProductData;
		List<TopProductData> topProductsData = new ArrayList<>();
		for(Terms.Bucket productBucket: productBuckets) {
			topProductData = new TopProductData();
			topProductData.setName(productBucket.getKey());
			topProductData.setValue(AggregationUtil.getSumAggregationValueFromBucket(productBucket, SearchConstants.AMOUNT_AGGREGATION));
			topProductsData.add(topProductData);
		}
		return topProductsData;
	}

	/**
	 * Get Product Wise Revenue from invoice item ids query
	 * @param invoiceItemIds
	 * @return
	 */
	private SearchRequestBuilder getProductWiseRevenueFromInvoiceItemIdsQuery(final List<String> invoiceItemIds) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), 
						FilterBuilders.termsFilter(ERPConstants.INVOICE_ITEM_ID_RAW, invoiceItemIds)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.PRODUCT_AGGREGATION)
						.field(ERPConstants.PRODUCT_ID_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
						.subAggregation(AggregationUtil.sumAggregation(SearchConstants.AMOUNT_AGGREGATION, ERPConstants.INVOICE_ITEM_AMOUNT)));
		return searchRequestBuilder;
	}
}