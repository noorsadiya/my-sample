package com.miri.search.data;

import java.io.Serializable;

/**
 * Fiscal Dates in String format
 * @author rammoole
 *
 */
public class FiscalDatesStrData implements Serializable{
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -5818710332717754458L;
	private String fiscalStartDateStr;
	private String fiscalEndDateStr;
	
	/**
	 * @return the fiscalStartDateStr
	 */
	public String getFiscalStartDateStr() {
		return fiscalStartDateStr;
	}
	/**
	 * @param fiscalStartDateStr the fiscalStartDateStr to set
	 */
	public void setFiscalStartDateStr(String fiscalStartDateStr) {
		this.fiscalStartDateStr = fiscalStartDateStr;
	}
	/**
	 * @return the fiscalEndDateStr
	 */
	public String getFiscalEndDateStr() {
		return fiscalEndDateStr;
	}
	/**
	 * @param fiscalEndDateStr the fiscalEndDateStr to set
	 */
	public void setFiscalEndDateStr(String fiscalEndDateStr) {
		this.fiscalEndDateStr = fiscalEndDateStr;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FiscalDateStr [fiscalStartDateStr=" + fiscalStartDateStr + ", fiscalEndDateStr=" + fiscalEndDateStr
				+ "]";
	}

}