package com.miri.search.data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Regions Win Loss Data
 * @author rammoole
 *
 */
public class RegionWinLossData implements Serializable{
	private String region;
	private WinLossData regionWinLossData;
	private Map<String, WinLossData> coutriesWinLossData = new HashMap<>();
	
	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @return the regionWinLossData
	 */
	public WinLossData getRegionWinLossData() {
		return regionWinLossData;
	}
	/**
	 * @param regionWinLossData the regionWinLossData to set
	 */
	public void setRegionWinLossData(WinLossData regionWinLossData) {
		this.regionWinLossData = regionWinLossData;
	}
	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return the coutriesWinLossData
	 */
	public Map<String, WinLossData> getCoutriesWinLossData() {
		return coutriesWinLossData;
	}
	/**
	 * @param coutriesWinLossData the coutriesWinLossData to set
	 */
	public void setCoutriesWinLossData(Map<String, WinLossData> coutriesWinLossData) {
		this.coutriesWinLossData = coutriesWinLossData;
	}
}
