/**
 *
 */
package com.miri.search.explore;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.MultiSearchRequestBuilder;
import org.elasticsearch.action.search.MultiSearchResponse;
import org.elasticsearch.action.search.MultiSearchResponse.Item;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.base.ElasticsearchConfig;
import com.miri.search.constants.SearchConstants;
import com.miri.search.utils.TimerUtil;

/**
 * FreeTextSearchService : Service class to handle free text search service.
 *
 * @author Chandra
 *
 */
@Component
public class FreeTextSearchService {

	private static final Logger LOGGER = Logger.getLogger(FreeTextSearchService.class);

	@Autowired
	ElasticsearchConfig elasticsearchConfig;

	@Autowired
	TimerUtil timerUtil;

	private static final int DEFAULT_SCROLL_SIZE = 100;

	/**
	 * Runs free text search for given keyword across all the documents
	 * available in Elasticsearch.
	 * 
	 * @param searchKey
	 * @return
	 */
	public List<SearchHit> queryForAll(final String searchKey, Set<String> filters) {
		final Client client = elasticsearchConfig.getTransportClient();
		return queryForAll(client, searchKey, filters, DEFAULT_SCROLL_SIZE);

	}

	public SearchResponse quickQueryAll(Set<String> types, final String searchKey, final int size) {
		final Client client = elasticsearchConfig.getTransportClient();
		return quickQueryForAll(client, types, searchKey, size);
	}

	public List<SearchResponse> quickQueryAll(Set<String> types, String[] searchKeys, final int size) {
		final Client client = elasticsearchConfig.getTransportClient();
		return quickQueryForAll(client, types, searchKeys, size);
	}

	/**
	 * Makes ES call and returns all search hits.
	 * 
	 * @param client
	 * @param searchKey
	 */
	public List<SearchHit> queryForAll(final Client client, final String searchKey, final Set<String> types,
			int pageSize) {
		SearchRequestBuilder searchRequestBuilder = client
				.prepareSearch(SearchConstants.ERP, SearchConstants.CRM, SearchConstants.MAP, SearchConstants.MANUAL)
				.setSearchType(SearchType.SCAN).setScroll(TimeValue.timeValueMinutes(1)).setSize(pageSize)
				.setQuery(QueryBuilders.matchQuery("_all", searchKey).fuzziness(2).prefixLength(2));

		if (null != types && !types.isEmpty())
			searchRequestBuilder.setTypes(StringUtils.join(types, ","));

		SearchResponse firstScrollResponse = searchRequestBuilder.execute().actionGet();
		// get the first page of actual results
		firstScrollResponse = client.prepareSearchScroll(firstScrollResponse.getScrollId())
				.setScroll(TimeValue.timeValueMinutes(1)).execute().actionGet();

		List<SearchHit> searchHits = new ArrayList<>();
		while (firstScrollResponse.getHits().hits().length > 0) {

			for (final SearchHit hit : firstScrollResponse.getHits().hits()) {
				searchHits.add(hit);
			}

			// update the scroll response to get more entries from the old index
			firstScrollResponse = client.prepareSearchScroll(firstScrollResponse.getScrollId())
					.setScroll(TimeValue.timeValueMinutes(1)).execute().actionGet();
		}
		return searchHits;
	}

	/**
	 * Basic free text search against all ES docs.
	 * 
	 * @param client
	 * @param query
	 * @param types
	 */
	public SearchResponse quickQueryForAll(Client client, Set<String> types, final String searchKey, int size) {
		LOGGER.info("search for key: " + searchKey);
		if (size == -1) {
			final MatchQueryBuilder query = QueryBuilders.matchQuery("_all", searchKey).fuzziness(0)
					.prefixLength(searchKey.length());
			SearchRequestBuilder searchRequestBuilder = new SearchRequestBuilder(client)
					.setIndices(SearchConstants.CRM, SearchConstants.MAP)
					.setTypes(ElasticSearchEnums.MAP_CAMPAIGN.getText(),ElasticSearchEnums.CRM_CAMPAIGN.getText(),ElasticSearchEnums.CRM_OPPORTUNITY.getText()
							)
					.setQuery(query).setSize(1);
			SearchResponse searchResponse = searchRequestBuilder.execute().actionGet();
			if (null != searchResponse) {
				size = (int) searchResponse.getHits().getTotalHits();
			}
		}
		final MatchQueryBuilder query = QueryBuilders.matchQuery("_all", searchKey).fuzziness(2).prefixLength(2);
		SearchRequestBuilder searchRequestBuilder = new SearchRequestBuilder(client)
				.setIndices(SearchConstants.CRM, SearchConstants.MAP).setQuery(query).setSize(size)
				.addHighlightedField("parentCampaignName")
				.setTypes(ElasticSearchEnums.MAP_CAMPAIGN.getText(),ElasticSearchEnums.CRM_CAMPAIGN.getText(),ElasticSearchEnums.CRM_OPPORTUNITY.getText()
						)
				.addHighlightedField("campaignName").addHighlightedField("leadOwner").addHighlightedField("userName")
				.addHighlightedField("leadName").addHighlightedField("leadName").addHighlightedField("productName")
				.addHighlightedField("productInterest").addHighlightedField("opportunityOwner")
				.addHighlightedField("opportunityId").addHighlightedField("invoiceId")
				.addHighlightedField("salesPerson").addHighlightedField("companyName").addHighlightedField("owner")
				.addHighlightedField("accountName").setExplain(false);

		if (null != types && !types.isEmpty())
			searchRequestBuilder.setTypes(StringUtils.join(types, ','));

		final SearchResponse searchResponse = searchRequestBuilder.execute().actionGet();

		return searchResponse;

	}

	/**
	 * Takes multiple search keys and run Multi search request builder.
	 * 
	 * @param client
	 * @param types
	 * @param searchKeys
	 * @param size
	 * @return
	 */
	public List<SearchResponse> quickQueryForAll(Client client, Set<String> types, final String[] searchKeys,
			int size) {

		LOGGER.info("search for keys: " + searchKeys);
		List<Integer> sizeList = new ArrayList<>();
		if (size == -1) {
			MultiSearchRequestBuilder multiSearchRequestBuilder = new MultiSearchRequestBuilder(client);
			SearchRequestBuilder searchRequestBuilder = null;
			for (String key : searchKeys) {
				searchRequestBuilder = new SearchRequestBuilder(client)
						.setIndices(SearchConstants.ERP, SearchConstants.CRM, SearchConstants.MAP,
								SearchConstants.MANUAL)
						.setSearchType(SearchType.DFS_QUERY_THEN_FETCH)
						.setQuery(QueryBuilders.matchQuery("_all", key).fuzziness(2).prefixLength(2)).setSize(1);

				MultiSearchResponse multiSearchResponse = multiSearchRequestBuilder.execute().actionGet();
				Item[] items = multiSearchResponse.getResponses();
				for (int i = 0; i < items.length; i++) {
					sizeList.add((int) items[i].getResponse().getHits().getTotalHits());
				}
			}
		}
		MultiSearchRequestBuilder multiSearchRequestBuilder = new MultiSearchRequestBuilder(client);
		SearchRequestBuilder searchRequestBuilder = null;
		for (int i = 0; i < searchKeys.length; i++) {
			String key = searchKeys[i];
			if (!sizeList.isEmpty()) {
				size = sizeList.get(i);
			}
			searchRequestBuilder = new SearchRequestBuilder(client)
					.setIndices(SearchConstants.ERP, SearchConstants.CRM, SearchConstants.MAP, SearchConstants.MANUAL)
					.setSearchType(SearchType.DFS_QUERY_THEN_FETCH)
					.setQuery(QueryBuilders.matchQuery("_all", key).fuzziness(2).prefixLength(2)).setSize(size)
					.addHighlightedField("campaignName").addHighlightedField("leadOwner").addHighlightedField("userName")
					.addHighlightedField("leadName").addHighlightedField("leadName").addHighlightedField("productName")
					.addHighlightedField("productInterest").addHighlightedField("opportunityOwner")
					.addHighlightedField("opportunityId").addHighlightedField("invoiceId")
					.addHighlightedField("salesPerson").addHighlightedField("companyName").addHighlightedField("owner")
					.addHighlightedField("accountName").setExplain(false);

			if (null != types && !types.isEmpty())
				searchRequestBuilder.setTypes(StringUtils.join(types, ','));

			multiSearchRequestBuilder.add(searchRequestBuilder);
		}
		MultiSearchResponse multiSearchResponse = multiSearchRequestBuilder.execute().actionGet();

		Item[] items = multiSearchResponse.getResponses();
		List<SearchResponse> responses = new ArrayList<>();
		for (int i = 0; i < items.length; i++) {
			responses.add(items[i].getResponse());
		}
		return responses;

	}

}
