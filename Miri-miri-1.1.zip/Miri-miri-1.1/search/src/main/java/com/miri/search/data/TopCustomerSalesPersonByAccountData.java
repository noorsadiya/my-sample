package com.miri.search.data;

import java.io.Serializable;

public class TopCustomerSalesPersonByAccountData implements Serializable {
	String salesPerson;
	String accountName;
	String sumRevenue;
	public String getSalesPerson() {
		return salesPerson;
	}
	public void setSalesPerson(String salesPerson) {
		this.salesPerson = salesPerson;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getSumRevenue() {
		return sumRevenue;
	}
	public void setSumRevenue(String sumRevenue) {
		this.sumRevenue = sumRevenue;
	}
}
