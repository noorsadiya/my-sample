package com.miri.search.service.crm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.get.GetRequestBuilder;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.metrics.sum.InternalSum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.CrmCampaign;
import com.miri.data.jpa.util.AppSalesStageContainer;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.MAPConstants;
import com.miri.search.constants.OpportunityStagesEnum;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.CampaignHierarchyData;
import com.miri.search.data.CampaignRevenueData;
import com.miri.search.data.InvoiceStatsData;
import com.miri.search.data.WinLossData;
import com.miri.search.esutils.AggregationUtil;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;
import com.miri.search.service.manual.ManualAccountStrategyService;
import com.miri.search.service.map.MapCampaignService;
import com.miri.search.utils.MiriComparators;
import com.miri.search.utils.MiriComparators.CampaignSetComparator;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.MiriNumberUtils;
import com.miri.search.utils.TimerUtil;

/**
 * Services pertaining to CRM campaigns
 * @author Noor
 *
 */
@Component
public class CRMCampaignService extends MiriSearchService {
	private static final Logger LOG = LogManager.getLogger(CRMCampaignService.class);

	private static final String GROUPNAME_TOTALCAMPAIGNCOST = "totalCampaignCost";
	private static final String GROUPNAME_PARENTCAMPAIGNNAME = "parentCampaignName";

	@Autowired
	private ManualAccountStrategyService manualAccountStrategyService;

	@Autowired
	private CRMOpportunityService crmOpportunityService;

	@Autowired
	private ERPInvoiceService erpInvoiceService;

	@Autowired
	private ESQueryUtils esQueryUtils;

	@Autowired
	private TimerUtil timerUtil;

	@Autowired
	private AppSalesStageContainer appSalesStageContainer;

	private ConcurrentHashMap<String, Double> topCampaignsLocal = new ConcurrentHashMap<>();
	
	@Autowired
	MapCampaignService mapCampaignService;

	/**
	 * Get campaign name based on the opportunity campaign Id. Try to get the parent campaign name. if there is no
	 * parent campaign fall back to sub-campaign name.
	 * @return
	 * @author rammoole
	 */
	public String getCampaignNamebyOpportunityPrimaryCampaignSource(String primaryCampaignSource) {
		if(primaryCampaignSource == null || primaryCampaignSource.isEmpty()){
			return SearchConstants.NOT_APPLICABLE;
		}
		//CrmCampaign crmCampaign = this.crmCampaignRepository.findByCampaignId(primaryCampaignSource);
		CrmCampaign crmCampaign =(CrmCampaign)
				esQueryUtils.getUniqueDocumentByDocId(getDocumentType(),getIndex(),SearchConstants.CAMPAIGN_ID_RAW, primaryCampaignSource);
		CrmCampaign crmParentCampaign =(CrmCampaign)
				esQueryUtils.getUniqueDocumentByDocId(getDocumentType(),getIndex(),SearchConstants.CAMPAIGN_ID_RAW, crmCampaign.getParentCampaignId());
		String campaignName;
		if (crmParentCampaign != null) {
			campaignName = crmParentCampaign.getCampaignName();
		}
		else {
			campaignName = crmCampaign.getCampaignName();
		}
		return campaignName;
	}
	/**
	 * Get campaign name based on the opportunity campaign Id. Try to get the parent campaign name. if there is no
	 * parent campaign fall back to sub-campaign name.
	 * @return
	 * @author rammoole
	 */
	public String getCampaignIdbyOpportunityPrimaryCampaignSource(String primaryCampaignSource) {
		if(primaryCampaignSource == null || primaryCampaignSource.isEmpty()){
			return SearchConstants.NOT_APPLICABLE;
		}
		//CrmCampaign crmCampaign = this.crmCampaignRepository.findByCampaignId(primaryCampaignSource);
		CrmCampaign crmCampaign =(CrmCampaign)
				esQueryUtils.getUniqueDocumentByDocId(getDocumentType(),getIndex(),SearchConstants.CAMPAIGN_ID_RAW, primaryCampaignSource);
		CrmCampaign crmParentCampaign =(CrmCampaign)
				esQueryUtils.getUniqueDocumentByDocId(getDocumentType(),getIndex(),SearchConstants.CAMPAIGN_ID_RAW, crmCampaign.getParentCampaignId());
		String campaignName;
		if (crmParentCampaign != null) {
			campaignName = crmParentCampaign.getCampaignId();
		}
		else {
			campaignName = crmCampaign.getCampaignId();
		}
		return campaignName;
	}

	/**
	 * Get Campaign Name by primary campaign source - returns the subcampaign name
	 * @param primaryCampaignSource
	 * @return
	 */
	public String getCampaignNamebyPrimaryCampaignSource(String primaryCampaignSource) {
		if(primaryCampaignSource == null || primaryCampaignSource.isEmpty()){
			return SearchConstants.NOT_APPLICABLE;
		}
		//CrmCampaign crmCampaign = this.crmCampaignRepository.findByCampaignId(primaryCampaignSource);
		CrmCampaign crmCampaign = (CrmCampaign)
				esQueryUtils.getUniqueDocumentByDocId(getDocumentType(),getIndex(),SearchConstants.CAMPAIGN_ID_RAW, primaryCampaignSource);
		if(crmCampaign != null) {
			return crmCampaign.getCampaignName();
		} else {
			return SearchConstants.NOT_APPLICABLE;
		}
	}


	/**
	 * Get campaign name based on the opportunity Id. Try to get the parent campaign name. if there is no parent
	 * campaign fall back to sub-campaign name. Using Core elasticsearch API
	 * @return
	 * @author rammoole
	 */
	public CrmCampaign getParentCrmCampaignByOpportunityPrimaryCampaignSource(String primaryCampaignSource) {

		CrmCampaign crmCampaign = this.getCrmCampaignByCampaignId(primaryCampaignSource);
		CrmCampaign crmParentCampaign = null;
		if (crmCampaign != null) {
			crmParentCampaign = this.getCrmCampaignByCampaignId(crmCampaign.getParentCampaignId());
			if (crmParentCampaign != null) {
				//LOG.info("returning parent campaign" + crmParentCampaign.getCampaignId());
				return crmParentCampaign;
			}
		}

		return crmCampaign;
	}

	/**
	 * Get campaign name based on the opportunity Id. Try to get the parent campaign name. if there is no parent
	 * campaign fall back to sub-campaign name. Using Core elasticsearch API
	 *
	 * @return
	 * @author rammoole
	 */
	public CrmCampaign getCrmCampaignByCampaignId(String campaignId) {
		SearchResponse searchReponse = getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_CAMPAIGN.getText())
				.setQuery(QueryBuilders.termQuery(SearchConstants.CAMPAIGN_ID_RAW, campaignId)).execute().actionGet();
		CrmCampaign crmCampaign = null;
		for (SearchHit searchHit : searchReponse.getHits()) {
			crmCampaign = (CrmCampaign) ESObjectMapper.getObject(searchHit.getSource(),
					ElasticSearchEnums.CRM_CAMPAIGN.getText(), ElasticSearchEnums.CRM.getText());
			break;
		}
		return crmCampaign;
	}

	/**
	 * Returns CRM campaign by campaign id.
	 *
	 * @param campaignId
	 * @return
	 */
	public CrmCampaign getCrmCampaignById(final String campaignId) {
		//LOG.info("Campaign ID: "+ campaignId);
		return (CrmCampaign) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), "campaignId.raw",
				campaignId);
	}

	/**
	 * Get campaign name based on the opportunity Id.
	 *
	 * @param opportunityId
	 * @return
	 */
	public CrmCampaign getCrmCampaignByOpportunityId(final String opportunityId) {
		return (CrmCampaign) esQueryUtils.getUniqueDocumentByDocId(getDocumentType(), getIndex(), "opportunityId.raw",
				opportunityId);
	}

	/**
	 * Get Campaign Spend Amount By Month
	 * @param startDate
	 * @param endDate
	 */
	public Map<Integer, Double> getCampaignSpendByMonth(Calendar startDate, Calendar endDate) {

		timerUtil.start();
		Map<Integer,String> monthAndYearMap=MiriDateUtils.getMonthsBetweenDates(startDate, endDate);
		List<Integer> months = new LinkedList<>(monthAndYearMap.keySet());
		SearchRequestBuilder srb = this.getTransportClient()
				.prepareSearch(ElasticSearchEnums.MAP.getText()).setTypes(ElasticSearchEnums.MAP_CAMPAIGN.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE)))
				.addAggregation(AggregationBuilders.dateHistogram(SearchConstants.DATE_HISTOGRAM)
						.field(SearchConstants.CREATED_DATE).interval(DateHistogram.Interval.MONTH)
						/*.extendedBounds(parseDateToString(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD),
								parseDateToString(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD))*/
						.format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).subAggregation(AggregationBuilders
								.sum(SearchConstants.SUM_AGGREGATION).field(SearchConstants.CAMPAIGN_SPEND)));
		SearchResponse searchResponse = srb.execute().actionGet();
		timerUtil.end();
		LOG.debug("ES time getCampaignSpendByMonth ES"+timerUtil.timeTakenInMillis());
		return AggregationUtil.getDateHistogramSumAggrResult(searchResponse, SearchConstants.DATE_HISTOGRAM,
				SearchConstants.SUM_AGGREGATION,months);
	}

	/**
	 * To get all the campaigns by revenue with in the fiscal year
	 * @return
	 * @author rammoole
	 */
	public Map<Object, Double> getAllCampaignsByRevenue() {
		String fiscalStartDate = this.manualAccountStrategyService.getFiscalStartDateStr();
		String endDate = MiriDateUtils.parseDateToString(Calendar.getInstance(), MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return this.getAllCampaignsWithInTimeFrame(fiscalStartDate, endDate);
	}

	/**
	 * This method returns the top 25 CRM Campaigns sorted by descending order of revenue
	 * @author rammoole
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return
	 *//*
	public Map<Object, Double> getTop25CampaignsByRevenue() {
		Map<Object, Double> topCampaigns = this.getAllCampaignsByRevenue();
		return this.getTop25Campaigns(topCampaigns);
	}*/

	/**
	 * This method returns the top 25 CRM Campaigns sorted by descending order of revenue with in the time frame Time
	 * frames are dates for 1st Quarter, 2nd Quarter, 3rd Quarter etc
	 * @author rammoole
	 * @return
	 *//*
	public Map<Object, Double> getTop25CampaignsByRevenue(String startDate, String endDate) {
		Map<Object, Double> topCampaigns = this.getAllCampaignsWithInTimeFrame(startDate, endDate);
		return this.getTop25Campaigns(topCampaigns);
	}*/

	/**
	 * Gets top 25 campaigns
	 * @param topCampaigns
	 * @return
	 *//*
	public Map<Object, Double> getTop25Campaigns(Map<Object, Double> topCampaigns) {

		if (topCampaigns != null && topCampaigns.size() > SearchConstants.TOP_25_ITEMS) {
			Map<Object, Double> top25Campaigns = new LinkedHashMap<Object, Double>();
			int index = 0;
			for (Map.Entry<Object, Double> crmCampaign : topCampaigns.entrySet()) {
				top25Campaigns.put(crmCampaign.getKey(), crmCampaign.getValue());
				index++;
				if (index == SearchConstants.TOP_25_ITEMS) {
					break;
				}
			}
			return top25Campaigns;
		}
		else {
			return topCampaigns;
		}
	}
*/
/*	*//**
	 * This method returns the top 25 CRM Campaigns sorted by descending order of revenue with in the time frame Time
	 * frames are dates for 1st Quarter, 2nd Quarter, 3rd Quarter etc
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 *//*
	public Map<Object, Double> getTop25CampaignsByRevenue(Calendar startDate, Calendar endDate) {
		String startDateStr = MiriDateUtils.parseDateToString(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		String endDateStr = MiriDateUtils.parseDateToString(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return this.getTop25CampaignsByRevenue(startDateStr, endDateStr);
	}
*/
	/**
	 * Get all the campaigns with in the time frame
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<Object, Double> getAllCampaignsWithInTimeFrame(Calendar startDate, Calendar endDate) {
		String startDateStr = MiriDateUtils.parseDateToString(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		String endDateStr = MiriDateUtils.parseDateToString(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return this.getAllCampaignsWithInTimeFrame(startDateStr, endDateStr);
	}

	/**
	 * Get all the campaigns with the time frame (1st Quarter, 2nd Quarter, etc)
	 * @param startDate
	 * @param endDate
	 * @param noOfCampaigns - if passed greater than zero then only those many campaigns will be returned. if zero unlimited number of campaigns will be returned
	 * @return
	 * @author rammoole
	 */
	@Cacheable
	public Map<Object, Double> getAllCampaignsWithInTimeFrame(final String startDate, final String endDate) {
		timerUtil.start();

		topCampaignsLocal = new ConcurrentHashMap<>();
		ExecutorService executorService =  Executors.newFixedThreadPool(70);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText()).setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.termsQuery(SearchConstants.STAGE_RAW,
						appSalesStageContainer.getClosedWonMappedStages()),
						FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate)))
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION)
						.field(SearchConstants.PRIMARY_CAMP_SOURCE).size(0));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Aggregations aggregations = searchResponse.getAggregations();
		timerUtil.end();
		LOG.debug("first query: " + timerUtil.timeTakenInMillis());

		timerUtil.start();
		Terms campaignTerms = aggregations.get(SearchConstants.CAMPAIGN_AGGREGATION);

		Collection<Terms.Bucket> campaignBuckets = campaignTerms.getBuckets();
		//LOG.debug("Campaign Buckets:" + campaignBuckets.size());
		for (final Terms.Bucket campaignBucket : campaignBuckets) {
			//LOG.info("Campaign Term:" + campaignBucket.getKey());
			if(StringUtils.isNotBlank(campaignBucket.getKey())){
				executorService.submit(new Runnable() {
					@Override
					public void run() {
						// Call your method  here and update ConcurrentHashMap
						updateCampaignMap(campaignBucket.getKey(), startDate, endDate,
								OpportunityStagesEnum.CLOSED_WON.getText(), null);
					}
				});

			}
		}
		executorService.shutdown();

		try {
			if(!executorService.awaitTermination(1, TimeUnit.MINUTES))
				executorService.shutdownNow();
		}
		catch (InterruptedException e) {
			LOG.error("Interruped Exception while updating the campaigns map:" + e.getMessage());
		}

		timerUtil.end();
		LOG.debug(" ES time getAllCampaignsWithInTimeFrame ES" + timerUtil.timeTakenInMillis());
		return getParentCampaignList();
	}

	/**
	 * This method is used by executor service thread to update the top campaigns
	 * @param campaignId
	 * @param startDate
	 * @param endDate
	 */
	@Cacheable
	public void updateCampaignMap(final String campaignId, final String startDate, final String endDate,
			final String stage, final List<String> crmOpportunityIds) {
		Client client = this.getTransportClient();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate));
		}
		if(!StringUtils.isEmpty(campaignId)) {
			boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, campaignId));
		}

		if(!StringUtils.isEmpty(stage)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getMappedSaleStage(stage)));
		}

		if(!CollectionUtils.isEmpty(crmOpportunityIds)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, crmOpportunityIds));
		}

		SearchRequestBuilder searchRequestBuilder =  client.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setScroll(new TimeValue(60000))
				.setSearchType(SearchType.SCAN)
				.setSize(500);

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> opportunityIds = new ArrayList<>();
		while(true) {
			for (SearchHit hit : searchResponse.getHits().getHits()) {
				opportunityIds.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(60000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		Double invoiceAmount = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, startDate, endDate);
		CrmCampaign crmCampaign = this.getParentCrmCampaignByOpportunityPrimaryCampaignSource(campaignId);
		if(crmCampaign != null){
			if(topCampaignsLocal.containsKey(crmCampaign.getCampaignName())) {
				topCampaignsLocal.put(crmCampaign.getCampaignId(), invoiceAmount + topCampaignsLocal.get(crmCampaign.getCampaignName()));
			} else {
				topCampaignsLocal.put(crmCampaign.getCampaignId(), invoiceAmount);
			}
		}
	}

	/**
	 * Get all the campaigns with the time frame (1st Quarter, 2nd Quarter, etc)
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public Map<Object, Double> getAllCampaignsWithInTimeFrameByOpportunities(final String startDate, final String endDate,
			final List<String> opportunityIds) {
		timerUtil.start();
		topCampaignsLocal = new ConcurrentHashMap<>();

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
				.prepareSearch(ElasticSearchEnums.CRM.getText()).setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION)
						.field(SearchConstants.PRIMARY_CAMP_SOURCE).size(0));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		Aggregations aggregations = searchResponse.getAggregations();

		Terms campaignTerms = aggregations.get(SearchConstants.CAMPAIGN_AGGREGATION);
		ExecutorService executorService =  Executors.newFixedThreadPool(70);
		Collection<Terms.Bucket> campaignBuckets = campaignTerms.getBuckets();
		for (final Terms.Bucket campaignBucket : campaignBuckets) {
			if(!StringUtils.isEmpty(campaignBucket.getKey())){
				executorService.submit(new Runnable() {
					@Override
					public void run() {
						// Call your method  here and update ConcurrentHashMap
						updateCampaignMap(campaignBucket.getKey(), startDate, endDate,
								OpportunityStagesEnum.CLOSED_WON.getText(), opportunityIds);
					}
				});
			}
		}

		executorService.shutdown();
		try {
			if(!executorService.awaitTermination(1, TimeUnit.MINUTES))
				executorService.shutdownNow();
		}
		catch (InterruptedException e) {
			LOG.error("Interruped Exception while updating the campaigns map:" + e.getMessage());
		}

		timerUtil.end();

		LOG.debug("Time taken get all Campaigns by Opportunities :" + timerUtil.timeTakenInMillis());
		return getParentCampaignList();
	}

	/**
	 * @return
	 */
	private Map<Object, Double> getParentCampaignList() {
		Map<Object, Double> parentCampaignList = new LinkedHashMap<>();
		Map<String, Double> sortedCampaigns = MiriSearchUtils.sortMapByValueWithString(topCampaignsLocal);
		for(Map.Entry<String, Double> campaignEntry: sortedCampaigns.entrySet()) {
			CrmCampaign parentCampaign = this.getCrmCampaignById(campaignEntry.getKey());
			parentCampaignList.put(parentCampaign, campaignEntry.getValue());
		}
		return parentCampaignList;
	}

	/**
	 * Get Competitive Win rate for campaigns
	 * @param crmCampaignIds
	 * @author rammoole
	 */
	public Map<String, WinLossData> getCompetitiveWinRateForCampaignIds(List<String> crmCampaignIds, String startDate, String endDate) {
		Map<String, WinLossData> campaignWinRate = new HashMap<>();
		WinLossData winLossObject;
		for (String parenCampaignId : crmCampaignIds) {
			List<String> wonOpportunities = crmOpportunityService.getWonOpportunitiesByParentCampaignId(parenCampaignId, startDate, endDate);

			double wonSum = erpInvoiceService.getInvoiceAmountByOpportunityIds(wonOpportunities, startDate, endDate);
			Object[] lostData = crmOpportunityService.getLostOpportunitiesAndAmountByParentCampaignId(parenCampaignId, startDate, endDate);
			CrmCampaign crmCampaign = this
					.getCrmCampaignByCampaignId(parenCampaignId);
			winLossObject = new WinLossData();
			winLossObject.setWonCount(wonOpportunities.size());
			winLossObject.setWonAmount(wonSum);
			winLossObject.setLostCount((long) lostData[0]);
			winLossObject.setLostAmount((double) lostData[1]);
			LOG.info("campaign Name" + crmCampaign.getCampaignName());
			campaignWinRate.put(crmCampaign.getCampaignName(), winLossObject);
		}
		return campaignWinRate;
		// if the number campaigns are greater than 25 then calculate the win percentage of other at once.
	}

	/**
	 * Get Competitive Win rate for campaigns
	 * @param crmCampaigns
	 * @author rammoole
	 */
	public Map<String, WinLossData> getCompetitiveWinRateForCampaigns(Map<Object, Double> crmCampaigns, final String startDate, final String endDate) {
		List<String> crmCampaignIds = new ArrayList<>();
		for (Map.Entry<Object, Double> crmCampaign : crmCampaigns.entrySet()) {
			crmCampaignIds.add(((CrmCampaign) crmCampaign.getKey()).getCampaignId());
		}
		LOG.info("campaign Ids Size:" + crmCampaignIds.size());
		return this.getCompetitiveWinRateForCampaignIds(crmCampaignIds, startDate, endDate);
		// if the number campaigns are greater than 25 then calculate the win percentage of other at once.
	}

	/**
	 * Constructing query and returning searchResponse for competitive winrate by campaign
	 * @param crmCampaignIds
	 * @return
	 * @author rammoole
	 */
	public SearchResponse getCompetitiveWinRateSearchResponseForCampaigns(List<String> crmCampaignIds, String startDate, String endDate) {
		BoolFilterBuilder boolQueryBuilder = FilterBuilders.boolFilter();
		boolQueryBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, crmCampaignIds));
		boolQueryBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gt(startDate).lt(endDate));
		String[] wonStages = (String[]) appSalesStageContainer.getClosedWonMappedStages().toArray();
		String[] lostStages = (String[]) appSalesStageContainer.getClosedLostMappedStages().toArray();
		SearchRequestBuilder builder = getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolQueryBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION)
						.field(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW)
						.subAggregation(AggregationBuilders.terms(SearchConstants.WON_AGGREGATION)
								.field(SearchConstants.STAGE_RAW)
								.include(wonStages))
						.subAggregation(AggregationBuilders.terms(SearchConstants.LOST_AGGREGATION)
								.field(SearchConstants.STAGE_RAW)
								.include(lostStages).subAggregation(AggregationBuilders
										.sum(SearchConstants.LOST_OPPORTUNITIES_AMOUNT).field(SearchConstants.AMOUNT))));
		return builder.get();
	}

	/**
	 * Get Competitive Win Rate for Other campaigns. Here other campaigns mean by is that, there are more than 25
	 * campaigns
	 * @param otherCrmCampaigns
	 * @return
	 * @author rammoole
	 */
	public WinLossData getCompetitiveWinRateForOtherCampaigns(Map<Object, Double> otherCrmCampaigns, String startDate, String endDate) {
		List<String> crmCampaignIds = new ArrayList<>();
		for (Map.Entry<Object, Double> crmCampaign : otherCrmCampaigns.entrySet()) {
			crmCampaignIds.add(((CrmCampaign) crmCampaign.getKey()).getCampaignId());
		}
		LOG.info("CRM Other campaigns data:" + crmCampaignIds.size());
		return this.getCompetitiveWinRateForOtherCampaignIds(crmCampaignIds, startDate, endDate);
	}

	/**
	 * Get Competitive Win Rate for Other campaigns. Here other campaigns mean by is that, there are more than 25
	 * campaigns
	 * @param otherCrmCampaignIds
	 * @return
	 * @author rammoole
	 */
	public WinLossData getCompetitiveWinRateForOtherCampaignIds(List<String> otherCrmCampaignIds, String startDate, String endDate) {
		SearchResponse searchResponse = this.getCompetitiveWinRateSearchResponseForCampaigns(otherCrmCampaignIds, startDate, endDate);
		Terms campaignTerms = searchResponse.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
		Collection<Terms.Bucket> campaignBuckets = campaignTerms.getBuckets();
		double wonOpportunitiesAmount = 0;
		long wonOpportunities = 0;
		long lostOpportunities = 0;
		double lostOpportunitiesAmount = 0;
		for (Terms.Bucket campaignBucket : campaignBuckets) {
			Object[] winLossData = this.crmOpportunityService
					.getWinLossDataFromAggregation(campaignBucket.getAggregations());
			wonOpportunities += (long) winLossData[0];
			wonOpportunitiesAmount += (double) winLossData[1];
			lostOpportunities += (long) winLossData[2];
			lostOpportunitiesAmount += (double) winLossData[3];
		}
		WinLossData winLossObject = new WinLossData();
		winLossObject.setWonCount(wonOpportunities);
		winLossObject.setWonAmount(wonOpportunitiesAmount);
		winLossObject.setLostCount(lostOpportunities);
		winLossObject.setLostAmount(lostOpportunitiesAmount);
		return winLossObject;
	}

	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_CAMPAIGN.getText();
	}

	/**
	 * Get All parentCampaign from CRM, returns a map of campaign id and campaign name
	 * @param selectedCampaigns
	 * @return
	 */
	public List<CampaignHierarchyData> getAllCampaignHierarchy(List<String> selectedCampaigns) {
		Client client = this.getTransportClient();
		AbstractAggregationBuilder termsAggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(SearchConstants.PARENT_CAMPAIGN_ID_RAW).size(0);

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(ElasticSearchEnums.CRM.getText()).setTypes(ElasticSearchEnums.CRM_CAMPAIGN.getText())
				.addAggregation(termsAggr);
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		Terms responseTerms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		String parentCampaginName = null;
		String parentCampaignId = null;
		CampaignHierarchyData campaignHierarchyData;
		//CampaignHierarchyData subCampaignHierarchyData;
		//List<CampaignHierarchyData> subCampaignHierarchyList;
		List<CampaignHierarchyData> parentCampaignHierarchyList = new ArrayList<>();
		for (Bucket camapignsBucket : responseTerms.getBuckets()) {
			campaignHierarchyData = new CampaignHierarchyData();
			parentCampaignId = camapignsBucket.getKeyAsText().toString();
			if(StringUtils.isNotBlank(parentCampaignId)) {
				//LOG.info("Each Parent campaign :" + parentCampaignId);
				GetRequestBuilder getRequestBuilder = client.prepareGet(getIndex(), getDocumentType(), parentCampaignId);
				GetResponse getResponse = esQueryUtils.execute(getRequestBuilder);
				if(getResponse.getSource() != null) {
					parentCampaginName = getResponse.getSource().get(CRMConstants.CAMPAIGN_NAME).toString();
					campaignHierarchyData.setName(parentCampaginName);
					campaignHierarchyData.setId(parentCampaignId);
					if(CollectionUtils.isNotEmpty(selectedCampaigns) && selectedCampaigns.contains(parentCampaignId)) {
					      campaignHierarchyData.setValue(true);
					   }
					//boolean allSubCampaignsSelected = true;
					//Map<String, String> subCampaigns = this.getSubCampaigns(parentCampaignId);
					//subCampaignHierarchyList = new ArrayList<>();
					//for(Map.Entry<String, String> subCampaign: subCampaigns.entrySet()) {
					//	subCampaignHierarchyData = new CampaignHierarchyData();
					//	subCampaignHierarchyData.setId(subCampaign.getKey());
					//	subCampaignHierarchyData.setName(subCampaign.getValue());
						//LOG.info(selectedCampaigns.contains(subCampaign.getKey()));
						//LOG.info(subCampaign.getKey());
						//if(CollectionUtils.isNotEmpty(selectedCampaigns) && selectedCampaigns.contains(subCampaign.getKey())) {
						//	subCampaignHierarchyData.setValue(true);
						//} else {
						//	allSubCampaignsSelected = false;
						//}
						//subCampaignHierarchyList.add(subCampaignHierarchyData);
					//}
					//campaignHierarchyData.setSubCampaigns(subCampaignHierarchyList);
					//if(allSubCampaignsSelected) {
					//	campaignHierarchyData.setValue(true);
					//}
					parentCampaignHierarchyList.add(campaignHierarchyData);
				}
			}
		}
		//LOG.info(parentCampaignHierarchyList);
		LOG.debug("getAllParentCampaigns" + parentCampaignHierarchyList.size());
		return parentCampaignHierarchyList;
	}

	/**
	 * Get All parentCampaign from CRM, returns a map of campaign id and campaign name
	 */
	public Map<String, String> getAllParentCampaigns() {
		Map<String, String> parentCampaigns = new HashMap<>();

		AbstractAggregationBuilder termsAggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(SearchConstants.PARENT_CAMPAIGN_ID_RAW).size(0);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
				.prepareSearch(ElasticSearchEnums.CRM.getText()).setTypes(ElasticSearchEnums.CRM_CAMPAIGN.getText())
				.addAggregation(termsAggr);

		LOG.trace("AllParentCampaigns : Query : "+searchRequestBuilder);

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		Terms responseTerms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		String parentCampaginName = null;
		String parentCampaignId = null;
		for (Bucket camapignsBucket : responseTerms.getBuckets()) {
			parentCampaignId = camapignsBucket.getKey();
			if(StringUtils.isNotBlank(parentCampaignId)) {
				parentCampaginName = this.getCampaignNamebyPrimaryCampaignSource(parentCampaignId);
				parentCampaigns.put(parentCampaignId, parentCampaginName);
			}
		}
		//LOG.info("getAllParentCampaigns" + parentCampaigns.size());
		return parentCampaigns;

	}

	/**
	 * Returns Map of parent campaign Id & names for the given date range
	 *
	 * @param reviewStartDate data range start
	 * @param reviewEndDate data range end
	 * @return Map of parent campaign Id & names for the given date range
	 */
	public Map<String, String> getAllParentCampaigns(final String reviewStartDate, final String reviewEndDate) {
		Map<String, String> parentCampaigns = new HashMap<>();

		BoolQueryBuilder fiscalConditionClause = QueryBuilders.boolQuery();
		fiscalConditionClause.must(QueryBuilders.rangeQuery(SearchConstants.CREATED_DATE)
													.gte(reviewStartDate)
													.lte(reviewEndDate));

		AbstractAggregationBuilder termsAggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
														.field(SearchConstants.PARENT_CAMPAIGN_ID_RAW)
														.size(0);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
														.prepareSearch(getIndex())
														.setTypes(getDocumentType())
														.setQuery(fiscalConditionClause)
														.addAggregation(termsAggr)
														.setSize(1);

		LOG.debug("AllParentCampaigns with Dates : Query : "+searchRequestBuilder);

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		Terms responseTerms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		String parentCampaignName = null;
		String parentCampaignId = null;
		TopHits topHits;
		for (Bucket camapignsBucket : responseTerms.getBuckets()) {
			parentCampaignId = camapignsBucket.getKeyAsText().toString();
			if(StringUtils.isNotBlank(parentCampaignId)){
				topHits = camapignsBucket.getAggregations().get("parentCampaignNameGroup");
				parentCampaignName = (String)topHits.getHits().getAt(0).getSource().get(GROUPNAME_PARENTCAMPAIGNNAME);
				parentCampaigns.put(parentCampaignId, parentCampaignName);
			}

		}
		//LOG.info("getAllParentCampaigns" + parentCampaigns.size());
		return parentCampaigns;

	}

	/**
	 * Get All Created Date of campaign
	 */
	public Date getCampaignCreatedDate(String campaignId) {

		Date campaignCreatedDate = null;

		SearchResponse response = this.getTransportClient()
				.prepareSearch(ElasticSearchEnums.CRM.getText()).setTypes(ElasticSearchEnums.CRM_CAMPAIGN.getText())
				.setQuery(QueryBuilders.termQuery(SearchConstants.CAMPAIGN_ID_RAW, campaignId))
				.addField(SearchConstants.CREATED_DATE)
				.execute().actionGet();

		for (SearchHit hit : response.getHits()) {
			campaignCreatedDate = MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					hit.field(SearchConstants.CREATED_DATE).getValue().toString());
		}
		LOG.info("campaignCreatedDate" + campaignCreatedDate);
		return campaignCreatedDate;

	}

	/**
	 * This method can be used to get sub campaigns of the provided parent campaign
	 *
	 * @param parentCampaign campaign Id for which sub campaigns need to be fetched
	 * @return {@link List} List containing all the sub campaigns of the provided parent campaign
	 *
	 */

	public Map<String, String> getSubCampaigns(String parentCampaign) {
		timerUtil.start();
		Map<String, String> campaignIds = new HashMap<>();
		Client client = this.getTransportClient();
		QueryBuilder opportunityQueryBuilder = QueryBuilders.termQuery(CRMConstants.CAMPAIGN_PARENT_CAMPAIGN_ID_RAW,
				parentCampaign);

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(opportunityQueryBuilder).setSearchType(SearchType.SCAN).setSize(300)
				.setScroll(new TimeValue(6000))
				.addField(SearchConstants.CAMPAIGN_ID).addField(SearchConstants.CRM_CAMPAIGN_NAME);

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		while(true) {
			for (SearchHit hit : response.getHits()) {
				campaignIds.put(hit.field(SearchConstants.CAMPAIGN_ID).getValue().toString(),
						hit.field(SearchConstants.CRM_CAMPAIGN_NAME).getValue().toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if(response.getHits().getHits().length == 0) {
				break;
			}
		}
		timerUtil.end();

		LOG.info(" ES time getSubCampaigns ES" + timerUtil.timeTakenInMillis());
		return campaignIds;
	}
	
	/**
	 * This method can be used to get sub campaigns of the provided parent campaign
	 *
	 * @param parentCampaign campaign Id for which sub campaigns need to be fetched
	 * @return {@link List} List containing all the sub campaigns of the provided parent campaign
	 *
	 */
	public Map<String, String> getSubCampaigns(String parentCampaign, List<String> campaigns) {
		timerUtil.start();
		
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termFilter(CRMConstants.CAMPAIGN_PARENT_CAMPAIGN_ID_RAW,parentCampaign));
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_ID_RAW,campaigns));
		Map<String, String> campaignIds = new HashMap<>();
		Client client = this.getTransportClient();
		
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter)).setSearchType(SearchType.SCAN).setSize(300)
				.setScroll(new TimeValue(6000))
				.addField(SearchConstants.CAMPAIGN_ID).addField(SearchConstants.CRM_CAMPAIGN_NAME);
		
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		while(true) {
			for (SearchHit hit : response.getHits()) {
				campaignIds.put(hit.field(SearchConstants.CAMPAIGN_ID).getValue().toString(),
						hit.field(SearchConstants.CRM_CAMPAIGN_NAME).getValue().toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if(response.getHits().getHits().length == 0) {
				break;
			}
		}
		timerUtil.end();
		
		LOG.info(" ES time getSubCampaigns ES" + timerUtil.timeTakenInMillis());
		return campaignIds;
	}
	/**
	 * This method can be used to get sub campaigns of the provided parent campaign
	 *
	 * @param parentCampaign campaign Id for which sub campaigns need to be fetched
	 * @return {@link List} List containing all the sub campaigns of the provided parent campaign
	 *
	 */
	public Map<String, String> getSubCampaigns(List<String> parentCampaigns, List<String> campaigns) {
		timerUtil.start();
		
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PARENT_CAMPAIGN_ID_RAW,parentCampaigns));
		boolFilter.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_ID_RAW,campaigns));
		Map<String, String> campaignIds = new HashMap<>();
		Client client = this.getTransportClient();
		
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter)).setSearchType(SearchType.SCAN).setSize(300)
				.setScroll(new TimeValue(6000))
				.addField(SearchConstants.CAMPAIGN_ID).addField(SearchConstants.CRM_CAMPAIGN_NAME);
		
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		while(true) {
			for (SearchHit hit : response.getHits()) {
				campaignIds.put(hit.field(SearchConstants.CAMPAIGN_ID).getValue().toString(),
						hit.field(SearchConstants.CRM_CAMPAIGN_NAME).getValue().toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if(response.getHits().getHits().length == 0) {
				break;
			}
		}
		timerUtil.end();
		
		LOG.info(" ES time getSubCampaigns ES" + timerUtil.timeTakenInMillis());
		return campaignIds;
	}
	/**
	 * This method can be used to get sub campaigns of the provided parent campaign
	 *
	 * @param parentCampaign campaign Id for which sub campaigns need to be fetched
	 * @return {@link List} List containing all the sub campaigns of the provided parent campaign
	 *
	 */
	
	public List<String> getSubCampaigns(List<String> parentCampaigns) {
		List<String> campaignIds = new ArrayList<>();
		Client client = this.getTransportClient();
		QueryBuilder opportunityQueryBuilder = QueryBuilders.termsQuery(CRMConstants.CAMPAIGN_PARENT_CAMPAIGN_ID_RAW,
				parentCampaigns);
		
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(opportunityQueryBuilder).setSearchType(SearchType.SCAN).setSize(1000)
				.setScroll(new TimeValue(6000))
				.addField(SearchConstants.CAMPAIGN_ID).addField(SearchConstants.CRM_CAMPAIGN_NAME);
		
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		while(true) {
			for (SearchHit hit : response.getHits()) {
				campaignIds.add(hit.field(SearchConstants.CAMPAIGN_ID).getValue().toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if(response.getHits().getHits().length == 0) {
				break;
			}
		}
		return campaignIds;
	}

	/**
	 * This method can be used to get sub campaigns of the provided parent campaign
	 *
	 * @param parentCampaign campaign Id for which sub campaigns need to be fetched
	 * @return {@link List} List containing all the sub campaigns of the provided parent campaign
	 *
	 */
	public List<String> getSubCampaignIds(String parentCampaign) {
		Map<String, String> subCampaigns = this.getSubCampaigns(parentCampaign);
		return new ArrayList<>(subCampaigns.keySet());
	}
	
	/**
	 * This method can be used to get sub campaigns of the provided parent campaign
	 *
	 * @param parentCampaign campaign Id for which sub campaigns need to be fetched
	 * @return {@link List} List containing all the sub campaigns of the provided parent campaign
	 *
	 */
	public List<String> getMarketingSubCampaignIds(String parentCampaign) {
		List<String> marketingSubCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		Map<String, String> subCampaigns = this.getSubCampaigns(parentCampaign, marketingSubCampaigns);
		return new ArrayList<>(subCampaigns.keySet());
	}
	
	/**
	 * This method can be used to get sub campaigns of the provided parent campaign
	 *
	 * @param parentCampaign campaign Id for which sub campaigns need to be fetched
	 * @return {@link List} List containing all the sub campaigns of the provided parent campaign
	 *
	 */
	public Map<String, String> getMarketingSubCampaignIds(List<String> parentCampaigns) {
		List<String> marketingSubCampaigns =  mapCampaignService.getMarketingSubCampaigns();
		Map<String, String> subCampaigns = this.getSubCampaigns(parentCampaigns, marketingSubCampaigns);
		return subCampaigns;
	}
	/**
	 * This method can be used to get sub campaigns of the provided parent campaign
	 *
	 * @param parentCampaign campaign Id for which sub campaigns need to be fetched
	 * @return {@link List} List containing all the sub campaigns of the provided parent campaign
	 *
	 */

	public Map<String, Date> getSubCampaignsDate(String parentCampaign) {
		Map<String, Date> campaignIds = new HashMap<>();

		QueryBuilder opportunityQueryBuilder = QueryBuilders.termQuery(SearchConstants.PARENT_CAMPAIGN_ID_RAW,
				parentCampaign);

		SearchResponse response = this.getTransportClient()
				.prepareSearch(ElasticSearchEnums.CRM.getText()).setTypes(ElasticSearchEnums.CRM_CAMPAIGN.getText())
				.setQuery(opportunityQueryBuilder).setSize(1000)
				.addField(SearchConstants.CAMPAIGN_ID).addField(SearchConstants.CREATION_DATE).execute()
				.actionGet();

		for (SearchHit hit : response.getHits()) {
			campaignIds.put(hit.field(SearchConstants.CAMPAIGN_ID).getValue().toString(),
					MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
							hit.field(SearchConstants.CREATION_DATE).getValue().toString()));
		}
		LOG.info("getSubCampaigns:-" + campaignIds);
		return campaignIds;
	}

	/**
	 * Get campaigns Spend amount
	 * @param parentCampaign
	 * @return
	 */
	public Map<String, Double> getSubCampaignsSpend(String parentCampaign) {
		timerUtil.start();
		Map<String, Double> campaignIds = new HashMap<>();

		QueryBuilder opportunityQueryBuilder = QueryBuilders.termQuery(SearchConstants.PARENT_CAMPAIGN_ID_RAW, parentCampaign);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
				.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(opportunityQueryBuilder).setSize(1000)
				.addField(CRMConstants.CAMPAIGN_NAME).addField(SearchConstants.ACTUAL_COST);
		SearchResponse response = searchRequestBuilder.execute().actionGet();

		for (SearchHit hit : response.getHits()) {
			campaignIds.put(hit.field(CRMConstants.CAMPAIGN_NAME).getValue().toString(),
					Double.parseDouble(hit.field(SearchConstants.ACTUAL_COST).getValue().toString()));
		}
		timerUtil.end();
		LOG.info(" ES time getSubCampaigns spend: ES" + timerUtil.timeTakenInMillis());
		return campaignIds;
	}

	/**
	 * Get Campaign Revenue, ADS, ASP and Deals Closed
	 * @param campaignId
	 * @return
	 * @author rammoole
	 */
	public CampaignRevenueData getCampaignRevenueAspAdsDealsClosed(String campaignId) {
		List<String> opportunityIds = this.crmOpportunityService.getOpportuniesByCampaignIds(Arrays.asList(campaignId), null, null);
		CampaignRevenueData campaignRevenueData = new CampaignRevenueData();
		double revenue = this.erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, null, null);
		double avgSellPrice = this.erpInvoiceService.averageSellPriceByOpportunities(opportunityIds);
		campaignRevenueData.setRevenueAmount(revenue);
		campaignRevenueData.setAverageDealSize(revenue / opportunityIds.size());
		campaignRevenueData.setNoOfDeals((long) opportunityIds.size());
		campaignRevenueData.setAverageSellPrice(avgSellPrice);
		return campaignRevenueData;
	}

	/**
	 * Get Sub Campaigns Revenue
	 * @param parentCampaign
	 * @return
	 * @author rammoole
	 */
	public Map<String, CampaignRevenueData> getSubCampaignsRevenue(String parentCampaign) {
		timerUtil.start();
		Map<String, CampaignRevenueData> subCampaignsRevenue = new HashMap<>();

		Map<String, String> subCampaignsList = this.getSubCampaigns(parentCampaign);
		for (Map.Entry<String, String> subCampaign : subCampaignsList.entrySet()) {
			subCampaignsRevenue.put(subCampaign.getValue(),
					this.getCampaignRevenueAspAdsDealsClosed(subCampaign.getKey()));
		}
		timerUtil.end();
		LOG.info(" Java Time getSubCampaigns revenue: ES" +timerUtil.timeTakenInMillis());
		return subCampaignsRevenue;
	}

	/**
	 * Get Average Days for campaigns
	 * @param campaigns
	 * @return
	 */
	public long getAverageDaysForCampaigns(List<String> campaigns){
		SearchResponse searchResponse = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.termsQuery(SearchConstants.CAMPAIGN_ID_RAW, campaigns))
				.setSize(0)
				.addAggregation(AggregationBuilders.avg(SearchConstants.AVG_AGGREGATION).field(SearchConstants.CREATED_DATE))
				.get();
		return (long) AggregationUtil.getAggregationValue(searchResponse, SearchConstants.AVG_AGGREGATION, SearchConstants.AVG_AGGREGATION_TYPE);
	}

	/**
	 * Returns campaign id and name map for the given set of campaign id's.
	 *
	 * @param keySet
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getCampaignNameByIdAsMap(Set<String> keySet) {
		if (null == keySet || keySet.isEmpty())
			return MapUtils.EMPTY_MAP;

		List<String> list = new ArrayList<>(keySet);

		int batchSize = 1000;

		int times = list.size() / batchSize;
		int toIndex = batchSize;
		int fromIndex = 0;
		Map<String, String> campaignIdAndNameByMap = new HashMap<>();
		for (int i = times; i >= 0; i--) {

			toIndex = toIndex > list.size() ? list.size() : toIndex;
			SearchRequestBuilder searchRequestBuilder = new SearchRequestBuilder(getTransportClient());
			BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery()
					.must(QueryBuilders.termsQuery("campaignId.raw", list.subList(fromIndex, toIndex)));
			searchRequestBuilder.setQuery(boolQueryBuilder).setIndices(getIndex()).setTypes(getDocumentType()).setSize(toIndex-fromIndex)
			.addAggregation(AggregationBuilders.terms("by_campaign_id").field("campaignId.raw").size(toIndex-fromIndex)
					.subAggregation(AggregationBuilders.terms("by_campaign_name").field("campaignName.raw").size(toIndex-fromIndex) ));

			SearchResponse searchResponse = searchRequestBuilder.execute().actionGet();
			Terms campaignIdTerms = searchResponse.getAggregations().get("by_campaign_id");
			Collection<Terms.Bucket> campaignIdBuckets = campaignIdTerms.getBuckets();
			for (Iterator<Terms.Bucket> campaignIdBucketsItr = campaignIdBuckets.iterator(); campaignIdBucketsItr.hasNext();) {
				Terms.Bucket eachCampaignIdBucket = (Terms.Bucket) campaignIdBucketsItr.next();
				Terms campaignNameTerms = eachCampaignIdBucket.getAggregations().get("by_campaign_name");
				if (null != campaignNameTerms.getBuckets() && campaignNameTerms.getBuckets().size() > 0)
					campaignIdAndNameByMap.put(eachCampaignIdBucket.getKey(),
							((Terms.Bucket) campaignNameTerms.getBuckets().toArray()[0]).getKey());
			}
			fromIndex = toIndex + 1;
			toIndex = toIndex + batchSize;

			searchResponse = null;
			searchRequestBuilder = null;
			boolQueryBuilder = null;

			if (fromIndex > toIndex || fromIndex > list.size())
				break;

		}
		return campaignIdAndNameByMap;
	}

	public Map<String,String> getAllSubCamapigns(){
		Map<String,String> subCampaigns=new HashMap<>();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.mustNot(FilterBuilders.termFilter(CRMConstants.CAMPAIGN_PARENT_CAMPAIGN_ID_RAW, ""));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
				.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		while(true){
			SearchHits oppSearchHits = searchResponse.getHits();
			for (SearchHit hit : oppSearchHits) {
				subCampaigns.put(hit.getSource().get(CRMConstants.CAMPAIGN_ID).toString(),hit.getSource().get(CRMConstants.CAMPAIGN_NAME).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =   getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(1000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return subCampaigns;
	}

	/**
	 * Get Top Sub Campaigns By Revenue
	 * @param startDate
	 * @param endDate
	 * @param size
	 * @return
	 */
	public List<CampaignRevenueData> getSubCampaignsByRevenue(final String startDate, final String endDate, List<String> marketingCampaigns, final int size) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();

		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, appSalesStageContainer.getClosedWonMappedStages()));
		
		List<String> subCampaigns = new ArrayList<>();
		
		for(String parentCampaign: marketingCampaigns) {
			List<String> parentCampaignSubCampaigns = this.getSubCampaignIds(parentCampaign);
			subCampaigns.addAll(parentCampaignSubCampaigns);
		}
		if(subCampaigns != null) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_PRIMARY_CAMP_SOURCE_RAW, subCampaigns));
		}

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText()).setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION)
						.field(SearchConstants.PRIMARY_CAMP_SOURCE).size(0));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		int maxHits = 0;
		Terms terms = searchResponse.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
		Collection<Terms.Bucket> campaignBuckets = terms.getBuckets();
		for(Terms.Bucket bucket: campaignBuckets) {
			maxHits = (int) bucket.getDocCount();
			break;
		}

		searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText()).setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.terms(SearchConstants.CAMPAIGN_AGGREGATION)
						.field(SearchConstants.PRIMARY_CAMP_SOURCE).size(0)
						.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_WON_OPPORTUNITY_HITS)
								.setSize(maxHits).setFetchSource(CRMConstants.OPPORTUNITY_ID, null)));
		searchResponse = esQueryUtils.execute(searchRequestBuilder);
		terms = searchResponse.getAggregations().get(SearchConstants.CAMPAIGN_AGGREGATION);
		campaignBuckets = terms.getBuckets();
		CrmCampaign crmCampaign;
		
		List<CampaignRevenueData> topSubCampaigns = new ArrayList<>();
		CampaignRevenueData campaignRevenueData;
		for(Terms.Bucket bucket: campaignBuckets) {
			campaignRevenueData = new CampaignRevenueData();
			crmCampaign = this.getCrmCampaignById(bucket.getKey());
			TopHits topOpportunityHits = bucket.getAggregations().get(SearchConstants.TOP_WON_OPPORTUNITY_HITS);
			List<String> opportunityIds = new ArrayList<>();
			for(SearchHit hit: topOpportunityHits.getHits()) {
				opportunityIds.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			InvoiceStatsData dealsAdsAspRevenueAmount = erpInvoiceService.getAdsAspDealsRevenueByOpportunities(opportunityIds, startDate, endDate);

			campaignRevenueData.setRevenueAmount(dealsAdsAspRevenueAmount.getRevenueAmount());
			campaignRevenueData.setAverageDealSize(dealsAdsAspRevenueAmount.getAds());
			campaignRevenueData.setAverageSellPrice(dealsAdsAspRevenueAmount.getAsp());
			campaignRevenueData.setNoOfDeals(dealsAdsAspRevenueAmount.getDealsClosed());
			if(crmCampaign != null) {
				campaignRevenueData.setCampaignSpend(crmCampaign.getActualCost());
				campaignRevenueData.setCampaignName(crmCampaign.getCampaignName());
				campaignRevenueData.setCampaignId(crmCampaign.getCampaignId());
				topSubCampaigns.add(campaignRevenueData);
			}
		}
		Collections.sort(topSubCampaigns, new Comparator<CampaignRevenueData>() {
			public int compare(CampaignRevenueData campaignRevenueDataOne, CampaignRevenueData campaignRevenueDataTwo) {
				return campaignRevenueDataTwo.getRevenueAmount().compareTo(campaignRevenueDataOne.getRevenueAmount());
			}
		});
		
		if(topSubCampaigns.size() > size) {
			return topSubCampaigns.subList(0, size);
		} else {
			return topSubCampaigns;
		}
	}

	/**
	 * Get Selected Sub campaigns data
	 * @return
	 */
	public List<CampaignRevenueData> getSelectedCampaignsData(List<String> selectedCampaigns, String startDate, String endDate, int size) {
		return getSubCampaignsByRevenue(startDate, endDate, selectedCampaigns, size);
	}

	/**
	 * Return sum of actual cost for the campaigns created in the given review period.
	 * campaignIdCollector - should have the ids of the campaigns for which the sum was calculated
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @param campaignIds set to add campaigns for which the sum of cost was added
	 * @return sum of actual cost for the campaigns created in the given review period.
	 */
	public double getCampaignCostWithIds(final String reviewStartDate, final String reviewEndDate, final Set<String> campaignIds) {
		Client client = getTransportClient();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(MAPConstants.CAMPAIGN_ID_RAW, campaignIds));

		SumBuilder totalCampaignCostClause = AggregationBuilders.sum(GROUPNAME_TOTALCAMPAIGNCOST).field(SearchConstants.ACTUAL_COST);

		SearchRequestBuilder campaignCostSearchBuilder = client.prepareSearch(ElasticSearchEnums.MAP.getText())
													 .setTypes(ElasticSearchEnums.MAP_CAMPAIGN.getText())
													 .setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
													 .addAggregation(totalCampaignCostClause);

		//LOG.debug("CampaignCostWithIds: Query : "+campaignCostSearchBuilder);

		SearchResponse campaignCostSearchResponse = esQueryUtils.execute(campaignCostSearchBuilder);

		InternalSum totalCampaignCostAggregation = campaignCostSearchResponse.getAggregations().get(GROUPNAME_TOTALCAMPAIGNCOST);
		double totalCampaignCost = totalCampaignCostAggregation.getValue();

		//2. Get Sum of all campaigns costs that are manually entered
		/*SearchHit[] searchHits = campaignCostSearchResponse.getHits().getHits();
		if (ArrayUtils.isNotEmpty(searchHits) && campaignIdCollector != null) {
			for (SearchHit searchHit : searchHits) {
				campaignIdCollector.add((String) searchHit.getSource().get(SearchConstants.CAMPAIGN_ID));
			}
		}*/

		return totalCampaignCost;
	}

	/**
	 * Get campaign start date in milli seconds
	 * @param campaignId
	 * @return
	 */
	public long getCrmCampaignStartDateByCampaignId(String campaignId) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setFetchSource(CRMConstants.CAMPAIGN_START_DATE, null)
				.setQuery(QueryBuilders.termQuery(CRMConstants.CAMPAIGN_ID_RAW, campaignId));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		if(searchResponse.getHits().totalHits() > 0) {
			String campaignStartDate = searchResponse.getHits().getAt(0).getSource().get(CRMConstants.CAMPAIGN_START_DATE).toString();
			Calendar startDate = MiriDateUtils.parseStrDateToCalendar(campaignStartDate.replace("T", " ").replace("Z", ""), MiriDateUtils.DATE_FORMAT_YYYY_MM_DD_HH_MM_SSS);
			return startDate.getTimeInMillis();
		} else {
			return 0;
		}
	}

	/**
	 * A Set of Maps campaign id (as value) and campaign name (as name)
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @param vendorNameCollector set to add vendor names for the campaign source
	 * @return A Set of Maps campaign id (as value) and campaign name (as name)
	 */
	public SortedSet<Map<String, String>> getAllCampaignsWithVendorName(final String reviewStartDate, final String reviewEndDate, final Set<String> vendorNameCollector) {
		LOG.debug("Enter into fetchCampaignDetails");
		SortedSet<Map<String, String>> campaignSet = new TreeSet<Map<String, String>>(MiriComparators.CAMPAIGNSET_COMPARATOR);

		BoolFilterBuilder conditionClause = FilterBuilders.boolFilter().should(FilterBuilders.orFilter(FilterBuilders.notFilter(FilterBuilders.existsFilter(SearchConstants.END_DATE)),
																	FilterBuilders.rangeFilter(SearchConstants.END_DATE).gte(reviewStartDate)));
//		ExistsFilterBuilder existsFilter = FilterBuilders.existsFilter(SearchConstants.END_DATE);

		SearchRequestBuilder searchBuilder = getTransportClient().prepareSearch(SearchConstants.CRM)
																	.setTypes(SearchConstants.CRM_CAMPAIGN)
																	.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), conditionClause))
																	.addField(SearchConstants.CAMPAIGN_ID)
																	.addField(SearchConstants.CRM_CAMPAIGN_NAME)
																	.addField(SearchConstants.VENDOR_TYPE)
																	.addField(SearchConstants.VENDOR_NAME)
																	.setScroll(new TimeValue(6000))
																	.setSearchType(SearchType.SCAN)
																	.setSize(500);

		LOG.debug("fetchAllCampaigns : Query : " + searchBuilder);

		SearchResponse response = searchBuilder.execute().actionGet();

		Map<String, String> campaigns = null;
		while(true){
			for (SearchHit hit : response.getHits()) {
				campaigns = new HashMap<String, String>();
				campaigns.put(CampaignSetComparator.VALUE_FIELD, String.valueOf(hit.field(SearchConstants.CAMPAIGN_ID).getValue()));
				campaigns.put(CampaignSetComparator.NAME_FIELD, String.valueOf(hit.field(SearchConstants.CRM_CAMPAIGN_NAME).getValue()));
				campaignSet.add(campaigns);

				Object type = String.valueOf(hit.field(SearchConstants.VENDOR_TYPE).getValue());
				Object name = String.valueOf(hit.field(SearchConstants.VENDOR_NAME).getValue());
				vendorNameCollector.add(StringUtils.lowerCase(type + "_" + name));
			}
			 SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(response.getScrollId())
				      .setScroll(new TimeValue(6000));
			 response = esQueryUtils.execute(searchScrollRequestBuilder);
		    if(response.getHits().getHits().length == 0) {
		    	break;
		    }
		}
		return campaignSet;
	}


	/**
	 * Returns the ES source of the Crm Campaign for the given campaign name
	 *
	 * @param campaignName for which the details are needed
	 * @return the source of the Crm Campaign for the given campaign name
	 */
	public Map<String, Object> getCampaignByName(String campaignName) {
		LOG.debug("Enter into getCampaignByName" + campaignName);
		Map<String, Object> campaignDetails = Collections.emptyMap();

//		FiscalDatesStrData fiscalDatesStrData = manualAccountStrategyService.get1YearDatesStr();
//		String reviewStartDate = fiscalDatesStrData.getFiscalStartDateStr();
//		String reviewEndDate = fiscalDatesStrData.getFiscalEndDateStr();

//		BoolQueryBuilder fiscalConditionClause = QueryBuilders.boolQuery();
//		fiscalConditionClause.must(QueryBuilders.matchQuery(SearchConstants.CRM_CAMPAIGN_NAME, campaignName))
//								.must(QueryBuilders.rangeQuery(SearchConstants.CREATED_DATE)
//													.gte(reviewStartDate)
//													.lte(reviewEndDate));

		SearchRequestBuilder searchBuilder = getTransportClient().prepareSearch(getIndex())
												.setTypes(getDocumentType())
												.setQuery(QueryBuilders.matchQuery(SearchConstants.CAMPAIGN_NAME_RAW, campaignName))
												.addSort(SortBuilders.fieldSort(SearchConstants.CREATED_DATE).order(SortOrder.DESC));

		LOG.debug("CampaignByName : Query : " + searchBuilder);

		SearchResponse response = searchBuilder.execute().actionGet();

		SearchHit[] hitsArr = response.getHits().getHits();
		if (ArrayUtils.isNotEmpty(hitsArr)) {
			campaignDetails = hitsArr[0].getSource();
		}

		return campaignDetails;
	}
	
	public Map<String, Double> getCampaignCosts(){
		Client client = getTransportClient();
		
		Map<String, Double> campaignCost = new HashMap<>();

		SearchRequestBuilder campaignCostSearchBuilder = client.prepareSearch(ElasticSearchEnums.CRM.getText())
													 .setTypes(ElasticSearchEnums.CRM_CAMPAIGN.getText())
													 .setScroll(new TimeValue(6000))
														.setSearchType(SearchType.SCAN);

		SearchResponse campaignCostSearchResponse = esQueryUtils.execute(campaignCostSearchBuilder);
		
		while(true) {
			for (SearchHit hit : campaignCostSearchResponse.getHits()) {
				campaignCost.put((String)hit.getSource().get(SearchConstants.CRM_CAMPAIGN_NAME), MiriNumberUtils.createDouble(hit.getSource().get(CRMConstants.CAMPAIGN_ACTUALL_COST)));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(campaignCostSearchResponse.getScrollId()).setScroll(new TimeValue(6000));
			campaignCostSearchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(campaignCostSearchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return campaignCost;
	}
}
