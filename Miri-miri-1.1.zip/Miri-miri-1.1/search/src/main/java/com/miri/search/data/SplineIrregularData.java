package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

/**
 * Spline Irregular Data
 * @author rammoole
 *
 */
public class SplineIrregularData implements Serializable {
	/**
	 * Generated serial version UID
	 */
	private static final long serialVersionUID = -3747094936533378751L;

	private String name;
	
	private String campaignName;
	
	private List<MultipleAxesChartData> revenueData;

	public List<MultipleAxesChartData> getRevenueData() {
		return revenueData;
	}

	public void setRevenueData(List<MultipleAxesChartData> revenueData) {
		this.revenueData = revenueData;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the campaignName
	 */
	public String getCampaignName() {
		return campaignName;
	}

	/**
	 * @param campaignName the campaignName to set
	 */
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SplineIrregularData [revenueData=" + revenueData + ", name=" + name + "]";
	}
}
