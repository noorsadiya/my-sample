package com.miri.search.data;

import java.io.Serializable;

/**
 * Win Loss Data Object for Win Loss trend analysis 
 * @author rammoole
 *
 */
public class WinLossData implements Serializable {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 560134614824670749L;
	private String stackedParamName;
	private long wonCount;
	private double wonAmount;
	private long lostCount;
	private double lostAmount;
	
	/**
	 * @return the stackedParamName
	 */
	public String getStackedParamName() {
		return stackedParamName;
	}
	/**
	 * @param stackedParamName the stackedParamName to set
	 */
	public void setStackedParamName(String stackedParamName) {
		this.stackedParamName = stackedParamName;
	}
	
	/**
	 * @return the wonCount
	 */
	public long getWonCount() {
		return wonCount;
	}
	/**
	 * @param wonCount the wonCount to set
	 */
	public void setWonCount(long wonCount) {
		this.wonCount = wonCount;
	}
	/**
	 * @return the wonAmount
	 */
	public double getWonAmount() {
		return wonAmount;
	}
	/**
	 * @param wonAmount the wonAmount to set
	 */
	public void setWonAmount(double wonAmount) {
		this.wonAmount = wonAmount;
	}
	/**
	 * @return the lostCount
	 */
	public long getLostCount() {
		return lostCount;
	}
	/**
	 * @param lostCount the lostCount to set
	 */
	public void setLostCount(long lostCount) {
		this.lostCount = lostCount;
	}
	/**
	 * @return the lostAmount
	 */
	public double getLostAmount() {
		return lostAmount;
	}
	/**
	 * @param lostAmount the lostAmount to set
	 */
	public void setLostAmount(double lostAmount) {
		this.lostAmount = lostAmount;
	}
	
	
}
