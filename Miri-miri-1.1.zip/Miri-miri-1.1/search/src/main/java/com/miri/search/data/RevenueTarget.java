package com.miri.search.data;

import java.util.List;

import com.miri.cis.entity.MonthlyTarget;

/**
 * @author supraja
 *
 */
public class RevenueTarget {
	private String label;
	private Double quarterTarget;
	private List<MonthlyTarget> monthlyTarget;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Double getQuarterTarget() {
		return quarterTarget;
	}

	public void setQuarterTarget(Double quarterTarget) {
		this.quarterTarget = quarterTarget;
	}

	public List<MonthlyTarget> getMonthlyTarget() {
		return monthlyTarget;
	}

	public void setMonthlyTarget(List<MonthlyTarget> monthlyTarget) {
		this.monthlyTarget = monthlyTarget;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RevenueTarget [label=").append(label );
		builder.append(", quarterTarget=").append( quarterTarget);
		builder.append(", monthlyTarget=").append(monthlyTarget).append("]");
		return builder.toString();
	}

}
