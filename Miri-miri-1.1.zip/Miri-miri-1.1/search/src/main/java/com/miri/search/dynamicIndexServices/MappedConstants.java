package com.miri.search.dynamicIndexServices;

public class MappedConstants {
	
	public static final String CRM_ERP_MAPPED = "opportunity_invoice_mapped";
	public static final String ORDER_BY_ERP_SALES_AMOUNT = "opportunity_invoice_mapped.salesAmount";
	public static final String CHILDREN = "children";
	public static final String GRAND_CHILDREN = "Grand children";
	public static final String OPPORTUNITY_CAMPAIGN_MAPPED = "crm_Opportunity_campaign_mapped";
	public static final String OPPORTUNITY_INVOICE_MAPPED = "opportunity_invoice_mapped";
	public static final String FILTERED_AGGREGATION = "filtered Aggregation";
	public static final String LOST_AGGREGATION = "Lost Aggregation";
	public static final String WON_AGGREGATION = "Won Aggregation";
	public static final String GRAND_FILTERED_AGGREGATION = "grand filtered Aggregation";

}
