package com.miri.search.constants;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 * Opportunity Stage 
 *
 */
public enum OpportunityStagesEnum {
	
	/*PROSPECTING(com.miri.data.constants.OpportunityStagesEnum.PROSPECTING.getText()), 
	QUALIFICATION(com.miri.data.constants.OpportunityStagesEnum.QUALIFICATION.getText()), 
	NEED_ANALYSIS(com.miri.data.constants.OpportunityStagesEnum.NEED_ANALYSIS.getText()), 
	VALUE_PROPOSITION(com.miri.data.constants.OpportunityStagesEnum.VALUE_PROPOSITION.getText()), 
	DECISION_MAKERS(com.miri.data.constants.OpportunityStagesEnum.DECISION_MAKERS.getText()), 
	PERCEPTION_ANALYSIS(com.miri.data.constants.OpportunityStagesEnum.PERCEPTION_ANALYSIS.getText()), 
	
	//Qualified Stages
	PRICE_QUOTE(com.miri.data.constants.OpportunityStagesEnum.PRICE_QUOTE.getText()), 
	NEGOTIATION(com.miri.data.constants.OpportunityStagesEnum.NEGOTIATION.getText()),
	*/
	
	//Closed Stages
	CLOSED_WON(com.miri.data.constants.OpportunityStagesEnum.CLOSED_WON.getText()),
	CLOSED_LOST(com.miri.data.constants.OpportunityStagesEnum.CLOSED_LOST.getText()),
	
	//Error stage
	STAGE_EMPTY(com.miri.data.constants.OpportunityStagesEnum.STAGE_EMPTY.getText()),
	
	//Qualified and Others
	QUALIFIED(com.miri.data.constants.OpportunityStagesEnum.QUALIFIED_PIPELINE.getText()),
	OTHERS(com.miri.data.constants.OpportunityStagesEnum.OTHERS.getText());
	
	
	private String text;
	
    private static Map<String, OpportunityStagesEnum> metricMapper = new HashMap<>();

    static {
        for (final OpportunityStagesEnum metric : OpportunityStagesEnum.values()) {
            metricMapper.put(metric.getText(), metric);
        }
        metricMapper = Collections.unmodifiableMap(metricMapper);
    }

    public static Map<String, OpportunityStagesEnum> getMetricMapper() {
        return metricMapper;
    }

    private OpportunityStagesEnum(final String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    /**
     * Returns String value corresponding to Enum.
     *
     * @param text
     * @return
     */
    public static OpportunityStagesEnum fromString(final String text) {
        if (text != null) {
            for (final OpportunityStagesEnum metricsEnum : OpportunityStagesEnum.values()) {
                if (text.equalsIgnoreCase(metricsEnum.getText())) {
                    return metricsEnum;
                }
            }
        }
        return null;
    }
}
