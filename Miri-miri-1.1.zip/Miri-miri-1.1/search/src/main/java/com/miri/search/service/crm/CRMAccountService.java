package com.miri.search.service.crm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.CrmAccount;
import com.miri.cis.entity.ESEntity;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.OpportunityStagesEnum;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.InvoiceDataPojo;
import com.miri.search.data.InvoiceStatsData;
import com.miri.search.data.RevenueOpportunitiesData;
import com.miri.search.data.WinLossData;
import com.miri.search.esutils.BoolQueryBuilderRequest;
import com.miri.search.esutils.BoolQueryBuilderRequest.BoolType;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.erp.ERPInvoiceService;
import com.miri.search.service.erp.ERPOpportunityCompetitorService;
import com.miri.search.service.manual.ManualAccountStrategyService;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.TimerUtil;

/**
 * CRM Account Service 
 * @author rammoole
 *
 */
@Component
public class CRMAccountService extends MiriSearchService {

	private static final Logger LOG = LogManager.getLogger(CRMAccountService.class);

	@Autowired
	private CRMOpportunityService crmOpportunityService;

	@Autowired
	private ManualAccountStrategyService manualAccountStrategyService;

	@Autowired
	private ERPInvoiceService erpInvoiceService;

	@Autowired
	private ERPOpportunityCompetitorService erpOpportunityCompetitorService;

	@Autowired
	ESQueryUtils esQueryUtils;

	@Autowired
	private TimerUtil timerUtil;

	private ConcurrentHashMap<String, Object> topCountriesData = new ConcurrentHashMap<>();

	private ConcurrentHashMap<String, Object> topRegionsData = new ConcurrentHashMap<>();

	/**
	 * To get Account Name by accountId
	 * @param accountId
	 * @return CrmAccount
	 * @author rammoole
	 */
	public CrmAccount getAccountByAccountId(String accountId) {
		GetResponse getResponse = this.getTransportClient().prepareGet(getIndex(), getDocumentType(), accountId).get();
		return (CrmAccount) ESObjectMapper.getObject(getResponse.getSource(), getDocumentType(), getIndex());
	}

	/**
	 * To get Account objects by accountIds.
	 * 
	 * @param accountId
	 * @return CrmAccount
	 */
	public List<ESEntity> getAccountsByAccountIds(List<String> accountIds) { 
		return esQueryUtils.getEntitiesByIds(getDocumentType(), getIndex(), CRMConstants.ACCOUNT_ID_RAW, accountIds);
	}

	
	/**
	 * Returns Account Name using account Id
	 * @param accountId
	 * @return
	 */
	public String getAccountNameByAccountId(String accountId) {
		CrmAccount crmAccount = this.getAccountByAccountId(accountId);
		if(null != crmAccount){
			return crmAccount.getAccountName();
		} else {
			return StringUtils.EMPTY;
		}
	}

	/**
	 * Get All the accounts by revenue with in the fiscal year
	 * @return
	 */
	public Map<String, Object> getAllAccountsByRevenue() {
		String fiscalStartDate = this.manualAccountStrategyService.getFiscalStartDateStr();
		String endDate = MiriDateUtils.parseDateToString(Calendar.getInstance(), MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return this.getAllAccountsByRevenueWithInTimeFrame(fiscalStartDate, endDate);
	}

	/**
	 * Get all the accounts by revenue with in the 
	 * @param startDate
	 * @param endDate
	 * @return
	 */

	public Map<String, Object> getAllAccountsByRevenueWithInTimeFrame(final String startDate, 
			final String endDate) {
		Map<String, Object> topAccountsData = new HashMap<>();
		timerUtil.start();
		// handling the mapped sales stage in the called method
		SearchRequestBuilder searchRequestBuilder = this.crmOpportunityService.getAccountsByOpportunityQuery(startDate, 
				endDate, OpportunityStagesEnum.CLOSED_WON.getText());

		Aggregations aggregations = esQueryUtils.execute(searchRequestBuilder).getAggregations();
		Terms accountTerms = aggregations.get(SearchConstants.ACCOUNT_AGGREGATION);

		Collection<Terms.Bucket> accountBuckets = accountTerms.getBuckets();
		
		long maxHits = 0;
		for(final Terms.Bucket accountBucket: accountBuckets) {
			maxHits = accountBucket.getDocCount();
			break;
			/*accountIds.add(accountBucket.getKey());
			executorService.submit(new Runnable() {
				@Override
				public void run() {
					updateTopAccountsMap(startDate, endDate, accountBucket.getKey(), 
							OpportunityStagesEnum.CLOSED_WON.getText(), null);
				}
			});*/
		}

		searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setSize(0)
				.setQuery(QueryBuilders.termQuery(SearchConstants.STAGE_RAW, OpportunityStagesEnum.CLOSED_WON.getText()))
				/*FilterBuilders.rangeFilter(SearchConstants.CREATED_ON).gte(startDate).lte(endDate)))*/
				.addAggregation(AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
						.field(SearchConstants.ACCOUNT_ID_RAW).size(0).subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_HITS_AGGREGATION)
								.setSize((int) maxHits).setFetchSource(SearchConstants.OPPORTUNITY_ID, null)));
		
		accountTerms = esQueryUtils.execute(searchRequestBuilder).getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);

		accountBuckets = accountTerms.getBuckets();
		List<String> opportunityIds;
		for(final Terms.Bucket accountBucket: accountBuckets) {
			TopHits topAccountHits = accountBucket.getAggregations().get(SearchConstants.TOP_HITS_AGGREGATION);
			opportunityIds  = new ArrayList<>();
			for(SearchHit hit: topAccountHits.getHits()) {
				opportunityIds.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			CrmAccount account = this.getAccountByAccountId(accountBucket.getKey());
			List<String> lostOpportunityIds = this.crmOpportunityService.getLostOpportunitiesByAccountId(accountBucket.getKey(), startDate, endDate);
			double revenueAmount = this.erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, startDate, endDate);
			RevenueOpportunitiesData revenueOpportunitiesData = new RevenueOpportunitiesData();
			revenueOpportunitiesData.setOpportunityIds(opportunityIds);
			revenueOpportunitiesData.setRevenueAmount(revenueAmount);
			revenueOpportunitiesData.setLostOpportunityIds(lostOpportunityIds);
			revenueOpportunitiesData.setId(accountBucket.getKey());
			topAccountsData.put(account.getAccountName(), revenueOpportunitiesData);
		}
		//executorService.shutdown();

		/*try {
			if(!executorService.awaitTermination(1, TimeUnit.MINUTES))
				executorService.shutdownNow();
		} catch(InterruptedException e) {
			LOG.error("Exception while updating the concurrent Account map :" + e.getMessage());
		}*/

		LOG.debug("Processed accounts data :" + timerUtil.timeTakenInMillis());
		return MiriSearchUtils.sortMapByObjectValue(topAccountsData);
	}

	/**
	 * Account Ids by Industry name
	 * @param industryName
	 * @return
	 */
	public List<String> getAccountIdsByIndustry(String industryName) {
		Client client = this.getTransportClient();
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType()).setQuery(QueryBuilders.termQuery(CRMConstants.ACCOUNT_INDUSTRY_RAW, industryName))
				.setSearchType(SearchType.SCAN).setSize(500)
				.setScroll(new TimeValue(6000));
		SearchResponse searchResponse = searchRequestBuilder.get();
		List<String> accountIds = new ArrayList<>(); 
		while(true) {
			for(SearchHit hit: searchResponse.getHits()) {
				accountIds.add(hit.getSource().get(SearchConstants.ACCOUNT_ID).toString());
			}
			//LOG.debug("opportunity Ids size:" + opportunityIds.size());
			searchResponse = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)).get();
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		return accountIds;
	}

	/**
	 * Get All Accounts with in the time frame
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public Map<String, Object> getAllAccountsByRevenueWithInTimeFrame(Calendar startDate,
			Calendar endDate) {
		String startDateStr = MiriDateUtils.parseDateToString(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		String endDateStr = MiriDateUtils.parseDateToString(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return this.getAllAccountsByRevenueWithInTimeFrame(startDateStr, endDateStr);
	}

	/**
	 * Get Competitive Win Rate for Customers/Accounts
	 * @param customersData
	 * @return
	 * @author rammoole
	 */
	public List<WinLossData> getWinLossDataForCustomers(List<Object> customersData) {
		return this.erpOpportunityCompetitorService.getWinRateForCompetitors(customersData,null,null);
	}

	/**
	 * Win Loss Data for other customers/accounts. here other customers mean by is there are more than 25 Customers/Accounts.
	 * rest of the customers/accounts other than top 25
	 * @param otherCustomersData
	 * @return
	 * @author rammoole
	 */
	public WinLossData getWinLossDataForOtherCustomers(List<Object> otherCustomersData) {
		return this.erpOpportunityCompetitorService.getWinRateForOtherCompetitors(otherCustomersData,null,null);
	}

	/**
	 * Update Countries data by executor service threads
	 * @param startDate
	 * @param endDate
	 * @param stage
	 * @param accountId
	 */
	public void updateCountriesMap(final String startDate, final String endDate, final String stage, 
			final String accountId, final List<String> crmOpportunityIds) {
		Client client = this.getTransportClient();

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(accountId)) {
			boolFilterBuilder.must(FilterBuilders.termFilter(SearchConstants.ACCOUNT_ID_RAW, accountId));
		}
		if(StringUtils.isNotBlank(stage)) {
			boolFilterBuilder.must(FilterBuilders.termFilter(SearchConstants.STAGE_RAW, stage));
		}

		if(CollectionUtils.isNotEmpty(crmOpportunityIds)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, crmOpportunityIds));
		}

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));
		}

		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(500);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		CrmAccount account = this.getAccountByAccountId(accountId);
		List<String> opportunityIds = new ArrayList<>();
		while(true) {
			for(SearchHit opportunityHit: searchResponse.getHits()) {
				opportunityIds.add(opportunityHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}

		timerUtil.end();
		//LOG.debug("Countries Query :" + timerUtil.timeTakenInMillis() + "|" + opportunityIds.size());
		double revenueAmount = this.erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, startDate, endDate);
		List<String> lostOpportunityIds = this.crmOpportunityService.getLostOpportunitiesByAccountId(accountId, startDate, endDate);
		if(topCountriesData.containsKey(account.getBillingAddress().getCountryName())) {
			RevenueOpportunitiesData revenueOpportunitiesData = (RevenueOpportunitiesData) topCountriesData
					.get(account.getBillingAddress().getCountryName());
			revenueOpportunitiesData.setRevenueAmount(revenueOpportunitiesData.getRevenueAmount() + revenueAmount);
			revenueOpportunitiesData.getOpportunityIds().addAll(opportunityIds);
			revenueOpportunitiesData.getLostOpportunityIds().addAll(lostOpportunityIds);
			topCountriesData.put(account.getBillingAddress().getCountryName(), revenueOpportunitiesData);
		} else {
			RevenueOpportunitiesData revenueOpportunitiesData = new RevenueOpportunitiesData();
			revenueOpportunitiesData.setOpportunityIds(opportunityIds);
			revenueOpportunitiesData.setRevenueAmount(revenueAmount);
			revenueOpportunitiesData.setLostOpportunityIds(lostOpportunityIds);
			topCountriesData.put(account.getBillingAddress().getCountryName(), revenueOpportunitiesData);
		}
	}

	/**
	 * Get opportunities by regions - This method is not used any where now. But needed for next sprint.
	 * @param startDate
	 * @param endDate
	 * @return
	 */

	public Map<String, Object> getOpportunitiesByRegion(final String startDate, final String endDate, final String stage) {
		timerUtil.start();
		topRegionsData = new ConcurrentHashMap<>();
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.addAggregation(AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
						.field(CRMConstants.ACCOUNT_REGION_RAW).size(0));
		Aggregations aggregations = searchRequestBuilder.get().getAggregations();
		timerUtil.end();
		LOG.debug("After executing the accountAggregation Query:" + timerUtil.timeTakenInMillis());
		timerUtil.start();
		Terms regionTerms = aggregations.get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> regionBuckets = regionTerms.getBuckets();
		LOG.debug("Account Region: " + regionBuckets.size());
		ExecutorService executorService =  Executors.newFixedThreadPool(70);
		for(final Terms.Bucket regionBucket: regionBuckets) {
			executorService.submit(new Runnable() {
				@Override
				public void run() {
					updateRegionsMap(startDate, endDate, stage, regionBucket.getKey());
				}
			});
		}
		executorService.shutdown();

		try {
			if(executorService.awaitTermination(1, TimeUnit.MINUTES)) {
				executorService.shutdownNow();
			}
		} catch (InterruptedException e) {
			LOG.error("exception while running executor service threads for accounts" + e.getMessage());
		}
		LOG.info("Regions Data:" + topRegionsData.size());
		timerUtil.end();
		LOG.debug("Time Taken For Regions:" + timerUtil.timeTakenInMillis());
		return MiriSearchUtils.sortMapByObjectValue(topRegionsData);
	}

	/**
	 * Updates the region map
	 * @param startDate
	 * @param endDate
	 * @param stage
	 * @param region
	 */
	public void updateRegionsMap(final String startDate, final String endDate, final String stage, final String region) {
		//LOG.info("Update Regions Information");
		timerUtil.start();
		Client client = this.getTransportClient();
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.termQuery(CRMConstants.ACCOUNT_REGION_RAW, region))
				.setSearchType(SearchType.SCAN).setSize(500)
				.setFetchSource(CRMConstants.OPPORTUNITY_ACCOUNT_ID, null)
				.setScroll(new TimeValue(600000));
		//LOG.debug(searchRequestBuilder);
		timerUtil.end();
		LOG.debug("Time taken for opportunnies of the account:" + timerUtil.timeTakenInMillis());
		//LOG.debug("Search Request Builder" + searchRequestBuilder);
		SearchResponse searchResponse = searchRequestBuilder.get();
		List<String> accountIds = new ArrayList<>();
		while(true) {
			for(SearchHit hit: searchResponse.getHits().getHits()) {
				accountIds.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ACCOUNT_ID).toString());
			}
			searchResponse = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(600000)).get();
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		timerUtil.start();
		//LOG.debug("Region - Accounts Size: " + region + "-" + accountIds.size());
		searchRequestBuilder = client.prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText()).setSearchType(SearchType.SCAN).setSize(500)
				.setFetchSource(CRMConstants.OPPORTUNITY_ID, null)
				.setScroll(new TimeValue(6000));
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(stage)) {
			boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.OPPORTUNITY_STAGE_RAW, stage));
		}

		if(CollectionUtils.isNotEmpty(accountIds)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ACCOUNT_ID_RAW, accountIds));
		}

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CREATED_ON).gte(startDate).lte(endDate));
		}
		searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		//LOG.debug(searchRequestBuilder);
		searchResponse = searchRequestBuilder.get();
		timerUtil.end();
		LOG.debug("Time Taken opportunities by account Ids: " + timerUtil.timeTakenInMillis());
		//LOG.debug("Hits Size: " + searchResponse.getHits().getTotalHits());
		List<String> opportunityIds = new ArrayList<>();
		while(true) {
			for(SearchHit hit: searchResponse.getHits().getHits()) {
				opportunityIds.add(hit.getSource().get(CRMConstants.OPPORTUNITY_ID).toString());
			}
			searchResponse = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)).get();
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		timerUtil.start();
		//LOG.debug("Opportunities :" + region + "|" + opportunityIds.size());
		Map<String, Object> countriesData = this.getCountriesByAccountIds(accountIds, startDate, endDate);
		//LOG.debug(countriesData);
		timerUtil.end();
		LOG.debug("Timer Taken Account Countries: " + timerUtil.timeTakenInMillis());
		timerUtil.start();
		double revenueAmount = erpInvoiceService.getInvoiceAmountByOpportunityIds(opportunityIds, startDate, endDate);
		List<String> lostOpportunityIds = crmOpportunityService.getLostOpportunitiesByAccountIds(accountIds, startDate, endDate);
		RevenueOpportunitiesData revenueOpportunitiesData = new RevenueOpportunitiesData();
		revenueOpportunitiesData.setOpportunityIds(opportunityIds);
		revenueOpportunitiesData.setRevenueAmount(revenueAmount);
		revenueOpportunitiesData.setLostOpportunityIds(lostOpportunityIds);
		revenueOpportunitiesData.setCountriesData(countriesData);
		topRegionsData.put(region, revenueOpportunitiesData);
		timerUtil.end();
		LOG.debug("revenue amount, lost opportunities and Map updation : " + timerUtil.timeTakenInMillis());
	}

	/**
	 * Get Countries information by account Ids
	 * @param accountIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Object> getCountriesByAccountIds(final List<String> accountIds, final String startDate, 
			final String endDate) {
		BoolQueryBuilderRequest boolQueryRequests = new BoolQueryBuilderRequest(CRMConstants.OPPORTUNITY_ACCOUNT_ID_RAW,
				accountIds, SearchConstants.BATCH_SIZE_1000, BoolType.MUST);
		BoolQueryBuilder boolQueryBuilder = MiriSearchUtils.createBoolQueryBuilder(boolQueryRequests);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setSize(0)
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText()).setQuery(boolQueryBuilder)
				.addAggregation(AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
						.field(CRMConstants.OPPORTUNITY_ACCOUNT_ID_RAW).size(0));
		//LOG.debug("Account countries :" + searchRequestBuilder);
		SearchResponse searchResponse = searchRequestBuilder.get();

		Terms accountTerms = searchResponse.getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
		Collection<Terms.Bucket> accountBuckets = accountTerms.getBuckets();
		Map<String, Object> countriesData = new HashMap<>();
		List<String> wonOpportunities;
		List<String> lostOpportunities;
		RevenueOpportunitiesData revenueOpportunitiesData;
		String countryName;
		for(Terms.Bucket accountBucket: accountBuckets) {
			//LOG.debug("Account Bucket :" + accountBucket.getKey());
			CrmAccount crmAccount = this.getAccountByAccountId(accountBucket.getKey());
			//LOG.debug("CRM Account :" + crmAccount);
			wonOpportunities = crmOpportunityService.getWonOpportunitiesByAccountId(accountBucket.getKey(), startDate, endDate);
			lostOpportunities = crmOpportunityService.getLostOpportunitiesByAccountId(accountBucket.getKey(), startDate, endDate);
			countryName = crmAccount.getBillingAddress().getCountryName();
			if(countriesData.containsKey(countryName)) {
				revenueOpportunitiesData = (RevenueOpportunitiesData) countriesData.get(countryName);
				revenueOpportunitiesData.getOpportunityIds().addAll(wonOpportunities);
				revenueOpportunitiesData.getLostOpportunityIds().addAll(lostOpportunities);
				revenueOpportunitiesData.setRevenueAmount(revenueOpportunitiesData.getRevenueAmount() + 
						erpInvoiceService.getInvoiceAmountByOpportunityIds(wonOpportunities, null, null));
				countriesData.put(countryName, revenueOpportunitiesData);
			} else {
				revenueOpportunitiesData = new RevenueOpportunitiesData();
				revenueOpportunitiesData.setOpportunityIds(wonOpportunities);
				revenueOpportunitiesData.setLostOpportunityIds(lostOpportunities);
				revenueOpportunitiesData.setRevenueAmount(erpInvoiceService.getInvoiceAmountByOpportunityIds(
						wonOpportunities, startDate, endDate));
				countriesData.put(countryName, revenueOpportunitiesData);
			}
		}
		return MiriSearchUtils.sortMapByObjectValue(countriesData);
	}

	/**
	 * Get the Win Loss Data by country
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public Map<String, Object> getCountriesByOpportunities(final String startDate, final String endDate, 
			final List<String> opportunityIds, final String stage) {
		timerUtil.start();
		topCountriesData = new ConcurrentHashMap<>();
		SearchRequestBuilder searchRequestBuilder = this.crmOpportunityService
				.getAccountsByOpportunityQueryByOpportunities(startDate, endDate, opportunityIds);
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		Aggregations aggregations = response.getAggregations();
		Terms accountTerms = aggregations.get(SearchConstants.ACCOUNT_AGGREGATION);
		Collection<Terms.Bucket> accountBuckets = accountTerms.getBuckets();
		ExecutorService executorService =  Executors.newFixedThreadPool(70);
		for(final Terms.Bucket accountBucket: accountBuckets) {
			executorService.submit(new Runnable() {
				@Override
				public void run() {
					updateCountriesMap(startDate, endDate, stage, 
							accountBucket.getKey(), opportunityIds);
				}
			});
		}

		executorService.shutdown();
		try {
			if(executorService.awaitTermination(1, TimeUnit.MINUTES)) {
				executorService.shutdownNow();
			}
		} catch (InterruptedException e) {
			LOG.error("exception while running executor service threads for accounts :" + e.getMessage());
		}
		try {
			if(executorService.awaitTermination(1, TimeUnit.MINUTES)) {
				executorService.shutdownNow();
			}
		} catch (InterruptedException e) {
			LOG.error("exception while running executor service threads for accounts :" + e.getMessage());
		}
		timerUtil.end();
		LOG.debug("Time Taken For countries: " + timerUtil.timeTakenInMillis());
		return MiriSearchUtils.sortMapByObjectValue(topCountriesData);
	}


	/* (non-Javadoc)
	 * @see com.miri.search.service.MiriSearchService#getIndex()
	 */
	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	/* (non-Javadoc)
	 * @see com.miri.search.service.MiriSearchService#getDocumentType()
	 */
	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_ACCOUNT.getText();
	}

	/**
	 * Get Lost Opportunities By Account ID
	 * @param accountId
	 * @return
	 */
	public List<String> getLostOpportunitiesByAccountId(String accountId) {
		// Get all the lost opportunities
		SearchResponse searchResponse = this.getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.termQuery(SearchConstants.ACCOUNT_ID, accountId))
				.setPostFilter(FilterBuilders.termFilter(SearchConstants.STAGE_RAW, SearchConstants.OPPORTUNITY_CLOSED_LOST))
				.get();
		List<String> opportunityIds = null;
		if(searchResponse != null) {
			opportunityIds = new ArrayList<>();
			SearchHits searchHits = searchResponse.getHits();
			for(SearchHit searchHit: searchHits) {
				opportunityIds.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
		}
		return opportunityIds;
	}

	/**
	 * Get all the lost opportunities by industry
	 * @param industryName
	 * @return
	 */
	public List<String> getLostOpportunitiesByIndustry(String industryName) {
		SearchResponse searchResponse = this.getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_OPPORTUNITY.getText())
				.setQuery(QueryBuilders.termQuery(SearchConstants.OPPORTUNITY_INDUSTRY, industryName))
				.setPostFilter(FilterBuilders.termFilter(SearchConstants.STAGE_RAW, SearchConstants.OPPORTUNITY_CLOSED_LOST))
				.get();
		List<String> opportunityIds = null;
		if(searchResponse != null) {
			opportunityIds = new ArrayList<>();
			SearchHits searchHits = searchResponse.getHits();
			for(SearchHit searchHit: searchHits) {
				opportunityIds.add(searchHit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
		}
		return opportunityIds;
	}

	/**
	 * To get Crm account by accountId
	 * @param accountId
	 * @return CrmAccount
	 */
	public CrmAccount getCRMAccountByAccountId(String accountId) {
		timerUtil.start();
		CrmAccount crmAccount=(CrmAccount)esQueryUtils.getUniqueDocumentByDocId(getDocumentType(),getIndex(),SearchConstants.ACCOUNT_ID_RAW, accountId);
		timerUtil.end();
		LOG.debug("getCRMAccountByAccountId ES"+timerUtil.timeTakenInMillis());
		return crmAccount;

	}

	//	/**
	//	 * Get top countries by revenue
	//	 * @param startDate
	//	 * @param endDate
	//	 * @param stage
	//	 * @return
	//	 */
	//	public Map<String, Object> getTopCountriesByRevenue(final String startDate, final String endDate) {
	//		Map<String, Object> topCountriesData = new ConcurrentHashMap<>();
	//		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
	//				.setTypes(getDocumentType())
	//				.setSize(0)
	//				.addAggregation(AggregationBuilders.terms(SearchConstants.COUNTRY_AGGREGATION).field(CRMConstants.ACCOUNT_BILLING_ADDRESS_COUNTRY_RAW).size(0));
	//		
	//		Aggregations aggregations = searchRequestBuilder.get().getAggregations();
	//
	//		Terms countryTerms = aggregations.get(SearchConstants.COUNTRY_AGGREGATION);
	//		Collection<Terms.Bucket> accountBuckets = countryTerms.getBuckets();
	//
	//		for(final Terms.Bucket countryBucket: accountBuckets) {
	//			List<String> accountIds = this.getAccountIdsForCountry(countryBucket.getKey(), null, null);
	//			//LOG.info("Account Ids" + accountIds.size());
	//			List<String> wonOpportunityIds = this.crmOpportunityService.getOpportunitiesByAccountIdsAndStage(accountIds, OpportunityStagesEnum.CLOSED_WON.getText(), null, null, null);
	//			//LOG.info("Won Opportunity IDs: "+ wonOpportunityIds.size());
	//			List<String> lostOpportunityIds = this.crmOpportunityService.getOpportunitiesByAccountIdsAndStage(accountIds, OpportunityStagesEnum.CLOSED_LOST.getText(), null, null, null);
	//			
	//			double revenueAmount = this.erpInvoiceService.getInvoiceAmountByOpportunityIds(wonOpportunityIds, startDate, endDate);
	//			
	//			//LOG.info("revenue Amount :" + countryBucket.getKey() + "|" + revenueAmount);
	//			RevenueOpportunitiesData revenueOpportunitiesData = new RevenueOpportunitiesData();
	//			revenueOpportunitiesData.setOpportunityIds(wonOpportunityIds);
	//			revenueOpportunitiesData.setRevenueAmount(revenueAmount);
	//			revenueOpportunitiesData.setLostOpportunityIds(lostOpportunityIds);
	//			topCountriesData.put(countryBucket.getKey(), revenueOpportunitiesData);
	//		}
	//		return MiriSearchUtils.sortMapByObjectValue(topCountriesData);
	//	}
	/**
	 * Get top countries by revenue
	 * @param startDate
	 * @param endDate
	 * @param stage
	 * @return
	 */
	public Map<String, Object> getTopCountriesByRevenueFromOpportunities(final String startDate, final String endDate, List<String> opportunityIds) {
		Map<String, Object> topCountriesData = new ConcurrentHashMap<>();
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.COUNTRY_AGGREGATION).field(CRMConstants.ACCOUNT_BILLING_ADDRESS_COUNTRY_RAW).size(0));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Collection<Terms.Bucket> countryBuckets = null;
		if (searchResponse.getAggregations() != null) {
			Terms countryTerms = searchResponse.getAggregations().get(SearchConstants.COUNTRY_AGGREGATION);
			countryBuckets = countryTerms.getBuckets();
		}
		//LOG.info(countryBuckets.size());
		RevenueOpportunitiesData revenueOpportunitiesData = null;
		for(final Terms.Bucket countryBucket: countryBuckets) {
			
			List<String> accountIds = this.getAccountIdsForCountry(countryBucket.getKey(), null, null);
			//  LOG.info("Account Ids" + accountIds.size());
			List<String> wonOpportunityIds = this.crmOpportunityService.getOpportunitiesByAccountIdsAndStage(accountIds, OpportunityStagesEnum.CLOSED_WON.getText(), null, null, opportunityIds);
			//  LOG.info("Won Opportunity IDs: "+ wonOpportunityIds.size());
			//	List<String> lostOpportunityIds = this.crmOpportunityService.getOpportunitiesByAccountIdsAndStage(accountIds, OpportunityStagesEnum.CLOSED_LOST.getText(), null, null, opportunityIds);

			InvoiceStatsData invoiceStats = this.erpInvoiceService.getAdsAspDealsRevenueByOpportunities(wonOpportunityIds, startDate, endDate);
			
			//LOG.info("revenue Amount :" + countryBucket.getKey() + "|" + revenueAmount);
			if(invoiceStats.getRevenueAmount() > 0) {
				revenueOpportunitiesData = new RevenueOpportunitiesData();
				revenueOpportunitiesData.setOpportunityIds(wonOpportunityIds);
				revenueOpportunitiesData.setRevenueAmount(invoiceStats.getRevenueAmount());
				revenueOpportunitiesData.setAvgSellPrice(invoiceStats.getAsp());
				revenueOpportunitiesData.setAvgDealSize(invoiceStats.getAds());
				revenueOpportunitiesData.setNoOfDeals(invoiceStats.getDealsClosed());
				revenueOpportunitiesData.setValidOpportunityIds(invoiceStats.getValidOpportunities());
				//revenueOpportunitiesData.setLostOpportunityIds(lostOpportunityIds);
				topCountriesData.put(countryBucket.getKey(), revenueOpportunitiesData);
			}
		}
		return MiriSearchUtils.sortMapByObjectValue(topCountriesData);
	}
	/**
	 * Get top countries by revenue
	 * @param startDate
	 * @param endDate
	 * @param stage
	 * @return
	 */
	public Map<String, Object> getTopCountriesByRevenueFromOpportunitiesWithoutAdditionalData(final String startDate, final String endDate, List<String> opportunityIds) {
		Map<String, Object> topCountriesData = new ConcurrentHashMap<>();
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.COUNTRY_AGGREGATION).field(CRMConstants.ACCOUNT_BILLING_ADDRESS_COUNTRY_RAW).size(0));
		
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Collection<Terms.Bucket> countryBuckets = null;
		if (searchResponse.getAggregations() != null) {
			Terms countryTerms = searchResponse.getAggregations().get(SearchConstants.COUNTRY_AGGREGATION);
			countryBuckets = countryTerms.getBuckets();
		}
		//LOG.info(countryBuckets.size());
		RevenueOpportunitiesData revenueOpportunitiesData = null;
		for(final Terms.Bucket countryBucket: countryBuckets) {
			
			List<String> accountIds = this.getAccountIdsForCountry(countryBucket.getKey(), null, null);
			//  LOG.info("Account Ids" + accountIds.size());
			List<String> wonOpportunityIds = this.crmOpportunityService.getOpportunitiesByAccountIdsAndStage(accountIds, OpportunityStagesEnum.CLOSED_WON.getText(), null, null, opportunityIds);
			//  LOG.info("Won Opportunity IDs: "+ wonOpportunityIds.size());
			//	List<String> lostOpportunityIds = this.crmOpportunityService.getOpportunitiesByAccountIdsAndStage(accountIds, OpportunityStagesEnum.CLOSED_LOST.getText(), null, null, opportunityIds);
			double revenueAmount = erpInvoiceService.getInvoiceAmountByOpportunityIds(wonOpportunityIds, startDate, endDate);
			
			//LOG.info("revenue Amount :" + countryBucket.getKey() + "|" + revenueAmount);
			if(revenueAmount > 0) {
				revenueOpportunitiesData = new RevenueOpportunitiesData();
				revenueOpportunitiesData.setOpportunityIds(wonOpportunityIds);
				revenueOpportunitiesData.setRevenueAmount(revenueAmount);
				//revenueOpportunitiesData.setLostOpportunityIds(lostOpportunityIds);
				topCountriesData.put(countryBucket.getKey(), revenueOpportunitiesData);
			}
		}
		return MiriSearchUtils.sortMapByObjectValue(topCountriesData);
	}
	
	/**
	 * Gets the Revenue and Opportunities for a country
	 * @param countryName
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public InvoiceDataPojo getOpportunitiesOfCountry(String countryName, String startDate, String endDate){
		List<String> accountIds = this.getAccountIdsForCountry(countryName, null, null);
		List<String> wonOpportunityIds = this.crmOpportunityService
					.getOpportunitiesByAccountIdsAndStage(accountIds, null, null, null, null);
		return erpInvoiceService.getRevenueAndUniqueOpportunities(wonOpportunityIds, startDate, endDate);
	}

	/**
	 * Gets the Top countries With in time Frame
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Object> getTopCountriesByRevenue(final String startDate, final String endDate) {
		return this.getTopCountriesByRevenueFromOpportunities(startDate, endDate, null);

	}

	/**
	 * Get Top Countries by revenue
	 * @param countryName
	 * @param startDate
	 * @param endDate
	 * @return
	 * @author rammoole
	 */
	public List<String> getAccountIdsForCountry(final String countryName, final String startDate, final String endDate) {
		List<String> opportunityIds = new ArrayList<>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.ACCOUNT_CREATED_DATE).from(startDate).to(endDate));
		}

		if(StringUtils.isNotBlank(countryName)) {
			boolFilterBuilder.must(FilterBuilders.termFilter(CRMConstants.ACCOUNT_BILLING_ADDRESS_COUNTRY_RAW, countryName));
		}

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.CRM_ACCOUNT.getText()).setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(1000)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);

		while(true) {
			for(SearchHit hit: opportunityRespose.getHits().getHits()) {
				opportunityIds.add(hit.getSource().get(CRMConstants.ACCOUNT_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(60000));
			opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return opportunityIds;
	}
	
	/**
	 * Gets AccountNames Froms AccountIds
	 * @param accountIds
	 * @return 
	 */
	public List<String> getAccountNamesForIds(List<String> accountIds){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_ID_RAW, accountIds));
		List<String> accountNames = new ArrayList<>();
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);

		while(true) {
			for(SearchHit hit: opportunityRespose.getHits().getHits()) {
				accountNames.add((String)hit.getSource().get(CRMConstants.ACCOUNT_NAME));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(60000));
			opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return accountNames;
	}
	
	/**
	 * Gets Account ID by Account Name
	 * @param accountName
	 * @return
	 */
	public List<String> getAccountIdByAccountName(String accountName) {
		return getAccountIdsByAccountNames(Arrays.asList(accountName));
	}
	
	/**
	 * Gets Account ID by Account Name
	 * @param accountName
	 * @return
	 */
	public List<String> getAccountIdsByAccountNames(List<String> accountName) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.termsFilter(CRMConstants.ACCOUNT_NAME_RAW, accountName)));
				
		SearchResponse searchResponse = this.esQueryUtils.execute(searchRequestBuilder);
		List<String> accountId = new ArrayList<>();
		
		while(true) {
			for(SearchHit hit: searchResponse.getHits().getHits()) {
				accountId.add((String)hit.getSource().get(CRMConstants.ACCOUNT_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(60000));
			searchResponse = esQueryUtils.execute(searchScrollRequestBuilder);
			if(searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		
		return accountId;
	}
	
	/**
	 * Gets AccountNames Froms AccountIds
	 * @param accountIds
	 * @return 
	 */
	public Map<String, String> getAccountNamesAndIdsForAccountIds(List<String> accountIds){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.ACCOUNT_ID_RAW, accountIds));
		Map<String, String> accountNames = new HashMap<>();
		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse opportunityRespose = esQueryUtils.execute(searchRequestBuilder);

		while(true) {
			for(SearchHit hit: opportunityRespose.getHits().getHits()) {
				accountNames.put((String)hit.getSource().get(CRMConstants.ACCOUNT_ID),(String)hit.getSource().get(CRMConstants.ACCOUNT_NAME));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder = getTransportClient().prepareSearchScroll(opportunityRespose.getScrollId()).setScroll(new TimeValue(60000));
			opportunityRespose = esQueryUtils.execute(searchScrollRequestBuilder);
			if(opportunityRespose.getHits().getHits().length == 0) {
				break;
			}
		}
		return accountNames;
	}
}
