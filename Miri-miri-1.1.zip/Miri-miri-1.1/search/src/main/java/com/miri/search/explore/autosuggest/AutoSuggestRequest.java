/**
 * 
 */
package com.miri.search.explore.autosuggest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

/**
 * @author Chandra
 *
 */
@Component
public class AutoSuggestRequest {

	private Map<String, List<String>> docAndFieldsMap = new HashMap<>();

	List<RequestItem> requestItems = new ArrayList<>();

	public List<RequestItem> getRequestItems() {
		return requestItems;
	}

	public Map<String, List<String>> getDocAndFieldsMap() {
		return docAndFieldsMap;
	}

	public void setRequestItems(List<RequestItem> requestItems) {
		this.requestItems = requestItems;
	}

	public void setDocAndFieldsMap(Map<String, List<String>> docAndFieldsMap) {
		this.docAndFieldsMap = docAndFieldsMap;
	}

	public static class RequestItem {
		private String docType;

		private List<String> fields;

		private String identifier;

		public String getDocType() {
			return docType;
		}

		public void setDocType(String docType) {
			this.docType = docType;
		}

		public List<String> getFields() {
			return fields;
		}

		public void setFields(List<String> fields) {
			this.fields = fields;
		}

		public String getIdentifier() {
			return identifier;
		}

		public void setIdentifier(String identifier) {
			this.identifier = identifier;
		}

	}
}
