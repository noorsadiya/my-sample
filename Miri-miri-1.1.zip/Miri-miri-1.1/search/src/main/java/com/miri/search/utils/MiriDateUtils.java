
package com.miri.search.utils;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.miri.search.data.FiscalDatesData;
import com.miri.search.data.FiscalDatesStrData;

/**
 * Miri Date Utils
 * @author rammoole
 *
 */
public final class MiriDateUtils {

	private static final Logger LOG = LogManager.getLogger(MiriDateUtils.class);


	public static final String DATE_FORMAT_YYYY_MM_DD_HH_MM_SSS = "yyyy-MM-dd hh:mm:ss.SSS";
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	public static final String[] MONTH_NAMES = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

	private MiriDateUtils() {

	}

	/**
	 * Parses String to Date object in the given format
	 * @param dateFormat
	 * @param dateStr
	 * @return Date object if parseable other returns current date.
	 */
	public static Date parseStringToDate(String dateFormat, String dateStr) {
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
		try {
			return formatter.parse(dateStr);
		} catch (ParseException e) {
			LOG.error("Exception while parsing date :", e);
		}
		return null;
	}

	/**
	 * Parses String to Calendar object in the given format
	 * @param dateStr
	 * @param dateFormat
	 * @return Date object if parseable other returns current Calendar.
	 */
	public static Calendar parseStrDateToCalendar(String dateStr, String dateFormat) {
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
		try {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(formatter.parse(dateStr));
			return calendar;
		} catch (ParseException e) {
			LOG.error("Exception while parsing date :", e);
		}
		return Calendar.getInstance();
	}

	public static Date getFirstQuarterDate() {

		return new Date();
	}

	public static int getMonth(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.MONTH);
	}

	/**
	 * Converting calendar date object to String with format pattern
	 * @param date
	 * @param format
	 * @return
	 * @author rammoole
	 */
	public static String parseDateToString(Calendar date, String format) {
		SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
		return dateFormatter.format(date.getTime());
	}
	
	/**
	 * Converting calendar date object to String with format pattern
	 * @param date
	 * @param format
	 * @return
	 * @author rammoole
	 */
	public static String parseDateToString(Date date, String format) {
		SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
		return dateFormatter.format(date);
	}

	/**
	 * Returns the numbers of the months between the dates
	 * @param startDate
	 * @param endDate
	 * @author rammoole
	 * @return
	 */
	public static Map<Integer, String> getMonthsBetweenDates(Calendar startDateCal, Calendar endDateCal) {
		Map<Integer,String> monthAndYearMap = new LinkedHashMap<>();
		Calendar startDate = Calendar.getInstance();
		startDate.setTimeInMillis(startDateCal.getTimeInMillis());
		Date endDate = endDateCal.getTime();
		int counter = 0;

		Format formatter = new SimpleDateFormat("MMM YY"); 
		
		while (endDate.getTime() > startDate.getTimeInMillis()) {
			monthAndYearMap.put(counter, formatter.format(startDate.getTime()));
			startDate.add(Calendar.MONTH, 1);
			counter++;
			if( counter!=0 && endDateCal.get(Calendar.MONTH) == startDate.get(Calendar.MONTH)){
				monthAndYearMap.put(counter,formatter.format(startDate.getTime()));
			}
				
		}
		return monthAndYearMap;
	}
	
	/**
	 * Get Months between the dates
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static Map<String, Integer> getMonthsBetweenDates(final String startDate, final String endDate) {
		Calendar startDateCal = parseStrDateToCalendar(startDate, DATE_FORMAT_YYYY_MM_DD);
		Calendar endDateCal = parseStrDateToCalendar(endDate, DATE_FORMAT_YYYY_MM_DD);
		Map<String, Integer> monthsBetweenDates = new LinkedHashMap<>();
		for(Map.Entry<Integer, String> monthEntry: getMonthsBetweenDates(startDateCal, endDateCal).entrySet()) {
			monthsBetweenDates.put(monthEntry.getValue(), monthEntry.getKey());
		}
		return monthsBetweenDates;
	}
	

	/**
	 * Gets the updated endDate till the current date
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static Map<Integer, String> getUpdatedDates(final String startDate, final String endDate){
		Calendar startDateCal = parseStrDateToCalendar(startDate, DATE_FORMAT_YYYY_MM_DD);
		Calendar endDateCal = parseStrDateToCalendar(endDate, DATE_FORMAT_YYYY_MM_DD);
		if(endDateCal.after(Calendar.getInstance())){
			endDateCal.setTime(new Date());
		}
		Map<Integer, String> monthsBetweenDates = new LinkedHashMap<>();
		for(Map.Entry<Integer, String> monthEntry: getMonthsBetweenDates(startDateCal, endDateCal).entrySet()) {
			monthsBetweenDates.put(monthEntry.getKey(), monthEntry.getValue());
		}
		return monthsBetweenDates;
		
	}
	
	/**
	 * Gets the updated endDate till the current date
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static Map<String, Integer> getUpdatedDatesWithStringKey(final String startDate, final String endDate){
		Calendar startDateCal = parseStrDateToCalendar(startDate, DATE_FORMAT_YYYY_MM_DD);
		Calendar endDateCal = parseStrDateToCalendar(endDate, DATE_FORMAT_YYYY_MM_DD);
		if(endDateCal.after(Calendar.getInstance())){
			endDateCal.setTime(new Date());
		}
		Map<String, Integer> monthsBetweenDates = new LinkedHashMap<>();
		for(Map.Entry<Integer, String> monthEntry: getMonthsBetweenDates(startDateCal, endDateCal).entrySet()) {
			monthsBetweenDates.put(monthEntry.getValue(), monthEntry.getKey());
		}
		return monthsBetweenDates;
		
	}
	/**
	 * Get Months between the dates
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static List<String> getMonthsBetweenDatesInMMM(final Calendar startDateCal, final Calendar endDateCal) {
		List<String> monthsBetweenDates = new ArrayList<>();
		Calendar startDate = Calendar.getInstance();
		startDate.setTimeInMillis(startDateCal.getTimeInMillis());
		Date endDate = endDateCal.getTime();
		Format formatter = new SimpleDateFormat("MMM");
		while (endDate.getTime() > startDate.getTimeInMillis()) {
			monthsBetweenDates.add(formatter.format(startDate.getTime()));
			startDate.add(Calendar.MONTH, 1);
		}
		return monthsBetweenDates;
	}

	public static List<String> datesBetween(Date d1, Date d2) {
		List<String> ret = new ArrayList<String>();
		Calendar c = Calendar.getInstance();
		c.setTime(d1);
		Format formatter = new SimpleDateFormat("MMM YYY"); 
		while (d2.getTime() > c.getTimeInMillis()) {
			ret.add(formatter.format(c.getTime()));
			c.add(Calendar.MONTH, 1);
		}
		System.out.println(ret);
		return ret;
	}
	
	public static boolean isDateOneGreaterThanDateTwo(Date dateOne, Date dateTwo){
		
		if(dateOne != null){
			return dateTwo == null ? true : (dateOne.after(dateTwo) || dateOne.equals(dateTwo)); 
		}
		return false;
	}

	//	/**
	//	 * Returns the numbers of the months between the dates
	//	 * @param startDate
	//	 * @param endDate
	//	 * @author rammoole
	//	 * @return
	//	 */
	//	public static Map<Integer,String> getMonthsBetweenDates(Calendar startDate, Calendar endDate) {
	//		Map<Integer,String> monthAndYearMap=new LinkedHashMap<>();
	//		List<Integer> months = new LinkedList<>();
	//		int startingMonth = startDate.get(Calendar.MONTH);
	//		int fiscalStartYear=startDate.get(Calendar.YEAR);
	//		int fiscalEndMonth=endDate.get(Calendar.MONTH);
	//		int fiscalEndYear=endDate.get(Calendar.YEAR);
	//		int nextYearMonth=0;
	//		String monthWithYear=null;
	//		
	//		int fiscalEnd=11;
	//		if(fiscalEndMonth < fiscalEnd && startingMonth < fiscalEndMonth){
	//			fiscalEnd=fiscalEndMonth;
	//		}
	//		for(int i=startingMonth;i<=fiscalEnd;i++){
	//			months.add(startingMonth);
	//			monthWithYear=String.valueOf(MONTH_NAMES[startingMonth])+ " " +String.valueOf(fiscalStartYear).substring(2,String.valueOf(fiscalStartYear).length());
	//			monthAndYearMap.put(startingMonth,monthWithYear);
	//			startingMonth++;
	//		}
	//		
	//		if(fiscalStartYear!=fiscalEndYear){
	//			for(int j=0;j<=fiscalEndMonth;j++){
	//				months.add(nextYearMonth);
	//				monthWithYear=String.valueOf(MONTH_NAMES[nextYearMonth])+ " " +String.valueOf(fiscalEndYear).substring(2,String.valueOf(fiscalEndYear).length());
	//				monthAndYearMap.put(nextYearMonth,monthWithYear);
	//				nextYearMonth++;
	//			}
	//		}
	//		return monthAndYearMap;
	//		
	//	}

	/**
	 * Elasticsearch Formatted Date
	 * @param dateToformat
	 * @return
	 */
	public static String getElasticSearchFormattedDate(final Calendar dateToformat){
		SimpleDateFormat dateFormatter = new SimpleDateFormat(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		return dateFormatter.format(dateToformat.getTime());
	}

	/**
	 * @param date
	 * @return
	 */

	public static String getMonthAsString(final Date date) {

		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int month = cal.get(Calendar.MONTH);
		return MONTH_NAMES[month];
	}

	public static String getYearAsString(final Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		String year = String.valueOf(cal.get(Calendar.YEAR));
		return year;
	}

	/**
	 * @return
	 */
	public static List<String> getMonthsByFiscal() {
		List<String> list = new LinkedList<>();
		String[] months = new DateFormatSymbols().getShortMonths();
		list = Arrays.asList(months);
		return list;
	}
	
	
	/**
	 * Calculate the previous year
	 */
	public  static FiscalDatesData getPreviousFiscalYear(FiscalDatesData currentFiscalDates){
		FiscalDatesData previousFiscalDates=new  FiscalDatesData();
		
		Calendar startDate=currentFiscalDates.getFiscalStartDate();
		Calendar previousStartDate=Calendar.getInstance();
		if(null !=startDate){
			previousStartDate.set(startDate.get(Calendar.YEAR), startDate.get(Calendar.MONTH), 
					1);
			previousStartDate.set(Calendar.YEAR,previousStartDate.get(Calendar.YEAR)-1 );
			previousStartDate.set(previousStartDate.get(Calendar.YEAR), previousStartDate.get(Calendar.MONTH), 
					previousStartDate.getActualMaximum(Calendar.DAY_OF_MONTH));
			previousFiscalDates.setFiscalStartDate(previousStartDate);
		}
		
		Calendar endDate=currentFiscalDates.getFiscalEndDate();
		Calendar previousEndDate=Calendar.getInstance();
		if(null !=endDate){
			previousEndDate.set(endDate.get(Calendar.YEAR), endDate.get(Calendar.MONTH), 
					1);
			previousEndDate.set(Calendar.YEAR,previousEndDate.get(Calendar.YEAR)-1 );
			previousEndDate.set(previousEndDate.get(Calendar.YEAR), previousEndDate.get(Calendar.MONTH), 
					previousEndDate.getActualMaximum(Calendar.DAY_OF_MONTH));
			previousFiscalDates.setFiscalEndDate(previousEndDate);
		}
		
		return previousFiscalDates;
	}
	
	/***
	 * getExpiredDates : returns the expired dates where startdate will be the fiscal start date 
	 * end date is current date
	 * @param fiscalDates
	 * @return
	 */
	public static FiscalDatesStrData getExpiredDates(FiscalDatesStrData fiscalDates){
		
		FiscalDatesStrData expiredDates=new FiscalDatesStrData();
		expiredDates.setFiscalStartDateStr(fiscalDates.getFiscalStartDateStr());
		expiredDates.setFiscalEndDateStr(MiriDateUtils.parseDateToString(Calendar.getInstance(), 
				MiriDateUtils.DATE_FORMAT_YYYY_MM_DD));
		
		return expiredDates;
		
	}
	
	public static boolean isDateBetween(String date, Calendar startDate, Calendar endDate){
		Calendar dateToCheck = parseStrDateToCalendar(date, DATE_FORMAT_YYYY_MM_DD);
		if((dateToCheck.after(startDate) && dateToCheck.before(endDate)) || dateToCheck.equals(startDate) || dateToCheck.equals(endDate)){
			return true;
		}
		return false;
	}
		
	/**
	 * splitFiscalIntoMonths : List of months between two dates
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static List<String> splitFiscalIntoMonths(Calendar startDate, Calendar endDate){
		List<String> dates=new ArrayList<>();
		while(startDate.getTimeInMillis() <= endDate.getTimeInMillis()){
		 	startDate.add(Calendar.MONTH, 1);
		 	dates.add(MiriDateUtils.getElasticSearchFormattedDate(startDate));
		}
	    
		return dates;
	}
	

}