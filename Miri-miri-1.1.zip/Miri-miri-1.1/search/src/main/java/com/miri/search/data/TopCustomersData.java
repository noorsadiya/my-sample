package com.miri.search.data;

import java.io.Serializable;

import com.miri.search.constants.SearchConstants;

public class TopCustomersData implements Comparable<TopCustomersData>,Serializable {
	String xAxisName; 
	Double totalRevenue;
	Long hoverDealsClosed;
	Double yAxisValue;
	Integer countProducts;
	TopHighestCustomerData topHighestcustomer;
	
	Double zAxisValue;
	
	public String getxAxisName() {
		return xAxisName;
	}
	public void setxAxisName(String xAxisName) {
		this.xAxisName = xAxisName;
	}
	public Double getTotalRevenue() {
		return totalRevenue;
	}
	public void setTotalRevenue(Double totalRevenue) {
		this.totalRevenue = totalRevenue;
	}
	public Long getHoverDealsClosed() {
		return hoverDealsClosed;
	}
	public void setHoverDealsClosed(Long hoverDealsClosed) {
		this.hoverDealsClosed = hoverDealsClosed;
	}
	public Double getyAxisValue() {
		return yAxisValue;
	}
	public void setyAxisValue(Double yAxisValue) {
		this.yAxisValue = yAxisValue;
	}
	public Integer getCountProducts() {
		return countProducts;
	}
	public void setCountProducts(Integer countProducts) {
		this.countProducts = countProducts;
	}
	public TopHighestCustomerData getTopHighestcustomer() {
		return topHighestcustomer;
	}
	public void setTopHighestcustomer(TopHighestCustomerData topHighestcustomer) {
		this.topHighestcustomer = topHighestcustomer;
	}
	
	public Double getzAxisValue() {
		return zAxisValue;
	}
	
	public void setzAxisValue(Double zAxisValue) {
		this.zAxisValue = zAxisValue;
	}
	
	@Override
	public int compareTo(TopCustomersData customerData) {
		if(Math.abs(this.getyAxisValue() - customerData.getyAxisValue()) < SearchConstants.EPSILON) {
			return 0;
		} else {
			return this.getyAxisValue() > customerData.getyAxisValue() ? -1 : 1;
		}
	}
}
	
	