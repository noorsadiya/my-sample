package com.miri.search.data;

import java.io.Serializable;

/**
 * Buyers Journey Trend Analysis Graph Data
 * @author rammoole
 *
 */
public class SplineIrregularTimeData implements Serializable {
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -578548048631722091L;

	private BJTAData currentFiscalData;
	
	private BJTAData previousFiscalData;
	
	private String xAxisCategory;
	
	/**
	 * @return the currentFiscalData
	 */
	public BJTAData getCurrentFiscalData() {
		return currentFiscalData;
	}

	/**
	 * @param currentFiscalData the currentFiscalData to set
	 */
	public void setCurrentFiscalData(BJTAData currentFiscalData) {
		this.currentFiscalData = currentFiscalData;
	}

	/**
	 * @return the previousFiscalData
	 */
	public BJTAData getPreviousFiscalData() {
		return previousFiscalData;
	}

	/**
	 * @param previousFiscalData the previousFiscalData to set
	 */
	public void setPreviousFiscalData(BJTAData previousFiscalData) {
		this.previousFiscalData = previousFiscalData;
	}

	/**
	 * @return the xAxisCategory
	 */
	public String getxAxisCategory() {
		return xAxisCategory;
	}

	/**
	 * @param xAxisCategory the xAxisCategory to set
	 */
	public void setxAxisCategory(String xAxisCategory) {
		this.xAxisCategory = xAxisCategory;
	}
}
