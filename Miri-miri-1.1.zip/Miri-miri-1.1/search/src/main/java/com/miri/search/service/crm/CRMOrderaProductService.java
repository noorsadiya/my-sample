/**
 * 
 */
package com.miri.search.service.crm;

import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.entity.CrmOrderProduct;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.service.common.MiriSearchService;

/**
 * @author Chandra
 *
 */
@Component
public class CRMOrderaProductService extends MiriSearchService {
	
	@Autowired
	ESQueryUtils esQueryUtils;
    /*
     * (non-Javadoc)
     * 
     * @see com.miri.search.service.MiriSearchService#getIndex()
     */
    @Override
    public String getIndex() {
        return ElasticSearchEnums.CRM.getText();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.miri.search.service.MiriSearchService#getDocumentType()
     */
    @Override
    public String getDocumentType() {
        return ElasticSearchEnums.CRM_ORDER_PRODUCT.getText();
    }

    /**
     * Returns CRM OrderProduct instance based on given order and product id.
     * 
     * @param orderId
     * @param productId
     * @return
     */
    public CrmOrderProduct getOrderProductByOrderAndProduct(final String orderId, final String productId) {
        TreeMap<String, Object> fieldMap = new TreeMap<>();
        fieldMap.put("order.raw", orderId);
        fieldMap.put("productId.raw", productId);
        return (CrmOrderProduct) esQueryUtils.getUniqueDocumentByDocIdMap(getDocumentType(), getIndex(), fieldMap);
    }

}
