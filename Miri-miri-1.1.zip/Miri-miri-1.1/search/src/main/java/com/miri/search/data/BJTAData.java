package com.miri.search.data;

import java.io.Serializable;

/**
 * Buyers Journey Trend Analysis metric params
 * @author rammoole
 *
 */
public class BJTAData implements Serializable {
	
	
	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = -1066306689007416506L;
	private Integer timeToOpportunity;
	private Integer timeToSalesOrder;
	private Integer timeToInvoice;
	private Integer opportunityCount;
	private Integer salesOrderCount;
	private Integer invoiceCount;
	private Double revenueAmount;
	/**
	 * @return the timeToOpportunity
	 */
	public Integer getTimeToOpportunity() {
		return timeToOpportunity;
	}
	/**
	 * @param timeToOpportunity the timeToOpportunity to set
	 */
	public void setTimeToOpportunity(Integer timeToOpportunity) {
		this.timeToOpportunity = timeToOpportunity;
	}
	/**
	 * @return the timeToSalesOrder
	 */
	public Integer getTimeToSalesOrder() {
		return timeToSalesOrder;
	}
	/**
	 * @param timeToSalesOrder the timeToSalesOrder to set
	 */
	public void setTimeToSalesOrder(Integer timeToSalesOrder) {
		this.timeToSalesOrder = timeToSalesOrder;
	}
	/**
	 * @return the timeToInvoice
	 */
	public Integer getTimeToInvoice() {
		return timeToInvoice;
	}
	/**
	 * @param timeToInvoice the timeToInvoice to set
	 */
	public void setTimeToInvoice(Integer timeToInvoice) {
		this.timeToInvoice = timeToInvoice;
	}
	/**
	 * @return the opportunityCount
	 */
	public Integer getOpportunityCount() {
		return opportunityCount;
	}
	/**
	 * @param opportunityCount the opportunityCount to set
	 */
	public void setOpportunityCount(Integer opportunityCount) {
		this.opportunityCount = opportunityCount;
	}
	/**
	 * @return the salesOrderCount
	 */
	public Integer getSalesOrderCount() {
		return salesOrderCount;
	}
	/**
	 * @param salesOrderCount the salesOrderCount to set
	 */
	public void setSalesOrderCount(Integer salesOrderCount) {
		this.salesOrderCount = salesOrderCount;
	}
	/**
	 * @return the invoiceCount
	 */
	public Integer getInvoiceCount() {
		return invoiceCount;
	}
	/**
	 * @param invoiceCount the invoiceCount to set
	 */
	public void setInvoiceCount(Integer invoiceCount) {
		this.invoiceCount = invoiceCount;
	}
	/**
	 * @return the revenueAmount
	 */
	public Double getRevenueAmount() {
		return revenueAmount;
	}
	/**
	 * @param revenueAmount the revenueAmount to set
	 */
	public void setRevenueAmount(Double revenueAmount) {
		this.revenueAmount = revenueAmount;
	}
}
