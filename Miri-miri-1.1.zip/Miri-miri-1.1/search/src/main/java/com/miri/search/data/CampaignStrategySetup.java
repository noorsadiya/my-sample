package com.miri.search.data;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.miri.cis.utilities.DateUtilities;
import com.miri.data.jpa.domain.CampaignStrategy;

/**
 * @author supraja
 *
 */
public class CampaignStrategySetup implements Serializable {

	private static final long serialVersionUID = 4257289497868219528L;

	private String campaignName;

	private String campaignId;

	private String campaignStartDate;

	private String parentCampaignId;

	private String parentCampaignName;

	private String newParentCampaignName;

	private Double campaignCost;

	private boolean isDraft;

	private Set<String> editableFields;

	public CampaignStrategySetup() {
		this.isDraft = true;
		this.editableFields = new HashSet<>();
	}

	public CampaignStrategySetup(String campaignName, String campaignId, String campaignStartDate,
			String parentCampaignId, String parentCampaignName, String newCampaignName, double campaignCost,
			boolean isDraft, Set<String> editableFields) {
		this.campaignName = campaignName;
		this.campaignId = campaignId;
		this.campaignStartDate = campaignStartDate;
		this.parentCampaignId = parentCampaignId;
		this.parentCampaignName = parentCampaignName;
		this.newParentCampaignName = newCampaignName;
		this.campaignCost = campaignCost;
		this.isDraft = isDraft;
		this.editableFields = editableFields;
	}

	/**
	 * @return the campaignName
	 */
	public String getCampaignName() {
		return campaignName;
	}

	/**
	 * @param campaignName the campaignName to set
	 */
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	/**
	 * @return the campaignId
	 */
	public String getCampaignId() {
		return campaignId;
	}

	/**
	 * @param campaignId the campaignId to set
	 */
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	/**
	 * @return the campaignStartDate
	 */
	public String getCampaignStartDate() {
		return campaignStartDate;
	}

	/**
	 * @param campaignStartDate the campaignStartDate to set
	 */
	public void setCampaignStartDate(String campaignStartDate) {
		this.campaignStartDate = campaignStartDate;
	}

	/**
	 * @return the parentCampaignId
	 */
	public String getParentCampaignId() {
		return parentCampaignId;
	}

	/**
	 * @param parentCampaignId the parentCampaignId to set
	 */
	public void setParentCampaignId(String parentCampaignId) {
		this.parentCampaignId = parentCampaignId;
	}

	/**
	 * @return the parentCampaignName
	 */
	public String getParentCampaignName() {
		return parentCampaignName;
	}

	/**
	 * @param parentCampaignName the parentCampaignName to set
	 */
	public void setParentCampaignName(String parentCampaignName) {
		this.parentCampaignName = parentCampaignName;
	}

	/**
	 * @return the campaignCost
	 */
	public Double getCampaignCost() {
		return campaignCost;
	}

	/**
	 * @param campaignCost the campaignCost to set
	 */
	public void setCampaignCost(Double campaignCost) {
		this.campaignCost = campaignCost;
	}

	/**
	 * @return the newParentCampaignName
	 */
	public String getNewParentCampaignName() {
		return newParentCampaignName;
	}

	/**
	 * @param newParentCampaignName the newParentCampaignName to set
	 */
	public void setNewParentCampaignName(String newParentCampaignName) {
		this.newParentCampaignName = newParentCampaignName;
	}

	/**
	 * @return the isDraft
	 */
	public boolean isDraft() {
		return isDraft;
	}

	/**
	 * @param isDraft the isDraft to set
	 */
	public void setDraft(boolean isDraft) {
		this.isDraft = isDraft;
	}

	/**
	 * @return the editableFields
	 */
	public Set<String> getEditableFields() {
		return editableFields;
	}

	/**
	 * @param editableFields the editableFields to set
	 */
	public void setEditableFields(Set<String> editableFields) {
		this.editableFields = editableFields;
	}

	public void updateWithCrmCampaign(Map<String, Object> campaignData) {
		this.campaignName = (String) campaignData.get("campaignName");
		if (StringUtils.isBlank(this.campaignName)) {
			this.editableFields.add("campaignName");
		}
		this.campaignId = (String) campaignData.get("campaignId");
		if (StringUtils.isBlank(this.campaignId)) {
			this.editableFields.add("campaignId");
		}
		this.campaignStartDate = (String) campaignData.get("startDate");
		if (StringUtils.isBlank(this.campaignStartDate)) {
			this.editableFields.add("campaignStartDate");
		}
		this.parentCampaignId = (String) campaignData.get("parentCampaignId");
		if (StringUtils.isBlank(this.parentCampaignId)) {
			this.editableFields.add("parentCampaignId");
		}
		this.parentCampaignName = (String) campaignData.get("parentCampaignName");
		if (StringUtils.isBlank(this.parentCampaignName)) {
			this.editableFields.add("parentCampaignName");
		}
		this.newParentCampaignName = (String) campaignData.get("parentCampaignName");
		if (StringUtils.isBlank(this.newParentCampaignName)) {
			this.editableFields.add("newParentCampaignName");
		}
		Number actualCost = ((Number) campaignData.get("actualCost"));
		if (actualCost != null) {
			campaignCost = actualCost.doubleValue();
		}
		// cost is editable if it is null or 0
		if (actualCost == null || actualCost.doubleValue() == 0) {
			this.editableFields.add("campaignCost");
		}
		this.isDraft = true;
	}

	@SuppressWarnings("unchecked")
	public void updateWithManualCampaign(Map<String, Object> campaignData) {
		this.campaignName = (String) campaignData.get("campaignName");
		this.campaignId = (String) campaignData.get("campaignId");
		this.campaignStartDate = (String) campaignData.get("campaignStart");
		this.parentCampaignId = (String) campaignData.get("parentCampaignId");
		this.parentCampaignName = (String) campaignData.get("parentCampaignName");
		this.newParentCampaignName = (String) campaignData.get("newCampaignName");
		this.campaignCost = ((Number) campaignData.get("totalCost")).doubleValue();
		this.isDraft = Boolean.valueOf(String.valueOf(campaignData.get("draft")));
		Object editableFieldsObject = campaignData.get("editableFields");
		if (editableFieldsObject instanceof Collection) {
			this.editableFields.addAll(Collection.class.cast(editableFieldsObject));
		} else if (editableFieldsObject instanceof String) {
			this.editableFields.addAll(Arrays.asList(StringUtils.split((String)editableFieldsObject, ",")));
		}
	}

	public void updateWithManualCampaign(CampaignStrategy campaignStrategy) {
		this.campaignName = campaignStrategy.getCampaignName();
		this.campaignId = campaignStrategy.getCampaignId();
		this.campaignStartDate = DateUtilities.dateToString(campaignStrategy.getCampaignStartDate());
		this.parentCampaignId = campaignStrategy.getParentCampaignId();
		this.parentCampaignName = campaignStrategy.getParentCampaignName();
		this.newParentCampaignName = campaignStrategy.getNewCampaignName();
		this.campaignCost = campaignStrategy.getTotalCampaignCost();
		this.isDraft = campaignStrategy.isDraft();
		this.editableFields = campaignStrategy.getEditableFields();
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CampaignStrategySetup [campaignName=");
		builder.append(campaignName);
		builder.append(", campaignId=");
		builder.append(campaignId);
		builder.append(", campaignStartDate=");
		builder.append(campaignStartDate);
		builder.append(", parentCampaignId=");
		builder.append(parentCampaignId);
		builder.append(", parentCampaignName=");
		builder.append(parentCampaignName);
		builder.append(", newParentCampaignName=");
		builder.append(newParentCampaignName);
		builder.append(", campaignCost=");
		builder.append(campaignCost);
		builder.append(", isDraft=");
		builder.append(isDraft);
		builder.append(", editableFields=");
		builder.append(editableFields);
		builder.append("]");
		return builder.toString();
	}
}
