package com.miri.search.service.erp;

import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.SearchConstants;
import com.miri.search.esutils.AggregationUtil;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.TimerUtil;

/**
 * Services pertaining to erp/erp_invoice and product by account document in elastic search
 * @author noor
 *
 */

@Component
public class ProductInvoiceService extends MiriSearchService {

	Logger logger = LogManager.getLogger(ProductInvoiceService.class);
	
	@Autowired
	TimerUtil timerUtil;

	/*//TODO: This needs to be optimized by using a query and segregated into different service calls
	public Map<String, Object> getTopIndustriesByProduct(List<String> crmOpportunities) {
		Map<String, Object> topIndustriesByRevenue = new LinkedHashMap<String, Object>();
		for (CrmOpportunity opportunity : crmOpportunities) {

			SearchQuery saleOrderSearchQuery = new NativeSearchQueryBuilder()
					.withQuery(QueryBuilders.matchQuery("opportunityId.raw", opportunity.getOpportunityId()))
					.withSearchType(SearchType.QUERY_AND_FETCH).withIndices("erp").withTypes("salesOrder").build();
			List<ErpSalesOrder> erpSalesOrderList = this.elasticsearchTemplate.queryForList(saleOrderSearchQuery,
					ErpSalesOrder.class);
			for (ErpSalesOrder erpSalesOrder : erpSalesOrderList) {
				List<String> items = erpSalesOrder.getItems();
				for (String itemId : items) {
					SearchQuery orderItemQuery = new NativeSearchQueryBuilder()
							.withQuery(QueryBuilders.matchQuery("itemId.raw", itemId))
							.withSearchType(SearchType.QUERY_AND_FETCH).withIndices("erp").withTypes("orderItem")
							.build();

					List<ErpOrderItem> erpOrderItemList = this.elasticsearchTemplate.queryForList(orderItemQuery,
							ErpOrderItem.class);
					for (ErpOrderItem erpOrderItem : erpOrderItemList) {
						String productName = erpOrderItem.getItemName();
						if (topIndustriesByRevenue.containsKey(productName)) {
							topIndustriesByRevenue.put(productName,
									(Double) topIndustriesByRevenue.get(productName) + erpOrderItem.getTotalValue());
						} else {
							topIndustriesByRevenue.put(productName, erpOrderItem.getTotalValue());
						}
					}
				}
			}
		}
		return topIndustriesByRevenue;*/
	//}

	/*// Top Customers wins by revenue - by product
	public Map<String, Object> getSalesOrderListByOpportunity(List<String> mapOpportunities) {
		Map<String, Object> topCustomersByRevenue = new LinkedHashMap<String, Object>();

		for (String mapOpportunity : mapOpportunities) {

			TopHighestCustomer topHighestCustome = new TopHighestCustomer();
			SearchQuery saleOrderSearchQuery = new NativeSearchQueryBuilder()
					.withQuery(QueryBuilders.matchQuery(SearchConstants.OPPORTUNITY_ID, mapOpportunity))
					.withSearchType(SearchType.QUERY_AND_FETCH).withIndices(SearchConstants.ERP).withTypes(SearchConstants.ERP_SALES_ORDER).build();
			List<ErpSalesOrder> erpSalesOrderList = this.elasticsearchTemplate.queryForList(saleOrderSearchQuery,
					ErpSalesOrder.class);

			//get opportunity count here
			TopCustomerByProductPojo topCustomerByProduct = new TopCustomerByProductPojo();
			TopHighestCustomer topHighestCustomer = new TopHighestCustomer();
			for (ErpSalesOrder erpSalesOrder : erpSalesOrderList) {
				topHighestCustomer.setCustomerName(erpSalesOrder.getAccountName());
				List<String> items = erpSalesOrder.getItems();
				for (String itemId : items) {
					SearchQuery orderItemQuery = new NativeSearchQueryBuilder()
							.withQuery(QueryBuilders.matchQuery("itemId.raw", itemId))
							.withSearchType(SearchType.QUERY_AND_FETCH).withIndices("erp").withTypes("orderItem")
							.build();
					List<ErpOrderItem> erpOrderItemList = this.elasticsearchTemplate.queryForList(orderItemQuery,
							ErpOrderItem.class);
					logger.info("size of order items of "+erpOrderItemList.size());
					for (ErpOrderItem erpOrderItem : erpOrderItemList) {
						String productName = erpOrderItem.getItemName();
						double itemCost = erpOrderItem.getTotalValue();
						if(topCustomersByRevenue.size()<=0){
							topHighestCustome.setTotalSalesAmount(itemCost);
							topCustomerByProduct.setTopHighestCustomer(topHighestCustomer);
							topCustomerByProduct.setTotalRevenu(itemCost);
							topCustomersByRevenue.put(productName, topCustomerByProduct);
						}else if(topCustomersByRevenue.get(productName) != null){
								TopHighestCustomer topHighestcustomer = topCustomerByProduct.getTopHighestCustomer();
								if(topHighestcustomer.getTotalSalesAmount()<=itemCost){
									double revenueAmount = topCustomerByProduct.getTotalRevenu()+itemCost;
									topHighestcustomer.setTotalSalesAmount(itemCost);
									topCustomerByProduct.setTopHighestCustomer(topHighestcustomer);
									topCustomerByProduct.setTotalRevenu(revenueAmount);
								}
							}else{	
								topHighestCustome.setTotalSalesAmount(itemCost);
								topCustomerByProduct.setTopHighestCustomer(topHighestCustomer);
								topCustomerByProduct.setTotalRevenu(itemCost);
								topCustomersByRevenue.put(productName, topCustomerByProduct);
							}
						}

				}
			}
		}
		return topCustomersByRevenue;
	}	
	 */	

	/**
	 * Get the number of products sold between the start date and end date 
	 * @param startDate
	 * @param endDate
	 * @return Map<month,numofProducts>
	 */
	public  Map<Integer,Double> getProductQuantiesByMonth(List<String> opportunities,Calendar startDate,Calendar endDate){
		timerUtil.start();
		Map<Integer,String> monthAndYearMap=MiriDateUtils.getMonthsBetweenDates(startDate, endDate);
	    List<Integer> months = new LinkedList<>( monthAndYearMap.keySet());
	    
	    String minBound=MiriDateUtils.parseDateToString(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		String maxBound=MiriDateUtils.parseDateToString(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);
		
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();

		if (CollectionUtils.isNotEmpty(opportunities)) {
			boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunities));
			// rangeFilterQuery = QueryBuilders.filteredQuery(termsQuery,
			// rangeFilter);
		}

		if (StringUtils.isNotEmpty(minBound) && StringUtils.isNotEmpty(maxBound)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE).from(minBound)
					.to(maxBound).includeLower(true).includeUpper(true));
		}
		

		//Create a aggregation get the sum of product Quantity amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth=AggregationUtil.
				sumAggregation(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION, SearchConstants.ERP_INVOICE_PRODUCT_QUANTITY);


		//Create a aggregation to sort the invoices by month
		AbstractAggregationBuilder invoiceDateAggregation=AggregationBuilders.dateHistogram(SearchConstants.PRODUCT_QUANTITY_DATE_AGGREGATION)
				.field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH)
				.format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.minDocCount(0)
				.subAggregation(sumInvoiceAmountByMonth);

		SearchRequestBuilder searchRequestBuilder = getTransportClient()
				.prepareSearch(SearchConstants.ERP).setTypes(SearchConstants.ERP_INVOICE)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(invoiceDateAggregation)
				.setSearchType(SearchType.QUERY_AND_FETCH);
		SearchResponse response = searchRequestBuilder.execute().actionGet();
		timerUtil.end();
		logger.debug("getProductQuantiesByMonth ES Time Taken" + timerUtil.timeTakenInMillis());

		//this result is to get the aggregations result
		timerUtil.start();
		Map<Integer,Double> productSumByMonthMap=AggregationUtil.getDateHistogramSumAggrResult
				(response,SearchConstants.PRODUCT_QUANTITY_DATE_AGGREGATION,
						SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION,months);
		timerUtil.end();
		logger.debug("getProductQuantiesByMonth Java Time Taken"+timerUtil.timeTakenInMillis());
	
		return productSumByMonthMap;
	}
	
	/**
	 * This Method will be used to get sum of product Quantity for the opportunity Ids
	 * @param opportunityIds
	 * 		List of opportunity Id's for which we need product Quantity
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return
	 * 		Sum of all product Quantity
	 */
	public Double getSumOfProductQuanityForOpportunities(List<String> opportunityIds, String startDate, String endDate){
		Client client = getTransportClient();
		
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(!CollectionUtils.isEmpty(opportunityIds)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).from(startDate).to(endDate));
		}
		
		AbstractAggregationBuilder sumProductQuantity=AggregationUtil.
				sumAggregation(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION, SearchConstants.ERP_INVOICE_PRODUCT_QUANTITY);
		
		SearchResponse searchResponse = client.prepareSearch(SearchConstants.ERP)
				.setTypes(SearchConstants.ERP_INVOICE)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(sumProductQuantity)
				.setSize(0)
				.execute().actionGet();
		Sum sum = searchResponse.getAggregations().get(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION);
		return sum.getValue();
	}
	/**
	 * This Method will be used to get sum of product Quantity for the opportunity Ids
	 * @param opportunityIds
	 * 		List of opportunity Id's for which we need product Quantity
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return
	 * 		Sum of all product Quantity
	 */
	public Double getSumOfProductQuanityForOpportunities(List<String> opportunityIds){
		if(CollectionUtils.isNotEmpty(opportunityIds)) {
			BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
			boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
			AbstractAggregationBuilder sumProductQuantity=AggregationUtil.
					sumAggregation(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION, SearchConstants.ERP_INVOICE_PRODUCT_QUANTITY);
			
			SearchResponse searchResponse = this.getTransportClient().prepareSearch(SearchConstants.ERP)
					.setTypes(SearchConstants.ERP_INVOICE)
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
					.addAggregation(sumProductQuantity)
					.setSize(0)
					.execute().actionGet();
			Sum sum = searchResponse.getAggregations().get(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION);
			return sum.getValue();
		}
		return 0d;
		
		
	}
	
	/**
	 * This Method will be used to get sum of product Quantity for the opportunity Ids
	 * @param opportunityIds
	 * 		List of opportunity Id's for which we need product Quantity
	 * @param startDate TODO
	 * @param endDate TODO
	 * @return
	 * 		Sum of all product Quantity
	 */
	public Double getSumOfProductQuanityForOpportunitiesInBatches(List<String> opportunityIds, String startDate, String endDate){
		timerUtil.start();
		Double sum = 0.0;
		int batchSize = 1000;
		int start = 0;
		int end = batchSize;
		int outerForCount = opportunityIds.size() / batchSize; // this is like the number of iterations
		int remainingItems = opportunityIds.size() % batchSize; // This is for any remaining data after the iterations
		for(int i = 0; i < outerForCount; i++) {
			sum += (getSumOfProductQuanityForOpportunities(opportunityIds.subList(start, end),startDate, endDate)); // Here do process your entries to get the actual data required.
		    start = start + batchSize;
		    end = end + batchSize;
		}
		if(remainingItems != 0) {
		    end = end - batchSize + remainingItems;
		    sum += (getSumOfProductQuanityForOpportunities(opportunityIds.subList(start, end),startDate, endDate));		
		 }
		timerUtil.end();
		logger.debug("getSumOfProductQuanityForOpportunitiesInBatches ES"+timerUtil.timeTakenInMillis());
		return sum;
	}

	@Override
	public String getIndex() {
		return ElasticSearchEnums.ERP.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_OPPORTUNITY.getText();
	}

}
