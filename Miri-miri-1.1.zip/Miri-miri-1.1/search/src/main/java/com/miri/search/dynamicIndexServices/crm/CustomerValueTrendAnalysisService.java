package com.miri.search.dynamicIndexServices.crm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.FilterBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.children.ChildrenBuilder;
import org.elasticsearch.search.aggregations.bucket.children.InternalChildren;
import org.elasticsearch.search.aggregations.bucket.filter.Filter;
import org.elasticsearch.search.aggregations.bucket.filter.FilterAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.bucket.histogram.InternalHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Order;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ElasticSearchEnums;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.CustomerValueData;
import com.miri.search.data.MultipleAxesChartData;
import com.miri.search.data.SplineIrregularData;
import com.miri.search.data.TopProductData;
import com.miri.search.dynamicIndexServices.MappedConstants;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.map.MapCampaignService;
import com.miri.search.utils.MiriDateUtils;

@Component
@SuppressWarnings("rawtypes")
public class CustomerValueTrendAnalysisService extends MiriSearchService {
	
	@Autowired
	MapCampaignService mapCampaignService;

	@Override
	public String getIndex() {
		return ElasticSearchEnums.CRM.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.CRM_CAMPAIGN_OPPORTUNITY_MAPPED.getText();
	}

	@SuppressWarnings("unchecked")
	public SplineIrregularData getOverAllCustomerValueByMonth(String startDate, String endDate) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder
				.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate));

		SumBuilder sumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(ElasticSearchEnums.OPPORTUNITY_INVOICE_MAPPED.getText()).subAggregation(sumBuilder);

		TermsBuilder accountAggre = AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
				.field(CRMConstants.ACCOUNT_NAME_RAW).size(0);

		AbstractAggregationBuilder dateAggregation = AggregationBuilders.dateHistogram(SearchConstants.DATE_HISTOGRAM)
				.field(CRMConstants.OPPORTUNITY_CLOSED_DATE).interval(DateHistogram.Interval.MONTH)
				.format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate)
				.subAggregation(accountAggre).subAggregation(parentBuilder);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(dateAggregation);

		SearchResponse searchResponse = searchRequestBuilder.get();

		Collection<InternalHistogram.Bucket> termsBuckets = null;
		InternalChildren internalChildren = null;
		Sum sum = null;
		if (searchResponse.getAggregations() != null) {
			InternalHistogram terms = searchResponse.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
			termsBuckets = terms.getBuckets();
		}
		int count = 0;
		MultipleAxesChartData revenueData;
		List<MultipleAxesChartData> revenueDataList = new ArrayList<>();
		for (InternalHistogram.Bucket termBucket : termsBuckets) {
			revenueData = new MultipleAxesChartData();
			Terms accountTerms = termBucket.getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
			internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
			sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
			Collection<Bucket> accounts = accountTerms.getBuckets();
			revenueData.setCustomersCount(accounts.size());
			revenueData.setRevenueAmount(sum.getValue());
			double averageRevenue = (sum.getValue() / accounts.size());
			revenueData.setAverageRevenue(Double.isNaN(averageRevenue) ? 0 : averageRevenue);
			revenueData.setxAxis(count);
			revenueDataList.add(revenueData);
		}
		SplineIrregularData splineIrregularData = new SplineIrregularData();
		splineIrregularData.setRevenueData(revenueDataList);
		return splineIrregularData;
	}

	/**
	 * Gets Overall Top Industries
	 * 
	 * @param size
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Double> getTopFieldsByRevenue(int size, String startDate, String endDate, String field) {
		Map<String, Double> topFields = new HashMap<String, Double>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.hasChildFilter(MappedConstants.CRM_ERP_MAPPED,
				QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate)));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(field, ""));
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(parentSumBuilder);
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(field)
				.subAggregation(parentBuilder).size(size)
				.order(Order.aggregation(MappedConstants.CHILDREN + ">" + SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);

		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		InternalChildren internalChildren = null;
		Sum sum = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if (StringUtils.isNotBlank(termBucket.getKey())) {
				internalChildren = termBucket.getAggregations().get(MappedConstants.CHILDREN);
				sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				revenue = sum.getValue();
				if (revenue > 0) {
					topFields.put(termBucket.getKey(), revenue);
				}
			}
		}
		return topFields;
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, Map<Integer, CustomerValueData>> getCustomerLifeTimeValueDataByProduct(String startDate, String endDate,List<String> products) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).from(startDate).to(endDate));
		
		TermsBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);
		
		AbstractAggregationBuilder currentDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(CRMConstants.OPPORTUNITY_CLOSED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0)
				.extendedBounds(startDate, endDate).subAggregation(opportunityAggregation);
		
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(currentDateAggregation);

		SearchResponse searchResponse = searchRequestBuilder.get();
		InternalHistogram dateHistogram = searchResponse.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
		Collection<InternalHistogram.Bucket> dateBuckets = dateHistogram.getBuckets();
		int count = 0;
		Map<Integer, List<String>> map = new HashMap<>();
		Map<String, Map<Integer, CustomerValueData>> newMap = new HashMap<>();
		
		CustomerValueData customerValueData = null;
		for(InternalHistogram.Bucket dateBucket : dateBuckets){
			List<String> opportunities =  new ArrayList<>();
			Terms monthlyOpportunityTerms = dateBucket.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			Collection<Bucket> opportunityBuckets = monthlyOpportunityTerms.getBuckets();
			for(Bucket opportunityBucket :  opportunityBuckets){
				opportunities.add(opportunityBucket.getKey());
			}
			List<TopProductData> topProductsByOpportunities = this.getTopProductsByOpportunities(opportunities, products);
			for(TopProductData productData : topProductsByOpportunities){
				customerValueData = new CustomerValueData();
				customerValueData.setCustomersCount(getCustomerCount(productData.getOpportunities()));
				customerValueData.setRevenue(productData.getValue());
				Map<Integer, CustomerValueData> values = null;
				if(null != newMap.get(productData.getName())){
					values = newMap.get(productData.getName());
					values.put(count, customerValueData);
				}else{
					values =  new HashMap<>();
					values.put(count, customerValueData);
				}
				newMap.put(productData.getName(), values);
			}
			count++;
		}
		
		return newMap;
	}
	
	public int getCustomerCount(List<String> opportunities){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(CRMConstants.ACCOUNT_NAME_RAW)
				.size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);

		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		if(null != termsBuckets){
			return termsBuckets.size();
		}else{
			return 0;
		}
	
	}
	

	public List<SplineIrregularData> getCustomerLifeTimeValueDataByField(String startDate, String endDate,
			String previousStartDate, String previousEndDate, String field, List<String> fieldValues) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(field, fieldValues));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(field, ""));
		
		if(field.equals(CRMConstants.CRM_PARENT_CAMPAIGN_NAME_RAW)){
			List<String> marketingSubCampaigns = mapCampaignService.getMarketingSubCampaigns();
			boolFilterBuilder.must(FilterBuilders.termsFilter(CRMConstants.CAMPAIGN_PRIMARY_CAMP_SOURCE_RAW, marketingSubCampaigns));
		}

		SumBuilder sumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);
		ChildrenBuilder parentBuilder = AggregationBuilders.children(MappedConstants.CHILDREN)
				.childType(MappedConstants.CRM_ERP_MAPPED).subAggregation(sumBuilder);

		TermsBuilder accountAggre = AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION)
				.field(CRMConstants.ACCOUNT_NAME_RAW).size(0);

		
		AbstractAggregationBuilder currentDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(CRMConstants.OPPORTUNITY_CLOSED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0)
				.extendedBounds(startDate, endDate).subAggregation(accountAggre).subAggregation(parentBuilder);
		
		AbstractAggregationBuilder previousDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(CRMConstants.OPPORTUNITY_CLOSED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0)
				.extendedBounds(previousStartDate, previousEndDate).subAggregation(accountAggre).subAggregation(parentBuilder);
		
		TermsBuilder currentFieldAggregation = AggregationBuilders.terms(SearchConstants.FIELD_AGGREGATION).field(field)
				.size(0).subAggregation(currentDateAggregation);
		TermsBuilder previousFieldAggregation = AggregationBuilders.terms(SearchConstants.FIELD_AGGREGATION).field(field)
				.size(0).subAggregation(previousDateAggregation);

		FilterAggregationBuilder currentFilteredAggregation = AggregationBuilders
				.filter(MappedConstants.FILTERED_AGGREGATION)
				.filter(FilterBuilders.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(startDate).lte(endDate))
				.subAggregation(currentFieldAggregation);
		
		FilterAggregationBuilder previousFilteredAggregation = AggregationBuilders
				.filter(MappedConstants.GRAND_FILTERED_AGGREGATION).filter(FilterBuilders
						.rangeFilter(CRMConstants.OPPORTUNITY_CLOSED_DATE).gte(previousStartDate).lte(previousEndDate))
				.subAggregation(previousFieldAggregation);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(currentFilteredAggregation).addAggregation(previousFilteredAggregation);

		SearchResponse searchResponse = searchRequestBuilder.get();
		Filter currentTerms = searchResponse.getAggregations().get(MappedConstants.FILTERED_AGGREGATION);
		Filter previousTerms = searchResponse.getAggregations().get(MappedConstants.GRAND_FILTERED_AGGREGATION);
		Terms terms = currentTerms.getAggregations().get(SearchConstants.FIELD_AGGREGATION);
		List<Bucket> termsBuckets = terms.getBuckets();
		Map<String, Object> fieldData = new HashMap<>();
		for (Terms.Bucket termBucket : termsBuckets) {
			Map<Integer, CustomerValueData> customerValueData = this.getDataByMonth(termBucket);
			fieldData.put(termBucket.getKey(), customerValueData);
		}
		
		return this.getCurrentData(previousTerms, fieldData, field);
	}
	
	public Map<Integer, CustomerValueData> getDataByMonth(Bucket termBucket){
		InternalHistogram dateHistogram = termBucket.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
		Collection<InternalHistogram.Bucket> dateBuckets = dateHistogram.getBuckets();
		int count = 0;
		CustomerValueData customerValueData;
		Map<Integer, CustomerValueData> monthWiseRevenueAndAccountName = new HashMap<>();
		for (InternalHistogram.Bucket dateBucket : dateBuckets) {
			customerValueData = new CustomerValueData();
			Terms accountTerms = dateBucket.getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
			List<Bucket> accountBuckets = accountTerms.getBuckets();
			InternalChildren internalChildren  = dateBucket.getAggregations().get(MappedConstants.CHILDREN);
			Sum sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
			customerValueData.setCustomersCount(accountBuckets.size());
			customerValueData.setRevenue(sum.getValue());
			monthWiseRevenueAndAccountName.put(count++, customerValueData);
		}
		return monthWiseRevenueAndAccountName;
	}

	public List<SplineIrregularData> getCurrentData(Filter currentTerms, Map<String, Object> fieldData, String field) {
		
		Terms terms = currentTerms.getAggregations().get(SearchConstants.FIELD_AGGREGATION);
		List<Bucket> termsBuckets = terms.getBuckets();
		SplineIrregularData splineData;
		List<SplineIrregularData> customerLifeTimeTrendData = new ArrayList<>();
		CustomerValueData customerValueData;
		for (Terms.Bucket termBucket : termsBuckets) {
			int count = 0;
			splineData = new SplineIrregularData();
			InternalHistogram dateHistogram = termBucket.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
			Collection<InternalHistogram.Bucket> dateBuckets = dateHistogram.getBuckets();
			Map<Integer, CustomerValueData> monthWiseRevenueAndAccountName = new HashMap<>();
			for (InternalHistogram.Bucket dateBucket : dateBuckets) {
				customerValueData = new CustomerValueData();
				Terms accountTerms = dateBucket.getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
				List<Bucket> accountBuckets = accountTerms.getBuckets();
				InternalChildren internalChildren  = dateBucket.getAggregations().get(MappedConstants.CHILDREN);
				Sum sum = internalChildren.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				customerValueData.setCustomersCount(accountBuckets.size());
				customerValueData.setRevenue(sum.getValue());
				monthWiseRevenueAndAccountName.put(count++, customerValueData);
			}
			Map<Integer, CustomerValueData> map = (Map<Integer, CustomerValueData>) fieldData.get(termBucket.getKey());
			List<MultipleAxesChartData> revenueDataList = this.getCustomerValueData(field, termBucket.getKey(), map, monthWiseRevenueAndAccountName);
			splineData.setName(termBucket.getKey());
			splineData.setRevenueData(revenueDataList);
			customerLifeTimeTrendData.add(splineData);
		}
		return customerLifeTimeTrendData;
				
	}

	

	private List<MultipleAxesChartData> getCustomerValueData(final String field, final String fieldName,
			Map<Integer, CustomerValueData> customerValueData,
			Map<Integer, CustomerValueData> previousFYCustomerValueData) {
		MultipleAxesChartData revenueData;
		List<MultipleAxesChartData> revenueDataList = new ArrayList<>();
		for (Map.Entry<Integer, CustomerValueData> customerValueDataEntry : customerValueData.entrySet()) {
			revenueData = new MultipleAxesChartData();
			revenueData.setCustomersCount(customerValueDataEntry.getValue().getCustomersCount());
			revenueData.setRevenueAmount(customerValueDataEntry.getValue().getRevenue());
			double averageRevenue = 0;
			if (customerValueDataEntry.getValue().getCustomersCount() > 0) {
				averageRevenue = customerValueDataEntry.getValue().getRevenue()
						/ customerValueDataEntry.getValue().getCustomersCount();
			}
			double previousFyAverageRevenue = 0;
			if (previousFYCustomerValueData.get(customerValueDataEntry.getKey()).getCustomersCount() > 0) {
				previousFyAverageRevenue = previousFYCustomerValueData.get(customerValueDataEntry.getKey()).getRevenue()
						/ previousFYCustomerValueData.get(customerValueDataEntry.getKey()).getCustomersCount();
			}
			revenueData.setAverageRevenue(Double.isNaN(averageRevenue) ? 0 : averageRevenue);
			revenueData.setxAxis(customerValueDataEntry.getKey());
			if(fieldName.equalsIgnoreCase(CRMConstants.CAMPAIGN_NAME)){
				revenueData.setCampaignName(fieldName);
			}
			if(fieldName.equalsIgnoreCase(CRMConstants.COMPETITOR_RAW)){
				revenueData.setCompetitor(fieldName);
			}
			if(fieldName.equalsIgnoreCase(CRMConstants.OPPORTUNITY_OWNER_RAW)){
				revenueData.setSalesPerson(fieldName);
			}
			if(fieldName.equalsIgnoreCase(CRMConstants.PRODUCT)){
				revenueData.setProductName(fieldName);
			}
			if(fieldName.equalsIgnoreCase(CRMConstants.ACCOUNT_INDUSTRY_RAW)){
				revenueData.setIndustry(fieldName);
			}
			if(fieldName.equalsIgnoreCase(CRMConstants.OPPORTUNITY_COUNTRY_RAW)){
				revenueData.setCountry(fieldName);
			}
			revenueData.setPreviousFyAvgRevenue(Double.isNaN(previousFyAverageRevenue) ? 0 : previousFyAverageRevenue);
			revenueDataList.add(revenueData);
		}
		return revenueDataList;
	}
	
	
	public List<MultipleAxesChartData> getCustomerValueDataForProduct(Map<Integer, CustomerValueData> customerValueData,
			Map<Integer, CustomerValueData> previousFYCustomerValueData, String productName) {
		MultipleAxesChartData revenueData;
		List<MultipleAxesChartData> revenueDataList = new ArrayList<>();
		for (Map.Entry<Integer, CustomerValueData> customerValueDataEntry : customerValueData.entrySet()) {
			revenueData = new MultipleAxesChartData();
			revenueData.setCustomersCount(customerValueDataEntry.getValue().getCustomersCount());
			revenueData.setRevenueAmount(customerValueDataEntry.getValue().getRevenue());
			double averageRevenue = 0;
			if (customerValueDataEntry.getValue().getCustomersCount() > 0) {
				averageRevenue = customerValueDataEntry.getValue().getRevenue()
						/ customerValueDataEntry.getValue().getCustomersCount();
			}
			double previousFyAverageRevenue = 0;
			if(null !=  previousFYCustomerValueData && null != previousFYCustomerValueData.get(customerValueDataEntry.getKey())){
				if (previousFYCustomerValueData.get(customerValueDataEntry.getKey()).getCustomersCount() > 0) {
					previousFyAverageRevenue = previousFYCustomerValueData.get(customerValueDataEntry.getKey()).getRevenue()
							/ previousFYCustomerValueData.get(customerValueDataEntry.getKey()).getCustomersCount();
				}
			}
			revenueData.setAverageRevenue(Double.isNaN(averageRevenue) ? 0 : averageRevenue);
			revenueData.setxAxis(customerValueDataEntry.getKey());
			revenueData.setProductName(productName);
			revenueData.setPreviousFyAvgRevenue(Double.isNaN(previousFyAverageRevenue) ? 0 : previousFyAverageRevenue);
			revenueDataList.add(revenueData);
		}
		return revenueDataList;
	}
	
	public List<TopProductData> getTopProductsByOpportunities(List<String> opportunities,  List<String> topProducts) {
		List<TopProductData> topProuctsList = new ArrayList<TopProductData>();
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, ""));
		boolFilterBuilder.mustNot(FilterBuilders.termFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, "NULL"));
		boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.PRODUCT_LEVEL_THREE_RAW, topProducts));
		if (CollectionUtils.isNotEmpty(opportunities)) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));

		}
		SumBuilder parentSumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_ITEM_AMOUNT);

		TermsBuilder opportunityAggregation = AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);

		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.INDUSTRY_AGGREGATION)
				.field(ERPConstants.PRODUCT_LEVEL_THREE_RAW).subAggregation(parentSumBuilder)
				.size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS).subAggregation(opportunityAggregation)
				.order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.CRM.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOCE_INVOICE_ITEM_MAPPED.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder)).setSize(0)
				.addAggregation(aggregationBuilders);

		SearchResponse searchResponse = searchRequestBuilder.get();
		Collection<Terms.Bucket> termsBuckets = null;
		Sum sum = null;
		double revenue = 0;
		if (searchResponse.getAggregations() != null) {
			Terms terms = searchResponse.getAggregations().get(SearchConstants.INDUSTRY_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}
		for (Terms.Bucket termBucket : termsBuckets) {
			if (StringUtils.isNotBlank(termBucket.getKey())) {
				sum = termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				revenue = sum.getValue();
				if (revenue > 0) {
					List<String> proOpportunities = new ArrayList<>();
					Terms opportunityTerms = termBucket.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
					Collection<Bucket> opportunityBuckets = opportunityTerms.getBuckets();
					for(Bucket oppo :  opportunityBuckets){
						proOpportunities.add(oppo.getKey());
					}
					topProuctsList.add(constructProductObject(proOpportunities, termBucket.getKey(), revenue));
				}
			}
		}
		return topProuctsList;
	}
	
	private TopProductData constructProductObject(List<String> opportunities, String name, double revenue) {
		TopProductData topProductData = new TopProductData();
		topProductData.setName(name);
		topProductData.setValue(revenue);
		topProductData.setOpportunities(opportunities);
		return topProductData;
	}

	
	
}
