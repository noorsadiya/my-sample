package com.miri.search.service.erp;

import static com.miri.search.utils.MiriDateUtils.parseDateToString;
import static com.miri.search.utils.MiriDateUtils.parseStringToDate;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.map.ListOrderedMap;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.elasticsearch.action.count.CountRequestBuilder;
import org.elasticsearch.action.count.CountResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolFilterBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.bucket.histogram.InternalHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.StringTerms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Order;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.elasticsearch.search.aggregations.metrics.avg.InternalAvg;
import org.elasticsearch.search.aggregations.metrics.min.MinBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.InternalSum;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHitsBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.miri.cis.base.ESObjectMapper;
import com.miri.cis.base.ElasticSearchEnums;
import com.miri.cis.base.ElasticsearchConfig;
import com.miri.cis.base.VendorTypeEnum;
import com.miri.cis.entity.CrmOpportunity;
import com.miri.cis.entity.ESEntity;
import com.miri.cis.entity.ErpInvoice;
import com.miri.search.constants.CRMConstants;
import com.miri.search.constants.ERPConstants;
import com.miri.search.constants.SearchConstants;
import com.miri.search.data.CustomerValueData;
import com.miri.search.data.FilterData;
import com.miri.search.data.InvoiceDataPojo;
import com.miri.search.data.InvoiceItemData;
import com.miri.search.data.InvoiceStatsData;
import com.miri.search.data.RevenueOpportunitiesData;
import com.miri.search.data.TopProductsDataPojo;
import com.miri.search.data.TopSalesPersonData;
import com.miri.search.esutils.AggregationUtil;
import com.miri.search.esutils.ESQueryUtils;
import com.miri.search.esutils.MiriSearchUtils;
import com.miri.search.service.common.MiriSearchService;
import com.miri.search.service.crm.CRMOpportunityProductService;
import com.miri.search.service.crm.CRMProductService;
import com.miri.search.utils.MiriDateUtils;
import com.miri.search.utils.TimerUtil;

/**
 * Services pertaining to erp/erp_invoice document in elastic search
 *
 * @author noor
 *
 */
@Component
public class ERPInvoiceService extends MiriSearchService {

	private final static Logger LOG = LogManager.getLogger(ERPInvoiceService.class);

	private static final String GROUPNAME_TOTALSALESAMOUNT = "totalSalesAmount";
	//private static final String GROUPNAME_TOTALPRODUCTS = "totalProducts";
	private static final String GROUPNAME_GROUPEDACCOUNTS = "groupedAccounts";
	
	/*private static final String ERP_TEMP_INDEX = "erptemp";
	private static final String ERP_ALL_INVOICE_DOC_TYPE = "erp_all_invoice";*/

	
	@Autowired
	private ESQueryUtils esQueryUtils;

	@Autowired
	private ElasticsearchConfig elasticsearchConfig;

	@Autowired
	private TimerUtil timeUtil;

	@Autowired
	private ERPOpportunityCompetitorService erpOpportunityCompetitorService;

	@Autowired
	private CRMOpportunityProductService crmOpportunityProductService;
	
	@Autowired
	private ERPInvoiceItemService erpInvoiceItemService;
	
	@Autowired
	private CRMProductService crmProductService;

	/**
	 * Get Invoice Amount by Opportunity Id
	 *
	 * @param opportunityId
	 * @return
	 */
	public double getInvoiceAmountByOpportunityId(String opportunityId) {
		// LOG.info("get invoice amount by opportunity Id");
		timeUtil.start();
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.termsQuery(SearchConstants.OPPORTUNITY_ID_RAW, opportunityId))
				.addAggregation(AggregationBuilders.sum(SearchConstants.INVOICE_AMOUNT_AGGREGATION)
						.field(SearchConstants.SALES_AMOUNT));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		timeUtil.end();
		return AggregationUtil.getAggregationValue(searchResponse, SearchConstants.INVOICE_AMOUNT_AGGREGATION,
				SearchConstants.SUM_AGGREGATION_TYPE);
	}

	/**
	 * Returns ERP invoice by opportunity id.
	 *
	 * @param opportunityId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, ErpInvoice> getInvoicesAsMapByOpportunityId(final String opportunityId) {
		LOG.debug("Get ERP invoice by opportunity Id");
		List<ESEntity> esEntities = esQueryUtils.getMultipleDocsByFKId(getDocumentType(), getIndex(),
				SearchConstants.OPPORTUNITY_ID_RAW, opportunityId);
		Map<String, ErpInvoice> erpInvoiceMap = new ListOrderedMap();
		ErpInvoice erpInvoice = null;
		for (ESEntity esEntity : esEntities) {
			erpInvoice = (ErpInvoice) esEntity;
			erpInvoiceMap.put(erpInvoice.getInvoiceId(), erpInvoice);
		}
		return erpInvoiceMap;
	}

	/**
	 * Returns ERP invoice by opportunity id.
	 *
	 * @param opportunityId
	 * @return
	 */
	public List<ErpInvoice> getInvoicesByOptyAndSOId(final String opportunityId, final String salesOrderId) {
		LOG.debug("Get ERP invoice by opportunity Id");
		BoolQueryBuilder boolQueryBuilder = new BoolQueryBuilder();
		boolQueryBuilder.must(QueryBuilders.termQuery("opportunityId.raw", opportunityId));
		boolQueryBuilder.must(QueryBuilders.termQuery("saleOrderId.raw", salesOrderId));

		SearchResponse searchResponse = elasticsearchConfig.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setQuery(boolQueryBuilder).execute().actionGet();
		SearchHits searchHits = searchResponse.getHits();
		Iterator<SearchHit> iterator = searchHits.iterator();
		List<ErpInvoice> erpInvoices = new ArrayList<>();
		while (iterator.hasNext()) {
			SearchHit searchHit = iterator.next();
			erpInvoices
			.add((ErpInvoice) ESObjectMapper.getObject(searchHit.getSource(), getDocumentType(), getIndex()));
		}

		return erpInvoices;

	}
	
	/**
	 * Returns ERP invoice by opportunity id.
	 *
	 * @param opportunityId
	 * @return
	 */
	public List<ErpInvoice> getInvoicesBySOId(final String salesOrderId) {
		// LOG.debug("Get ERP invoice by sales order Id");
		BoolQueryBuilder boolQueryBuilder = new BoolQueryBuilder();
		boolQueryBuilder.must(QueryBuilders.termQuery("saleOrderId.raw", salesOrderId));

		SearchResponse searchResponse = elasticsearchConfig.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setQuery(boolQueryBuilder).execute().actionGet();
		SearchHits searchHits = searchResponse.getHits();
		Iterator<SearchHit> iterator = searchHits.iterator();
		List<ErpInvoice> erpInvoices = new ArrayList<>();
		while (iterator.hasNext()) {
			SearchHit searchHit = iterator.next();
			erpInvoices
			.add((ErpInvoice) ESObjectMapper.getObject(searchHit.getSource(), getDocumentType(), getIndex()));
		}

		return erpInvoices;

	}

	/**
	 * Returns the Sum of invoice amount for each opportunity
	 *
	 * @return
	 */
	public Map<String, Double> getInvoiceAmountSumByOpportunity() {
		Map<String, Double> invoiceByOpportunityMap = new HashMap<String, Double>();

		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder termAggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(SearchConstants.OPPORTUNITY_ID_RAW).size(0).subAggregation(sumInvoiceAmountByMonth);

		SearchResponse response = getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText()).addAggregation(termAggr)
				.execute().actionGet();

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> buckets = terms.getBuckets();

		LOG.debug("buckets size:" + buckets.size());
		for (Terms.Bucket bucket : buckets) {
			Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			invoiceByOpportunityMap.put(bucket.getKeyAsText().toString(), sum.getValue());
		}

		// LOG.debug("getInvoiceAmountSumByOpportunity:-"+invoiceByOpportunityMap);
		return invoiceByOpportunityMap;
	}

	/**
	 * Returns the Sum of invoice amount for each opportunity
	 *
	 * @return
	 */
	public Map<String, Double> getInvoiceAmountSumByOpportunities(List<String> opportunities) {
		Map<String, Double> invoiceByOpportunityMap = new HashMap<String, Double>();

		TermsQueryBuilder OpptysTerm = QueryBuilders.termsQuery("opportunityId.raw", opportunities);

		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder termAggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(SearchConstants.OPPORTUNITY_ID_RAW).size(0).subAggregation(sumInvoiceAmountByMonth);

		SearchResponse response = getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText()).setQuery(OpptysTerm).addAggregation(termAggr)
				.execute().actionGet();

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> buckets = terms.getBuckets();
		LOG.debug("buckets size:" + buckets.size());
		for (Terms.Bucket bucket : buckets) {
			Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			invoiceByOpportunityMap.put(bucket.getKeyAsText().toString(), sum.getValue());
		}

		// LOG.debug("getInvoiceAmountSumByOpportunity:-"+invoiceByOpportunityMap);
		return invoiceByOpportunityMap;
	}

	/**
	 * Gets the Sum of all the opportunities
	 *
	 * @param opportunities
	 * @return
	 */
	public Double getInvoiceSumForOpportunites(List<String> opportunities) {
		timeUtil.start();
		if (opportunities.size() <= 0) {
			return 0.0;
		}
		Client client = getTransportClient();
		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		BoolQueryBuilder termsQuery = MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW,
				opportunities, SearchConstants.BATCH_SIZE_1000);

		SearchResponse response = client.prepareSearch(ElasticSearchEnums.ERP.getText()).setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(termsQuery).addAggregation(sumInvoiceAmountByMonth)
				.setSize(0).execute().actionGet();

		Sum sum = (Sum) response.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
		timeUtil.end();
		//LOG.debug("getInvoiceSumForOpportunites ES"+timeUtil.timeTakenInMillis());
		return sum.getValue();
	}

	/**
	 * MarketingSpendRoiMetric
	 *
	 * @param opportunityIds
	 * @param startDate
	 *            TODO
	 * @param endDate
	 *            TODO
	 * @return
	 */
	public Double getInvoiceAmountByOpportunityIds(List<String> opportunityIds, String startDate, String endDate) {
		timeUtil.start();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		}
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(AggregationBuilders.sum(SearchConstants.INVOICE_AMOUNT_AGGREGATION).field(SearchConstants.SALES_AMOUNT));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		if(searchResponse.getAggregations() != null) {
			Sum sumAggregation = searchResponse.getAggregations().get(SearchConstants.INVOICE_AMOUNT_AGGREGATION);
			if (sumAggregation != null) {
				return sumAggregation.getValue();
			}
		}
		timeUtil.end();
		return 0d;
	}

	/**
	 * Get Invoice Amount by Opportunityids and sales person
	 * @param opportunityIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Double getInvoiceAmountByOpportunityIdsAndSalesPerson(List<String> opportunityIds, String startDate, String endDate, String salesPerson) {
		timeUtil.start();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		}
		boolFilter.must(FilterBuilders.termFilter(ERPConstants.INVOICE_SALES_PERSON_RAW, salesPerson));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(AggregationBuilders.sum(SearchConstants.INVOICE_AMOUNT_AGGREGATION).field(SearchConstants.SALES_AMOUNT));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		if(searchResponse.getAggregations() != null) {
			Sum sumAggregation = searchResponse.getAggregations().get(SearchConstants.INVOICE_AMOUNT_AGGREGATION);
			if (sumAggregation != null) {
				return sumAggregation.getValue();
			}
		}

		timeUtil.end();
		return 0d;
	}

	/**
	 *
	 * @param oppIds
	 * @return
	 */
	public Map<String, Object> getAccountNamesByOpportunityId(List<String> oppIds) {

		Map<String, Object> accountNamesMap = new HashMap<String, Object>();

		Client client = getTransportClient();

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();

		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, oppIds));

		// QueryBuilder queryBuilder =
		// QueryBuilders.termsQuery(SearchConstants.OPPORTUNITY_ID_RAW, oppIds);
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setScroll(new TimeValue(6000)).setSize(2000).setSearchType(SearchType.SCAN)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		while (true) {
			for (SearchHit searchHit : searchResponse.getHits().getHits()) {
				Map<String, Object> result = searchHit.getSource();

				String opportunity = (String) result.get(SearchConstants.OPPORTUNITY_ID);
				String accountName = (String) result.get(SearchConstants.ACCOUNT_NAME);
				accountNamesMap.put(opportunity, accountName);

			}
			searchResponse = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000)).get();
			if (searchResponse.getHits().getHits().length == 0) {
				break;
			}
		}

		// LOG.debug("Account Names By OpportunitId:"+accountNamesMap);
		return accountNamesMap;

	}

	/**
	 * Get Invoice sum for the provided Opportunity ID.
	 *
	 */
	public double getInvoiceSumByOpportunityId(String optId) {

		List<String> list = new ArrayList<String>();

		list.add(optId);

		return getInvoiceSumByOpportunityIds(list).get(optId);
	}

	/**
	 * Gets the invoice sum for the provides Opportunity IDs
	 *
	 * @param List
	 *            - Opportunities ids
	 * @return Map - Key -> Opportunity id & Value -> Invoices sum.
	 */
	public Map<String, Double> getInvoiceSumByOpportunityIds(List<String> list) {


		Map<String, Double> invoiceMap = new HashMap<String, Double>();

		// Terms Query
		QueryBuilder queryBuilder = QueryBuilders.termsQuery(SearchConstants.OPPORTUNITY_ID_RAW, list);

		// Terms Aggregation
		TermsBuilder termBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(SearchConstants.OPPORTUNITY_ID_RAW);

		// Sum Aggregation
		SumBuilder sumBuilder = AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);

		SearchResponse response = getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText()).setQuery(queryBuilder)
				.addAggregation(termBuilder.subAggregation(sumBuilder)).execute().actionGet();

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> termsBuckets = terms.getBuckets();

		for (Terms.Bucket termBucket : termsBuckets) {
			InternalSum internalSum = (InternalSum) termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
			invoiceMap.put(termBucket.getKey(), Double.valueOf(internalSum.getValue()));
		}

		// LOG.debug("Invoice sum for Opportunities" + invoiceMap);

		return invoiceMap;
	}

	/**
	 * Get Average Sell price By Month with in start and end dates
	 *
	 * @param startDate
	 * @param endDate
	 */
	public Map<Integer, Double> getAvgSellPriceByMonth(Calendar startDate, Calendar endDate) {
		SearchResponse searchResponse = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.addAggregation(AggregationBuilders.dateHistogram(SearchConstants.DATE_HISTOGRAM)
						.field(SearchConstants.CREATED_DATE).interval(DateHistogram.Interval.MONTH)
						.extendedBounds(parseDateToString(startDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD),
								parseDateToString(endDate, MiriDateUtils.DATE_FORMAT_YYYY_MM_DD))
						.format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
						.subAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION)
								.field(SearchConstants.SALES_AMOUNT))
						.subAggregation(AggregationBuilders.sum(SearchConstants.QUANTITY_AGGREGATION)
								.field(SearchConstants.PRODUCT_QUANTITY)))
				.execute().actionGet();

		InternalHistogram<org.elasticsearch.search.aggregations.bucket.histogram.InternalHistogram.Bucket> dateHisto = searchResponse.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
		Collection<InternalHistogram.Bucket> buckets = dateHisto.getBuckets();
		Map<Integer, Double> aspByMonth = new LinkedHashMap<>();

		double asp;
		DecimalFormat df = new DecimalFormat("#.00");
		Calendar cal = Calendar.getInstance();
		for (InternalHistogram.Bucket bucket : buckets) {
			cal.setTime(parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD, bucket.getKeyAsText().toString()));
			int month = cal.get(Calendar.MONTH);
			Sum salesAmoountSum = bucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
			Sum quantitiySum = bucket.getAggregations().get(SearchConstants.QUANTITY_AGGREGATION);
			asp = Double.valueOf(df.format(salesAmoountSum.getValue() / quantitiySum.getValue()));
			aspByMonth.put(month, asp);
		}

		// LOG.debug(aspByMonth);
		return aspByMonth;
	}

	/**
	 * Gets the invoices sum by Opportunity ID.
	 *
	 * @param opportunityIds
	 * @return Map - Key - Opportunity ID. Value - List of Maps (Key- Month,
	 *         Value-invoice Sum)
	 */
	public Map<String, Object> getInvoiceSumByOpportunityId(List<String> opportunityIds) {

		Map<String, Object> invoiceSumByMonthMap = new HashMap<String, Object>();

		SearchResponse response = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.termsQuery(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds))
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.addAggregation(AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
						.field(SearchConstants.OPPORTUNITY_ID_RAW).size(0)
						.subAggregation(AggregationBuilders.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION)
								.field(SearchConstants.CREATED_DATE).interval(DateHistogram.Interval.MONTH)
								.format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
								.subAggregation(AggregationBuilders.sum(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH)
										.field(ERPConstants.INVOICE_SALES_AMOUNT))))
				.execute().actionGet();

		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> termsBuckets = terms.getBuckets();

		for (Terms.Bucket termBucket : termsBuckets) {

			String opportunityId = termBucket.getKey();
			List<Map<Integer, Double>> list = new ArrayList<Map<Integer, Double>>();

			InternalHistogram<InternalHistogram.Bucket> datehist = termBucket.getAggregations()
					.get(SearchConstants.INVOICE_DATE_AGGEGATION);
			Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();

			for (InternalHistogram.Bucket bucket : buckets) {

				Map<Integer, Double> resultsMap = new HashMap<Integer, Double>();

				int month = MiriDateUtils.getMonth(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
						bucket.getKeyAsText().toString()));
				Sum sum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
				resultsMap.put(month, sum.getValue());

				list.add(resultsMap);
			}
			invoiceSumByMonthMap.put(opportunityId, list);
		}

		return invoiceSumByMonthMap;
	}

	/**
	 * Gets the invoices sum by Opportunity ID.
	 *
	 * @param opportunityIds
	 * @param startDate
	 * @param endDate
	 * @return Map - Key - Month in Integer format. Value - List of Maps (Key-
	 *         opportunity, Value-invoice Sum)
	 */
	public Map<Integer, Object> getInvoiceSumByMonth(List<String> opportunityIds, String startDate, String endDate) {

		Map<Integer, Object> invoiceSumByMonthMap = new LinkedHashMap<Integer, Object>();

		BoolQueryBuilder boolQueryBuilder = MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW,
				opportunityIds, 1000);
		boolQueryBuilder.must(QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));

		SearchResponse response = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(boolQueryBuilder).setSearchType(SearchType.QUERY_AND_FETCH)
				.addAggregation(AggregationBuilders.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION)
						.field(ERPConstants.INVOICE_CREATED_DATE).interval(DateHistogram.Interval.MONTH)
						.format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
						.subAggregation(AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
								.field(SearchConstants.OPPORTUNITY_ID_RAW).size(0)
								.subAggregation(AggregationBuilders.sum(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH)
										.field(ERPConstants.INVOICE_SALES_AMOUNT))))
				.execute().actionGet();

		InternalHistogram<InternalHistogram.Bucket> datehist = response.getAggregations()
				.get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();

		for (InternalHistogram.Bucket bucket : buckets) {

			int month = MiriDateUtils.getMonth(MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					bucket.getKeyAsText().toString()));

			Terms terms = bucket.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			Collection<Terms.Bucket> termsBuckets = terms.getBuckets();

			Map<Object, Double> resultsMap = new HashMap<Object, Double>();

			for (Terms.Bucket termBucket : termsBuckets) {

				String opportunityId = termBucket.getKey();

				Sum sum = (Sum) termBucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);

				resultsMap.put(opportunityId, sum.getValue());
			}

			invoiceSumByMonthMap.put(month, resultsMap);

		}

		return invoiceSumByMonthMap;
	}

	@Override
	public String getIndex() {
		return ElasticSearchEnums.ERP.getText();
	}

	@Override
	public String getDocumentType() {
		return ElasticSearchEnums.ERP_INVOICE.getText();
	}

	/**
	 * @param endDate
	 *            TODO
	 * @param startDate
	 *            TODO
	 * @return Invoices from fiscal start date to current date
	 */
	public List<ErpInvoice> getInvoicesWithInFiscal(String startDate, String endDate) {

		timeUtil.start();
		Client client = getTransportClient();

		List<ErpInvoice> erpInvoices = new ArrayList<ErpInvoice>();

		SearchResponse invoiceSearch = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSearchType(SearchType.SCAN).setScroll(new TimeValue(6000))
				.setQuery(QueryBuilders.rangeQuery(SearchConstants.CREATED_DATE).from(startDate).to(endDate)).execute()
				.actionGet();

		do {
			for (SearchHit hit : invoiceSearch.getHits().getHits()) {

				ErpInvoice erpInvoice = (ErpInvoice) ESObjectMapper.getObject(hit.getSource(),
						ElasticSearchEnums.ERP_INVOICE.getText(), VendorTypeEnum.ERP.getText());

				if (erpInvoice != null) {
					erpInvoices.add(erpInvoice);
				}
			}
			invoiceSearch = client.prepareSearchScroll(invoiceSearch.getScrollId()).setScroll(new TimeValue(60000))
					.execute().actionGet();

		} while (invoiceSearch.getHits().getHits().length != 0);

		timeUtil.end();

		LOG.debug("getInvoicesWithInFiscal ES"+timeUtil.timeTakenInMillis());
		// LOG.debug("Fisical Year("+fiscalStartDate+" to "+currentDate+")...:
		// No of ERP Invoices "+erpInvoices.size());
		// LOG.debug("ERP Invoices....."+erpInvoices);
		return erpInvoices;
	}

	/**
	 * Average Sell Price by opportunity ids
	 *
	 * @param opportunityIds
	 * @return
	 */
	public Double averageSellPriceByOpportunities(List<String> opportunityIds) {
		DecimalFormat df = new DecimalFormat("#.00");
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText()).setSearchType(SearchType.QUERY_AND_FETCH).setSize(0)
				.setQuery(QueryBuilders.termsQuery(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds))
				.addAggregation(
						AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(SearchConstants.SALES_AMOUNT))
				.addAggregation(AggregationBuilders.sum(SearchConstants.QUANTITY_AGGREGATION)
						.field(SearchConstants.PRODUCT_QUANTITY));
		SearchResponse searchResponse = searchRequestBuilder.execute().actionGet();
		Aggregations aggregations = searchResponse.getAggregations();

		Sum invoiceAmountAggregation = aggregations.get(SearchConstants.SUM_AGGREGATION);
		Sum productQuantityAggregation = aggregations.get(SearchConstants.QUANTITY_AGGREGATION);
		double avgSellPrice = invoiceAmountAggregation.getValue() / productQuantityAggregation.getValue();
		return Double.isNaN(avgSellPrice) ? 0 : Double.valueOf(df.format(avgSellPrice));
	}

	/**
	 * Get all the invoices by opportunities
	 *
	 * @param crmOpportunities
	 * @return
	 */
	public List<Object> getInvoicesByOpportunities(List<CrmOpportunity> crmOpportunities) {
		List<String> opportunityIds = new ArrayList<>();
		for (CrmOpportunity crmOpportunity : crmOpportunities) {
			opportunityIds.add(crmOpportunity.getOpportunityId());
		}
		List<ErpInvoice> erpInvoices = this.getInvoicesByOpportunitiesInBatches(opportunityIds);
		double invoiceAmount = this.getInvoiceAmountByOpportunityIds(opportunityIds, null, null);
		List<Object> invoicesAndAmount = new ArrayList<>();
		invoicesAndAmount.add(erpInvoices);
		invoicesAndAmount.add(invoiceAmount);
		return invoicesAndAmount;
	}

	/**
	 * Get all the invoices by Opportunity Ids
	 * @param opportunityIds
	 * @return
	 */
	public List<ErpInvoice> getInvoicesByOpportunityIds(List<String> opportunityIds) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSize(opportunityIds.size());

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<ErpInvoice> erpInvoices = new ArrayList<>();
		SearchHits invoiceHits = searchResponse.getHits();
		if (invoiceHits != null) {
			for (SearchHit invoiceHit : invoiceHits.getHits()) {
				erpInvoices.add(
						(ErpInvoice) ESObjectMapper.getObject(invoiceHit.getSource(), getDocumentType(), getIndex()));
			}
		}
		return erpInvoices;
	}

	/**
	 * Get Invoice Ids for opportunity Ids
	 * @param opportunityIds
	 * @return
	 */
	public List<String> getInvoiceIdsByOpportunityIds(List<String> opportunityIds) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSize(opportunityIds.size());

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> erpInvoiceIds = new ArrayList<>();
		SearchHits invoiceHits = searchResponse.getHits();
		if (invoiceHits != null) {
			for (SearchHit invoiceHit : invoiceHits.getHits()) {
				erpInvoiceIds.add(invoiceHit.getSource().get(ERPConstants.INVOICE_ID).toString());
			}
		}
		return erpInvoiceIds;
	}


	/**
	 * Process Opportunities in batches to get Invoices.
	 *
	 * @param opportunityIds
	 * @return
	 */
	public List<ErpInvoice> getInvoicesByOpportunitiesInBatches(List<String> opportunityIds) {
		if (!CollectionUtils.isEmpty(opportunityIds)) {
			List<ErpInvoice> erpInvoices = new ArrayList<>();
			int batchSize = 1000;
			int start = 0;
			int end = batchSize;
			int outerForCount = opportunityIds.size() / batchSize; // this is
			// like the
			// number of
			// iterations
			int remainingItems = opportunityIds.size() % batchSize; // This is
			// for any
			// remaining
			// data
			// after the
			// iterations
			for (int i = 0; i < outerForCount; i++) {
				erpInvoices.addAll(this.getInvoicesByOpportunityIds(opportunityIds.subList(start, end)));
				start = start + batchSize;
				end = end + batchSize;
			}
			if (remainingItems != 0) {
				end = end - batchSize + remainingItems;
				erpInvoices.addAll(this.getInvoicesByOpportunityIds(opportunityIds.subList(start, end)));
			}
			return erpInvoices;
		} else {
			return null;
		}
	}

	/**
	 * Get Invoices and revenue amount by sales person
	 *
	 * @param salesPersonName
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<Object> getInvoicesBySalesPerson(String salesPersonName, String startDate, String endDate) {
		Client client = this.getTransportClient();
		SearchResponse scrollResponse = client.prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.termQuery(SearchConstants.SALES_OWNER_RAW, salesPersonName))
				.setPostFilter(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).gte(startDate).lte(endDate))
				.get();
		List<ErpInvoice> erpInvoices = new ArrayList<>();
		List<String> opportunityIds = new ArrayList<>();
		while (true) {
			for (SearchHit hit : scrollResponse.getHits().getHits()) {
				erpInvoices.add((ErpInvoice) ESObjectMapper.getObject(hit.getSource(), getDocumentType(), getIndex()));
				opportunityIds.add(hit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			scrollResponse = client.prepareSearchScroll(scrollResponse.getScrollId()).setScroll(new TimeValue(60000))
					.execute().actionGet();
			// Break condition: No hits are returned
			if (scrollResponse.getHits().getHits().length == 0) {
				break;
			}
		}
		double invoiceAmount = this.getInvoiceAmountByOpportunityIds(opportunityIds, null, null);
		List<Object> invoiceAmountAndSum = new ArrayList<>();
		invoiceAmountAndSum.add(erpInvoices);
		invoiceAmountAndSum.add(invoiceAmount);
		return invoiceAmountAndSum;
	}

	/**
	 * Process In
	 *
	 * @param invoiceIds
	 * @return
	 */
	public double getAvgInvoiceCreationDate(List<String> invoiceIds) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termFilter(ERPConstants.INVOICE_ID_RAW, invoiceIds));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(SearchConstants.CREATED_DATE));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		return AggregationUtil.getAggregationValue(searchResponse, SearchConstants.SUM_AGGREGATION,
				SearchConstants.SUM_AGGREGATION_TYPE);
	}

	/**
	 * Get Invoice Amount, Count and Average Creation Date
	 * @param opportunityIds
	 * @return
	 */
	public InvoiceStatsData getAvgInvoiceCreationDateAndAmountByOpportunities(List<String> opportunityIds) {
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.INVOICE_OPPORTUNITY_ID_RAW, opportunityIds));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.setSize(0)
				.addAggregation(AggregationBuilders.sum(SearchConstants.AMOUNT_AGGREGATION).field(SearchConstants.SALES_AMOUNT))
				.addAggregation(AggregationBuilders.avg(SearchConstants.AVG_AGGREGATION).field(SearchConstants.CREATED_DATE))
				.addAggregation(AggregationBuilders.sum(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION).field(ERPConstants.INVOICE_PRODUCT_QUANTITY));
		//LOG.info("Average Invoice Creation date :" + searchRequestBuilder);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		InvoiceStatsData invoiceAmountAndCreationDate = new InvoiceStatsData();
		invoiceAmountAndCreationDate.setRevenueAmount(AggregationUtil.getAggregationValue(searchResponse, SearchConstants.AMOUNT_AGGREGATION,
				SearchConstants.SUM_AGGREGATION_TYPE));
		invoiceAmountAndCreationDate.setAvgCreationTme(((Double) AggregationUtil.getAggregationValue(searchResponse, SearchConstants.AVG_AGGREGATION,
				SearchConstants.AVG_AGGREGATION_TYPE)).longValue());
		invoiceAmountAndCreationDate.setCount(searchResponse.getHits().getTotalHits());
		invoiceAmountAndCreationDate.setProductQuantity(AggregationUtil.getAggregationValue(searchResponse, SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION,
				SearchConstants.SUM_AGGREGATION_TYPE));
		return invoiceAmountAndCreationDate;
	}
	
	/**
	 * Get Invoice Amount, Count and Average Creation Date
	 * @param opportunityIds
	 * @return
	 */
	public InvoiceStatsData getAvgInvoiceCreationDateAndAmountByOpportunitiesDateAndSalesPerson(List<String> opportunityIds,String startDate,
			String endDate,String salesPerson) {
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE).gte(startDate).lte(endDate));
		}

		if(StringUtils.isNotBlank(salesPerson)) {
			boolFilter.must(FilterBuilders.termFilter(ERPConstants.INVOICE_SALES_PERSON_RAW, salesPerson));
		}

		if(CollectionUtils.isNotEmpty(opportunityIds)) {
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		}
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSize(0)
				.addAggregation(AggregationBuilders.sum(SearchConstants.AMOUNT_AGGREGATION).field(SearchConstants.SALES_AMOUNT))
				.addAggregation(AggregationBuilders.avg(SearchConstants.AVG_AGGREGATION).field(SearchConstants.CREATED_DATE))
				.addAggregation(AggregationBuilders.sum(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION).field(ERPConstants.INVOICE_PRODUCT_QUANTITY));
		
		if (boolFilter.toString().contains("must")) {
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
		}
		
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		InvoiceStatsData invoiceAmountAndCreationDate = new InvoiceStatsData();
		invoiceAmountAndCreationDate.setRevenueAmount(AggregationUtil.getAggregationValue(searchResponse, SearchConstants.AMOUNT_AGGREGATION,
				SearchConstants.SUM_AGGREGATION_TYPE));
		invoiceAmountAndCreationDate.setAvgCreationTme(((Double) AggregationUtil.getAggregationValue(searchResponse, SearchConstants.AVG_AGGREGATION,
				SearchConstants.AVG_AGGREGATION_TYPE)).longValue());
		invoiceAmountAndCreationDate.setCount(searchResponse.getHits().getTotalHits());
		invoiceAmountAndCreationDate.setProductQuantity(AggregationUtil.getAggregationValue(searchResponse, SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION,
				SearchConstants.SUM_AGGREGATION_TYPE));
		return invoiceAmountAndCreationDate;
	}


	/**
	 * Get Average Invoice Creation Date for objects
	 * @return
	 */
	public double getAvgInvoiceDate(List<ErpInvoice> erpInvoices) {
		if (!CollectionUtils.isEmpty(erpInvoices)) {
			List<String> invoiceIds = new ArrayList<>();
			for (ErpInvoice erpInvoice : erpInvoices) {
				invoiceIds.add(erpInvoice.getInvoiceId());
			}
			return getAvgInvoiceCreationDate(invoiceIds);
		} else {
			return 0;
		}
	}

	/**
	 * Get the number of invoices by Opportunity
	 *
	 * @param opportunityIds
	 * @return
	 */
	public int getInvoiceCountByOpportunities(List<String> opportunityIds) {
		BoolQueryBuilder boolQueryBuilder = new BoolQueryBuilder();
		boolQueryBuilder.must(QueryBuilders.termQuery("opportunityId.raw", opportunityIds));

		SearchResponse searchResponse = elasticsearchConfig.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType()).setQuery(boolQueryBuilder).execute().actionGet();

		SearchHits searchHits = searchResponse.getHits();

		return (int) searchHits.getTotalHits();
	}

	/*
	 * Get the total product quantity from invoice by opportunity ids
	 *
	 * @param opportunityIds
	 *
	 * @return
	 */
	public double getTotalProdQuantity(List<String> opportunityIds) {
		SearchResponse searchResponse = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText()).setSearchType(SearchType.QUERY_THEN_FETCH)
				.setQuery(QueryBuilders.termsQuery(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds))
				.addAggregation(AggregationBuilders.sum(SearchConstants.ERP_INVOICE_PRODUCT_QUANTITY)
						.field(SearchConstants.PRODUCT_QUANTITY))
				.execute().actionGet();

		Sum sumAggregation = searchResponse.getAggregations().get(SearchConstants.ERP_INVOICE_PRODUCT_QUANTITY);

		if (null != sumAggregation) {
			return sumAggregation.getValue();
		} else {
			return 0d;
		}
	}

	public Map<String, List<String>> getOpportunitesAndSalesPerson(List<String> opportunties, String startDate,
			String endDate) {
		Client client = getTransportClient();

		Map<String, List<String>> wonOptys = new HashMap<>();

		BoolQueryBuilder termsQuery = MiriSearchUtils.createBoolQueryBuilder(SearchConstants.OPPORTUNITY_ID_RAW,
				opportunties, 1000);
		termsQuery.must(QueryBuilders.rangeQuery(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));

		TopHitsBuilder tophits = AggregationBuilders.topHits(SearchConstants.TOTAL_HITS_AGGR).setSize(3000)
				.setFetchSource(SearchConstants.OPPORTUNITY_ID, null).setSize(3000);

		TermsBuilder aggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(SearchConstants.SALES_PERSON_RAW).size(0).subAggregation(tophits);

		SearchResponse opportunityRespose = client.prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_OPPORTUNITY.getText()).setSearchType(SearchType.QUERY_AND_FETCH)
				.setQuery(termsQuery).setSize(10000).addAggregation(aggr).execute().actionGet();

		Terms aggTerms = opportunityRespose.getAggregations().get(SearchConstants.TERMS_AGGREGATION);

		for (Bucket bucket : aggTerms.getBuckets()) {
			List<String> opportunitesListForIndustry = new ArrayList<>();
			TopHits topHitsAggr = bucket.getAggregations().get(SearchConstants.TOTAL_HITS_AGGR);
			SearchHit[] opportunityHits = topHitsAggr.getHits().getHits();
			for (SearchHit searchhit : opportunityHits) {
				opportunitesListForIndustry.add(searchhit.getSource().get(SearchConstants.OPPORTUNITY_ID).toString());
			}
			wonOptys.put(bucket.getKeyAsText().string(), opportunitesListForIndustry);

		}
		// LOG.debug("getOpportunitesAndIndustry" + wonOptys);
		return wonOptys;
	}
	
	
	/**
	 * Average Invoice Creation Time for opportunities
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<Integer, Double> getAverageInvoiceCreationTimeForOpportunities(List<String> opportunities, String startDate, String endDate){
		timeUtil.start();
		AbstractAggregationBuilder aggregation = AggregationBuilders
				.dateHistogram(SearchConstants.OPPORTUNITY_AGGREGATION).field(ERPConstants.INVOICE_CREATED_DATE)
				.extendedBounds(startDate, endDate)
				.minDocCount(0)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.subAggregation(AggregationBuilders.avg(SearchConstants.AVG_AGGREGATION).field(ERPConstants.INVOICE_CREATED_DATE));
		BoolFilterBuilder boolFilter=FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));
		boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).gt(startDate).lt(endDate));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(aggregation)
				.setSize(0);
		SearchResponse searchResponse = searchRequestBuilder.get();
		InternalHistogram<org.elasticsearch.search.aggregations.bucket.histogram.InternalHistogram.Bucket> datehist = searchResponse.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		Map<Integer, Double> mapForListofDateForMon = MiriSearchUtils.populateMonthsEmptyDoubleData();
		for (InternalHistogram.Bucket bucket : buckets) {
			InternalAvg sum = (InternalAvg) bucket.getAggregations().get(SearchConstants.AVG_AGGREGATION);
			double millis = sum.getValue();
			Date createddate = MiriDateUtils.parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD,
					bucket.getKey());
			int month= MiriDateUtils.getMonth(createddate);
			mapForListofDateForMon.put(month, millis);
		}
		timeUtil.end();
		LOG.debug("ES time getAverageInvoiceCreationTimeForOpportunities"+timeUtil.timeTakenInMillis());
		return mapForListofDateForMon;
	}

	/**
	 * Get Invoice Ids with in date range
	 * @param fiscalStartDateStr
	 * @param fiscalEndDateStr
	 * @return
	 */
	public List<String> getInvoiceIdByDateRange(String startDate, String endDate) {
		Client client = this.getTransportClient();
		SearchRequestBuilder searchRequestBuilder = client.prepareSearch(getIndex())
				.setTypes(getDocumentType()).setSearchType(SearchType.SCAN).setSize(600).setScroll(new TimeValue(6000))
				.setFetchSource(ERPConstants.INVOICE_ID, null)
				.setPostFilter(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		List<String> invoiceIds = new ArrayList<>();
		do {
			for(SearchHit hit: searchResponse.getHits()) {
				invoiceIds.add(hit.getSource().get(ERPConstants.INVOICE_ID).toString());
			}
			SearchScrollRequestBuilder searchScrollRequest = client.prepareSearchScroll(searchResponse.getScrollId()).setScroll(new TimeValue(6000));
			searchResponse = esQueryUtils.execute(searchScrollRequest);
		} while(searchResponse.getHits().getHits().length != 0);

		return invoiceIds;
    }

	/**
	 * Gets the revenue of a customer within timeFrame for the opportunities
	 * @param accountName
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public double getRevenueByAccountNameAndOpportunities(String accountName, List<String> opportunities, String startDate, String endDate){

		AbstractAggregationBuilder sumAggreagtion=AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT);

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();

		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}

		boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE).from(startDate).to(endDate));
		boolFilter.must(FilterBuilders.termFilter(SearchConstants.ACCOUNT_NAME_RAW, accountName));

		SearchResponse response = getTransportClient()
				.prepareSearch(ElasticSearchEnums.ERP.getText()).setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(sumAggreagtion)
				.setSearchType(SearchType.QUERY_AND_FETCH)
				.execute().actionGet();

		Sum sum = response.getAggregations().get(SearchConstants.SUM_AGGREGATION);
		return sum.getValue();
	}

	/**
	 * Get Deals Closed by Account Name and Opportunities
	 * @param accountName
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public long getDealsClosedByAccountNameAndOpportunities(String accountName, List<String> opportunities, String startDate, String endDate){
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.from(startDate)
				.to(endDate));
		boolFilter.must(FilterBuilders.termFilter(SearchConstants.ACCOUNT_NAME_RAW, accountName));

		TermsBuilder aggregation = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);

		SearchRequestBuilder revenueSearchBuilder = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(aggregation).setSize(0);
		SearchResponse revenueSearchResponse =esQueryUtils.execute(revenueSearchBuilder);
		Terms aggr= revenueSearchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);

		return aggr.getBuckets().size();
	}

	/**
	 * Gets the List of Invoice Items from opportunities
	 * @param opportunityIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<String> getInvoiceItemsByOpportunities(List<String> opportunityIds, final String startDate, final String endDate){

		BoolFilterBuilder boolFilter = getBoolFilterBuilder(opportunityIds, startDate, endDate);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(1000);

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		List<String> invoiceItemIds = new ArrayList<>();

		while (true) {
			for (SearchHit hit : response.getHits()) {
				invoiceItemIds.addAll((List<String>)hit.getSource().get(ERPConstants.INVOICE_ITEMS));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(60000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}
		return invoiceItemIds;
	}

	/**
	 * Gets the Products and Revenue of the Invoive Items
	 * @param invoiceItems
	 * @return
	 */
	public List<TopProductsDataPojo> getProductsFromTheInvoices(List<String> invoiceItems, List<String> productNames){
		// LOG.info("invoice items :" + invoiceItems.size());
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(ERPConstants.PRODUCT_NAME_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS).order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false))
				.subAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(SearchConstants.AMOUNT))
				.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_HITS_AGGREGATION).setFetchSource(ERPConstants.PRODUCT_ID, null).setSize(1));

		BoolFilterBuilder boolFilter = null;
		if(CollectionUtils.isNotEmpty(invoiceItems)) {
			boolFilter = FilterBuilders.boolFilter();
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.INVOICE_ITEM_ID_RAW, invoiceItems));
		}
		
		if(CollectionUtils.isNotEmpty(productNames)) {
			if(boolFilter == null) {
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.PRODUCT_NAME_RAW, productNames));
		}
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(ElasticSearchEnums.ERP_INVOICE_ITEM.getText())
				.addAggregation(aggregationBuilders);
			

		if(null != boolFilter) {
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
		}

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		
		Collection<Terms.Bucket> termsBuckets  = null;
		if(response.getAggregations() != null){
			Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}

		TopProductsDataPojo topProductsDataPojo = null;
		List<TopProductsDataPojo> topProductsDataPojos = new ArrayList<>();

		for (Terms.Bucket termBucket : termsBuckets) {
			topProductsDataPojo = new TopProductsDataPojo();
			String productName = termBucket.getKey();
			if(StringUtils.isNotEmpty(productName)){
				Sum sum = termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				TopHits topHits = termBucket.getAggregations().get(SearchConstants.TOP_HITS_AGGREGATION);
				topProductsDataPojo.setRevenueAmount(sum.getValue());
				topProductsDataPojo.setProductName(productName);
				topProductsDataPojo.setProductId((String) topHits.getHits().getAt(0).getSource().get(ERPConstants.PRODUCT_ID));
				topProductsDataPojos.add(topProductsDataPojo);
				//LOG.info("Product Name :" + productName + " Revenue Amount :" + sum.getValue());
			}
		}
		return topProductsDataPojos;
	}
	
	/**
	 * Get Top Product Codes from Invoice
	 * @param invoiceItems
	 * @param productNames
	 * @return
	 */
	public List<TopProductsDataPojo> getProductCodesFromInvoices(List<String> invoiceItems, List<String> productNames){
		// LOG.info("invoice items :" + invoiceItems.size());
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(ERPConstants.PRODUCT_ID_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS).order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false))
				.subAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(SearchConstants.AMOUNT))
				.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_HITS_AGGREGATION).setFetchSource(ERPConstants.PRODUCT_ID, null).setSize(1));

		BoolFilterBuilder boolFilter = null;
		if(CollectionUtils.isNotEmpty(invoiceItems)) {
			boolFilter = FilterBuilders.boolFilter();
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.INVOICE_ITEM_ID_RAW, invoiceItems));
		}
		
		if(CollectionUtils.isNotEmpty(productNames)) {
			if(boolFilter == null) {
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.PRODUCT_ID_RAW, productNames));
		}
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(ElasticSearchEnums.ERP_INVOICE_ITEM.getText())
				.setSize(0)
				.addAggregation(aggregationBuilders);
			

		if(null != boolFilter) {
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
		}

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		
		Collection<Terms.Bucket> termsBuckets  = null;
		if(response.getAggregations() != null){
			Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}

		TopProductsDataPojo topProductsDataPojo = null;
		List<TopProductsDataPojo> topProductsDataPojos = new ArrayList<>();

		for (Terms.Bucket termBucket : termsBuckets) {
			topProductsDataPojo = new TopProductsDataPojo();
			String productName = termBucket.getKey();
			if(StringUtils.isNotEmpty(productName)){
				Sum sum = termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				TopHits topHits = termBucket.getAggregations().get(SearchConstants.TOP_HITS_AGGREGATION);
				topProductsDataPojo.setRevenueAmount(sum.getValue());
				topProductsDataPojo.setProductName(productName);
				topProductsDataPojo.setProductId((String) topHits.getHits().getAt(0).getSource().get(ERPConstants.PRODUCT_ID));
				topProductsDataPojos.add(topProductsDataPojo);
				//LOG.info("Product Name :" + productName + " Revenue Amount :" + sum.getValue());
			}
		}
		return topProductsDataPojos;
	}

	/**
	 * Gets the Products and there revenue by the opportunities
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<TopProductsDataPojo> getTopProductsFromTheOpportunitieswithInTimeFrame(List<String> opportunities, String startDate, String endDate){
		List<String> invoiceItems = this.getInvoiceItemsByOpportunities(opportunities, startDate, endDate);
		// Passing productNames as null to get all the product information
		return this.getProductsFromTheInvoices(invoiceItems, null);
	}
	
	/**
	 * Gets the Products and there revenue by the opportunities
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @param productNames
	 * @return
	 */
	public List<TopProductsDataPojo> getTopProductsFromTheOpportunitieswithInTimeFrame(List<String> opportunities, String startDate, String endDate, List<String> productNames){
		List<String> invoiceItems = this.getInvoiceItemsByOpportunities(opportunities, startDate, endDate);
		return this.getProductsFromTheInvoices(invoiceItems, productNames);
	}
	
	/**
	 * Gets the Products Codes and their revenue by the opportunities
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<TopProductsDataPojo> getTopProductCodesFromTheOpportunitieswithInTimeFrame(List<String> opportunities, String startDate, String endDate){
		List<String> invoiceItems = this.getInvoiceItemsByOpportunities(opportunities, startDate, endDate);
		// Passing productCodes as null to get all the product information
		return this.getProductCodesFromInvoices(invoiceItems, null);
	}
	
	/**
	 * Gets the Products Codes and there revenue by the opportunities
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @param productCodes
	 * @return
	 */
	public List<TopProductsDataPojo> getTopProductCodesFromTheOpportunitieswithInTimeFrame(List<String> opportunities, String startDate, String endDate, List<String> productCodes){
		List<String> invoiceItems = this.getInvoiceItemsByOpportunities(opportunities, startDate, endDate);
		return this.getProductCodesFromInvoices(invoiceItems, productCodes);
	}

	/**
	 * Gets the Products and there revenue by the opportunities
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @return,
	 */
	public TopProductsDataPojo getTopProductFromTheOpportunitieswithInTimeFrame(List<String> opportunities, String startDate, String endDate, List<String> productNames){
		List<String> invoiceItems = this.getInvoiceItemsByOpportunities(opportunities, startDate, endDate);
		List<TopProductsDataPojo> topProducts = this.getProductsFromTheInvoices(invoiceItems, productNames);
		if(topProducts.get(0) != null){
			return topProducts.get(0);
		}
		return null;
	}

	/**
	 * Gets the Top Products and Revenue With In the Time Frame
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<TopProductsDataPojo> getTopProductswithInTimeFrame(String startDate, String endDate) {
		List<String> invoiceItems = this.getInvoiceItemsByOpportunities(null, startDate, endDate);
		// Passing productNames as null to get all the product information 
		return this.getProductsFromTheInvoices(invoiceItems, null);
	}
	
	/**
	 * Gets the Top Products and Revenue With In the Time Frame
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<TopProductsDataPojo> getTopProductswithInTimeFrame(String startDate, String endDate, List<String> productNames) {
		List<String> invoiceItems = this.getInvoiceItemsByOpportunities(null, startDate, endDate);
		return this.getProductsFromTheInvoices(invoiceItems, productNames);
	}
	
	/**
	 * Gets the Top Product Codes and Revenue With In the Time Frame
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<TopProductsDataPojo> getTopProductCodeswithInTimeFrame(String startDate, String endDate) {
		List<String> invoiceItems = this.getInvoiceItemsByOpportunities(null, startDate, endDate);
		// Passing productCodes as null to get all the product information 
		return this.getProductsFromTheInvoices(invoiceItems, null);
	}

	/**
	 * Gets the Top Product Codes and Revenue With In the Time Frame
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<TopProductsDataPojo> getTopProductsCodeWithInTimeFrame(String startDate, String endDate, List<String> productNames) {
		List<String> invoiceItems = this.getInvoiceItemsByOpportunities(null, startDate, endDate);
		return this.getProductCodesFromInvoices(invoiceItems, productNames);
	}
	
	/**
	 * Get Top Solution Level Combos in Time Frame 
	 * @param startDate
	 * @param endDate
	 */
	public Map<String, InvoiceItemData> getTopProductCombosWithInTimeFrame(String startDate, String endDate) {
		// Passing null value to check all the opportunities with in the fiscal dates
		return this.getTopProductCombosWithInTimeFrame(null, startDate, endDate);
	}
	
	/**
	 * 
	 * @param opportunityIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, InvoiceItemData> getTopProductCombosWithInTimeFrame(List<String> opportunityIds, final String startDate, final String endDate) {
		// Passing null value to check all the opportunities with in the fiscal dates
		Map<String, InvoiceItemData> invoiceItemIdsByOpportunities = this.getInvoiceItemsByOpportunityId(opportunityIds, startDate, endDate);
		Collection<String> productCodes;
		String solutionCombo;
		Map<String, InvoiceItemData> solComboData = new HashMap<>();
		InvoiceItemData invoiceItemData;
		for(Map.Entry<String, InvoiceItemData> invoiceItemIdsEntry: invoiceItemIdsByOpportunities.entrySet()) {
			invoiceItemData = new InvoiceItemData();
			productCodes = this.erpInvoiceItemService.getProductCodesByInvoiceItemIds(invoiceItemIdsEntry.getValue().getItemIds());
			// Find the solution level combo
			solutionCombo = this.crmProductService.getSolutionLevelCombo(productCodes);
			updateSolutionComboMap(productCodes, solutionCombo, solComboData, invoiceItemData, invoiceItemIdsEntry);
		}
		/*for(String sol: solutionLevelCombo) {
			LOG.info(sol);
		}*/
		//LOG.info("solution Level Combos :" + solutionLevelCombo);
		return solComboData;
	}

	/**
	 * @param productNames
	 * @param solutionCombo
	 * @param solComboData
	 * @param invoiceItemData
	 * @param invoiceItemIdsEntry
	 */
	private void updateSolutionComboMap(Collection<String> productNames, final String solutionCombo,
			Map<String, InvoiceItemData> solComboData, InvoiceItemData invoiceItemData, final
			Map.Entry<String, InvoiceItemData> invoiceItemIdsEntry) {
		if(StringUtils.isNotBlank(solutionCombo)) {
			if(solComboData.containsKey(solutionCombo)) {
				InvoiceItemData existingInvoiceItemData = solComboData.get(solutionCombo);
				existingInvoiceItemData.getItemIds().addAll(invoiceItemIdsEntry.getValue().getItemIds());
				existingInvoiceItemData.getProductNames().addAll(productNames);
				existingInvoiceItemData.setSalesAmount(existingInvoiceItemData.getSalesAmount() + invoiceItemIdsEntry.getValue().getSalesAmount());
			} else {
				invoiceItemData.setItemIds(invoiceItemIdsEntry.getValue().getItemIds());
				invoiceItemData.setProductNames(productNames);
				invoiceItemData.setSalesAmount(invoiceItemIdsEntry.getValue().getSalesAmount());
				solComboData.put(solutionCombo, invoiceItemData);
			}
		}
	}
	
	/**
	 * Get Invoice Items segregated by Opportunity Ids
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, InvoiceItemData> getInvoiceItemsByOpportunityId(final List<String> opportunityIds, final String startDate, final String endDate) {
		BoolFilterBuilder boolFilter = getBoolFilterBuilder(opportunityIds, startDate, endDate);
		
		SearchRequestBuilder searchRequestBuilder = getInvoiceItemsByOppQuery(boolFilter);
		
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		
		long topHitsSize = getTopHitsSizeFromSearchResponse(searchResponse, SearchConstants.OPPORTUNITY_AGGREGATION);
		
		searchRequestBuilder = getInvoiceItemIdByOppQueryWithTopHits(boolFilter, topHitsSize);

		searchResponse = esQueryUtils.execute(searchRequestBuilder);
		return this.getInvoiceItemIdsByOppFromSearchResponse(searchResponse);
	}

	/**
	 * Get Invoice Item Ids by Opportunity Query with Top Hits Aggregations
	 * @param boolFilter
	 * @param topHitsSize
	 * @return
	 */
	private SearchRequestBuilder getInvoiceItemIdByOppQueryWithTopHits(BoolFilterBuilder boolFilter,
			long topHitsSize) {
		return this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
						.field(ERPConstants.OPPORTUNITY_ID_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS)
						.subAggregation(AggregationBuilders.topHits(SearchConstants.TOP_HITS_AGGREGATION).setSize((int)topHitsSize))
						.subAggregation(AggregationBuilders.sum(SearchConstants.AMOUNT_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT)));
	}

	/**
	 * Get Invoice Item Ids by opportunity from search response
	 * @param searchResponse
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Map<String, InvoiceItemData> getInvoiceItemIdsByOppFromSearchResponse(SearchResponse searchResponse) {
		Aggregations oppAggregations = searchResponse.getAggregations();
		Terms oppTerms = oppAggregations.get(SearchConstants.OPPORTUNITY_AGGREGATION);
		List<Terms.Bucket> oppBuckets = oppTerms.getBuckets();
		Map<String, InvoiceItemData> invoiceItemIdsByOpp = new HashMap<>();
		List<String> invoiceItemIds;
		InvoiceItemData invoiceItemData;
		for(Terms.Bucket oppBucket: oppBuckets) {
			invoiceItemIds = new ArrayList<>();
			Aggregations bucketAggregation = oppBucket.getAggregations();
			TopHits invoiceTopHits = bucketAggregation.get(SearchConstants.TOP_HITS_AGGREGATION);
			for (SearchHit hit : invoiceTopHits.getHits()) {
				invoiceItemIds.addAll((List<String>)hit.getSource().get(ERPConstants.INVOICE_ITEMS));
			}
			invoiceItemData = new InvoiceItemData();
			invoiceItemData.setItemIds(invoiceItemIds);
			invoiceItemData.setSalesAmount(AggregationUtil.getSumAggregationValueFromBucket(oppBucket, SearchConstants.AMOUNT_AGGREGATION));
			invoiceItemIdsByOpp.put(oppBucket.getKey(), invoiceItemData);
		}
		return invoiceItemIdsByOpp;
	}

	/**
	 * Get Invoice Items by Opportunity Ids Query
	 * @param boolFilter
	 * @return
	 */
	private SearchRequestBuilder getInvoiceItemsByOppQuery(BoolFilterBuilder boolFilter) {
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION)
						.field(ERPConstants.OPPORTUNITY_ID_RAW).size(SearchConstants.UNLIMITED_AGGREGATION_ITEMS));
		return searchRequestBuilder;
	}

	/**
	 * Get Bool Filter builder for filter conditions
	 * @param opportunityIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	private BoolFilterBuilder getBoolFilterBuilder(final List<String> opportunityIds, final String startDate,
			final String endDate) {
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(opportunityIds)) {
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(startDate)
					.to(endDate));
		}
		return boolFilter;
	}

	/**
	 * Get Top Hits size from aggregation
	 * @param opportunityAggregation
	 */
	private long getTopHitsSizeFromSearchResponse(final SearchResponse searchResponse, final String aggregationName) {
		long topHitsSize = 10;
		Aggregations opportunityAggregation = searchResponse.getAggregations();
		if(opportunityAggregation != null) {
			Terms opportunityTerms = opportunityAggregation.get(aggregationName);
			List<Terms.Bucket> opportunityBuckets = opportunityTerms.getBuckets();
			for(Terms.Bucket oppBucket: opportunityBuckets) {
				topHitsSize = oppBucket.getDocCount();
				break;
			}
		}
		return topHitsSize;
	}
	
	/**
	 * Get Document count for the fields not empty
	 * @param field
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public long getDocumentCountForFieldNotEmpty(String field, String startDate, String endDate){
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(StringUtils.isNotEmpty(startDate) && StringUtils.isNotEmpty(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(startDate)
					.to(endDate));
		}

		boolFilter.mustNot(FilterBuilders.termFilter(field, ""));

		CountRequestBuilder countRequestBuilder = this.getTransportClient().prepareCount(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
		return countRequestBuilder.get().getCount();
	}

	/**
	 * Gets the Top sales Person with in time frame and opportunities
	 * @param startDate
	 * @param endDate
	 * @param opportunities
	 * @param size
	 * @return
	 */
	public List<TopSalesPersonData> getTopSalesPersonsWithInFiscal(List<String> opportunities, int size, String startDate, String endDate) {
		BoolFilterBuilder boolFilter = null;
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter = FilterBuilders.boolFilter();
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(startDate)
					.to(endDate));
		}
		if(CollectionUtils.isNotEmpty(opportunities)) {
			if(null == boolFilter){
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));
		}

		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(ERPConstants.INVOICE_SALES_PERSON_RAW).size(0).order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false))
				.subAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT));

		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(aggregationBuilders.subAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION).field(CRMConstants.OPPORTUNITY_ID_RAW)
						.size(0)));

		SearchResponse searchResponse =  esQueryUtils.execute(searchRequestBuilder);
		Collection<Terms.Bucket> termsBuckets = null;
		if(searchResponse.getAggregations() != null){
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}

		TopSalesPersonData topSalesPersonData = null;
		List<TopSalesPersonData> topSalesPersonDatas = new ArrayList<>();
		List<String> salesPersonopportunities = null;
		for (Terms.Bucket termBucket : termsBuckets) {
			salesPersonopportunities = new ArrayList<>();
			Collection<Terms.Bucket> opportunityBuckets = null;
			if(size != 0 && topSalesPersonDatas.size() >= size){
				break;
			}
			topSalesPersonData = new TopSalesPersonData();
			if(null != termBucket.getAggregations()){
				Terms opportunityTerms = termBucket.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
				opportunityBuckets = opportunityTerms.getBuckets();
			}
			for (Terms.Bucket oppBucket : opportunityBuckets) {
				salesPersonopportunities.add(oppBucket.getKey());
			}
			String salesPerson = termBucket.getKey();
			if(StringUtils.isNotEmpty(salesPerson)) {
				Sum sum = termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
				topSalesPersonData.setRevenueAmount(sum.getValue());
				topSalesPersonData.setSalesPerson(salesPerson);
				topSalesPersonData.setOpportunities(salesPersonopportunities);
				topSalesPersonDatas.add(topSalesPersonData);
			}
		}

		return topSalesPersonDatas;
	}
	
	/**
	 * Gets the Top sales Person with in time frame and opportunities
	 * @param startDate
	 * @param endDate
	 * @param opportunities
	 * @param size
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<TopSalesPersonData> getMonthWiseTopSalesPersonsWithInFiscal(String fiscalStartDate, String fiscalEdDate, List<String> opportunities, int size, String maxBound, String minBound){
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(StringUtils.isNotEmpty(fiscalStartDate) && StringUtils.isNotEmpty(fiscalEdDate)){
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(fiscalStartDate)
					.to(fiscalEdDate));
		}
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));
		}

		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder totalAfggre = AggregationUtil
				.sumAggregation("totalSumAggregation", ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder invoiceDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(maxBound, minBound).minDocCount(0).subAggregation(sumInvoiceAmountByMonth);


		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(ERPConstants.INVOICE_SALES_PERSON_RAW).size(0).order(Order.aggregation("totalSumAggregation", false))
				.subAggregation(invoiceDateAggregation)
				.subAggregation(totalAfggre);

		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(aggregationBuilders);

		SearchResponse searchResponse = searchRequestBuilder.get();

		Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		Collection<Terms.Bucket> termsBuckets = terms.getBuckets();

		TopSalesPersonData topSalesPersonData = null;
		List<TopSalesPersonData> topSalesPersonDatas = new ArrayList<>();

		for (Terms.Bucket termBucket : termsBuckets) {
			topSalesPersonData = new TopSalesPersonData();
			String salesPerson = termBucket.getKey();
			if(StringUtils.isNotEmpty(salesPerson)){
				Sum sum = termBucket.getAggregations().get("totalSumAggregation");
				topSalesPersonData.setSalesPerson(salesPerson);
				topSalesPersonData.setRevenueAmount(sum.getValue());
				InternalHistogram datehist = termBucket.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
				Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
				Map<Integer, Double> resultsMap = new LinkedHashMap<>();
				int count = 0;
				for (InternalHistogram.Bucket bucket : buckets) {
					Sum monthSum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
					resultsMap.put(count,monthSum.getValue());
					count++;
				}
				topSalesPersonData.setMonthWiseRevenue(resultsMap);
			}
			topSalesPersonDatas.add(topSalesPersonData);
		}

		return topSalesPersonDatas;
	}

	/**
	 * Gets the Month wise Revenue of a sales person
	 * @param opportunities
	 * @param salesPerson
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<Integer, Double> getMonthWiseRevenueForSalesPerson(List<String> opportunities, String salesPerson, String startDate, String endDate){
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(startDate)
					.to(endDate));
		}
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		if(StringUtils.isNotBlank(salesPerson)){
			boolFilter.must(FilterBuilders.termFilter(ERPConstants.INVOICE_SALES_PERSON_RAW, salesPerson));

		}
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);

		AbstractAggregationBuilder invoiceDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(startDate, endDate).minDocCount(0).subAggregation(sumInvoiceAmountByMonth);

		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(invoiceDateAggregation);

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		Map<Integer, Double> resultsMap = new LinkedHashMap<>();
		int count = 0;
		for (InternalHistogram.Bucket bucket : buckets) {
			Sum monthSum = (Sum) bucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
			resultsMap.put(count,monthSum.getValue());
			count++;
		}

		return resultsMap;
	}

	/**
	 *  Gets the all the Sales persons, Opportunities, Revenue with in provided timeframe
	 *
	 * @param startDate
	 * @param endDate
	 *
	 * @return List of Sales person data contains sales person name,no of opportunities, revenue.
	 */
	public List<TopSalesPersonData> getTop25SalesPersonsAndOpportunitiesAndRevenue(String startDate, String endDate){
		return getTop25SalesPersonAndOpportunitiesAndRevenueByOpportunities(null, startDate, endDate);
	}

	/**
	 *  Gets the all the Sales persons, Opportunities, Revenue with in provided time frame and opportunities
	 *
	 * @param startDate
	 * @param endDate
	 *
	 * @return List of Sales person data contains sales person name,no of opportunities, revenue.
	 */
	public List<TopSalesPersonData> getTop25SalesPersonAndOpportunitiesAndRevenueByOpportunities(List<String> opportunityIds, String startDate, String endDate){

		timeUtil.start();

		List<TopSalesPersonData> salesPersonsList= new ArrayList<TopSalesPersonData>();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();

		if(opportunityIds != null){
			boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		}

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		}

		TermsBuilder termAggr = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_PERSON_RAW).size(0);

		TermsBuilder childTermAggBuilder = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
				.field(ERPConstants.INVOICE_OPPORTUNITY_ID_RAW).size(0).order(Order.aggregation(SearchConstants.INVOICE_AMOUNT_AGGREGATION, false));

		SumBuilder sumAggBuilder = AggregationBuilders.sum(SearchConstants.INVOICE_AMOUNT_AGGREGATION)
				.field(ERPConstants.INVOICE_SALES_AMOUNT);

		SearchRequestBuilder builder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.setSearchType(SearchType.QUERY_THEN_FETCH).setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0).addAggregation(termAggr.subAggregation(childTermAggBuilder.subAggregation(sumAggBuilder)));

		SearchResponse searchResponse = esQueryUtils.execute(builder);

		Terms aggTerms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);

		for (Bucket bucket : aggTerms.getBuckets()) {

			TopSalesPersonData salesPersonData = new TopSalesPersonData();

			String salesPersonName = bucket.getKey();

			List<String> opportunityList = new ArrayList<String>();

			Terms childAggTerms = bucket.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			double revenueAmount = 0;
			for(Bucket childBucket : childAggTerms.getBuckets()){

				opportunityList.add(childBucket.getKey());

				Sum sumAggregation = childBucket.getAggregations().get(SearchConstants.INVOICE_AMOUNT_AGGREGATION);

				if (sumAggregation != null) {
					revenueAmount = revenueAmount + sumAggregation.getValue();
				}
			}

			salesPersonData.setSalesPerson(salesPersonName);
			salesPersonData.setOpportunities(opportunityList);
			salesPersonData.setRevenueAmount(revenueAmount);

			salesPersonsList.add(salesPersonData);

			if(salesPersonsList.size() >= 24){
				break;
			}
		}

		timeUtil.end();

		return salesPersonsList;
	}

	/**
	 * Gets the Top Competitors With in time Frame and Opportunities
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Object> getTopCompetitorsWithInTimeFrameFromOpportunities(List<String> opportunities, String startDate, String endDate){
		timeUtil.start();
		BoolFilterBuilder boolFilter = null;
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter = FilterBuilders.boolFilter();
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(startDate)
					.to(endDate));
		}

	    if(CollectionUtils.isNotEmpty(opportunities)) {
			if(boolFilter == null) {
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));
		}

		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(ERPConstants.OPPORTUNITY_ID_RAW).size(0).order(Order.aggregation(SearchConstants.SUM_AGGREGATION, false))
				.subAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT));

		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(aggregationBuilders);
		if(boolFilter != null) {
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
		}

		Map<String, Object> allCompetitors = new HashMap<>();
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		Collection<Terms.Bucket> termsBuckets = null;
		if(searchResponse.getAggregations() != null){
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			termsBuckets = terms.getBuckets();
		}

		for (Terms.Bucket termBucket : termsBuckets) {
			String opportunityId = termBucket.getKey();
			if(StringUtils.isNotBlank(opportunityId)){
				String competitorName = erpOpportunityCompetitorService.getErpOpportunityCompetitors(opportunityId);
				if(StringUtils.isNotBlank(competitorName)) {
					Sum sum = termBucket.getAggregations().get(SearchConstants.SUM_AGGREGATION);
					double revenue = sum.getValue();
					if (!allCompetitors.containsKey(competitorName)) {
						List<String> opportunityIdList = new ArrayList<>();
						RevenueOpportunitiesData competitorData = new RevenueOpportunitiesData();
						opportunityIdList.add(opportunityId);
						competitorData.setRevenueAmount(revenue);
						competitorData.setOpportunityIds(opportunityIdList);
						allCompetitors.put(competitorName, competitorData);
					}
					else {
						RevenueOpportunitiesData competitorData = (RevenueOpportunitiesData) allCompetitors.get(competitorName);
						competitorData.setRevenueAmount(competitorData.getRevenueAmount() + revenue);
						competitorData.getOpportunityIds().add(opportunityId);
						allCompetitors.put(competitorName, competitorData);
					}
				}
			}
		}
		timeUtil.end();
		LOG.info("time taken competitors - " + timeUtil.timeTakenInSec());
		return  MiriSearchUtils.sortMapByObjectValue(allCompetitors);
	}

	/**
	 * Gets the Top Competitors With in time Frame and Opportunities
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public Map<String, Object> getTopCompetitorsWithInTimeFrame(String startDate, String endDate){
		return this.getTopCompetitorsWithInTimeFrameFromOpportunities(null,	startDate, endDate);
	}

	/**
	 * Gets the Unique Opportunities for the sales person
	 * @param startDate
	 * @param endDate
	 * @param salesPerson
	 * @return
	 */
	public List<String> getWonOpportunitiesOfSalesPerson(String startDate, String endDate, String salesPerson, List<String> overallOpportunities){
		Set<String> opportunities = new TreeSet<>();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(startDate)
					.to(endDate));
		}

		if(StringUtils.isNotBlank(salesPerson)) {
			boolFilter.must(FilterBuilders.termFilter(ERPConstants.INVOICE_SALES_PERSON_RAW, salesPerson));
		}

		if(CollectionUtils.isNotEmpty(overallOpportunities)){
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, overallOpportunities));
		}

		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN);

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		while (true) {
			for (SearchHit hit : response.getHits()) {
				opportunities.add((String)hit.getSource().get(ERPConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(60000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}
		return new ArrayList<>(opportunities);
	}

	/**
	 * Gets the Unique Opportunities for the sales person
	 * @param startDate
	 * @param endDate
	 * @param salesPerson
	 * @return
	 */
	public List<String> getAllOpprtunitiesOfSalesPerson(String salesPerson,List<String> opportunityIds,String startDate,
			String endDate){
		Set<String> opportunities = new TreeSet<>();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(StringUtils.isNotEmpty(salesPerson)){
			boolFilter.must(FilterBuilders.termFilter(ERPConstants.INVOICE_SALES_PERSON_RAW, salesPerson));
		}
		if(CollectionUtils.isNotEmpty(opportunityIds)){
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(startDate)
					.to(endDate));
		}

		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setScroll(new TimeValue(6000));

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		while (true) {
			for (SearchHit hit : response.getHits()) {
				opportunities.add((String)hit.getSource().get(ERPConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(60000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}
		return new ArrayList<>(opportunities);
	}
	/**
	 * Get ADS, ASP, No of Deals and Revenue Amount for the list of opportunities
	 * @param opportunityIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public InvoiceStatsData getAdsAspDealsRevenueByOpportunities(List<String> opportunityIds, final String startDate, final String endDate) {
		timeUtil.start();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));

		if(startDate != null && endDate!= null) {
			boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		}
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION).field(CRMConstants.OPPORTUNITY_ID_RAW).size(opportunityIds.size()))
				.addAggregation(AggregationBuilders.sum(SearchConstants.INVOICE_AMOUNT_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT))
				.addAggregation(AggregationBuilders.sum(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION).field(ERPConstants.INVOICE_PRODUCT_QUANTITY));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		InvoiceStatsData adsAspDealsRevenue = new InvoiceStatsData();
		int deals = 0;
		List<String> validOpportunityIds = new ArrayList<>();
		if(searchResponse.getAggregations() != null) {
			Sum sumSalesAmountAggregation = searchResponse.getAggregations().get(SearchConstants.INVOICE_AMOUNT_AGGREGATION);
			Sum sumProdQtyAggregation = searchResponse.getAggregations().get(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION);
			Terms validOpportunityAggregation = searchResponse.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
			Collection<Terms.Bucket> validOpportunityBuckets = null;
			if(validOpportunityAggregation != null)
				validOpportunityBuckets = validOpportunityAggregation.getBuckets();

			if(validOpportunityBuckets != null) {
				deals = validOpportunityBuckets.size();
				for(Terms.Bucket bucket: validOpportunityBuckets) {
					validOpportunityIds.add(bucket.getKey());
				}
			}

			double revenueAmount = 0;
			double prodQty = 0;
			if (sumSalesAmountAggregation != null) {
				revenueAmount = sumSalesAmountAggregation.getValue();
			}
			if (sumProdQtyAggregation != null) {
				prodQty = sumProdQtyAggregation.getValue();
			}

			adsAspDealsRevenue.setAds(deals > 0 ? revenueAmount / deals : 0d);
			adsAspDealsRevenue.setAsp(prodQty > 0 ? revenueAmount / prodQty : 0d);
			adsAspDealsRevenue.setRevenueAmount(revenueAmount);
			adsAspDealsRevenue.setDealsClosed((long) deals);
			adsAspDealsRevenue.setValidOpportunities(validOpportunityIds);
		}

		timeUtil.end();
		return adsAspDealsRevenue;
	}

	/**
	  * Gets the Product opportunities
	  * @param productId
	 * @param startDate
	 * @param endDate
	 * @param opportunities
	  * @return
	  */
	public InvoiceDataPojo getWonUniqueOpportinitiesOfProduct(String productId, String startDate, String endDate, List<String> opportunities){
		return getWonUniqueOpportinitiesOfProduct(Arrays.asList(productId), startDate, endDate, opportunities);
	}
	
	/**
	  * Gets the Product opportunities
	  * @param productId
	 * @param startDate
	 * @param endDate
	 * @param opportunities
	  * @return
	  */
	public InvoiceDataPojo getWonUniqueOpportinitiesOfProduct(Collection<String> productIds, String startDate, String endDate, List<String> opportunities){
		BoolFilterBuilder boolFilter = null;

		if(productIds != null) {
			boolFilter = FilterBuilders.boolFilter();
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.PRODUCT_ID_RAW, productIds));
		}

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(ElasticSearchEnums.ERP_INVOICE_ITEM.getText())
				.setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(6000))
				.setSize(1000);

		if(boolFilter != null) {
			searchRequestBuilder.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter));
		} else {
			searchRequestBuilder.setQuery(QueryBuilders.matchAllQuery());
		}

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		List<String> invoiceItems = new ArrayList<>();

		while (true) {
			for (SearchHit hit : response.getHits()) {
				invoiceItems.add((String)hit.getSource().get(ERPConstants.INVOICE_ITEM_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}

		return this.getUniqueOpportunitiesFromInvoiceItems(invoiceItems, startDate, endDate, opportunities);
	}

	 /**
	  * Gets the Unique Opportunities for a product
	  * @param invoiceItems
	  * @param startDate
	  * @param endDate
	  * @return
	  */
	public InvoiceDataPojo getUniqueOpportunitiesFromInvoiceItems(List<String> invoiceItems, String startDate, String endDate, List<String> validOpportunities){
		InvoiceDataPojo invoiceDataPojo = new InvoiceDataPojo();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(ERPConstants.INVOICE_ITEMS_RAW, invoiceItems));

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		}

		if(CollectionUtils.isNotEmpty(validOpportunities)){
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, validOpportunities));
		}

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSearchType(SearchType.SCAN)
				.setSize(1000)
				.setScroll(new TimeValue(6000));
		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		Set<String> opportunities= new TreeSet<>();

		while (true) {
			for (SearchHit hit : response.getHits()) {
				opportunities.add((String)hit.getSource().get(ERPConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}
		double revenue = this.getRevenueByInvoiceItems(new ArrayList<>(invoiceItems), startDate, endDate, validOpportunities);
		invoiceDataPojo.setOpportunities(new ArrayList<>(opportunities));
		invoiceDataPojo.setRevenue(revenue);
		invoiceDataPojo.setInvoiceItems(invoiceItems);
		invoiceDataPojo.setProductQuantity(response.getHits().getTotalHits());
		return invoiceDataPojo;
	}


	 /**
	  * Gets the product Quantity for invoice items
	  * @param invoiceItems
	  * @param startDate
	  * @param endDate
	  * @param opportunities
	  * @return
	  */
	 public double getproductquntityFromInvoiceItems(List<String> invoiceItems, String startDate, String endDate, List<String> opportunities){
		 Client client = getTransportClient();

			BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
			if(CollectionUtils.isNotEmpty(opportunities)) {
				boolFilterBuilder.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunities));
			}
			if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
				boolFilterBuilder.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).from(startDate).to(endDate));
			}

			if(CollectionUtils.isNotEmpty(invoiceItems)){
				boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.INVOICE_ITEMS_RAW, invoiceItems));
			}

			AbstractAggregationBuilder sumProductQuantity=AggregationUtil.
					sumAggregation(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION, SearchConstants.ERP_INVOICE_PRODUCT_QUANTITY);

			SearchResponse searchResponse = client.prepareSearch(ElasticSearchEnums.ERP.getText())
					.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
					.addAggregation(sumProductQuantity)
					.setSize(0)
					.execute().actionGet();
			Sum sum = searchResponse.getAggregations().get(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION);
			return sum.getValue();
	 }

	 /**
	  * This method gives the revenue by Invoice Items
	  * @param invoiceItems
	  * @param startDate
	  * @param endDate
	  * @return
	  */
	 public double getRevenueByInvoiceItems(List<String> invoiceItems, String startDate, String endDate, List<String> opportunities){
		 BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		 boolFilter.must(FilterBuilders.termsFilter(ERPConstants.INVOICE_ITEMS_RAW, invoiceItems));

		 if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			 boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		 }

		 if(CollectionUtils.isNotEmpty(opportunities)){
			 boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));
		 }

		 SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				 .setTypes(getDocumentType())
				 .setSize(0)
				 .setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				 .addAggregation(AggregationBuilders.sum(SearchConstants.INVOICE_AMOUNT_AGGREGATION).field(SearchConstants.SALES_AMOUNT));

		 SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);

		 if(searchResponse.getAggregations() != null) {
			 Sum sumAggregation = searchResponse.getAggregations().get(SearchConstants.INVOICE_AMOUNT_AGGREGATION);
			 if (sumAggregation != null) {
				 return sumAggregation.getValue();
			 }
		 }
		 return 0;
	 }


	 /**
	  * Gets the Product opportunities
	  * @param productIds
	 * @param startDate
	 * @param endDate
	 * @param opportunities TODO
	  * @return
	  */
	 public double getDistinctCountOfOppoForProduct(List<String> productIds, String startDate, String endDate, List<String> opportunities){
		 BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();

		 if(CollectionUtils.isNotEmpty(productIds)) {
			 boolFilter.must(FilterBuilders.termsFilter(ERPConstants.PRODUCT_ID_RAW, productIds));
		 }

		 SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				 .setTypes(ElasticSearchEnums.ERP_INVOICE_ITEM.getText())
				 .setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				 .setSearchType(SearchType.SCAN)
				 .setScroll(new TimeValue(6000));
		 SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		 List<String> invoiceItems = new ArrayList<>();

		 while (true) {
			 for (SearchHit hit : response.getHits()) {
				 invoiceItems.add((String)hit.getSource().get(ERPConstants.INVOICE_ITEM_ID));
			 }
			 SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
			 response = esQueryUtils.execute(searchScrollRequestBuilder);
			 if (response.getHits().getHits().length == 0) {
				 break;
			 }
		 }

		 return this.calculateDistinctCountFromInvoices(invoiceItems, startDate, endDate, opportunities);
	 }


	 /**
	  * Gets the Unique Opportunities for a product
	  * @param invoiceItems
	  * @param startDate
	  * @param endDate
	  * @return
	  */
	 public double calculateDistinctCountFromInvoices(List<String> invoiceItems, String startDate, String endDate, List<String> validOpportunities){
		  BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		  boolFilter.must(FilterBuilders.termsFilter(ERPConstants.INVOICE_ITEMS_RAW, invoiceItems));
		  boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		  if(CollectionUtils.isNotEmpty(validOpportunities)){
			   boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, validOpportunities));
		   }

		  SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
		    .setTypes(getDocumentType())
		    .setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
		    .addAggregation(AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(ERPConstants.OPPORTUNITY_ID_RAW).size(0));
		  SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		  Terms validOpportunityAggregation = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		  Collection<Terms.Bucket> validOpportunityBuckets = null;
			if(validOpportunityAggregation != null)
				validOpportunityBuckets = validOpportunityAggregation.getBuckets();
		  return validOpportunityBuckets.size();
	 }

	/**
	 * Get ADS, ASP, Deals Closed and Revenue by opportunityIds and sales person
	 * @param opportunityIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public InvoiceStatsData getAdsAspDealsRevenueByOpportunitiesAndSalesPerson(List<String> opportunityIds, final String startDate, final String endDate, String salesPerson) {
		timeUtil.start();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		}
		boolFilter.must(FilterBuilders.termFilter(ERPConstants.INVOICE_SALES_PERSON_RAW, salesPerson));
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(ElasticSearchEnums.ERP.getText())
				.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(AggregationBuilders.terms(SearchConstants.OPPORTUNITY_AGGREGATION).field(CRMConstants.OPPORTUNITY_ID_RAW).size(opportunityIds.size()))
				.addAggregation(AggregationBuilders.sum(SearchConstants.INVOICE_AMOUNT_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT))
				.addAggregation(AggregationBuilders.sum(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION).field(ERPConstants.INVOICE_PRODUCT_QUANTITY));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		InvoiceStatsData invoiceStatsData = new InvoiceStatsData();
		int deals = 0;
		List<String> validOpportunityIds = new ArrayList<>();
		if(searchResponse.getAggregations() != null) {
			Sum sumSalesAmountAggregation = searchResponse.getAggregations().get(SearchConstants.INVOICE_AMOUNT_AGGREGATION);
			Sum sumProdQtyAggregation = searchResponse.getAggregations().get(SearchConstants.PRODUCT_QUANTITY_SUM_AGGREGATION);

			Terms validOpportunityAggregation = searchResponse.getAggregations().get(SearchConstants.OPPORTUNITY_AGGREGATION);
			Collection<Terms.Bucket> validOpportunityBuckets = null;
			if(validOpportunityAggregation != null)
				validOpportunityBuckets = validOpportunityAggregation.getBuckets();

			if(validOpportunityBuckets != null) {
				deals = validOpportunityBuckets.size();
				for(Terms.Bucket bucket: validOpportunityBuckets) {
					validOpportunityIds.add(bucket.getKey());
				}
			}

			double revenueAmount = 0;
			double prodQty = 0;
			if (sumSalesAmountAggregation != null) {
				revenueAmount = sumSalesAmountAggregation.getValue();
			}
			if (sumProdQtyAggregation != null) {
				prodQty = sumProdQtyAggregation.getValue();
			}

			invoiceStatsData.setAds(deals > 0 ? revenueAmount / deals : 0.0);
			invoiceStatsData.setAsp(prodQty != 0 ? revenueAmount / prodQty : 0.0);
			invoiceStatsData.setRevenueAmount(revenueAmount);
			invoiceStatsData.setDealsClosed((long) deals);
			invoiceStatsData.setValidOpportunities(validOpportunityIds);
		}

		timeUtil.end();
		return invoiceStatsData;
	}

	/**
	 * Get Month Wise Revenue and count of accounts
	 * @param fiscalStartDateStr
	 * @param fiscalEndDateStr
	 */
	public Map<Integer, CustomerValueData> getMonthWiseRevenueAndAccountCount(final String fiscalStartDateStr, final String fiscalEndDateStr) {
		return this.getMonthWiseRevenueAndAccountCountByOpportunities(fiscalStartDateStr, fiscalEndDateStr, null);
	}

	/**
	 * Get Month Wise Revenue and count of accounts by opportunities
	 * @param fiscalStartDateStr
	 * @param fiscalEndDateStr
	 * @param opportunityIds
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<Integer, CustomerValueData> getMonthWiseRevenueAndAccountCountByOpportunities(final String fiscalStartDateStr, final String fiscalEndDateStr, final List<String> opportunityIds) {
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, ERPConstants.INVOICE_SALES_AMOUNT);
		AbstractAggregationBuilder invoiceDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(fiscalStartDateStr, fiscalEndDateStr).minDocCount(0).subAggregation(sumInvoiceAmountByMonth)
				.subAggregation(AggregationBuilders.terms(SearchConstants.ACCOUNT_AGGREGATION).field(ERPConstants.INVOICE_ACCOUNT_NAME_RAW).size(0));

		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(fiscalStartDateStr) && StringUtils.isNotBlank(fiscalEndDateStr)) {
			boolFilterBuilder.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).gte(fiscalStartDateStr).lte(fiscalEndDateStr));
		}

		if(opportunityIds != null) {
			boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		}
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
				.addAggregation(invoiceDateAggregation);
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		//Terms monthTerms = searchResponse.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		//Collection<Terms.Bucket> monthBuckets = monthTerms.getBuckets();
		InternalHistogram datehist = searchResponse.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> monthBuckets = datehist.getBuckets();

		Map<Integer, CustomerValueData> monthWiseRevenueAndAccountName = new HashMap<>();
		CustomerValueData customerValueData;
		Map<Integer, String> updatedDates = MiriDateUtils.getUpdatedDates(fiscalStartDateStr, fiscalEndDateStr);
		int count = 0;
		for(InternalHistogram.Bucket monthBucket: monthBuckets) {
			if(updatedDates.get(count)!=null){
				Sum sumAggregation = monthBucket.getAggregations().get(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH);
				Terms accountTerms = monthBucket.getAggregations().get(SearchConstants.ACCOUNT_AGGREGATION);
				customerValueData = new CustomerValueData();
				if(accountTerms != null) {
					customerValueData.setCustomersCount(accountTerms.getBuckets().size());
				}
				if(sumAggregation != null) {
					customerValueData.setRevenue(sumAggregation.getValue());
				}
				monthWiseRevenueAndAccountName.put(count++, customerValueData);
			} else {
				monthWiseRevenueAndAccountName.put(count++, null);
			}
		}
		return monthWiseRevenueAndAccountName;
	}

	public InvoiceDataPojo getUniqueOpportunitiesAndRevenueOfProduct(String productId, String startDate, String endDate, List<String> opportunityIds){
		List<String> invoiceItems = this.getInvoiceItemsByOpportunities(opportunityIds, startDate, endDate);
		InvoiceDataPojo invoiceItemsAndOpportunities = new InvoiceDataPojo();
		List<String> opportunities = crmOpportunityProductService.getWonOpportunitiesForProductIdByOpportunities(opportunityIds, productId, startDate, endDate, null);
		double revenue = this.getRevenueOfProductFromInvoices(invoiceItems, productId);
		invoiceItemsAndOpportunities.setOpportunities(opportunities);
		invoiceItemsAndOpportunities.setInvoiceItems(invoiceItems);
		invoiceItemsAndOpportunities.setRevenue(revenue);
		return invoiceItemsAndOpportunities;

	}

	/**
	 * Gets the List of Invoice Items from opportunities
	 * @param opportunityIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public InvoiceDataPojo getInvoiceItemsAndOpportunities(List<String> opportunityIds, String startDate, String endDate){

		BoolFilterBuilder boolFilter = getBoolFilterBuilder(opportunityIds, startDate, endDate);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
													.setTypes(getDocumentType())
													.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
													.setSearchType(SearchType.SCAN)
													.setScroll(new TimeValue(6000));

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		List<String> invoiceItemIds = new ArrayList<>();
		Set<String> uniqueOpportunityIds = new TreeSet<>();

		while (true) {
			for (SearchHit hit : response.getHits()) {
				invoiceItemIds.addAll((List<String>)hit.getSource().get(ERPConstants.INVOICE_ITEMS));
				uniqueOpportunityIds.add((String) hit.getSource().get(ERPConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(60000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}
		InvoiceDataPojo invoiceDataPojo = new InvoiceDataPojo();
		invoiceDataPojo.setInvoiceItems(invoiceItemIds);
		invoiceDataPojo.setOpportunities(new ArrayList<>(uniqueOpportunityIds));
		return invoiceDataPojo;
	}


	/**
	 * Gets the Products revenue from invoice
	 * @param invoiceItems
	 * @param productId
	 * @return
	 */
	public double getRevenueOfProductFromInvoices(List<String> invoiceItems, String productId){
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(invoiceItems)){
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.INVOICE_ITEM_ID_RAW, invoiceItems));
		}
		if(StringUtils.isNotBlank(productId)){
			boolFilter.must(FilterBuilders.termFilter(ERPConstants.PRODUCT_ID_RAW, productId));
		}
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
													.setTypes(ElasticSearchEnums.ERP_INVOICE_ITEM.getText())
													.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
													.addAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(SearchConstants.AMOUNT));

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		Sum sum = response.getAggregations().get(SearchConstants.SUM_AGGREGATION);

		return sum.getValue();
	}

	/**
	 * Gets the Campaigns and Opprtunities By month leads
	 * @param campaignId
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public SearchResponse getNumberOfCustomersByMonth(List<String> opportunities, String startDate, String endDate){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));

		AbstractAggregationBuilder subaggregation = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(ERPConstants.INVOICE_ACCOUNT_NAME_RAW).size(0);

		AbstractAggregationBuilder dateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.CAMPAIGN_AGGREGATION).field(ERPConstants.INVOICE_CREATED_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD).minDocCount(0).extendedBounds(startDate, endDate).subAggregation(subaggregation);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
				.addAggregation(dateAggregation)
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		return searchResponse;
	}


	/**
	 * Returns the total of sales amount from invoices created in the given
	 * review period
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @return total of sales amount
	 */
	public double getTotalSalesAmount(final String reviewStartDate, final String reviewEndDate) {
		SumBuilder totalSalesAmountClause = AggregationBuilders.sum(GROUPNAME_TOTALSALESAMOUNT).field(SearchConstants.SALES_AMOUNT);
		Aggregations aggregation = getErpInvoiceFieldSum(reviewStartDate, reviewEndDate, totalSalesAmountClause);
		return ((InternalSum)aggregation.get(GROUPNAME_TOTALSALESAMOUNT)).getValue();
	}

	/**
	 * Returns the total of all the product quantities from invoices created in
	 * the given review period
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @return total of product quantities
	 */
//	public double getTotalProductCount(final String reviewStartDate, final String reviewEndDate) {
//		SumBuilder totalProductsClause = AggregationBuilders.sum(GROUPNAME_TOTALPRODUCTS).field("invoiceDocumentRefId"/*SearchConstants.PRODUCT_QUANTITY*/);
//		Aggregations aggregation = getErpInvoiceFieldSum(reviewStartDate, reviewEndDate, totalProductsClause);
//		return ((InternalSum)aggregation.get(GROUPNAME_TOTALPRODUCTS)).getValue();
//	}
	public double getTotalProductCount(final String reviewStartDate, final String reviewEndDate) {
		Client client = getTransportClient();

		BoolQueryBuilder fiscalConditionClause = QueryBuilders.boolQuery();
		fiscalConditionClause.must(QueryBuilders.rangeQuery(SearchConstants.CREATED_DATE)
													.gte(reviewStartDate)
													.lte(reviewEndDate));

		CountRequestBuilder countRequestBuilder = client.prepareCount(getIndex())
													.setTypes(getDocumentType())
													.setQuery(fiscalConditionClause);

		LOG.trace("TotalProductCount : Query : " + countRequestBuilder);

		CountResponse countResponse = countRequestBuilder.execute().actionGet();
		long count = countResponse.getCount();

		return Double.valueOf(count);
	}

	/**
	 * Returns the Aggregations result instance of Invoices for given
	 * aggregation clause and for the give review period
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @param agregationClause aggregation clause to be applied
	 * @return Aggregations result instance of Invoices
	 */
	private Aggregations getErpInvoiceFieldSum(final String reviewStartDate, final String reviewEndDate,
			final SumBuilder agregationClause) {
		Client client = getTransportClient();

		BoolQueryBuilder fiscalConditionClause = QueryBuilders.boolQuery();
		fiscalConditionClause.must(QueryBuilders.rangeQuery(SearchConstants.CREATED_DATE)
													.gte(reviewStartDate)
													.lte(reviewEndDate));

		//Modifying the index name to erp_all_revenue to depict all revenue from MI, SG and ThirdParty
		SearchRequestBuilder searchBuilder = client.prepareSearch(getIndex())
													.setTypes(getDocumentType())
													.setQuery(fiscalConditionClause)
													.addAggregation(agregationClause)
													.setSize(0);

		LOG.trace("ErpInvoiceFieldSum : Query : " + searchBuilder);

		SearchResponse searchResponse = searchBuilder.execute().actionGet();
		return searchResponse.getAggregations();
	}

	/**
	 * Returns count of accounts with revenue above given limit for the given review period.
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @param upperBoundLimit revenue limit to apply for the accounts
	 * @return count of accounts with revenue above given limit
	 */
	public Number getNumberOfAccountsAboveGivenRevenueLimit(final String reviewStartDate, final String reviewEndDate, final long upperBoundLimit) {
		Client client = getTransportClient();

		BoolQueryBuilder fiscalConditionClause = QueryBuilders.boolQuery();
		fiscalConditionClause.must(QueryBuilders.rangeQuery(SearchConstants.CREATED_DATE)
													.gte(reviewStartDate)
													.lte(reviewEndDate));


		TermsBuilder aggregation = AggregationBuilders.terms(GROUPNAME_GROUPEDACCOUNTS)
														.field(SearchConstants.ACCOUNT_ID_RAW)
														.size(0) //0 sets to Integer.MAX_VALUE
														.order(Order.aggregation(GROUPNAME_TOTALSALESAMOUNT, false))
															.subAggregation(AggregationBuilders.sum(GROUPNAME_TOTALSALESAMOUNT).field(SearchConstants.SALES_AMOUNT));

		SearchRequestBuilder searchBuilder = client.prepareSearch(getIndex())
													.setTypes(getDocumentType())
													.setQuery(fiscalConditionClause)
													.addAggregation(aggregation)
													.setSize(0);

		//LOG.debug("NumberOfAccountsAboveGivenRevenueLimit : Query : "+searchBuilder);

		SearchResponse searchResponse = searchBuilder.execute().actionGet();
		Aggregations aggregations = searchResponse.getAggregations();
		StringTerms groupedAccounts = aggregations.get(GROUPNAME_GROUPEDACCOUNTS);
		Collection<Bucket> buckets = groupedAccounts.getBuckets();

		long topRevenueAccounts = 0L;
		for (Bucket bucket : buckets) {
			InternalSum sum = bucket.getAggregations().get(GROUPNAME_TOTALSALESAMOUNT);
			if (sum.getValue() >= upperBoundLimit) {
				topRevenueAccounts++;
			}
		}

		return Long.valueOf(topRevenueAccounts);
	}

	/**
	 * Returns total of revenue generated in the review period for the given opportunity ids.
	 *
	 * @param reviewStartDate start date of review period
	 * @param reviewEndDate end date of review period
	 * @param wonMiOpportunityIds list of marketing influenced "Won and Closed" opportunity ids
	 * @return total of revenue generated in the review period for the given opportunity ids
	 */
	public double getTotalRevenueForOpportunties(final String reviewStartDate, final String reviewEndDate, final List<String> wonMiOpportunityIds) {
		Client client = getTransportClient();
		SumBuilder totalSalesAmountClause = AggregationBuilders.sum(GROUPNAME_TOTALSALESAMOUNT).field(ERPConstants.INVOICE_SALES_AMOUNT);

		BoolFilterBuilder matchFilterClause = FilterBuilders.boolFilter()
				.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, wonMiOpportunityIds))
				.must(FilterBuilders.rangeFilter(SearchConstants.CREATED_DATE).gte(reviewStartDate).lte(reviewEndDate));


		SearchRequestBuilder revenueSearchBuilder = client.prepareSearch(getIndex()).setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), matchFilterClause))
				.addAggregation(totalSalesAmountClause).setSize(0);

		//LOG.debug("MarketingSpendRoi: revenueSearch Query : "+revenueSearchBuilder);
		SearchResponse revenueSearchResponse = revenueSearchBuilder.execute().actionGet();

		InternalSum revenueAggregation = revenueSearchResponse.getAggregations().get(GROUPNAME_TOTALSALESAMOUNT);
		return revenueAggregation.getValue();
	}

	/**
	 * Get deals from opportunities
	 */

	public long getDealsFromOpportunities(List<String> opportunities){
		long deals=0;
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(CRMConstants.OPPORTUNITY_ID_RAW, opportunities));
			TermsBuilder aggregation = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
					.field(CRMConstants.OPPORTUNITY_ID_RAW).size(0);

		//	CardinalityBuilder aggregation = AggregationBuilders.cardinality(SearchConstants.CARDINALITY_AGGR)
			//		.field(CRMConstants.OPPORTUNITY_ID_RAW);

			SearchRequestBuilder revenueSearchBuilder = getTransportClient().prepareSearch(getIndex()).setTypes(getDocumentType())
					.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
					.addAggregation(aggregation).setSize(0);
			SearchResponse revenueSearchResponse =esQueryUtils.execute(revenueSearchBuilder);
			Terms aggr= revenueSearchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			if(aggr.getBuckets()!=null){
				deals=aggr.getBuckets().size();
			}
		}

		return deals;

	}


	 /** Gets the Opportunities And Revenue
	 * @param opportunities
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public InvoiceDataPojo getRevenueAndUniqueOpportunities(List<String> opportunities, String startDate, String endDate){
		InvoiceDataPojo invoiceDataPojo = new InvoiceDataPojo();
		Set<String> uniqueOpportunities = new TreeSet<>();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(CollectionUtils.isNotEmpty(opportunities)){
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunities));
		}
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		}

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
													.setTypes(getDocumentType())
													.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
													.setSearchType(SearchType.SCAN)
													.setScroll(new TimeValue(6000));

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		while (true) {
			for (SearchHit hit : response.getHits()) {
				uniqueOpportunities.add((String)hit.getSource().get(ERPConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(6000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}

		double revenue = this.getInvoiceAmountByOpportunityIds(opportunities, startDate, endDate);
		invoiceDataPojo.setOpportunities(new ArrayList<>(uniqueOpportunities));
		invoiceDataPojo.setRevenue(revenue);
		return invoiceDataPojo;
	}


	/**
	 * Gets the Unique Opportunities for the sales person
	 * @param startDate
	 * @param endDate
	 * @param salesPerson
	 * @return
	 */
	public InvoiceDataPojo geUniqueOpportunitiesOfSalesPersonAndRevenue(String startDate, String endDate, String salesPerson, List<String> overallOpportunities){
		InvoiceDataPojo invoiceDataPojo = new InvoiceDataPojo();
		Set<String> opportunities = new TreeSet<>();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(startDate)
					.to(endDate));
		}

		if(StringUtils.isNotBlank(salesPerson)) {
			boolFilter.must(FilterBuilders.termFilter(ERPConstants.INVOICE_SALES_PERSON_RAW, salesPerson));
		}

		if(CollectionUtils.isNotEmpty(overallOpportunities)){
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, overallOpportunities));
		}

		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN);

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		while (true) {
			for (SearchHit hit : response.getHits()) {
				opportunities.add((String)hit.getSource().get(ERPConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(60000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}

		double revenue = this.getInvoiceAmountByOpportunityIds(new ArrayList<>(opportunities), startDate, endDate);
		invoiceDataPojo.setOpportunities(new ArrayList<>(opportunities));
		invoiceDataPojo.setRevenue(revenue);
		return invoiceDataPojo;
	}


	/**
	 * Gets the Unique Opportunities for the sales person
	 * @param startDate
	 * @param endDate
	 * @param salesPerson
	 * @return
	 */
	public InvoiceDataPojo geUniqueOpportunitiesOfCustomerAndRevenue(String startDate, String endDate, String customerName, List<String> overallOpportunities){
		InvoiceDataPojo invoiceDataPojo = new InvoiceDataPojo();
		Set<String> opportunities = new TreeSet<>();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)){
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE)
					.from(startDate)
					.to(endDate));
		}

		if(StringUtils.isNotBlank(customerName)) {
			boolFilter.must(FilterBuilders.termFilter(ERPConstants.INVOICE_ACCOUNT_NAME_RAW, customerName));
		}

		if(CollectionUtils.isNotEmpty(overallOpportunities)){
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, overallOpportunities));
		}

		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setScroll(new TimeValue(6000))
				.setSearchType(SearchType.SCAN);

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);
		while (true) {
			for (SearchHit hit : response.getHits()) {
				opportunities.add((String)hit.getSource().get(ERPConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(60000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}
		double revenue = this.getInvoiceAmountByOpportunityIds(new ArrayList<>(opportunities), startDate, endDate);
		invoiceDataPojo.setOpportunities(new ArrayList<>(opportunities));
		invoiceDataPojo.setRevenue(revenue);
		return invoiceDataPojo;
	}

	/**
	 * Gets the Monthwise opportunities
	 * @return
	 */
	public Map<String, List<String>> getMonthWiseOpportunities(){
		Map<String, List<String>> opportunitiesByMonth = new HashMap<>();


		AbstractAggregationBuilder aggregation = AggregationBuilders
				.dateHistogram(SearchConstants.DATE_HISTOGRAM).field(ERPConstants.INVOICE_CREATED_DATE)
				.minDocCount(0)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD);

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
											.prepareSearch(getIndex())
											.setTypes(getDocumentType())
											.addAggregation(aggregation);


		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);


		InternalHistogram<InternalHistogram.Bucket> dateHisto = searchResponse.getAggregations().get(SearchConstants.DATE_HISTOGRAM);
		Collection<InternalHistogram.Bucket> buckets = dateHisto.getBuckets();
		String previousDate = null;
		for (InternalHistogram.Bucket bucket : buckets) {
			parseStringToDate(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD, bucket.getKey());
			if(StringUtils.isNotBlank(previousDate)){
				getOpportunitiesBetweenDates(previousDate, bucket.getKey());
				opportunitiesByMonth.put(previousDate, getOpportunitiesBetweenDates(previousDate, bucket.getKey()));
			}
			previousDate = bucket.getKey();
		}
		return opportunitiesByMonth;
	}

	/**
	 * Get Opportunities Between Dates
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getOpportunitiesBetweenDates(String startDate, String endDate){
		Set<String>  opprtunities =  new HashSet<>();
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));

		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
											.prepareSearch(getIndex())
											.setTypes(getDocumentType())
											.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
											.setScroll(new TimeValue(6000));

		SearchResponse  response = esQueryUtils.execute(searchRequestBuilder);
		while (true) {
			for (SearchHit hit : response.getHits()) {
				opprtunities.add((String)hit.getSource().get(ERPConstants.OPPORTUNITY_ID));
			}
			SearchScrollRequestBuilder searchScrollRequestBuilder =  getTransportClient().prepareSearchScroll(response.getScrollId()).setScroll(new TimeValue(60000));
			response = esQueryUtils.execute(searchScrollRequestBuilder);
			if (response.getHits().getHits().length == 0) {
				break;
			}
		}
		return new ArrayList<>(opprtunities);
	}
	
	
	/**
	 * Get Opportunities Between Dates
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public int getOpportunityCountBetweenDates(String startDate, String endDate){
		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		
		TermsBuilder aggregationBuilders = AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION).field(ERPConstants.OPPORTUNITY_ID_RAW).size(0);
		
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
				.prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(aggregationBuilders);
		
		SearchResponse  response = esQueryUtils.execute(searchRequestBuilder);
		
		Terms terms = response.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
		List<Bucket> buckets = terms.getBuckets();
		return buckets.size();
	}
	
	

	/**
	 * Gets the revenue of asales Person
	 * @param startDate
	 * @param endDate
	 * @param salesPerson
	 * @return
	 */
	public double getRevenueForSalesPerson(String startDate, String endDate, String salesPerson, List<String> overallOpportunities) {
		BoolFilterBuilder boolFilter = null;

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter = FilterBuilders.boolFilter();
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE).gte(startDate).lte(endDate));
		}

		if(StringUtils.isNotBlank(salesPerson)) {
			if(boolFilter == null) {
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.termFilter(ERPConstants.INVOICE_SALES_PERSON_RAW, salesPerson));
		}

		if(CollectionUtils.isNotEmpty(overallOpportunities)) {
			if(boolFilter == null) {
				boolFilter = FilterBuilders.boolFilter();
			}
			boolFilter.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, overallOpportunities));
		}

		SearchRequestBuilder searchRequestBuilder =  this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setSize(0)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(AggregationBuilders.sum(SearchConstants.SUM_AGGREGATION).field(ERPConstants.INVOICE_SALES_AMOUNT));

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		Sum sum = response.getAggregations().get(SearchConstants.SUM_AGGREGATION);
		return sum.getValue();
	}

	/**
	 *
	 * @param opportunityIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<FilterData> getDealsByProductForOpportunities(List<String> opportunityIds, String startDate, String endDate, int size) {
		List<TopProductsDataPojo> topProducts = this.getTopProductsFromTheOpportunitieswithInTimeFrame(opportunityIds, startDate, endDate, null);
		List<TopProductsDataPojo> topLevelThreeProducts = crmProductService.getLevelThreeSegregatedProducts(topProducts, CRMConstants.CRM_PRODUCT_PRODUCT_NAME_RAW);
		List<FilterData> productDeals = new ArrayList<>();
		FilterData filterData;
		for(TopProductsDataPojo topProduct: topLevelThreeProducts) {
			filterData = new FilterData();
			filterData.setName(topProduct.getProductName());
			InvoiceDataPojo invoiceDataPojo = this.getWonUniqueOpportinitiesOfProduct(topProduct.getProductIds(), startDate, endDate, opportunityIds);
			if(invoiceDataPojo != null && CollectionUtils.isNotEmpty(invoiceDataPojo.getOpportunities())) {
				filterData.setDeals(invoiceDataPojo.getOpportunities().size());
			}
			filterData.setRevenue(topProduct.getRevenueAmount());
			productDeals.add(filterData);
			if(productDeals.size() == size) {
				break;
			}
		}
		return productDeals;
	}
	
	
	/**
	 * Method to return the revenue for every month from a new document erp_all_invoice to 
	 * depict all revenue from MI, SG and ThirdParty
	 * @return 
	 *//*
	public Map<Integer, MultipleAxesChartData> getERPTotalRevenue(Calendar startDate, Calendar endDate) {

		Map<Integer, String> monthAndYearMap = MiriDateUtils.getMonthsBetweenDates(startDate, endDate);
		List<Integer> months = new LinkedList<>(monthAndYearMap.keySet());

		String minBound = MiriDateUtils.getElasticSearchFormattedDate(startDate);
		String maxBound = MiriDateUtils.getElasticSearchFormattedDate(endDate);

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		if (StringUtils.isNotEmpty(minBound) && StringUtils.isNotEmpty(maxBound)) {
			boolFilter.must(FilterBuilders.rangeFilter(SearchConstants.ERP_INVOICE_CREATION_DATE).from(minBound)
					.to(maxBound).includeLower(true).includeUpper(true));
		}
		
		// Create a aggregation get the sum of invoice amounts
		AbstractAggregationBuilder sumInvoiceAmountByMonth = AggregationUtil
				.sumAggregation(SearchConstants.SUM_INVOICE_AMOUNT_BY_MONTH, SearchConstants.INVOICE_AMOUNT);

		// Create a aggregation to sort the invoices by month
		AbstractAggregationBuilder invoiceDateAggregation = AggregationBuilders
				.dateHistogram(SearchConstants.INVOICE_DATE_AGGEGATION).field(SearchConstants.ERP_INVOICE_CREATION_DATE)
				.interval(DateHistogram.Interval.MONTH).format(MiriDateUtils.DATE_FORMAT_YYYY_MM_DD)
				.extendedBounds(minBound, maxBound).minDocCount(0).subAggregation(sumInvoiceAmountByMonth);

		SearchRequestBuilder searchRequestBuilder = getTransportClient().prepareSearch(ERP_TEMP_INDEX)
				.setTypes(ERP_ALL_INVOICE_DOC_TYPE)
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.addAggregation(invoiceDateAggregation).setSize(0);

		SearchResponse response = esQueryUtils.execute(searchRequestBuilder);

		InternalHistogram datehist = response.getAggregations().get(SearchConstants.INVOICE_DATE_AGGEGATION);
		Collection<InternalHistogram.Bucket> buckets = datehist.getBuckets();
		Map<Integer, MultipleAxesChartData> resultsMap = MiriSearchUtils.populateRevenuePojoResult(buckets, null,
				months);

		return resultsMap;
	}*/
	
	/**
	 * Gets the REsponse for first opportunity of a customer
	 * @param opportunityIds
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<String> getFirstOpportunitiesForCustomer(List<String> opportunityIds, String startDate, String endDate){
		BoolFilterBuilder boolFilterBuilder = FilterBuilders.boolFilter();
		boolFilterBuilder.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).gte(startDate).lte(endDate));
		boolFilterBuilder.must(FilterBuilders.termsFilter(ERPConstants.OPPORTUNITY_ID_RAW, opportunityIds));
		TermsBuilder aggregationBuilders =  AggregationBuilders.terms(SearchConstants.TERMS_AGGREGATION)
											.field(ERPConstants.INVOICE_ACCOUNT_NAME_RAW)
											.order(Order.aggregation(SearchConstants.INVOICE_DATE_AGGEGATION, false))
											.size(0);
		MinBuilder minDateBuilder = AggregationBuilders
									.min(SearchConstants.INVOICE_DATE_AGGEGATION)
									.field(ERPConstants.INVOICE_CREATED_DATE);
		TopHitsBuilder tophits = AggregationBuilders
								.topHits(SearchConstants.TOP_HITS_AGGREGATION)
								.setFetchSource(new String[] {ERPConstants.OPPORTUNITY_ID, ERPConstants.INVOICE_CREATED_DATE}, null)
								.setSize(1);
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient()
												.prepareSearch(ElasticSearchEnums.ERP.getText())
												.setTypes(ElasticSearchEnums.ERP_INVOICE.getText())
												.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilterBuilder))
												.addAggregation(aggregationBuilders.subAggregation(minDateBuilder).subAggregation(tophits));
		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		return this.fetchFirstOpportunitiesForCustomer(searchResponse);
	}
	
	/**
	 * Gets the opportunities from the response
	 * @param searchResponse
	 * @return
	 */
	public List<String> fetchFirstOpportunitiesForCustomer(SearchResponse searchResponse){
		Set<String> opportunities = new TreeSet<String>();
		if(null != searchResponse.getAggregations()){
			Terms terms = searchResponse.getAggregations().get(SearchConstants.TERMS_AGGREGATION);
			Collection<Terms.Bucket> buckets = terms.getBuckets();
			for (Terms.Bucket bucket : buckets) {
				TopHits topHitsAggr = bucket.getAggregations().get(SearchConstants.TOP_HITS_AGGREGATION);
				SearchHit[] opportunityHits = topHitsAggr.getHits().getHits();
				for (SearchHit searchhit : opportunityHits) {
					opportunities.add((String)searchhit.getSource().get(SearchConstants.OPPORTUNITY_ID));
				}
			}		
		}
		return new ArrayList<>(opportunities);
	}
	
	/**
	 * MarketingSpendRoiMetric
	 *
	 * @param opportunityIds
	 * @param startDate
	 *            TODO
	 * @param endDate
	 *            TODO
	 * @return
	 */
	public InvoiceDataPojo getInvoiceAmountAndInvoiceByOpportunityIds(List<String> opportunityIds, String startDate, String endDate) {
		timeUtil.start();

		BoolFilterBuilder boolFilter = FilterBuilders.boolFilter();
		boolFilter.must(FilterBuilders.termsFilter(SearchConstants.OPPORTUNITY_ID_RAW, opportunityIds));

		if(StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			boolFilter.must(FilterBuilders.rangeFilter(ERPConstants.INVOICE_CREATED_DATE).from(startDate).to(endDate));
		}
		SearchRequestBuilder searchRequestBuilder = this.getTransportClient().prepareSearch(getIndex())
				.setTypes(getDocumentType())
				.setQuery(QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), boolFilter))
				.setSize(0)
				.addAggregation(AggregationBuilders.sum(SearchConstants.INVOICE_AMOUNT_AGGREGATION).field(SearchConstants.SALES_AMOUNT));

		SearchResponse searchResponse = esQueryUtils.execute(searchRequestBuilder);
		double revenue = 0;

		if(searchResponse.getAggregations() != null) {
			Sum sumAggregation = searchResponse.getAggregations().get(SearchConstants.INVOICE_AMOUNT_AGGREGATION);
			if (sumAggregation != null) {
				revenue =  sumAggregation.getValue();
			}
		}
		timeUtil.end();
		InvoiceDataPojo invoiceDataPojo = new InvoiceDataPojo();
		invoiceDataPojo.setRevenue(revenue);
		invoiceDataPojo.setProductQuantity(searchResponse.getHits().getTotalHits());
		return invoiceDataPojo;
	}
}
