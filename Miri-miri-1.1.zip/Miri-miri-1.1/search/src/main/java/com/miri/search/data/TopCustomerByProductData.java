package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

public class TopCustomerByProductData  implements Serializable{
	List<TopCustomerProductsData> topCustomerProducts;

	public List<TopCustomerProductsData> getTopCustomerProducts() {
		return topCustomerProducts;
	}

	public void setTopCustomerProducts(List<TopCustomerProductsData> topCustomerProducts) {
		this.topCustomerProducts = topCustomerProducts;
	}
}
	