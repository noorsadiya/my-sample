/**
 * 
 */
package com.miri.search.exception;

/**
 * @author Chandra
 *
 */
public class MiriSearchServiceException extends RuntimeException {

	private static final long serialVersionUID = 754958938600761490L;

	public MiriSearchServiceException() {
	}

	public MiriSearchServiceException(String message) {
		super(message);
	}

	public MiriSearchServiceException(Throwable cause) {
		super(cause);
	}

	public MiriSearchServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public MiriSearchServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
