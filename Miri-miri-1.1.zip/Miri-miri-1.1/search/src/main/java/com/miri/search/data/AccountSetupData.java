package com.miri.search.data;

import java.io.Serializable;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class AccountSetupData implements Serializable {

	private Map<String, Object> accountData;

	public Map<String, Object> getAccountData() {
		return accountData;
	}

	public void setAccountData(Map<String, Object> accountData) {
		this.accountData = accountData;
	}

}
