package com.miri.search.data;

import java.io.Serializable;
import java.util.List;

public class ExcelPojo implements Serializable{
	
	private static final long serialVersionUID = -7094830895771439989L;

	private String graphName;
	
	private String headerFields;
	
	private List<String> rowData;
	
	public String getGraphName() {
		return graphName;
	}

	public void setGraphName(String name) {
		this.graphName = name;
	}

	public String getHeaderFields() {
		return headerFields;
	}

	public void setHeaderFields(String headerFields) {
		this.headerFields = headerFields;
	}

	public List<String> getRowData() {
		return rowData;
	}

	public void setRowData(List<String> rowData) {
		this.rowData = rowData;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ExcelPojo [graphName=" + graphName + ", headerFields=" + headerFields + ", data size=" + rowData.size() + "]";
	}
	
}
