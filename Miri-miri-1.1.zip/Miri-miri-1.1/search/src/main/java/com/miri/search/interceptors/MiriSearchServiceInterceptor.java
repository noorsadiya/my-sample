/**
 * 
 */
package com.miri.search.interceptors;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

import com.miri.cache.client.CacheKeyUtil;
import com.miri.cache.client.MiriCacheClient;
import com.miri.search.exception.MiriESException;
import com.miri.search.exception.MiriSearchServiceException;

/**
 * @author Chandra
 * 
 * MiriSearchServiceInterceptor: Intercepts all CRM, MAP and ERP service layer methods.
 *
 */
@Aspect
public class MiriSearchServiceInterceptor {
	private static final Logger LOGGER = Logger.getLogger(MiriSearchServiceInterceptor.class);

	@Pointcut("execution(public * com.miri.search.service.crm.*.*(..)) "
			+ "|| execution(public * com.miri.search.service.map.*.*(..)) "
			+ "|| execution(public * com.miri.search.service.erp.*.*(..))"
			+ "|| execution(public * com.miri.search.service.manual.*.*(..))")
	public void miriSearchServicePointcut() {
	}

	@Around("miriSearchServicePointcut()")
	public Object interceptMiriSearchService(ProceedingJoinPoint pjp) throws MiriSearchServiceException {
		String interceptMessage = pjp.getTarget().getClass().getSimpleName() + " : " + pjp.getSignature().getName();
//		LOGGER.info("Executing Miri Search Service : " + interceptMessage);
		long start = System.currentTimeMillis();
		Object returnValue = null;
		try {
			String cacheKey = CacheKeyUtil.createKey(interceptMessage, pjp.getArgs());
//			LOGGER.info("Cache key : " + cacheKey);
			returnValue = MiriCacheClient.getInstance().get(cacheKey);
			if (returnValue == null) {
				returnValue = pjp.proceed();
				MiriCacheClient.getInstance().set(cacheKey, MiriCacheClient.EXPIRE_IN_ONE_DAY, returnValue);
			}
			
			//returnValue = pjp.proceed();
			long elapsedTime = System.currentTimeMillis() - start;
//			LOGGER.info("Method execution time for" + interceptMessage + " : " + elapsedTime + " MilliSec.");
		} catch (MiriESException ex) {
			LOGGER.error("Miri Search Service Exception: ", ex); 
			throw new MiriSearchServiceException(ex.getMessage(), ex.getCause());
		} catch (Throwable ex) {
			LOGGER.error("UNKNOWN Miri Search Service ERROR: ", ex);
			throw new MiriSearchServiceException(ex.getMessage(), ex.getCause());
		}
		return returnValue;
	}
}
